@echo off
chcp 65001 >nul
cd /d "%~dp0"
title NEXUS - installazione
echo.
echo  Installazione di NEXUS
echo  ------------------------------
echo  Cartella: %~dp0
echo.

rem ---- 1. Python 3.12 (o 3.13) installato sul PC
set PY=
py -3.12 -c "import sys" >nul 2>nul && set PY=py -3.12
if not defined PY py -3.13 -c "import sys" >nul 2>nul && set PY=py -3.13
if not defined PY (
  echo  [ERRORE] Python 3.12 non trovato.
  echo  Scaricalo da https://www.python.org/downloads/ ^(versione 3.12^), spunta "Add python.exe to PATH" e ripeti.
  goto fallito
)
echo  [1/4] Python trovato: %PY%

rem ---- 2. Ambiente Python del programma (.venv): se e' rimasto a meta' si ripara o si rifa'
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" -m pip --version >nul 2>nul && goto ambiente_ok
  echo  [2/4] Ambiente .venv incompleto ^(manca pip^): provo a ripararlo...
  ".venv\Scripts\python.exe" -m ensurepip --upgrade >nul 2>nul
  ".venv\Scripts\python.exe" -m pip --version >nul 2>nul && goto ambiente_ok
  echo  [2/4] Non riparabile: lo cancello e lo ricreo.
  rmdir /s /q ".venv"
  if exist ".venv" (
    echo  [ERRORE] Non riesco a cancellare la cartella .venv: forse il Gestionale e' ancora aperto.
    echo  Chiudi la finestra di NEXUS ^(o termina python.exe^), poi ripeti.
    goto fallito
  )
)
echo  [2/4] Creo l'ambiente Python del programma ^(.venv^)...
%PY% -m venv .venv
if errorlevel 1 (
  echo.
  echo  [ERRORE] Creazione dell'ambiente Python non riuscita: il motivo e' scritto qui sopra.
  goto fallito
)
".venv\Scripts\python.exe" -m pip --version >nul 2>nul || ".venv\Scripts\python.exe" -m ensurepip --upgrade
".venv\Scripts\python.exe" -m pip --version >nul 2>nul
if errorlevel 1 (
  echo.
  echo  [ERRORE] L'ambiente e' stato creato ma senza pip ^(lo strumento che scarica le librerie^).
  echo  Di solito dipende dall'installazione di Python: reinstalla Python 3.12 da python.org
  echo  ^(non dal Microsoft Store^) con le opzioni predefinite, poi ripeti.
  goto fallito
)
:ambiente_ok
echo  [2/4] Ambiente Python pronto.

rem ---- 3. Librerie (serve Internet)
echo  [3/4] Scarico e installo le librerie ^(serve Internet, qualche minuto^)...
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul 2>nul
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo  [ERRORE] Installazione delle librerie non riuscita: il motivo e' scritto qui sopra.
  echo  Se parla di connessione, proxy o certificati: controlla Internet e ripeti.
  goto fallito
)

rem ---- 4. Controllo finale e impostazioni
".venv\Scripts\python.exe" -c "import gestionale, fastapi, sqlalchemy, lxml, openpyxl" 2>nul
if errorlevel 1 (
  echo  [ERRORE] Le librerie risultano installate ma il programma non parte: mandami questa finestra.
  ".venv\Scripts\python.exe" -c "import gestionale, fastapi, sqlalchemy, lxml, openpyxl"
  goto fallito
)
echo  [4/4] Controllo finale superato.

rem ---- Impostazioni: se manca config.json si copia quello della versione precedente (O6),
rem      cercato nelle cartelle Gestionale_AD_v* accanto a questa (anche dentro la cartella doppia di Estrai tutto)
if exist "config.json" goto config_ok
set "PRECEDENTE="
for /d %%D in ("%~dp0..\Gestionale_AD_v*") do if exist "%%~fD\config.json" if /i not "%%~fD\"=="%~dp0" set "PRECEDENTE=%%~fD"
for /d %%D in ("%~dp0..\..\Gestionale_AD_v*") do if exist "%%~fD\config.json" if /i not "%%~fD\"=="%~dp0" set "PRECEDENTE=%%~fD"
for /d %%D in ("%~dp0..\..\Gestionale_AD_v*") do for /d %%E in ("%%~fD\Gestionale_AD_v*") do if exist "%%~fE\config.json" if /i not "%%~fE\"=="%~dp0" set "PRECEDENTE=%%~fE"
if not defined PRECEDENTE goto config_nuovo
copy "%PRECEDENTE%\config.json" "config.json" >nul
echo  Impostazioni ^(config.json^) copiate dalla versione precedente:
echo    %PRECEDENTE%
goto config_ok
:config_nuovo
copy "config.esempio.json" "config.json" >nul
echo  Creato un config.json nuovo: se avevi una versione precedente, copia qui il suo config.json.
:config_ok
echo.
echo  Installazione completata. Per avviare: doppio clic su AVVIA_WINDOWS.bat
echo  Controlla che "cartella_dati" in config.json indichi la cartella dei tuoi dati ^(LEGGIMI, paragrafo 7^).
pause
exit /b 0

:fallito
echo.
echo  Installazione NON riuscita. Se non e' chiaro il perche', fai uno screenshot di questa finestra.
pause
exit /b 1
