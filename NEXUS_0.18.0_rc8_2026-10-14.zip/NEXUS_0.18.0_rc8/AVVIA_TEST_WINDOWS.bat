@echo off
setlocal
set GESTIONALE_DATABASE_URL=
chcp 65001 >nul
cd /d "%~dp0"
title NEXUS - AMBIENTE DI PROVA (verbali)
if not exist ".venv\Scripts\python.exe" (
  echo  Prima esegui INSTALLA_WINDOWS.bat
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -c "import httpx" >nul 2>nul
if errorlevel 1 ".venv\Scripts\python.exe" -m pip install -r requirements-sviluppo.txt
if not exist "..\GestionaleAD_dati_TEST\AMBIENTE_DI_PROVA_COMPLETO.txt" (
  echo  Creo l'ambiente di prova: utenti, clienti, impianti, preventivi e verifiche finti...
  ".venv\Scripts\python.exe" strumenti\crea_ambiente_di_prova.py
  if errorlevel 1 (
    pause
    exit /b 1
  )
)
set GESTIONALE_CARTELLA_DATI=%~dp0..\GestionaleAD_dati_TEST
echo.
echo  ==============================================================
echo   AMBIENTE DI PROVA - dati finti, NON l'archivio vero
echo   Cartella: ..\GestionaleAD_dati_TEST
echo   Utenti: admin, responsabile, tecnico1, tecnico2, segreteria
echo   Password per tutti: password di prova
echo   Apri il browser su  http://127.0.0.1:8462
echo  ==============================================================
echo.
".venv\Scripts\python.exe" -m gestionale
pause
