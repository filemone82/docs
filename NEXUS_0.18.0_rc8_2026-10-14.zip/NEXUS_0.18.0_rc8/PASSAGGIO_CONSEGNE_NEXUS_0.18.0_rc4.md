# Passaggio di consegne — NEXUS 0.18.0_rc4

**Data:** 14 ottobre 2026. **Stato:** incremento DPR/PostgreSQL per collaudo;
non è una release autorizzata per la produzione. Leggere anche
`NEXUS_DPR_POSTGRESQL_COLLAUDO.md` e il codice, che prevale su questo riepilogo
se emergono divergenze. La base è `NEXUS_0.18.0_rc3` (migrazione `0028`);
questa versione aggiunge `0029`. Nessun database o backup reale è stato
modificato per preparare questa versione.

## Obiettivo e decisioni dell'utente

NEXUS è il futuro gestionale integrato di AD (rami DPR 462/01 e DM 11/04/2011)
e della distinta I&C/IEC. AD_DPR sarà messo in produzione per primo (obiettivo
gennaio–marzo 2027), seguito da AD_DM e I&C. L'applicazione autonoma
verbalizzAI, oggi in produzione su SQLite, deve continuare a funzionare fino
al passaggio a NEXUS_DPR. A quel punto i verbali devono essere parte del
percorso DPR in NEXUS, nello stesso PostgreSQL, senza un'applicazione o uno
switch separato. Importare una volta sola i verbali prodotti nel frattempo
dalla copia autonoma, senza perderne PDF, Word, revisioni o registro eventi.

**Condivisione DPR/DM:** clienti/sedi, logiche di preventivi (anteprima,
stampa, invio), registrazione ordini, assegnazione a tecnici, registrazione
verifiche, riesame e fatturazione appartengono ai moduli comuni, con ambito e
regole specifiche; non creare una seconda implementazione DPR di questi
processi. Nella base rc3 sono già presenti `anagrafica`, `preventivi`,
`verifiche`, `finanza` e i corrispondenti flussi DM. L'attuale interfaccia
verbali DPR è ancora servita a `/verbali` con il ponte del modulo incorporato:
**la completa fusione della pagina nella verifica DPR non è ancora fatta**.

Altri vincoli confermati: I&C è una società distinta con proprie finanze e
vista; anagrafiche e attrezzature possono essere comuni. La vista AD_DM non
deve menzionare esplicitamente I&C, pur mantenendo un audit riservato fedele.
La migrazione Garda/tre MariaDB e degli archivi documentali resta successiva;
nella transizione non è richiesta sincronizzazione automatica con Garda.

## Stato ereditato dalla rc3

- `nexus_locale` dell'utente è PostgreSQL 18 su Windows, schema a `0028`.
  35 test nativi rc3 sono passati; backup `nexus_locale_rc3_0028.dump` di
  391039 byte e backup applicativo completo sono stati verificati dall'utente.
- Il gestionale centrale usa PostgreSQL, ma i verbali incorporati usano ancora
  `verbali/archivio.sqlite` e i documenti sono copiati su disco. Accessi,
  permessi e posta erano già connessi a NEXUS via
  `gestionale/moduli/verbali/{archivio,ponte,api,servizio}.py`.
- Il motore VerbalizzAI originale si trova in
  `gestionale/terzi/verbalizzai/storage.py`: molti SQL SQLite, backup
  `.adbackup.zip` con `archive.json`, manifest, documenti per SHA256. Il test
  `tests/test_verbalizzai_identico.py` impedisce modifiche accidentali al
  codice vendorizzato. In rc4 **non è stato modificato**.

## Modifiche in questa rc4

1. `gestionale/migrazioni/versions/0029_archivio_verbali_pg.py` crea nel DB
   NEXUS lo schema `verbali` con `meta`, `objects`, `documents` (bytea),
   `events`, `users` storici e indici di ricerca. La migrazione è senza
   operazioni dati per SQLite, ma porta anche SQLite alla revisione `0029`.
2. `gestionale/moduli/verbali/postgresql.py` è un adattatore specifico che
   conserva le API del motore di verbalizzAI: connessioni psycopg verso lo
   schema dedicato, transazioni, lock fra processi, conflitti di revisione,
   ricerche JSON, registri e backup. La logica dei verbali rimane una sola,
   nel motore originale. Conservarne la semantica nelle correzioni.
3. `gestionale/moduli/verbali/archivio.py` aggiunge
   `ArchivioVerbaliPostgresql`, mantenendo utenti e permessi attivi in NEXUS.
4. `gestionale/moduli/verbali/importa_postgresql.py` importa **solo backup
   completi** (`.adbackup.zip`, formato 2) in archivio PG vuoto. Confronta
   oggetti, documenti, metadati e tutti gli eventi originali; il ripristino
   aggiunge un evento di migrazione. Verifica nuovamente il backup esportato.
   La sorgente non viene modificata. Se PG è popolato, rifiuta l'importazione.
5. `core/config.py` e `app.py`: `verbali_postgresql` è `false` per
   impostazione iniziale. Con `true` e URL PostgreSQL apre il nuovo backend;
   con un vecchio `archivio.sqlite` presente e PG vuoto ferma l'avvio,
   richiedendo prima l'importazione. Avviare l'app con flag true **solo dopo**
   l'importazione, altrimenti il caricamento iniziale dei modelli popola PG e
   impedisce l'importazione una tantum.
6. `moduli/backup/postgresql.py`: quando i verbali sono in PG il dump del DB
   li include già, quindi non aggiunge/ripristina una seconda copia separata.
   La modalità rc3 con verbali SQLite conserva il vecchio comportamento.
7. `tests/postgresql/test_verbali_pg.py` comprende tre test per migrazione e
   confronto, rifiuto di backup incompleti e avvio dell'app su PG senza
   `archivio.sqlite`.
8. `gestionale/moduli/beni/modelli.py` preserva le tre colonne
   `tipo_ver_gvr_*` come `VARCHAR(20)` nel metadata SQLite storico e come
   `TEXT` in PostgreSQL (migrazione `0028`); il test di portabilità in
   `tests/test_porting_postgresql.py` valuta esplicitamente il tipo PG.

## Verifiche e limiti effettivi

- Localmente: 13 test dell'area verbali su SQLite passati; `ruff` sui nuovi
  file passa; i tre test nativi PG sono raccolti ma **saltati** perché in
  questo ambiente non esiste un server PostgreSQL. Il collaudo Windows
  dell'utente è perciò indispensabile prima di abilitare il backend.
- Prima della correzione dei tipi ereditati dalla rc3, la suite generale ha
  dato **372 passed, 38 skipped, 3 failed** (11 subtest passati, 11m30s).
  I tre fallimenti erano controlli SQLite di coerenza tra le migrazioni
  `VARCHAR(20)` e il modello Python divenuto `TEXT` nella rc3. Dopo la
  correzione, i tre casi più gli undici test di portabilità PG passano
  insieme (**14 passed**). Non è stata ripetuta l'intera suite di 11 minuti:
  i 372 test restanti erano già passati e l'ultima modifica è circoscritta
  ai tipi delle tre colonne e all'asserzione del test di portabilità.
  Non scrivere «test PG superati» basandosi sui `skipped`.
- Non è stata effettuata una prova su copia del backup reale dell'utente, né
  un import verso `nexus_locale`, né un deploy sul VPS.
- Il nuovo backend è un adattatore del motore vendorizzato, non ancora una
  riscrittura di tutte le regole. In caso di fallimenti PG correggere
  l'adattatore preservando il motore originale e aggiungere un test di
  regressione che eserciti il flusso reale.

## Procedura immediata per la prossima istanza

1. Recuperare questa rc4, leggere i file citati e verificare che la suite
   generale sia terminata. Non modificare il database `nexus_locale` per
   completare i test.
2. Nel PostgreSQL locale Windows usare `tests/postgresql/test_verbali_pg.py`
   con `NEXUS_TEST_POSTGRESQL_ADMIN_URL`: la fixture crea e distrugge solo
   database temporanei `nexustest_<uuid>`. Controllare `3 passed`, non
   `3 skipped`; acquisire il traceback integrale se fallisce.
3. Correggere i problemi individuati, rieseguire i tre test e i test comuni
   interessati. Estendere le prove native a compilazione, emissione,
   revisione, allegati, invio e riesame tramite API NEXUS, con ruoli distinti.
4. Preparare **un database di prova distinto** e una copia del backup reale
   completo verbalizzAI. Eseguire il comando d'importazione solo a NEXUS
   fermo; verificare SHA, conteggi, collegamenti e PDF. Collaudare creazione,
   verifica e ripristino del backup NEXUS sul database di prova.
5. Solo dopo questi risultati progettare il taglio finale: arresto delle
   scritture sulla copia autonoma, ultimo backup completo, importazione,
   riconciliazione con incarichi/verifiche NEXUS, attivazione backend PG e
   possibilità provata di ripristino. Il collegamento visuale del modulo
   `/verbali` va poi inglobato nel percorso delle verifiche DPR, senza
   duplicare i flussi comuni DM.

**Regola per passaggi fra LLM:** questa cartella/versione è l'unica base di
partenza; prima di cambiare i file registrare obiettivo e versione iniziale,
poi annotare file cambiati, ragione, test realmente eseguiti, limitazioni e
prossimo passo. Non far modificare gli stessi file a due istanze in parallelo.
