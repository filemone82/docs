# NEXUS 0.18.0 rc2 — aggiornamento e collaudo locale

Questa è una candidata di collaudo. Corregge la prova nativa PostgreSQL 18 avviata su Windows (rc1: 20 passati, 4 falliti, 15 errori) e aggiunge la migrazione 0028 dei cataloghi DM. La suite locale SQLite della rc2 ha terminato con 374 test passati, 35 prove PostgreSQL saltate, 1 avviso e 11 subtest passati. I cambiamenti non attestano ancora l'esito sul server PostgreSQL: la suite nativa va ripetuta sul PC con il ruolo `nexus_locale`. Non usare ancora rc2 per sostituire Garda o per spostare VerbalizzAI in produzione.

## Prima di aprire rc2

1. Conserva la cartella originale `NEXUS_0.18.0_rc1` e il backup già ottenuto (`nexus_locale.dump`, 270 KB, comando `pg_dump` con uscita 0). Conserva anche la copia completa della cartella `Dati_PostgreSQL_Collaudo` e di `config.postgresql.collaudo.json` che hai fatto sul Desktop. Il solo dump PostgreSQL non contiene i file dell'archivio VerbalizzAI incorporato.
2. Estrai rc2 in una **nuova cartella**, accanto alla rc1. Non sovrascrivere il codice rc1 o i backup.
3. Copia **soltanto** `config.postgresql.collaudo.json` dalla rc1 nella cartella del programma rc2. Verifica che il suo campo `cartella_dati` punti ancora alla cartella originale dei dati (o a una copia completa scelta esplicitamente). Non copiare password o URL PostgreSQL in questo file. Il database `nexus_locale` è sul server e non si sposta copiando cartelle.
4. Installa le librerie con `INSTALLA_WINDOWS.bat` nella nuova cartella. Il pacchetto include `AVVIA_NEXUS_POSTGRESQL_WINDOWS.bat`: avvia con **quello**, non con `AVVIA_WINDOWS.bat`. Inserisci la password del ruolo PostgreSQL quando richiesta, senza mostrarla a nessuno. Il primo avvio fa un backup `pre_aggiornamento` e applica la 0028 al database `nexus_locale`. Se il backup preliminare fallisce, la migrazione non parte: conserva l'errore.
5. Nell'interfaccia controlla il cliente e la sede che avevi già creato. In pgAdmin, collegato al database **nexus_locale**, esegui `SELECT version_num FROM alembic_version;`: il risultato atteso è `0028`. Controlla anche che la sezione tipi e tariffe DM mostri i dati. Finché il database è alla 0028, **non riaprire rc1** sullo stesso database: è codice precedente allo schema.

Il backup automatico in `config.postgresql.collaudo.json` è disabilitato. Il backup di avvio PostgreSQL include i documenti del gestionale, ma durante il *pre_aggiornamento* l'oggetto VerbalizzAI non è ancora inizializzato e quel backup non contiene il suo archivio incorporato. Per questa prova rimangono indispensabili le copie complete della cartella dati e il dump indipendente già conservati. Il VerbalizzAI autonomo su `verbalizzai.adsrl.net` resta separato e continua a usare SQLite.

## Prova automatica PostgreSQL

Con NEXUS fermo, apri PowerShell nella **nuova cartella rc2**. Se la variabile della precedente sessione non c'è più, imposta una nuova URL per il *database di amministrazione `postgres`* con lo stesso utente di collaudo; non scrivere la password in un messaggio o nel codice:

```powershell
$env:GESTIONALE_PG_BIN = "C:\Program Files\PostgreSQL\18\bin"
$pgPassword = Read-Host "Password PostgreSQL di nexus_locale" -AsSecureString
$pgCredenziale = [System.Net.NetworkCredential]::new("", $pgPassword)
$pgPasswordUrl = [uri]::EscapeDataString($pgCredenziale.Password)
$env:NEXUS_TEST_POSTGRESQL_ADMIN_URL = "postgresql+psycopg://nexus_locale:${pgPasswordUrl}@127.0.0.1:5432/postgres"
Remove-Variable pgPassword, pgCredenziale, pgPasswordUrl
& ".\.venv\Scripts\python.exe" -m pytest -q tests/postgresql --timeout=240
```

La suite crea database temporanei `nexustest_<UUID>` e li elimina senza `DROP ... FORCE`. Non elimina `nexus_locale` né usa i suoi dati; richiede al ruolo il permesso `CREATEDB`, già previsto per questa prova. Conserva la riga finale con test passati/falliti e il dettaglio di eventuali errori; **non inviare la URL con password**. Un fallimento nativo richiede analisi prima di passare alla VPS.

## Ambito e limiti

La baseline PostgreSQL 0027 conteneva lo schema, ma non le 6 famiglie GVR, 31 tipi, 72 specifiche, 162 compatibilità e 314 tariffe DM storiche. La 0028 importa le righe mancanti con ID originali, controlla l'identità degli ID già presenti e non sovrascrive tariffe o descrizioni modificate. SQLite attraversa 0028 senza modificare dati. La migrazione inversa PostgreSQL è deliberatamente bloccata: per tornare a 0027 occorre un ripristino completo e coordinato di database e file, dopo aver fermato NEXUS.

Questo pacchetto non implementa ancora l'attività EX/IEC, i confini dei permessi finanziari AD–IEC, l'importazione dei tre MariaDB Garda con documenti, né la conversione a PostgreSQL dei Verbali incorporati. Questi restano passaggi distinti da collaudare prima del passaggio in produzione. Il collaudo sulla VPS avrà senso dopo l'esito nativo locale e con un archivio di staging isolato.
