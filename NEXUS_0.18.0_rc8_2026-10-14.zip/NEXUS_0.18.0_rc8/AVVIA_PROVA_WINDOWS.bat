@echo off
setlocal
set GESTIONALE_DATABASE_URL=
chcp 65001 >nul
cd /d "%~dp0"
title NEXUS - ARCHIVIO DI PROVA
if not exist ".venv\Scripts\python.exe" (
  echo  Prima esegui INSTALLA_WINDOWS.bat
  pause
  exit /b 1
)
if not exist "..\GestionaleAD_dati_PROVA\database.sqlite" ".venv\Scripts\python.exe" strumenti\genera_dati_prova.py
set GESTIONALE_CARTELLA_DATI=%~dp0..\GestionaleAD_dati_PROVA
echo  ATTENZIONE: archivio di PROVA, non quello vero.
".venv\Scripts\python.exe" -m gestionale
pause
