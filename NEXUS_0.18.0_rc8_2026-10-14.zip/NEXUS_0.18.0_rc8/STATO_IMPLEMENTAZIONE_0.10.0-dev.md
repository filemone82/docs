# Incremento di sviluppo DPR–DM 0.10.0-dev

Versione 1.0 — 9 ottobre 2026. Codice effettivamente realizzato a partire dalla 0.9.1, nell’unico progetto integrato. Nessuna istanza parallela avviata. Questo è un punto di avanzamento recuperabile, **non il rilascio completo R99**: il flusso tecnico DM, INAIL e il raccordo amministrativo DM sono ancora da completare.

## Cosa cambia concretamente

Le offerte DM utilizzano le stesse testate, righe, documenti, accettazioni e riesami del DPR. La distinzione è esplicita per ambito; la numerazione resta distinta. Il DM mantiene cliente e sede obbligatori e seleziona soltanto le attrezzature della sede, come adsrl. Il DPR mantiene l’offerta al cliente con impianti multisede. Non è stato introdotto un secondo archivio DM.

| Parte | Codice disponibile | Limite da conservare |
|---|---|---|
| Schede SC/SP/GVR | Identificazione, classificazione, parametri tecnici e date suddivisi in linguette; esenzione F/T/I, tipo prossima verifica, CF costruttore, reparto/riferimento/CE, PED/fluidi/insieme/pacco, portata/panieri e parametri camere. | Maschere ancora da confrontare nell’uso Windows; collegamenti portale/gestione licenze, tutti i riferimenti agli ultimi lavori e azioni Garda non sono completi. |
| Controlli | Matricola 4/1/5/2 con zeri iniziali; nuove schede richiedono all.7, ID specifica, esenzione e tipo prossima verifica. Compatibilità e famiglia GVR derivata da all.7. | Le vecchie schede 0.9 incomplete non sono riempite automaticamente: si controllano i campi toccati e l’ingresso nel preventivo. Non inventare una classificazione per gli importati. |
| Tariffe DM | 132 righe GVR e 182 SC/SP dal backup, conservate con provenienza e importi in centesimi. Selezione V1/V2/V3/V4, messa in servizio, SC/SP e combinazioni GVR. | Valori del backup, non attestazione di tariffario normativo attualmente vigente. Edizione/gestione del tariffario, EX e altri contributi/trasferte restano da raccordare. |
| Offerte DM | Cliente+sede, serie letterale e numero, attrezzature, combinazioni, sconti, licenza gestionale opzionale, revisioni, accettazione scritta anche parziale, RC comune. | Generazione dalle scadenze e tutte le varianti Garda non completate. Non autorizzato il nuovo multisede ordinario DM. |
| Documenti | Modello Word originale Garda, elenchi GVR/SC-SP e clausola licenza opzionale; stesso servizio DPR per anteprima, approvazione, ritocchi e invio. Fotografie per gli emessi. | Word effettivamente compilato; conversione PDF DM reale e resa grafica Windows non collaudate qui. Il ciclo PDF nei test ordinari usa un convertitore simulato. |
| Nome offerta DM | Nome Garda: Preventivo, numero/serie con slash sostituiti, data, ragione sociale; pulizia e limite 80 caratteri. Email proposta dalla sede. | Nomi di verbali, schede di prima verifica e allegati INAIL restano nel registro N01–N14, da implementare nei rispettivi flussi. Nessun invio esterno eseguito durante le prove. |
| Incarichi DM | Una riga accettata genera un incarico collegato al bene **solo dopo RC conforme**, senza duplicarlo ripetendo il riesame. Copia della fotografia commerciale. | Stato disponibile soltanto **da assegnare**. Affidamento, esecuzione, numerazione, verbali, riesame tecnico e aggiornamenti di scadenza NON sono implementati da questa tabella. |
| Duplicati | Blocco per stessa attrezzatura/tipo/componenti già preventivate; controllo anche modificando le righe dello stesso preventivo. Componenti disgiunte possono essere offerte separatamente. | Annullamento libera la prestazione. Il controllo di nuovo ciclo dopo lavoro completato va raccordato quando esiste il flusso tecnico DM; non presentarlo già completo. |
| DPR esistente | Percorso commerciale/tecnico e finanza precedenti conservati; proiezione degli impianti sul parco e correzione R98 restano. | Nessuna prova di produzione o di PostgreSQL. VerbalizzAI incorporato resta 0.3.32.3, autonomo/VPS invariati. |

Non sono deroghe alle regole Garda: le parti mancanti sono lavoro ancora aperto. R73 resta vincolante e l’accordo R99 non è segnato soddisfatto da un preventivo funzionante.

## Riscontro Garda utilizzato

Sorgente adsrl: `cust/meta/attrezzature.js`, `preventivi.js`, `preventivi_righe.js`; `cust/_custom.php` per tariffazione, salvataggio attributi e nomi/invio delle offerte; `std/fw/gi_common.php` per l’effettivo arrotondamento. Database: cataloghi e tabelle `tariffe_gvr`/`tariffe_sc_sp`. Modello originale `cust/modelli/preventivo.docx` ricevuto nel backup.

GVR prima verifica: V1 con messa in servizio, V2 senza. Successiva: V3 per funzionamento o interna, V4 per integrità/composite. Le tubazioni non accettano interna, neppure in una combinazione. SC/SP usa la compatibilità fra all.7 e ID specifica. Si conservano combinazioni per riga: due componenti preventivate insieme non producono automaticamente due incarichi.

**Particolarità degli sconti da non “correggere” tacitamente:** Garda arrotonda a due decimali la frazione sconto/100 tramite `gi_bcdiv`, quindi moltiplica tramite `gi_bcmul` arrotondando al centesimo. Per 311,17 € e 12,5% usa 0,13 e ottiene 270,72 €. Il nuovo percorso DM conserva questo risultato. Un eventuale diverso calcolo richiede valutazione esplicita; il DPR mantiene il proprio comportamento precedente.

## Migrazione e recupero del codice

Migrazione applicativa **0012**, successiva a 0011: estende le offerte comuni e le righe, aggiunge `dm_tariffe` e `dm_incarichi`. Le offerte precedenti diventano ambito DPR con serie derivata dall’anno, senza riscrivere numero, stato, righe o documenti. Le FK dei beni/sedi sono dichiarate. Il vincolo consente alle righe di puntare a impianto DPR oppure asset DM, senza entrambi.

La prova da 0011 contiene cliente/sede, attrezzatura GVR con attributi e camera, impianto DPR e offerta DPR inviata con documento; verifica tutti i campi delle tabelle precedenti, gli ID, i riferimenti e le FK dopo migrazione. Il registro conserva gli eventi precedenti e aggiunge l’evento di aggiornamento. Backup pre-aggiornamento presente. Copiare una tabella di test non equivale a importare gli archivi Garda di esercizio.

La 0.9.1 resta conservata. Ripresa del nuovo lavoro: pacchetto `Gestionale_AD_0.10.0-dev_checkpoint_DPR_DM_2026-10-09.zip`, cartella `Gestionale_AD_integrato_sviluppo`, file stato dedicato e migrazione 0012. Non ricominciare da 0.9.1 perdendo questo incremento, non ricreare 0012 e non avviare un nuovo AD_DM autonomo.

Per un’eventuale prova locale utilizzare il launcher **AVVIA_COLLAUDO_WINDOWS.bat**, che usa Dati_Collaudo separato. Per migrare un collaudo precedente lavorare sulla copia completa dell’archivio. Per tornare alla versione precedente serve il backup precedente, non lo stesso database aggiornato. Il pacchetto è sorgente di sviluppo, non sostituzione proposta per l’esercizio.

## Prove osservate

168 test passati nella suite completa finale (147 della base e 21 DM), Linux/Python 3.12.14/SQLite; 1 avviso della suite. Ruff E9/F sui file applicativi interessati e controllo sintattico JavaScript passati. Alembic non rileva differenze fra schema 0012 e modelli dichiarati.

Il controllo DOM+HTTP usa il JavaScript effettivo e un backend locale isolato: nuova/modifica GVR, parametri tecnici e linguette, famiglia derivata, camere L/DN e volume, CND con report, PSV/taratura comune, creazione dell’offerta DM dalla sede e aggiunta della verifica multipla con tariffa. Non è una prova grafica in browser Windows.

I test hanno individuato e corretto anche la rimozione della **tabella** del prezzo licenza nel Word quando la licenza non è proposta: non bastava eliminare i paragrafi. Il modello originale è preservato. Nessun archivio utente, originale S3, servizio Aruba o VPS è stato modificato.

## Prossimo blocco autorizzato

Proseguire dal codice salvato: flusso tecnico DM e aggiornamenti per componenti, generatore GVR/SC-SP e schede di prima verifica con nomi Garda, fatturazione DM collegata e rendicontazione trimestrale INAIL. Completare anche classificazione/riferimenti/azioni delle schede e tariffazione/EX/scadenze. Il flusso va ricavato dal PHP e dalle relazioni del dump, senza estendere automaticamente la macchina DPR al DM. I&C resta nel completamento successivo; l’import operativo XLS/XLSX resta alla fine.

Controllare le regole già analizzate nei rapporti 06/07/11/12 prima di aggiungere nuovi servizi. Non contrassegnare DM o INAIL come completi senza esecuzione dei rispettivi scenari e pacchetti. Il kit parallelo del rapporto 22 conserva la precedente baseline: se in futuro si aprono istanze, fornire il presente checkpoint e le versioni correnti di 00/04/16/19/21/23. Al momento l’utente conferma che nessuna istanza parallela è stata lanciata.
