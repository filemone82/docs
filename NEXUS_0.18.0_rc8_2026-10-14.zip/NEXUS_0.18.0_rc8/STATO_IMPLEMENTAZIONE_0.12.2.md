# Stato della consegna 0.12.2

11 ottobre 2026. Schema Alembic 0015. Base per il passo B del documento 18 (migrazione a secco dei tre gestionali e motore fatture multi-sezionale), poi AD_dpr «viable».

Cosa contiene in più rispetto alla 0.12.1-wip1: `documentazione/30_Differenze_0.12.2_2026-10-11.md`. Lo stato delle aree (DPR, nucleo comune, DM, EX, I&C, migrazione) è quello descritto nel documento 18 § 2.2, con le correzioni del passo A applicate. Fatture DM e INAIL restano bozza backend non collaudata. I documenti di stato precedenti sono evidenze storiche.
