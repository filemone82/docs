@echo off
setlocal
set GESTIONALE_DATABASE_URL=
chcp 65001 >nul
cd /d "%~dp0"
title NEXUS - aggiunta di AD_dm (adsrl) all'archivio importato da Garda
if not exist ".venv\Scripts\python.exe" (
  echo  Prima esegui INSTALLA_WINDOWS.bat
  pause
  exit /b 1
)
if not exist "..\GestionaleAD_dati_GARDA\database.sqlite" (
  echo  Archivio non ancora creato: esegui prima IMPORTA_DA_GARDA_WINDOWS.bat con il file di ingecert
  pause
  exit /b 1
)
echo.
echo  Aggiunge AD_dm (adsrl) all'archivio ..\GestionaleAD_dati_GARDA gia' importato da ingecert:
echo  clienti (fusi per partita IVA o codice fiscale), sedi, attrezzature SC/SP/GVR, camere,
echo  accessori e date iniziali. Si fa una volta sola; il database di Garda NON viene toccato.
echo  Chiudi prima il programma se e' aperto su quell'archivio (AVVIA_GARDA_WINDOWS.bat).
echo.
set "ADSRL=%~1"
if "%ADSRL%"=="" set /p "ADSRL= Trascina qui il file .sql di ADSRL e premi Invio: "
set "ADSRL=%ADSRL:"=%"
if not exist "%ADSRL%" (
  echo  File non trovato: %ADSRL%
  pause
  exit /b 1
)
".venv\Scripts\python.exe" strumenti\importa_da_garda.py --aggiungi-adsrl "%ADSRL%"
echo.
echo  Per aprirlo: AVVIA_GARDA_WINDOWS.bat  (stessa password di prima)
pause
