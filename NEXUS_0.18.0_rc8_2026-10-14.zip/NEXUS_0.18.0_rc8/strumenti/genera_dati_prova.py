"""Crea un ARCHIVIO DI PROVA separato con circa 10 anni di registro operazioni simulato (300.000 righe),
per provare a mano la velocità delle griglie. Non tocca mai l'archivio vero.

Uso (dalla cartella del programma):
    .venv\\Scripts\\python.exe strumenti\\genera_dati_prova.py        (Windows)
    .venv/bin/python strumenti/genera_dati_prova.py                    (Linux)

Poi si avvia il programma su quell'archivio con AVVIA_PROVA_WINDOWS.bat e si entra con
utente «prova» e password «archivio simulato 2016».
"""

from __future__ import annotations

import random
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import insert  # noqa: E402

from gestionale.app import prepara_archivio  # noqa: E402
from gestionale.core.config import CARTELLA_PROGRAMMA, Config  # noqa: E402
from gestionale.moduli.registro.modelli import RegistroOperazione  # noqa: E402
from gestionale.moduli.registro.servizio import IMPRONTA_INIZIALE, _impronta  # noqa: E402
from gestionale.moduli.utenti import servizio as utenti  # noqa: E402

CARTELLA = CARTELLA_PROGRAMMA.parent / "GestionaleAD_dati_PROVA"
RIGHE = 300_000


def main() -> None:
    if (CARTELLA / "database.sqlite").exists():
        print(f"L'archivio di prova esiste già in {CARTELLA}: cancellalo a mano se vuoi rigenerarlo.")
        return
    cfg = Config(cartella_dati=CARTELLA, backup_automatico=False)
    arc = prepara_archivio(cfg)
    with arc.scrittura() as s:
        utenti.crea_primo_amministratore(s, cfg, "prova", "Utente di prova", "archivio simulato 2016")
    with arc.scrittura() as s:
        ultima = s.query(RegistroOperazione).order_by(RegistroOperazione.id.desc()).first()
        precedente = ultima.impronta if ultima else IMPRONTA_INIZIALE
        azioni = ["preventivo.crea", "preventivo.invia", "verbale.emetti", "accesso.entrata", "cliente.modifica"]
        nomi = ["Anna Bianchi", "Mario Rossi", "Luca Verdi", "Federico Amateis", "Giulia Neri"]
        quando = datetime(2016, 1, 4, 8, 0)
        righe = []
        for i in range(RIGHE):
            quando += timedelta(minutes=random.randint(5, 25))
            r = RegistroOperazione(quando=quando, utente_id=None, utente_nome=random.choice(nomi), azione=random.choice(azioni),
                                   oggetto_tipo="prova", oggetto_id=str(i),
                                   descrizione=f"Operazione simulata n. {i} sul cliente di prova {random.randint(1, 2700)}",
                                   dettagli="{}", impronta_precedente=precedente)
            r.impronta = _impronta(precedente, r)  # catena valida: il controllo di integrità resta «tutto in ordine»
            precedente = r.impronta
            righe.append({c: getattr(r, c) for c in ("quando", "utente_id", "utente_nome", "azione", "oggetto_tipo",
                                                     "oggetto_id", "descrizione", "dettagli", "impronta_precedente", "impronta")})
        s.execute(insert(RegistroOperazione), righe)
    arc.chiudi()
    print(f"Archivio di prova creato in {CARTELLA} con {RIGHE} righe di registro. Utente: prova · password: archivio simulato 2016")


if __name__ == "__main__":
    import os
    if os.environ.get("GESTIONALE_DATABASE_URL"):
        raise SystemExit("Questo strumento storico prepara SQLite. Per PostgreSQL usare il collaudo dedicato; nessun archivio è stato creato.")
    main()
