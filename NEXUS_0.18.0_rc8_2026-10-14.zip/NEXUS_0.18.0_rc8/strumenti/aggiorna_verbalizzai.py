"""Copia una versione di VerbalizzAI dentro il gestionale (gestionale/terzi/verbalizzai), senza toccarne il codice.

Uso (dalla cartella del programma):
    .venv\\Scripts\\python.exe strumenti\\aggiorna_verbalizzai.py C:\\percorso\\VerbalizzAI_AD_v0.3.32.1
    python strumenti/aggiorna_verbalizzai.py /percorso/VerbalizzAI_AD_v0.3.32.1.zip

Cosa fa:
1. copia i file Python della cartella principale di VerbalizzAI (tranne gli strumenti di avvio), la cartella
   `static/` e i modelli dei verbali rev. 02 (`modelli_rev02/m01/*.docx` → `modelli/`);
2. toglie i file Python della versione precedente che la nuova non ha più;
3. rende «relativi» gli import tra i file di VerbalizzAI (`from storage import …` → `from .storage import …`):
   è l'UNICA modifica al codice di VerbalizzAI, fatta in automatico;
4. controlla che i file attesi ci siano, che nessun import assoluto sia rimasto e che tutto si compili;
5. scrive la versione in `terzi/verbalizzai/__init__.py` (VERSIONE) e copia VERSIONI.md.

Dopo: eseguire tutti i test (ESEGUI_TEST_WINDOWS.bat). Il test `tests/test_ponte_contratto.py` dice subito
se la nuova versione ha cambiato qualcosa che il gestionale usa.
"""

from __future__ import annotations

import ast
import os
import re
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

RADICE = Path(__file__).resolve().parents[1]
DESTINAZIONE = RADICE / "gestionale" / "terzi" / "verbalizzai"
ESCLUSI = {"avvia_test.py"}  # avvio autonomo di VerbalizzAI: nel gestionale non serve
ATTESI = {"app.py", "storage.py", "wordio.py", "forms.py", "rules.py", "templates.py", "pdfconv.py", "mailer.py", "xlsxio.py"}


def _sorgente(percorso: Path) -> tuple[Path, tempfile.TemporaryDirectory | None]:
    if percorso.is_file() and percorso.suffix.lower() == ".zip":
        tmp = tempfile.TemporaryDirectory()
        with zipfile.ZipFile(percorso) as z:
            for nome in z.namelist():
                if nome.startswith("/") or ".." in Path(nome).parts:
                    raise SystemExit(f"Zip non valido: percorso sospetto {nome!r}")
            z.extractall(tmp.name)
        cartelle = [p.parent for p in Path(tmp.name).rglob("storage.py")]
        if len(cartelle) != 1:
            raise SystemExit("Nello zip non trovo una sola cartella di VerbalizzAI (con storage.py).")
        return cartelle[0], tmp
    if not (percorso / "storage.py").exists():
        raise SystemExit(f"{percorso} non sembra una cartella di VerbalizzAI (manca storage.py).")
    return percorso, None


def rendi_relativi(testo: str, moduli: set[str]) -> str:
    # Python ammette «import pdfconv, layout, templates» e import interni alle
    # funzioni. Si trasformano i soli nodi import, lasciando invariato il resto.
    righe = testo.splitlines(keepends=True)
    posizioni = [0]
    for riga in righe:
        posizioni.append(posizioni[-1] + len(riga))

    def posizione(riga: int, colonna: int) -> int:
        # Gli offset AST sono byte UTF-8, non indici di caratteri.
        return posizioni[riga - 1] + len(righe[riga - 1].encode('utf-8')[:colonna].decode('utf-8'))

    modifiche = []
    for nodo in ast.walk(ast.parse(testo)):
        sostituzione = None
        if isinstance(nodo, ast.Import) and any(x.name in moduli for x in nodo.names):
            parti = []
            for x in nodo.names:
                nome = x.name + (f' as {x.asname}' if x.asname else '')
                parti.append(('from . import ' if x.name in moduli else 'import ') + nome)
            sostituzione = '; '.join(parti)
        elif isinstance(nodo, ast.ImportFrom) and nodo.level == 0 and nodo.module in moduli:
            inizio = posizione(nodo.lineno, nodo.col_offset)
            fine = posizione(nodo.end_lineno, nodo.end_col_offset)
            sostituzione = testo[inizio:fine].replace('from ', 'from .', 1)
        if sostituzione is not None:
            modifiche.append((posizione(nodo.lineno, nodo.col_offset),
                              posizione(nodo.end_lineno, nodo.end_col_offset), sostituzione))
    for inizio, fine, sostituzione in sorted(modifiche, reverse=True):
        testo = testo[:inizio] + sostituzione + testo[fine:]
    nomi = "|".join(sorted(moduli))
    testo = re.sub(rf"__import__\((['\"])({nomi})\1\)", r"__import__(__package__ + '.\2', fromlist=['\2'])", testo)
    return testo


def import_assoluti_rimasti(testo: str, moduli: set[str]) -> list[str]:
    rimasti = []
    for nodo in ast.walk(ast.parse(testo)):
        if isinstance(nodo, ast.Import):
            rimasti.extend(f'import {x.name}' for x in nodo.names if x.name in moduli)
        elif isinstance(nodo, ast.ImportFrom) and nodo.level == 0 and nodo.module in moduli:
            rimasti.append(f'from {nodo.module} import')
    nomi = "|".join(sorted(moduli))
    rimasti.extend(m.group(0) for m in re.finditer(rf"__import__\(['\"]({nomi})['\"]\)", testo))
    return rimasti


IMPRONTE = "IMPRONTE_ORIGINE.json"


def impronte_cartella(cartella: Path) -> dict[str, str]:
    """SHA-256 di ogni file della copia incorporata (percorsi con «/»), esclusi l'elenco stesso e le cache Python."""
    import hashlib
    out = {}
    for f in sorted(cartella.rglob("*")):
        rel = f.relative_to(cartella).as_posix()
        if f.is_file() and rel != IMPRONTE and "__pycache__" not in f.parts:
            out[rel] = hashlib.sha256(f.read_bytes()).hexdigest()
    return out


def scrivi_impronte(cartella: Path, versione: str, origine: str) -> None:
    """R111: elenco delle impronte della copia appena fatta. Il test di contratto lo confronta a ogni esecuzione:
    se qualcuno modifica a mano un file di VerbalizzAI dentro il gestionale, il test fallisce."""
    import json
    dati = {"versione": versione, "origine": origine,
            "regola": "Copia identica a VerbalizzAI in produzione; unica differenza ammessa: import resi relativi.",
            "file": impronte_cartella(cartella)}
    (cartella / IMPRONTE).write_text(json.dumps(dati, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")


def aggiorna(percorso: Path) -> str:
    sorgente, tmp = _sorgente(percorso)
    try:
        file_py = sorted(p for p in sorgente.glob("*.py") if p.name not in ESCLUSI)
        nomi = {p.name for p in file_py}
        mancanti = ATTESI - nomi
        if mancanti:
            raise SystemExit(f"Mancano file attesi in VerbalizzAI: {', '.join(sorted(mancanti))}")
        moduli = {p.stem for p in file_py}
        versione = re.search(r"APP_VERSION\s*=\s*['\"]([^'\"]+)", (sorgente / "storage.py").read_text(encoding="utf-8"))
        versione = versione.group(1) if versione else "sconosciuta"

        # Validare tutti i sorgenti e i modelli PRIMA di sostituire la versione
        # incorporata: un errore non deve lasciare metà vecchia/metà nuova.
        convertiti = {}
        for p in file_py:
            testo = rendi_relativi(p.read_text(encoding="utf-8"), moduli)
            rimasti = import_assoluti_rimasti(testo, moduli)
            if rimasti:
                raise SystemExit(f"{p.name}: import non convertiti: {rimasti}")
            compile(testo, str(p), 'exec')
            convertiti[p.name] = testo
        modelli = sorted((sorgente / "modelli_rev02" / "m01").glob("M0?-PO01_dpr_rev02.docx"))
        if len(modelli) != 3:
            raise SystemExit("Mancano i modelli M01, M02, M03 rev. 02 in modelli_rev02/m01.")
        if not (sorgente / 'static').is_dir():
            raise SystemExit('Manca la cartella static di VerbalizzAI.')

        init = DESTINAZIONE / "__init__.py"
        testo = init.read_text(encoding="utf-8") if init.exists() else 'VERSIONE = ""\n'
        testo = re.sub(r'^VERSIONE = .*$', f'VERSIONE = "{versione}"', testo, flags=re.M)
        testo = re.sub(r"Versione di origine: VerbalizzAI AD [^\n]*", f"Versione di origine: VerbalizzAI AD {versione}.", testo)
        compile(testo, str(init), 'exec')
        DESTINAZIONE.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='aggiorna_vz_', dir=DESTINAZIONE.parent) as lavoro:
            nuova = Path(lavoro) / 'nuova'
            nuova.mkdir()
            for nome, contenuto in convertiti.items():
                (nuova / nome).write_text(contenuto, encoding='utf-8', newline='\n')
            shutil.copytree(sorgente / 'static', nuova / 'static')
            (nuova / 'modelli').mkdir()
            for m in modelli:
                shutil.copy2(m, nuova / 'modelli' / m.name)
            if (sorgente / 'VERSIONI.md').exists():
                shutil.copy2(sorgente / 'VERSIONI.md', nuova / 'VERSIONI_VerbalizzAI.md')
            (nuova / '__init__.py').write_text(testo, encoding='utf-8', newline='\n')
            scrivi_impronte(nuova, versione, percorso.name)
            precedente = Path(lavoro) / 'precedente'
            if DESTINAZIONE.exists():
                os.replace(DESTINAZIONE, precedente)
            try:
                os.replace(nuova, DESTINAZIONE)
            except BaseException:
                if precedente.exists():
                    os.replace(precedente, DESTINAZIONE)
                raise
        return versione
    finally:
        if tmp is not None:
            tmp.cleanup()


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit(__doc__)
    v = aggiorna(Path(sys.argv[1]).expanduser().resolve())
    print(f"VerbalizzAI {v} copiato in {DESTINAZIONE}. Ora esegui i test (ESEGUI_TEST_WINDOWS.bat).")
