"""R136 (0.16): grafica dei modelli dei verbali DM (M14-PO01_dm GVR, M11-PO01_dm SC/SP) allineata ai modelli M01–M03 di
VerbalizzAI, come nuova revisione (rev. 03) del sistema di gestione.

Federico, 12/10/2026, 17:02: «i modelli ok, però devi aggiornare la grafica (logo, font, colori etc.) ai modelli m01,
m02, etc. di verbalizzAI». Si cambia SOLO la forma, mai il contenuto: testi, segnaposto {{…}}, tabelle e sezioni restano
quelli della rev. 02 approvata. Dalla grafica di M01-PO01_dpr rev. 02:
- carattere Calibri (titolo in Cambria), testo grigio ardesia 2C3F3F;
- titoli delle sezioni («1) Configurazione…», «2) Regolarità…», «3) Stato di conservazione», «4) Osservazioni») in verde
  AD 327F7C, grassetto, con la riga sottile sotto come le sezioni di M01;
- tabelle con bordi sottili B9CFCC e la prima riga (intestazioni) su fondo EEF5F4;
- intestazione e piè di pagina nello stesso carattere; nel piè di pagina il codice del modello passa a «rev. 03».

Uso: python strumenti/ristila_modelli_dm.py   → gestionale/dati/modelli/verbale-gvr_rev03.docx e verbale-sc-sp_rev03.docx
"""

from __future__ import annotations

import io
import re
import sys
import zipfile
from pathlib import Path

CARTELLA = Path(__file__).resolve().parents[1] / "gestionale" / "dati" / "modelli"
TESTO, ACCENTO, BORDO, FONDO = "2C3F3F", "327F7C", "B9CFCC", "EEF5F4"
DATA_REV = "12.10.2026"
SEZIONE = re.compile(r"^\s*\d\)\s")


def _testo(p: str) -> str:
    return "".join(re.findall(r"<w:t[^>]*>([^<]*)</w:t>", p))


def _font(xml: str, titolo: bool = False) -> str:
    nome = "Cambria" if titolo else "Calibri"
    xml = re.sub(r'<w:rFonts w:ascii="Cambria( Math)?" w:hAnsi="Cambria( Math)?"', lambda m: f'<w:rFonts w:ascii="{nome}{m.group(1) or ""}" w:hAnsi="{nome}{m.group(2) or ""}"', xml)
    return xml


def _colora_run(rpr: str, colore: str, grassetto: bool = False) -> str:
    rpr = re.sub(r"<w:color [^>]*/>", "", rpr)
    if grassetto and "<w:b/>" not in rpr:
        rpr = rpr.replace("<w:rPr>", "<w:rPr><w:b/><w:bCs/>", 1)
    # l'ordine dello schema vuole color dopo b/i/caps…: lo mettiamo prima di sz se c'è, altrimenti in fondo
    if "<w:sz " in rpr:
        return rpr.replace("<w:sz ", f'<w:color w:val="{colore}"/><w:sz ', 1)
    return rpr.replace("</w:rPr>", f'<w:color w:val="{colore}"/></w:rPr>', 1)


def _paragrafo(p: str) -> str:
    t = _testo(p).strip()
    titolo = t.startswith("VERBALE DI VERIFICA")
    p = _font(p, titolo)
    sezione = bool(SEZIONE.match(t))
    colore = ACCENTO if sezione else TESTO

    def run(m: re.Match) -> str:
        r = m.group(0)
        if "<w:rPr>" not in r:
            r = r.replace("<w:r>", "<w:r><w:rPr></w:rPr>", 1) if r.startswith("<w:r>") else re.sub(r"(<w:r [^>]*>)", r"\1<w:rPr></w:rPr>", r, count=1)
        return re.sub(r"<w:rPr>.*?</w:rPr>", lambda x: _colora_run(x.group(0), colore, sezione), r, count=1, flags=re.S)

    p = re.sub(r"<w:r[ >](?:(?!<w:r[ >]).)*?</w:r>", run, p, flags=re.S)
    if sezione and "<w:pBdr>" not in p:
        bordo = f'<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="{ACCENTO}"/></w:pBdr>'
        if "<w:pPr>" in p:
            p = p.replace("<w:pPr>", "<w:pPr>" + bordo, 1)
        else:
            p = re.sub(r"(<w:p[ >][^>]*>|<w:p>)", lambda m: m.group(1) + f"<w:pPr>{bordo}</w:pPr>", p, count=1)
    return p


def _tabelle(xml: str) -> str:
    xml = re.sub(r'(<w:(?:top|left|bottom|right|insideH|insideV) w:val="single" w:sz=")\d+(" w:space="0" w:color=")auto(")',
                 lambda m: f"{m.group(1)}4{m.group(2)}{BORDO}{m.group(3)}", xml)

    def prima_riga(m: re.Match) -> str:
        tbl = m.group(0)
        r = re.search(r"<w:tr[ >].*?</w:tr>", tbl, re.S)
        if not r:
            return tbl
        riga = r.group(0)
        if "{{" in riga:  # una riga con segnaposto non è un'intestazione
            return tbl
        nuova = re.sub(r"<w:tcPr>", f'<w:tcPr><w:shd w:val="clear" w:color="auto" w:fill="{FONDO}"/>', riga)
        nuova = re.sub(r'<w:shd w:val="clear" w:color="auto" w:fill="EEF5F4"/>(.*?)<w:shd [^>]*/>', r"\1" + f'<w:shd w:val="clear" w:color="auto" w:fill="{FONDO}"/>', nuova, flags=re.S)
        return tbl.replace(riga, nuova, 1)

    return re.sub(r"<w:tbl>(?:(?!<w:tbl>).)*?</w:tbl>", prima_riga, xml, flags=re.S)


def ristila(raw: bytes, codice: str) -> bytes:
    zin = zipfile.ZipFile(io.BytesIO(raw))
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            dati = zin.read(item.filename)
            if item.filename == "word/document.xml":
                x = dati.decode("utf-8")
                x = re.sub(r"<w:p[ >](?:(?!<w:p[ >]).)*?</w:p>", lambda m: _paragrafo(m.group(0)), x, flags=re.S)
                dati = _tabelle(x).encode("utf-8")
            elif item.filename in ("word/header1.xml", "word/footer1.xml"):
                x = _font(dati.decode("utf-8"))
                x = re.sub(rf"{re.escape(codice)} rev\. 02 del 16\.07\.2025", f"{codice} rev. 03 del {DATA_REV}", x)
                dati = x.encode("utf-8")
            elif item.filename == "word/styles.xml":
                dati = _font(dati.decode("utf-8")).encode("utf-8")
            zout.writestr(item, dati)
    return out.getvalue()


def main() -> int:
    for sorgente, codice, destinazione in (("verbale-gvr.docx", "M14-PO01_dm", "verbale-gvr_rev03.docx"),
                                          ("verbale-sc-sp.docx", "M11-PO01_dm", "verbale-sc-sp_rev03.docx")):
        nuovo = ristila((CARTELLA / sorgente).read_bytes(), codice)
        (CARTELLA / destinazione).write_bytes(nuovo)
        print("scritto", CARTELLA / destinazione)
    return 0


if __name__ == "__main__":
    sys.exit(main())
