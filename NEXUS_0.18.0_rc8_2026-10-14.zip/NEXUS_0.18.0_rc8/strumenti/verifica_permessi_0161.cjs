"use strict";
// Funzione JavaScript reale, DOM ridotto e utente inventato. Non è un collaudo visuale completo.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const src=fs.readFileSync(path.join(root,'gestionale/static/js/schede.js'),'utf8');
async function prova(user,attivita){
  const ctx={GAD:{api:async()=>user},document:{documentElement:{dataset:{ambito:attivita}}}};
  vm.createContext(ctx);vm.runInContext(src,ctx);await ctx.GAD.schede.me();return ctx.GAD.schede;
}
(async()=>{
  const codici=['verifiche.assegna','verifiche.riesame','verifiche.esegui','fatture.genera'];
  for(const rt of ['DPR','DM']){
    const altro=rt==='DPR'?'DM':'DPR';
    const user={permessi:codici,permessi_per_attivita:{[rt]:codici,[altro]:['verifiche.esegui','fatture.genera']}};
    const s=await prova(user,altro);
    assert.strictEqual(s.puo('verifiche.riesame'),false);
    assert.strictEqual(s.puo('verifiche.assegna'),false);
    assert.strictEqual(s.puo('verifiche.esegui'),true);
    assert.strictEqual(s.puo('fatture.genera'),true);
    assert.strictEqual(s.puo('verifiche.riesame',rt),true);
    assert.strictEqual(s.puo('verifiche.riesame','IEC'),true); // I&C mantiene la semantica server attuale
    await assert.rejects(s.affidaRighe([{verifica_id:1}],altro==='DM'),/Non puoi affidare/);
  }
  const admin=await prova({permessi:codici,permessi_per_attivita:{DPR:codici,DM:codici}},'DM');
  assert.strictEqual(admin.puo('verifiche.riesame'),true);
  const compat=await prova({permessi:['fatture.genera']},'DPR');
  assert.strictEqual(compat.puo('fatture.genera'),true);
  assert.strictEqual(compat.puo('verifiche.riesame'),false);
  console.log('Permessi client: ruoli incrociati, ruolo comune, attività esplicita e compatibilità verificati.');
})().catch(e=>{console.error(e);process.exitCode=1;});
