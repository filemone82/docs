"""Crea l'AMBIENTE DI PROVA: un archivio separato con utenti, clienti, impianti, preventivi e verifiche FINTI,
per provare il gestionale con i verbali (VerbalizzAI 0.3.32.1) senza toccare l'archivio vero.

Uso (dalla cartella del programma; lo fa da solo AVVIA_TEST_WINDOWS.bat la prima volta):
    .venv\\Scripts\\python.exe strumenti\\crea_ambiente_di_prova.py            (Windows)
    .venv/bin/python strumenti/crea_ambiente_di_prova.py                        (Linux)
    ... crea_ambiente_di_prova.py --cartella C:\\percorso\\cartella              (cartella diversa)

Cartella predefinita: GestionaleAD_dati_TEST accanto alla cartella del programma.
Tutti gli utenti hanno la password «password di prova». Le firme grafiche sono finte (una riga con la scritta PROVA).
Tutto passa dalle stesse funzioni che si usano dal browser, con i loro controlli.
"""

from __future__ import annotations

import argparse
import base64
import struct
import sys
import zlib
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    from fastapi.testclient import TestClient
except ImportError:  # httpx manca: si installa con requirements-sviluppo.txt
    raise SystemExit("Manca un componente: eseguire prima  .venv\\Scripts\\python.exe -m pip install -r requirements-sviluppo.txt") from None

from gestionale.app import crea_app  # noqa: E402
from gestionale.core.config import CARTELLA_PROGRAMMA, Config  # noqa: E402

CARTELLA = CARTELLA_PROGRAMMA.parent / "GestionaleAD_dati_TEST"
PASSWORD = "password di prova"
UTENTI = (  # nome utente, nome, ruolo
    # R132 (0.13.1): ruoli per attività
    ("responsabile", "Rossi Mario (RT DPR prova)", "responsabile_tecnico"),
    ("responsabile_dm", "Gialli Paolo (RT DM prova)", "responsabile_tecnico_dm"),
    ("tecnico1", "Bianchi Luca (verificatore DM e DPR prova)", "tecnico_dm_dpr"),
    ("tecnico2", "Verdi Anna (verificatore DM e DPR prova)", "tecnico_dm_dpr"),
    ("segreteria", "Neri Giulia (segreteria prova)", "segreteria"),
)


def partita_iva(n: int) -> str:
    """Partita IVA finta ma formalmente valida (cifra di controllo giusta)."""
    base = f"9{n:09d}"
    totale = 0
    for i, c in enumerate(base):
        d = int(c)
        if i % 2:
            d = d * 2 - 9 if d * 2 > 9 else d * 2
        totale += d
    return base + str((10 - totale % 10) % 10)


def firma_png(testo_righe: int) -> bytes:
    """Immagine 360 × 120 con una «firma» finta (due tratti): basta per provare firma ed emissione."""
    w, h = 360, 120
    righe = []
    for y in range(h):
        riga = bytearray(b"\xff" * w)
        for x in range(40, 320):
            if abs(y - (60 + ((x // 20) % 2) * 8 - 4 + testo_righe)) <= 1:
                riga[x] = 0
        righe.append(b"\x00" + bytes(riga))

    def blocco(tipo: bytes, dati: bytes) -> bytes:
        return struct.pack(">I", len(dati)) + tipo + dati + struct.pack(">I", zlib.crc32(tipo + dati) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n" + blocco(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 0, 0, 0, 0))
            + blocco(b"IDAT", zlib.compress(b"".join(righe))) + blocco(b"IEND", b""))


class Sessione:
    def __init__(self, c: TestClient) -> None:
        import re

        self.c = c
        self.h = {"X-CSRF-Token": re.search(r'name="csrf" content="([^"]+)"', c.get("/profilo").text).group(1)}

    def _ok(self, r):  # noqa: ANN001, ANN202
        if r.status_code != 200:
            raise SystemExit(f"Errore durante la creazione dei dati di prova ({r.request.method} {r.request.url.path}): {r.text}")
        return r.json()

    def get(self, url: str):  # noqa: ANN201
        return self._ok(self.c.get(url))

    def post(self, url: str, dati: dict | None = None):  # noqa: ANN201
        return self._ok(self.c.post(url, json=dati or {}, headers=self.h))

    def put(self, url: str, dati: dict):  # noqa: ANN201
        return self._ok(self.c.put(url, json=dati, headers=self.h))

    def vz(self, percorso: str, dati: dict):  # noqa: ANN201
        token = self.get("/verbali/api/me")["csrf"]
        return self._ok(self.c.post("/verbali/api/" + percorso, json=dati, headers={"X-AD-Token": token}))


def entra(app, username: str, password: str) -> Sessione:  # noqa: ANN001
    c = TestClient(app, base_url="http://localhost")
    r = c.post("/api/accesso", json={"username": username, "password": password})
    if r.status_code != 200:
        raise SystemExit(f"Accesso di prova non riuscito per {username}: {r.text}")
    return Sessione(c)


_PDF_VUOTO = (b"%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n"
              b"3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 595 842]>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n")


def dm(admin: Sessione, sessioni: dict, sede: dict, oggi: date) -> None:
    """Dati AD_dm per le prove manuali: un recipiente GVR (famiglia a1, senza visita interna) e un generatore di vapore
    (famiglia a2, con visita interna), un preventivo DM accettato e riesaminato, un incarico chiuso con PDF (da riesaminare)
    e uno solo assegnato. Se LibreOffice manca, il primo incarico resta «registrato»."""
    def bene(matricola: str, tipo: int, famiglia: int, spec: int, nome: str) -> dict:
        return admin.post("/api/beni", {"gruppo": "GVR", "sede_id": sede["id"], "matr_informale": matricola, "denominazione": nome,
                                        "tipo_attr_id": tipo, "tipo_attr_gvr_id": famiglia, "id_spec_id": spec,
                                        "anno_matricola": "2018", "cod_att_matricola": "7", "num_matricola": matricola.split("/")[1][1:], "prov_immatr": "NO",
                                        "dati_dm": {"esente_verifiche": "F", "tipo_prox_verifica": "V2"},
                                        # R142 (0.16): prossima verifica obbligatoria alla registrazione
                                        "date_iniziali": {c: {"data_ultima": (oggi - timedelta(days=700)).isoformat(),
                                                              "data_prossima": (oggi + timedelta(days=30)).isoformat()}
                                                          for c in ["funzionamento", "integrita"] + (["interna"] if famiglia in (2, 3) else [])}})
    recipiente = bene("2018/700101/NO", 18, 1, 40, "Serbatoio aria compressa (prova)")
    generatore = bene("2018/700102/NO", 24, 2, 52, "Generatore di vapore (prova)")
    p = admin.post("/api/preventivi", {"ambito": "DM", "sede_id": sede["id"], "attrezzature": [
        {"asset_id": recipiente["id"], "tipo_verifica_dm": "V2", "tipo_verifica_gvr": "funz"},
        {"asset_id": generatore["id"], "tipo_verifica_dm": "V2", "tipo_verifica_gvr": "funz_interna"}]})
    doc = admin.post(f"/api/preventivi/{p['id']}/anteprima")["documento"]
    if not doc["approvato"]:
        admin.post(f"/api/preventivi/{p['id']}/documenti/{doc['pdf_documento_id']}/approva")
    p = admin.post(f"/api/preventivi/{p['id']}/inviato", {"versione": admin.get(f"/api/preventivi/{p['id']}")["versione"]})
    p = admin.post(f"/api/preventivi/{p['id']}/righe/stato", {"righe": [r["id"] for r in p["righe"]], "stato": "accettata",
                                                             "versione": p["versione"], "evidenza_accettazione": "Ordine via email (dati di prova)"})
    admin.post(f"/api/preventivi/{p['id']}/riesame", {"esito": "conforme", "requisiti_chiari": True, "competenza_strumenti": True,
                                                      "imparzialita": True, "tempi": True})
    incarichi = {v["asset_id"]: v for v in admin.get("/api/dm/incarichi") if v["preventivo_id"] == p["id"]}
    chi = {u: sessioni[u].get("/api/io")["id"] for u in ("tecnico1", "tecnico2")}

    def assegna(v: dict, tecnico: str) -> dict:
        v = admin.get(f"/api/dm/incarichi/{v['id']}")
        return admin.post(f"/api/dm/incarichi/{v['id']}/assegna", {"versione": v["versione"], "verificatore_id": chi[tecnico]})

    t1 = sessioni["tecnico1"]
    v = assegna(incarichi[recipiente["id"]], "tecnico1")
    prossima = oggi.replace(year=oggi.year + 2).isoformat()
    v = t1.put(f"/api/dm/incarichi/{v['id']}/bozza", {"versione": v["versione"], "asset_versione": v["asset_versione"],
                                                     "data_rilascio": oggi.isoformat(), "date": {"funz": prossima}})
    v = t1.post(f"/api/dm/incarichi/{v['id']}/registra", {"versione": v["versione"]})
    prof = v["profilo_tecnico"]
    admin.put(f"/api/dm/tecnici/{prof['utente_id']}/profilo", {"versione": prof["versione"], "nome": "Tecnico", "cognome": "Uno",
                                                               "qualifica": "Ing.", "codice_fiscale": "TCNNUO80A01L219X"})
    # 0.15: i verbali DM richiedono la firma DM del tecnico (distinta da quella DPR di VerbalizzAI)
    for chi_firma, sessione in (("tecnico1", t1), ("tecnico2", sessioni["tecnico2"])):
        uid = sessione.get("/api/io")["id"]
        sessione.c.post(f"/api/dm/tecnici/{uid}/firma", files={"file": ("firma_dm.png", firma_png(3 if chi_firma == "tecnico1" else 9), "image/png")},
                        headers=sessione.h)
    r = t1.c.post(f"/api/dm/incarichi/{v['id']}/documenti/genera", json={"versione": t1.get(f"/api/dm/incarichi/{v['id']}")["versione"]},
                  headers=t1.h)
    if r.status_code == 200:
        v = r.json()
        d = next(x for x in v["documenti"] if x["attuale"] and x["tipo"] == "verbale" and x["formato"] == "pdf")
        t1.post(f"/api/dm/incarichi/{v['id']}/effettuata", {"versione": v["versione"], "documento_id": d["id"], "impronta_pdf": d["impronta"]})
    else:  # di solito LibreOffice non trovato: l'incarico resta registrato, il resto dell'ambiente è pronto
        print(f"Nota: verbale DM di prova non generato ({r.text}). L'incarico DM resta «registrato».")
    assegna(incarichi[generatore["id"]], "tecnico2")


PRONTO = "AMBIENTE_DI_PROVA_COMPLETO.txt"


def crea(cartella: Path) -> None:
    if (cartella / "database.sqlite").exists():
        if not (cartella / PRONTO).exists():
            # 0.12.3: una creazione interrotta lasciava un archivio a metà che poi si apriva come se fosse buono.
            raise SystemExit(f"L'ambiente di prova in {cartella} è incompleto (creazione interrotta o versione precedente).\n"
                             "Chiudi il gestionale di prova ed esegui RICREA_AMBIENTE_DI_PROVA_WINDOWS.bat per ricrearlo da zero.")
        print(f"L'ambiente di prova esiste già in {cartella}. Per ricrearlo da zero usa RICREA_AMBIENTE_DI_PROVA_WINDOWS.bat.")
        return
    cfg = Config(cartella_dati=cartella, backup_automatico=False, apri_browser=False)
    from gestionale.core import pdf

    if not pdf.disponibile(cfg.libreoffice):  # senza LibreOffice: PDF dei preventivi finti, solo per questo archivio di prova
        print("ATTENZIONE: LibreOffice non trovato. I PDF dei preventivi di prova saranno pagine vuote; per lavorare serve LibreOffice.")
        pdf.da_word = lambda docx, conf="": _PDF_VUOTO
    app = crea_app(cfg)
    with TestClient(app, base_url="http://localhost") as c:
        r = c.post("/api/primo-avvio", json={"username": "admin", "nome": "Amministratore (prova)", "password": PASSWORD})
        if r.status_code != 200:
            raise SystemExit(r.text)
        admin = Sessione(c)
        ruoli = {x["codice"]: x["id"] for x in admin.get("/api/ruoli")}
        sessioni = {"admin": admin}
        for username, nome, ruolo in UTENTI:
            provvisoria = admin.post("/api/utenti", {"username": username, "nome": nome, "ruolo_id": ruoli[ruolo]})["password_provvisoria"]
            s = entra(app, username, provvisoria)
            s.post("/api/io/password", {"attuale": provvisoria, "nuova": PASSWORD})
            sessioni[username] = s
        # firme grafiche finte di chi firma i verbali
        for i, username in enumerate(("admin", "responsabile", "tecnico1", "tecnico2")):
            sessioni[username].vz("signature", {"content": base64.b64encode(firma_png(i * 6)).decode(), "filename": "firma_prova.png"})

        # ---- anagrafica finta
        oggi = date.today()

        def cliente(n: int, ragione: str, comune: str, cap: str, **extra) -> dict:  # noqa: ANN003
            piva = partita_iva(n)
            return admin.post("/api/clienti", {"ragione_sociale": ragione, "tipo": "privato", "partita_iva": piva, "codice_fiscale": piva,
                                               "indirizzo": f"Via della Prova {n}", "comune_istat": comune, "cap": cap,
                                               "email_verbali": f"verbali{n}@esempio.invalid", "email_fatture": f"fatture{n}@esempio.invalid",
                                               "codice_sdi": "0000000", **extra})

        def sede(cliente_id: int, nome: str, comune: str, cap: str) -> dict:
            return admin.post("/api/sedi", {"cliente_id": cliente_id, "denominazione": nome, "indirizzo": "Via del Cantiere 1",
                                            "comune_istat": comune, "cap": cap})

        def impianto(sede_id: int, tipologia: str, anni_fa: float | None, **extra) -> dict:  # noqa: ANN003
            dati = {"sede_id": sede_id, "tipologia": tipologia, "periodicita_anni": 2, **extra}
            if anni_fa is not None:
                dati["ultima_verifica_data"] = (oggi - timedelta(days=int(anni_fa * 365))).isoformat()
                dati["ultima_verifica_numero"] = "VP/900/24"
            return admin.post("/api/impianti", dati)

        alfa = cliente(1, "ALFA MECCANICA S.r.l. (PROVA)", "001314", "10088")
        beta = cliente(2, "BETA LOGISTICA S.p.A. (PROVA)", "001272", "10121")
        gamma = cliente(3, "COMUNE DI GAMMA (PROVA)", "096004", "13900", tipo="pa", codice_sdi="UFPROV")
        delta = cliente(4, "DELTA CHIMICA S.r.l. (PROVA)", "003106", "28100")
        s_alfa = sede(alfa["id"], "Stabilimento di Volpiano", "001314", "10088")
        s_beta1 = sede(beta["id"], "Magazzino Torino Nord", "001272", "10156")
        s_beta2 = sede(beta["id"], "Deposito Chivasso", "001082", "10034")
        s_gamma1 = sede(gamma["id"], "Scuola primaria G. Rodari", "096004", "13900")
        s_gamma2 = sede(gamma["id"], "Palestra comunale", "096004", "13900")
        s_delta = sede(delta["id"], "Reparto produzione", "003106", "28100")
        i1 = impianto(s_alfa["id"], "terra_bt", 1.9, potenza_kw="45", pod=["IT001E00000001"])
        i2 = impianto(s_alfa["id"], "scariche", 1.9, asta=True, numero_aste="2")
        i3 = impianto(s_beta1["id"], "terra_at", 4.9, potenza_kw="800", periodicita_anni=5, cabine_mt_bt="2", pod=["IT001E00000002"])
        i4 = impianto(s_beta2["id"], "terra_bt", 1.95, potenza_kw="12", pod=["IT001E00000003"])
        i5 = impianto(s_gamma1["id"], "terra_bt", 1.7, potenza_kw="30", pod=["IT001E00000004"])
        impianto(s_gamma2["id"], "terra_bt", 2.2, potenza_kw="20", pod=["IT001E00000005"])  # scaduto: da preventivare
        i7 = impianto(s_delta["id"], "esplosione", 1.8, gas=True, zone=["1", "2"])
        i8 = impianto(s_delta["id"], "terra_bt", None, potenza_kw="150", pod=["IT001E00000006"])  # mai verificato

        # ---- preventivo accettato e riesaminato: nascono le verifiche
        def accettato(impianti: list[int]) -> dict:
            p = admin.post("/api/preventivi", {"impianti": impianti})
            righe = []
            for r in p["righe"]:
                riga = {"id": r["id"], "tipo_verifica": r["tipo_verifica"], "sconto": "0"}
                if r.get("voce_id") and not r["tariffa_standard"]:
                    riga["quantita"] = "4"  # voci a ore (pericolo di esplosione): 4 ore previste
                righe.append(riga)
            p = admin.put(f"/api/preventivi/{p['id']}", {**p, "righe": righe})
            # 0.7.0 (D80): come dall'interfaccia — anteprima, approvazione del documento, «Segna come inviato»
            doc = admin.post(f"/api/preventivi/{p['id']}/anteprima")["documento"]
            admin.post(f"/api/preventivi/{p['id']}/documenti/{doc['pdf_documento_id']}/approva")
            p = admin.post(f"/api/preventivi/{p['id']}/inviato", {"versione": admin.get(f"/api/preventivi/{p['id']}")["versione"]})
            p = admin.post(f"/api/preventivi/{p['id']}/righe/stato", {"righe": [r["id"] for r in p["righe"]], "stato": "accettata", "versione": p["versione"],
                                                                         "evidenza_accettazione": "Email di conferma del cliente (dati di prova)"})
            admin.post(f"/api/preventivi/{p['id']}/riesame", {"esito": "conforme", "requisiti_chiari": True, "competenza_strumenti": True,
                                                              "imparzialita": True, "tempi": True})
            return admin.get(f"/api/preventivi/{p['id']}")

        p1 = accettato([i1["id"], i2["id"]])
        p2 = accettato([i3["id"], i4["id"]])
        p3 = accettato([i5["id"]])
        p4 = accettato([i7["id"]])
        # Un preventivo «creato», da completare e inviare. Su un impianto non ancora preventivato: dalla 0.8.1 (R98)
        # non si fa un secondo preventivo sulla stessa scadenza già preventivata.
        admin.post("/api/preventivi", {"impianti": [i8["id"]]})

        verificatori = {x["nome"]: x["id"] for x in admin.get("/api/verifiche/valori")["verificatori"]}

        def per_impianto(p: dict) -> dict:
            return {v["impianto_id"]: v for v in p["verifiche"]}

        def assegna(v: dict, chi: str) -> dict:
            v = admin.get(f"/api/verifiche/{v['id']}")
            nome = {u: n for u, n, _ in UTENTI}[chi]
            return admin.post(f"/api/verifiche/{v['id']}/assegna", {"verificatore_id": verificatori[nome], "versione": v["versione"]})

        def registra(v: dict, chi: str) -> dict:
            return sessioni[chi].post(f"/api/verifiche/{v['id']}/registra", {"data_esecuzione": oggi.isoformat(), "versione": v["versione"]})

        # tecnico1: due verifiche registrate (numero del verbale assegnato) → «Compila il verbale»
        registra(assegna(per_impianto(p1)[i1["id"]], "tecnico1"), "tecnico1")
        registra(assegna(per_impianto(p1)[i2["id"]], "tecnico1"), "tecnico1")
        # tecnico2: una registrata, una solo assegnata (da programmare e registrare)
        registra(assegna(per_impianto(p2)[i3["id"]], "tecnico2"), "tecnico2")
        assegna(per_impianto(p2)[i4["id"]], "tecnico2")
        # p3 e p4: verifiche «da assegnare» per provare l'assegnazione del RT
        _ = (p3, p4)

        # ---- AD_dm (0.12.2): un recipiente e un generatore di vapore nella sede di DELTA
        dm(admin, sessioni, s_delta, oggi)
    (cartella / PRONTO).write_text(f"Ambiente di prova creato il {date.today().isoformat()} dalla versione del programma in uso.\n",
                                   encoding="utf-8")
    print(f"Ambiente di prova creato in {cartella}.")
    print(f"Utenti (password per tutti: «{PASSWORD}»): admin, " + ", ".join(u for u, _, _ in UTENTI))


if __name__ == "__main__":
    import os
    if os.environ.get("GESTIONALE_DATABASE_URL"):
        raise SystemExit("Questo strumento storico prepara SQLite. Per PostgreSQL usare il collaudo dedicato; nessun archivio è stato creato.")
    a = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    a.add_argument("--cartella", type=Path, default=CARTELLA)
    crea(a.parse_args().cartella)
