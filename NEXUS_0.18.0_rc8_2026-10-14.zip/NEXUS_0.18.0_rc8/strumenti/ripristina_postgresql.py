"""Ripristino di collaudo a server applicativo fermo. Non è il trasferimento Garda."""
from pathlib import Path
import argparse
import json
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from gestionale.core.config import carica_config
from gestionale.core.db import Archivio
from gestionale.moduli.backup.postgresql import ripristina_a_fermo
from gestionale.moduli.utenti.servizio import Attore
from gestionale.moduli.verbali.archivio import ArchivioVerbali


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('backup', help='Nome del backup già verificato nella cartella backup')
    p.add_argument('--applicazione-ferma', action='store_true', help='Conferma che il servizio Nexus è fermo')
    args = p.parse_args()
    if not args.applicazione_ferma:
        p.error('Fermare il servizio applicativo prima del ripristino.')
    cfg = carica_config()
    if not cfg.postgresql:
        p.error('GESTIONALE_DATABASE_URL deve indicare il database PostgreSQL dedicato.')
    arc = Archivio(cfg)
    try:
        arc.verbali = ArchivioVerbali(cfg.cartella_dati / 'verbali', arc)
        print(json.dumps(ripristina_a_fermo(arc, args.backup, Attore(id=None, nome='Ripristino amministrativo di collaudo'))))
    finally:
        arc.chiudi()


if __name__ == '__main__':
    main()
