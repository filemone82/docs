"""Prova browser della 0.17, archivio sintetico, nessun dato operativo."""
import json, socket, sys, tempfile, threading, time, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
import uvicorn
from fastapi.testclient import TestClient
from playwright.sync_api import sync_playwright
from gestionale.app import crea_app
from gestionale.core.config import Config
from conftest import Sessione, PASSWORD_ADMIN, ruolo_id, segna_inviato, nuovo_utente
from test_anagrafica import crea_cliente, crea_sede, crea_impianto
from test_beni import ok, nuovo
from gestionale.core import pdf
from test_dm_documenti import pdf_di_prova

checks=[];errors=[];failures=[]
with tempfile.TemporaryDirectory(prefix='nexus017_ui_') as temp:
 app=crea_app(Config(cartella_dati=Path(temp)/'dati',iterazioni_password=1000,backup_automatico=False,apri_browser=False))
 tc=TestClient(app,base_url='http://testserver');ok(tc.post('/api/primo-avvio',json={'username':'collaudo','nome':'Amministratore prova','password':PASSWORD_ADMIN}));admin=Sessione(tc)
 c=crea_cliente(admin,ragione_sociale='Cliente sintetico Zeta',ambiti=['DPR','DM']);sd=crea_sede(admin,c['id'],denominazione='Sede sintetica');ip=crea_impianto(admin,sd['id'],ultima_verifica_data='2024-10-01')
 p=ok(admin.post('/api/preventivi',{'impianti':[ip['id']]}));p=segna_inviato(admin,p);p=ok(admin.post(f"/api/preventivi/{p['id']}/righe/stato",{'righe':[r['id'] for r in p['righe']],'stato':'accettata','versione':p['versione'],'evidenza_accettazione':'Conferma sintetica'}))
 q=ok(admin.post('/api/preventivi',{'cliente_id':c['id']}));q=ok(admin.post(f"/api/preventivi/{q['id']}/voci",{'versione':q['versione'],'descrizione':'Riga estranea','importo':'42'}))
 u=ok(admin.post('/api/utenti',{'username':'utente017','nome':'Utente collaudo017','ruolo_id':ruolo_id(admin,'tecnico_dm')}))
 a_dm=nuovo(admin,sd,'GVR','GVR-SINTETICO-017')
 from test_dm_tecnico import incarico
 dm_v,_,_=incarico(admin,sd,a=a_dm)
 rt_dm=nuovo_utente(admin,app,'rt_dm_browser017','responsabile_tecnico_dm')
 ip2=crea_impianto(admin,sd['id'],tipologia='scariche',asta=True,numero_aste='1',potenza_kw='',periodicita_anni=2)
 p2=ok(admin.post('/api/preventivi',{'impianti':[ip2['id']]}));p2=segna_inviato(admin,p2)
 p2=ok(admin.post(f"/api/preventivi/{p2['id']}/righe/stato",{'righe':[r['id'] for r in p2['righe']],'stato':'accettata','versione':p2['versione'],'evidenza_accettazione':'Conferma sintetica'}))
 ok(admin.post(f"/api/preventivi/{p2['id']}/riesame",{'esito':'conforme','requisiti_chiari':True,'competenza_strumenti':True,'imparzialita':True,'tempi':True}))
 p2=ok(admin.get(f"/api/preventivi/{p2['id']}"));vid=p2['verifiche'][0]['id'];v=ok(admin.get(f"/api/verifiche/{vid}"))
 v=ok(admin.post(f"/api/verifiche/{vid}/assegna",{'versione':v['versione'],'verificatore_id':ok(admin.get('/api/io'))['id']}))
 v=ok(admin.post(f"/api/verifiche/{vid}/registra",{'versione':v['versione'],'data_esecuzione':'2026-10-08'}))
 from test_verifiche import verbale_m02
 ok(admin.c.post(f"/api/verifiche/{vid}/verbale",files={'word':('verbale-sintetico.docx',verbale_m02(v['codice_verbale'],'08/10/2026'))},data={'versione':v['versione']},headers=admin.h))
 sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 server=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=port,log_level='error'));thread=threading.Thread(target=lambda:server.run(sockets=[sock]),daemon=True);thread.start()
 while not server.started:time.sleep(.05)
 base=f'http://127.0.0.1:{port}'
 with sync_playwright() as pw:
  b=pw.chromium.launch(headless=True,args=['--no-sandbox']);ctx=b.new_context(viewport={'width':1440,'height':1000},timezone_id='Europe/Rome')
  for name,value in tc.cookies.items():ctx.add_cookies([{'name':name,'value':value,'url':base}])
  page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)));page.on('response',lambda r:failures.append((r.status,r.url)) if r.status>=500 else None)
  def grid():page.wait_for_selector('.tabulator-row');page.wait_for_timeout(250)
  # Filtri testo, cancellazione, nascondi e ripristino iniziale.
  page.goto(base+'/clienti');grid()
  page.get_by_role('button',name='Filtra: Ragione sociale',exact=True).click()
  dialog=page.locator('#modale');dialog.locator('select').select_option('inizia');dialog.locator('input:not([type=checkbox])').fill('Cliente sintetico');dialog.get_by_role('button',name='Applica',exact=True).click();grid()
  assert page.locator('.tabulator-row').count()==1
  page.get_by_role('button',name='Cancella filtro: Ragione sociale',exact=True).click();grid()
  page.get_by_role('button',name='Nascondi colonna: Ragione sociale',exact=True).click();assert not page.locator('.tabulator-col[tabulator-field="ragione_sociale"]').is_visible()
  page.get_by_role('button',name='Configurazioni ▾',exact=True).click();page.get_by_role('button',name='Vista iniziale della versione corrente',exact=True).click();grid()
  assert page.locator('.tabulator-col[tabulator-field="ragione_sociale"]').is_visible();checks.append('Filtri testo strutturati, pulisci, nascondi, ripristina vista')
  # Scadenze: prima colonna, data preset e raggruppamento.
  page.goto(base+'/scadenze');grid()
  fields=page.locator('.tabulator-header .tabulator-col[tabulator-field]').evaluate_all('(xs)=>xs.filter(x=>getComputedStyle(x).display!=="none").map(x=>x.getAttribute("tabulator-field"))')
  assert [x for x in fields if not x.startswith('_')][0]=='cliente_ragione_sociale'
  assert page.locator('.griglia-barra select').first.input_value()=='cliente_ragione_sociale'
  page.get_by_role('button',name='Filtra: Prossima verifica',exact=True).click();dialog.locator('select').select_option('Questo anno');assert dialog.locator('input[type=date]').nth(0).input_value().endswith('-01-01');dialog.get_by_role('button',name='Applica',exact=True).click();grid();checks.append('Scadenze: cliente in prima colonna, gruppo iniziale, periodo date')
  # DM: query raggruppate con minimi e colonne iniziali, su dati tecnici reali sintetici.
  page.goto(base+'/attrezzature-gvr');grid();assert page.locator('.griglia-barra select').first.input_value()=='sede_operativa'
  page.goto(base+'/scadenze-tecniche');grid()
  fields=page.locator('.tabulator-header .tabulator-col[tabulator-field]').evaluate_all('(xs)=>xs.filter(x=>getComputedStyle(x).display!=="none").map(x=>x.getAttribute("tabulator-field"))')
  assert [x for x in fields if not x.startswith('_')][0]=='sede_operativa'
  checks.append('Attrezzature e Scadenze DM: raggruppamento server e sede in prima colonna Scadenze')
  # RC master parziale, esito non automatico.
  page.goto(base+f"/preventivi?apri={p['id']}");page.get_by_role('button',name='Riesame',exact=True).click()
  master=page.get_by_label('Seleziona tutti i requisiti',exact=True);master.check();page.get_by_label('Tempi di esecuzione sostenibili',exact=True).uncheck()
  assert master.evaluate('(x)=>x.indeterminate') is True
  page.get_by_label('Esito',exact=True).select_option('non_conforme');page.get_by_label('Note',exact=True).fill('Requisito tempi non soddisfatto, caso sintetico')
  page.get_by_role('button',name='Registra il riesame',exact=True).click();page.wait_for_timeout(500);checks.append('RC cumulativo, deflag parziale, esito manuale e registrazione negativa')
  # Contesto preservato tra Tutte, Azzera e vista salvata.
  page.goto(base+f"/righe-preventivi?campo=preventivo_id&valore={p['id']}");grid()
  assert page.locator('.contesto-preventivo').count()==1
  page.get_by_role('button',name='Tutte',exact=True).click();grid();page.get_by_role('button',name='Azzera filtri',exact=True).click();grid()
  assert 'Riga estranea' not in page.locator('.tabulator-table').inner_text()
  page.get_by_role('button',name='Configurazioni ▾',exact=True).click();page.get_by_role('button',name='＋ Salva la vista attuale…',exact=True).click();dialog.locator('input:not([type=checkbox])').fill('Vista collaudo');dialog.get_by_role('button',name='Salva',exact=True).click();page.wait_for_timeout(250)
  page.get_by_role('button',name='Configurazioni ▾',exact=True).click();page.get_by_role('button',name='Vista collaudo',exact=True).click();grid();assert 'Riga estranea' not in page.locator('.tabulator-table').inner_text()
  checks.append('Contesto singolo preventivo preservato con Tutte, Azzera e configurazione salvata')
  # Salva tecnico poi intera scheda, firma poi salva, vero conflitto.
  page.goto(base+'/utenti');grid();page.locator('#griglia-utenti .tabulator-cell').filter(has_text='Utente collaudo017').first.click();page.get_by_label('Nome',exact=True).fill('Tecnico sintetico');page.get_by_label('Email',exact=True).fill('prova@example.org')
  page.get_by_role('button',name='Salva dati del tecnico',exact=True).click();page.wait_for_timeout(300)
  page.get_by_role('button',name='Salva e chiudi',exact=True).click();page.wait_for_timeout(400);assert not page.locator('#pannello').is_visible()
  assert ok(admin.get(f"/api/utenti/{u['id']}"))['email']=='prova@example.org'
  checks.append('Salva tecnico seguito da Salva e chiudi senza falso conflitto')
  page.locator('#griglia-utenti .tabulator-cell').filter(has_text='Utente collaudo017').first.click();page.get_by_label('Nome',exact=True).fill('Bozza preservata')
  # PNG valido, costruito qui, non firma reale.
  import zlib,struct
  def chunk(t,d):return struct.pack('!I',len(d))+t+d+struct.pack('!I',zlib.crc32(t+d)&0xffffffff)
  png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('!IIBBBBB',300,100,8,2,0,0,0))+chunk(b'IDAT',zlib.compress((b'\0'+b'\xff'*900)*100))+chunk(b'IEND',b'')
  page.get_by_label('Immagine della firma DM',exact=True).set_input_files({'name':'firma-sintetica.png','mimeType':'image/png','buffer':png});page.wait_for_timeout(400)
  assert page.get_by_label('Nome',exact=True).input_value()=='Bozza preservata'
  page.locator('#pannello-azioni').get_by_role('button',name='Salva',exact=True).click();page.wait_for_timeout(300)
  assert ok(admin.get(f"/api/dm/tecnici/{u['id']}/profilo"))['nome']=='Bozza preservata'
  checks.append('Firma DM seguita da Salva: versione aggiornata e bozza preservata')
  x=ok(admin.get(f"/api/utenti/{u['id']}"));ok(admin.put(f"/api/utenti/{u['id']}",{**x,'nome':'Modifica altra sessione'}))
  page.get_by_label('Nome e cognome',exact=True).fill('Bozza da conservare');page.get_by_role('button',name='Salva e chiudi',exact=True).click();page.wait_for_timeout(300)
  assert page.locator('#pannello').is_visible() and page.get_by_label('Nome e cognome',exact=True).input_value()=='Bozza da conservare'
  assert ok(admin.get(f"/api/utenti/{u['id']}"))['nome']=='Modifica altra sessione';checks.append('Vero conflitto 409 conserva la scheda e i dati non salvati')
  page.goto(base+f"/verifiche?apri={vid}");page.get_by_text('Non puoi riesaminare il tuo verbale: serve un altro responsabile tecnico abilitato.',exact=True).wait_for()
  assert page.get_by_role('button',name='Registra il riesame',exact=True).count()==0
  checks.append('Interfaccia DPR: riesame del proprio verbale indisponibile con spiegazione')
  page.locator('[data-chiudi-pannello]').click();grid()
  azioni=page.locator('.griglia-azioni');assert '0 selezionate' in azioni.inner_text()
  assert all(azioni.get_by_role('button').nth(i).is_disabled() for i in range(azioni.get_by_role('button').count()))
  testi=azioni.get_by_role('button').all_text_contents();assert 'Affida' in testi[0] and 'Fattura' in testi[-1]
  page.locator('.tabulator-row input[type=checkbox]').first.check();page.wait_for_timeout(150)
  assert '1 selezionata' in azioni.inner_text() and azioni.get_by_role('button').first.is_disabled()
  checks.append('Barre distinte, conteggio selezione, affidamento prima della fattura e azioni non ammissibili disabilitate')
  # RT DM senza ruolo DPR: il selettore dell'affidamento deve usare i valori DM.
  for name,value in rt_dm.c.cookies.items():ctx.add_cookies([{'name':name,'value':value,'url':base}])
  page.goto(base+'/verifiche-gvr');grid();page.locator('.tabulator-row input[type=checkbox]').first.check()
  page.get_by_role('button',name=re.compile('Affida le selezionate')).click();dialog.wait_for(state='visible')
  dialog.locator('select').select_option(str(u['id']));dialog.get_by_role('button',name='Affida',exact=True).click();page.wait_for_timeout(350)
  assert ok(admin.get(f"/api/dm/incarichi/{dm_v['id']}"))['verificatore_id']==u['id']
  checks.append('RT DM senza ruolo DPR: affidamento in blocco con lista verificatori DM corretta')
  page.screenshot(path=str(Path(temp)/'browser017-synthetic.png'),full_page=False)
  assert not errors,errors;assert not failures,failures
  b.close()
 server.should_exit=True;thread.join(timeout=5)
print(json.dumps({'browser':'Chromium 134','checks':checks,'javascript_errors':errors,'http_5xx':failures,'result':'PASS'},ensure_ascii=False,indent=2))
