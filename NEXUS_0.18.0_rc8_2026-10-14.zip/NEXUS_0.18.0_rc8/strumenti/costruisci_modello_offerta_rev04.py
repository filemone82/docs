"""Costruisce il modello dell'offerta M01-RG01_dpr rev. 04 dalla rev. 03 (decisione D60, osservazione O14).

Modifiche, tutte di impaginazione (il testo non cambia):
1. tabella degli impianti: colonne ribilanciate (ubicazione più larga), righe che non si spezzano tra due pagine,
   riga dei titoli ripetuta su ogni pagina;
2. riquadro «Si prega di inviare l'accettazione…»: da riquadro mobile agganciato alla pagina (finiva da solo a
   pagina 2) a paragrafo con bordo dentro la tabella delle firme, sotto «Volpiano, lì …» (resta sempre a pagina 1);
3. «CONDIZIONI DI EROGAZIONE…» sempre da pagina nuova;
4. piè di pagina: «rev. 04 del 05.10.2026».

Uso:  python strumenti/costruisci_modello_offerta_rev04.py  (legge e scrive in gestionale/dati/modelli)
"""

from __future__ import annotations

import copy
import io
import zipfile
from pathlib import Path

from lxml import etree

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W, "wps": "http://schemas.microsoft.com/office/word/2010/wordprocessingShape"}
CARTELLA = Path(__file__).resolve().parents[1] / "gestionale" / "dati" / "modelli"
ORIGINE = CARTELLA / "M01-RG01_dpr_Offerta_rev.03.docx"
DESTINAZIONE = CARTELLA / "M01-RG01_dpr_Offerta_rev.04.docx"
LARGHEZZE = [2400, 2600, 1750, 1500, 1100]  # twip: descrizione, ubicazione, tipologia, potenza, tariffa (totale 9350)
REV_VECCHIA, REV_NUOVA = "rev. 03 del 04.10.2026", "rev. 04 del 05.10.2026"


def w(tag: str) -> str:
    return f"{{{W}}}{tag}"


def _figlio(padre, tag: str, primo: bool = False):  # noqa: ANN001, ANN202
    x = padre.find(w(tag))
    if x is None:
        x = etree.Element(w(tag))
        if primo:
            padre.insert(0, x)
        else:
            padre.append(x)
    return x


def tabella_impianti(body) -> None:  # noqa: ANN001
    tbl = next(t for t in body.findall(w("tbl")) if "{{#r}}" in "".join(t.itertext()).replace(" ", ""))
    tbl.find(w("tblPr")).find(w("tblW")).set(w("w"), str(sum(LARGHEZZE)))
    griglia = tbl.find(w("tblGrid"))
    for col, larg in zip(griglia.findall(w("gridCol")), LARGHEZZE):
        col.set(w("w"), str(larg))
    for i, tr in enumerate(tbl.findall(w("tr"))):
        trpr = _figlio(tr, "trPr", primo=True)
        _figlio(trpr, "cantSplit")
        if i == 0:
            _figlio(trpr, "tblHeader")
        for tc, larg in zip(tr.findall(w("tc")), LARGHEZZE):
            tcw = tc.find(w("tcPr")).find(w("tcW"))
            tcw.set(w("w"), str(larg))
            tcw.set(w("type"), "dxa")


def riquadro_nel_testo(body) -> None:  # noqa: ANN001
    p = next(p for p in body.findall(w("p")) if p.find(".//" + w("drawing")) is not None
             and "Si prega di inviare" in "".join(p.itertext()))
    txbx = p.find(".//" + w("txbxContent"))
    testi = [p2 for p2 in txbx.findall(w("p"))] if txbx is not None else []
    nuovi = []
    for i, origine in enumerate(testi):
        if not "".join(origine.itertext()).strip():
            continue
        q = etree.Element(w("p"))
        ppr = etree.SubElement(q, w("pPr"))
        etree.SubElement(ppr, w("keepLines"))
        bordo = etree.SubElement(ppr, w("pBdr"))
        for lato in ("top", "left", "bottom", "right"):
            b = etree.SubElement(bordo, w(lato))
            b.set(w("val"), "single"); b.set(w("sz"), "4"); b.set(w("space"), "4"); b.set(w("color"), "2E807C")
        sp = etree.SubElement(ppr, w("spacing")); sp.set(w("before"), "120"); sp.set(w("after"), "0")
        ind = etree.SubElement(ppr, w("ind")); ind.set(w("left"), "0"); ind.set(w("right"), "300")
        for r in origine.findall(".//" + w("r")):
            r2 = copy.deepcopy(r)
            rpr = _figlio(r2, "rPr", primo=True)
            for vecchio in rpr.findall(w("sz")) + rpr.findall(w("szCs")):
                rpr.remove(vecchio)
            etree.SubElement(rpr, w("sz")).set(w("val"), "16")
            q.append(r2)
        nuovi.append(q)
    # dentro la prima cella della tabella delle firme che precede il riquadro («Volpiano, lì …»)
    firme = p.getprevious()
    while firme is not None and firme.tag != w("tbl"):
        firme = firme.getprevious()
    cella = firme.find(w("tr")).find(w("tc"))
    for q in nuovi:
        cella.append(q)
    body.remove(p)


def condizioni_da_pagina_nuova(body) -> None:  # noqa: ANN001
    p = next(p for p in body.findall(w("p")) if "".join(p.itertext()).strip().startswith("CONDIZIONI DI EROGAZIONE"))
    _figlio(_figlio(p, "pPr", primo=True), "pageBreakBefore")


def costruisci() -> bytes:
    zin = zipfile.ZipFile(ORIGINE)
    uscita = io.BytesIO()
    with zipfile.ZipFile(uscita, "w", zipfile.ZIP_DEFLATED) as zout:
        for info in zin.infolist():
            dati = zin.read(info.filename)
            if info.filename == "word/document.xml":
                radice = etree.fromstring(dati)
                body = radice.find(w("body"))
                tabella_impianti(body)
                riquadro_nel_testo(body)
                condizioni_da_pagina_nuova(body)
                dati = etree.tostring(radice, xml_declaration=True, encoding="UTF-8", standalone=True)
            elif info.filename.startswith("word/footer"):
                dati = dati.replace(REV_VECCHIA.encode(), REV_NUOVA.encode())
            zout.writestr(info, dati)
    return uscita.getvalue()


if __name__ == "__main__":
    DESTINAZIONE.write_bytes(costruisci())
    print("Scritto", DESTINAZIONE)
