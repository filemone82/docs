"""Crea un archivio NUOVO del Gestionale AD popolato dal database del gestionale di Garda (AD_dpr, «ingecert»).

Uso (dalla cartella del programma; lo fa IMPORTA_DA_GARDA_WINDOWS.bat):
    .venv\\Scripts\\python.exe strumenti\\importa_da_garda.py C:\\percorso\\ingecert_2026-10-07.sql
    ... importa_da_garda.py ingecert.sql --adsrl C:\\percorso\\adsrl_2026-10-07.sql   (anche AD_dm, 0.12.4)
    ... importa_da_garda.py --aggiungi-adsrl adsrl.sql      (AD_dm in un archivio GARDA già creato da ingecert)
    ... --cartella C:\\percorso\\cartella_dati      (cartella diversa da quella predefinita)

- Il dump è l'esportazione SQL completa del database (struttura e dati), es. fatta con HeidiSQL; va bene anche .zip o .gz.
- Cartella predefinita: GestionaleAD_dati_GARDA accanto alla cartella del programma. Deve essere nuova (o senza archivio).
- Si crea l'amministratore «admin» con una password provvisoria mostrata una volta sola (va cambiata al primo accesso).
- Gli utenti di Garda entrano DISATTIVATI (le loro password non si possono riusare): l'amministratore li riattiva da
  Sistema › Utenti e dà a ciascuno una password provvisoria.
- Alla fine scrive il rapporto «importazione_garda.txt» (e .json) nella cartella dei dati: numeri, segnalazioni da
  controllare, quadratura dei totali dei preventivi.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from gestionale.core.config import CARTELLA_PROGRAMMA, Config  # noqa: E402
from gestionale.core.sicurezza import password_temporanea  # noqa: E402

CARTELLA = CARTELLA_PROGRAMMA.parent / "GestionaleAD_dati_GARDA"


def rapporto_testo(esito: dict, file: str, secondi: float) -> str:
    righe = [f"Importazione dal database di Garda — file {file} — {time.strftime('%d/%m/%Y %H:%M')} ({secondi:.0f} s)", "", "IMPORTATI"]
    righe += [f"  {k}: {n}" for k, n in esito["importati"].items()]
    righe += ["", f"SEGNALAZIONI DA CONTROLLARE ({len(esito['problemi'])}; nelle schede, campo «Da controllare»)"]
    righe += [f"  {x['quanti']:5d}  {x['problema']}" for x in esito["tipi_di_problema"]]
    q = esito["quadratura_totali"]
    righe += ["", f"QUADRATURA DEI TOTALI DEI PREVENTIVI: {len(q)} differenze" +
              (" (di solito preventivi rifiutati: Garda sommava anche le righe rifiutate)" if q else "")]
    righe += [f"  {x}" for x in q]
    righe += ["", "NUMERATORI DI GARDA (ultimo numero usato)"] + [f"  {k}: {n}" for k, n in esito["numeratori_garda"].items()]
    righe += ["", "DETTAGLIO DELLE SEGNALAZIONI"] + [f"  {p['entita']} · {p['nome']} · {p['problema']}" for p in esito["problemi"]]
    return "\n".join(righe) + "\n"


def importa(dump: Path, cartella: Path) -> str:
    from fastapi.testclient import TestClient

    from gestionale.app import crea_app
    from gestionale.moduli.garda import dump as lettore
    from gestionale.moduli.garda import importa as garda
    from gestionale.moduli.utenti.modelli import Utente

    if (cartella / "database.sqlite").exists():
        raise SystemExit(f"In {cartella} c'è già un archivio: l'importazione da Garda si fa su una cartella nuova. Cancellala o usa --cartella.")
    inizio = time.time()
    print(f"Lettura di {dump.name}…")
    dati = lettore.leggi(lettore.testo_del_dump(dump), garda.TABELLE)
    print("Tabelle lette: " + ", ".join(f"{t} {len(r)}" for t, r in sorted(dati.items()) if r))
    cfg = Config(cartella_dati=cartella, backup_automatico=False, apri_browser=False)
    app = crea_app(cfg)
    password = password_temporanea()
    with TestClient(app, base_url="http://localhost") as c:
        r = c.post("/api/primo-avvio", json={"username": "admin", "nome": "Amministratore", "password": password})
        if r.status_code != 200:
            raise SystemExit(r.text)
    arc = app.state.archivio
    with arc.scrittura() as s:
        admin = s.query(Utente).filter_by(username="admin").one()
        admin.cambio_password_richiesto = True
        print("Importazione in corso (tutto o niente)…")
        esito = garda.importa(s, admin, dati, dump.name)
    testo = rapporto_testo(esito, dump.name, time.time() - inizio)
    (cartella / "importazione_garda.txt").write_text(testo, encoding="utf-8")
    (cartella / "importazione_garda.json").write_text(json.dumps(esito, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
    print("\n".join(testo.splitlines()[:40]))
    print(f"\nArchivio creato in {cartella}. Rapporto completo: importazione_garda.txt")
    return password


def mostra_password(password: str) -> None:
    print("\n  Accesso:  utente  admin   password provvisoria  " + password)
    print("  (scrivila adesso: non viene salvata. Al primo accesso il programma chiede di cambiarla.)\n")


def rapporto_dm(esito: dict, file: str, secondi: float) -> str:
    righe = [f"Importazione AD_dm dal database di Garda — file {file} — {time.strftime('%d/%m/%Y %H:%M')} ({secondi:.0f} s)", "", "IMPORTATI"]
    righe += [f"  {k}: {n}" for k, n in esito["importati"].items()]
    righe += ["", "QUADRATURA (righe lette nel dump e righe entrate)"] + [f"  {x}" for x in esito["quadratura"]]
    righe += ["", f"SEGNALAZIONI DA CONTROLLARE ({len(esito['problemi'])})"]
    righe += [f"  {x['quanti']:5d}  {x['problema']}" for x in esito["tipi_di_problema"]]
    righe += ["", "DETTAGLIO DELLE SEGNALAZIONI"] + [f"  {p['entita']} · {p['nome']} · {p['problema']}" for p in esito["problemi"]]
    return "\n".join(righe) + "\n"


def aggiungi_adsrl(dump: Path, cartella: Path) -> None:
    """AD_dm (adsrl) dentro un archivio già importato da ingecert, nella stessa cartella."""
    from gestionale.app import crea_app
    from gestionale.moduli.garda import dump as lettore
    from gestionale.moduli.garda import importa_dm
    from gestionale.moduli.utenti.modelli import Utente

    if not (cartella / "database.sqlite").exists():
        raise SystemExit(f"In {cartella} non c'è un archivio: importa prima ingecert (IMPORTA_DA_GARDA_WINDOWS.bat).")
    inizio = time.time()
    print(f"Lettura di {dump.name}…")
    dati = lettore.leggi(lettore.testo_del_dump(dump), importa_dm.TABELLE_DM)
    print("Tabelle lette: " + ", ".join(f"{t} {len(r)}" for t, r in sorted(dati.items()) if r))
    app = crea_app(Config(cartella_dati=cartella, backup_automatico=False, apri_browser=False))
    arc = app.state.archivio
    with arc.scrittura() as s:
        attore = s.query(Utente).filter_by(username="admin").first() or s.query(Utente).first()
        print("Importazione AD_dm in corso (tutto o niente)…")
        try:
            esito = importa_dm.importa(s, attore, dati, dump.name)
        except ValueError as e:
            raise SystemExit(str(e)) from None
    testo = rapporto_dm(esito, dump.name, time.time() - inizio)
    (cartella / "importazione_garda_adsrl.txt").write_text(testo, encoding="utf-8")
    (cartella / "importazione_garda_adsrl.json").write_text(json.dumps(esito, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
    print("\n".join(testo.splitlines()[:45]))
    print(f"\nAD_dm aggiunto all'archivio {cartella}. Rapporto completo: importazione_garda_adsrl.txt")


if __name__ == "__main__":
    import os
    if os.environ.get("GESTIONALE_DATABASE_URL"):
        raise SystemExit("Questo strumento storico prepara SQLite. Per PostgreSQL usare il collaudo dedicato; nessun archivio è stato creato.")
    a = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    a.add_argument("dump", type=Path, nargs="?", help="dump di ingecert (AD_dpr)")
    a.add_argument("--adsrl", type=Path, help="dump di adsrl (AD_dm) da aggiungere dopo ingecert")
    a.add_argument("--aggiungi-adsrl", type=Path, help="solo AD_dm, in un archivio GARDA già creato")
    a.add_argument("--cartella", type=Path, default=CARTELLA)
    x = a.parse_args()
    cartella = x.cartella.expanduser().resolve()
    if x.aggiungi_adsrl:
        aggiungi_adsrl(x.aggiungi_adsrl.expanduser().resolve(), cartella)
    elif x.dump:
        password = importa(x.dump.expanduser().resolve(), cartella)
        try:
            if x.adsrl:
                aggiungi_adsrl(x.adsrl.expanduser().resolve(), cartella)
        finally:  # la password va mostrata comunque, alla fine, perché non si perda fra le righe del rapporto
            mostra_password(password)
    else:
        a.error("indica il dump di ingecert, oppure --aggiungi-adsrl con il dump di adsrl")
