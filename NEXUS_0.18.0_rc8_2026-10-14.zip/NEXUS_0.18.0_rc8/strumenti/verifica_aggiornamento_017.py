"""Prova ripetibile di aggiornamento su copia sintetica, due processi e due versioni."""
import json, os, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
import argparse
parser=argparse.ArgumentParser(description='Prova aggiornamento su archivio sintetico temporaneo')
parser.add_argument('--base-dir',type=Path,required=True,help='Cartella del codice NEXUS 0.16.0 ricevuto')
args=parser.parse_args()
base=args.base_dir.resolve();new=ROOT
assert (base/'gestionale/__init__.py').is_file(), 'Base 0.16 non trovata'
seed=r'''
import json,sqlite3,sys
from pathlib import Path
from fastapi.testclient import TestClient
from gestionale.app import crea_app
from gestionale.core.config import Config
from gestionale import VERSIONE
assert VERSIONE == '0.16.0', VERSIONE
from conftest import PASSWORD_ADMIN, Sessione
from test_anagrafica import crea_cliente,crea_sede,crea_impianto
cfg=Config(cartella_dati=Path(sys.argv[1]),iterazioni_password=1000,backup_automatico=False,apri_browser=False)
app=crea_app(cfg);c=TestClient(app,base_url='http://testserver')
assert c.post('/api/primo-avvio',json={'username':'prova_upgrade','nome':'Amministratore sintetico','password':PASSWORD_ADMIN}).status_code==200
s=Sessione(c);cli=crea_cliente(s,ragione_sociale='Cliente aggiornamento sintetico',ambiti=['DPR','DM']);sd=crea_sede(s,cli['id']);ip=crea_impianto(s,sd['id'])
assert s.post('/api/preventivi',{'impianti':[ip['id']]}).status_code==200
with sqlite3.connect(cfg.percorso_database) as db:
 tables=[r[0] for r in db.execute("select name from sqlite_master where type='table' and name not like 'sqlite_%'")]
 snapshot={t:list(db.execute('select * from "'+t+'" order by rowid')) for t in tables if t!='permessi'}
Path(sys.argv[2]).write_text(json.dumps(snapshot,sort_keys=True,default=str))
app.state.archivio.chiudi()
'''
check=r'''
import json,sqlite3,sys
from pathlib import Path
from gestionale.app import crea_app
from gestionale.core.config import Config
from gestionale import VERSIONE
assert VERSIONE == '0.17.0', VERSIONE
from gestionale.core.migrazioni import revisione_database
from gestionale.moduli.utenti.modelli import Ruolo,Utente
from gestionale.moduli.utenti import servizio
from gestionale.moduli.utenti.accesso import UtenteCorrente
from sqlalchemy import select
cfg=Config(cartella_dati=Path(sys.argv[1]),iterazioni_password=1000,backup_automatico=False,apri_browser=False);app=crea_app(cfg)
attesi=json.loads(Path(sys.argv[2]).read_text())
with sqlite3.connect(cfg.percorso_database) as db:
 actual={t:list(db.execute('select * from "'+t+'" order by rowid')) for t in attesi}
 assert json.dumps(actual,sort_keys=True,default=str)==json.dumps(attesi,sort_keys=True,default=str)
assert revisione_database(app.state.archivio.motore)=='0027'
with app.state.archivio.lettura() as s:
 rt=s.execute(select(Ruolo).where(Ruolo.codice=='responsabile_tecnico_dm')).scalar_one()
 perm=servizio.permessi_di_ruolo(s,rt)
 assert 'anagrafica.impianti' in perm  # concessione storica 0.16 preservata
 u=UtenteCorrente(99,'rt','RT DM','RT DM',False,perm,per_attivita={'DM':perm})
 assert not u.puo('anagrafica.impianti') and u.puo('beni.gestire')
print(json.dumps({'result':'PASS','schema':'0027','tables_preserved':len(attesi),'legacy_grants_preserved':True,'new_activity_guard':True}))
app.state.archivio.chiudi()
'''
with tempfile.TemporaryDirectory(prefix='nexus017_upgrade_') as tmp:
 data=Path(tmp)/'dati';snap=Path(tmp)/'snapshot.json'
 for directory,script in [(base,seed),(new,check)]:
  env=dict(os.environ,PYTHONPATH=str(directory)+os.pathsep+str(directory/'tests'))
  run=subprocess.run([sys.executable,'-c',script,str(data),str(snap)],env=env,cwd=directory,capture_output=True,text=True)
  assert run.returncode==0,run.stdout+run.stderr
  if run.stdout:print(run.stdout.strip())
