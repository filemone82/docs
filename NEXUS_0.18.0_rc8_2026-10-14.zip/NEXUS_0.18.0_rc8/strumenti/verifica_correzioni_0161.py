"""Regressioni AD-REV-008…013, eseguibili senza SQLAlchemy/FastAPI/pytest.

Esegue le funzioni del pacchetto con sessioni sostitutive e dati inventati.
Word, PNG, JavaScript e (con --pdf) LibreOffice sono reali. Non sostituisce
la suite HTTP/ORM: i confini non eseguiti sono dichiarati nel rapporto.

Uso: python strumenti/verifica_correzioni_0161.py [--pdf]
"""
from __future__ import annotations

import ast
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
from types import SimpleNamespace as NS
import unittest
from zipfile import ZipFile
import zlib

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))
from lxml import etree
from gestionale.core import pdf
from gestionale.core.errori import ErroreUtente
from gestionale.core.permessi import TECNICI, GESTIONE_PER_ATTIVITA
from gestionale.moduli.dm import word, impaginazione
from gestionale.moduli.finanza import stampa
from gestionale.moduli.finanza.riferimenti import chiave_documento, documenti_del_preventivo

PDF = '--pdf' in sys.argv
OUT = ROOT / 'report_collaudo' / 'correzioni_0.16.1'


def funzioni(path, names, env, classes=()):
    """Carica il corpo originale; sostituisce solo i confini delle dipendenze relative/ORM."""
    tree = ast.parse((ROOT / path).read_text(encoding='utf-8'))
    class ImportLocali(ast.NodeTransformer):
        def visit_ImportFrom(self, node):
            return None if node.level else node
    nodes = []
    for n in tree.body:
        if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name in (*names, *classes):
            if isinstance(n, ast.FunctionDef):
                n.decorator_list = []
            nodes.append(ImportLocali().visit(n))
    assert {n.name for n in nodes} == set((*names, *classes))
    nodes.insert(0, ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0))
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), str(ROOT / path), 'exec'), env)


def png(w=300, h=100):
    def chunk(tag, raw):
        return struct.pack('!I', len(raw)) + tag + raw + struct.pack('!I', zlib.crc32(tag + raw) & 0xffffffff)
    rows = []
    for y in range(h):
        rows.append(b'\x00' + b''.join(b'\x20\x20\x20\xff' if abs(x-y*2) < 2 else b'\xff\xff\xff\x00' for x in range(w)))
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('!IIBBBBB', w, h, 8, 6, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(b''.join(rows))) + chunk(b'IEND', b'')


def testo_docx(raw):
    with ZipFile(io.BytesIO(raw)) as z:
        root = etree.fromstring(z.read('word/document.xml'))
    return ''.join(root.xpath('//w:t/text()', namespaces={'w': word.word.W}))


class Contatore:
    def __init__(self, **d):
        self.__dict__.update(d)


def dm(gruppo='GVR', rev=1, modello=''):
    asset = NS(gruppo=gruppo, modello='Modello inventato', tipo_attr_gvr_id=None, tipo_attr_id=1, id_spec_id=1,
        attributi_json='{}', matr_informale='2020/1/123/TO', num_fabbrica='PROVA-123', costruttore='Costruttore inventato',
        sede=NS(indirizzo='Via Prova 1', comune='Torino', provincia='TO', cliente=NS(ragione_sociale='Cliente collaudo inventato')))
    row = NS(tipo_verifica_gvr='funz' if gruppo == 'GVR' else '', tipo_verifica_dm='V2', tariffa_standard=10000)
    catalogo = json.loads((ROOT / 'gestionale/dati/DM_campi_verifica_Garda.json').read_text())['campi']
    campi = {x['name']: False if x['type']=='boolean' else None if x['type']=='date' else '' for x in catalogo
              if not (x['name'].startswith('gvr_') and gruppo!='GVR' or x['name'].startswith('sc_sp_') and gruppo=='GVR')}
    if gruppo == 'GVR':
        campi.update(gvr_ver_attr=True, gvr_ver_insieme=False, gvr_osserv='DATI INVENTATI - PROVA TECNICA')
    else:
        campi['sc_sp_osservazioni'] = 'DATI INVENTATI - PROVA TECNICA'
    draft = {'campi':campi, 'date':{'funz':'2028-12-30'} if gruppo=='GVR' else {'scsp':'2028-12-30'}, 'camere':[],
             'esito':'Positivo', 'regime':'A2', 'data_rilascio':'2027-01-02'}
    code = f'V/{gruppo}/0040/26'
    history = [{'revisione': n, 'precedente': n-1, 'emesso_il':'2026-12-31' if n==1 else '2027-01-02',
                'codice_precedente':code, 'motivo':'Correzione di prova'} for n in range(1,rev+1)]
    v = NS(id=1, numero=40, anno=2026, codice_verbale=code, revisione=rev, revisioni_json=json.dumps(history),
           bozza_json=json.dumps(draft), verificatore_id=9)
    user = NS(id=9, versione=1, dati_tecnici_json=json.dumps({'nome':'Tecnico', 'cognome':'Inventato', 'qualifica':'Prova'}))
    models = {k: object() for k in ('Utente','TipoAttrezzatura','IdSpecifica','FamigliaGvr')}
    file = modello or ('verbale-gvr.docx' if gruppo=='GVR' else 'verbale-sc-sp.docx')
    raw = (ROOT / 'gestionale/dati/modelli' / file).read_bytes()
    class Session:
        def __init__(self):
            self.contatori = {}
        def get(self, m, id):
            if m is models['Utente']: return user
            if m is Contatore: return self.contatori.get(id)
            if m in (models['TipoAttrezzatura'],models['IdSpecifica']): return NS(codice='a1' if m is models['TipoAttrezzatura'] else '1')
            return None
        def add(self, x):
            self.contatori[(x.gruppo,x.anno)] = x
    session = Session()
    te = {'date':date, 'Decimal':Decimal, 'ROUND_HALF_UP':ROUND_HALF_UP, 'ErroreUtente':ErroreUtente,
          'ContatoreDM':Contatore, 'dati_lavoro':lambda *_:(asset,row,None)}
    funzioni('gestionale/moduli/dm/servizio.py', ['componenti'], te)
    funzioni('gestionale/moduli/dm/tecnico.py', ['_registra_numero'], te)
    env = {**models, 'json':json, 'hashlib':hashlib, 're':re, 'word':word, 'ErroreUtente':ErroreUtente,
        'PROFILO':{'nome','cognome','qualifica','codice_fiscale'},
        'tecnico':NS(dati_lavoro=te['dati_lavoro'], componenti=te['componenti'],
                     DATE={'funz':'funzionamento','integrita':'integrita','interna':'interna','scsp':'scsp'}, TIPI={'V2':'Successiva'}),
        'firma_dm':lambda *_:png(), 'modelli_servizio':NS(in_uso=lambda *_:NS(id=1, documento_id=1, codice='MODELLO-PROVA', revisione='03' if 'rev03' in file else '02')),
        'archivio':NS(leggi=lambda *_:(None,raw)), 'pdf':pdf, 'imp':impaginazione, 'io':io}
    from pypdf import PdfReader
    env['PdfReader'] = PdfReader
    funzioni('gestionale/moduli/dm/documenti.py', ['dumps','profilo_json','dati_revisione','valori','compila','valida_pdf'], env)
    return v, draft, session, te, env, NS(cfg=NS(cartella_documenti=ROOT,libreoffice=''))


def doc(numero='ORD-12', cig='CIG-A', cup='CUP-A', commessa='LOTTO-A'):
    return dict(tipo='OrdineAcquisto', numero=numero, data='2026-10-01', cig=cig, cup=cup, commessa=commessa)


def fattura(documenti, ambito='DPR'):
    righe = []
    for i, docs in enumerate(documenti,1):
        ref = {'ambito':ambito,'preventivo':f'P/00{i}/26'}
        if docs is not None: ref['documenti_collegati']=docs
        descr = f'Verifica impianto {i}'
        if ambito=='DM' and docs:
            descr += f", preventivo {ref['preventivo']}, rif. ordine cliente {docs[0]['numero']}"
        righe.append({'descrizione':descr,'quantita':'1','prezzo':'100.00','importo':10000,'aliquota':2200,'riferimenti':ref})
    return {'righe':righe,'opzioni':{'documenti':[d for ds in documenti if ds for d in ds]}}


class Revisioni(unittest.TestCase):
    def test_identificazione_gvr_scsp_revisioni_1_2_modelli_02_03(self):
        for gruppo in ('GVR','SC'):
            for n in (1,2):
                for suffix in ('','_rev03'):
                    with self.subTest(gruppo=gruppo,rev=n,modello=suffix):
                        file = ('verbale-gvr' if gruppo=='GVR' else 'verbale-sc-sp') + suffix + '.docx'
                        v,d,s,t,e,a=dm(gruppo,n,file)
                        prep=e['valori'](s,v,a)
                        raw=word.compila(prep['modello'],prep['valori'],prep['camere'],prep['firma'])
                        text=testo_docx(raw)
                        self.assertIn(f'{gruppo} 40/2026 · rev. {n}',text)
                        prev=f'V/{gruppo}/0040/26' + (' rev. 1' if n==2 else '')
                        self.assertIn('Sostituisce il verbale n. '+prev,text)
                        self.assertIn('emesso il '+('31/12/2026' if n==1 else '02/01/2027'),text)
                        self.assertEqual(text.count('Sostituisce il verbale'),1)
                        self.assertNotIn('{{',text)

    def test_impronta_revisione_diversa_originale(self):
        v,d,s,t,e,a=dm(rev=0)
        old=e['valori'](s,v,a)
        self.assertNotIn('v.revisione_dicitura',old['valori'])
        v.revisione=1;v.revisioni_json=json.dumps([{'revisione':1,'precedente':0,'emesso_il':'2026-12-31'}])
        new=e['valori'](s,v,a)
        self.assertNotEqual(old['impronta'],new['impronta'])
        self.assertIn('revisione_verbale',new['fotografia'])

    def test_compatibilita_storico_0160_e_data_mancante(self):
        v,d,s,t,e,a=dm()
        v.revisioni_json=json.dumps([{'revisione':1,'precedente':0,'emesso_il':'2026-12-31'}])
        self.assertIn(v.codice_verbale,e['dati_revisione'](v)['dicitura'])
        v.revisioni_json='[]'
        with self.assertRaises(ErroreUtente):e['dati_revisione'](v)

    def test_numero_revisione_a_cavallo_anno(self):
        for gruppo in ('GVR','SC','SP'):
            v,d,s,t,e,a=dm(gruppo)
            code=v.codice_verbale
            t['_registra_numero'](s,v,d)
            self.assertEqual((v.numero,v.anno,v.codice_verbale),(40,2026,code))
            self.assertEqual(v.data_rilascio,date(2027,1,2))
            self.assertFalse(s.contatori)

    def test_verbale_ordinario_si_numera_nel_nuovo_anno(self):
        v,d,s,t,e,a=dm(rev=0)
        t['_registra_numero'](s,v,d)
        self.assertEqual(v.codice_verbale,'V/GVR/0001/27')
        self.assertEqual(s.contatori[('GVR',2027)].ultimo,1)

    def test_revisione_senza_identita_non_consuma_numero(self):
        v,d,s,t,e,a=dm();v.numero=None
        with self.assertRaises(ErroreUtente):t['_registra_numero'](s,v,d)
        self.assertFalse(s.contatori)


class DocumentiFattura(unittest.TestCase):
    def aggrega(self, docs, esistenti=()):
        f=NS(opzioni=json.dumps({'documenti':list(esistenti),'causale':'Da conservare'}),versione=1)
        calls=[]
        def modifica(s,u,x,d):
            x.opzioni=json.dumps(d['opzioni']);calls.append(d)
        e={'json':json,'chiave_documento':chiave_documento,'modifica':modifica}
        funzioni('gestionale/moduli/finanza/servizio.py',['_aggiungi_documenti'],e)
        ps=[NS(id=i,documenti_collegati=json.dumps([d])) for i,d in enumerate(docs,1)]
        e['_aggiungi_documenti'](None,None,f,ps)
        first=json.loads(f.opzioni)
        e['_aggiungi_documenti'](None,None,f,ps)
        self.assertEqual(json.loads(f.opzioni),first)
        self.assertEqual(first['causale'],'Da conservare')
        return first['documenti'],calls

    def test_metadati_diversi_conservati_e_ripetizione_idempotente(self):
        for campo in ('cig','cup','commessa'):
            with self.subTest(campo=campo):
                a=doc();b={**a,campo:'DIVERSO'}
                out,calls=self.aggrega([a,b])
                self.assertEqual(out,[a,b]);self.assertEqual(len(calls),1)

    def test_documenti_identici_accorpati_anche_su_bozza_esistente(self):
        a=doc();b=doc(cig='CIG-B')
        out,calls=self.aggrega([a,a,b],[a])
        self.assertEqual(out,[a,b]);self.assertEqual(len(calls),1)

    def test_fotografia_ordine_non_cambia_con_preventivo(self):
        p=NS(id=1,ambito='DPR',codice='P/001/26',cliente_id=9,documenti_collegati=json.dumps([doc()]),rif_ordine='',data_ordine=None)
        e={'json':json,'Cliente':object(),'documenti_del_preventivo':documenti_del_preventivo}
        funzioni('gestionale/moduli/finanza/prestazioni.py',['riferimenti'],e)
        refs=e['riferimenti'](NS(get=lambda *_:NS(ragione_sociale='Cliente prova')),None,p,None)
        p.documenti_collegati=json.dumps([doc(numero='ORD-NUOVO')])
        self.assertEqual(refs['documenti_collegati'],[doc()])

    def test_ordine_semplice_compatibile(self):
        p=NS(rif_ordine='ORD-LEGACY',data_ordine=date(2026,10,1),documenti_collegati='[]')
        self.assertEqual(documenti_del_preventivo(p)[0]['numero'],'ORD-LEGACY')
        self.assertEqual(documenti_del_preventivo(p)[0]['data'],'2026-10-01')


class StampaFattura(unittest.TestCase):
    def test_ordini_distinti_sulle_rispettive_righe(self):
        for ambito in ('DPR','DM'):
            a=doc('ORD-A');b=doc('ORD-B')
            rows,notes=stampa.righe_stampa(fattura([[a],[b]],ambito))
            self.assertIn('ORD-A',rows[0]['descrizione']);self.assertNotIn('ORD-B',rows[0]['descrizione'])
            self.assertIn('ORD-B',rows[1]['descrizione']);self.assertNotIn('ORD-A',rows[1]['descrizione'])
            self.assertFalse(any('ORD-' in n for n in notes))

    def test_ordine_comune_una_volta_anche_con_preventivi_diversi(self):
        for ambito in ('DPR','DM'):
            a=doc('ORD-COMUNE')
            rows,notes=stampa.righe_stampa(fattura([[a],[a]],ambito))
            self.assertFalse(any('ORD-COMUNE' in r['descrizione'] for r in rows))
            self.assertEqual(sum('ORD-COMUNE' in n for n in notes),1)

    def test_stessa_chiave_con_cig_diverso_non_e_comune(self):
        rows,notes=stampa.righe_stampa(fattura([[doc(cig='CIG-A')],[doc(cig='CIG-B')]]))
        self.assertIn('CIG-A',rows[0]['descrizione']);self.assertNotIn('CIG-B',rows[0]['descrizione'])
        self.assertIn('CIG-B',rows[1]['descrizione']);self.assertFalse(any('ORD-12' in n for n in notes))

    def test_vecchia_fattura_senza_fotografie_non_inventa_associazioni(self):
        f=fattura([None,None]);f['opzioni']['documenti']=[doc('ORD-A'),doc('ORD-B')]
        rows,notes=stampa.righe_stampa(f)
        self.assertFalse(any('ORD-' in r['descrizione'] for r in rows))
        self.assertTrue(any('ORD-A' in n for n in notes));self.assertTrue(any('ORD-B' in n for n in notes))

    def test_documento_comune_e_documenti_particolari(self):
        comune=doc('ORD-COMUNE');a=doc('CONTRATTO-A');a['tipo']='Contratto';b=doc('CONTRATTO-B');b['tipo']='Contratto'
        rows,notes=stampa.righe_stampa(fattura([[comune,a],[comune,b]]))
        self.assertEqual(sum('ORD-COMUNE' in n for n in notes),1)
        self.assertIn('CONTRATTO-A',rows[0]['descrizione']);self.assertIn('CONTRATTO-B',rows[1]['descrizione'])


class Permessi(unittest.TestCase):
    def test_payload_coerente_col_server_per_tutti_i_permessi(self):
        e={'dataclass':dataclass,'field':field,'TECNICI':TECNICI, 'GESTIONE_PER_ATTIVITA':GESTIONE_PER_ATTIVITA}
        funzioni('gestionale/moduli/utenti/accesso.py',[],e,classes=['UtenteCorrente'])
        all_codes={'verifiche.assegna','verifiche.riesame','verifiche.esegui','fatture.genera'}
        for rt in ('DPR','DM'):
            altro='DM' if rt=='DPR' else 'DPR'
            u=e['UtenteCorrente'](id=9,username='prova',nome='Prova',ruolo='Ruoli incrociati',amministratore=False,
                permessi=all_codes,per_attivita={rt:all_codes,altro:{'verifiche.esegui','fatture.genera'}})
            p=u.per_interfaccia()
            for a in ('DPR','DM'):
                for code in all_codes:self.assertEqual(code in p['permessi_per_attivita'][a],u.puo(code,a))
            self.assertNotIn('verifiche.riesame',p['permessi_per_attivita'][altro])
        # Ruolo comune e costruzioni compatibili senza mappa.
        for kwargs in ({'per_attivita':{'':all_codes}}, {'amministratore':True}, {'attivita':frozenset({'DM'})}):
            base=dict(id=9,username='prova',nome='Prova',ruolo='Prova',amministratore=False,permessi=all_codes)
            u=e['UtenteCorrente'](**{**base,**kwargs});p=u.per_interfaccia()
            for a in ('DPR','DM'):
                for code in all_codes:self.assertEqual(code in p['permessi_per_attivita'][a],u.puo(code,a))

    def test_javascript_originale(self):
        node=os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')
        if not node:self.skipTest('Node non disponibile: verifica JavaScript da eseguire separatamente.')
        r=subprocess.run([node,str(ROOT/'strumenti/verifica_permessi_0161.cjs')],capture_output=True,text=True)
        self.assertEqual(r.returncode,0,r.stdout+r.stderr)

    def test_testo_firma_coerente_con_minimo(self):
        js=(ROOT/'gestionale/static/js/schede.js').read_text()
        self.assertIn('minimo 50 × 20 pixel; consigliata',js)
        self.assertNotIn('PNG o JPG, almeno 300 × 100 pixel.',js)


class ConversionePDF(unittest.TestCase):
    @unittest.skipUnless(PDF,'Conversione reale: usare --pdf.')
    def test_cortesia_fattura_con_ordini_distinti(self):
        from pypdf import PdfReader
        f=fattura([[doc('ORD-A',cig='CIG-A')],[doc('ORD-B',cig='CIG-B')]])
        f.update(societa={'ragione_sociale':'Società collaudo inventata','indirizzo':'Via Prova 1','cap':'10100','comune':'Torino'},
            cliente={'ragione_sociale':'Cliente collaudo inventato','indirizzo':'Via Prova 2','cap':'10100','comune':'Torino'},
            tipo='TD01',data='2026-10-12',codice='',imponibile=20000,iva=4400,totale=24400,dovuto=24400,
            riepiloghi=[{'aliquota':2200,'imponibile':20000,'iva':4400,'natura':''}])
        raw=stampa.pdf_fattura(f)
        text=''.join(p.extract_text() or '' for p in PdfReader(io.BytesIO(raw)).pages)
        self.assertEqual(text.count('ORD-A'),1);self.assertEqual(text.count('ORD-B'),1)
        self.assertIn('CIG-A',text);self.assertIn('CIG-B',text);self.assertIn('BOZZA',text)

    @unittest.skipUnless(PDF,'Conversione reale: usare --pdf.')
    def test_revisioni_pdf_modelli_02_03(self):
        from pypdf import PdfReader
        OUT.mkdir(parents=True,exist_ok=True)
        for gruppo in ('GVR','SC'):
            for rev in (1,2):
                for suffix in ('','_rev03'):
                    file=('verbale-gvr' if gruppo=='GVR' else 'verbale-sc-sp')+suffix+'.docx'
                    v,d,s,t,e,a=dm(gruppo,rev,file);p=e['valori'](s,v,a)
                    preparata=e['compila'](p,a)
                    converted=pdf.da_word(impaginazione.sostituisci_firma(preparata['docx'],p['firma']))
                    self.assertEqual(impaginazione.pagine(converted),preparata['pagine'])
                    text=''.join(x.extract_text() or '' for x in PdfReader(io.BytesIO(converted)).pages)
                    self.assertIn(f'rev. {rev}',text);self.assertIn('Sostituisce il verbale',text)
                    (OUT/f'PROVA_{gruppo}_revisione_{rev}{suffix}.pdf').write_bytes(converted)

    @unittest.skipUnless(PDF,'Conversione reale: usare --pdf.')
    def test_pagine_anteprima_e_firma_con_revisione(self):
        OUT.mkdir(parents=True,exist_ok=True)
        for gruppo in ('GVR','SC'):
            file='verbale-gvr_rev03.docx' if gruppo=='GVR' else 'verbale-sc-sp_rev03.docx'
            v,d,s,t,e,a=dm(gruppo,1,file);p=e['valori'](s,v,a)
            base=word.compila(p['modello'],p['valori'],p['camere'],p['firma'],riserva=True)
            misura=impaginazione.applica(base,misura=True)
            spazio=impaginazione.spazio_mancante(misura,pdf.da_word(misura),pdf.da_word)
            bozza=impaginazione.applica(base,spazio=spazio)
            prima=pdf.da_word(bozza)
            dopo=pdf.da_word(impaginazione.sostituisci_firma(bozza,p['firma']))
            self.assertEqual(impaginazione.pagine(prima),impaginazione.pagine(dopo))
            (OUT/f'PROVA_{gruppo}_rev1_anteprima.pdf').write_bytes(prima)
            (OUT/f'PROVA_{gruppo}_rev1_firma.pdf').write_bytes(dopo)


if __name__=='__main__':
    if PDF and not pdf.disponibile():raise SystemExit('LibreOffice richiesto da --pdf non è disponibile.')
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__]))
    OUT.mkdir(parents=True,exist_ok=True)
    report={'versione':'0.16.1','python':sys.version.split()[0], 'test_eseguiti':result.testsRun,
        'fallimenti':len(result.failures),'errori':len(result.errors),'saltati':len(result.skipped),
        'pdf_reali':PDF,'limiti':'Funzioni originali con ORM/sessioni sostitutivi. Suite HTTP/SQLAlchemy/Alembic non eseguita.'}
    (OUT/'risultati.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    sys.exit(0 if result.wasSuccessful() else 1)
