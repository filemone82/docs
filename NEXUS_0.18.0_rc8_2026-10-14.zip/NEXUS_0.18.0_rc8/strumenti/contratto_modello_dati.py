"""Inventario riproducibile del modello Nexus; nessuna connessione o modifica ai dati."""
import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from sqlalchemy import CheckConstraint, UniqueConstraint
from sqlalchemy.dialects import postgresql
from gestionale.modelli import Base


def inventario():
    tabelle=[]
    for t in Base.metadata.sorted_tables:
        tabelle.append({'tabella':t.name,'pk':[c.name for c in t.primary_key.columns],
            'colonne':[{'nome':c.name,'tipo_pg':str(c.type.compile(dialect=postgresql.dialect())),
                        'nullable':c.nullable} for c in t.columns],
            'relazioni':[{'nome':str(f.name),'colonne':[e.parent.name for e in f.elements],
                          'destinazione':f.referred_table.name,'colonne_destinazione':[e.column.name for e in f.elements]}
                         for f in t.foreign_key_constraints],
            'unique':[[c.name for c in u.columns] for u in t.constraints if isinstance(u,UniqueConstraint)],
            'check':[str(c.sqltext) for c in t.constraints if isinstance(c,CheckConstraint)]})
    return {'schema':'0027','origine':'modelli applicativi, non introspezione di un server',
            'tabelle':tabelle,'numero_tabelle':len(tabelle),
            'numero_relazioni':sum(len(t['relazioni']) for t in tabelle)}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(inventario(),ensure_ascii=False,indent=2)+'\n')
