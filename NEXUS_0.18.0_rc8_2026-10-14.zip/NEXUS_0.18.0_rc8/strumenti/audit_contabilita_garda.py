"""Quadratura non distruttiva delle fatture Garda già estratte in staging SQLite.

Uso: python strumenti/audit_contabilita_garda.py /percorso/ingecert.sqlite --output quadratura.json
Non importa, non emette XML, non contatta S3/Aruba. Output aggregato, senza anagrafiche.
"""
import argparse
import json
import sqlite3
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path


def cent(v):
    return int((Decimal(str(v or 0)) * 100).quantize(Decimal(1), rounding=ROUND_HALF_UP))


def audit(path):
    with sqlite3.connect(path.resolve().as_uri()+'?mode=ro', uri=True) as c:
        c.row_factory = sqlite3.Row
        headers=list(c.execute('SELECT * FROM fatture_clienti'))
        rows=list(c.execute('SELECT * FROM fatture_clienti_righe'))
        anomalie=[]
        by_id={f['id']:f for f in headers}
        for f in headers:
            rs=[r for r in rows if r['fattura']==f['id']]
            base=sum(cent(r['totale_netto']) for r in rs)
            if abs(base-cent(f['totale_netto']))>1:
                anomalie.append({'fattura_sorgente_id':f['id'],'controllo':'righe_vs_imponibile','delta_centesimi':base-cent(f['totale_netto'])})
            if abs(cent(f['totale_netto'])+cent(f['totale_iva'])+cent(f['bollo_importo'])-cent(f['totale_documento']))>1:
                anomalie.append({'fattura_sorgente_id':f['id'],'controllo':'imponibile_iva_bollo_vs_totale'})
        orfane=sum(r['fattura'] not in by_id for r in rows)
        negative=sum(cent(r['totale_netto'])<0 for r in rows)
        pay=list(c.execute('SELECT * FROM pagamenti'))
        return {'sorgente':path.name,'fatture':len(headers),'righe':len(rows),'righe_orfane':orfane,
                'righe_negative':negative,'totale_documenti_centesimi':sum(cent(f['totale_documento']) for f in headers),
                'totale_dovuto_centesimi':sum(cent(f['totale_dovuto']) for f in headers),
                'scadenze_pagamento':len(pay),'totale_scadenze_centesimi':sum(cent(x['importo']) for x in pay),
                'anomalie':anomalie,'xml_originali_confrontati':0,
                'nota':'Quadratura dei record del dump; non equivale al confronto degli XML originali né importa gli incassi.'}


if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('staging',type=Path);a.add_argument('--output',type=Path);args=a.parse_args()
    data=json.dumps(audit(args.staging),ensure_ascii=False,indent=2)
    if args.output:args.output.write_text(data+'\n',encoding='utf-8')
    else:print(data)
