# NEXUS rc7 — avvio collaudo DPR via API su PostgreSQL

Base rc6, schema 0029 invariato. Federico ha eseguito il 14 ottobre 2026 i
cinque test di `tests/postgresql/test_verbali_pg.py` sul suo PostgreSQL 18:
**5 passed, 1 warning, 55.93 s** dopo la correzione `_righe()` di rc6.
L'avviso `httpx`/Starlette non ha impedito i test. Il test della prima
importazione era passato separatamente in 16.45 s.

La rc7 aggiunge solo `tests/postgresql/test_dpr_api_pg.py`, che riutilizza tre
test funzionali DPR esistenti con la fixture PostgreSQL e
`verbali_postgresql=True`: bozza/emissione/acquisizione della verifica,
interruzione e riallineamento, riesame non conforme e revisione. Non replica
le regole in test separati. In questo ambiente la raccolta mostra 3 test; la
prova locale dà 3 skipped perché il server PG non è disponibile. Il loro esito
su PostgreSQL nativo **non è ancora noto**.

Per il test rapido sul PC già predisposto, copiare soltanto
`tests/postgresql/test_dpr_api_pg.py` nella cartella omonima della copia rc5
che contiene già `postgresql.py` corretto. Conservare nello stesso PowerShell
la variabile `NEXUS_TEST_POSTGRESQL_ADMIN_URL`. Eseguire dapprima
`python -u -m pytest -vv -s --timeout=240 tests/postgresql/test_dpr_api_pg.py`.
La fixture crea e distrugge database temporanei `nexustest_<uuid>`. Non
modificare `nexus_locale`, non attivare PG dei verbali su dati reali.

Se fallisce, conservare il traceback integrale. Proseguire con correzioni
mirate e nuove prove prima di un'importazione su copia dei dati reali. Restano
aperte la migrazione ingecert MariaDB + allegati + storico amministrativo,
la quadratura con VerbalizzAI autonomo, backup/ripristino PG con verbali
importati, UI integrata e prove di usabilità per ruolo.
