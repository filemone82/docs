@echo off
chcp 65001 >nul
cd /d "%~dp0"
title NEXUS - test automatici
if not exist ".venv\Scripts\python.exe" (
  echo  Prima esegui INSTALLA_WINDOWS.bat
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pip install -r requirements-sviluppo.txt
".venv\Scripts\python.exe" -m pytest -v
pause
