# Gestionale AD 0.9.1 — correzione dei preventivi duplicati

9 ottobre 2026. Base evolutiva del gestionale integrato: nucleo iniziale, non AD_DM completo. Maschere DM invariate rispetto alla 0.9.0.

Il secondo preventivo sulla stessa verifica periodica non completata è bloccato già alla creazione, anche dalle API. La maschera delle scadenze disabilita Procedi per la periodica già coperta e collega il preventivo esistente. Annullamento della prestazione/offerta libera la scadenza; completamento del lavoro consente la successiva. Revisioni sostitutive e VS distinte conservate. Rifiuto non equivale ad annullamento.

Nessuna bonifica automatica dei duplicati precedenti: non si scelgono né cancellano offerte/incarichi al posto dell’operatore. Nessuna nuova migrazione rispetto alla versione base.

Suite completa: 147 test passati; 14 nuove regressioni. JavaScript maschera verificato in jsdom con API simulate, backend HTTP verificato separatamente. Linux/Python 3.12.14/SQLite; Windows non ancora osservato.

## Avvio e dati

Estrarre il programma in una cartella nuova, installare le dipendenze con INSTALLA_WINDOWS.bat e seguire INIZIA_QUI_WINDOWS.md. Usare una copia completa verificata dei dati precedenti, mai lo stesso archivio aperto da due programmi. AVVIA_COLLAUDO_WINDOWS.bat usa Dati_Collaudo nella nuova cartella: non ritrova automaticamente i dati del collaudo precedente. Per riusarli, chiudere i programmi e trasferire la copia completa nell’archivio di prova, oppure usare l’avvio ordinario con cartella_dati configurata esplicitamente.

Per l’aggiornamento circoscritto del collaudo 0.8 scegliere 0.8.1 (schema 0010). Per proseguire il progetto integrato scegliere 0.9.1 (schema 0011). Il salto 0.8→0.9 continua a richiedere la migrazione del nucleo, con backup pre-aggiornamento.

La 0.9.1 non completa DM/I&C né riscrive le maschere DM. Fonte funzionale principale: codice/database adsrl Garda; confronto delle schermate nel documento RIFERIMENTO_MASCHERE_DM.md incluso nella 0.9.1. INAIL, flussi e tariffe DM, documenti e compensi I&C restano da completare.

Risultati e rapporto dettagliato in report_collaudo. VerbalizzAI incorporato 0.3.32.3; autonomo/VPS separati.

Indicazione successiva R99: il prossimo rilascio funzionale richiesto sarà DPR+DM effettivamente integrato. Questo pacchetto è manutenzione/base tecnica già collaudata e non quel rilascio.
