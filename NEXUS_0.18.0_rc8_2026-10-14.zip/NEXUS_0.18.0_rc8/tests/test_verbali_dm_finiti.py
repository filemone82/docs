"""0.15 · Verbali DM come in VerbalizzAI: anteprima con spazio firma riservato e nome «BOZZA», firma DM obbligatoria,
emissione con la firma al posto dello spazio e controllo delle pagine, riquadro firme intero e in fondo alla pagina,
«Aggiorna / Conserva i dati del verbale»."""

import io
from zipfile import ZipFile

import pytest
from lxml import etree
from pypdf import PdfWriter
from test_beni import ok
from test_dm_documenti import doc, effettua, generata, pdf_valido, registrata, sede_dm  # noqa: F401
from test_dm_tecnico import assegna, incarico, salva

from gestionale.moduli.dm import impaginazione as imp

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def _pdf(pagine):
    w = PdfWriter()
    for _ in range(pagine):
        w.add_blank_page(width=595, height=842)
    b = io.BytesIO()
    w.write(b)
    return b.getvalue()


def test_emissione_con_pagine_diverse_rifiutata(admin, sede, monkeypatch):
    from gestionale.core import pdf
    v, _, _ = registrata(admin, sede)
    v = generata(admin, v)
    monkeypatch.setattr(pdf, "da_word", lambda *a: _pdf(2))      # con la firma il verbale «cresce» di una pagina
    r = effettua(admin, v)
    assert r.status_code == 400 and "da 1 a 2 pagine" in r.json()["errore"]
    assert ok(admin.get(f"/api/dm/incarichi/{v['id']}"))["stato"] == "registrata"


def test_ritocco_senza_spazio_firma_rifiutato_all_emissione(admin, sede):
    v, _, _ = registrata(admin, sede)
    v = generata(admin, v)
    raw = admin.get(doc(v, formato="docx")["url"]).content
    # ritocco che toglie il riquadro della firma (rinomina l'immagine riservata): il testo non cambia
    with ZipFile(io.BytesIO(raw)) as z:
        parti = {n: z.read(n) for n in z.namelist()}
    parti["word/document.xml"] = parti["word/document.xml"].replace(imp.RISERVATO.encode(), b"Immagine 1")
    out = io.BytesIO()
    with ZipFile(out, "w") as z:
        for n, b in parti.items():
            z.writestr(n, b)
    r = admin.post(f"/api/dm/incarichi/{v['id']}/documenti/carica", files={"file": ("ritocco.docx", out.getvalue())},
                   data={"versione": str(v["versione"]), "tipo": "verbale"})
    assert r.status_code == 200, r.text
    v = r.json()
    assert doc(v)["origine"] == "word_ritoccato" and doc(v)["nome"].endswith(" - BOZZA.pdf")
    r = effettua(admin, v)
    assert r.status_code == 400 and "spazio riservato alla firma" in r.json()["errore"]


def test_aggiorna_o_conserva_i_dati_del_verbale(admin, sede):
    v, a, _ = registrata(admin, sede)
    v = ok(salva(admin, v, campi={"gvr_acc_sicur": "Valvole del 2024"}, data_rilascio="2026-08-01", date={"funz": "2028-07-31"}))
    ok(effettua(admin, generata(admin, v)))
    a = ok(admin.get(f"/api/beni/{a['id']}"))
    w, _, _ = incarico(admin, sede, a=a)
    w = assegna(admin, w)
    from test_dm_tecnico import pronta, registra
    w = ok(salva(admin, w, campi={"gvr_acc_sicur": "Valvola provvisoria in prova"}, data_rilascio="2026-10-01",
                 date={"funz": "2028-09-30"}))
    w = ok(registra(admin, pronta(admin, w)))
    w = generata(admin, ok(admin.get(f"/api/dm/incarichi/{w['id']}")))
    d = doc(w)
    r = admin.post(f"/api/dm/incarichi/{w['id']}/effettuata", {"versione": w["versione"], "documento_id": d["id"],
                                                                "impronta_pdf": d["impronta"], "dati_verbale": "boh"})
    assert r.status_code == 400
    w = ok(admin.post(f"/api/dm/incarichi/{w['id']}/effettuata", {"versione": w["versione"], "documento_id": d["id"],
                                                                   "impronta_pdf": d["impronta"], "dati_verbale": "conserva"}))
    assert w["stato"] == "effettuata"
    g = {x["codice"]: x for x in ok(admin.get(f"/api/dm/attrezzature/{a['id']}/dati-verbale"))["gruppi"]}
    assert g["gvr_accessori"]["valore"]["campi"]["gvr_acc_sicur"] == "Valvole del 2024"
    assert g["gvr_accessori"]["valore"]["origine"] == "conservata"
    # il verbale emesso resta con i suoi dati
    assert ok(admin.get(f"/api/dm/incarichi/{w['id']}"))["bozza"]["campi"]["gvr_acc_sicur"] == "Valvola provvisoria in prova"


def test_riquadro_firme_intero_e_spinto_in_fondo(admin, sede, app):
    v, _, _ = registrata(admin, sede)
    v = generata(admin, v)
    raw = admin.get(doc(v, formato="docx")["url"]).content
    root = etree.fromstring(ZipFile(io.BytesIO(raw)).read("word/document.xml"))
    blocco = imp.blocco_firme(root.find(W + "body"))
    assert len([x for x in blocco if x.tag == W + "tbl"]) >= 2
    for t in (x for x in blocco if x.tag == W + "tbl"):
        assert all(tr.find(W + "trPr/" + W + "cantSplit") is not None for tr in t.iter(W + "tr"))
    assert imp.ha_spazio_riservato(raw)
    # distanziatore: con uno spazio misurato va un paragrafo «mantieni con il successivo» prima del riquadro
    spinto = imp.applica(raw, spazio=120.0)
    r2 = etree.fromstring(ZipFile(io.BytesIO(spinto)).read("word/document.xml"))
    primo = imp.blocco_firme(r2.find(W + "body"))[0].getprevious()
    assert primo.find(W + "pPr/" + W + "keepNext") is not None
    assert primo.find(W + "pPr/" + W + "spacing").get(W + "before") == str(round(119 * 20))
    # misura: segnalibro invisibile sotto il riquadro
    misura = imp.applica(raw, misura=True)
    assert imp.SEGNO.encode() in ZipFile(io.BytesIO(misura)).read("word/document.xml")


@pytest.mark.pdf_vero
def test_libreoffice_riquadro_in_fondo_e_stesse_pagine(admin, sede):
    from gestionale.core import pdf
    if not pdf.disponibile():
        pytest.skip("LibreOffice non installato")
    v, _, _ = registrata(admin, sede)
    v = generata(admin, v)
    anteprima = admin.get(doc(v)["url"]).content
    docx = admin.get(doc(v, formato="docx")["url"]).content
    # nell'anteprima il riquadro è già in fondo: una nuova misura trova (quasi) niente spazio libero
    misura = imp.applica(docx, misura=True)
    assert imp.spazio_mancante(misura, pdf.da_word(misura), pdf.da_word) < 20
    v = ok(effettua(admin, v))
    assert imp.pagine(admin.get(doc(v)["url"]).content) == imp.pagine(anteprima)
