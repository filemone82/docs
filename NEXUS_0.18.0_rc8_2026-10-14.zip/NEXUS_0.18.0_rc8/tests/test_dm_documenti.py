"""Ciclo DM: attese dai sorgenti Garda, documenti e mail su HTTP effettivo."""

from conftest import revisore
import io
from zipfile import ZipFile, ZIP_DEFLATED

import pytest
from pypdf import PdfWriter, PdfReader
from lxml import etree

from conftest import nuovo_utente
from test_dm_tecnico import incarico, assegna, pronta, registra, salva
from test_beni import ok, nuovo
from test_anagrafica import crea_cliente, crea_sede
from gestionale.moduli.dm.modelli import IncaricoDM


def pdf_di_prova():
    w = PdfWriter()
    w.add_blank_page(width=595, height=842)
    stream = io.BytesIO()
    w.write(stream)
    return stream.getvalue()


@pytest.fixture(autouse=True)
def pdf_valido(request, monkeypatch):
    if request.node.get_closest_marker('pdf_vero') is None:
        from gestionale.core import pdf
        monkeypatch.setattr(pdf, 'da_word', lambda *a: pdf_di_prova())


@pytest.fixture(name='sede')
def sede_dm(admin):
    return crea_sede(admin, crea_cliente(admin)['id'])


def profilo(admin, v):
    p = v['profilo_tecnico']
    ok(admin.put(f"/api/dm/tecnici/{p['utente_id']}/profilo", {
        'versione': p['versione'], 'nome': 'Mario', 'cognome': 'Rossi', 'qualifica': 'Ing.', 'codice_fiscale': 'RSSMRA80A01H501U'}))


def generata(admin, v):
    if not (v.get('profilo_tecnico') or {}).get('firma_dm'):   # 0.15: l'anteprima richiede la firma DM del tecnico
        firma_dm(admin, v)
        v = ok(admin.get(f"/api/dm/incarichi/{v['id']}"))
    return ok(admin.post(f"/api/dm/incarichi/{v['id']}/documenti/genera", {'versione': v['versione']}))


def doc(v, tipo='verbale', formato='pdf'):
    return next(x for x in v['documenti'] if x['attuale'] and x['tipo'] == tipo and x['formato'] == formato)


def effettua(admin, v):
    d = doc(v)
    return admin.post(f"/api/dm/incarichi/{v['id']}/effettuata", {
        'versione': v['versione'], 'documento_id': d['id'], 'impronta_pdf': d['impronta']})


def carica(admin, v, raw, tipo='verbale', nome='firmato.pdf'):
    return admin.post(f"/api/dm/incarichi/{v['id']}/documenti/carica", files={'file': (nome, raw)},
        data={'versione': str(v['versione']), 'tipo': tipo})


FIRMA_DM = (b"\x89PNG\r\n\x1a\n" + b"\x00\x00\x00\rIHDR" + (600).to_bytes(4, "big") + (200).to_bytes(4, "big")
            + b"\x08\x02\x00\x00\x00" + b"\x00" * 64)


def firma_dm(admin, v):
    """0.15: anteprima ed emissione richiedono la firma DM del tecnico."""
    uid = v['profilo_tecnico']['utente_id']
    r = admin.c.post(f"/api/dm/tecnici/{uid}/firma", files={'file': ('firma.png', FIRMA_DM, 'image/png')}, headers=admin.h)
    assert r.status_code == 200, r.text


def registrata(admin, sede, firma=True, **kw):
    v, a, p = incarico(admin, sede, **kw)
    v = ok(registra(admin, pronta(admin, assegna(admin, v))))
    profilo(admin, v)
    if firma:
        firma_dm(admin, v)
        v = ok(admin.get(f"/api/dm/incarichi/{v['id']}"))
    return v, a, p


@pytest.mark.parametrize('gruppo', ['GVR', 'SC', 'SP'])
def test_modelli_originali_tutti_campi_e_pdf_confermato(admin, sede, gruppo):
    a = nuovo(admin, sede, gruppo, 'COLLAUDO-' + gruppo) if gruppo != 'GVR' else None
    v, a, _ = registrata(admin, sede, a=a)
    v = generata(admin, v)
    raw = admin.get(doc(v, formato='docx')['url']).content
    with ZipFile(io.BytesIO(raw)) as z:
        text = ''.join(etree.fromstring(z.read('word/document.xml')).itertext())
        assert '{{' not in text and 'Mario' in text and 'Rossi' in text
        assert 'GVR 1/2026' in text if gruppo == 'GVR' else gruppo in text
        assert ('Verifica di funzionamento' if gruppo == 'GVR' else 'Verifica periodica (successiva alla prima)') in text
        assert ('Attrezzatura a pressione' if gruppo == 'GVR' else 'Gru') in text
        assert 'Esito adeguato ai fini della sicurezza' in text if gruppo != 'GVR' else 'Risulta adeguato ai fini della sicurezza' in text
    assert effettua(admin, {**v, 'documenti': [{**x, 'impronta': 'errata'} for x in v['documenti']]}).status_code == 400
    v = ok(effettua(admin, v))
    assert v['stato'] == 'effettuata'
    d = doc(v)
    assert d['definitivo'] and d['nome'].startswith('verbale ')
    assert d['nome'].endswith('08102028 funz.pdf' if gruppo == 'GVR' else '08102028.pdf')   # AD-REV-007
    assert admin.get(d['url']).content == pdf_di_prova()
    sc = ok(admin.get(f"/api/beni/{a['id']}"))['scadenze']
    x = next(x for x in sc if x['componente'] == ('funzionamento' if gruppo == 'GVR' else 'scsp'))
    assert x['data_ultima'] == '2026-10-09' and x['data_prossima'] == '2028-10-08' and x['fonte'] == 'dm'
    assert salva(admin, v, campi={}).status_code == 400
    assert carica(admin, v, pdf_di_prova()).status_code == 400


def test_v1_scheda_tecnica_obbligatoria_e_pdf_non_valido(admin, sede):
    v, _, _ = incarico(admin, sede, tipo='V1')
    v = ok(registra(admin, pronta(admin, assegna(admin, v), regime='A1')))
    profilo(admin, v)
    v = generata(admin, v)
    assert effettua(admin, v).status_code == 400
    before = v['versione']
    assert carica(admin, v, b'%PDF-1.7 falso').status_code == 400
    v = ok(admin.get(f"/api/dm/incarichi/{v['id']}"))
    assert v['versione'] == before
    v = ok(carica(admin, v, pdf_di_prova(), 'scheda_tecnica'))
    v = ok(effettua(admin, v))
    assert doc(v, 'scheda_tecnica')['nome'].startswith('scheda tecnica ')


def test_pdf_diventa_obsoleto_se_cambia_scheda_tecnico_o_firma(admin, sede):
    v, _, _ = registrata(admin, sede)
    v = generata(admin, v)
    v = ok(salva(admin, v, campi={'gvr_osserv': 'Nuova osservazione rilevata'}))
    assert effettua(admin, v).status_code == 400
    v = generata(admin, v)
    p = v['profilo_tecnico']
    ok(admin.put(f"/api/dm/tecnici/{p['utente_id']}/profilo", {'versione': p['versione'], 'qualifica': 'Dott. Ing.'}))
    assert effettua(admin, v).status_code == 400
    v = generata(admin, v)
    assert ok(effettua(admin, v))['stato'] == 'effettuata'


def modifica_word(raw, modifica_testo=False):
    out = io.BytesIO()
    ns = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
    with ZipFile(io.BytesIO(raw)) as z, ZipFile(out, 'w', ZIP_DEFLATED) as dst:
        for n in z.namelist():
            b = z.read(n)
            if n == 'word/document.xml':
                root = etree.fromstring(b)
                root.find('.//' + ns + 'pgMar').set(ns + 'top', '1250')
                if modifica_testo:
                    root.find('.//' + ns + 't').text = 'CONTENUTO ALTERATO'
                b = etree.tostring(root, xml_declaration=True, encoding='UTF-8')
            dst.writestr(n, b)
    return out.getvalue()


def test_ritocco_impaginazione_ammette_margini_e_rifiuta_contenuti(admin, sede):
    v, _, _ = registrata(admin, sede)
    v = generata(admin, v)
    raw = admin.get(doc(v, formato='docx')['url']).content
    assert carica(admin, v, modifica_word(raw, True), nome='ritocco.docx').status_code == 400
    v = ok(carica(admin, v, modifica_word(raw), nome='ritocco.docx'))
    assert doc(v)['origine'] == 'word_ritoccato'
    assert len(v['documenti']) == 4
    assert ok(effettua(admin, v))['stato'] == 'effettuata'


def test_riesame_dm_r101_riapre_e_preserva_storico_e_documenti(admin, sede):
    v, _, _ = registrata(admin, sede)
    v = ok(revisore(admin, "DM").post(f"/api/dm/incarichi/{v['id']}/riesame", {'versione': v['versione'], 'esito': 'C'}))
    v = ok(effettua(admin, generata(admin, v)))
    assert v['riesame']['esito'] == 'C'
    assert revisore(admin, "DM").post(f"/api/dm/incarichi/{v['id']}/riesame", {'versione': v['versione'], 'esito': 'N'}).status_code == 400
    v = ok(revisore(admin, "DM").post(f"/api/dm/incarichi/{v['id']}/riesame", {'versione': v['versione'], 'esito': 'N', 'nota': 'Controllo da ripetere'}))
    assert v['stato'] == 'registrata' and doc(v)['definitivo']
    assert len(v['riesami']) == 2


@pytest.mark.parametrize('con_base', [True, False])
def test_riesame_negativo_ciclo_completo_tecnico_scadenze_e_cnd(admin, sede, app, con_base):
    """R108/R109: negativo → registrata; il tecnico assegnato vede la nota; date e CND tornano ai valori precedenti
    (date iniziali dichiarate oppure vuote); correzione, nuova chiusura e nuovo riesame; storico completo."""
    from test_dm_preventivi import gvr
    a = gvr(admin, sede)
    if con_base:
        a = ok(admin.put(f"/api/beni/{a['id']}/scadenze", {'versione': a['versione'], 'componente': 'funzionamento',
            'data_ultima': '2024-10-01', 'data_prossima': '2026-10-01'}))
    a = ok(admin.get(f"/api/beni/{a['id']}"))
    a = ok(admin.put(f"/api/beni/{a['id']}/scadenze", {'versione': a['versione'], 'componente': 'cnd',
        'data_ultima': '2016-10-09', 'data_prossima': '2026-11-30', 'numero_report': 'CND-STORICO'}))
    t = nuovo_utente(admin, app, 'dm_riesame', 'tecnico_dm')
    v, a, _ = incarico(admin, sede, a=a, comb='funz_integrita')
    v = assegna(admin, v, t.get('/api/io').json()['id'])
    v = ok(registra(t, pronta(t, v, cnd={'ultima': '2026-10-09', 'prossima': '2036-10-08', 'numero_report': 'CND-ERRATO'})))
    profilo(admin, v)
    v = ok(t.get(f"/api/dm/incarichi/{v['id']}"))
    v = ok(effettua(t, generata(t, v)))
    sc = {x['componente']: x for x in ok(admin.get(f"/api/beni/{a['id']}"))['scadenze']}
    assert sc['funzionamento']['data_prossima'] == '2028-10-08' and sc['cnd']['data_prossima'] == '2036-10-08'
    # Il tecnico non può riesaminare il proprio lavoro.
    assert t.post(f"/api/dm/incarichi/{v['id']}/riesame", {'versione': v['versione'], 'esito': 'N', 'nota': 'x'}).status_code == 403
    v = ok(revisore(admin, "DM").post(f"/api/dm/incarichi/{v['id']}/riesame", {'versione': v['versione'], 'esito': 'N',
        'nota': 'Data CND errata: rifare il controllo delle date'}))
    assert v['stato'] == 'registrata' and doc(v)['definitivo']
    vista = ok(t.get(f"/api/dm/incarichi/{v['id']}"))
    assert vista['riesame']['esito'] == 'N' and 'Data CND errata' in vista['riesame']['nota']
    sc = {x['componente']: x for x in ok(admin.get(f"/api/beni/{a['id']}"))['scadenze']}
    if con_base:
        assert sc['funzionamento']['data_ultima'] == '2024-10-01' and sc['funzionamento']['data_prossima'] == '2026-10-01'
    else:
        # R142 (0.16): senza base esplicita resta la data dichiarata alla registrazione dell'attrezzatura
        assert sc['funzionamento']['data_ultima'] is None and sc['funzionamento']['data_prossima'] == '2027-06-30'
    assert sc['cnd']['data_prossima'] == '2026-11-30' and sc['cnd']['numero_report'] == 'CND-STORICO'
    # Correzione: una CND più vicina di quella errata ora si registra (prima sarebbe stata scartata).
    v = ok(salva(t, vista, cnd={'ultima': '2026-10-09', 'prossima': '2031-10-08', 'numero_report': 'CND-2026-01'}))
    v = ok(effettua(t, generata(t, v)))
    assert v['stato'] == 'effettuata' and v['riesame']['fatto'] is False  # serve un nuovo riesame
    sc = {x['componente']: x for x in ok(admin.get(f"/api/beni/{a['id']}"))['scadenze']}
    assert sc['cnd']['data_prossima'] == '2031-10-08' and sc['cnd']['numero_report'] == 'CND-2026-01'
    assert sc['funzionamento']['data_prossima'] == '2028-10-08'
    v = ok(revisore(admin, "DM").post(f"/api/dm/incarichi/{v['id']}/riesame", {'versione': v['versione'], 'esito': 'C'}))
    assert v['stato'] == 'effettuata'
    assert [x['esito'] for x in v['riesami']] == ['C', 'N'] and all(x['utente'] and x['data'] for x in v['riesami'])
    # Ogni riesame lega il PDF esaminato (qui i PDF di prova sono identici, quindi lo stesso file in archivio).
    assert all(x['documento_id'] for x in v['riesami'])


def test_cnd_corretta_a_mano_dopo_chiusura_non_viene_ripristinata(admin, sede):
    from test_dm_preventivi import gvr
    a = gvr(admin, sede)
    a = ok(admin.put(f"/api/beni/{a['id']}/scadenze", {'versione': a['versione'], 'componente': 'cnd',
        'data_ultima': '2016-10-09', 'data_prossima': '2026-11-30', 'numero_report': 'CND-STORICO'}))
    v, a, _ = registrata(admin, sede, a=a, comb='integrita')
    v = ok(salva(admin, v, cnd={'ultima': '2026-10-09', 'prossima': '2031-10-08', 'numero_report': 'CND-A'}))
    v = ok(effettua(admin, generata(admin, v)))
    a = ok(admin.get(f"/api/beni/{a['id']}"))
    a = ok(admin.put(f"/api/beni/{a['id']}/scadenze", {'versione': a['versione'], 'componente': 'cnd',
        'data_prossima': '2031-12-31', 'numero_report': 'CND-A-rev'}))
    ok(revisore(admin, "DM").post(f"/api/dm/incarichi/{v['id']}/riesame", {'versione': v['versione'], 'esito': 'N', 'nota': 'Rivedere'}))
    x = next(x for x in ok(admin.get(f"/api/beni/{a['id']}"))['scadenze'] if x['componente'] == 'cnd')
    assert x['data_prossima'] == '2031-12-31' and x['numero_report'] == 'CND-A-rev'


def test_precedenti_selettivi_scadenza_componenti_salvata_non_riproposta(admin, sede, app):
    v, a, _ = registrata(admin, sede)
    v = ok(salva(admin, v, campi={'gvr_acc_sicur': 'Lista F', 'gvr_osserv': 'Osservazione F'},
                       data_rilascio='2026-08-01', date={'funz': '2029-07-31'}))
    ok(effettua(admin, generata(admin, v)))
    a = ok(admin.get(f"/api/beni/{a['id']}"))
    w, _, _ = incarico(admin, sede, a=a, comb='integrita')
    w = pronta(admin, assegna(admin, w), campi={'gvr_tub_stato': 'Integrità tubi', 'gvr_osserv': 'Osservazione I'})
    w = ok(registra(admin, w))
    ok(effettua(admin, generata(admin, w)))
    a = ok(admin.get(f"/api/beni/{a['id']}"))
    z, _, _ = incarico(admin, sede, a=a, comb='funz_integrita')
    z = assegna(admin, z)
    assert z['bozza']['campi']['gvr_acc_sicur'] == 'Lista F'
    assert z['bozza']['campi']['gvr_tub_stato'] == 'Integrità tubi'
    # Federico (12/10/2026, 13:32): nel combinato con funzionamento valgono le osservazioni dell'ultimo funzionamento
    # (prima, come Garda, la più recente fra le componenti: «Osservazione I»)
    assert z['bozza']['campi']['gvr_osserv'] == 'Osservazione F'
    assert z['bozza']['provenienza_precedenti']['gvr_acc_sicur']['incarico_id'] == v['id']
    z = ok(salva(admin, z, campi={'gvr_osserv': 'Annotazione nuova'}))
    a = ok(admin.get(f"/api/beni/{a['id']}"))
    ok(admin.put(f"/api/beni/{a['id']}", {'versione': a['versione'], 'modello': 'Nuovo modello'}))
    z = ok(admin.get(f"/api/dm/incarichi/{z['id']}"))
    assert z['bozza']['campi']['gvr_osserv'] == 'Annotazione nuova'
    with app.state.archivio.lettura() as s:
        assert s.get(IncaricoDM, v['id']).stato == 'effettuata'


def test_permessi_hash_download_mail_e_invii_non_toccano_pdf(admin, sede, app, monkeypatch):
    v, _, _ = registrata(admin, sede)
    v = ok(effettua(admin, generata(admin, v)))
    altro = nuovo_utente(admin, app, 'dm_intruso', 'tecnico_dm')
    assert altro.get(doc(v)['url']).status_code == 403
    assert altro.get(f"/api/dm/incarichi/{v['id']}/email").status_code == 403
    seen = []
    from gestionale.core import posta
    monkeypatch.setattr(posta, 'invia', lambda cfg, msg: seen.append(msg) or 'SMTP simulato')
    b = ok(admin.get(f"/api/dm/incarichi/{v['id']}/email"))
    b.update(a='collaudo@example.invalid', cc='', allegati=[x['id'] for x in b['allegati']])
    v = ok(admin.post(f"/api/dm/incarichi/{v['id']}/email", b))
    assert next(seen[0].iter_attachments()).get_payload(decode=True) == admin.get(doc(v)['url']).content
    assert len(v['invii']) == 1


@pytest.mark.parametrize('prossima,attesa,avviso,report,report_atteso', [
    ('2030-10-08','2030-10-08',False,'CND-NUOVO','CND-NUOVO'),
    ('2027-10-08','2029-10-08',True,'CND-NUOVO','CND-PRECEDENTE'),
    ('2029-10-08','2029-10-08',False,'CND-NUOVO','CND-NUOVO'),
    ('2030-10-08','2030-10-08',False,'','CND-PRECEDENTE'),
])
def test_cnd_confronto_date_e_report_preservato(admin, sede, prossima, attesa, avviso, report, report_atteso):
    from test_dm_preventivi import gvr
    a = gvr(admin, sede)
    a = ok(admin.put(f"/api/beni/{a['id']}/scadenze", {'versione': a['versione'], 'componente': 'cnd',
        'data_ultima': '2019-10-09', 'data_prossima': '2029-10-08', 'numero_report': 'CND-PRECEDENTE'}))
    v, a, _ = registrata(admin, sede, a=a, comb='integrita')
    v = ok(salva(admin, v, cnd={'ultima':'2026-10-09','prossima':prossima,'numero_report':report}))
    v = ok(effettua(admin, generata(admin, v)))
    assert bool(v['avvisi']) == avviso
    a = ok(admin.get(f"/api/beni/{a['id']}"))
    x = next(x for x in a['scadenze'] if x['componente']=='cnd')
    assert x['data_prossima'] == attesa
    assert x['numero_report'] == report_atteso


def test_effettuata_retrodatata_non_sostituisce_ultima_pertinente_e_annullamento(admin,sede):
    v, a, _ = registrata(admin,sede)
    v = ok(salva(admin,v,data_rilascio='2026-09-01',date={'funz':'2029-08-31'}))
    v = ok(effettua(admin,generata(admin,v)))
    a = ok(admin.get(f"/api/beni/{a['id']}"))
    w, a, _ = registrata(admin,sede,a=a)
    w = ok(salva(admin,w,data_rilascio='2026-08-01',date={'funz':'2028-07-31'}))
    w = ok(effettua(admin,generata(admin,w)))
    a = ok(admin.get(f"/api/beni/{a['id']}"))
    x = next(x for x in a['scadenze'] if x['componente']=='funzionamento')
    assert x['data_ultima']=='2026-09-01' and x['data_prossima']=='2029-08-31'
    ok(admin.post(f"/api/dm/incarichi/{v['id']}/annulla",{'versione':v['versione'],'motivo':'Correzione del lavoro'}))
    a = ok(admin.get(f"/api/beni/{a['id']}"))
    x = next(x for x in a['scadenze'] if x['componente']=='funzionamento')
    assert x['data_ultima']=='2026-08-01' and x['data_prossima']=='2028-07-31'


def test_migrazione_0013_popolata_preserva_bozza_e_relazioni(admin,sede,app):
    from alembic import command
    from gestionale.core import migrazioni
    from alembic.autogenerate import compare_metadata
    from alembic.runtime.migration import MigrationContext
    from gestionale.modelli import Base
    v, _, _ = incarico(admin,sede)
    v = pronta(admin,assegna(admin,v),campi={'gvr_osserv':'Bozza precedente'})
    arc = app.state.archivio
    cfg = migrazioni.config_alembic('sqlite:///'+str(arc.cfg.percorso_database))
    command.downgrade(cfg,'0013')
    assert migrazioni.revisione_database(arc.motore)=='0013'
    migrazioni.aggiorna(arc.motore)
    w = ok(admin.get(f"/api/dm/incarichi/{v['id']}"))
    assert w['versione']==v['versione'] and w['bozza']==v['bozza'] and w['riga_id']==v['riga_id']
    assert w['riesame']['fatto'] is False and w['documenti']==[]
    with arc.motore.connect() as conn:
        assert conn.exec_driver_sql('PRAGMA foreign_key_check').all()==[]
        assert compare_metadata(MigrationContext.configure(conn),Base.metadata)==[]


def test_riesame_multiplo_atomico_conflitto_e_incarichi_aperti(admin,sede):
    v, a, _ = incarico(admin,sede)
    w, _, _ = incarico(admin,sede,a=a,comb='integrita')
    data={'esito':'C','incarichi':[{'id':v['id'],'versione':v['versione']},{'id':w['id'],'versione':0}]}
    assert admin.post('/api/dm/incarichi/riesame-in-blocco',data).status_code==409
    assert not ok(admin.get(f"/api/dm/incarichi/{v['id']}"))['riesame']['fatto']
    data['incarichi'][1]['versione']=w['versione']
    assert ok(admin.post('/api/dm/incarichi/riesame-in-blocco',data))['riesaminate']==2
    v=ok(admin.get(f"/api/dm/incarichi/{v['id']}"))
    assert v['stato']=='da_assegnare' and v['riesame']['esito']=='C'


def test_firma_comune_pdf_e_backup_ripristino_dm(admin,sede,app):
    from test_verbali import _firma
    from conftest import Sessione, PASSWORD_ADMIN
    from test_scheda_verbale_dm import PNG
    v, _, _ = registrata(admin,sede,firma=False)
    _firma(admin)   # firma DPR di VerbalizzAI: dalla 0.13.0 non entra nei verbali DM (firme distinte)
    r=admin.post(f"/api/dm/incarichi/{v['id']}/documenti/genera", {'versione': v['versione']})
    assert r.status_code==400 and 'firma DM' in r.json()['errore']       # 0.15: senza firma DM niente anteprima
    uid=v['profilo_tecnico']['utente_id']
    assert admin.c.post(f"/api/dm/tecnici/{uid}/firma", files={'file': ('firma.png', PNG, 'image/png')}, headers=admin.h).status_code==200
    v=generata(admin,ok(admin.get(f"/api/dm/incarichi/{v['id']}")))
    word_bytes=admin.get(doc(v,formato='docx')['url']).content
    with ZipFile(io.BytesIO(word_bytes)) as z:   # anteprima: spazio riservato, la firma non c'è ancora
        assert 'word/media/dm_spazio_firma.png' in z.namelist() and 'word/media/dm_firma.png' not in z.namelist()
    assert doc(v)['nome'].endswith(' - BOZZA.pdf')
    v=ok(effettua(admin,v))
    d=doc(v)
    assert d['origine']=='firmato' and d['definitivo']
    with ZipFile(io.BytesIO(admin.get(doc(v,formato='docx')['url']).content)) as z:   # emissione: firma DM al suo posto
        assert 'word/media/dm_firma.png' in z.namelist()
    before=admin.get(d['url']).content
    assert admin.get(d['url']+'?in_linea=true').headers['X-Frame-Options']=='SAMEORIGIN'
    b=ok(admin.post('/api/backup'))['nome']
    assert ok(admin.post(f'/api/backup/{b}/verifica'))['valido']
    assert admin.post('/api/backup/'+b+'/ripristina',{'conferma':'RIPRISTINA'}).status_code==200
    assert admin.get('/api/io').status_code==401
    assert admin.c.post('/api/accesso',json={'username':'federico','password':PASSWORD_ADMIN}).status_code==200
    nuova=Sessione(admin.c)
    assert nuova.get(d['url']).content==before
    assert ok(nuova.post('/api/backup/integrita'))['tutto_ok']


@pytest.mark.pdf_vero
@pytest.mark.parametrize('gruppo', ['GVR', 'SC', 'SP'])
def test_pdf_libreoffice_reale_modelli_dm(admin, sede, gruppo):
    from gestionale.core import pdf
    if not pdf.disponibile():
        pytest.skip('LibreOffice non installato')
    a = nuovo(admin, sede, gruppo, 'REALE-' + gruppo) if gruppo != 'GVR' else None
    v, _, _ = registrata(admin, sede, a=a)
    v = generata(admin, v)
    raw = admin.get(doc(v)['url']).content
    reader = PdfReader(io.BytesIO(raw))
    text = '\n'.join(p.extract_text() for p in reader.pages)
    assert 'Mario' in text and 'Rossi' in text and '{{' not in text
    assert ('Verifica di funzionamento' if gruppo == 'GVR' else 'Verifica periodica (successiva alla prima)') in text
    assert ok(effettua(admin, v))['stato'] == 'effettuata'
