"""Accesso, sessioni, protezioni, utenti, ruoli e permessi (D22, D24, D37)."""

from __future__ import annotations

from fastapi.testclient import TestClient

from conftest import PASSWORD_ADMIN, Sessione, nuovo_utente, ruolo_id


def test_primo_avvio_porta_alla_creazione_dell_amministratore(client):
    r = client.get("/", follow_redirects=False)
    assert r.status_code == 303 and r.headers["location"] == "/primo-avvio"
    r = client.post("/api/primo-avvio", json={"username": "federico", "nome": "Federico", "password": "corta"})
    assert r.status_code == 400 and "almeno 10" in r.json()["errore"]


def test_primo_avvio_si_fa_una_volta_sola(admin, client):
    r = client.post("/api/primo-avvio", json={"username": "altro", "nome": "Altro", "password": "un'altra frase lunga"})
    assert r.status_code == 400
    assert client.get("/primo-avvio", follow_redirects=False).headers["location"] == "/accesso"


def test_amministratore_ha_tutti_i_permessi(admin):
    io = admin.get("/api/io").json()
    assert io["amministratore"] and "sistema.utenti" in io["permessi"] and "fatture.genera" in io["permessi"]


def test_intestazioni_di_sicurezza(admin):
    r = admin.get("/utenti")
    assert "default-src 'self'" in r.headers["content-security-policy"]
    assert r.headers["x-frame-options"] == "DENY"
    assert 'style="' not in r.text  # nessuno stile in linea
    assert "<script>" not in r.text  # nessuno script in linea


def test_senza_codice_csrf_le_modifiche_sono_rifiutate(admin):
    r = admin.c.post("/api/backup")
    assert r.status_code == 403 and "codice di sicurezza" in r.json()["errore"]


def test_richiesta_da_altro_sito_rifiutata(admin):
    r = admin.c.post("/api/backup", headers=admin.h | {"Origin": "http://sito-malevolo.example"})
    assert r.status_code == 403


def test_senza_sessione_api_401_e_pagine_alla_login(client, admin):
    nuovo = TestClient(client.app, base_url="http://testserver")
    assert nuovo.get("/api/io").status_code == 401
    assert nuovo.get("/utenti", follow_redirects=False).headers["location"] == "/accesso"


def test_blocco_dopo_cinque_password_sbagliate_e_sblocco(admin, app):
    anna = nuovo_utente(admin, app, "anna", "segreteria")
    c = TestClient(app, base_url="http://testserver")
    for _ in range(5):
        assert c.post("/api/accesso", json={"username": "anna", "password": "sbagliata"}).status_code == 401
    r = c.post("/api/accesso", json={"username": "anna", "password": "password nuova personale"})
    assert r.status_code == 423 and "bloccato" in r.json()["errore"]
    id_anna = anna.get("/api/io").json()["id"]
    assert admin.post(f"/api/utenti/{id_anna}/sblocca").status_code == 200
    assert c.post("/api/accesso", json={"username": "anna", "password": "password nuova personale"}).status_code == 200


def test_utente_inesistente_stesso_messaggio(client, admin):
    r1 = client.post("/api/accesso", json={"username": "nessuno", "password": "x"}).json()["errore"]
    r2 = client.post("/api/accesso", json={"username": "federico", "password": "x"}).json()["errore"]
    assert r1 == r2


def test_password_provvisoria_obbliga_al_cambio(admin, app):
    r = admin.post("/api/utenti", {"username": "luca", "nome": "Luca", "ruolo_id": ruolo_id(admin, "tecnico")})
    provvisoria = r.json()["password_provvisoria"]
    c = TestClient(app, base_url="http://testserver")
    c.post("/api/accesso", json={"username": "luca", "password": provvisoria})
    luca = Sessione(c)
    assert luca.post("/api/griglie/utenti/dati", {}).status_code == 403
    assert c.get("/", follow_redirects=False).headers["location"] == "/profilo"
    assert luca.post("/api/io/password", {"attuale": provvisoria, "nuova": "luca"}).status_code == 400
    assert luca.post("/api/io/password", {"attuale": provvisoria, "nuova": "una nuova frase segreta"}).status_code == 200
    assert c.get("/", follow_redirects=False).status_code == 200


def test_il_server_controlla_i_permessi(admin, app):
    seg = nuovo_utente(admin, app, "anna", "segreteria")
    assert seg.get("/api/utenti/1").status_code == 403
    assert seg.post("/api/backup").status_code == 403
    assert seg.post("/api/griglie/registro/dati", {}).status_code == 403
    assert seg.get("/utenti").status_code == 200 and "Non hai il permesso" in seg.get("/utenti").text


def test_esportazione_solo_con_permesso(admin, app):
    rt = nuovo_utente(admin, app, "mario", "responsabile_tecnico")
    assert rt.post("/api/griglie/registro/dati", {}).status_code == 200  # il RT vede il registro
    r = rt.post("/api/griglie/registro/esporta", {"colonne": ["quando"]})
    assert r.status_code == 403


def test_ultimo_amministratore_non_si_disattiva_ne_declassa(admin):
    io = admin.get("/api/io").json()
    r = admin.post(f"/api/utenti/{io['id']}/disattiva", {})
    assert r.status_code == 400
    r = admin.put(f"/api/utenti/{io['id']}", {"nome": "Federico", "ruolo_id": ruolo_id(admin, "segreteria")})
    assert r.status_code == 400 and "ultimo amministratore" in r.json()["errore"]


def test_utente_disattivato_non_entra_e_perde_la_sessione(admin, app):
    anna = nuovo_utente(admin, app, "anna", "segreteria")
    id_anna = anna.get("/api/io").json()["id"]
    versione = admin.get(f"/api/utenti/{id_anna}").json()["versione"]
    assert admin.post(f"/api/utenti/{id_anna}/disattiva", {"versione": versione}).status_code == 200
    assert anna.get("/api/io").status_code == 401
    c = TestClient(app, base_url="http://testserver")
    assert c.post("/api/accesso", json={"username": "anna", "password": "password nuova personale"}).status_code == 403


def test_modifica_concorrente_segnalata(admin, app):
    nuovo_utente(admin, app, "anna", "segreteria")
    u = admin.get("/api/utenti/2").json()
    assert admin.put("/api/utenti/2", {"nome": "Anna B.", "email": "", "ruolo_id": u["ruolo_id"], "versione": u["versione"]}).status_code == 200
    r = admin.put("/api/utenti/2", {"nome": "Anna C.", "email": "", "ruolo_id": u["ruolo_id"], "versione": u["versione"]})
    assert r.status_code == 409 and "modificato da un altro utente" in r.json()["errore"]


def test_ruoli_creabili_con_copia_dei_permessi(admin):
    seg = ruolo_id(admin, "segreteria")
    r = admin.post("/api/ruoli", {"nome": "Ispettore esterno", "descrizione": "Collaboratore", "copia_da": seg})
    assert r.status_code == 200
    matrice = admin.get("/api/permessi/matrice").json()
    nuovo = next(x for x in matrice["ruoli"] if x["nome"] == "Ispettore esterno")
    originale = next(x for x in matrice["ruoli"] if x["id"] == seg)
    assert set(originale["permessi"]) <= set(nuovo["permessi"])
    assert admin.post("/api/ruoli", {"nome": "ispettore ESTERNO"}).status_code == 400  # nome già usato


def test_permessi_a_grana_fine_valgono_subito(admin, app):
    tec = nuovo_utente(admin, app, "luca", "tecnico")
    assert tec.post("/api/griglie/registro/dati", {}).status_code == 403
    id_tec = ruolo_id(admin, "tecnico")
    matrice = admin.get("/api/permessi/matrice").json()
    r_tec = next(x for x in matrice["ruoli"] if x["id"] == id_tec)
    r = admin.put("/api/permessi/ruolo", {"ruolo_id": id_tec, "permessi": r_tec["permessi"] + ["sistema.registro"], "versione": r_tec["versione"]})
    assert r.status_code == 200
    assert tec.post("/api/griglie/registro/dati", {}).status_code == 200
    registro = admin.post("/api/griglie/registro/dati", {"ricerca": "Permessi del ruolo"}).json()
    assert registro["totale"] == 1 and "Consultare il registro" in registro["righe"][0]["descrizione"]


def test_permessi_compresi(admin, app):
    """Chi può modificare i clienti può anche vederli (gestire comprende vedere)."""
    from gestionale.core.permessi import espandi
    assert "anagrafica.vedere" in espandi({"anagrafica.clienti"})


def test_ruolo_amministratore_intoccabile(admin):
    id_admin = ruolo_id(admin, "amministratore")
    assert admin.put("/api/permessi/ruolo", {"ruolo_id": id_admin, "permessi": []}).status_code == 400
    assert admin.put(f"/api/ruoli/{id_admin}", {"nome": "Capo"}).status_code == 400
    assert admin.delete(f"/api/ruoli/{id_admin}").status_code == 400


def test_ruolo_usato_non_si_elimina_ne_si_disattiva_con_utenti_attivi(admin, app):
    nuovo_utente(admin, app, "anna", "segreteria")
    seg = ruolo_id(admin, "segreteria")
    assert admin.delete(f"/api/ruoli/{seg}").status_code == 400
    assert admin.put(f"/api/ruoli/{seg}", {"nome": "Segreteria", "attivo": False}).status_code == 400
    nuovo = admin.post("/api/ruoli", {"nome": "Mai usato"}).json()
    assert admin.delete(f"/api/ruoli/{nuovo['id']}").status_code == 200


def test_permesso_sconosciuto_rifiutato(admin):
    seg = ruolo_id(admin, "segreteria")
    r = admin.put("/api/permessi/ruolo", {"ruolo_id": seg, "permessi": ["sistema.tutto"]})
    assert r.status_code == 400


def test_uscita_chiude_la_sessione(admin):
    assert admin.post("/api/uscita").status_code == 200
    assert admin.get("/api/io").status_code == 401


def test_password_amministratore_ok(client, admin):
    nuovo = TestClient(client.app, base_url="http://testserver")
    assert nuovo.post("/api/accesso", json={"username": "FEDERICO", "password": PASSWORD_ADMIN}).status_code == 200


def test_misura_del_testo_per_utente(admin):
    """0.3.1 (D57): ognuno sceglie Normale o Grande; vale su tutte le pagine."""
    assert admin.get("/api/io").json()["testo"] == "normale"
    assert 'data-testo="normale"' in admin.get("/").text
    assert admin.put("/api/io/testo", {"misura": "enorme"}).status_code == 400
    assert admin.put("/api/io/testo", {"misura": "grande"}).status_code == 200
    assert admin.get("/api/io").json()["testo"] == "grande"
    assert 'data-testo="grande"' in admin.get("/clienti").text
