"""La factory psycopg accetta comandi senza righe oltre a SELECT."""

from types import SimpleNamespace

from gestionale.moduli.verbali.postgresql import _righe


def test_factory_senza_descrizione_e_con_colonne():
    assert _righe(SimpleNamespace(description=None))([]) == {}
    r = _righe(SimpleNamespace(description=[SimpleNamespace(name="id")]))(["prova"])
    assert r["id"] == "prova" and r[0] == "prova"
