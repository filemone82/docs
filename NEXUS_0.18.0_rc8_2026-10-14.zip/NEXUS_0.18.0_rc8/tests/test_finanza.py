"""Regressioni economiche: XML XSD, immutabilità, crediti, incassi e concorrenza."""

from conftest import revisore

import hashlib

import pytest
from conftest import nuovo_utente
from test_anagrafica import PIVA, PIVA_2, crea_cliente
from test_verifiche import (
    accettato as accettato,  # noqa: PLC0414  (fixture pytest riutilizzata)
)
from test_verifiche import verbale_m02

from gestionale.moduli.finanza.xml_fattura import valida


@pytest.fixture
def economia(admin):
    c = crea_cliente(
        admin,
        ragione_sociale="Cliente collaudo",
        partita_iva=PIVA,
        codice_fiscale=PIVA,
        indirizzo="Via Prova 1",
        comune="Torino",
        cap="10100",
        provincia="TO",
    )
    so = next(
        x
        for x in admin.get("/api/finanza/valori").json()["societa"]
        if x["codice"] == "AD"
    )
    d = {
        "ragione_sociale": "AD collaudo S.r.l.",
        "partita_iva": PIVA_2,
        "codice_fiscale": PIVA_2,
        "indirizzo": "Via Sede 2",
        "cap": "10100",
        "comune": "Torino",
        "provincia": "TO",
        "nazione": "IT",
        "regime_fiscale": "RF01",
    }
    r = admin.put(f"/api/societa/{so['id']}", {"versione": so["versione"], "dati": d})
    assert r.status_code == 200, r.text
    return {"cliente": c, "societa": so}


def ok(r):
    assert r.status_code == 200, r.text
    return r.json()


def nuovo(admin, economia, tipo="TD01", **kw):
    return ok(
        admin.post(
            "/api/fatture",
            {
                "societa_id": economia["societa"]["id"],
                "cliente_id": economia["cliente"]["id"],
                "data": "2026-10-08",
                "tipo": tipo,
                **kw,
            },
        )
    )


def riga(admin, f, prezzo="100.00", **kw):
    return ok(
        admin.post(
            f"/api/fatture/{f['id']}/righe",
            {
                "versione": f["versione"],
                "descrizione": "Prestazione collaudo",
                "prezzo": prezzo,
                "quantita": "1",
                "aliquota": "22",
                **kw,
            },
        )
    )


def emetti(admin, f):
    return ok(admin.post(f"/api/fatture/{f['id']}/emetti", {"versione": f["versione"]}))


def test_xml_fotografia_numerazione_ed_emissione_idempotente(admin, economia):
    f = emetti(admin, riga(admin, nuovo(admin, economia)))
    assert (f["imponibile"], f["iva"], f["totale"], f["residuo"]) == (
        10000,
        2200,
        12200,
        12200,
    )
    raw = admin.get(f"/api/fatture/{f['id']}/xml/1").content
    valida(raw)
    assert f["esportazioni"][0]["sha256"] == hashlib.sha256(raw).hexdigest()
    assert b"<PrezzoTotale>100.00</PrezzoTotale>" in raw
    assert (
        admin.post(
            f"/api/fatture/{f['id']}/emetti", {"versione": f["versione"]}
        ).status_code
        == 400
    )
    assert (
        admin.put(
            f"/api/fatture/{f['id']}",
            {"versione": f["versione"], "opzioni": {"causale": "nuova"}},
        ).status_code
        == 400
    )
    c = economia["cliente"]
    ok(admin.put(f"/api/clienti/{c['id']}", {**c, "ragione_sociale": "Nome mutato"}))
    assert admin.get(f"/api/fatture/{f['id']}").json()["cliente"] == "Cliente collaudo"
    assert admin.get(f"/api/fatture/{f['id']}/xml/1").content == raw
    f2 = emetti(admin, riga(admin, nuovo(admin, economia, "TD02")))
    assert f2["codice"] == "2/2026/DPR"  # R140 (0.16): formato di Garda


def test_incasso_unico_due_fatture_storno_e_rollback(admin, economia):
    f1 = emetti(admin, riga(admin, nuovo(admin, economia)))
    f2 = emetti(admin, riga(admin, nuovo(admin, economia)))
    d = {
        "societa_id": economia["societa"]["id"],
        "cliente_id": economia["cliente"]["id"],
        "data": "2026-10-08",
        "importo": "150",
        "allocazioni": [
            {"fattura_id": f1["id"], "importo": "100"},
            {"fattura_id": f2["id"], "importo": "50"},
        ],
    }
    x = ok(admin.post("/api/incassi", d))
    assert x["importo"] == 15000 and x["non_associato"] == 0
    assert admin.get(f"/api/fatture/{f1['id']}").json()["residuo"] == 2200
    assert admin.get(f"/api/fatture/{f2['id']}").json()["residuo"] == 7200
    # Over-allocation rolls back removal of the valid old associations.
    r = admin.put(
        f"/api/incassi/{x['id']}/allocazioni",
        {
            "versione": x["versione"],
            "allocazioni": [
                {"fattura_id": f1["id"], "importo": "122"},
                {"fattura_id": f2["id"], "importo": "122"},
            ],
        },
    )
    assert r.status_code == 400
    assert admin.get(f"/api/fatture/{f1['id']}").json()["residuo"] == 2200
    ok(
        admin.post(
            f"/api/incassi/{x['id']}/storna",
            {"versione": x["versione"], "motivo": "Registrazione duplicata"},
        )
    )
    assert admin.get(f"/api/fatture/{f1['id']}").json()["residuo"] == 12200


def test_note_credito_parziali_senza_incassi_fittizi(admin, economia):
    f = emetti(admin, riga(admin, nuovo(admin, economia)))
    nc = nuovo(admin, economia, "TD04", originale_id=f["id"])
    nc = riga(admin, nc, "40", origine_credito_id=f["righe"][0]["id"])
    nc = emetti(admin, nc)
    assert nc["totale"] == 4880 and nc["codice"] == "1/2026/DPR-NC"
    raw = admin.get(f"/api/fatture/{nc['id']}/xml/1").content
    valida(raw)
    assert b"TD04" in raw and b"DatiFattureCollegate" in raw
    x = admin.get(f"/api/fatture/{f['id']}").json()
    assert x["residuo"] == 7320 and x["pagato"] == 0
    nc2 = nuovo(admin, economia, "TD04", originale_id=f["id"])
    assert (
        admin.post(
            f"/api/fatture/{nc2['id']}/righe",
            {
                "versione": nc2["versione"],
                "origine_credito_id": f["righe"][0]["id"],
                "prezzo": "61",
                "quantita": "1",
                "aliquota": "22",
            },
        ).status_code
        == 400
    )
    assert admin.get("/api/incassi").json() == []


def test_split_payment_ritenuta_scadenze(admin, economia):
    f = riga(
        admin,
        nuovo(admin, economia, opzioni={"ritenuta_percentuale": "4"}),
        "100",
        esigibilita="S",
    )
    assert f["totale"] == 12200 and f["dovuto"] == 9600
    assert (
        admin.put(
            f"/api/fatture/{f['id']}/scadenze",
            {
                "versione": f["versione"],
                "scadenze": [{"data": "2026-11-01", "importo": "50"}],
            },
        ).status_code
        == 200
    )
    f = admin.get(f"/api/fatture/{f['id']}").json()
    assert (
        admin.post(
            f"/api/fatture/{f['id']}/emetti", {"versione": f["versione"]}
        ).status_code
        == 400
    )
    f = ok(
        admin.put(
            f"/api/fatture/{f['id']}/scadenze",
            {
                "versione": f["versione"],
                "scadenze": [
                    {"data": "2026-11-01", "importo": "48"},
                    {"data": "2026-12-01", "importo": "48"},
                ],
            },
        )
    )
    f = emetti(admin, f)
    raw = admin.get(f"/api/fatture/{f['id']}/xml/1").content
    valida(raw)
    assert b"<ImportoRitenuta>4.00" in raw and b"<EsigibilitaIVA>S" in raw


def test_scarta_correggi_riemetti_conservando_tentativi(admin, economia):
    f = emetti(admin, riga(admin, nuovo(admin, economia)))
    e = f["esportazioni"][0]
    raw = admin.get(f"/api/fatture/{f['id']}/xml/1").content
    d = {
        "identificativo_origine": "ricevuta-collaudo-1",
        "esito": "scartata",
        "messaggio": "Codice destinatario",
    }
    f = ok(admin.post(f"/api/fatture/esportazioni/{e['id']}/esito", d))
    assert f["stato"] == "scartata"
    assert (
        ok(admin.post(f"/api/fatture/esportazioni/{e['id']}/esito", d))["versione"]
        == f["versione"]
    )
    f = ok(
        admin.post(
            f"/api/fatture/{f['id']}/correggi-scarto", {"versione": f["versione"]}
        )
    )
    f = ok(
        admin.put(
            f"/api/fatture/{f['id']}",
            {"versione": f["versione"], "opzioni": {"causale": "Secondo tentativo"}},
        )
    )
    f = emetti(admin, f)
    assert f["codice"] == "1/2026/DPR" and len(f["esportazioni"]) == 2
    assert admin.get(f"/api/fatture/{f['id']}/xml/1").content == raw
    assert admin.get(f"/api/fatture/{f['id']}/xml/2").content != raw
    assert (
        admin.post(
            f"/api/fatture/esportazioni/{e['id']}/esito",
            {"identificativo_origine": "vecchia", "esito": "consegnata"},
        ).status_code
        == 409
    )


def test_permessi_csrf_versione_e_input_non_validi(admin, app, economia):
    f = nuovo(admin, economia)
    tecnico = nuovo_utente(admin, app, "tecnico_economia", "tecnico")
    assert tecnico.get("/api/fatture").status_code == 403
    assert tecnico.post("/api/incassi", {}).status_code == 403
    assert admin.c.post("/api/fatture", json={}).status_code == 403
    assert (
        admin.put(
            f"/api/fatture/{f['id']}", {"versione": f["versione"] - 1}
        ).status_code
        == 409
    )
    assert admin.put(f"/api/fatture/{f['id']}", {}).status_code == 400
    assert (
        admin.post("/api/fatture", {"societa_id": "NO", "cliente_id": 1}).status_code
        == 400
    )
    for prezzo in ("NaN", "Infinity", "-2"):
        assert (
            admin.post(
                f"/api/fatture/{f['id']}/righe",
                {"versione": f["versione"], "descrizione": "x", "prezzo": prezzo},
            ).status_code
            == 400
        )


@pytest.mark.pdf_vero
def test_pdf_fattura_reale(admin, economia):
    f = emetti(admin, riga(admin, nuovo(admin, economia)))
    r = admin.get(f"/api/fatture/{f['id']}/pdf")
    assert r.status_code == 200, r.text
    assert r.content.startswith(b"%PDF") and len(r.content) > 5000
    import shutil
    import subprocess
    import tempfile
    from pathlib import Path

    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "fattura.pdf"
        p.write_bytes(r.content)
        if shutil.which("pdftotext"):
            txt = subprocess.check_output(["pdftotext", str(p), "-"]).decode()
            assert "Cliente collaudo" in txt and "122,00" in txt and "Fattura Nr." in txt  # R140 (0.16): come Garda


def assegna_registra(admin, v):
    v = ok(admin.get(f"/api/verifiche/{v['id']}"))
    who = admin.get("/api/verifiche/valori").json()["verificatori"][0]["id"]
    v = ok(
        admin.post(
            f"/api/verifiche/{v['id']}/assegna",
            {"versione": v["versione"], "verificatore_id": who},
        )
    )
    return ok(
        admin.post(
            f"/api/verifiche/{v['id']}/registra",
            {"versione": v["versione"], "data_esecuzione": "2026-10-08"},
        )
    )


def test_riesame_negativo_riemissione_storico_e_fatturazione(
    admin, economia, accettato
):
    v = assegna_registra(admin, accettato["preventivo"]["verifiche"][0])

    def upload(v):
        return ok(
            admin.c.post(
                f"/api/verifiche/{v['id']}/verbale",
                files={
                    "word": ("v.docx", verbale_m02(v["codice_verbale"], "08/10/2026"))
                },
                data={"versione": v["versione"]},
                headers=admin.h,
            )
        )

    v = upload(v)
    f = nuovo(
        admin, economia
    )  # Intestatario terzo: non modifica il committente della prestazione.
    data = {"versione": f["versione"], "riga_preventivo_id": v["riga_id"]}
    assert admin.post(f"/api/fatture/{f['id']}/righe", data).status_code == 400
    v = ok(
        revisore(admin).post(
            f"/api/verifiche/{v['id']}/riesame",
            {
                "versione": v["versione"],
                "esito": "non_conforme",
                "note": "Ripetere la misura",
            },
        )
    )
    assert v["stato"] == "registrata" and len(v["storico_riesami"]) == 1
    v = upload(v)
    v = ok(
        revisore(admin).post(
            f"/api/verifiche/{v['id']}/riesame",
            {"versione": v["versione"], "esito": "conforme"},
        )
    )
    assert (
        len(v["storico_riesami"]) == 2
        and v["storico_riesami"][0]["note"] == "Ripetere la misura"
    )
    f = ok(admin.post(f"/api/fatture/{f['id']}/righe", data))
    f = emetti(admin, f)
    assert f["righe"][0]["riferimenti"]["committente_id"] != f["cliente_id"]
    assert f["righe"][0]["riferimenti"]["verbale"] == v["codice_verbale"]


def test_sospensione_indipendenza_stesso_numero(admin, accettato):
    v = assegna_registra(admin, accettato["preventivo"]["verifiche"][0])
    code = v["codice_verbale"]
    assert v["indipendenza"] is True
    v = ok(
        admin.post(
            f"/api/verifiche/{v['id']}/sospendi",
            {"versione": v["versione"], "motivo": "Impianto non disponibile"},
        )
    )
    assert v["stato"] == "sospesa"
    v = ok(
        admin.post(f"/api/verifiche/{v['id']}/riprendi", {"versione": v["versione"]})
    )
    assert v["stato"] == "registrata" and v["codice_verbale"] == code
    # R119: dopo la registrazione l'indipendenza non si cambia più (si riassegna)
    r = admin.post(f"/api/verifiche/{v['id']}/indipendenza", {"versione": v["versione"], "indipendenza": False})
    assert r.status_code == 400 and "prima della registrazione" in r.text


def test_indipendenza_no_blocca_programmazione_e_registrazione_dpr(admin, app, accettato):
    """R110 + R119 (11/10/2026): preimpostata su «Sì»; la dichiara SOLO il verificatore assegnato; con «No» la verifica
    torna al responsabile tecnico da riassegnare (senza verificatore e senza data prevista)."""
    from conftest import nuovo_utente

    v = ok(admin.get(f"/api/verifiche/{accettato['preventivo']['verifiche'][0]['id']}"))
    io = ok(admin.get("/api/io"))["id"]
    rt = nuovo_utente(admin, app, "rt_indip", "responsabile_tecnico")
    v = ok(admin.post(f"/api/verifiche/{v['id']}/assegna", {"versione": v["versione"], "verificatore_id": io}))
    assert v["indipendenza"] is True
    v = ok(admin.post(f"/api/verifiche/{v['id']}/programma", {"versione": v["versione"], "data_programmata": "2026-10-20"}))
    r = rt.post(f"/api/verifiche/{v['id']}/indipendenza", {"versione": v["versione"], "indipendenza": False})
    assert r.status_code == 403  # il RT non dichiara per il verificatore assegnato
    v = ok(admin.post(f"/api/verifiche/{v['id']}/indipendenza", {"versione": v["versione"], "indipendenza": False}))
    assert v["stato"] == "da_assegnare" and v["verificatore_id"] is None and v["data_programmata"] is None and v["indipendenza"]
    assert "NON essere indipendente" in v["indipendenza_esclusa"]
    r = admin.post(f"/api/verifiche/{v['id']}/registra", {"versione": v["versione"], "data_esecuzione": "2026-10-20"})
    assert r.status_code == 400
    rt_id = ok(rt.get("/api/io"))["id"]
    v = ok(admin.post(f"/api/verifiche/{v['id']}/assegna", {"versione": v["versione"], "verificatore_id": rt_id}))
    assert v["stato"] == "assegnata" and v["indipendenza"] is True
    v = ok(rt.post(f"/api/verifiche/{v['id']}/indipendenza", {"versione": v["versione"], "indipendenza": True}))  # RT assegnatario: dichiara lui
    v = ok(rt.post(f"/api/verifiche/{v['id']}/programma", {"versione": v["versione"], "data_programmata": "2026-10-20"}))
    v = ok(admin.post(f"/api/verifiche/{v['id']}/registra", {"versione": v["versione"], "data_esecuzione": "2026-10-20"}))
    assert v["stato"] == "registrata"


def test_aggiornamento_0008_preserva_documenti_e_riesame(admin, accettato, cfg, tmp_path):
    """Archivio nel vecchio schema, popolato e con PDF referenziato: aggiornamento senza perdere legami."""
    import shutil
    import sqlite3

    from alembic import command
    from sqlalchemy import text

    from gestionale.app import prepara_archivio
    from gestionale.core import migrazioni
    from gestionale.core.config import Config

    v = assegna_registra(admin, accettato["preventivo"]["verifiche"][0])
    v = ok(admin.c.post(
        f"/api/verifiche/{v['id']}/verbale",
        files={"word": ("legacy.docx", verbale_m02(v["codice_verbale"], "08/10/2026"))},
        data={"versione": v["versione"]}, headers=admin.h,
    ))
    v = ok(revisore(admin).post(f"/api/verifiche/{v['id']}/riesame", {
        "versione": v["versione"], "esito": "conforme", "note": "Riesame precedente all'aggiornamento",
    }))
    legacy = Config(cartella_dati=tmp_path / "archivio_0008", backup_automatico=False, iterazioni_password=1000)
    legacy.prepara_cartelle()
    command.upgrade(migrazioni.config_alembic(f"sqlite:///{legacy.percorso_database}"), "0008")
    # Si copiano soltanto tabelle e colonne esistenti nello schema 0008; i nuovi dati non vengono inventati.
    with sqlite3.connect(cfg.percorso_database) as src, sqlite3.connect(legacy.percorso_database) as dst:
        tables = [r[0] for r in dst.execute("SELECT name FROM sqlite_master WHERE type='table'")
                  if r[0] != "alembic_version" and not r[0].startswith("sqlite_")]
        for table in tables:
            columns = [r[1] for r in dst.execute(f'PRAGMA table_info("{table}")')]
            names = ",".join(f'"{c}"' for c in columns)
            rows = src.execute(f'SELECT {names} FROM "{table}"').fetchall()
            dst.executemany(f'INSERT INTO "{table}" ({names}) VALUES ({",".join("?" for _ in columns)})', rows)
        assert dst.execute("PRAGMA foreign_key_check").fetchall() == []
        linked = dst.execute("SELECT id, verifica_id, documento_id FROM verifiche_documenti ORDER BY id").fetchall()
    shutil.copytree(cfg.cartella_documenti, legacy.cartella_documenti, dirs_exist_ok=True)
    arc = prepara_archivio(legacy)
    try:
        with arc.motore.connect() as conn:
            assert conn.exec_driver_sql("PRAGMA foreign_keys").scalar() == 1
            assert conn.exec_driver_sql("PRAGMA foreign_key_check").all() == []
            assert [tuple(r) for r in conn.execute(text("SELECT id, verifica_id, documento_id FROM verifiche_documenti ORDER BY id"))] == linked
            history = conn.execute(text("SELECT verifica_id, documento_id, esito, note FROM verifiche_riesami")).one()
            assert history.verifica_id == v["id"] and history.esito == "conforme"
            assert history.documento_id is not None and history.note == "Riesame precedente all'aggiornamento"
            assert conn.execute(text("SELECT evidenza_accettazione FROM preventivi LIMIT 1")).scalar() == ""
        assert any("pre_aggiornamento" in p.name for p in legacy.cartella_backup.iterdir())
    finally:
        arc.chiudi()


def test_senza_conferma_scritta_non_si_accetta(admin):
    from conftest import segna_inviato
    from test_anagrafica import crea_impianto, crea_sede

    c = crea_cliente(admin)
    s = crea_sede(admin, c["id"])
    i = crea_impianto(admin, s["id"])
    p = ok(admin.post("/api/preventivi", {"impianti": [i["id"]]}))
    d = {
        "versione": p["versione"],
        "righe": [p["righe"][0]["id"]],
        "stato": "accettata",
    }
    assert admin.post(f"/api/preventivi/{p['id']}/righe/stato", d).status_code == 400
    p = segna_inviato(admin, p)
    d["versione"] = p["versione"]
    assert admin.post(f"/api/preventivi/{p['id']}/righe/stato", d).status_code == 400
    p = ok(
        admin.post(
            f"/api/preventivi/{p['id']}/righe/stato",
            {**d, "evidenza_accettazione": "Email del 08/10/2026, cartella cliente"},
        )
    )
    assert p["evidenza_accettazione"].startswith("Email")


def test_vs_non_sposta_scadenza_e_non_copia_risultati(admin, app, accettato):
    from datetime import date

    from gestionale.moduli.anagrafica.modelli import Impianto
    from gestionale.moduli.verifiche.modelli import Verifica

    v = assegna_registra(admin, accettato["preventivo"]["verifiche"][0])
    arc = app.state.archivio
    with arc.scrittura() as s:
        vv = s.get(Verifica, v["id"])
        vv.tipo_verifica = "straordinaria"
        vv.codice_verbale = vv.codice_verbale.replace("VP/", "VS/")
        x = s.get(Impianto, vv.impianto_id)
        x.ultima_verifica_data = date(2025, 1, 1)
        x.ultima_verifica_numero = "VP/001/25"
        x.prossima_verifica = date(2026, 12, 31)
    v = admin.get(f"/api/verifiche/{v['id']}").json()
    v = ok(
        admin.c.post(
            f"/api/verifiche/{v['id']}/verbale",
            files={"word": ("vs.docx", verbale_m02(v["codice_verbale"], "08/10/2026"))},
            data={"versione": v["versione"]},
            headers=admin.h,
        )
    )
    x = admin.get(f"/api/impianti/{v['impianto_id']}").json()
    assert (
        v["prossima_verifica"] is None
        and x["prossima_verifica"] == "2026-12-31"
        and x["ultima_verifica_numero"] == "VP/001/25"
    )
    assert "stato_tecnico" in x["caratteristiche"]


def test_cliente_mutato_non_riscrive_preventivo_emesso(admin, accettato, app):
    from gestionale.moduli.preventivi.modelli import Preventivo
    from gestionale.moduli.preventivi.servizio import valori_documento

    p = accettato["preventivo"]
    c = admin.get(f"/api/clienti/{p['cliente_id']}").json()
    with app.state.archivio.lettura() as s:
        prima = valori_documento(s, s.get(Preventivo, p["id"]))
    ok(
        admin.put(
            f"/api/clienti/{c['id']}", {**c, "ragione_sociale": "Nome successivo"}
        )
    )
    with app.state.archivio.lettura() as s:
        dopo = valori_documento(s, s.get(Preventivo, p["id"]))
    assert dopo == prima


def test_migrazione_0015_popolata_e_ritorno_bloccato_con_dati_nuovi(admin, economia, app):
    """A6 (documento 18): 0014 → 0015 con fatture già presenti; ritorno a 0014 ammesso senza dati nuovi,
    impedito (e atomico: lo schema resta 0015) quando ci sono righe «prestazione intera»."""
    from alembic import command
    from alembic.autogenerate import compare_metadata
    from alembic.runtime.migration import MigrationContext

    from gestionale.core import migrazioni
    from gestionale.modelli import Base

    f = emetti(admin, riga(admin, nuovo(admin, economia)))
    arc = app.state.archivio
    cfg = migrazioni.config_alembic("sqlite:///" + str(arc.cfg.percorso_database))
    command.downgrade(cfg, "0014")
    assert migrazioni.revisione_database(arc.motore) == "0014"
    with arc.motore.connect() as conn:
        assert conn.exec_driver_sql("SELECT COUNT(*) FROM fatture_righe WHERE fattura_id=?", (f["id"],)).scalar() == 1
    migrazioni.aggiorna(arc.motore)
    assert migrazioni.revisione_database(arc.motore) == migrazioni.revisione_programma()
    dopo = ok(admin.get(f"/api/fatture/{f['id']}"))
    assert dopo["codice"] == f["codice"] and dopo["righe"] == f["righe"] and dopo["stato"] == f["stato"]
    with arc.motore.connect() as conn:
        assert conn.exec_driver_sql("PRAGMA foreign_key_check").all() == []
        assert compare_metadata(MigrationContext.configure(conn), Base.metadata) == []
    with arc.motore.begin() as conn:
        conn.exec_driver_sql("UPDATE fatture_righe SET prestazione_intera=1 WHERE fattura_id=?", (f["id"],))
    with pytest.raises(RuntimeError, match="0014 impedito"):
        command.downgrade(cfg, "0014")
    assert migrazioni.revisione_database(arc.motore) == "0015"  # la 0016 torna indietro, la 0015 si ferma intera
    with arc.motore.connect() as conn:
        assert conn.exec_driver_sql("SELECT prestazione_intera FROM fatture_righe WHERE fattura_id=?", (f["id"],)).scalar() == 1
