"""Regole comuni B1: dati dichiarati, cataloghi e regressione dei collegamenti DPR."""

import json
import sqlite3
from pathlib import Path
import pytest
from sqlalchemy import select
from conftest import nuovo_utente
from test_anagrafica import crea_cliente, crea_sede, crea_impianto
from test_verifiche import accettato  # noqa: F401 (fixture di un'offerta DPR accettata)


def ok(r):
    assert r.status_code == 200, r.text
    return r.json()


@pytest.fixture
def sede(admin):
    return crea_sede(admin, crea_cliente(admin)["id"])


def nuovo(admin, sede, gruppo="GVR", matricola="PROVA-001", **extra):
    defaults = {}
    if gruppo != "PSV":
        catalogo = ok(admin.get("/api/beni/cataloghi"))
        compat = [x for x in catalogo["compatibilita"] if x["gruppo"] == gruppo]
        tipo = extra.get("tipo_attr_id", next(x["id"] for x in catalogo["tipi_attrezzature"] if x["gruppo"] == gruppo))
        famiglia = next(x["famiglia_gvr_id"] for x in catalogo["tipi_attrezzature"] if x["id"] == tipo)
        id_spec = next((x["id_spec_id"] for x in compat if (x["famiglia_gvr_id"] == famiglia if gruppo == "GVR" else x["tipo_attr_id"] == tipo)), None)
        defaults = {"tipo_attr_id": tipo, "id_spec_id": id_spec}
        extra["dati_dm"] = {"esente_verifiche": "F", "tipo_prox_verifica": "V2", **extra.get("dati_dm", {})}
        if "date_iniziali" not in extra:  # R142 (0.16): la prossima verifica è obbligatoria alla registrazione
            fam = extra.get("tipo_attr_gvr_id", famiglia)
            comp = ["scsp"] if gruppo != "GVR" else ["funzionamento", "integrita"] + (["interna"] if fam in (2, 3) else [])
            extra["date_iniziali"] = {c: {"data_prossima": "2027-06-30"} for c in comp}
        elif extra["date_iniziali"] is None:
            del extra["date_iniziali"]
    return ok(
        admin.post(
            "/api/beni",
            {
                "gruppo": gruppo,
                "sede_id": sede["id"],
                "matr_informale": matricola,
                "denominazione": "Bene di collaudo",
                **defaults,
                **({"anno_matricola": "2020", "cod_att_matricola": "A", "num_matricola": "00001", "prov_immatr": "TO"} if gruppo != "PSV" else {}),
                **extra,
            },
        )
    )


def modifica(admin, a, **extra):
    return ok(admin.put(f"/api/beni/{a['id']}", {"versione": a["versione"], **extra}))


def scad(admin, a, comp, **extra):
    return ok(
        admin.put(
            f"/api/beni/{a['id']}/scadenze",
            {"versione": a["versione"], "componente": comp, **extra},
        )
    )


def test_cataloghi_preservano_ogni_riga_e_attributo_garda(admin, app):
    from gestionale.moduli.beni.modelli import (
        FamigliaGvr,
        TipoAttrezzatura,
        IdSpecifica,
        CompatibilitaClassificazione,
    )

    p = (
        Path(__file__).parents[1]
        / "gestionale/migrazioni/versions/0011_cataloghi_garda.json"
    )
    raw = json.loads(p.read_text(encoding="utf-8"))
    d = ok(admin.get("/api/beni/cataloghi"))
    assert [
        len(d[x])
        for x in ["famiglie_gvr", "tipi_attrezzature", "id_specifiche", "compatibilita"]
    ] == [6, 31, 72, 162]
    with app.state.archivio.lettura() as s:
        for cls, t in [
            (FamigliaGvr, "tipi_attrezzature_gvr"),
            (TipoAttrezzatura, "tipi_attrezzature"),
            (IdSpecifica, "id_specifiche"),
            (CompatibilitaClassificazione, "tipi_attr_id_specifiche"),
        ]:
            assert [
                json.loads(x.origine_json)
                for x in s.scalars(select(cls).order_by(cls.id))
            ] == raw[t]


def test_classificazione_manuale_e_id_specifica_compatibili(admin, sede):
    c = ok(admin.get("/api/beni/cataloghi"))
    old = next(
        x for x in c["compatibilita"] if x["gruppo"] == "SC" and x["tipo_attr_id"] == 2
    )
    a = nuovo(
        admin,
        sede,
        "SC",
        tipo_attr_id=2,
        id_spec_id=old["id_spec_id"],
        anno_costruzione=2015,
    )
    # Nessun cambio automatico basato sull'orologio: la categoria ricevuta rimane.
    assert a["tipo_attr_id"] == 2 and a["anno_costruzione"] == 2015
    assert admin.put(f"/api/beni/{a['id']}", {"versione": a["versione"], "tipo_attr_id": 1, "id_spec_id": None}).status_code == 400
    compat_nuova = next(x for x in c["compatibilita"] if x["gruppo"] == "SC" and x["tipo_attr_id"] == 1)
    a = modifica(admin, a, tipo_attr_id=1, id_spec_id=compat_nuova["id_spec_id"])
    assert a["tipo_attr_id"] == 1
    assert (
        admin.put(
            f"/api/beni/{a['id']}", {"versione": a["versione"], "tipo_attr_id": 12}
        ).status_code
        == 400
    )
    assert (
        admin.put(
            f"/api/beni/{a['id']}", {"versione": a["versione"], "id_spec_id": 1}
        ).status_code
        == 400
    )
    assert ok(admin.get(f"/api/beni/{a['id']}"))["versione"] == a["versione"]
    assert len(ok(admin.get(f"/api/storico/asset/{a['id']}"))) == 2


def test_identita_per_sede_e_cancellazione_sede_protetta(admin, sede):
    a = nuovo(admin, sede, "SC")
    assert (
        admin.post(
            "/api/beni",
            {
                "gruppo": "SP",
                "sede_id": sede["id"],
                "matr_informale": a["matr_informale"],
            },
        ).status_code
        == 400
    )
    # Accessori hanno un proprio spazio di matricole, come le tabelle Garda separate.
    nuovo(admin, sede, "PSV", a["matr_informale"])
    seconda = crea_sede(admin, sede["cliente_id"], denominazione="Seconda sede")
    nuovo(admin, seconda, "SC", a["matr_informale"])
    assert admin.delete(f"/api/sedi/{sede['id']}").status_code == 400


def test_tubazione_senza_interna_e_validazione_classificazione(admin, sede):
    c = ok(admin.get("/api/beni/cataloghi"))
    t = next(x for x in c["tipi_attrezzature"] if x["famiglia_gvr_id"] == 4)
    a = nuovo(admin, sede, tipo_attr_gvr_id=4, tipo_attr_id=t["id"])
    assert "interna" not in a["componenti"]
    assert (
        admin.put(
            f"/api/beni/{a['id']}/scadenze",
            {
                "versione": a["versione"],
                "componente": "interna",
                "data_prossima": "2030-01-01",
            },
        ).status_code
        == 400
    )
    assert (
        admin.put(
            f"/api/beni/{a['id']}", {"versione": a["versione"], "tipo_attr_gvr_id": 1}
        ).status_code
        == 400
    )
    # DM-07: la visita interna è solo dei generatori (famiglie a2/a3, tipi Garda 24/25); un recipiente non la ha.
    r = nuovo(admin, sede, matricola="REC", tipo_attr_gvr_id=1)
    assert "interna" not in r["componenti"]
    assert admin.put(f"/api/beni/{r['id']}/scadenze", {"versione": r["versione"], "componente": "interna",
                                                       "data_prossima": "2030-01-01"}).status_code == 400
    b = nuovo(admin, sede, matricola="GV", tipo_attr_id=24, tipo_attr_gvr_id=2)
    assert "interna" in b["componenti"]
    b = scad(admin, b, "interna", data_prossima="2030-01-01")
    assert (
        admin.put(
            f"/api/beni/{b['id']}", {"versione": b["versione"], "tipo_attr_gvr_id": 4}
        ).status_code
        == 400
    )
    assert ok(admin.get(f"/api/beni/{b['id']}"))["tipo_attr_gvr_id"] == 2


def test_date_iniziali_senza_verbale_e_correzione_tracciata(admin, sede, app):
    a = nuovo(admin, sede)
    a = scad(
        admin,
        a,
        "cnd",
        data_ultima="2026-09-30",
        data_prossima="2036-09-29",
        numero_report="CND/001/26",
        nota="Da report esistente",
    )
    assert (
        a["scadenze"][0]["fonte"] == "dichiarata"
        and a["scadenze"][0]["numero_report"] == "CND/001/26"
    )
    with app.state.archivio.motore.connect() as c:
        assert c.exec_driver_sql("select count(*) from verifiche").scalar() == 0
    a = scad(admin, a, "cnd", numero_report="CND/002/26")
    assert a["scadenze"][0]["data_prossima"] == "2036-09-29"
    x = ok(admin.get("/api/beni/scadenze?componente=cnd"))
    assert x["totale"] == 1 and x["righe"][0]["numero_report"] == "CND/002/26"
    # La rimozione di dati dichiarati resta auditabile.
    a = ok(
        admin.c.request(
            "DELETE",
            f"/api/beni/{a['id']}/scadenze/cnd",
            json={"versione": a["versione"]},
            headers=admin.h,
        )
    )
    assert [x["componente"] for x in a["scadenze"]] == ["funzionamento", "integrita"]  # R142: quelle della registrazione
    assert len(ok(admin.get(f"/api/storico/asset/{a['id']}"))) == 4


def test_camere_volume_esclude_dn_e_aggiornamento_non_duplica(admin, sede):
    a = nuovo(admin, sede)
    for nome, u, v in [
        ("camera 1", "L", "12,3"),
        ("camera 2", "L", "7.1"),
        ("tubazione", "DN", "150"),
    ]:
        a = ok(
            admin.post(
                f"/api/beni/{a['id']}/camere",
                {
                    "versione": a["versione"],
                    "identificazione": nome,
                    "unita": u,
                    "valore": v,
                },
            )
        )
    assert a["volume_totale_litri"] == "19.4"
    c = a["camere"][0]
    a = ok(
        admin.put(
            f"/api/beni/{a['id']}/camere/{c['id']}",
            {
                "versione": a["versione"],
                "identificazione": c["identificazione"],
                "unita": "L",
                "valore": "13,5",
            },
        )
    )
    assert len(a["camere"]) == 3 and a["volume_totale_litri"] == "20.6"
    assert (
        admin.post(
            f"/api/beni/{a['id']}/camere",
            {
                "versione": a["versione"],
                "identificazione": " CAMERA 1 ",
                "unita": "L",
                "valore": "1",
            },
        ).status_code
        == 400
    )
    for v in ["-1", "NaN", "Infinity", "0.11"]:
        assert (
            admin.post(
                f"/api/beni/{a['id']}/camere",
                {
                    "versione": a["versione"],
                    "identificazione": "non valida",
                    "unita": "L",
                    "valore": v,
                },
            ).status_code
            == 400
        )
    a = ok(admin.post(f"/api/beni/{a['id']}/camere", {
        "versione": a["versione"], "identificazione": "Camera 3",
        "unita": "L", "valore": "1.000",
    }))
    assert a["volume_totale_litri"] == "1020.6"
    b = nuovo(admin, sede, matricola="ALTRO")
    assert (
        admin.put(
            f"/api/beni/{b['id']}/camere/{c['id']}",
            {
                "versione": b["versione"],
                "identificazione": "X",
                "unita": "L",
                "valore": "1",
            },
        ).status_code
        == 404
    )


def test_valvola_condivisa_taratura_aggiornata_una_volta(admin, sede):
    a = nuovo(admin, sede)
    b = nuovo(admin, sede, matricola="B")
    p = nuovo(admin, sede, "PSV", "VALVOLA-1")
    p = scad(
        admin,
        p,
        "taratura",
        data_ultima="2026-09-28",
        data_prossima="2028-09-27",
        numero_report="TAR/1",
    )
    a = ok(
        admin.post(
            f"/api/beni/{a['id']}/accessori",
            {"versione": a["versione"], "accessorio_id": p["id"]},
        )
    )
    b = ok(
        admin.post(
            f"/api/beni/{b['id']}/accessori",
            {"versione": b["versione"], "accessorio_id": p["id"]},
        )
    )
    assert (
        a["taratura_accessori"]
        == b["taratura_accessori"]
        == {"data_ultima": "2026-09-28", "data_prossima": "2028-09-27"}
    )
    assert (
        admin.post(
            f"/api/beni/{a['id']}/accessori",
            {"versione": a["versione"], "accessorio_id": p["id"]},
        ).status_code
        == 400
    )
    p = scad(admin, p, "taratura", data_prossima="2029-09-27")
    for x in (a, b):
        assert (
            ok(admin.get(f"/api/beni/{x['id']}"))["taratura_accessori"]["data_prossima"]
            == "2029-09-27"
        )
    p = ok(
        admin.post(
            f"/api/beni/{p['id']}/dismesso",
            {"versione": p["versione"], "dismesso": True, "motivo": "Sostituita"},
        )
    )
    assert (
        ok(admin.get(f"/api/beni/{a['id']}"))["taratura_accessori"]["data_prossima"]
        is None
    )
    assert ok(admin.get("/api/beni/scadenze?gruppo=PSV"))["totale"] == 0


def test_concorrenza_permessi_e_pagine(admin, sede, app):
    a = nuovo(admin, sede)
    a2 = modifica(admin, a, note="Nuova nota")
    assert (
        admin.put(
            f"/api/beni/{a['id']}", {"versione": a["versione"], "note": "Vecchia nota"}
        ).status_code
        == 409
    )
    assert (
        admin.put(f"/api/beni/{a['id']}", {"note": "Senza versione"}).status_code == 400
    )
    assert (
        admin.put(
            f"/api/beni/{a['id']}/scadenze",
            {"versione": a["versione"], "componente": "cnd"},
        ).status_code
        == 409
    )
    tecnico = nuovo_utente(admin, app, "tecnico_b1", "tecnico")
    assert tecnico.get("/api/beni/cataloghi").status_code == 200
    assert (
        tecnico.put(
            f"/api/beni/{a['id']}", {"versione": a2["versione"], "note": "X"}
        ).status_code
        == 403
    )
    assert tecnico.get("/api/beni/scadenze").status_code == 403
    assert (
        admin.get("/beni").status_code == 200 and "beni.js" in admin.get("/beni").text
    )
    assert admin.get("/scadenze-tecniche").status_code == 200
    assert (
        admin.c.put(
            f"/api/beni/{a['id']}", json={"versione": a2["versione"], "note": "X"}
        ).status_code
        == 403
    )


def test_ponte_dpr_aggiornamento_e_cancellazione_atomici(admin, sede, app):
    i = crea_impianto(admin, sede["id"], ultima_verifica_data="2024-12-10")
    a = ok(admin.get(f"/api/beni/{i['asset_id']}"))
    assert a["gruppo"] == "DPR" and a["scadenze"][0]["data_prossima"] == "2026-12-09"
    assert a["origini"] == [
        {"sistema": "gestionale_dpr", "tabella": "impianti", "id_origine": str(i["id"])}
    ]
    i = ok(admin.put(f"/api/impianti/{i['id']}", {**i, "denominazione": "Nuovo nome"}))
    assert ok(admin.get(f"/api/beni/{i['asset_id']}"))["denominazione"] == "Nuovo nome"
    assert (
        admin.put(
            f"/api/beni/{i['asset_id']}",
            {"versione": i["versione"], "denominazione": "Bypass"},
        ).status_code
        == 400
    )
    j = crea_impianto(admin, sede["id"])
    assert admin.delete(f"/api/impianti/{j['id']}").status_code == 200
    assert admin.get(f"/api/beni/{j['asset_id']}").status_code == 404
    with app.state.archivio.motore.connect() as c:
        assert c.exec_driver_sql("PRAGMA foreign_key_check").all() == []


def test_ponte_intercetta_anche_scritture_orm_e_rollback(admin, sede, app):
    from gestionale.moduli.anagrafica.modelli import Impianto

    arc = app.state.archivio
    with arc.scrittura() as s:
        i = Impianto(
            sede_id=sede["id"], tipologia="terra_bt", potenza_kw=50, periodicita_anni=2
        )
        s.add(i)
        s.flush()
        iid, aid = i.id, i.asset_id
    with pytest.raises(RuntimeError):
        with arc.scrittura() as s:
            i = s.get(Impianto, iid)
            i.denominazione = "Da annullare"
            s.flush()
            raise RuntimeError("Rollback intenzionale")
    assert ok(admin.get(f"/api/beni/{aid}"))["denominazione"] == ""
    with arc.scrittura() as s:
        i = s.get(Impianto, iid)
        i.prossima_verifica = __import__("datetime").date(2030, 1, 1)
    assert (
        ok(admin.get(f"/api/beni/{aid}"))["scadenze"][0]["data_prossima"]
        == "2030-01-01"
    )


def test_migrazione_0010_preserva_offerta_verifiche_e_id(
    admin, accettato, cfg, tmp_path  # noqa: F811
):
    from alembic import command
    from gestionale.app import prepara_archivio
    from gestionale.core import migrazioni
    from gestionale.core.config import Config

    legacy = Config(
        cartella_dati=tmp_path / "vecchio",
        backup_automatico=False,
        iterazioni_password=1000,
    )
    legacy.prepara_cartelle()
    command.upgrade(
        migrazioni.config_alembic(f"sqlite:///{legacy.percorso_database}"), "0010"
    )
    with (
        sqlite3.connect(cfg.percorso_database) as src,
        sqlite3.connect(legacy.percorso_database) as dst,
    ):
        tables = [
            r[0]
            for r in dst.execute("SELECT name FROM sqlite_master WHERE type='table'")
            if r[0] != "alembic_version" and not r[0].startswith("sqlite_")
        ]
        for t in tables:
            cols = [r[1] for r in dst.execute(f'PRAGMA table_info("{t}")')]
            names = ",".join(f'"{x}"' for x in cols)
            rows = src.execute(f'SELECT {names} FROM "{t}"').fetchall()
            dst.executemany(
                f'INSERT INTO "{t}" ({names}) VALUES ({",".join("?" for _ in cols)})',
                rows,
            )
        expected = {
            t: dst.execute(
                "select id,impianto_id from " + t + " order by id"
            ).fetchall()
            for t in ["verifiche", "preventivi_righe"]
        }
        ids = dst.execute("select id,sede_id from impianti order by id").fetchall()
    arc = prepara_archivio(legacy)
    try:
        with arc.motore.connect() as c:
            assert c.exec_driver_sql("PRAGMA foreign_key_check").all() == []
            assert [
                tuple(x)
                for x in c.exec_driver_sql(
                    "select id,sede_id from impianti order by id"
                )
            ] == ids
            for t, rows in expected.items():
                assert [
                    tuple(x)
                    for x in c.exec_driver_sql(
                        "select id,impianto_id from " + t + " order by id"
                    )
                ] == rows
            assert c.exec_driver_sql("select count(*) from asset").scalar() == len(ids)
            assert (
                c.exec_driver_sql(
                    "select count(*) from impianti where asset_id != id"
                ).scalar()
                == 0
            )
        with arc.motore.connect() as c:
            before = {
                tuple(x) for x in c.exec_driver_sql("select id,asset_id from impianti")
            }
        migrazioni.aggiorna(arc.motore)
        with arc.motore.connect() as c:
            assert {
                tuple(x) for x in c.exec_driver_sql("select id,asset_id from impianti")
            } == before
        assert any(
            "pre_aggiornamento" in x.name for x in legacy.cartella_backup.iterdir()
        )
    finally:
        arc.chiudi()


def test_backup_comune_preserva_camere_date_associazioni_e_origini(admin, sede, app):
    from conftest import Sessione

    a = nuovo(admin, sede)
    a = ok(
        admin.post(
            f"/api/beni/{a['id']}/camere",
            {
                "versione": a["versione"],
                "identificazione": "Camera backup",
                "unita": "L",
                "valore": "123,4",
            },
        )
    )
    a = scad(admin, a, "cnd", numero_report="CND/BACKUP", data_prossima="2036-01-01")
    p = nuovo(admin, sede, "PSV", "PSV-BACKUP")
    p = scad(admin, p, "taratura", data_prossima="2028-01-01")
    a = ok(
        admin.post(
            f"/api/beni/{a['id']}/accessori",
            {"versione": a["versione"], "accessorio_id": p["id"]},
        )
    )
    i = crea_impianto(admin, sede["id"])
    nome = ok(admin.post("/api/backup"))["nome"]
    assert ok(admin.post(f"/api/backup/{nome}/verifica"))["valido"]
    modifica(admin, a, note="Da annullare con ripristino")
    p = scad(admin, p, "taratura", data_prossima="2029-01-01")
    assert ok(admin.post(f"/api/backup/{nome}/ripristina", {"conferma": "RIPRISTINA"}))
    assert admin.get("/api/io").status_code == 401
    ok(
        admin.c.post(
            "/api/accesso",
            json={"username": "federico", "password": "una frase abbastanza lunga"},
        )
    )
    nuova = Sessione(admin.c)
    x = ok(nuova.get(f"/api/beni/{a['id']}"))
    assert x == a
    assert (
        x["volume_totale_litri"] == "123.4"
        and x["taratura_accessori"]["data_prossima"] == "2028-01-01"
    )
    assert ok(nuova.get(f"/api/beni/{i['asset_id']}"))["origini"][0][
        "id_origine"
    ] == str(i["id"])
    assert ok(nuova.post("/api/backup/integrita"))["tutto_ok"]
