"""Prove locali della portabilità e dei confini; non attestano un server PostgreSQL."""
from datetime import date
from pathlib import Path
import hashlib
import json
import zipfile

import pytest
from sqlalchemy import literal, select
from sqlalchemy.dialects import postgresql

from gestionale import modelli  # noqa: F401 (tutte le tabelle nel metadata)
from gestionale.app import prepara_archivio
from gestionale.core import migrazioni
from gestionale.core.config import Config, carica_config
from gestionale.core.db import Base, crea_motore
from gestionale.core.sql_portabile import anno_dopo, data_tra_giorni, giorni_fra, json_testo, oggi_italiano, testi_uniti
from gestionale.core.sql_json_booleano import json_booleano_intero
from gestionale.moduli.backup import postgresql as pg


def test_snapshot_cataloghi_dm_compatibile_con_colonne_testuali():
    snapshot = json.loads((Path(__file__).resolve().parents[1] / 'gestionale' / 'migrazioni' /
                           'versions' / '0028_cataloghi_dm.json').read_text(encoding='utf-8'))
    assert len(max((r['tipo_ver_gvr_1'] or '' for r in snapshot['cls_tipi_attrezzature']), key=len)) > 20
    for nome, righe in snapshot.items():
        tabella = Base.metadata.tables[nome]
        for colonna in tabella.c:
            # La variante SQLite conserva VARCHAR(20), mentre PostgreSQL
            # riceve TEXT (0028) e deve contenere l'intero snapshot Garda.
            limite = getattr(colonna.type.dialect_impl(postgresql.dialect()), 'length', None)
            if limite is not None:
                assert all(len(r[colonna.name]) <= limite for r in righe if isinstance(r.get(colonna.name), str)), (nome, colonna.name)


def test_url_separato_da_file_e_segreto_nella_config(tmp_path,monkeypatch):
    url='postgresql://nexus:segreto_sintetico@localhost/nexus_test'
    monkeypatch.setenv('GESTIONALE_DATABASE_URL',url)
    monkeypatch.setenv('GESTIONALE_CARTELLA_DATI',str(tmp_path))
    cfg=carica_config(tmp_path/'inesistente.json')
    assert cfg.postgresql and cfg.database_url==url
    assert 'segreto_sintetico' not in repr(cfg)
    assert not cfg.percorso_database.exists()
    config=tmp_path/'config.json'
    config.write_text(json.dumps({'database_url':url}))
    with pytest.raises(ValueError,match='non in config.json'):carica_config(config)
    monkeypatch.setenv('GESTIONALE_DATABASE_URL','mysql://localhost/no')
    with pytest.raises(ValueError):carica_config(tmp_path/'inesistente.json')


def test_date_null_anno_bisestile_json_e_aggregazione_sqlite(tmp_path):
    e=crea_motore(str(tmp_path/'prova.sqlite'))
    try:
        with e.connect() as c:
            assert c.scalar(select(data_tra_giorni(literal(date(2026,12,31)),2)))==date(2027,1,2)
            assert c.scalar(select(anno_dopo(literal(date(2024,2,29)))))==date(2025,3,1)
            assert c.scalar(select(giorni_fra(literal(date(2027,1,2)),literal(date(2026,12,31)))))==2
            assert c.scalar(select(giorni_fra(literal(None),oggi_italiano()))) is None
            assert c.scalar(select(json_testo(literal('{"descr_attr":"Valvola"}'),'descr_attr')))=='Valvola'
            assert c.scalar(select(json_booleano_intero(literal('{"marcatura_ce":true}'),'marcatura_ce')))==1
            assert c.scalar(select(json_booleano_intero(literal('{"marcatura_ce":false}'),'marcatura_ce')))==0
            c.exec_driver_sql('CREATE TABLE nomi(valore TEXT)')
            c.exec_driver_sql("INSERT INTO nomi VALUES ('A'),(NULL),('B')")
            from sqlalchemy import column, table
            t=table('nomi',column('valore'))
            assert c.scalar(select(testi_uniti(t.c.valore,', ')))=='A, B'
    finally:e.dispose()


def test_compilazione_pg_senza_funzioni_sqlite():
    q=select(oggi_italiano(),data_tra_giorni(literal(date(2026,1,1)),30),
             anno_dopo(literal(date(2024,2,29))),giorni_fra(literal(date(2026,1,2)),literal(date(2026,1,1))),
             json_testo(literal('{}'),'descr_attr'),testi_uniti(literal('A'),', '))
    sql=str(q.compile(dialect=postgresql.dialect(),compile_kwargs={'literal_binds':True}))
    assert "Europe/Rome" in sql and 'make_date' in sql and 'string_agg' in sql and 'jsonb_extract_path_text' in sql
    assert 'julianday' not in sql and 'group_concat' not in sql and 'json_extract(' not in sql


def test_tutte_le_griglie_compilabili_pg(app):
    from gestionale.core.griglia import REGISTRO_GRIGLIE
    controllate=0
    for g in REGISTRO_GRIGLIE.values():
        if g.da is None:continue
        colonne=[c.espressione.label(c.campo) for c in g.colonne if c.espressione is not None and not c.calcolata]
        sql=str(select(*colonne).select_from(g.da()).compile(dialect=postgresql.dialect()))
        assert not any(x in sql for x in ('group_concat(', 'julianday(', 'json_extract(', 'date(%(')),g.codice
        controllate+=1
    assert controllate>=20


def test_utility_usa_password_solo_nell_ambiente(tmp_path,monkeypatch):
    import subprocess
    cfg=Config(database_url='postgresql://nexus:segreto_sintetico@localhost:5439/nexus_test')
    monkeypatch.setattr(pg,'_utility',lambda n:n)
    def run(args,**kw):
        assert 'segreto_sintetico' not in ' '.join(args)
        assert kw['env']['PGPASSWORD']=='segreto_sintetico'
        assert kw['env']['PGDATABASE']=='nexus_test' and kw['env']['PGPORT']=='5439'
        return subprocess.CompletedProcess(args,0,b'ok',b'')
    monkeypatch.setattr(pg.subprocess,'run',run)
    assert pg._esegui(cfg,'pg_dump',['--file',tmp_path/'database.pgdump'])==b'ok'


def test_backup_pg_hash_toc_schema_e_rifiuto_percorsi(tmp_path,monkeypatch):
    from types import SimpleNamespace
    cfg=Config(cartella_dati=tmp_path,database_url='postgresql://nexus@localhost/nexus_test');cfg.prepara_cartelle()
    arc=SimpleNamespace(cfg=cfg)
    raw=b'PGDMPdump_sintetico'
    m={'backend':'postgresql','revisione_schema':'0027','file':[{'percorso':'database.pgdump','sha256':hashlib.sha256(raw).hexdigest(),'dimensione':len(raw)}]}
    def scrivi(nome,content=raw,extra=False):
        p=tmp_path/nome
        with zipfile.ZipFile(p,'w') as z:
            z.writestr('manifest.json',json.dumps(m));z.writestr('database.pgdump',content)
            if extra:z.writestr('../fuori','errore')
        return p
    monkeypatch.setattr(pg,'_esegui',lambda cfg,n,args:b'COPY public.alembic_version (version_num) FROM stdin;\n0027\n\\.\n' if '--data-only' in args else b'catalogo')
    assert pg.verifica_file(arc,scrivi('valido.zip'))['valido']
    assert not pg.verifica_file(arc,scrivi('alterato.zip',b'PGDMPalterato'))['valido']
    assert not pg.verifica_file(arc,scrivi('percorso.zip',extra=True))['valido']
    assert not (tmp_path.parent/'fuori').exists()


def test_marcatore_di_recupero_blocca_apertura(tmp_path):
    (tmp_path/'ripristino_postgresql_in_corso.json').write_text('{}')
    cfg=Config(cartella_dati=tmp_path)
    with pytest.raises(RuntimeError,match='incompleto'):prepara_archivio(cfg)
    assert not cfg.percorso_database.exists()


def test_centesimi_64_bit_senza_restringere_sqlite(app):
    from gestionale.moduli.tariffario.modelli import VoceTariffa,VersioneTariffa
    from sqlalchemy.dialects import sqlite
    from gestionale.moduli.finanza.modelli import Fattura
    assert str(Fattura.__table__.c.totale.type.compile(dialect=postgresql.dialect()))=='BIGINT'
    assert str(Fattura.__table__.c.totale.type.compile(dialect=sqlite.dialect()))=='INTEGER'
    arc=app.state.archivio
    with arc.scrittura() as s:
        voce=s.scalar(select(VoceTariffa).limit(1))
        v=VersioneTariffa(voce_id=voce.id,valida_dal=date(2099,1,1),prezzo=3_000_000_000)
        s.add(v);s.flush();id=v.id
    with arc.lettura() as s:assert s.get(VersioneTariffa,id).prezzo==3_000_000_000


@pytest.mark.parametrize('recupero_riesce',[True,False])
def test_restore_incerto_tenta_recupero_e_conserva_marcatore_se_fallisce(tmp_path,monkeypatch,recupero_riesce):
    from contextlib import nullcontext
    from types import SimpleNamespace
    from gestionale.core.errori import ErroreUtente
    from gestionale.moduli.backup import servizio as backup
    from gestionale.moduli.utenti.servizio import Attore
    cfg=Config(cartella_dati=tmp_path,database_url='postgresql://nexus@localhost/nexus_test');cfg.prepara_cartelle()
    (cfg.cartella_documenti/'prima.txt').write_text('Originale')
    nomi=['GestionaleAD_backup_20261013_180000_manuale.zip','GestionaleAD_backup_20261013_180001_pre_ripristino.zip']
    for nome in nomi:
        with zipfile.ZipFile(cfg.cartella_backup/nome,'w') as z:
            z.writestr('database.pgdump',b'PGDMPsintetico')
            z.writestr('documenti/prima.txt','Originale')
    arc=SimpleNamespace(cfg=cfg,esclusivo=nullcontext)
    monkeypatch.setattr(pg,'verifica_file',lambda *a:{'valido':True,'revisione_schema':migrazioni.revisione_programma()})
    monkeypatch.setattr(pg,'crea',lambda *a,**k:{'nome':nomi[1]})
    chiamate=[]
    def restore(*args):
        chiamate.append(args)
        if len(chiamate)==1 or not recupero_riesce:raise ErroreUtente('Esito del commit non noto')
        return b''
    monkeypatch.setattr(pg,'_esegui',restore)
    with pytest.raises(ErroreUtente):pg.ripristina_a_fermo(arc,nomi[0],Attore(id=None,nome='Prova'))
    assert len(chiamate)==2
    assert (cfg.cartella_documenti/'prima.txt').read_text()=='Originale'
    assert (cfg.cartella_dati/'ripristino_postgresql_in_corso.json').exists()==(not recupero_riesce)
