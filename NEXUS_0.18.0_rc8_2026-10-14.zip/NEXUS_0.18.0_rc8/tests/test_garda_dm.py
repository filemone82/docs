"""0.12.4: aggiunta del database di Garda AD_dm («adsrl») a un archivio già importato da ingecert, con dati finti.

Stessa forma del dump vero (colonne e JSON delle camere copiati dalla struttura di adsrl_2026-10-07.sql), valori inventati.
"""

from __future__ import annotations

import json

import pytest
from sqlalchemy import select
from test_garda import MINI

from gestionale.moduli.anagrafica.modelli import Cliente, Sede
from gestionale.moduli.beni.modelli import Asset, AssetOrigine, AssetRelazione
from gestionale.moduli.garda import dump, importa, importa_dm

CAMERE_GV = json.dumps([
    {"gvr_att": "Corpo cilindrico", "gvr_nf": "NF-1", "gvr_ps": "12", "gvr_ts": "191", "gvr_nat": "Acqua", "gvr_stt": "L", "gvr_grp": "2",
     "gvr_vol": "3.000,5", "gvr_dn": "/"},
    {"gvr_att": "Surriscaldatore", "gvr_nf": "NF-2", "gvr_ps": "12", "gvr_ts": "250", "gvr_nat": "Vapore", "gvr_stt": "G", "gvr_grp": "2",
     "gvr_vol": "191.7", "gvr_dn": ""},
]).replace("'", "\\'")
CAMERE_ILLEGGIBILI = "non è JSON"

MINI_DM = rf"""
-- dump di prova con la forma di adsrl
INSERT INTO `clienti` (`id`, `rag_soc`, `indirizzo`, `cerca_comune`, `comune`, `cap`, `prov`, `regione`, `cod_fis`, `p_iva`, `note`,
  `last_update_user`, `last_update_ts`, `last_update_nr`, `sconto_def`, `referente_commerciale`, `nazione`, `email`, `pec`, `sdi_pec`,
  `rif_amministrazione`, `istituto_finanziario`, `iban`, `dich_intento`, `dich_intento_n`, `dich_intento_data`, `pagamento`, `iva`,
  `rit_acc_str`) VALUES
	(1, 'OFFICINA L\'ANCORA SRL', 'Via Roma 1', NULL, 'Torino', '10121', 'TO', 'Piemonte', '01234567897', '01234567897', NULL, 1, NULL, 1,
	 NULL, NULL, 1, NULL, NULL, 'ABC1234', NULL, NULL, NULL, 'F', NULL, NULL, 2, 1, NULL),
	(2, 'Caseificio Valle Srl', 'Strada Bassa 4', NULL, 'Cuneo', '12100', 'CN', 'Piemonte', '02345678901', '02345678901', 'solo DM', 1, NULL, 1,
	 NULL, NULL, 1, 'info@caseificio.invalid', NULL, '0000000', NULL, NULL, NULL, 'F', NULL, NULL, 2, 1, NULL);
INSERT INTO `clienti_sedi_operative` (`id`, `cliente`, `indirizzo`, `cerca_comune`, `comune`, `cap`, `prov`, `regione`, `nome_referente`,
  `contatto_referente`, `note`, `last_update_user`, `last_update_ts`, `last_update_nr`, `email_ref`, `tel_ref`, `nome_sede`, `utente_cliente`,
  `inattiva`) VALUES
	(10, 1, 'Via  Roma, 1', NULL, 'TORINO', '10121', 'TO', 'Piemonte', NULL, NULL, NULL, 1, NULL, 1, NULL, NULL, 'Centrale termica', NULL, 'F'),
	(11, 2, 'Strada Bassa 4', NULL, 'Cuneo', '12100', 'CN', 'Piemonte', NULL, NULL, NULL, 1, NULL, 1, NULL, NULL, 'Stabilimento', NULL, 'F'),
	(12, 2, 'Via Chiusa 9', NULL, 'Cuneo', '12100', 'CN', 'Piemonte', NULL, NULL, NULL, 1, NULL, 1, NULL, NULL, 'Vecchio magazzino', NULL, 'T');
INSERT INTO `attrezzature` (`id`, `sede_operativa`, `anno_matricola`, `cod_att_matricola`, `num_matricola`, `prov_immatr`, `num_fabbrica`,
  `rag_soc_costr`, `cf_costr`, `modello`, `anno_costr`, `descr`, `descr_gvr`, `rif_interno`, `marcatura_ce`, `note_attr`, `gruppo_attr`,
  `tipo_attr`, `id_spec`, `ps_attr_gvr`, `volume_attr_gvr`, `ts_attr_gvr`, `sup_risc_attr_gvr`, `prod_attr_gvr`, `sogg_messa_servizio_gvr`,
  `gruppo_fluido`, `cat_ped`, `portata_attr_sc_sp`, `n_panieri_idroestr`, `matr_informale`, `dismessa`, `tipo_prox_verifica`, `ultima_funz`,
  `data_ult_funz`, `data_prox_funz`, `data_ult_integrita`, `data_prox_integrita`, `ultima_interna`, `data_ult_interna`, `data_prox_interna`,
  `data_ult_cnd`, `data_prox_cnd`, `ultima_scsp`, `data_ult_scsp`, `data_prox_scsp`, `data_ult_suppl`, `data_prox_suppl`, `reparto`,
  `matr_insieme`, `id_pacco_bombola`, `descr_attr`, `esente_verifiche`, `gvr_conf_dati_tecnici`, `tipo_attr_verbale`, `gvr_breve_descr_funz`) VALUES
	(500, 10, '2001', 'GV', '123', 'to', 'F-77', 'Caldaie Srl', NULL, 'CX 3000', 2001, 'Generatore di vapore', NULL, 'GV1', 'T', 'nota',
	 'GVR', 24, 52, '12', '3192', '191', '80', '2000', 'T', '2', 'IV', NULL, NULL, 'GV-1', 'F', NULL, 900,
	 '2025-05-10', '2026-05-10', '2023-05-10', '2026-05-10', 901, '2024-05-10', '2026-05-10', '2015-01-01', '2027-01-01',
	 NULL, NULL, NULL, NULL, NULL, 'Caldaie', NULL, NULL, NULL, 'F', '{CAMERE_GV}', NULL, 'Produzione vapore'),
	(501, 10, NULL, NULL, NULL, NULL, 'R-9', 'Serbatoi Spa', NULL, NULL, 'sconosciuto', 'Serbatoio aria', NULL, NULL, 'T', NULL,
	 'GVR', 18, 40, '11', '270', '-10/120', NULL, NULL, 'F', '2', 'II', NULL, NULL, 'R-1', 'F', NULL, NULL,
	 '2025-01-15', '2027-01-15', NULL, NULL, NULL, '2020-01-15', '2030-01-15', NULL, NULL,
	 NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'F', '{CAMERE_ILLEGGIBILI}', NULL, NULL),
	(502, 11, '1998', 'SC', '55', 'CN', 'G-3', 'Gru Srl', NULL, 'G20', 1998, 'Gru a torre', NULL, NULL, 'F', NULL,
	 'SC', 1, 6, NULL, NULL, NULL, NULL, NULL, 'F', NULL, NULL, '2000 kg', NULL, 'G-1', 'T', NULL, NULL,
	 NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
	 902, '2024-03-01', '2025-03-01', '2019-03-01', '2029-03-01', NULL, NULL, NULL, NULL, 'F', NULL, NULL, NULL),
	(503, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Carrello', NULL, NULL, 'F', NULL,
	 'SC', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'F', NULL, NULL, NULL, NULL, 'g-1 ', 'F', NULL, NULL,
	 NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'F', NULL, NULL, NULL),
	(504, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ponte', NULL, NULL, 'F', NULL,
	 'SC', 1, 6, NULL, NULL, NULL, NULL, NULL, 'F', NULL, NULL, NULL, NULL, 'G-1', 'F', NULL, NULL,
	 NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'F', NULL, NULL, NULL),
	(505, 999, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Orfana', NULL, NULL, 'F', NULL,
	 'SC', 1, 6, NULL, NULL, NULL, NULL, NULL, 'F', NULL, NULL, NULL, NULL, 'X-1', 'F', NULL, NULL,
	 NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'F', NULL, NULL, NULL);
INSERT INTO `valvole_sicurezza` (`id`, `fabbr`, `modello`, `matricola`, `dn`, `diametro`, `area`, `ptar`, `ultima_tar`, `prossima_tar`,
  `last_update_user`, `last_update_ts`, `last_update_nr`, `sede_operativa`, `dismessa`, `tip_accessorio`) VALUES
	(700, 'Valvole Srl', 'VS1', 'VS-1', '25', NULL, NULL, '12', '2025-05-10', '2026-05-10', 1, NULL, 1, 10, 'F', 'valvola di sicurezza'),
	(701, 'Valvole Srl', 'VS1', 'VS-2', '25', NULL, NULL, '11', NULL, NULL, 1, NULL, 1, 10, 'F', NULL);
INSERT INTO `attrezzature_vds` (`id`, `attrezzatura`, `valvola_sicurezza`, `last_update_user`, `last_update_ts`, `last_update_nr`) VALUES
	(1, 500, 700, 1, NULL, 1), (2, 501, 701, 1, NULL, 1), (3, 500, 700, 1, NULL, 1), (4, 999, 700, 1, NULL, 1);
INSERT INTO `verifiche` (`id`, `stato_verifica`, `attrezzatura`, `codice_verifica`) VALUES
	(900, 'effettuata', 500, 'V/10/25'), (901, 'effettuata', 500, 'V/11/24'), (902, 'effettuata', 502, 'V/12/24');
"""


@pytest.fixture
def archivio_dpr(admin, app):
    with app.state.archivio.scrittura() as s:
        importa.importa(s, None, dump.leggi(MINI, importa.TABELLE), "mini.sql")
    return app.state.archivio


def test_lettura_del_dump_dm():
    d = dump.leggi(MINI_DM, importa_dm.TABELLE_DM)
    assert len(d["attrezzature"]) == 6 and len(d["valvole_sicurezza"]) == 2
    assert json.loads(d["attrezzature"][0]["gvr_conf_dati_tecnici"])[0]["gvr_vol"] == "3.000,5"
    assert importa_dm._decimi("3.000,5") == 30005 and importa_dm._decimi("191.7") == 1917
    assert importa_dm._decimi("4.000") == 40000 and importa_dm._decimi("/") is None and importa_dm._decimi("") is None


def test_aggiunta_di_ad_dm(admin, app, archivio_dpr):
    with archivio_dpr.scrittura() as s:
        esito = importa_dm.importa(s, None, dump.leggi(MINI_DM, importa_dm.TABELLE_DM), "mini_dm.sql")
    imp = esito["importati"]
    assert imp["sedi AD_dm unite alla sede DPR con lo stesso indirizzo (R116)"] == 1
    assert "clienti_sedi_operative: lette 3, importate 3 (di cui 1 unite a una sede DPR)" in esito["quadratura"]
    # R118: accoppiamenti controllati — nessuna sede in più o in meno, ogni bene nella sede giusta, ogni collegamento contato
    assert "sedi nell'archivio: attese 4 (prima 2 + 3 adsrl − 1 unite), presenti 4" in esito["quadratura"]
    assert "attrezzature e accessori nella sede giusta: 7 su 7" in esito["quadratura"]
    assert "attrezzature_vds: lette 4, importate 2, scartate con motivo 2" in esito["quadratura"]
    assert imp["clienti già presenti, fusi con AD_dm"] == 1 and imp["clienti nuovi da AD_dm"] == 1
    assert imp["attrezzature GVR"] == 2 and imp["attrezzature SC"] == 3 and imp["accessori"] == 2
    assert imp["camere GVR"] == 2 and imp["collegamenti attrezzatura-accessorio"] == 2
    assert imp["collegamenti attrezzatura-accessorio non importati (riferimento mancante o doppio)"] == 2
    # quadratura: l'attrezzatura senza sede è l'unica differenza; il volume delle camere quadra
    assert "attrezzature: lette 6, importate 5 · DIFFERENZA 1" in esito["quadratura"]
    assert esito["quadratura"][-1] == "volume totale delle camere (litri): Garda 3192.2, archivio 3192.2"
    testi = " | ".join(p["problema"] for p in esito["problemi"])
    for atteso in ("senza sede operativa valida", "camere illeggibile", "visita interna su una famiglia che non la prevede",
                   "stessa matricola informale", "da classificare", "anno di costruzione «sconosciuto»"):
        assert atteso in testi, atteso
    with archivio_dpr.lettura() as s:
        # cliente fuso: stesso record DPR, con la nota; cliente nuovo con codice dm:
        officina = s.scalar(select(Cliente).where(Cliente.partita_iva == "01234567897"))
        assert officina.codice_esterno == "10" and "adsrl codice 1" in officina.note
        assert s.scalar(select(Cliente).where(Cliente.codice_esterno == "dm:2")).ragione_sociale == "Caseificio Valle Srl"
        sedi = {x.codice_esterno: x for x in s.scalars(select(Sede).where(Sede.codice_esterno.like("%dm:%")))}
        # R116: la sede adsrl 10 («Via  Roma, 1», «TORINO») è lo stesso stabilimento della sede DPR 100: unita
        assert set(sedi) == {"100 · dm:10", "dm:11", "dm:12"} and not sedi["dm:12"].attiva
        unita = sedi["100 · dm:10"]
        assert unita.cliente_id == officina.id and unita.denominazione == "Stabilimento" and unita.ambito_dpr and unita.ambito_dm
        assert "Unita la sede «Centrale termica»" in unita.note and "denominazione: Centrale termica" in unita.note
        assert {a.matr_informale for a in s.scalars(select(Asset).where(Asset.sede_id == unita.id))} >= {"GV-1", "R-1", "VS-1"}
        assert len(list(s.scalars(select(Sede).where(Sede.cliente_id == officina.id)))) == 1
        sedi.pop("100 · dm:10")
        # R114: anagrafica unica con gli ambiti — fuso AD_DPR + AD_DM, nuovo solo AD_DM, chi è solo in ingecert resta AD_DPR
        assert (officina.ambito_dpr, officina.ambito_dm) == (True, True)
        caseificio = s.scalar(select(Cliente).where(Cliente.codice_esterno == "dm:2"))
        assert (caseificio.ambito_dpr, caseificio.ambito_dm) == (False, True)
        comune = s.scalar(select(Cliente).where(Cliente.codice_esterno == "11"))
        assert (comune.ambito_dpr, comune.ambito_dm) == (True, False)
        assert all(x.ambito_dm and not x.ambito_dpr for x in sedi.values())
        origine = {o.id_origine: o.asset for o in s.scalars(select(AssetOrigine).where(AssetOrigine.sistema == importa_dm.SISTEMA))}
        gv, rec, gru, carrello = origine["500"], origine["501"], origine["502"], origine["503"]
        # generatore di vapore: classificazione, attributi, camere, date per componente come date iniziali dichiarate
        assert (gv.tipo_attr_id, gv.tipo_attr_gvr_id, gv.id_spec_id, gv.prov_immatr) == (24, 2, 52, "TO")
        attr = json.loads(gv.attributi_json)
        assert attr["marcatura_ce"] is True and attr["ps_attr_gvr"] == "12" and attr["reparto"] == "Caldaie"
        assert [(c.identificazione, c.unita, c.valore_decimi) for c in gv.camere] == [("Corpo cilindrico", "L", 30005), ("Surriscaldatore", "L", 1917)]
        sc = {x.componente: x for x in gv.scadenze}
        assert set(sc) == {"funzionamento", "integrita", "interna", "cnd"}
        assert all(x.fonte == "dichiarata" for x in sc.values()) and str(sc["cnd"].data_prossima) == "2027-01-01"
        assert sc["funzionamento"].nota.endswith("ultimo verbale in Garda V/10/25") and "V/11/24" in sc["interna"].nota
        # recipiente (famiglia a1): niente camere (JSON illeggibile), la visita interna resta ma è segnalata
        assert rec.camere == [] and rec.anno_costruzione is None and "interna" in {x.componente for x in rec.scadenze}
        # SC: dismessa resta dismessa, date SC/SP e supplementare
        assert gru.dismesso and {x.componente for x in gru.scadenze} == {"scsp", "supplementare"}
        assert carrello.tipo_attr_id is None and carrello.id_spec_id is None
        assert origine["504"].matr_informale == "G-1 (504)"
        # accessori: tarature e collegamenti
        vs1 = s.scalar(select(Asset).where(Asset.gruppo == "PSV", Asset.matr_informale == "VS-1"))
        assert json.loads(vs1.attributi_json) == {"tip_accessorio": "valvola di sicurezza", "dn": "25", "ptar": "12"}
        assert [x.componente for x in vs1.scadenze] == ["taratura"]
        rel = list(s.scalars(select(AssetRelazione)))
        assert {(r.asset_id, r.accessorio_id) for r in rel} == {(gv.id, vs1.id), (rec.id, origine["701"].id)}
        gv_id = gv.id
    scheda = admin.get(f"/api/beni/{gv_id}").json()
    assert scheda["volume_totale_litri"] == "3192.2" and "interna" in scheda["componenti"]
    assert [a["matricola"] for a in scheda["accessori"]] == ["VS-1"]
    assert scheda["origini"] == [{"sistema": "garda_adsrl", "tabella": "attrezzature", "id_origine": "500"}]
    # seconda volta: rifiutata, nulla cambia
    with archivio_dpr.scrittura() as s, pytest.raises(ValueError, match="già stato importato"):
        importa_dm.importa(s, None, dump.leggi(MINI_DM, importa_dm.TABELLE_DM), "mini_dm.sql")


def test_ad_dm_solo_dopo_ad_dpr(admin, app):
    with app.state.archivio.scrittura() as s, pytest.raises(ValueError, match="Importa prima"):
        importa_dm.importa(s, None, dump.leggi(MINI_DM, importa_dm.TABELLE_DM), "mini_dm.sql")
    with app.state.archivio.scrittura() as s, pytest.raises(ValueError, match="attrezzature"):
        importa_dm.importa(s, None, dump.leggi(MINI, importa.TABELLE), "ingecert.sql")


def test_scheda_accessorio_con_i_dati_di_garda(admin):
    """I campi degli accessori (tipologia, DN, diametro, area, Ptar) erano solo nel database di Garda: ora sono nella scheda."""
    from test_anagrafica import crea_cliente, crea_sede
    from test_beni import modifica, nuovo, ok

    sede = crea_sede(admin, crea_cliente(admin)["id"])
    cat = ok(admin.get("/api/beni/cataloghi"))
    assert [x["nome"] for x in cat["schede_dm"]["PSV"]] == ["tip_accessorio", "dn", "diametro", "area", "ptar"]
    p = nuovo(admin, sede, "PSV", "VS-9", dati_dm={"tip_accessorio": "disco di rottura", "dn": "50", "ptar": "10 bar"})
    p = ok(admin.get(f"/api/beni/{p['id']}"))
    assert p["attributi"] == {"tip_accessorio": "disco di rottura", "dn": "50", "ptar": "10 bar"}
    assert p["campi_dm"][0]["nome"] == "tip_accessorio"
    p = modifica(admin, p, dati_dm={"area": "12 cm²"})
    assert ok(admin.get(f"/api/beni/{p['id']}"))["attributi"]["area"] == "12 cm²"
    r = admin.put(f"/api/beni/{p['id']}", {"versione": p["versione"], "dati_dm": {"tip_accessorio": "rubinetto"}})
    assert r.status_code == 400 and "valore non previsto" in r.text
