"""0.14 · Fatture DPR complete pari a Garda: dati del cedente (REA, contatti), documenti collegati, modalità di
pagamento con rate (tipi_pagamento), «salda subito», nome file SdI, XML in blocco, ricevute SdI da file,
scadenze di pagamento, avvisi della bozza."""

import io
import zipfile
from datetime import date

from test_finanza import economia as economia  # noqa: F401, PLC0414  (fixture)
from test_finanza import emetti, nuovo, ok, riga
from test_finanza import accettato as accettato  # noqa: F401, PLC0414

from gestionale.moduli.finanza import pagamenti
from gestionale.moduli.finanza.xml_fattura import valida

NS_SDI = "http://ivaservizi.agenziaentrate.gov.it/docs/xsd/messaggi/v1.0"


def _societa_completa(admin, economia):
    so = next(x for x in ok(admin.get("/api/finanza/valori"))["societa"] if x["codice"] == "AD")
    return ok(admin.put(f"/api/societa/{so['id']}", {"versione": so["versione"], "dati": {
        "rea_ufficio": "TO", "rea_numero": "1234567", "capitale_sociale": "10.000,00", "socio_unico": "SM",
        "stato_liquidazione": "LN", "telefono": "011 1234567", "email": "amministrazione@example.it",
        "id_trasmittente": "01234567890"}}))


def _modalita(admin, descrizione):
    return next(m for m in ok(admin.get("/api/finanza/valori"))["modalita"] if m["descrizione"] == descrizione)


def test_cedente_rea_contatti_e_documenti_collegati(admin, economia):
    _societa_completa(admin, economia)
    f = riga(admin, nuovo(admin, economia))
    f = ok(admin.put(f"/api/fatture/{f['id']}", {"versione": f["versione"], "opzioni": {"documenti": [
        {"tipo": "OrdineAcquisto", "numero": "ODA-77", "data": "2026-09-01", "cig": "Z1234567890", "cup": ""},
        {"tipo": "Contratto", "numero": "C-2026/4", "data": "2026-01-10", "cup": "J11B22000010001", "commessa": "Lotto 2"}]}}))
    assert [d["tipo"] for d in f["opzioni"]["documenti"]] == ["OrdineAcquisto", "Contratto"]
    f = emetti(admin, f)
    raw = admin.get(f"/api/fatture/{f['id']}/xml/1").content
    valida(raw)
    x = raw.decode()
    assert "<IscrizioneREA>" in x and "<Ufficio>TO</Ufficio>" in x and "<NumeroREA>1234567</NumeroREA>" in x
    assert "<CapitaleSociale>10000.00</CapitaleSociale>" in x and "<SocioUnico>SM</SocioUnico>" in x
    assert "<Email>amministrazione@example.it</Email>" in x
    assert x.index("<DatiOrdineAcquisto>") < x.index("<DatiContratto>")
    assert "<CodiceCIG>Z1234567890</CodiceCIG>" in x and "<CodiceCommessaConvenzione>Lotto 2</CodiceCommessaConvenzione>" in x
    # R138 (0.16): documento di trasporto e fattura principale, nell'ordine dello schema, XML valido
    h = riga(admin, nuovo(admin, economia))
    h = ok(admin.put(f"/api/fatture/{h['id']}", {"versione": h["versione"], "opzioni": {"documenti": [
        {"tipo": "FatturaPrincipale", "numero": "12/2026/DPR", "data": "2026-09-10"},
        {"tipo": "DDT", "numero": "DDT-7", "data": "2026-09-03"}, {"tipo": "OrdineAcquisto", "numero": "ODA-9", "data": "2026-09-01"}]}}))
    h = emetti(admin, h)
    raw = admin.get(f"/api/fatture/{h['id']}/xml/1").content
    valida(raw)
    x = raw.decode()
    assert x.index("<DatiOrdineAcquisto>") < x.index("<DatiDDT>") < x.index("<FatturaPrincipale>")
    assert "<NumeroDDT>DDT-7</NumeroDDT>" in x and "<NumeroFatturaPrincipale>12/2026/DPR</NumeroFatturaPrincipale>" in x
    # documenti non validi
    g = riga(admin, nuovo(admin, economia))
    r = admin.put(f"/api/fatture/{g['id']}", {"versione": g["versione"], "opzioni": {"documenti": [{"tipo": "Altro", "numero": "1"}]}})
    assert r.status_code == 400
    r = admin.put(f"/api/fatture/{g['id']}", {"versione": g["versione"], "opzioni": {"documenti": [{"tipo": "Contratto", "numero": ""}]}})
    assert r.status_code == 400


def test_nome_file_sdi_e_progressivo_di_cinque_caratteri(admin, economia):
    _societa_completa(admin, economia)
    f = emetti(admin, riga(admin, nuovo(admin, economia)))
    e = f["esportazioni"][0]
    assert e["nome_file"].startswith("IT01234567890_") and len(e["nome_file"].split("_")[1]) == len("XXXXX.xml")
    r = admin.get(f"/api/fatture/{f['id']}/xml/1")
    assert e["nome_file"] in r.headers["content-disposition"]
    progressivo = e["nome_file"].split("_")[1][:-4]
    assert f"<ProgressivoInvio>{progressivo}</ProgressivoInvio>" in r.text
    from gestionale.moduli.finanza.servizio import progressivo
    assert [progressivo(n) for n in (1, 36, 4096)] == ["00001", "00010", "0035S"] and len(progressivo(60_000_000)) == 5


def test_regole_di_pagamento_come_garda():
    r = pagamenti.valida({"mp": "MP05", "rate": [{"giorni": 30, "percentuale": "50", "fine_mese": True},
                                                {"giorni": 60, "percentuale": "50", "fine_mese": True}],
                          "fm_paga_dopo": 10, "sposta_scadenze": False})
    q = pagamenti.calcola(date(2026, 10, 12), 10001, r)
    assert [(x["data"], x["importo"]) for x in q] == [(date(2026, 12, 10), 5001), (date(2027, 1, 10), 5000)]
    r = pagamenti.valida({"mp": "MP12", "rate": [{"giorni": 30, "percentuale": "100", "fine_mese": True}], "sposta_scadenze": True})
    assert pagamenti.calcola(date(2026, 7, 15), 5000, r)[0]["data"] == date(2026, 9, 10)     # 31/8 → 10/9
    assert pagamenti.calcola(date(2026, 11, 20), 5000, r)[0]["data"] == date(2027, 1, 10)    # 31/12 → 10/1
    assert pagamenti.proposta_da_descrizione("Bonifico 60 gg F.M.")["rate"] == [{"giorni": 60, "percentuale": "100", "fine_mese": True}]
    assert pagamenti.proposta_da_descrizione("Ri.Ba. 30 gg F.M.")["mp"] == "MP12"
    for errato in ({"mp": "MP99"}, {"rate": [{"giorni": 30, "percentuale": "60"}]}, {"rate": [{"giorni": -1, "percentuale": "100"}]}):
        try:
            pagamenti.valida(errato)
            raise AssertionError(errato)
        except Exception as e:  # noqa: BLE001
            assert "ErroreUtente" in type(e).__name__


def test_scadenze_dalla_modalita_del_cliente_e_predefinita(admin, economia):
    m = _modalita(admin, "Bonifico 30 gg F.M.")
    ok(admin.put(f"/api/finanza/modalita/{m['id']}/regole", {"versione": m["versione"], "regole": {
        "mp": "MP05", "rate": [{"giorni": 30, "percentuale": "100", "fine_mese": True}]}}))
    c = economia["cliente"]
    c = ok(admin.get(f"/api/clienti/{c['id']}"))
    ok(admin.put(f"/api/clienti/{c['id']}", {**c, "modalita_pagamento_id": m["id"]}))
    f = riga(admin, nuovo(admin, economia))
    assert f["modalita_pagamento"]["descrizione"] == "Bonifico 30 gg F.M." and f["modalita_pagamento"]["provenienza"] == "dal cliente"
    f = emetti(admin, f)
    assert [(q["data"], q["importo"], q["modalita"]) for q in f["scadenze"]] == [("2026-11-30", 12200, "MP05")]
    # predefinita, se il cliente non ne ha
    p = _modalita(admin, "Bonifico 60 gg D.F.")
    ok(admin.put(f"/api/finanza/modalita/{p['id']}/regole", {"versione": p["versione"], "regole": {
        "mp": "MP05", "predefinito": True, "rate": [{"giorni": 60, "percentuale": "100", "fine_mese": False}]}}))
    c = ok(admin.get(f"/api/clienti/{c['id']}"))
    ok(admin.put(f"/api/clienti/{c['id']}", {**c, "modalita_pagamento_id": None}))
    g = riga(admin, nuovo(admin, economia))
    assert g["modalita_pagamento"]["provenienza"] == "predefinita"
    g = ok(admin.post(f"/api/fatture/{g['id']}/scadenze/calcola", {"versione": g["versione"]}))
    assert [q["data"] for q in g["scadenze"]] == ["2026-12-07"]
    # una sola predefinita
    mods = {x["descrizione"]: x for x in ok(admin.get("/api/finanza/valori"))["modalita"]}
    m = mods["Bonifico 30 gg F.M."]
    ok(admin.put(f"/api/finanza/modalita/{m['id']}/regole", {"versione": m["versione"], "regole": {**m["regole"], "predefinito": True}}))
    mods = {x["descrizione"]: x for x in ok(admin.get("/api/finanza/valori"))["modalita"]}
    assert [k for k, x in mods.items() if x["regole"]["predefinito"]] == ["Bonifico 30 gg F.M."]


def test_salda_subito(admin, economia):
    m = _modalita(admin, "Rimessa diretta")
    ok(admin.put(f"/api/finanza/modalita/{m['id']}/regole", {"versione": m["versione"], "regole": {
        "mp": "MP01", "salda_subito": True, "rate": [{"giorni": 0, "percentuale": "100", "fine_mese": False}]}}))
    f = riga(admin, nuovo(admin, economia))
    f = ok(admin.put(f"/api/fatture/{f['id']}", {"versione": f["versione"], "opzioni": {"modalita_pagamento_id": str(m["id"])}}))
    f = emetti(admin, f)
    assert f["residuo"] == 0 and f["pagato"] == 12200
    assert any("Saldato all'emissione" in x["causale"] for x in ok(admin.get("/api/incassi")))


def _notifica(tipo, nome_file, identificativo, extra=""):
    return (f'<?xml version="1.0" encoding="UTF-8"?><ns:{tipo} xmlns:ns="{NS_SDI}" versione="1.0">'
            f"<IdentificativoSdI>{identificativo}</IdentificativoSdI><NomeFile>{nome_file}</NomeFile>"
            f"<DataOraRicezione>2026-10-12T10:00:00</DataOraRicezione>{extra}</ns:{tipo}>").encode()


def _carica(admin, *files):
    r = admin.c.post("/api/fatture/esiti/importa", files=[("file", (n, b, "application/xml")) for n, b in files], headers=admin.h)
    assert r.status_code == 200, r.text
    return r.json()["risultati"]


def test_ricevute_sdi_da_file_e_xml_in_blocco(admin, economia):
    _societa_completa(admin, economia)
    a = emetti(admin, riga(admin, nuovo(admin, economia)))
    b = emetti(admin, riga(admin, nuovo(admin, economia)))
    na, nb = a["esportazioni"][0]["nome_file"], b["esportazioni"][0]["nome_file"]
    # consegna di a; la stessa ricevuta due volte non cambia nulla
    r = _carica(admin, ("rc.xml", _notifica("RicevutaConsegna", na, "111")))
    assert r[0]["stato"] == "registrata" and r[0]["esito"] == "consegnata"
    assert _carica(admin, ("rc.xml", _notifica("RicevutaConsegna", na, "111")))[0]["stato"] == "già registrata"
    assert ok(admin.get(f"/api/fatture/{a['id']}"))["stato"] == "consegnata"
    # scarto di b dentro uno ZIP, con gli errori; più un file sconosciuto
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("ns.xml", _notifica("NotificaScarto", nb + ".p7m", "222",
                                      "<ListaErrori><Errore><Codice>00305</Codice><Descrizione>IdFiscaleIVA non valido</Descrizione></Errore></ListaErrori>"))
        z.writestr("altro.xml", _notifica("RicevutaConsegna", "IT999_ZZZZZ.xml", "333"))
    r = _carica(admin, ("ricevute.zip", buf.getvalue()))
    stati = {x["file"]: x for x in r}
    assert stati["ns.xml"]["esito"] == "scartata" and stati["altro.xml"]["stato"] == "non registrata"
    bb = ok(admin.get(f"/api/fatture/{b['id']}"))
    assert bb["stato"] == "scartata" and "00305" in bb["esportazioni"][0]["esiti"][0]["messaggio"]
    # una consegna dopo lo scarto non è coerente: non registrata, nessun cambiamento
    assert _carica(admin, ("x.xml", _notifica("RicevutaConsegna", nb, "444")))[0]["stato"] == "non registrata"
    # file che non è una ricevuta
    assert _carica(admin, ("y.xml", b"<?xml version='1.0'?><Altro/>"))[0]["stato"] == "non registrata"
    # XML in blocco: le emesse nello ZIP con il nome SdI, le bozze elencate a parte
    c = riga(admin, nuovo(admin, economia))
    r = admin.post("/api/fatture/xml-zip", {"ids": [a["id"], b["id"], c["id"]]})
    assert r.status_code == 200
    z = zipfile.ZipFile(io.BytesIO(r.content))
    assert set(z.namelist()) == {na, nb, "LEGGIMI.txt"}
    valida(z.read(na))


def test_esito_pa_e_decorrenza(admin, economia):
    _societa_completa(admin, economia)
    f = emetti(admin, riga(admin, nuovo(admin, economia)))
    n = f["esportazioni"][0]["nome_file"]
    _carica(admin, ("rc.xml", _notifica("RicevutaConsegna", n, "9")))
    r = _carica(admin, ("ne.xml", _notifica("NotificaEsito", n, "9", "<EsitoCommittente><Esito>EC02</Esito><Descrizione>Manca il CIG</Descrizione></EsitoCommittente>")))
    assert r[0]["esito"] == "rifiutata_pa"
    assert "Manca il CIG" in ok(admin.get(f"/api/fatture/{f['id']}"))["esportazioni"][0]["esiti"][-1]["messaggio"]


def test_scadenze_di_pagamento_e_avvisi(admin, economia):
    m = _modalita(admin, "Bonifico 60 gg D.F.")
    ok(admin.put(f"/api/finanza/modalita/{m['id']}/regole", {"versione": m["versione"], "regole": {
        "mp": "MP05", "rate": [{"giorni": 0, "percentuale": "50", "fine_mese": False}, {"giorni": 700, "percentuale": "50", "fine_mese": False}]}}))
    f = riga(admin, nuovo(admin, economia))
    f = ok(admin.put(f"/api/fatture/{f['id']}", {"versione": f["versione"], "opzioni": {"modalita_pagamento_id": str(m["id"])}}))
    f = emetti(admin, f)
    ok(admin.post("/api/incassi", {"societa_id": economia["societa"]["id"], "cliente_id": economia["cliente"]["id"],
                                    "data": "2026-10-12", "importo": "61.00", "causale": "prima rata",
                                    "allocazioni": [{"fattura_id": f["id"], "importo": "61.00"}]}))
    righe = ok(admin.post("/api/griglie/scadenze_pagamento/dati", {}))["righe"]
    mie = sorted((x for x in righe if x["fattura_id"] == f["id"]), key=lambda x: x["data_scadenza"])
    assert [x["stato_rata"] for x in mie] == ["Saldata", "Da incassare"] and mie[0]["residuo"] == 6100
    # avviso del bollo sulle righe senza IVA oltre 77,47 €
    g = nuovo(admin, economia)
    g = riga(admin, g, prezzo="100.00", aliquota="0", natura="N2.2")
    assert any("bollo" in a for a in g["avvisi"])
    g = ok(admin.put(f"/api/fatture/{g['id']}", {"versione": g["versione"], "opzioni": {"bollo": "2.00"}}))
    assert not any("bollo" in a for a in g["avvisi"])
