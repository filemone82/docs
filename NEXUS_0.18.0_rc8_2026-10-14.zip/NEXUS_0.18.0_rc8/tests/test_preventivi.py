"""Versione 0.3.0: preventivi (numerazione, righe, sconti, stati, revisioni, riesame, documento, email)."""

from __future__ import annotations

import io
import zipfile
from datetime import date

import pytest
from conftest import nuovo_utente, segna_inviato
from test_anagrafica import PIVA, crea_cliente, crea_impianto, crea_sede

from gestionale.core import pdf


@pytest.fixture
def base(admin):
    c = crea_cliente(admin, ragione_sociale="Comune di Prova", tipo="pa", codice_sdi="UFABCD", termine_esecuzione="entro 60 giorni")
    s1, s2 = crea_sede(admin, c["id"]), crea_sede(admin, c["id"], denominazione="Scuola media")
    i1 = crea_impianto(admin, s1["id"], potenza_kw="30", ultima_verifica_data="2024-12-10")
    i2 = crea_impianto(admin, s2["id"], potenza_kw="120", tipologia="terra_at", cabine_mt_bt=1, ultima_verifica_data="2024-01-15")
    return {"cliente": c, "impianti": [i1, i2]}


def nuovo(admin, base, **extra):
    r = admin.post("/api/preventivi", {"impianti": [i["id"] for i in base["impianti"]], **extra})
    assert r.status_code == 200, r.text
    return r.json()


def test_numerazione_righe_e_totali(admin, base):
    p = nuovo(admin, base)
    anno = date.today().year % 100
    assert p["codice"] == f"P_001_{anno:02d}" and p["stato"] == "creato" and len(p["righe"]) == 2
    assert p["termine_esecuzione"] == "entro 60 giorni"                # proposto dal cliente
    assert [r["tariffa_standard"] for r in p["righe"]] == [30000, 60000]  # 30 kW → 300 €, 120 kW → 600 €
    assert p["totale"] == 90000 and p["righe"][1]["sede_nome"] == "Scuola media"  # D39: sedi diverse
    assert nuovo(admin, base, impianti=[], cliente_id=base["cliente"]["id"])["codice"] == f"P_002_{anno:02d}"
    altro = crea_impianto(admin, crea_sede(admin, crea_cliente(admin, ragione_sociale="Altro", partita_iva="12345678903",
                                                                     codice_fiscale="12345678903")["id"])["id"])
    r = admin.post(f"/api/preventivi/{p['id']}/impianti", {"impianti": [altro["id"]], "versione": p["versione"]})
    assert r.status_code == 400 and "altro cliente" in r.json()["errore"]
    assert admin.post(f"/api/preventivi/{p['id']}/impianti", {"impianti": [base["impianti"][0]["id"]], "versione": p["versione"]}).status_code == 400


def test_sconti_solo_se_sbloccati(admin, base):
    p = nuovo(admin, base)
    righe = [{"id": r["id"], "tipo_verifica": "periodica", "sconto": "10"} for r in p["righe"]]
    r = admin.put(f"/api/preventivi/{p['id']}", {**p, "righe": righe})
    assert r.status_code == 400 and "bloccati" in r.json()["errore"]
    c = base["cliente"]
    admin.post(f"/api/clienti/{c['id']}/sconti", {"ammessi": True, "motivo": "PA", "versione": c["versione"]})
    p = admin.put(f"/api/preventivi/{p['id']}", {**p, "righe": righe}).json()
    assert [r["tariffa_applicata"] for r in p["righe"]] == [27000, 54000] and p["totale"] == 81000 and p["totale_standard"] == 90000


def test_stati_fissato_revisioni_annullamento(admin, base):
    p = nuovo(admin, base)
    r1, r2 = (r["id"] for r in p["righe"])
    p = segna_inviato(admin, p)
    assert p["stato"] == "inviato" and not p["modificabile"]
    assert admin.put(f"/api/preventivi/{p['id']}", {**p, "righe_da_togliere": [r1]}).json()["righe"].__len__() == 2  # dopo l'invio non si tolgono
    rev = admin.post(f"/api/preventivi/{p['id']}/revisione", {"versione": p["versione"]}).json()
    assert rev["etichetta"].endswith("rev. 1") and rev["stato"] == "creato" and rev["codice"] == p["codice"]
    assert admin.get(f"/api/preventivi/{p['id']}").json()["stato"] == "sostituito"
    assert admin.post(f"/api/preventivi/{p['id']}/righe/stato", {"righe": [r1], "stato": "accettata"}).status_code == 400  # superato
    rev = segna_inviato(admin, rev)
    righe_rev = [r["id"] for r in rev["righe"]]
    x = admin.post(f"/api/preventivi/{rev['id']}/righe/stato", {"righe": [righe_rev[0]], "stato": "accettata", "evidenza_accettazione": "Email di conferma del caso di collaudo", "versione": rev["versione"]}).json()
    assert x["stato"] == "accettato_parzialmente" and x["fissato"]
    x = admin.post(f"/api/preventivi/{rev['id']}/righe/stato", {"righe": [righe_rev[1]], "stato": "rifiutata"}).json()
    assert x["stato"] == "accettato_parzialmente" and x["totale"] == 30000  # una accettata e una rifiutata: parziale; la rifiutata non conta nel totale
    assert admin.post(f"/api/preventivi/{rev['id']}/revisione", {"versione": x["versione"]}).status_code == 400  # accettato: fissato
    assert admin.delete(f"/api/preventivi/{rev['id']}").status_code == 400
    r = admin.post(f"/api/preventivi/{rev['id']}/riesame", {"esito": "conforme", "requisiti_chiari": True})
    assert r.status_code == 400  # conforme solo con tutti i punti
    # R109: un riesame non conforme resta nello storico anche dopo quello conforme successivo.
    x = admin.post(f"/api/preventivi/{rev['id']}/riesame", {"esito": "non_conforme", "note": "Tempi non compatibili: concordare la data"}).json()
    assert x["riesame"]["esito"] == "non_conforme" and len(x["riesami"]) == 1
    x = admin.post(f"/api/preventivi/{rev['id']}/riesame", {"esito": "conforme", "requisiti_chiari": True, "competenza_strumenti": True,
                                                            "imparzialita": True, "tempi": True}).json()
    assert x["riesame"]["esito"] == "conforme"
    assert [r["esito"] for r in x["riesami"]] == ["conforme", "non_conforme"]
    assert x["riesami"][1]["note"].startswith("Tempi non compatibili") and all(r["eseguito_da"] and r["eseguito_il"] for r in x["riesami"])
    x = admin.post(f"/api/preventivi/{rev['id']}/annulla", {"motivo": "", "versione": x["versione"]})
    assert x.status_code == 400
    storico = [s["azione"] for s in admin.get(f"/api/storico/preventivo/{rev['id']}").json()]
    assert "preventivo.riesame" in storico and "preventivo.revisione" in storico


def test_elimina_bozza_e_scadenziario(admin, base):
    p = nuovo(admin, base, impianti=[base["impianti"][0]["id"]])
    sc = {r["id"]: r for r in admin.post("/api/griglie/scadenze/dati", {}).json()["righe"]}
    assert sc[base["impianti"][0]["id"]]["preventivo"] == p["codice"] and sc[base["impianti"][0]["id"]]["stato_riga"] == "In attesa"
    assert sc[base["impianti"][1]["id"]]["preventivo"] is None and not sc[base["impianti"][1]["id"]]["in_preventivo"]
    da_preventivare = admin.post("/api/griglie/scadenze/dati", {"filtri": [{"campo": "in_preventivo", "valore": "no"}]}).json()
    assert da_preventivare["totale"] == 1
    aperti = admin.get(f"/api/preventivi/aperti?cliente_id={base['cliente']['id']}").json()
    assert [a["id"] for a in aperti] == [p["id"]]
    x = admin.post(f"/api/preventivi/{p['id']}/impianti", {"impianti": [base["impianti"][1]["id"]], "versione": p["versione"]}).json()
    assert len(x["righe"]) == 2
    assert admin.delete(f"/api/preventivi/{p['id']}").status_code == 200
    assert admin.post("/api/griglie/preventivi/dati", {}).json()["totale"] == 0
    assert admin.post("/api/griglie/preventivi/dati", {"ricerca": "x"}).status_code == 200
    assert admin.post("/api/griglie/righe_preventivi/dati", {"ricerca": "x"}).status_code == 400
    assert admin.post("/api/griglie/righe_preventivi/dati", {"contesto": {"preventivo_id":p["id"]}}).status_code == 404


@pytest.mark.pdf_vero
def test_documento_word_e_pdf(admin, base):
    p = nuovo(admin, base)
    r = admin.post(f"/api/preventivi/{p['id']}/documenti", {"pdf": pdf.disponibile()})
    assert r.status_code == 200, r.text
    x = r.json()
    assert x["segnaposto_vuoti"] == []
    word = next(d for d in x["generati"] if d["formato"] == "docx")
    assert word["nome_file"].startswith(p["codice"]) and "Comune di Prova" in word["nome_file"]
    contenuto = admin.get(f"/api/preventivi/{p['id']}/documenti/{word['documento_id']}").content
    xml = zipfile.ZipFile(io.BytesIO(contenuto)).read("word/document.xml").decode("utf-8")
    assert "{{" not in xml and "Comune di Prova" in xml and "Scuola media" in xml and "€ 900,00" in xml and p["codice"] in xml
    piede = zipfile.ZipFile(io.BytesIO(contenuto)).read("word/footer1.xml").decode("utf-8")
    assert "rev. 04" in piede
    if pdf.disponibile():
        assert any(d["formato"] == "pdf" for d in x["generati"])


def test_invio_email(admin, base, monkeypatch, app):
    from gestionale.core import posta

    inviati = []
    monkeypatch.setattr(posta, "invia", lambda cfg, msg, tempo=40: inviati.append(msg) or "Accettato dal server prova")
    monkeypatch.setattr(pdf, "da_word", lambda docx, conf="": b"%PDF-1.4 prova")
    p = nuovo(admin, base)
    bozza = admin.get(f"/api/preventivi/{p['id']}/email").json()
    assert p["codice"] in bozza["oggetto"] and "€ 900,00" in bozza["testo"] and bozza["allegato"] is None
    email = {"a": "ufficio@comune.it", "cc": "", "oggetto": bozza["oggetto"], "testo": bozza["testo"]}
    r = admin.post(f"/api/preventivi/{p['id']}/email", email)
    assert r.status_code == 409 and "approva" in r.json()["errore"] and not inviati   # D80: prima la presa visione
    doc = admin.post(f"/api/preventivi/{p['id']}/anteprima").json()["documento"]
    admin.post(f"/api/preventivi/{p['id']}/documenti/{doc['pdf_documento_id']}/approva")
    assert admin.get(f"/api/preventivi/{p['id']}/email").json()["allegato"]["nome_file"] == doc["nome_file"]
    r = admin.post(f"/api/preventivi/{p['id']}/email", email)
    assert r.status_code == 200, r.text
    x = r.json()
    assert x["stato"] == "inviato" and x["invii"][0]["destinatari"] == "ufficio@comune.it"
    allegato = next(inviati[0].iter_attachments())
    assert allegato.get_filename() == doc["nome_file"]
    assert allegato.get_content() == admin.get(f"/api/preventivi/{p['id']}/documenti/{doc['pdf_documento_id']}").content  # proprio quello approvato


def test_permessi_preventivi(admin, app, base):
    p = nuovo(admin, base)
    tecnico = nuovo_utente(admin, app, "tecnico2", "tecnico")
    assert tecnico.get(f"/api/preventivi/{p['id']}").status_code == 403
    seg = nuovo_utente(admin, app, "segreteria2", "segreteria")
    assert seg.get(f"/api/preventivi/{p['id']}").status_code == 200
    assert seg.post(f"/api/preventivi/{p['id']}/annulla", {"motivo": "prova"}).status_code == 403  # annullare: solo admin di partenza
    rt = nuovo_utente(admin, app, "rt2", "responsabile_tecnico")
    assert rt.post(f"/api/preventivi/{p['id']}/riesame", {"esito": "conforme"}).status_code == 400  # ha il permesso, ma non è accettato


def test_cliente_con_solo_partita_iva_rifiutato():
    assert PIVA  # (controllo D48 in test_anagrafica)


# ---------------------------------------------------------------- 0.3.1: stampa (D58)

def test_stampa_riusa_rigenera_e_stampa_il_pdf_inviato(admin, base, monkeypatch):
    contatore = []
    monkeypatch.setattr(pdf, "da_word", lambda docx, conf="": contatore.append(1) or f"%PDF-1.4 prova {len(contatore)}".encode())
    p = nuovo(admin, base)
    prima = admin.post(f"/api/preventivi/{p['id']}/stampa").json()
    assert prima["generato"] is True and prima["motivo"] == "generato"
    # niente è cambiato: stesso PDF, nessuna nuova generazione
    di_nuovo = admin.post(f"/api/preventivi/{p['id']}/stampa").json()
    assert di_nuovo["generato"] is False and di_nuovo["documento_id"] == prima["documento_id"] and len(contatore) == 1
    # il PDF si apre nel browser (in linea) e senza CSP, che bloccherebbe il lettore PDF
    r = admin.get(f"/api/preventivi/{p['id']}/documenti/{prima['documento_id']}?in_linea=true")
    assert r.headers["content-disposition"].startswith("inline") and "content-security-policy" not in r.headers
    assert admin.get(f"/api/preventivi/{p['id']}/documenti/{prima['documento_id']}").headers["content-disposition"].startswith("attachment")
    # il preventivo cambia: nuovo PDF
    p = admin.get(f"/api/preventivi/{p['id']}").json()
    p = admin.put(f"/api/preventivi/{p['id']}", {**p, "note": "cambiata", "righe": [{"id": r["id"], "tipo_verifica": r["tipo_verifica"], "sconto": "0"} for r in p["righe"]]}).json()
    dopo = admin.post(f"/api/preventivi/{p['id']}/stampa").json()
    assert dopo["generato"] is True and dopo["documento_id"] != prima["documento_id"]
    # segnato come inviato e poi cambiato (es. riferimento d'ordine): si stampa sempre il PDF dell'invio
    p = segna_inviato(admin, p)
    p = admin.put(f"/api/preventivi/{p['id']}", {**p, "rif_ordine": "ORD-7", "righe": [{"id": r["id"], "tipo_verifica": r["tipo_verifica"], "sconto": "0"} for r in p["righe"]]}).json()
    inviato = admin.post(f"/api/preventivi/{p['id']}/stampa").json()
    assert inviato["motivo"] == "inviato" and inviato["documento_id"] == dopo["documento_id"] and inviato["generato"] is False


def test_stampa_permessi(admin, app, base, monkeypatch):
    monkeypatch.setattr(pdf, "da_word", lambda docx, conf="": b"%PDF-1.4 prova")
    p = nuovo(admin, base)
    tecnico = nuovo_utente(admin, app, "tecnico3", "tecnico")
    assert tecnico.post(f"/api/preventivi/{p['id']}/stampa").status_code == 403


def test_modello_rev04_e_passaggio_dalla_rev03(app, cfg):
    """0.4.0 (D60): rev. 04 «sicura per LibreOffice» (codice e revisione in calce, riquadro nella tabella delle firme, condizioni
    da pagina nuova); su un archivio che usa la rev. 03 di sistema la rev. 04 la sostituisce, un modello dell'utente no."""
    from sqlalchemy import select

    from gestionale.moduli.documenti import modelli_servizio as ms
    from gestionale.moduli.documenti.modelli import ModelloDocumento

    file = ms.CARTELLA_MODELLI / ms.REV04
    z = zipfile.ZipFile(file)
    piede = z.read("word/footer1.xml").decode("utf-8")
    assert "rev. 04 del 05.10.2026" in piede and "rev. 03" not in piede
    corpo = z.read("word/document.xml").decode("utf-8")
    assert "pageBreakBefore" in corpo and "cantSplit" in corpo and "tblHeader" in corpo
    arc = app.state.archivio
    with arc.lettura() as s:
        m = s.execute(select(ModelloDocumento).where(ModelloDocumento.tipo == "preventivo", ModelloDocumento.in_uso.is_(True))).scalar()
        assert m.revisione == "04"
    # archivio della 0.3.x: rev. 03 di sistema in uso → la rev. 04 la sostituisce
    with arc.scrittura() as s:
        m04 = s.execute(select(ModelloDocumento).where(ModelloDocumento.revisione == "04")).scalar()
        doc = ms.documenti.salva(s, cfg.cartella_documenti, (ms.CARTELLA_MODELLI / "M01-RG01_dpr_Offerta_rev.03.docx").read_bytes(),
                                 "rev03.docx", ms.DOCX)
        s.delete(m04)
        s.flush()
        s.add(ModelloDocumento(tipo="preventivo", codice="M01-RG01_dpr", revisione="03", documento_id=doc.id, in_uso=True, caricato_da="Sistema"))
    with arc.scrittura() as s:
        ms.prepara(s, cfg)
    with arc.lettura() as s:
        assert s.execute(select(ModelloDocumento).where(ModelloDocumento.tipo == "preventivo", ModelloDocumento.in_uso.is_(True))).scalar().revisione == "04"


def test_o15_sconto_dopo_invio_con_revisione(admin, base):
    p = nuovo(admin, base)
    r1 = p["righe"][0]["id"]
    p = segna_inviato(admin, p)
    r = admin.post(f"/api/preventivi/{p['id']}/sconto-revisione", {"versione": p["versione"], "sconti": {str(r1): "10"}})
    assert r.status_code == 400 and "bloccati" in r.json()["errore"]
    c = admin.get(f"/api/clienti/{base['cliente']['id']}").json()
    admin.post(f"/api/clienti/{c['id']}/sconti", {"ammessi": True, "motivo": "PA", "versione": c["versione"]})
    rev = admin.post(f"/api/preventivi/{p['id']}/sconto-revisione", {"versione": p["versione"], "sconti": {str(r1): "10"}}).json()
    assert rev["etichetta"].endswith("rev. 1") and rev["stato"] == "creato" and rev["data"] == date.today().isoformat()
    assert [x["tariffa_applicata"] for x in rev["righe"]] == [27000, 60000]
    vecchio = admin.get(f"/api/preventivi/{p['id']}").json()
    assert vecchio["stato"] == "sostituito" and vecchio["totale"] == 90000   # il prezzo inviato resta com'era
    # dopo l'accettazione: niente
    rev = segna_inviato(admin, rev)
    rev = admin.post(f"/api/preventivi/{rev['id']}/righe/stato", {"righe": [x["id"] for x in rev["righe"]], "stato": "accettata", "evidenza_accettazione": "Email di conferma del caso di collaudo", "versione": rev["versione"]}).json()
    r = admin.post(f"/api/preventivi/{rev['id']}/sconto-revisione", {"versione": rev["versione"], "sconti": {str(rev["righe"][0]["id"]): "20"}})
    assert r.status_code == 400 and "accettazione" in r.json()["errore"]
