"""Lo switch è navigazione, non isolamento contabile o autorizzazione."""
from conftest import nuovo_utente


def menu(html):
    return html.split('<nav aria-label="Menu principale">', 1)[1].split('</nav>', 1)[0]


def test_selettore_tre_menu_stesso_archivio(admin):
    r = admin.post('/api/clienti', {'ragione_sociale': 'Cliente condiviso', 'tipo': 'privato', 'comune_istat': '001272', 'codice_fiscale': '01234567897', 'partita_iva': '01234567897'})
    assert r.status_code == 200, r.text
    c = r.json()
    for ambito, presente, assente in [('DM', '/verifiche-gvr', '/fatture'),
                                      ('IEC', '/clienti', '/preventivi-dm'),
                                      ('DPR', '/fatture', '/verifiche-gvr')]:
        r = admin.post('/api/ambito-attivo', {'ambito': ambito})
        assert r.status_code == 200, r.text
        assert r.json()['url'] == {'DPR': '/ad-dpr', 'DM': '/ad-dm', 'IEC': '/iec'}[ambito]
        html = admin.get('/').text
        assert f'data-ambito="{ambito}"' in html
        assert f'href="{presente}"' in menu(html)
        assert f'href="{assente}"' not in menu(html)
        assert admin.get(f"/api/clienti/{c['id']}").json()['ragione_sociale'] == 'Cliente condiviso'
    admin.post('/api/ambito-attivo', {'ambito': 'IEC'})
    assert 'Area operativa ancora da realizzare' in admin.get('/').text


def test_collegamenti_operativi_e_pagine_comuni(admin):
    admin.post('/api/ambito-attivo', {'ambito': 'IEC'})
    assert 'data-ambito="DM"' in admin.get('/incarichi-dm').text
    assert 'data-ambito="DM"' in admin.get('/clienti').text
    assert 'data-ambito="DPR"' in admin.get('/fatture').text
    assert 'data-ambito="DPR"' in admin.get('/sedi').text
    admin.c.cookies.set('gad_ambito', 'arbitrario')
    assert 'data-ambito="DPR"' in admin.get('/').text


def test_selettore_richiede_sessione_csrf_e_valore_valido(admin):
    assert admin.c.post('/api/ambito-attivo', json={'ambito': 'DM'}).status_code == 403
    for valore in ['ALTRO', [], None, 1]:
        assert admin.post('/api/ambito-attivo', {'ambito': valore}).status_code == 400
    admin.post('/api/uscita')
    assert admin.post('/api/ambito-attivo', {'ambito': 'DPR'}).status_code == 401


def test_cambiare_ambito_non_conferisce_permessi(admin, app):
    tecnico = nuovo_utente(admin, app, 'tecnicoarea', 'segreteria')   # R132: ruolo comune, vede le tre attività
    for ambito in ['DPR', 'DM', 'IEC']:
        assert tecnico.post('/api/ambito-attivo', {'ambito': ambito}).status_code == 200
        assert tecnico.get('/api/utenti/1').status_code == 403
        assert 'href="/utenti"' not in menu(tecnico.get('/').text)


def test_ingressi_distinti_selezionano_attivita_senza_cambiare_backend(admin):
    for url, ambito in [('/ad-dpr', 'DPR'), ('/ad-dm', 'DM'), ('/iec', 'IEC')]:
        assert f'data-ambito="{ambito}"' in admin.get(url).text
        assert f'data-ambito="{ambito}"' in admin.get('/clienti').text
