"""0.12.8 · N8 preventivo DM dalle scadenze (Garda `gi_scadenze_preventivi_crea`); N9 PVP e colonna di tariffa;
AD-13 sconto predefinito del cliente AD_DM."""

from __future__ import annotations

import pytest
from test_anagrafica import PIVA_2, crea_cliente, crea_sede
from test_beni import ok, scad
from test_dm_preventivi import gvr


@pytest.fixture
def sede_dm(admin):
    c = crea_cliente(admin, ragione_sociale="Caldaie Prova S.r.l.", partita_iva=PIVA_2, codice_fiscale=PIVA_2, ambiti=["DM"])
    c = ok(admin.put(f"/api/clienti/{c['id']}", {**c, "sconto_dm": "15"}))
    assert c["sconto_dm"] == 15
    return crea_sede(admin, c["id"], denominazione="Centrale termica")


def _scadenze(admin, **filtri):
    corpo = {"filtri": [{"campo": k, "valore": v} for k, v in filtri.items()], "dimensione": 200}
    return ok(admin.post("/api/griglie/scadenze_dm/dati", corpo))["righe"]


def test_una_riga_per_scadenza_e_copertura(admin, sede_dm):
    a = gvr(admin, sede_dm, dati_dm={"tipo_prox_verifica": "V2"})
    a = scad(admin, a, "funzionamento", data_ultima="2024-07-01", data_prossima="2026-07-01")
    a = scad(admin, a, "integrita", data_ultima="2016-07-01", data_prossima="2026-09-01")
    a = scad(admin, a, "cnd", data_ultima="2016-07-01", data_prossima="2026-09-01")
    righe = _scadenze(admin, matr_informale="GVR-001")
    da = {r["componente"]: r for r in righe}
    assert da["Funzionamento"]["da_preventivare"] == "Sì" and da["CND"]["da_preventivare"] == "No"
    # R129: CND è attività EX, non va nel preventivo DM (solo allegato VII D.Lgs. 81/08)
    assert (da["Funzionamento"]["regime"], da["CND"]["regime"]) == ("DM all. VII", "EX")
    r = admin.post("/api/dm/preventivi/da-scadenze", {"scadenze": [da["CND"]["id"]]})
    assert r.status_code == 400 and "attività EX" in r.json()["errore"]
    out = ok(admin.post("/api/dm/preventivi/da-scadenze", {"scadenze": [da["Funzionamento"]["id"], da["Integrità"]["id"]],
                                                         "data": "2026-10-11"}))
    assert len(out["preventivi"]) == 1 and out["preventivi"][0]["righe"] == 2
    p = ok(admin.get(f"/api/preventivi/{out['preventivi'][0]['id']}"))
    # due righe distinte, mai combinate; sconto predefinito del cliente (AD-13); colonna di tariffa visibile
    assert sorted(r["tipo_verifica_gvr"] for r in p["righe"]) == ["funz", "integrita"]
    assert {r["sconto"] for r in p["righe"]} == {15}
    assert {r["dettaglio"][0]["colonna"] for r in p["righe"]} == {"V3", "V4"}
    # ora sono coperte
    da = {r["componente"]: r for r in _scadenze(admin, matr_informale="GVR-001")}
    assert da["Funzionamento"]["preventivo"] and da["Funzionamento"]["da_preventivare"] == "No"
    r = admin.post("/api/dm/preventivi/da-scadenze", {"scadenze": [da["Funzionamento"]["id"]]})
    assert r.status_code == 409 or "preventivat" in r.json()["errore"]
    # combinazione scelta a mano su una riga: la riga doppia della stessa attrezzatura si segnala con il suo numero
    riga_funz = next(r for r in p["righe"] if r["tipo_verifica_gvr"] == "funz")
    r = admin.put(f"/api/preventivi/{p['id']}", {"versione": p["versione"], "righe": [{"id": riga_funz["id"], "tipo_verifica_gvr": "funz_integrita"}]})
    assert r.status_code == 409 and "togli prima quella riga" in r.json()["errore"]


def test_prima_periodica_dalla_scadenza_piu_vicina_e_messa_in_servizio(admin, sede_dm):
    a = gvr(admin, sede_dm, matricola="GVR-PVP", dati_dm={"tipo_prox_verifica": "V1"}, soggetto_messa_servizio=None)
    a = scad(admin, a, "funzionamento", data_prossima="2026-08-01")
    a = scad(admin, a, "integrita", data_prossima="2027-08-01")
    da = {r["componente"]: r for r in _scadenze(admin, matr_informale="GVR-PVP")}
    assert da["Funzionamento"]["tipo_prox_verifica"] == "Prima periodica"
    # N9: PVP GVR senza «soggetta a messa in servizio» → blocco, non più colonna V2 in silenzio
    r = admin.post("/api/dm/preventivi/da-scadenze", {"scadenze": [da["Funzionamento"]["id"]]})
    assert r.status_code == 400 and "art. 4" in r.json()["errore"]
    a = ok(admin.get(f"/api/beni/{a['id']}"))
    ok(admin.put(f"/api/beni/{a['id']}", {"versione": a["versione"], "soggetto_messa_servizio": True}))
    out = ok(admin.post("/api/dm/preventivi/da-scadenze", {"scadenze": [da["Funzionamento"]["id"], da["Integrità"]["id"]]}))
    p = ok(admin.get(f"/api/preventivi/{out['preventivi'][0]['id']}"))
    tipi = {r["tipo_verifica_gvr"]: (r["tipo_verifica_dm"], r["dettaglio"][0]["colonna"]) for r in p["righe"]}
    # AD-40: la scadenza più vicina eredita «prima periodica», l'altra è successiva
    assert tipi == {"funz": ("V1", "V1"), "integrita": ("V2", "V4")}



def test_un_preventivo_per_sede_e_preventivo_indicato(admin, app, sede_dm):
    from gestionale.moduli.preventivi.modelli import Preventivo

    altra = crea_sede(admin, sede_dm["cliente_id"], denominazione="Magazzino", indirizzo="Via Dora 9")
    a = scad(admin, gvr(admin, sede_dm, matricola="GVR-S1", dati_dm={"tipo_prox_verifica": "V2"}), "funzionamento", data_prossima="2026-11-01")
    scad(admin, a, "integrita", data_prossima="2026-12-01")
    scad(admin, gvr(admin, altra, matricola="GVR-S2", dati_dm={"tipo_prox_verifica": "V2"}), "funzionamento", data_prossima="2026-11-01")
    da = {r["matr_informale"] + r["componente"]: r["id"] for r in _scadenze(admin) if r["matr_informale"] in ("GVR-S1", "GVR-S2")}
    # due sedi: un preventivo per sede (il preventivo DM è della sede)
    out = ok(admin.post("/api/dm/preventivi/da-scadenze", {"scadenze": [da["GVR-S1Funzionamento"], da["GVR-S2Funzionamento"]]}))
    assert [x["righe"] for x in out["preventivi"]] == [1, 1] and len({x["id"] for x in out["preventivi"]}) == 2
    primo = next(x for x in out["preventivi"] if ok(admin.get(f"/api/preventivi/{x['id']}"))["sede_id"] == sede_dm["id"])
    # preventivo indicato: le righe si aggiungono a quello, se è «creato» e della stessa sede
    out = ok(admin.post("/api/dm/preventivi/da-scadenze", {"scadenze": [da["GVR-S1Integrità"]], "preventivo": primo["codice"]}))
    assert out["preventivi"][0]["id"] == primo["id"] and len(ok(admin.get(f"/api/preventivi/{primo['id']}"))["righe"]) == 2
    with app.state.archivio.scrittura() as s:
        s.get(Preventivo, primo["id"]).stato = "inviato"
    scad(admin, gvr(admin, sede_dm, matricola="GVR-S3", dati_dm={"tipo_prox_verifica": "V2"}), "funzionamento", data_prossima="2026-11-01")
    sid = next(r["id"] for r in _scadenze(admin, matr_informale="GVR-S3") if r["componente"] == "Funzionamento")
    r = admin.post("/api/dm/preventivi/da-scadenze", {"scadenze": [sid], "preventivo": primo["codice"]})
    assert r.status_code == 400 and "«creato»" in r.json()["errore"]



def test_attrezzatura_esente_o_iso17020_e_ex(admin, sede_dm):
    """R129 (0.12.9): un'attrezzatura esente o in regime volontario ISO 17020 non va nel preventivo DM."""
    for valore in ("T", "I"):
        a = scad(admin, gvr(admin, sede_dm, matricola=f"GVR-E{valore}", dati_dm={"tipo_prox_verifica": "V2", "esente_verifiche": valore}),
                 "funzionamento", data_prossima="2026-11-01")
        riga = next(r for r in _scadenze(admin, matr_informale=f"GVR-E{valore}") if r["componente"] == "Funzionamento")
        assert (riga["regime"], riga["da_preventivare"]) == ("EX", "No")
        r = admin.post("/api/dm/preventivi/da-scadenze", {"scadenze": [riga["id"]]})
        assert r.status_code == 400 and "attività EX" in r.json()["errore"]
        del a
