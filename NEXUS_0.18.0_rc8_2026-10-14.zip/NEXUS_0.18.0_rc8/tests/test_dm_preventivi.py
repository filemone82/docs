"""Percorso DM commerciale e riscontri indipendenti dal backup adsrl.

Tariffe attese: tariffe_gvr/id_spec=40 (249.40,266.37,145.28,145.28),
tariffe_sc_sp/compat=9 (311.17,184.04). Fonti _custom.php 2926–2992.
"""
import json
from decimal import Decimal
from pathlib import Path

import pytest
from sqlalchemy import select

from conftest import segna_inviato
from test_anagrafica import crea_cliente, crea_sede
from test_beni import nuovo, ok, modifica
from gestionale.moduli.dm.modelli import TariffaDM


@pytest.fixture
def sede(admin):
    return crea_sede(admin, crea_cliente(admin)["id"])


def gvr(admin, sede, matricola="GVR-001", **extra):
    return nuovo(admin,sede,"GVR",matricola,tipo_attr_id=18,tipo_attr_gvr_id=1,id_spec_id=40,**extra)


def gv(admin, sede, matricola="GV-001", **extra):
    """Generatore di vapore (tipo Garda 24, famiglia a2): l'unica famiglia, con a3, che ha la visita interna (DM-07)."""
    return nuovo(admin,sede,"GVR",matricola,tipo_attr_id=24,tipo_attr_gvr_id=2,id_spec_id=52,**extra)


def offerta(admin, sede, a, tipo="V2", combinazione="funz", **extra):
    return admin.post('/api/preventivi',{'ambito':'DM','sede_id':sede['id'],
        'attrezzature':[{'asset_id':a['id'],'tipo_verifica_dm':tipo,'tipo_verifica_gvr':combinazione}],**extra})


def leggi(admin,p):
    return ok(admin.get(f"/api/preventivi/{p['id']}"))


def test_matricola_regole_garda_e_zero_iniziale(admin,sede):
    a=gvr(admin,sede)
    assert a['num_matricola']=='00001'
    for key,v in [('cod_att_matricola','AB'),('num_matricola','1'),('prov_immatr','T1'),('anno_matricola','200A')]:
        assert admin.put(f"/api/beni/{a['id']}",{'versione':a['versione'],key:v}).status_code==400
    assert ok(admin.get(f"/api/beni/{a['id']}"))['versione']==a['versione']


def test_attributi_tecnici_validati_e_testi_conservati(admin,sede):
    a=gvr(admin,sede,dati_dm={'esente_verifiche':'I','tipo_prox_verifica':'V2','ps_attr_gvr':'1,5 / 6 bar',
                            'cat_ped':'III','matr_insieme':'2020/A/00001/TO'})
    assert a['attributi']['ps_attr_gvr']=='1,5 / 6 bar'
    assert offerta(admin,sede,a).status_code==400
    assert admin.put(f"/api/beni/{a['id']}",{'versione':a['versione'],'dati_dm':{'cat_ped':'V'}}).status_code==400
    assert admin.put(f"/api/beni/{a['id']}",{'versione':a['versione'],'dati_dm':{'portata_attr_sc_sp':'10'}}).status_code==400


def test_tariffe_tutte_le_righe_e_provenienze(admin,app):
    raw=json.loads((Path(__file__).parents[1]/'gestionale/migrazioni/versions/0012_tariffe_garda.json').read_text(encoding='utf-8'))
    with app.state.archivio.lettura() as s:
        ts=s.scalars(select(TariffaDM).order_by(TariffaDM.id)).all()
        assert len(ts)==314
        for t in ts:
            r=json.loads(t.origine_json)
            source='tariffe_gvr' if t.gruppo=='GVR' else 'tariffe_sc_sp'
            assert r in raw[source]
            assert t.importo==int(Decimal(str(r['tariffa_std']))*100)


@pytest.mark.parametrize('tipo,messa,comb,colonna,prezzo',[
    ('V1',True,'funz','V1',24940),('V1',False,'funz','V2',26637),
    ('V2',True,'funz','V3',14528),('V2',True,'interna','V3',14528),
    ('V2',True,'integrita','V4',14528),('V2',True,'funz_integrita','V4',14528),
    ('V2',True,'funz_integrita_interna','V4',14528)])
def test_scelta_colonna_gvr_come_garda(admin,sede,app,tipo,messa,comb,colonna,prezzo):
    if 'interna' in comb:
        # La visita interna esiste solo per GV/INS GV: stessa scelta di colonna, tariffa della specifica del generatore.
        from gestionale.moduli.dm.modelli import TariffaDM
        from sqlalchemy import select
        a=gv(admin,sede,soggetto_messa_servizio=messa)
        with app.state.archivio.lettura() as s:
            prezzo=s.scalar(select(TariffaDM.importo).where(TariffaDM.gruppo=='GVR',TariffaDM.id_spec_id==52,TariffaDM.tipo==colonna))
        assert prezzo
    else:
        a=gvr(admin,sede,soggetto_messa_servizio=messa)
    p=ok(offerta(admin,sede,a,tipo,comb))
    assert p['righe'][0]['tariffa_standard']==prezzo
    assert p['righe'][0]['dettaglio'][0]['colonna']==colonna


def test_sede_obbligatoria_e_filtro_dm(admin,sede):
    a=gvr(admin,sede)
    s2=crea_sede(admin,sede['cliente_id'],denominazione='Seconda sede')
    assert offerta(admin,s2,a).status_code==400
    assert admin.post('/api/preventivi',{'ambito':'DM','cliente_id':sede['cliente_id']}).status_code==400
    p=ok(offerta(admin,sede,a))
    assert admin.post(f"/api/preventivi/{p['id']}/impianti",{'versione':p['versione'],'impianti':[1]}).status_code==400


def test_componente_gvr_separata_e_blocco_sovrapposizioni(admin,sede):
    a=gvr(admin,sede)
    p=ok(offerta(admin,sede,a,combinazione='funz'))
    assert offerta(admin,sede,a,combinazione='funz_integrita').status_code==409
    assert offerta(admin,sede,a,combinazione='integrita').status_code==200
    assert admin.post(f"/api/preventivi/{p['id']}/annulla",{'versione':p['versione'],'motivo':'Prova'}).status_code==200
    assert offerta(admin,sede,a,combinazione='funz').status_code==200


def test_tubazione_senza_visita_interna_in_offerta(admin,sede):
    cat=ok(admin.get('/api/beni/cataloghi'))
    spec=next(x['id_spec_id'] for x in cat['compatibilita'] if x['gruppo']=='GVR' and x['famiglia_gvr_id']==4)
    a=nuovo(admin,sede,'GVR',tipo_attr_id=27,tipo_attr_gvr_id=4,id_spec_id=spec)
    assert offerta(admin,sede,a,combinazione='interna').status_code==400
    assert offerta(admin,sede,a,combinazione='funz_interna').status_code==400
    # DM-07: anche un recipiente (famiglia a1) non ha visita interna; un generatore di vapore sì.
    r=gvr(admin,sede,'REC-INT')
    assert offerta(admin,sede,r,combinazione='funz_interna').status_code==400
    assert offerta(admin,sede,gv(admin,sede),combinazione='funz_interna').status_code==200


def test_word_originale_dm_accettazione_riesame_fotografie(admin,sede,app):
    a=gvr(admin,sede,dati_dm={'descr_attr':'Recipiente collaudo','rif_interno':'R-01'})
    p=ok(offerta(admin,sede,a))
    # Il modello DM viene effettivamente compilato: nessun segnaposto lasciato vuoto.
    from gestionale.moduli.preventivi import servizio as pv
    from gestionale.core import word
    with app.state.archivio.lettura() as s:
        prep=pv.prepara_documento(s,app.state.archivio.cfg,p['id'])
        compiled=pv.compila_documento(prep,False)
    assert compiled['mancanti']==[]
    assert word.segnaposto(compiled['docx'])==[]
    assert prep['nome_docx'].startswith('Preventivo 1-')
    p=segna_inviato(admin,p)
    assert admin.post(f"/api/preventivi/{p['id']}/righe/stato",{'versione':p['versione'],'righe':[p['righe'][0]['id']],'stato':'accettata'}).status_code==400
    p=ok(admin.post(f"/api/preventivi/{p['id']}/righe/stato",{'versione':p['versione'],'righe':[p['righe'][0]['id']],'stato':'accettata','evidenza_accettazione':'Mail di conferma del collaudo'}))
    assert ok(admin.get('/api/dm/incarichi'))==[]
    dati={'esito':'conforme','requisiti_chiari':True,'competenza_strumenti':True,'imparzialita':True,'tempi':True}
    ok(admin.post(f"/api/preventivi/{p['id']}/riesame",dati))
    r=admin.post(f"/api/preventivi/{p['id']}/riesame",dati)  # N5 (0.12.8): senza cambiamenti il riesame non si ripete
    assert r.status_code==400 and 'non si ripete' in r.json()['errore']
    xs=ok(admin.get('/api/dm/incarichi'))
    assert len(xs)==1 and xs[0]['asset_id']==a['id']
    a=modifica(admin,a,dati_dm={'descr_attr':'Descrizione corrente nuova'})
    with app.state.archivio.lettura() as s:
        frozen=pv.prepara_documento(s,app.state.archivio.cfg,p['id'])
    assert frozen['elenchi_dm']['gvr'][0]['descr_attr']=='Recipiente collaudo'
    after=leggi(admin,p)
    assert admin.put(f"/api/preventivi/{p['id']}",{'versione':after['versione'],'righe':[{'id':p['righe'][0]['id'],'tipo_verifica_gvr':'integrita'}]}).json()['righe'][0]['tipo_verifica_gvr']=='funz'


def test_licenza_opzionale_e_revisioni_preservate(admin,sede,app):
    a=gvr(admin,sede);p=ok(offerta(admin,sede,a))
    p=ok(admin.put(f"/api/preventivi/{p['id']}",{'versione':p['versione'],'lic_gest':True,'prezzo_licenza':'80,00'}))
    assert p['totale']==14528+8000
    p=segna_inviato(admin,p)
    rev=ok(admin.post(f"/api/preventivi/{p['id']}/revisione",{'versione':p['versione']}))
    assert rev['ambito']=='DM' and rev['sede_id']==sede['id'] and rev['lic_gest']
    assert rev['righe'][0]['asset_id']==a['id'] and rev['prezzo_licenza']==8000


def test_quote_dm_scsp_tariffe_e_sconti_garda(admin,sede):
    a=nuovo(admin,sede,'SC',tipo_attr_id=1,id_spec_id=6)
    p=ok(offerta(admin,sede,a,'V1',''))
    assert p['totale']==31117
    p=ok(admin.put(f"/api/preventivi/{p['id']}",{'versione':p['versione'],'righe':[{'id':p['righe'][0]['id'],'sconto':'12,5'}]}))
    # gi_bcdiv/gi_bcmul arrotondano half-up: 12,5/100 -> 0,13; 311,17*0,87 -> 270,72.
    assert p['righe'][0]['tariffa_applicata']==27072


def test_migrazione_0011_preserva_beni_e_documenti_dpr(admin, app, cfg, tmp_path, sede):
    import sqlite3
    from alembic import command
    from gestionale.app import prepara_archivio
    from gestionale.core import migrazioni
    from gestionale.core.config import Config
    from test_anagrafica import crea_impianto
    a=gvr(admin,sede,dati_dm={'ps_attr_gvr':'16','tipo_prox_verifica':'V2'},attributi={'nota_origine':'conservare'})
    a=ok(admin.post(f"/api/beni/{a['id']}/camere", {'versione':a['versione'],'identificazione':'C1','unita':'L','valore':'20,5','dati_tecnici':{'gvr_ps':'16'}}))
    imp=crea_impianto(admin,sede['id'])
    pp=ok(admin.post('/api/preventivi',{'cliente_id':sede['cliente_id'],'impianti':[imp['id']]}))
    segna_inviato(admin,pp)
    old=Config(cartella_dati=tmp_path/'archivio_0011',backup_automatico=False,iterazioni_password=1000)
    old.prepara_cartelle()
    command.upgrade(migrazioni.config_alembic(f"sqlite:///{old.percorso_database}"),'0011')
    snapshots={}
    with sqlite3.connect(cfg.percorso_database) as src, sqlite3.connect(old.percorso_database) as dst:
        tables=[x[0] for x in dst.execute("SELECT name FROM sqlite_master WHERE type='table'") if x[0]!='alembic_version' and not x[0].startswith('sqlite_')]
        for t in tables:
            cols=[x[1] for x in dst.execute(f'PRAGMA table_info("{t}")')]
            names=','.join(f'"{x}"' for x in cols)
            rows=src.execute(f'SELECT {names} FROM "{t}" ORDER BY rowid').fetchall()
            dst.execute(f'DELETE FROM "{t}"')
            dst.executemany(f'INSERT INTO "{t}" ({names}) VALUES ({",".join("?" for x in cols)})',rows)
            snapshots[t]=(names,rows)
    arc=prepara_archivio(old)
    try:
        with arc.motore.connect() as c:
            assert c.exec_driver_sql('PRAGMA foreign_key_check').all()==[]
            for t,(names,rows) in snapshots.items():
                restored=[tuple(x) for x in c.exec_driver_sql(f'SELECT {names} FROM "{t}" ORDER BY rowid')]
                assert (restored[:len(rows)] if t=="registro_operazioni" else restored)==rows,t
            assert c.exec_driver_sql("SELECT ambito,serie FROM preventivi").all()==[('DPR',str(pp['anno']))]
            assert c.exec_driver_sql('SELECT count(*) FROM dm_tariffe').scalar()==314
        assert any('pre_aggiornamento' in x.name for x in old.cartella_backup.iterdir())
    finally:
        arc.chiudi()


def test_riavvio_non_riattiva_modello_dm_disattivato(admin,app,cfg):
    from gestionale.app import prepara_archivio
    from gestionale.moduli.documenti.modelli import ModelloDocumento
    with app.state.archivio.scrittura() as s:
        m=s.scalar(select(ModelloDocumento).where(ModelloDocumento.tipo=='preventivo_dm'))
        m.in_uso=False
    # Stesso archivio, senza duplicare il seed o alterare una scelta sui modelli.
    arc=prepara_archivio(cfg)
    try:
        with arc.lettura() as s:
            ms=s.scalars(select(ModelloDocumento).where(ModelloDocumento.tipo=='preventivo_dm')).all()
            assert len(ms)==1 and not ms[0].in_uso
    finally:
        arc.chiudi()


def test_modifica_riga_non_duplica_attivita_stesso_preventivo(admin,sede):
    a=gvr(admin,sede)
    p=ok(offerta(admin,sede,a))
    p=ok(admin.post(f"/api/dm/preventivi/{p['id']}/attrezzature",{'versione':p['versione'],'attrezzature':[{'asset_id':a['id'],'tipo_verifica_dm':'V2','tipo_verifica_gvr':'integrita'}]}))
    rid=p['righe'][0]['id']
    assert admin.put(f"/api/preventivi/{p['id']}",{'versione':p['versione'],'righe':[{'id':rid,'tipo_verifica_gvr':'funz_integrita'}]}).status_code==409
    assert leggi(admin,p)['righe'][0]['tipo_verifica_gvr']=='funz'


@pytest.mark.parametrize('licenza',[False,True])
def test_word_dm_clausola_licenza_e_somma_reali(admin,sede,app,licenza):
    from io import BytesIO
    from zipfile import ZipFile
    from lxml import etree
    from gestionale.moduli.preventivi import servizio as pv
    a=gvr(admin,sede)
    p=ok(offerta(admin,sede,a))
    if licenza:
        p=ok(admin.put(f"/api/preventivi/{p['id']}",{'versione':p['versione'],'lic_gest':True,'prezzo_licenza':'80,00'}))
    with app.state.archivio.lettura() as s:
        prep=pv.prepara_documento(s,app.state.archivio.cfg,p['id'])
        compiled=pv.compila_documento(prep,False)
    xml=etree.fromstring(ZipFile(BytesIO(compiled['docx'])).read('word/document.xml'))
    text=' '.join(xml.itertext())
    assert ('licenza valida 12 mesi' in text)==licenza
    assert '{{' not in text
    assert ('225,28' if licenza else '145,28') in text
