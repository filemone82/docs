"""Griglia comune: filtri, ordinamento, esportazione delle colonne visibili, configurazioni, velocità."""

from __future__ import annotations

import io
import time
from datetime import datetime, timedelta

import pytest
from openpyxl import load_workbook
from sqlalchemy import insert

from conftest import nuovo_utente
from gestionale.core import griglia as motore
from gestionale.core.errori import ErroreUtente
from gestionale.moduli.registro.modelli import RegistroOperazione


def _col(tipo):
    return motore.Colonna("x", "Colonna", tipo)


@pytest.mark.parametrize("tipo,testo,atteso", [
    ("numero", "100", ("confronto", "=", 100.0)),
    ("numero", ">=1.234,5", ("confronto", ">=", 1234.5)),
    ("numero", "10..20", ("tra", 10.0, 20.0)),
    ("importo", ">150", ("confronto", ">", 15000)),
    ("testo", "Rossi", ("contiene", "Rossi")),
])
def test_interpretazione_filtri(tipo, testo, atteso):
    c = motore.interpreta(_col(tipo), testo)
    if c.tipo == "contiene":
        assert (c.tipo, c.valore) == atteso
    elif c.tipo == "tra":
        assert (c.tipo, c.valore, c.fino) == atteso
    else:
        assert (c.tipo, c.operatore, c.valore) == atteso


def test_filtri_data():
    c = motore.interpreta(_col("data"), "04/10/2026")
    assert (c.valore.isoformat(), c.fino.isoformat()) == ("2026-10-04", "2026-10-05")
    c = motore.interpreta(_col("data"), "12/2026")
    assert (c.valore.isoformat(), c.fino.isoformat()) == ("2026-12-01", "2027-01-01")
    c = motore.interpreta(_col("data"), ">2025")
    assert c.operatore == ">=" and c.valore.isoformat() == "2026-01-01"
    assert motore.interpreta(_col("data"), "vuoto").tipo == "vuoto"


def test_filtro_non_valido_spiega_cosa_scrivere():
    with pytest.raises(ErroreUtente, match="scrivi una data"):
        motore.interpreta(_col("data"), "ieri")
    with pytest.raises(ErroreUtente, match="scrivi un numero"):
        motore.interpreta(_col("numero"), "tanti")


def test_griglia_filtra_ordina_e_pagina(admin, app):
    for nome in ("anna", "bruno", "carla"):
        nuovo_utente(admin, app, nome, "segreteria")
    r = admin.post("/api/griglie/utenti/dati", {"dimensione": 25, "ordinamenti": [{"campo": "username", "direzione": "desc"}]}).json()
    assert [x["username"] for x in r["righe"]] == ["federico", "carla", "bruno", "anna"]
    r = admin.post("/api/griglie/utenti/dati", {"filtri": [{"campo": "ruolo", "valore": "segret"}]}).json()
    assert r["totale"] == 3
    r = admin.post("/api/griglie/utenti/dati", {"filtri": [{"campo": "email", "valore": "vuoto"}]}).json()
    assert r["totale"] == 4
    r = admin.post("/api/griglie/utenti/dati", {"ricerca": "carl"}).json()
    assert r["totale"] == 1
    r = admin.post("/api/griglie/utenti/dati", {"filtri": [{"campo": "creato_il", "valore": "x"}]})
    assert r.status_code == 400
    r = admin.post("/api/griglie/utenti/dati", {"filtri": [{"campo": "inesistente", "valore": "x"}]})
    assert r.status_code == 400


def test_filtro_con_caratteri_speciali_non_rompe_la_ricerca(admin):
    r = admin.post("/api/griglie/registro/dati", {"ricerca": "100%_'\"--"})
    assert r.status_code == 200 and r.json()["totale"] == 0


def test_esportazione_solo_colonne_visibili_e_filtri(admin, app):
    nuovo_utente(admin, app, "anna", "segreteria")
    r = admin.post("/api/griglie/utenti/esporta", {"colonne": ["nome", "ruolo"], "filtri": [{"campo": "ruolo", "valore": "segreteria"}]})
    assert r.status_code == 200
    ws = load_workbook(io.BytesIO(r.content)).active
    righe = list(ws.iter_rows(values_only=True))
    assert righe[0] == ("Nome e cognome", "Ruoli")  # 0.16 (R143): più ruoli per utente
    assert righe[1:] == [("Anna", "Segreteria")]
    registro = admin.post("/api/griglie/registro/dati", {"ricerca": "Esportati"}).json()
    assert registro["totale"] == 1 and "1 righe" in registro["righe"][0]["descrizione"]


def test_configurazioni_salvate_per_utente(admin, app):
    dati = {"colonne": [{"campo": "nome", "visibile": True}], "filtri": [], "ordinamenti": []}
    a = admin.post("/api/griglie/utenti/configurazioni", {"nome": "Solo nomi", "dati": dati, "predefinita": True}).json()
    b = admin.post("/api/griglie/utenti/configurazioni", {"nome": "Altra", "dati": dati, "predefinita": True}).json()
    elenco = admin.get("/api/griglie/utenti/configurazioni").json()
    assert [c["predefinita"] for c in elenco if c["id"] == a["id"]] == [False]
    assert [c["predefinita"] for c in elenco if c["id"] == b["id"]] == [True]
    # aggiornamento con lo stesso nome (maiuscole indifferenti)
    admin.post("/api/griglie/utenti/configurazioni", {"nome": "SOLO NOMI", "dati": dati})
    assert len(admin.get("/api/griglie/utenti/configurazioni").json()) == 2
    # un altro utente non vede né elimina le configurazioni altrui
    rt = nuovo_utente(admin, app, "mario", "responsabile_tecnico")
    assert rt.get("/api/griglie/registro/configurazioni").json() == []
    assert rt.delete(f"/api/griglie/utenti/configurazioni/{a['id']}").status_code in (403, 404)
    assert admin.delete(f"/api/griglie/utenti/configurazioni/{a['id']}").status_code == 200


def test_griglia_backup_da_elenco(admin):
    admin.post("/api/backup")
    admin.post("/api/backup")
    r = admin.post("/api/griglie/backup/dati", {"filtri": [{"campo": "tipo", "valore": "Manuale"}]}).json()
    assert r["totale"] == 2 and r["somme"]["dimensione_mb"] >= 0
    from zoneinfo import ZoneInfo
    oggi = datetime.now(ZoneInfo("Europe/Rome")).strftime("%d/%m/%Y")
    assert admin.post("/api/griglie/backup/dati", {"filtri": [{"campo": "creato_il", "valore": oggi}]}).json()["totale"] == 2


def test_velocita_con_dieci_anni_di_dati(admin, app):
    """300.000 righe di registro (circa 10 anni): ogni pagina della griglia sotto mezzo secondo."""
    arc = app.state.archivio
    inizio = datetime(2016, 1, 1)
    righe = [
        {"quando": inizio + timedelta(minutes=17 * i), "utente_id": None, "utente_nome": f"Utente {i % 12}",
         "azione": ("preventivo.crea", "verbale.emetti", "accesso.entrata")[i % 3], "oggetto_tipo": "prova",
         "oggetto_id": str(i), "descrizione": f"Operazione di prova numero {i} sul cliente {i % 2700}",
         "dettagli": "{}", "impronta_precedente": "0" * 64, "impronta": "0" * 64}
        for i in range(300_000)
    ]
    with arc.scrittura() as s:
        s.execute(insert(RegistroOperazione), righe)
    richieste = [
        {"dimensione": 25},
        {"dimensione": 100, "pagina": 500},
        {"filtri": [{"campo": "descrizione", "valore": "cliente 1234"}]},
        {"filtri": [{"campo": "quando", "valore": "03/2021"}], "ordinamenti": [{"campo": "utente_nome", "direzione": "asc"}]},
        {"ricerca": "preventivo"},
    ]
    # Soglia: una pagina sotto il secondo e mezzo anche su un PC d'ufficio carico (0.12.9: misurato 1,05 s su Windows durante la suite). La ricerca «contiene» su 300.000 righe legge
    # tutto il registro (non c'è indice che la acceleri): su Windows si è misurato 0,55 s, qui circa la metà.
    # Si prende la migliore di tre misure per non dipendere da un picco momentaneo del PC (antivirus, disco).
    for corpo in richieste:
        durate = []
        for _ in range(3):
            t = time.perf_counter()
            r = admin.post("/api/griglie/registro/dati", corpo)
            durate.append(time.perf_counter() - t)
            assert r.status_code == 200
        assert min(durate) < 1.5, f"{corpo}: {min(durate):.2f} s"
