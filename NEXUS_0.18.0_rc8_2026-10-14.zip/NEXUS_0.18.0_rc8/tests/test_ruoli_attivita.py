"""R132 (12/10/2026, Federico: «ruoli distinti»): RT e verificatori per attività. Amministratore e segreteria comuni;
il verificatore può avere AD_DPR e AD_DM, l'RT una sola. Nessuna «mescolanza»: affidamenti, riesami, elenchi e menu
dell'altra attività non sono raggiungibili."""

from conftest import nuovo_utente, ruolo_id
from test_beni import ok
from test_dm_documenti import registrata, sede_dm  # noqa: F401
from test_dm_tecnico import incarico


def _ruoli(admin):
    return {r['codice']: r for r in ok(admin.get('/api/ruoli'))}


def test_ruoli_di_partenza_per_attivita(admin):
    r = _ruoli(admin)
    assert r['responsabile_tecnico']['nome'] == 'RT DPR' and r['responsabile_tecnico']['attivita'] == ['DPR']
    assert r['responsabile_tecnico_dm']['nome'] == 'RT DM' and r['responsabile_tecnico_dm']['attivita'] == ['DM']
    assert r['tecnico']['attivita'] == ['DPR'] and r['tecnico_dm']['attivita'] == ['DM']
    assert r['tecnico_dm_dpr']['nome'] == 'Verificatore DM e DPR' and r['tecnico_dm_dpr']['attivita'] == ['DPR', 'DM']
    assert r['segreteria']['attivita'] == [] and r['amministratore']['attivita'] == []
    # C20: gestione oggetti separata; gli altri permessi tecnici restano simmetrici.
    perm = {x['codice']: set(x['permessi']) for x in ok(admin.get('/api/permessi/matrice'))['ruoli']}
    gestione_dpr={'anagrafica.impianti','anagrafica.dismetti'}
    gestione_dm={'beni.gestire','beni.scadenze','beni.dismetti'}
    assert gestione_dpr <= perm['responsabile_tecnico'] and not gestione_dm & perm['responsabile_tecnico']
    assert gestione_dm <= perm['responsabile_tecnico_dm'] and not gestione_dpr & perm['responsabile_tecnico_dm']
    assert perm['responsabile_tecnico'] - gestione_dpr == perm['responsabile_tecnico_dm'] - gestione_dm
    assert perm['tecnico'] == perm['tecnico_dm'] == perm['tecnico_dm_dpr'] and perm['tecnico']


def test_rt_una_sola_attivita_verificatore_anche_due(admin):
    r = _ruoli(admin)
    x = r['responsabile_tecnico_dm']
    e = admin.put(f"/api/ruoli/{x['id']}", {'nome': x['nome'], 'attivita': ['DPR', 'DM'], 'versione': x['versione']})
    assert e.status_code == 400 and 'una sola attività' in e.json()['errore']
    e = admin.put(f"/api/ruoli/{x['id']}", {'nome': x['nome'], 'attivita': [], 'versione': x['versione']})
    assert e.status_code == 400
    y = r['tecnico']
    ok(admin.put(f"/api/ruoli/{y['id']}", {'nome': y['nome'], 'attivita': ['DPR', 'DM'], 'versione': y['versione']}))
    # un ruolo copiato da RT DM resta DM
    z = ok(admin.post('/api/ruoli', {'nome': 'Sostituto RT DM', 'copia_da': x['id']}))
    assert z['attivita'] == ['DM']


def test_nessuna_mescolanza_fra_dpr_e_dm(admin, app, sede):
    ver_dm = nuovo_utente(admin, app, 'ver_dm', 'tecnico_dm')
    ver_dpr = nuovo_utente(admin, app, 'ver_dpr', 'tecnico')
    ver_due = nuovo_utente(admin, app, 'ver_due', 'tecnico_dm_dpr')
    rt_dm = nuovo_utente(admin, app, 'rt_dm', 'responsabile_tecnico_dm')
    rt_dpr = nuovo_utente(admin, app, 'rt_dpr', 'responsabile_tecnico')
    # elenchi dei verificatori per l'affidamento
    dm = {x['nome'] for x in ok(admin.get('/api/dm/incarichi/valori'))['verificatori']}
    dpr = {x['nome'] for x in ok(admin.get('/api/verifiche/valori'))['verificatori']}
    assert {'Ver_Dm', 'Ver_Due', 'Rt_Dm'} <= dm and not {'Ver_Dpr', 'Rt_Dpr'} & dm
    assert {'Ver_Dpr', 'Ver_Due', 'Rt_Dpr'} <= dpr and not {'Ver_Dm', 'Rt_Dm'} & dpr
    # l'RT DM affida incarichi DM, ma non a un verificatore DPR; l'RT DPR non tocca il DM
    v, _, _ = incarico(admin, sede)
    id_dpr = ok(ver_dpr.get('/api/io'))['id']
    id_dm = ok(ver_dm.get('/api/io'))['id']
    e = rt_dm.post(f"/api/dm/incarichi/{v['id']}/assegna", {'versione': v['versione'], 'verificatore_id': id_dpr})
    assert e.status_code == 400
    assert rt_dpr.post(f"/api/dm/incarichi/{v['id']}/assegna", {'versione': v['versione'], 'verificatore_id': id_dm}).status_code == 403
    v = ok(rt_dm.post(f"/api/dm/incarichi/{v['id']}/assegna", {'versione': v['versione'], 'verificatore_id': id_dm}))
    assert v['verificatore_id'] == id_dm
    assert ver_dm.get(f"/api/dm/incarichi/{v['id']}").status_code == 200
    assert ver_dpr.get(f"/api/dm/incarichi/{v['id']}").status_code == 403
    assert rt_dpr.get(f"/api/dm/incarichi/{v['id']}").status_code == 403
    assert rt_dpr.post('/api/griglie/incarichi_dm/dati', {}).json().get('totale', 0) == 0
    # riesame del contratto: l'RT dell'altra attività no, la segreteria (comune) sì
    p = ok(admin.get(f"/api/preventivi/{v['preventivo_id']}"))
    assert p['ambito'] == 'DM'
    assert rt_dpr.post(f"/api/preventivi/{p['id']}/riesame", {'esito': 'conforme'}).status_code == 403
    # VerbalizzAI (verbali DPR): il verificatore DM non ha permessi tecnici
    assert ver_dm.get('/api/verifiche/valori').status_code == 403
    # menu e attività
    assert ver_dm.post('/api/ambito-attivo', {'ambito': 'DPR'}).status_code == 400
    ok(ver_due.post('/api/ambito-attivo', {'ambito': 'DPR'}))
    pagina = ver_dm.c.get('/', follow_redirects=True).text
    assert 'AD_DM' in pagina and '<option value="DPR"' not in pagina
    assert 'id="griglia"' not in ver_dm.c.get('/verifiche').text           # pagina DPR negata
    assert 'id="griglia"' in ver_dm.c.get('/verifiche-gvr').text


def test_migrazione_ruoli_esistenti(admin, app):
    """Archivio della 0.13.0: RT e Verificatore diventano DPR (con il nome di partenza aggiornato), nascono i ruoli DM
    con gli stessi permessi; gli utenti restano sul loro ruolo."""
    from alembic import command
    from sqlalchemy import text

    from gestionale.core import migrazioni
    rt = nuovo_utente(admin, app, 'rt_storico', 'responsabile_tecnico')
    arc = app.state.archivio
    cfg = migrazioni.config_alembic("sqlite:///" + str(arc.cfg.percorso_database))
    command.downgrade(cfg, "0020")
    with arc.motore.begin() as c:
        assert c.execute(text("SELECT COUNT(*) FROM ruoli WHERE codice LIKE '%_dm%'")).scalar() == 0
        c.execute(text("UPDATE ruoli SET nome = 'Responsabile tecnico' WHERE codice = 'responsabile_tecnico'"))
        c.execute(text("UPDATE ruoli SET nome = 'Verificatore' WHERE codice = 'tecnico'"))
    migrazioni.aggiorna(arc.motore)
    assert migrazioni.revisione_database(arc.motore) == migrazioni.revisione_programma()
    r = _ruoli(admin)
    assert r['responsabile_tecnico']['nome'] == 'RT DPR' and r['responsabile_tecnico']['attivita'] == ['DPR']
    assert r['tecnico']['nome'] == 'Verificatore DPR'
    assert r['responsabile_tecnico_dm']['attivita'] == ['DM'] and r['tecnico_dm_dpr']['attivita'] == ['DPR', 'DM']
    with arc.motore.connect() as c:
        def permessi(codice):
            return set(c.execute(text("SELECT permesso_codice FROM ruoli_permessi JOIN ruoli ON ruoli.id = ruolo_id "
                                      "WHERE codice = :c"), {'c': codice}).scalars())
        assert permessi('responsabile_tecnico_dm') == permessi('responsabile_tecnico')
        assert permessi('tecnico_dm') == permessi('tecnico')
    assert ok(rt.get('/api/io'))['ruolo'] == 'RT DPR'
    assert ruolo_id(admin, 'tecnico_dm')


def test_piu_ruoli_ogni_permesso_nella_sua_attivita(admin, app, sede):
    """R143 (0.16, Federico 12/10/2026, 17:58): «RT (e verificatore) DPR ma anche verificatore DM» con le caselle."""
    from conftest import Sessione
    from fastapi.testclient import TestClient
    r = admin.post("/api/utenti", {"username": "diego.prova", "nome": "Diego Prova", "ruolo_id": ruolo_id(admin, 'responsabile_tecnico'),
                                   "altri_ruoli": [ruolo_id(admin, 'tecnico_dm')]})
    u = ok(r)
    assert u['ruolo'] == 'RT DPR + Verificatore DM' and len(u['ruoli_id']) == 2
    c = TestClient(app, base_url="http://testserver")
    assert c.post("/api/accesso", json={"username": "diego.prova", "password": u['password_provvisoria']}).status_code == 200
    d = Sessione(c)
    assert d.post("/api/io/password", {"attuale": u['password_provvisoria'], "nuova": "password nuova personale"}).status_code == 200
    io = ok(d.get('/api/io'))
    assert set(io['attivita']) == {'DPR', 'DM'}
    assert 'verifiche.riesame' in io['permessi_per_attivita']['DPR']
    assert 'verifiche.riesame' not in io['permessi_per_attivita']['DM']
    assert 'verifiche.assegna' not in io['permessi_per_attivita']['DM']
    assert 'verifiche.esegui' in io['permessi_per_attivita']['DM']
    # verificatore in entrambe le attività
    assert 'Diego Prova' in {x['nome'] for x in ok(admin.get('/api/dm/incarichi/valori'))['verificatori']}
    assert 'Diego Prova' in {x['nome'] for x in ok(admin.get('/api/verifiche/valori'))['verificatori']}
    # RT solo nel DPR: non affida gli incarichi DM
    v, _, _ = incarico(admin, sede)
    assert d.post(f"/api/dm/incarichi/{v['id']}/assegna", {'versione': v['versione'], 'verificatore_id': io['id']}).status_code == 403
    # griglia utenti e ruolo usato come aggiuntivo: non si elimina
    righe = ok(admin.post('/api/griglie/utenti/dati', {}))['righe']
    assert next(x for x in righe if x['username'] == 'diego.prova')['ruolo'] == 'RT DPR + Verificatore DM'
    assert admin.delete(f"/api/ruoli/{ruolo_id(admin, 'tecnico_dm')}").status_code == 400
    # modifica: tolto il ruolo aggiuntivo
    u = ok(admin.get(f"/api/utenti/{io['id']}"))
    u = ok(admin.put(f"/api/utenti/{u['id']}", {"nome": u['nome'], "email": "", "ruolo_id": u['ruolo_id'], "altri_ruoli": [], "versione": u['versione']}))
    assert u['ruolo'] == 'RT DPR'
