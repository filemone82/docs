"""0.12.10 · Maschere AD_DM indicate da Federico (documento di progetto 30): colonne di partenza, raggruppamento per
sede operativa, dismesse nascoste, voci GVR e SC/SP distinte, fatture sulla griglia."""

from __future__ import annotations

from test_anagrafica import crea_cliente, crea_sede
from test_beni import nuovo, ok, scad
from test_dm_tecnico import incarico


def vista(admin, codice, ambito=""):
    d = ok(admin.get(f"/api/griglie/{codice}/definizione"))
    return (d["viste_predefinite"].get(ambito) or d["viste_predefinite"].get("")), {c["campo"] for c in d["colonne"]}


def test_viste_di_partenza(admin):
    v, _ = vista(admin, "clienti", "DM")
    assert v["colonne"] == ["ragione_sociale", "codice_fiscale", "indirizzo", "cap", "comune", "provincia", "regione", "commerciale"]
    v, _ = vista(admin, "sedi", "DM")
    assert v["colonne"][-4:] == ["cliente_ragione_sociale", "referente_nome", "referente_email", "referente_telefono"]
    v, campi = vista(admin, "attrezzature_gvr")
    assert v["raggruppa"] == "sede_operativa" and {"campo": "dismesso", "valore": "no"} in v["filtri"]
    assert v["colonne"][0:8] == ["reparto", "rif_interno", "descrizione", "matr_informale", "num_fabbrica", "ps", "volume", "anno_costruzione"]
    assert {"cnd_ultima", "cnd_prossima", "esente", "dismesso"} <= set(v["colonne"])
    v, campi = vista(admin, "attrezzature_scsp")
    assert "ps" not in campi and "volume" not in campi and {"scsp_ultima", "suppl_prossima"} <= set(v["colonne"])
    v, _ = vista(admin, "scadenze_dm")
    assert v["raggruppa"] == "sede_operativa" and "tipo_scadenza" in v["colonne"] and {"campo": "regime", "valore": "DM all. VII"} in v["filtri"]
    v, _ = vista(admin, "preventivi_dm")
    assert v["colonne"] == ["etichetta", "data", "stato", "fatturato", "cliente_ragione_sociale", "sede", "totale_standard", "totale", "riesame_tre"]
    v, _ = vista(admin, "incarichi_gvr")
    assert len(v["colonne"]) == 20 and v["colonne"][-3:] == ["preventivo", "fattura", "esporta_inail"]
    v, _ = vista(admin, "incarichi_scsp")
    assert len(v["colonne"]) == 16 and "regime" not in v["colonne"]


def test_attrezzature_gvr_e_scsp_separate(admin):
    sede = crea_sede(admin, crea_cliente(admin)["id"])
    gv = nuovo(admin, sede, "GVR", "GV-M1", tipo_attr_id=24, tipo_attr_gvr_id=2, id_spec_id=52,
               dati_dm={"reparto": "Centrale termica", "descr_attr": "Generatore di vapore", "ps_attr_gvr": "15", "volume_attr_gvr": "15000"})
    scad(admin, gv, "cnd", data_ultima="2024-05-01", data_prossima="2034-05-01")
    nuovo(admin, sede, "SC", "SC-M1")
    g = ok(admin.post("/api/griglie/attrezzature_gvr/dati", {}))["righe"]
    assert [x["matr_informale"] for x in g] == ["GV-M1"]
    r = g[0]
    assert (r["reparto"], r["descrizione"], r["ps"], r["volume"], r["cnd_prossima"], r["esente"]) == (
        "Centrale termica", "Generatore di vapore", "15", "15000", "2034-05-01", "No")
    assert sede["denominazione"] in r["sede_operativa"]
    assert [x["matr_informale"] for x in ok(admin.post("/api/griglie/attrezzature_scsp/dati", {}))["righe"]] == ["SC-M1"]
    html = admin.get("/attrezzature-gvr").text
    assert "Attrezzature SC/SP" in html and 'data-griglia="attrezzature_gvr"' in html


def test_verifiche_gvr_preventivi_e_fatture(admin):
    sede = crea_sede(admin, crea_cliente(admin)["id"])
    v, _a, p = incarico(admin, sede)
    g = ok(admin.post("/api/griglie/incarichi_gvr/dati", {}))["righe"]
    assert [x["id"] for x in g] == [v["id"]] and g[0]["esporta_inail"] == "No" and g[0]["fattura"] is None
    assert ok(admin.post("/api/griglie/incarichi_scsp/dati", {}))["righe"] == []
    pr = ok(admin.post("/api/griglie/preventivi_dm/dati", {}))["righe"]
    assert [(x["id"], x["fatturato"], x["riesame_tre"]) for x in pr] == [(p["id"], "No", "Sì, esito positivo")]
    assert ok(admin.post("/api/griglie/fatture/dati", {"ambito": "DM"}))["totale"] == 0
    for pagina in ("/verifiche-gvr", "/verifiche-scsp", "/fatture-dm"):
        assert admin.get(pagina).status_code == 200, pagina
