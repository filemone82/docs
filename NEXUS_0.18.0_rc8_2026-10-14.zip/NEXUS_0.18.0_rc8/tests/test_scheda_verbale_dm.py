"""0.13.0 · VerbalizzAI_DM, prima parte (R123, documento 24): dati del verbale come attributi dell'attrezzatura, con
provenienza, correzione a mano e storico; bozza dalla scheda; Pes/Tes di confronto; firma DM distinta dalla DPR;
copia del PDF definitivo nella cartella dei verbali DM con nome INAIL e nome «potabile»."""

from test_beni import ok
from test_dm_documenti import effettua, generata, pdf_valido, registrata, sede_dm  # noqa: F401
from test_dm_tecnico import assegna, incarico, salva

PNG = (b"\x89PNG\r\n\x1a\n" + b"\x00\x00\x00\rIHDR" + (400).to_bytes(4, "big") + (120).to_bytes(4, "big") + b"\x08\x02\x00\x00\x00"
       + b"\x00" * 64)


def test_scheda_dal_verbale_correzione_a_mano_e_bozza(admin, sede):
    v, a, _ = registrata(admin, sede)
    v = ok(salva(admin, v, campi={'gvr_acc_sicur': 'Valvola Carraro 12 bar', 'gvr_osserv': 'Anno di costruzione: 2000.'},
                 data_rilascio='2026-08-01', date={'funz': '2028-07-31'}))
    ok(effettua(admin, generata(admin, v)))
    x = ok(admin.get(f"/api/dm/attrezzature/{a['id']}/dati-verbale"))
    g = {y['codice']: y for y in x['gruppi']}
    assert g['gvr_accessori']['valore']['campi']['gvr_acc_sicur'] == 'Valvola Carraro 12 bar'
    assert g['gvr_accessori']['valore']['origine'] == 'verbale' and g['gvr_accessori']['valore']['incarico_id'] == v['id']
    assert g['gvr_osserv_funz']['valore']['campi']['gvr_osserv'] == 'Anno di costruzione: 2000.'
    assert g['gvr_conservazione']['valore'] is None
    assert x['definizioni']['gvr_acc_sicur']['etichetta']
    # correzione a mano: vale per la bozza successiva, con provenienza «manuale», e resta nello storico
    x = ok(admin.put(f"/api/dm/attrezzature/{a['id']}/dati-verbale/gvr_accessori",
                     {'campi': {'gvr_acc_sicur': 'Valvole sostituite: Carraro CS31, 12 bar'}, 'data_riferimento': '2026-09-01',
                      'nota': 'sostituzione comunicata dal cliente'}))
    g = {y['codice']: y for y in x['gruppi']}
    assert g['gvr_accessori']['valore']['origine'] == 'manuale' and len(x['storico']) == 1
    a = ok(admin.get(f"/api/beni/{a['id']}"))
    w, _, _ = incarico(admin, sede, a=a, comb='funz')
    w = assegna(admin, w)
    assert w['bozza']['campi']['gvr_acc_sicur'] == 'Valvole sostituite: Carraro CS31, 12 bar'
    assert w['bozza']['provenienza_precedenti']['gvr_acc_sicur']['origine'] == 'manuale'
    assert w['bozza']['campi']['gvr_osserv'] == 'Anno di costruzione: 2000.'          # osservazioni dal funzionamento
    # campi o gruppi non validi
    assert admin.put(f"/api/dm/attrezzature/{a['id']}/dati-verbale/scsp", {'campi': {}}).status_code == 400
    assert admin.put(f"/api/dm/attrezzature/{a['id']}/dati-verbale/gvr_accessori", {'campi': {'esito': 'x'}}).status_code == 400


def test_un_verbale_piu_recente_supera_la_correzione(admin, sede):
    v, a, _ = registrata(admin, sede)
    ok(admin.put(f"/api/dm/attrezzature/{a['id']}/dati-verbale/gvr_accessori",
                 {'campi': {'gvr_acc_sicur': 'A mano'}, 'data_riferimento': '2026-01-10'}))
    v = ok(salva(admin, v, campi={'gvr_acc_sicur': 'Dal verbale di agosto'}, data_rilascio='2026-08-01', date={'funz': '2028-07-31'}))
    ok(effettua(admin, generata(admin, v)))
    g = {y['codice']: y for y in ok(admin.get(f"/api/dm/attrezzature/{a['id']}/dati-verbale"))['gruppi']}
    assert g['gvr_accessori']['valore']['campi']['gvr_acc_sicur'] == 'Dal verbale di agosto'


def test_pes_tes_del_funzionamento_precedente(admin, sede):
    from test_dm_documenti import profilo
    from test_dm_tecnico import camera, camera_bozza, gvr, pronta, registra
    a = camera(admin, gvr(admin, sede), dati_tecnici={'gvr_ps': '12', 'gvr_ts': '191'})
    v, a, _ = incarico(admin, sede, a)
    v = assegna(admin, v)
    v = ok(salva(admin, v, camere=[camera_bozza(c, gvr_pes='7,5', gvr_tes='170') for c in v['bozza']['camere']]))
    v = ok(registra(admin, pronta(admin, v)))
    profilo(admin, v)
    v = ok(salva(admin, ok(admin.get(f"/api/dm/incarichi/{v['id']}")), data_rilascio='2026-08-01', date={'funz': '2028-07-31'}))
    ok(effettua(admin, generata(admin, v)))
    a = ok(admin.get(f"/api/beni/{a['id']}"))
    w, _, _ = incarico(admin, sede, a=a, comb='funz')
    w = assegna(admin, w)
    prec = w['bozza']['pes_tes_precedenti']
    assert list(prec.values())[0]['gvr_pes'] == '7,5'
    assert all(c['gvr_pes'] == '' for c in w['bozza']['camere'])                  # confronto, non copia


def test_firma_dm_distinta_e_copia_nella_cartella(admin, sede, app, tmp_path):
    v, a, _ = registrata(admin, sede, firma=False)
    uid = v['profilo_tecnico']['utente_id']
    assert admin.get(f"/api/dm/tecnici/{uid}/firma").status_code == 404
    r = admin.c.post(f"/api/dm/tecnici/{uid}/firma", files={'file': ('firma.png', PNG, 'image/png')}, headers=admin.h)
    assert r.status_code == 200 and r.json()['firma_dm'] is True
    assert admin.get(f"/api/dm/tecnici/{uid}/firma").content == PNG
    assert admin.c.post(f"/api/dm/tecnici/{uid}/firma", files={'file': ('x.txt', b'testo', 'text/plain')}, headers=admin.h).status_code == 400
    v = ok(admin.get(f"/api/dm/incarichi/{v['id']}"))
    assert v['profilo_tecnico']['firma_dm'] is True
    app.state.archivio.cfg.cartella_verbali_dm = str(tmp_path)
    v = ok(salva(admin, v, data_rilascio='2026-08-01', date={'funz': '2028-07-31'}))
    g = generata(admin, v)
    with app.state.archivio.lettura() as s:
        from gestionale.moduli.dm.documenti import valori
        from gestionale.moduli.dm.modelli import IncaricoDM
        assert valori(s, s.get(IncaricoDM, v['id']), app.state.archivio)['firma'] == PNG     # nel verbale DM la firma DM
    r = ok(effettua(admin, g))
    pdf = sorted(tmp_path.rglob('*.pdf'))
    assert len(pdf) == 2 and pdf[0].parent.parts[-3:-1] == ('GVR', '2026'), pdf
    nomi = sorted(p.name for p in pdf)
    assert any(n.startswith('verbale ') for n in nomi) and any(n.startswith('GVR_') and n.endswith('funzionamento.pdf') for n in nomi), nomi
    assert any('Copia salvata' in x for x in r['avvisi'])
    ok(admin.delete(f"/api/dm/tecnici/{uid}/firma"))
    assert admin.get(f"/api/dm/tecnici/{uid}/firma").status_code == 404


def _png(w, h):
    return (b"\x89PNG\r\n\x1a\n" + b"\x00\x00\x00\rIHDR" + w.to_bytes(4, "big") + h.to_bytes(4, "big") + b"\x08\x02\x00\x00\x00"
            + b"\x00" * 64)


def test_ad_rev_006_osservazioni_nel_verbale_combinato(admin, sede):
    """Federico (12/10/2026): nel verbale combinato con funzionamento si ripropongono le osservazioni dell'ultimo verbale
    di funzionamento, compresa una sua correzione a mano; la correzione delle osservazioni d'integrità non le sostituisce.
    Senza funzionamento vale la più recente, e a parità di data la correzione a mano. La provenienza lo dice."""
    from gestionale.moduli.dm.scheda_verbale import _chiave_osservazione
    v, a, _ = registrata(admin, sede)
    v = ok(salva(admin, v, campi={'gvr_osserv': 'Dal funzionamento precedente'}, data_rilascio='2026-10-12',
                 date={'funz': '2028-10-11'}))
    ok(effettua(admin, generata(admin, v)))
    ok(admin.put(f"/api/dm/attrezzature/{a['id']}/dati-verbale/gvr_osserv_integrita",
                 {'campi': {'gvr_osserv': 'Correzione manuale integrità'}, 'data_riferimento': '2026-10-12'}))
    a = ok(admin.get(f"/api/beni/{a['id']}"))
    w = assegna(admin, incarico(admin, sede, a=a, comb='funz_integrita')[0])
    assert w['bozza']['campi']['gvr_osserv'] == 'Dal funzionamento precedente'
    assert w['bozza']['provenienza_precedenti']['gvr_osserv']['gruppo'] == 'gvr_osserv_funz'
    ok(admin.put(f"/api/dm/attrezzature/{a['id']}/dati-verbale/gvr_osserv_funz",
                 {'campi': {'gvr_osserv': 'Correzione manuale funzionamento'}, 'data_riferimento': '2026-10-12'}))
    w = ok(admin.get(f"/api/dm/incarichi/{w['id']}"))       # la correzione arriva alla bozza aperta non salvata
    prov = w['bozza']['provenienza_precedenti']['gvr_osserv']
    assert w['bozza']['campi']['gvr_osserv'] == 'Correzione manuale funzionamento'
    assert prov['origine'] == 'manuale' and prov['versione_id']
    # senza funzionamento: a parità di data la correzione a mano, fra due correzioni l'ultima
    verbale = {'data': '2026-10-12', 'origine': 'verbale', 'incarico_id': 99, 'id': None}
    man1 = {'data': '2026-10-12', 'origine': 'manuale', 'incarico_id': None, 'id': 3}
    man2 = dict(man1, id=4)
    assert max([verbale, man1], key=_chiave_osservazione) is man1
    assert max([man2, verbale, man1], key=_chiave_osservazione) is man2
    assert max([man1, dict(verbale, data='2026-10-13')], key=_chiave_osservazione)['origine'] == 'verbale'


def test_ad_rev_007_nome_inail_gvr_con_attivita(admin, sede, app):
    from gestionale.moduli.dm.documenti import nome_inail
    from gestionale.moduli.dm.modelli import IncaricoDM
    v, a, _ = registrata(admin, sede)
    from test_dm_preventivi import gvr
    w, _, _ = incarico(admin, sede, a=gvr(admin, sede, 'GVR-ALTRA'), comb='funz_integrita')   # conta solo l'attività
    with app.state.archivio.lettura() as s:
        x, y = s.get(IncaricoDM, v['id']), s.get(IncaricoDM, w['id'])
        x.data_pvp = y.data_pvp = __import__('datetime').date(2028, 10, 11)
        n1, n2 = nome_inail(s, x, 'verbale'), nome_inail(s, y, 'verbale')
    assert n1.endswith('11102028 funz.pdf') and n2.endswith('11102028 funz-integr.pdf') and n1 != n2


def test_ad_rev_007_nessuna_sovrascrittura_silenziosa(tmp_path):
    from gestionale.moduli.dm.documenti import _scrivi_senza_sovrascrivere as scrivi
    nome = 'verbale 2000ABC123VR11102028'
    assert scrivi(tmp_path, nome, b'%PDF funzionamento') is None
    assert scrivi(tmp_path, nome, b'%PDF funzionamento') is None                 # stessa copia: idempotente
    avviso = scrivi(tmp_path, nome, b'%PDF integrita')                           # verbale diverso, stesso nome INAIL
    assert avviso and 'non è stato sostituito' in avviso and f'{nome} (2).pdf' in avviso
    assert (tmp_path / f'{nome}.pdf').read_bytes() == b'%PDF funzionamento'
    assert (tmp_path / f'{nome} (2).pdf').read_bytes() == b'%PDF integrita'
    assert scrivi(tmp_path, nome, b'%PDF integrita') is None                      # ripetuta: nessun terzo file
    assert len(list(tmp_path.glob('*.pdf'))) == 2


def test_ad_rev_008_limite_firma_dm_coerente(admin, sede):
    v, _, _ = registrata(admin, sede)
    uid = v['profilo_tecnico']['utente_id']
    r = admin.c.post(f"/api/dm/tecnici/{uid}/firma", files={'file': ('f.png', _png(200, 60), 'image/png')}, headers=admin.h)
    assert r.status_code == 200
    r = admin.c.post(f"/api/dm/tecnici/{uid}/firma", files={'file': ('f.png', _png(49, 60), 'image/png')}, headers=admin.h)
    assert r.status_code == 400 and '50 × 20' in r.text
    r = admin.c.post(f"/api/dm/tecnici/{uid}/firma", files={'file': ('f.png', _png(50, 20), 'image/png')}, headers=admin.h)
    assert r.status_code == 200
