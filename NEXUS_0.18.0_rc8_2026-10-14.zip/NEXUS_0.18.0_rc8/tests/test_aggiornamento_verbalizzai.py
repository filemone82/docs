"""Aggiornamento del generatore: import validi e versione precedente preservata se fallisce."""

from __future__ import annotations

import importlib.util
from pathlib import Path

import pytest


def strumento():
    p = Path(__file__).resolve().parents[1] / 'strumenti' / 'aggiorna_verbalizzai.py'
    spec = importlib.util.spec_from_file_location('aggiornamento_vz', p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def test_import_multipli_locali_ed_esterni_con_alias(tmp_path):
    m = strumento()
    pkg = tmp_path / 'generatore'
    pkg.mkdir()
    (pkg / '__init__.py').write_text('', encoding='utf-8')
    (pkg / 'pdfconv.py').write_text('valore = 41', encoding='utf-8')
    (pkg / 'layout.py').write_text('valore = 1', encoding='utf-8')
    testo = 'import os, pdfconv as pdf, layout\ndef risultato():\n    import pdfconv, layout\n    return pdfconv.valore + layout.valore\n'
    convertito = m.rendi_relativi(testo, {'pdfconv', 'layout'})
    assert m.import_assoluti_rimasti(convertito, {'pdfconv', 'layout'}) == []
    (pkg / 'app.py').write_text(convertito, encoding='utf-8')
    spec = importlib.util.spec_from_file_location('generatore', pkg / '__init__.py', submodule_search_locations=[str(pkg)])
    import sys
    package = importlib.util.module_from_spec(spec)
    sys.modules['generatore'] = package
    try:
        spec.loader.exec_module(package)
        app_spec = importlib.util.spec_from_file_location('generatore.app', pkg / 'app.py')
        app = importlib.util.module_from_spec(app_spec)
        app_spec.loader.exec_module(app)
        assert app.risultato() == 42 and app.pdf.valore == 41
    finally:
        for nome in list(sys.modules):
            if nome == 'generatore' or nome.startswith('generatore.'):
                del sys.modules[nome]


def _sorgente(tmp_path, m):
    sorgente = tmp_path / 'sorgente'
    sorgente.mkdir()
    for nome in m.ATTESI:
        (sorgente / nome).write_text('APP_VERSION = "prova"\n' if nome == 'storage.py' else 'valore = 1\n', encoding='utf-8')
    (sorgente / 'static').mkdir()
    (sorgente / 'static/app.js').write_text('/* nuova interfaccia */', encoding='utf-8')
    modelli = sorgente / 'modelli_rev02/m01'
    modelli.mkdir(parents=True)
    for n in (1, 2, 3):
        (modelli / f'M0{n}-PO01_dpr_rev02.docx').write_bytes(b'modello')
    return sorgente


@pytest.mark.parametrize('errore', ['sintassi', 'modello'])
def test_sorgente_incompleta_non_modifica_installazione(tmp_path, monkeypatch, errore):
    m = strumento()
    dest = tmp_path / 'installato'
    dest.mkdir()
    (dest / 'storage.py').write_text('VERSIONE_PRECEDENTE = True', encoding='utf-8')
    sorgente = _sorgente(tmp_path, m)
    if errore == 'sintassi':
        (sorgente / 'app.py').write_text('def funzione(', encoding='utf-8')
    else:
        (sorgente / 'modelli_rev02/m01/M03-PO01_dpr_rev02.docx').unlink()
    monkeypatch.setattr(m, 'DESTINAZIONE', dest)
    prima = {p.name: p.read_bytes() for p in dest.iterdir()}
    with pytest.raises((SyntaxError, SystemExit)):
        m.aggiorna(sorgente)
    assert {p.name: p.read_bytes() for p in dest.iterdir()} == prima


def test_errore_di_sostituzione_ripristina_versione_precedente(tmp_path, monkeypatch):
    m = strumento()
    dest = tmp_path / 'installato'
    dest.mkdir()
    (dest / 'storage.py').write_text('VERSIONE_PRECEDENTE = True', encoding='utf-8')
    sorgente = _sorgente(tmp_path, m)
    monkeypatch.setattr(m, 'DESTINAZIONE', dest)
    replace = m.os.replace

    def fallisci_nuova(src, dst):
        if Path(src).name == 'nuova':
            raise OSError('sostituzione non riuscita')
        replace(src, dst)

    monkeypatch.setattr(m.os, 'replace', fallisci_nuova)
    with pytest.raises(OSError, match='sostituzione non riuscita'):
        m.aggiorna(sorgente)
    assert (dest / 'storage.py').read_text(encoding='utf-8') == 'VERSIONE_PRECEDENTE = True'
