"""0.12.6 · Simulazione di Federico (11/10/2026): il Word del verbale precedente deve far ripartire la bozza dal suo
contenuto, come in VerbalizzAI; la data di emissione segue la data del verbale."""

from __future__ import annotations

import base64

from test_verbali import _registrata, _vz
from test_verifiche import accettato, verbale_m02  # noqa: F401


def _dati(admin, vid):
    x = _vz(admin, f"inspection?id={vid}").json()
    return (x.get("item") or x)["data"]


def _carica(admin, v, raw, nome="VP_050_24.docx"):
    return admin.c.post(f"/api/verifiche/{v['id']}/verbale/precedente", files={"file": (nome, raw, "application/octet-stream")}, headers=admin.h)


def test_word_caricato_dalla_verifica_fa_da_precedente(admin, accettato):  # noqa: F811
    v = _registrata(admin, accettato)
    assert admin.get(f"/api/verifiche/{v['id']}/verbale/precedente").json()["precedente"] is None
    vid = admin.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).json()["verbale_id"]   # bozza già aperta, vuota
    assert _dati(admin, vid)["baseline_id"] is None
    r = _carica(admin, v, verbale_m02("VP/050/24", "10/10/2024"))
    assert r.status_code == 200, r.text
    assert r.json()["bozza_rifatta"] and r.json()["precedente"]["numero"] == "VP/050/24"
    # la scheda dell'impianto del gestionale prende l'ultimo verbale (nessuno stato più recente)
    x = admin.get(f"/api/impianti/{accettato['scariche']['id']}").json()
    assert x["ultima_verifica_numero"] == "VP/050/24" and x["caratteristiche"]["verbale"] == "VP/050/24"
    nuova = admin.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).json()["verbale_id"]
    d = _dati(admin, nuova)
    assert nuova != vid and d["baseline_id"] == r.json()["precedente"]["id"]
    assert d["header"]["number"] == "VP/001/26" and d["header"]["issued_date"] == d["header"]["report_date"] == "15/10/2026"
    assert d["date_auto"]["issued_date"] == "15/10/2026"
    # solo Word
    assert _carica(admin, v, b"testo", nome="altro.txt").status_code == 400


def test_word_gia_importato_dalla_pagina_dei_verbali(admin, accettato):  # noqa: F811
    """Il caso della simulazione: Word importato prima dalla pagina «Verbali» (impianto di VerbalizzAI separato)."""
    v = _registrata(admin, accettato)
    raw = verbale_m02("VP/050/24", "10/10/2024")
    req = {"content": base64.b64encode(raw).decode(), "filename": "vecchio.docx", "client_name": "Verifiche Prova S.r.l.", "address": "Via Po 2"}
    separato = _vz(admin, "import/commit", req).json()["plant_id"]
    vid = admin.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).json()["verbale_id"]
    assert _dati(admin, vid)["plant_id"] != separato and _dati(admin, vid)["baseline_id"] is None   # il difetto segnalato
    r = _carica(admin, v, raw, "vecchio.docx")
    assert r.status_code == 200 and "già stato importato" in r.json()["note"][0]
    nuova = admin.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).json()["verbale_id"]
    d = _dati(admin, nuova)
    assert d["plant_id"] == separato and d["baseline_id"] == r.json()["precedente"]["id"]


def test_verbali_usano_il_libreoffice_di_config(tmp_path, monkeypatch):
    """L'anteprima PDF dei verbali (VerbalizzAI incorporato) usa il percorso «libreoffice» di config.json come il resto."""
    from gestionale.app import crea_app
    from gestionale.core.config import Config
    from gestionale.terzi.verbalizzai import pdfconv

    finto = tmp_path / "soffice.exe"
    finto.write_bytes(b"")
    crea_app(Config(cartella_dati=tmp_path / "dati", libreoffice=str(finto), backup_automatico=False, apri_browser=False))
    try:
        assert pdfconv.find() == str(finto)
    finally:
        pdfconv.configure("")
