"""0.12.8 · Registro dei rilievi della revisione della 0.12.6 (AD-REV-001…005): i casi riprodotti dal revisore."""

from __future__ import annotations

import pytest
from sqlalchemy import select
from test_anagrafica import crea_cliente, crea_impianto, crea_sede
from test_clienti_origini import _importa
from test_garda_dm import MINI_DM
from test_verbali import _registrata, _vz
from test_verifiche import accettato, verbale_m02  # noqa: F401

from gestionale.moduli.anagrafica import origini
from gestionale.moduli.anagrafica.modelli import Cliente, Origine


def _carica(admin, v, raw, nome):
    return admin.c.post(f"/api/verifiche/{v['id']}/verbale/precedente", files={"file": (nome, raw, "application/octet-stream")}, headers=admin.h)


@pytest.fixture
def descrizioni(monkeypatch):
    """Word M02 con la descrizione dell'impianto scelta dal test (il modello di prova la lascia vuota)."""
    from gestionale.terzi.verbalizzai import wordio

    originale = wordio.parse_word
    testi = {}

    def leggi(raw, nome):  # noqa: ANN001, ANN202
        d = originale(raw, nome)
        if nome in testi:
            d["plant"]["description"] = testi[nome]
        return d

    monkeypatch.setattr(wordio, "parse_word", leggi)
    return testi


def _dati(admin, vid):
    x = _vz(admin, f"inspection?id={vid}").json()
    return (x.get("item") or x)["data"]


def test_ad_rev_001_word_piu_recente_aggiorna_scheda_e_bozza(admin, accettato, descrizioni):  # noqa: F811
    v = _registrata(admin, accettato)
    descrizioni.update({"A.docx": "LPS 10", "B.docx": "LPS 20", "C.docx": "LPS 5"})
    assert _carica(admin, v, verbale_m02("VP/050/24", "10/10/2024"), "A.docx").status_code == 200
    r = _carica(admin, v, verbale_m02("VP/060/25", "10/10/2025"), "B.docx").json()
    assert any("aggiornata con i dati di questo verbale" in n and "Descrizione dell'impianto" in n for n in r["note"]), r["note"]
    imp = accettato["scariche"]["id"]
    voci = {x["etichetta"]: x["valore"] for x in admin.get(f"/api/impianti/{imp}/scheda-tecnica").json()["voci"]}
    assert voci["Descrizione dell'impianto"] == "LPS 20"
    # un Word più vecchio non torna indietro, e lo dice
    r = _carica(admin, v, verbale_m02("VP/040/23", "10/10/2023"), "C.docx").json()
    assert any("precedente alla scheda tecnica" in n for n in r["note"]), r["note"]
    vid = admin.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).json()["verbale_id"]
    assert _dati(admin, vid)["plant"]["description"] == "LPS 20"          # la bozza propone l'ultimo aggiornamento
    assert r["precedente"]["numero"] == "VP/060/25"


def test_ad_rev_002_vale_il_verbale_piu_recente(admin, app, accettato):  # noqa: F811
    from gestionale.terzi.verbalizzai import wordio

    v = _registrata(admin, accettato)
    a = app.state.verbali
    imp, sede = accettato["scariche"]["id"], accettato["scariche"]["sede_id"]
    def plant(nome):  # noqa: ANN001, ANN202
        return a.mutate(lambda c: a._put(c, "plant", {"client_name": "Verifiche Prova S.r.l.", "site_name": nome, "address": "Via Po 2",
                                                       "label": nome, "sede_id": sede, "impianti": {"M02": imp}}))
    vecchio, nuovo = plant("A"), plant("B")
    for numero, giorno in (("VP/001/23", "10/03/2023"), ("VP/001/24", "10/03/2024"), ("VP/001/25", "10/03/2025")):
        raw = verbale_m02(numero, giorno)
        a.import_word(raw, numero.replace("/", "_") + ".docx", wordio.parse_word(raw, "x.docx"), vecchio)
    raw = verbale_m02("VP/001/26", "10/03/2026")
    a.import_word(raw, "VP_001_26.docx", wordio.parse_word(raw, "x.docx"), nuovo)
    prec = admin.get(f"/api/verifiche/{v['id']}/verbale/precedente").json()["precedente"]
    assert prec["numero"] == "VP/001/26"
    vid = admin.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).json()["verbale_id"]
    assert _dati(admin, vid)["baseline_id"] == prec["id"]            # il riquadro dice ciò che la bozza usa


def test_ad_rev_003_non_si_sposta_lo_storico_di_un_altro_impianto(admin, app, accettato):  # noqa: F811
    from gestionale.terzi.verbalizzai import wordio

    v = _registrata(admin, accettato)
    sede = accettato["scariche"]["sede_id"]
    altro = crea_impianto(admin, sede, tipologia="scariche", asta=True, numero_aste="1", potenza_kw="", periodicita_anni=2)
    a = app.state.verbali
    pid = a.mutate(lambda c: a._put(c, "plant", {"client_name": "Verifiche Prova S.r.l.", "site_name": "", "address": "Via Po 2",
                                                  "label": "x", "sede_id": sede, "impianti": {"M02": altro["id"]}}))
    raw = verbale_m02("VP/050/24", "10/10/2024")
    a.import_word(raw, "vecchio.docx", wordio.parse_word(raw, "vecchio.docx"), pid)
    r = _carica(admin, v, raw, "vecchio.docx")
    assert r.status_code == 400 and f"impianto n. {altro['id']}" in r.json()["errore"]
    assert a.get(pid)["data"]["impianti"] == {"M02": altro["id"]}     # collegamento invariato


def test_ad_rev_004_recapiti_nella_fusione_dei_clienti(admin, app):
    dm = MINI_DM.replace("""(1, 'OFFICINA L\\'ANCORA SRL', 'Via Roma 1', NULL, 'Torino', '10121', 'TO', 'Piemonte', '01234567897', '01234567897', NULL, 1, NULL, 1,
	 NULL, NULL, 1, NULL, NULL, 'ABC1234',""", """(1, 'OFFICINA L\\'ANCORA SRL', 'Via Roma 1', NULL, 'Torino', '10121', 'TO', 'Piemonte', '01234567897', '01234567897', NULL, 1, NULL, 1,
	 15, NULL, 1, 'amministrazione@ancora.invalid', 'ancora@pec.invalid', 'ABC1234',""")
    assert dm != MINI_DM
    esito = _importa(app, dm)
    with app.state.archivio.lettura() as s:
        c = s.scalar(select(Cliente).where(Cliente.partita_iva == "01234567897"))
        assert c.pec == "ancora@pec.invalid" and "Completati da Garda AD_dm: PEC" in c.note        # vuoto → completato
        assert c.email_verbali == "info@esempio.invalid"                                           # diverso → resta, con avviso
        assert "amministrazione@ancora.invalid" in c.avvisi and "controlla" in c.avvisi
        assert c.sconto_dm == 1500                                                                  # sconto predefinito AD_DM (AD-13)
    assert esito["importati"]["clienti fusi: recapiti diversi da confermare"] == 1


def test_ad_rev_005_origini_di_un_cliente_eliminato(admin, app):
    c = crea_cliente(admin, ragione_sociale="Importato e poi eliminato")
    with app.state.archivio.scrittura() as s:
        origini.registra(s, origini.INGECERT, "clienti", 999, "cliente", c["id"])
    assert admin.delete(f"/api/clienti/{c['id']}").status_code == 200
    with app.state.archivio.lettura() as s:
        o = s.scalar(select(Origine).where(Origine.id_origine == "999"))
        assert o.eliminato_il is not None                                 # la provenienza resta, marcata
        assert origini.di(s, "cliente", c["id"]) == []                     # e non si attacca a un oggetto nuovo con lo stesso id


def test_ad_rev_002_parita_di_data_vale_l_aggiornamento(admin, app, accettato):  # noqa: F811
    """Residuo della riverifica 12/10: a parità di data vale il verbale aggiornato per ultimo, non lo storico più lungo."""
    from gestionale.terzi.verbalizzai import wordio

    v = _registrata(admin, accettato)
    a = app.state.verbali
    imp, sede = accettato["scariche"]["id"], accettato["scariche"]["sede_id"]

    def plant(nome):  # noqa: ANN001, ANN202
        return a.mutate(lambda c: a._put(c, "plant", {"client_name": "Verifiche Prova S.r.l.", "site_name": nome, "address": "Via Po 2",
                                                       "label": nome, "sede_id": sede, "impianti": {"M02": imp}}))
    lungo, breve = plant("A"), plant("B")
    for numero, giorno in (("VP/001/24", "10/03/2024"), ("VP/001/25", "10/03/2025"), ("VP/001/26", "10/03/2026")):
        raw = verbale_m02(numero, giorno)
        a.import_word(raw, numero.replace("/", "_") + ".docx", wordio.parse_word(raw, "x.docx"), lungo)
    raw = verbale_m02("VP/002/26", "10/03/2026")      # stessa data, importato (aggiornato) dopo
    a.import_word(raw, "VP_002_26.docx", wordio.parse_word(raw, "x.docx"), breve)
    prec = admin.get(f"/api/verifiche/{v['id']}/verbale/precedente").json()["precedente"]
    assert (prec["numero"], prec["plant_id"]) == ("VP/002/26", breve)
    vid = admin.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).json()["verbale_id"]
    assert _dati(admin, vid)["baseline_id"] == prec["id"]


def test_ad_rev_005_righe_tolte_e_preventivo_eliminato(admin, app):
    """Residuo della riverifica 12/10: anche le righe tolte dal preventivo (orfani) e quelle eliminate a cascata."""
    from gestionale.moduli.preventivi.modelli import RigaPreventivo

    c = crea_cliente(admin, ragione_sociale="Importato con preventivo")
    sede = crea_sede(admin, c["id"])
    i1, i2 = crea_impianto(admin, sede["id"]), crea_impianto(admin, sede["id"], tipologia="terra_at", cabine_mt_bt=1)
    p = admin.post("/api/preventivi", {"impianti": [i1["id"], i2["id"]]}).json()
    r1, r2 = (r["id"] for r in p["righe"])
    with app.state.archivio.scrittura() as s:
        origini.registra(s, origini.INGECERT, "preventivi", 77, "preventivo", p["id"])
        origini.registra(s, origini.INGECERT, "preventivi_righe", 771, "riga_preventivo", r1)
        origini.registra(s, origini.INGECERT, "preventivi_righe", 772, "riga_preventivo", r2)
    p = admin.put(f"/api/preventivi/{p['id']}", {**p, "righe_da_togliere": [r1]}).json()    # orfano (delete-orphan)
    with app.state.archivio.lettura() as s:
        assert s.get(RigaPreventivo, r1) is None
        assert s.scalar(select(Origine).where(Origine.id_origine == "771")).eliminato_il is not None
        assert s.scalar(select(Origine).where(Origine.id_origine == "772")).eliminato_il is None
    assert admin.delete(f"/api/preventivi/{p['id']}").status_code == 200                    # cascata
    with app.state.archivio.lettura() as s:
        assert all(s.scalar(select(Origine).where(Origine.id_origine == k)).eliminato_il is not None for k in ("77", "771", "772"))
        assert origini.di(s, "riga_preventivo", r2) == [] and origini.di(s, "preventivo", p["id"]) == []
