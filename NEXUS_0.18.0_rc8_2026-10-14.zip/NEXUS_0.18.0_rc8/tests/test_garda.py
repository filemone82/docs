"""0.7.1: importazione dal database del gestionale di Garda (dump MySQL di «ingecert»), con dati finti."""

from __future__ import annotations

import pytest
from test_anagrafica import crea_cliente

from gestionale.moduli.garda import dump, importa

MINI = r"""
-- dump di prova, stessa forma di quello di HeidiSQL
CREATE TABLE IF NOT EXISTS `clienti` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rag_soc` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;
INSERT INTO `clienti` (`id`, `rag_soc`, `indirizzo`, `comune`, `cap`, `prov`, `regione`, `cod_fis`, `p_iva`, `referente_commerciale`, `note`,
  `nome_referente`, `email_ref`, `tel_ref`, `nazione`, `email`, `pec`, `sdi_pec`, `rif_amministrazione`, `istituto_finanziario`, `iban`,
  `dich_intento`, `dich_intento_n`, `dich_intento_data`, `pagamento`, `iva`, `rit_acc_str`) VALUES
	(10, 'Officina L\'Ancora S.r.l.', 'Via Roma 1', 'Torino', '10121', 'TO', 'Piemonte', '01234567897', '01234567897', 4, 'nota; con punto e virgola',
	 'Mario', 'mario@esempio.invalid', '011 1234567', 1, 'info@esempio.invalid', '', 'ABC1234', NULL, NULL, NULL, 'F', NULL, NULL, 2, 1, '4%'),
	(11, 'Comune di Prova', 'Piazza Municipio 1', 'Biella', '13900', 'BI', 'Piemonte', '00000000000', '', NULL, NULL,
	 NULL, NULL, NULL, NULL, NULL, NULL, 'nan', NULL, NULL, NULL, 'F', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `clienti_sedi_operative` (`id`, `cliente`, `utente_cliente`, `nome_sede`, `indirizzo`, `comune`, `cap`, `prov`, `regione`,
  `nome_referente`, `email_ref`, `tel_ref`, `note`) VALUES
	(100, 10, NULL, 'Stabilimento', 'Via Roma 1', 'Torino', '10121', 'TO', 'Piemonte', NULL, NULL, NULL, NULL),
	(101, 11, NULL, '', 'Via Scuole 3', 'Biella', '13900', 'BI', 'Piemonte', NULL, NULL, NULL, NULL);
INSERT INTO `impianti` (`id`, `sede_operativa`, `tipo_impianto`, `anno_matricola`, `cod_att_matricola`, `num_matricola`, `prov_immatr`,
  `dismessa`, `den_impianto`, `pot_impianto`, `n_cab_trasf_mt_bt`, `n_sott_at_mt`, `codice_pod`, `periodicita_verifiche`, `ultima_verifica`,
  `data_ult_verifica`, `data_prox_verifica`, `par_ad_asta`, `num_par_ad_asta`, `par_gabbia`, `zona_0`, `zona_1`, `zona_2`, `zona_20`, `zona_21`,
  `zona_22`, `last_update_ts`) VALUES
	(1000, 100, 'area 2', '2010', '123', '45', 'TO', 'F', NULL, 30.00, NULL, NULL, 'IT001E12345678 cliente 99', 2, 5000, '2025-03-10', '2027-03-10',
	 'F', NULL, NULL, 'F', 'F', 'F', 'F', 'F', 'F', '2025-03-10 10:00:00'),
	(1001, 101, 'area 1', NULL, NULL, NULL, NULL, 'F', 'Scuola', NULL, NULL, NULL, NULL, 5, NULL, NULL, '2026-12-01',
	 'T', 2, 'sioltre350', 'F', 'F', 'F', 'F', 'F', 'F', NULL);
INSERT INTO `preventivi` (`id`, `stato_preventivo`, `rif_ord_cli`, `fatt_preventivo`, `data_preventivo`, `serie_preventivo`, `numero_preventivo`,
  `cliente`, `termine_esecuzione`, `ind_trasferta`, `contr_inail`, `totale_standard`, `totale_scontato`, `note_interne`, `riesame_fatto`,
  `riesame_esito`, `riesame_nota`, `termini_di_pagamento`, `tipo_documento`, `n_documento`, `data_documento`, `cig`, `cup`,
  `commessa_convenzione`, `ult_riesame_utente`, `ult_riesame_data`, `last_update_ts`, `referente_commerciale`) VALUES
	(200, 'accettato', 'ORD 7', 'totale', '2025-02-01', '2025', 41, 10, 'entro 30 giorni', 43.00, 'T', 100.00, 148.00, NULL, 'T', 'C', NULL, 2,
	 NULL, NULL, NULL, NULL, NULL, NULL, 8, '2025-02-03', '2025-02-03 09:00:00', NULL),
	(201, 'rifiutato', NULL, NULL, '2025-02-01', '2025_annullato', 41, 11, NULL, 0, 'F', 150.00, 150.00, NULL, 'F', NULL, NULL, NULL,
	 'OrdineAcquisto', 'PA-9', '2025-02-05', 'Z123', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `preventivi_righe` (`id`, `preventivo`, `stato_riga`, `n_riga`, `impianto`, `tipo_verifica`, `ric_tar`, `tariffa_standard`, `sconto`,
  `tariffa_applicata`, `verifica`) VALUES
	(300, 200, 'accettata', 1, 1000, 'VP', 'F', 100.00, 0, 100.00, 5000),
	(301, 201, 'rifiutata', 1, 1001, 'VP', 'F', 150.00, 0, 150.00, NULL);
INSERT INTO `verifiche` (`id`, `stato_verifica`, `impianto`, `codice_verifica`, `numero_verifica`, `anno_verifica`, `tecnico`, `tecnico_aff`,
  `tipo_verifica`, `esito_verifica`, `motivazione_sospensione`, `data_rilascio_verbale`, `data_consegna`, `data_prox_verifica`, `tariffa_standard`,
  `tariffa_effettiva`, `verbale`, `preventivo_riga`, `fattura`, `fattura_cliente`, `riesame_fatto`, `riesame_esito`, `riesame_nota`,
  `last_update_ts`, `data_progr`, `dichiaro_che`, `ult_riesame_utente`, `ult_riesame_data`) VALUES
	(5000, 'effettuata', 1000, 'VP/120/25', 120, '2025', 8, NULL, 'VP', 'Positivo', NULL, '2025-03-10', NULL, '2027-03-10', 100.00, 100.00,
	 NULL, 300, NULL, 77, 'T', 'C', NULL, '2025-03-12 09:00:00', '2025-03-10', 'T', 8, '2025-03-12');
INSERT INTO `verifiche_verbale` (`id`, `parent_id`, `file_size`, `file_name`) VALUES (1, 5000, 1000, 'VP_120_25.pdf');
INSERT INTO `utenti` (`id`, `attivo`, `utente`, `password`, `ruolo`, `cognome`, `nome`) VALUES
	(1, 'T', 'info@gardainformatica.it', 'x', 1, 'Garda', 'Admin'),
	(4, 'T', 'commerciale@esempio.invalid', 'x', 4, 'Bianchi', 'Carla'),
	(8, 'T', 'rt@esempio.invalid', 'x', 3, 'Rossi', 'Mario');
INSERT INTO `ruoli` (`id`, `predefinito`, `ruolo`, `permessi`) VALUES (1, 'F', 'Amministratore', ''), (3, 'F', 'Responsabile tecnico', ''),
	(4, 'F', 'Referente commerciale', '');
INSERT INTO `tipi_pagamento` (`id`, `predefinito`, `nome_pagamento`, `modalita`) VALUES (2, 'F', 'Bonifico 30 gg D.F.', 'MP05');
INSERT INTO `iva` (`id`, `predefinito`, `codice`, `perc_iva`, `perc_iva_indetr`, `classe_iva`, `descrizione`) VALUES
	(1, 'T', '22', 22.00, 0, 'Imponibile', 'Imponibile 22%');
INSERT INTO `nazioni` (`id`, `nazione`, `codice_iso_alpha2`) VALUES (1, 'Italia', 'IT');
INSERT INTO `gi_numerators` (`id`, `numerator_key`, `last_number`) VALUES (1, 'VPVS2025', 120);
CREATE VIEW `vista` AS select 1;
"""


def test_lettura_del_dump():
    d = dump.leggi(MINI, importa.TABELLE)
    assert len(d["clienti"]) == 2 and d["clienti"][0]["rag_soc"] == "Officina L'Ancora S.r.l."
    assert d["clienti"][0]["note"] == "nota; con punto e virgola" and d["impianti"][0]["pot_impianto"] == 30.0
    assert d["preventivi"][0]["ind_trasferta"] == 43.0 and d["verifiche"][0]["fattura"] is None
    with pytest.raises(dump.DumpNonValido):
        dump.leggi("INSERT INTO `clienti` (`id`) VALUES (1, 2);", {"clienti"})


def test_importazione_completa(admin, app):
    dati = dump.leggi(MINI, importa.TABELLE)
    arc = app.state.archivio
    with arc.scrittura() as s:
        esito = importa.importa(s, None, dati, "mini.sql")
    assert esito["importati"]["clienti"] == 2 and esito["importati"]["impianti"] == 2 and esito["importati"]["verifiche"] == 1
    assert esito["importati"]["utenti (disattivati)"] == 2 and esito["quadratura_totali"] == []
    clienti = admin.post("/api/griglie/clienti/dati", {}).json()
    assert clienti["totale"] == 2
    # utenti di Garda: disattivati, nessuna password riusata; l'utente di Garda Informatica non entra
    utenti = {u["username"]: u for u in admin.post("/api/griglie/utenti/dati", {}).json()["righe"]}
    assert "rt8" in utenti and not utenti["rt8"]["attivo"] and not any("garda" in k for k in utenti)  # nome troppo corto: + codice Garda
    # impianto: POD separato dal testo, codice di Garda, prossima verifica com'era in Garda
    imp = next(x for x in admin.post("/api/griglie/impianti/dati", {}).json()["righe"] if x["codice_esterno"] == "1000")
    scheda = admin.get(f"/api/impianti/{imp['id']}").json()
    assert scheda["pod"] == ["IT001E12345678"] and "cliente 99" in scheda["pod_note"] and scheda["prossima_verifica"] == "2027-03-10"
    assert scheda["ultima_verifica_numero"] == "VP/120/25"
    # preventivo: INAIL 5% e trasferta come righe a corpo → totale = 100 × 1,05 + 43 = 148 (come Garda); riesame conforme
    prev = admin.post("/api/griglie/preventivi/dati", {}).json()["righe"]
    p41 = [x for x in prev if x["numero"] == 41]
    assert len(p41) == 2  # stesso numero in Garda (serie «2025_annullato») → il secondo diventa rev. 1
    p = admin.get(f"/api/preventivi/{next(x['id'] for x in p41 if x['revisione'] == 0)}").json()
    assert p["stato"] == "accettato_totalmente" and p["totale"] == 14800 and p["riesame"]["esito"] == "conforme" and p["rif_ordine"] == "ORD 7"
    assert [r["sede_nome"] for r in p["righe"] if not r["impianto_id"]] == ["Contributo INAIL 5%", "Indennità di trasferta (Tariffario ISPESL 07.07.2005)"]
    # verifica: effettuata + riesame conforme = riesaminata; fatturata in Garda scritto nelle note
    v = admin.get(f"/api/verifiche/{p['verifiche'][0]['id']}").json()
    assert v["stato"] == "riesaminata" and v["codice_verbale"] == "VP/120/25" and v["esito"] == "positivo" and "FATTURATA in Garda" in v["note"]
    # le numerazioni proseguono da quelle di Garda (D76)
    nuovo = admin.post("/api/preventivi", {"cliente_id": p["cliente_id"]}).json()
    assert nuovo["numero"] >= 1 and nuovo["anno"] >= 2025
    # su un archivio che ha già clienti l'importazione si rifiuta
    with arc.scrittura() as s, pytest.raises(ValueError):
        importa.importa(s, None, dati, "mini.sql")


def test_non_si_importa_su_archivio_pieno(admin, app):
    crea_cliente(admin)
    with app.state.archivio.scrittura() as s, pytest.raises(ValueError):
        importa.importa(s, None, dump.leggi(MINI, importa.TABELLE), "mini.sql")
