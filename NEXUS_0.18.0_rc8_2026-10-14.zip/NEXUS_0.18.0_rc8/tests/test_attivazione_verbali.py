"""L'archivio precedente non può essere scambiato per i soli modelli PG."""
import json

import pytest

from gestionale.moduli.verbali.attivazione import CHIAVE, impronta, verifica_archivio_precedente
from gestionale.terzi.verbalizzai.storage import Archive


class _Target:
    def __init__(self, conferma=None):
        self.conferma = conferma

    def connect(self):
        target = self

        class Connessione:
            def __enter__(self):
                return self

            def __exit__(self, *_):
                pass

            def execute(self, _query, params):
                assert params == (CHIAVE,)
                return self

            def fetchone(self):
                return (json.dumps(target.conferma),) if target.conferma else None

        return Connessione()


def test_marca_archivio_identico_e_blocca_assenza_modifica_o_sorgente_diversa(tmp_path):
    vecchio = Archive(tmp_path / "verbali")
    origine = vecchio._snapshot()
    conferma = {"archive_id": origine["meta"]["archive_id"], "impronta": impronta(origine)}
    with pytest.raises(RuntimeError, match="manca la conferma"):
        verifica_archivio_precedente(_Target(), vecchio.path)
    verifica_archivio_precedente(_Target(conferma), vecchio.path)

    sbagliata = dict(conferma, archive_id="altro")
    with pytest.raises(RuntimeError, match="diverso"):
        verifica_archivio_precedente(_Target(sbagliata), vecchio.path)

    vecchio.mutate(lambda c: vecchio._put(c, "plant", {"client_name": "Nuovo"}, action="plant_new"))
    with pytest.raises(RuntimeError, match="modificato dopo"):
        verifica_archivio_precedente(_Target(conferma), vecchio.path)
