"""File del pacchetto per Windows (0.3.2)."""

from pathlib import Path

RADICE = Path(__file__).resolve().parents[1]


def test_file_bat_in_formato_windows():
    """I .bat devono avere gli a-capo di Windows (CRLF) e solo caratteri semplici, altrimenti cmd.exe li legge male."""
    bat = sorted(RADICE.glob("*.bat"))
    assert len(bat) >= 4
    for f in bat:
        dati = f.read_bytes()
        assert dati.count(b"\n") == dati.count(b"\r\n"), f.name
        dati.decode("ascii")
    installa = (RADICE / "INSTALLA_WINDOWS.bat").read_text(encoding="utf-8")
    assert "ensurepip" in installa and "rmdir /s /q" in installa and "[ERRORE]" in installa
