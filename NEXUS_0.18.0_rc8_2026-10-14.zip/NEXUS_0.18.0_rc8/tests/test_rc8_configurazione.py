"""rc8 · punto 5 (D2, Federico 14/10/2026): destinazioni dei documenti in Gestione › Configurazione.

Percorsi del server (NEXUS su VPS Ubuntu), uno per categoria; il vecchio `cartella_verbali_dm` di config.json resta il
valore iniziale; la copia automatica DM legge queste destinazioni e le schede DM vanno nella loro, se impostata.
"""

from __future__ import annotations

from test_beni import ok
from test_dm_documenti import effettua, generata, registrata, sede_dm  # noqa: F401
from test_dm_tecnico import salva


def test_destinazioni_salva_valida_e_prova(admin, app, tmp_path):
    d = ok(admin.get("/api/impostazioni/destinazioni"))["destinazioni"]
    assert [x["categoria"] for x in d] == ["verbali_dpr", "verbali_dm", "schede_dm", "fatture_pdf", "fatture_xml"]
    assert all(x["percorso"] == "" for x in d)
    assert {x["categoria"]: x["copia_attiva"] for x in d} == {"verbali_dpr": False, "verbali_dm": True, "schede_dm": True,
                                                            "fatture_pdf": False, "fatture_xml": False}
    # config.json come valore iniziale dei verbali DM
    app.state.archivio.cfg.cartella_verbali_dm = str(tmp_path / "da_config")
    x = next(x for x in ok(admin.get("/api/impostazioni/destinazioni"))["destinazioni"] if x["categoria"] == "verbali_dm")
    assert x["percorso"].endswith("da_config") and x["da_config"] is True
    # solo percorsi completi
    r = admin.put("/api/impostazioni/destinazioni", {"verbali_dpr": "cartella/relativa"})
    assert r.status_code == 400 and "percorso completo" in r.json()["errore"]
    nuove = ok(admin.put("/api/impostazioni/destinazioni", {"verbali_dpr": str(tmp_path / "dpr"), "fatture_xml": "  "}))["destinazioni"]
    assert next(x for x in nuove if x["categoria"] == "verbali_dpr")["percorso"] == str(tmp_path / "dpr")
    # prova dal server: cartella mancante, poi presente e scrivibile (nessun file lasciato)
    assert ok(admin.post("/api/impostazioni/destinazioni/prova", {"percorso": str(tmp_path / "dpr")}))["esito"] == "manca"
    (tmp_path / "dpr").mkdir()
    r = ok(admin.post("/api/impostazioni/destinazioni/prova", {"percorso": str(tmp_path / "dpr")}))
    assert r["esito"] == "ok" and list((tmp_path / "dpr").iterdir()) == []
    assert "Destinazioni dei documenti" in admin.get("/configurazione").text
    assert admin.get("/destinazioni-documenti").status_code == 200


def test_copia_dm_nella_destinazione_configurata(admin, sede, app, tmp_path):
    verbali = tmp_path / "verbali_dm"
    ok(admin.put("/api/impostazioni/destinazioni", {"verbali_dm": str(verbali), "schede_dm": str(tmp_path / "schede_dm")}))
    v, _a, _ = registrata(admin, sede)
    v = ok(salva(admin, v, data_rilascio="2026-08-01", date={"funz": "2028-07-31"}))
    r = ok(effettua(admin, generata(admin, v)))
    pdf = sorted(verbali.rglob("*.pdf"))
    assert len(pdf) == 2 and pdf[0].parent.parts[-3:-1] == ("GVR", "2026"), pdf
    assert any(str(verbali) in x for x in r["avvisi"])


def test_punto6_dati_della_societa_in_configurazione(admin):
    conf = admin.get("/configurazione").text
    assert 'href="/dati-societari"' in conf and "Dati della società e pagamenti" in conf
    assert admin.get("/dati-societari?ritorno=/fatture?apri=1").status_code == 200
    assert 'id="configura-societa"' not in admin.get("/fatture").text   # non più nella pagina Fatture
