"""AVVIA_TEST_WINDOWS.bat crea l'ambiente di prova con le stesse API del browser: deve restare allineato alle regole.

Regressione della 0.12.2 segnalata da Federico l'11/10/2026: lo script si fermava sull'evidenza scritta
dell'accettazione (0.8.0) e sul blocco dei preventivi doppi (R98)."""

from __future__ import annotations

import importlib.util
import sqlite3
from pathlib import Path


def test_ambiente_di_prova_completo_con_dpr_e_dm(tmp_path, monkeypatch):
    from gestionale.core import pdf
    from test_dm_documenti import pdf_di_prova

    monkeypatch.setattr(pdf, "da_word", lambda *a: pdf_di_prova())
    p = Path(__file__).resolve().parents[1] / "strumenti" / "crea_ambiente_di_prova.py"
    spec = importlib.util.spec_from_file_location("crea_ambiente_di_prova", p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    m.crea(tmp_path / "dati")
    db = sqlite3.connect(tmp_path / "dati" / "database.sqlite")
    try:
        stati_dpr = sorted(r[0] for r in db.execute("SELECT stato FROM verifiche"))
        assert "registrata" in stati_dpr and "assegnata" in stati_dpr and "da_assegnare" in stati_dpr
        assert db.execute("SELECT COUNT(*) FROM preventivi WHERE stato='creato'").fetchone()[0] == 1
        assert sorted(r[0] for r in db.execute("SELECT stato FROM dm_incarichi")) == ["assegnata", "effettuata"]
        assert (tmp_path / "dati" / m.PRONTO).exists()
    finally:
        db.close()


def test_ambiente_interrotto_non_si_apre_come_buono(tmp_path):
    p = Path(__file__).resolve().parents[1] / "strumenti" / "crea_ambiente_di_prova.py"
    spec = importlib.util.spec_from_file_location("crea_ambiente_di_prova_2", p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    (tmp_path / "database.sqlite").write_bytes(b"")  # archivio rimasto a metà, senza il file «completo»
    import pytest
    with pytest.raises(SystemExit, match="incompleto"):
        m.crea(tmp_path)
