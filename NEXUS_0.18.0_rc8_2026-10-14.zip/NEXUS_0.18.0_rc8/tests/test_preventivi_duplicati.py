"""Regressione: la stessa verifica periodica non genera due preventivi."""

from conftest import revisore
# ruff: noqa: F811 -- fixture pytest importate nei test sottostanti

from concurrent.futures import ThreadPoolExecutor

import pytest
from conftest import segna_inviato
from test_preventivi import base  # noqa: F401
from test_verifiche import accettato, verbale_m02  # noqa: F401

from gestionale.moduli.preventivi import copertura


def ok(r):
    assert r.status_code == 200, r.text
    return r.json()


def scadenza(admin, impianto):
    return next(r for r in ok(admin.post("/api/griglie/scadenze/dati", {}))["righe"] if r["id"] == impianto)


def test_secondo_preventivo_sulla_stessa_scadenza_bloccato(admin, base):
    impianto = base["impianti"][0]["id"]
    prima = admin.post("/api/preventivi", {"impianti": [impianto]}).json()
    seconda = admin.post("/api/preventivi/da-scadenze", {"impianti": [impianto]})
    assert seconda.status_code == 409, seconda.text
    assert prima["codice"] in seconda.json()["errore"]
    assert admin.post("/api/griglie/preventivi/dati", {}).json()["totale"] == 1


@pytest.mark.parametrize("percorso", ["nuovo", "scadenze", "aggiunta", "numero"])
def test_blocco_tutti_i_percorsi_e_rollback(admin, base, percorso):
    i1, i2 = (i["id"] for i in base["impianti"])
    p = ok(admin.post("/api/preventivi", {"impianti": [i1]}))
    assert scadenza(admin, i1)["preventivo_id"] == p["id"]
    if percorso in ("nuovo", "scadenze"):
        url = "/api/preventivi" if percorso == "nuovo" else "/api/preventivi/da-scadenze"
        r = admin.post(url, {"impianti": [i2, i1]})
        assert admin.post("/api/griglie/preventivi/dati", {}).json()["totale"] == 1
    else:
        altro = ok(admin.post("/api/preventivi", {"cliente_id": base["cliente"]["id"]}))
        url = f"/api/preventivi/{altro['id']}/impianti" if percorso == "aggiunta" else "/api/preventivi/da-scadenze"
        r = admin.post(url, {"impianti": [i2, i1], "preventivo": altro["codice"], "versione": altro["versione"]})
        assert admin.get(f"/api/preventivi/{altro['id']}").json()["righe"] == []
    assert r.status_code == 409 and p["codice"] in r.json()["errore"]
    assert not scadenza(admin, i2)["in_preventivo"]


@pytest.mark.parametrize("modo", ["preventivo", "riga", "elimina_bozza"])
def test_annullamento_libera_prestazione(admin, base, modo):
    i = base["impianti"][0]["id"]
    p = ok(admin.post("/api/preventivi", {"impianti": [i]}))
    if modo == "preventivo":
        ok(admin.post(f"/api/preventivi/{p['id']}/annulla", {"motivo": "Sostituzione", "versione": p["versione"]}))
    elif modo == "riga":
        ok(admin.post(f"/api/preventivi/{p['id']}/righe/stato", {"righe": [p["righe"][0]["id"]], "stato": "annullata", "versione": p["versione"]}))
    else:
        ok(admin.delete(f"/api/preventivi/{p['id']}"))
    assert not scadenza(admin, i)["in_preventivo"]
    altro = ok(admin.post("/api/preventivi", {"impianti": [i]}))
    assert scadenza(admin, i)["preventivo_id"] == altro["id"]


def test_rifiuto_non_equivale_annullamento_e_revisione_sostituisce(admin, base):
    i = base["impianti"][0]["id"]
    p = segna_inviato(admin, ok(admin.post("/api/preventivi", {"impianti": [i]})))
    p = ok(admin.post(f"/api/preventivi/{p['id']}/righe/stato", {"righe": [p["righe"][0]["id"]], "stato": "rifiutata", "versione": p["versione"]}))
    assert admin.post("/api/preventivi", {"impianti": [i]}).status_code == 409
    rev = ok(admin.post(f"/api/preventivi/{p['id']}/revisione", {"versione": p["versione"]}))
    assert rev["revisione"] == 1 and rev["numero"] == p["numero"]
    assert scadenza(admin, i)["preventivo_id"] == rev["id"]
    assert admin.post("/api/preventivi", {"impianti": [i]}).status_code == 409


def test_straordinaria_indipendente_e_cambio_tipo_non_aggira_blocco(admin, base):
    i = base["impianti"][0]["id"]
    vs = ok(admin.post("/api/preventivi", {"impianti": [i], "tipo_verifica": "straordinaria"}))
    assert not scadenza(admin, i)["in_preventivo"]
    vp = ok(admin.post("/api/preventivi", {"impianti": [i]}))
    r = admin.put(f"/api/preventivi/{vs['id']}", {**vs, "righe": [{"id": vs["righe"][0]["id"], "tipo_verifica": "periodica"}]})
    assert r.status_code == 409
    assert admin.get(f"/api/preventivi/{vs['id']}").json()["righe"][0]["tipo_verifica"] == "straordinaria"
    assert scadenza(admin, i)["preventivo_id"] == vp["id"]


def test_date_retrodatate_non_aggirano_blocco(admin, base):
    i = base["impianti"][0]["id"]
    p = ok(admin.post("/api/preventivi", {"impianti": [i], "data": "2024-01-01"}))
    assert scadenza(admin, i)["preventivo_id"] == p["id"]
    assert admin.post("/api/preventivi", {"impianti": [i], "data": "2027-01-01"}).status_code == 409


def test_due_richieste_concorrenti_creano_un_solo_preventivo(admin, base):
    i = base["impianti"][0]["id"]
    with ThreadPoolExecutor(max_workers=2) as pool:
        risposte = list(pool.map(lambda _: admin.post("/api/preventivi", {"impianti": [i]}), range(2)))
    assert sorted(r.status_code for r in risposte) == [200, 409]
    assert admin.post("/api/griglie/preventivi/dati", {}).json()["totale"] == 1


def test_verifica_completata_libera_successiva_riesame_negativo_riblocca(admin, app, accettato):
    i = accettato["scariche"]["id"]
    p = accettato["preventivo"]
    v = next(v for v in p["verifiche"] if v["impianto_id"] == i)
    v = ok(admin.get(f"/api/verifiche/{v['id']}"))
    assert admin.post("/api/preventivi", {"impianti": [i]}).status_code == 409
    tecnico = ok(admin.get("/api/verifiche/valori"))["verificatori"][0]["id"]
    v = ok(admin.post(f"/api/verifiche/{v['id']}/assegna", {"verificatore_id": tecnico, "versione": v["versione"]}))
    v = ok(admin.post(f"/api/verifiche/{v['id']}/registra", {"data_esecuzione": "2026-10-09", "versione": v["versione"]}))
    assert admin.post("/api/preventivi", {"impianti": [i]}).status_code == 409
    word = {"word": ("verbale.docx", verbale_m02(v["codice_verbale"], "09/10/2026"), "application/octet-stream")}
    def carica(v):
        return ok(admin.c.post(f"/api/verifiche/{v['id']}/verbale", files=word, data={"versione": v["versione"]}, headers=admin.h))
    v = carica(v)
    assert v["stato"] == "eseguita" and not scadenza(admin, i)["in_preventivo"]
    v = ok(revisore(admin).post(f"/api/verifiche/{v['id']}/riesame", {"esito": "non_conforme", "note": "Correggere il verbale", "versione": v["versione"]}))
    assert v["stato"] == "registrata" and scadenza(admin, i)["in_preventivo"]
    assert admin.post("/api/preventivi", {"impianti": [i]}).status_code == 409
    v = carica(v)
    v = ok(revisore(admin).post(f"/api/verifiche/{v['id']}/riesame", {"esito": "conforme", "versione": v["versione"]}))
    assert not scadenza(admin, i)["in_preventivo"]
    nuovo = ok(admin.post("/api/preventivi", {"impianti": [i], "data": "2026-10-09"}))
    assert nuovo["id"] != p["id"] and scadenza(admin, i)["preventivo_id"] == nuovo["id"]


def test_duplicati_pre_esistenti_non_generano_incarichi_e_non_sono_cancellati(admin, base, monkeypatch):
    i = base["impianti"][0]["id"]
    p = ok(admin.post("/api/preventivi", {"impianti": [i]}))
    # Riproduce dati creati dal programma precedente, senza bonificarli di nascosto.
    with monkeypatch.context() as m:
        m.setattr(copertura, "controlla", lambda *a, **k: None)
        altro = segna_inviato(admin, ok(admin.post("/api/preventivi", {"impianti": [i]})))
        altro = ok(admin.post(f"/api/preventivi/{altro['id']}/righe/stato", {"righe": [altro["righe"][0]["id"]], "stato": "accettata", "evidenza_accettazione": "Email di prova", "versione": altro["versione"]}))
    r = admin.post(f"/api/preventivi/{altro['id']}/riesame", {"esito": "conforme", "requisiti_chiari": True, "competenza_strumenti": True, "imparzialita": True, "tempi": True})
    assert r.status_code == 409 and p["codice"] in r.json()["errore"]
    assert admin.post("/api/griglie/verifiche/dati", {}).json()["totale"] == 0
    assert admin.post("/api/griglie/preventivi/dati", {}).json()["totale"] == 2
    p = segna_inviato(admin, p)
    r = admin.post(f"/api/preventivi/{p['id']}/righe/stato", {"righe": [p["righe"][0]["id"]], "stato": "accettata", "evidenza_accettazione": "Email di prova", "versione": p["versione"]})
    assert r.status_code == 409
    assert admin.get(f"/api/preventivi/{p['id']}").json()["righe"][0]["stato"] == "in_attesa"
    ok(admin.post(f"/api/preventivi/{p['id']}/annulla", {"motivo": "Duplicato", "versione": p["versione"]}))
    ok(admin.post(f"/api/preventivi/{altro['id']}/riesame", {"esito": "conforme", "requisiti_chiari": True, "competenza_strumenti": True, "imparzialita": True, "tempi": True}))
    assert admin.post("/api/griglie/verifiche/dati", {}).json()["totale"] == 1
