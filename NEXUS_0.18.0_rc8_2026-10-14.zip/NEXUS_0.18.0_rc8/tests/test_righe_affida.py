"""0.12.6 · Dalle righe accettate dei preventivi si affida l'incarico di verifica, come in Garda (DPR e DM)."""

from __future__ import annotations

from test_anagrafica import crea_cliente, crea_sede
from test_beni import ok
from test_dm_tecnico import incarico
from test_verifiche import accettato  # noqa: F401  (fixture)


def righe(admin, codice, preventivo_id=None, **filtri):
    corpo = {"filtri": [{"campo": k, "valore": v} for k, v in filtri.items()], "dimensione": 100}
    if codice.startswith("righe_preventivi"):
        assert preventivo_id is not None, "Il test deve indicare il singolo preventivo"
        corpo["contesto"] = {"preventivo_id": preventivo_id}
    return ok(admin.post(f"/api/griglie/{codice}/dati", corpo))["righe"]


def test_affidamento_dalle_righe_dpr(admin, accettato):  # noqa: F811
    io = ok(admin.get("/api/io"))
    da_affidare = righe(admin, "righe_preventivi", preventivo_id=accettato["preventivo"]["id"], stato_riga="Accettata", verifica_stato="Da assegnare")
    assert len(da_affidare) == 2 and all(r["verifica_id"] and not r["verificatore"] for r in da_affidare)
    # la riga di trasferta (senza impianto) non ha verifica: si vede vuota
    assert any(r["verifica_id"] is None for r in righe(admin, "righe_preventivi", preventivo_id=accettato["preventivo"]["id"], stato_riga="Accettata"))
    r = ok(admin.post("/api/verifiche/assegna-in-blocco", {"verifiche": [x["verifica_id"] for x in da_affidare], "verificatore_id": io["id"]}))
    assert r["assegnate"] == 2
    dopo = righe(admin, "righe_preventivi", preventivo_id=accettato["preventivo"]["id"], verifica_stato="Assegnata")
    assert len(dopo) == 2 and {x["verificatore"] for x in dopo} == {io["nome"]}
    assert admin.get("/righe-preventivi").status_code == 200


def test_affidamento_dalle_righe_dm(admin):
    sede = crea_sede(admin, crea_cliente(admin)["id"])
    v, _a, p = incarico(admin, sede)
    io = ok(admin.get("/api/io"))
    rr = righe(admin, "righe_preventivi_dm", preventivo_id=p["id"])
    assert [(x["preventivo_id"], x["verifica_id"], x["verifica_stato"], x["gruppo"]) for x in rr] == [(p["id"], v["id"], "Da assegnare", "GVR")]
    r = ok(admin.post("/api/dm/incarichi/assegna-in-blocco", {"verificatore_id": io["id"],
                                                             "incarichi": [{"id": rr[0]["verifica_id"], "versione": rr[0]["verifica_versione"]}]}))
    assert r["assegnate"] == 1
    assert righe(admin, "righe_preventivi_dm", preventivo_id=p["id"])[0]["verifica_stato"] == "Assegnata"
    assert admin.post("/api/griglie/righe_preventivi/dati", {"contesto": {"preventivo_id": p["id"]}}).status_code == 404  # ambito errato
    html = admin.get("/righe-preventivi-dm").text
    assert "righe_preventivi.js" in html and "Righe dei preventivi" in html


def test_griglia_incarichi_dm_e_righe_del_preventivo(admin):
    """0.12.9: Verifiche DM sulla griglia standard (selezione multipla, filtri) e righe filtrate per preventivo,
    usate dalla linguetta «Righe» della scheda per l'affidamento come in Garda."""
    sede = crea_sede(admin, crea_cliente(admin)["id"])
    v, _a, p = incarico(admin, sede)
    g = ok(admin.post("/api/griglie/incarichi_dm/dati", {}))["righe"]
    assert [(x["id"], x["stato"], x["gruppo"], x["preventivo_id"]) for x in g] == [(v["id"], "Da assegnare", "GVR", p["id"])]
    assert g[0]["tipo"] in ("Prima verifica periodica", "Verifica periodica successiva")
    filtrate = ok(admin.post("/api/griglie/incarichi_dm/dati", {"filtri": [{"campo": "stato", "valore": "Da assegnare"}]}))["righe"]
    assert len(filtrate) == 1
    righe_p = ok(admin.post("/api/griglie/righe_preventivi_dm/dati", {"filtri": [{"campo": "preventivo_id", "valore": str(p["id"])}]}))["righe"]
    assert [x["verifica_id"] for x in righe_p] == [v["id"]]
    assert admin.post("/api/griglie/righe_preventivi_dm/dati", {"filtri": [{"campo": "preventivo_id", "valore": str(p["id"] + 999)}]}).status_code == 404
    assert "griglia" in admin.get("/incarichi-dm").text


def test_dati_del_tecnico_nella_scheda_utente(admin):
    """0.12.9: i dati del tecnico si leggono e si salvano dalla scheda dell'utente (non più dall'incarico)."""
    io = ok(admin.get("/api/io"))
    p = ok(admin.get(f"/api/dm/tecnici/{io['id']}/profilo"))
    x = ok(admin.put(f"/api/dm/tecnici/{io['id']}/profilo", {"versione": p["versione"], "nome": "Mario", "cognome": "Rossi",
                                                            "qualifica": "Per. Ind.", "codice_fiscale": "rssmra80a01l219x"}))
    assert (x["nome"], x["codice_fiscale"]) == ("Mario", "RSSMRA80A01L219X")
    assert ok(admin.get(f"/api/dm/tecnici/{io['id']}/profilo"))["cognome"] == "Rossi"
    assert "dati-tecnico" in admin.get("/profilo").text
