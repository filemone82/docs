"""0.12.4 · R114: anagrafica unica con gli ambiti di lavoro AD_DPR, AD_DM, I&C. 0.16 · R137: l'ambito è del cliente e le sedi lo ereditano."""

from __future__ import annotations

from test_anagrafica import PIVA_2, crea_cliente, crea_impianto, crea_sede
from test_beni import nuovo, ok


def righe(admin, codice, ambito="", **filtri):
    corpo = {"ambito": ambito, "filtri": [{"campo": k, "valore": v} for k, v in filtri.items()], "dimensione": 100}
    return ok(admin.post(f"/api/griglie/{codice}/dati", corpo))["righe"]


def test_si_accendono_da_soli_e_si_spengono_solo_se_non_servono(admin):
    c = crea_cliente(admin)
    assert c["ambiti"] == []  # nessuna indicazione dall'API: nessun ambito finché non entra qualcosa
    sd = crea_sede(admin, c["id"])
    assert sd["ambiti"] == []
    crea_impianto(admin, sd["id"])
    assert ok(admin.get(f"/api/sedi/{sd['id']}"))["ambiti"] == ["DPR"]
    assert ok(admin.get(f"/api/clienti/{c['id']}"))["ambiti"] == ["DPR"]
    # un'attrezzatura DM nella stessa sede: la sede e il cliente diventano anche AD_DM
    nuovo(admin, sd, "SC", "SC-1")
    sd = ok(admin.get(f"/api/sedi/{sd['id']}"))
    c = ok(admin.get(f"/api/clienti/{c['id']}"))
    assert sd["ambiti"] == ["DPR", "DM"] and c["ambiti"] == ["DPR", "DM"]
    # R137: sulla sede l'ambito non si cambia (si eredita dal cliente); lo stesso valore del cliente è accettato
    r = admin.put(f"/api/sedi/{sd['id']}", {**sd, "ambiti": ["DM"]})
    assert r.status_code == 400 and "si imposta sul cliente" in r.json()["errore"]
    sd = ok(admin.put(f"/api/sedi/{sd['id']}", {**sd, "ambiti": ["DPR", "DM"]}))
    # spegnere sul cliente: una sua sede ha ancora attrezzature → no, con il nome della sede
    r = admin.put(f"/api/clienti/{c['id']}", {**c, "ambiti": ["DPR"]})
    assert r.status_code == 400 and "attrezzature o accessori non dismessi" in r.json()["errore"] and sd["denominazione"] in r.json()["errore"]
    # I&C si accende a mano sul cliente e passa a tutte le sue sedi; poi si spegne
    c = ok(admin.put(f"/api/clienti/{c['id']}", {**c, "ambiti": ["DPR", "DM", "IEC"]}))
    seconda = crea_sede(admin, c["id"], denominazione="Magazzino")
    assert ok(admin.get(f"/api/sedi/{sd['id']}"))["ambiti"] == ["DPR", "DM", "IEC"] and seconda["ambiti"] == ["DPR", "DM", "IEC"]
    c = ok(admin.put(f"/api/clienti/{c['id']}", {**ok(admin.get(f"/api/clienti/{c['id']}")), "ambiti": ["DPR", "DM"]}))
    assert c["ambiti"] == ["DPR", "DM"] and ok(admin.get(f"/api/sedi/{seconda['id']}"))["ambiti"] == ["DPR", "DM"]
    # il cambio a mano resta nel registro con il prima e il dopo
    voci = ok(admin.post("/api/griglie/registro/dati", {"ricerca": "Modificato il cliente", "dimensione": 10}))["righe"]
    assert voci
    r = admin.put(f"/api/clienti/{c['id']}", {**c, "ambiti": ["XYZ"]})
    assert r.status_code == 400


def test_elenchi_per_ambito(admin):
    dpr = crea_cliente(admin, ragione_sociale="Solo impianti S.r.l.")
    crea_impianto(admin, crea_sede(admin, dpr["id"])["id"])
    dm = crea_cliente(admin, ragione_sociale="Solo attrezzature S.r.l.", partita_iva=PIVA_2, codice_fiscale=PIVA_2, ambiti=["DM"])
    assert dm["ambiti"] == ["DM"]
    sede_dm = crea_sede(admin, dm["id"], denominazione="Officina")
    assert sede_dm["ambiti"] == ["DM"]  # la sede nuova senza indicazioni prende gli ambiti del cliente
    nuovo(admin, sede_dm, "GVR", "GVR-1")
    definizione = ok(admin.get("/api/griglie/clienti/definizione"))
    assert definizione["filtra_ambito"] and not ok(admin.get("/api/griglie/impianti/definizione"))["filtra_ambito"]
    def nomi(rr, campo="ragione_sociale"):
        return sorted(x[campo] for x in rr)

    assert nomi(righe(admin, "clienti")) == ["Solo attrezzature S.r.l.", "Solo impianti S.r.l."]
    assert nomi(righe(admin, "clienti", "DPR")) == ["Solo impianti S.r.l."]
    assert nomi(righe(admin, "clienti", "DM")) == ["Solo attrezzature S.r.l."]
    assert righe(admin, "clienti", "IEC") == []
    assert nomi(righe(admin, "sedi", "DM"), "denominazione") == ["Officina"]
    assert righe(admin, "clienti", "DM")[0]["n_attrezzature"] == 1
    # le colonne si possono anche filtrare a mano (e si esportano)
    assert nomi(righe(admin, "clienti", ambito_dm="Sì")) == ["Solo attrezzature S.r.l."]
    r = admin.post("/api/griglie/clienti/esporta", {"ambito": "DPR", "colonne": ["ragione_sociale"]})
    assert r.status_code == 200
    # un preventivo DM per il cliente solo impianti lo rende anche AD_DM
    sede_dpr = ok(admin.get(f"/api/clienti/{dpr['id']}/sedi"))[0]
    a = nuovo(admin, {"id": sede_dpr["id"]}, "SC", "SC-9")
    ok(admin.post("/api/preventivi", {"ambito": "DM", "sede_id": sede_dpr["id"],
                                      "attrezzature": [{"asset_id": a["id"], "tipo_verifica_dm": "V2"}]}))
    assert ok(admin.get(f"/api/clienti/{dpr['id']}"))["ambiti"] == ["DPR", "DM"]


def test_migrazione_ricava_gli_ambiti(admin, app):
    from alembic import command

    from gestionale.core import migrazioni

    dpr = crea_cliente(admin)
    crea_impianto(admin, crea_sede(admin, dpr["id"])["id"])
    dm = crea_cliente(admin, ragione_sociale="Attrezzature", partita_iva=PIVA_2, codice_fiscale=PIVA_2)
    nuovo(admin, crea_sede(admin, dm["id"]), "SC", "SC-1")
    vuoto = crea_cliente(admin, ragione_sociale="Prospect", partita_iva="", codice_fiscale="RSSMRA85T10A562S", tipo="persona_fisica")
    arc = app.state.archivio
    cfg = migrazioni.config_alembic("sqlite:///" + str(arc.cfg.percorso_database))
    command.downgrade(cfg, "0015")
    migrazioni.aggiorna(arc.motore)
    assert migrazioni.revisione_database(arc.motore) == migrazioni.revisione_programma()
    assert ok(admin.get(f"/api/clienti/{dpr['id']}"))["ambiti"] == ["DPR"]
    assert ok(admin.get(f"/api/clienti/{dm['id']}"))["ambiti"] == ["DM"]
    assert ok(admin.get(f"/api/clienti/{vuoto['id']}"))["ambiti"] == ["DPR"]


def test_preventivi_solo_nel_proprio_ambito(admin):
    """Richiesta dell'11/10, 11:56: nel nuovo preventivo DM solo sedi AD_DM; se serve, l'ambito si cambia dall'anagrafica."""
    dpr = crea_cliente(admin, ambiti=["DPR"])
    sede_dpr = crea_sede(admin, dpr["id"], denominazione="Cabina")
    dm = crea_cliente(admin, ragione_sociale="Officina DM", partita_iva=PIVA_2, codice_fiscale=PIVA_2, ambiti=["DM"])
    sede_dm = crea_sede(admin, dm["id"], denominazione="Officina")
    # ricerche dei due «Nuovo preventivo»
    assert [x["denominazione"] for x in ok(admin.get("/api/sedi/cerca?ambito=DM"))] == ["Officina"]
    assert [x["ragione_sociale"] for x in ok(admin.get("/api/clienti/cerca?ambito=DPR"))] == [dpr["ragione_sociale"]]
    assert len(ok(admin.get("/api/sedi/cerca"))) == 2  # senza ambito: tutte (anagrafica)
    # creazione: rifiutata fuori ambito, con l'indicazione di dove cambiarlo
    r = admin.post("/api/preventivi", {"ambito": "DM", "sede_id": sede_dpr["id"]})
    assert r.status_code == 400 and "non è AD_DM" in r.json()["errore"]
    r = admin.post("/api/preventivi", {"cliente_id": dm["id"]})
    assert r.status_code == 400 and "non è AD_DPR" in r.json()["errore"]
    ok(admin.post("/api/preventivi", {"ambito": "DM", "sede_id": sede_dm["id"]}))
    ok(admin.post("/api/preventivi", {"cliente_id": dpr["id"]}))
    # l'ambito aggiunto a mano al cliente (e quindi a tutte le sue sedi, R137) apre il preventivo DM
    c = ok(admin.get(f"/api/clienti/{dpr['id']}"))
    ok(admin.put(f"/api/clienti/{c['id']}", {**c, "ambiti": ["DPR", "DM"]}))
    assert "Cabina" in [x["denominazione"] for x in ok(admin.get("/api/sedi/cerca?ambito=DM"))]
    ok(admin.post("/api/preventivi", {"ambito": "DM", "sede_id": sede_dpr["id"]}))
    assert ok(admin.get(f"/api/clienti/{dpr['id']}"))["ambiti"] == ["DPR", "DM"]
