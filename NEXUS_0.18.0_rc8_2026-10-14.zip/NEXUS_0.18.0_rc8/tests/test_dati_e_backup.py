"""Registro a catena, documenti, backup/verifica/ripristino, migrazioni, avvio."""

from __future__ import annotations

import sqlite3
import zipfile

import pytest
from alembic.autogenerate import compare_metadata
from alembic.runtime.migration import MigrationContext

from conftest import nuovo_utente
from gestionale.app import DatabaseTroppoNuovo, prepara_archivio
from gestionale.modelli import Base
from gestionale.moduli.documenti import servizio as documenti


def _sql(cfg, comando, parametri=()):
    conn = sqlite3.connect(cfg.percorso_database)
    try:
        conn.execute(comando, parametri)
        conn.commit()
    finally:
        conn.close()


def test_schema_del_database_uguale_ai_modelli(app):
    """Le migrazioni descrivono esattamente i modelli: nessuna differenza dimenticata."""
    with app.state.archivio.motore.connect() as conn:
        differenze = compare_metadata(MigrationContext.configure(conn), Base.metadata)
    assert differenze == []


def test_migrazione_fallita_annulla_ddl_e_ripristina_vincoli(cfg):
    """Anche una ricostruzione di tabella deve annullarsi se trova riferimenti non integri."""
    from alembic import command

    from gestionale.core import migrazioni
    from gestionale.core.db import Archivio

    cfg.prepara_cartelle()
    command.upgrade(migrazioni.config_alembic(f"sqlite:///{cfg.percorso_database}"), "0008")
    # Archivio deliberatamente malformato, creato fuori dal servizio applicativo.
    _sql(cfg, """INSERT INTO verifiche_documenti
        (id, verifica_id, formato, documento_id, nome_file, in_uso, creato_il, creato_da)
        VALUES (1,999,'pdf',999,'inesistente.pdf',1,'2026-10-08','prova')""")
    arc = Archivio(cfg)
    try:
        with pytest.raises(RuntimeError, match="collegamenti"):
            migrazioni.aggiorna(arc.motore)
        assert migrazioni.revisione_database(arc.motore) == "0008"
        with arc.motore.connect() as conn:
            assert conn.exec_driver_sql("PRAGMA foreign_keys").scalar() == 1
            assert conn.exec_driver_sql("SELECT COUNT(*) FROM verifiche_documenti").scalar() == 1
            assert conn.exec_driver_sql("SELECT COUNT(*) FROM sqlite_master WHERE name='fatture'").scalar() == 0
    finally:
        arc.chiudi()


def test_registro_non_modificabile_ne_cancellabile(admin, cfg):
    with pytest.raises(sqlite3.IntegrityError, match="non si può modificare"):
        _sql(cfg, "UPDATE registro_operazioni SET descrizione='falso'")
    with pytest.raises(sqlite3.IntegrityError, match="non si può cancellare"):
        _sql(cfg, "DELETE FROM registro_operazioni")


def test_catena_del_registro_scopre_le_alterazioni(admin, cfg):
    assert admin.post("/api/registro/verifica").json()["integro"]
    # Simula un'alterazione fatta aggirando le protezioni del database
    _sql(cfg, "DROP TRIGGER registro_operazioni_niente_modifiche")
    _sql(cfg, "UPDATE registro_operazioni SET descrizione='alterata' WHERE id=1")
    esito = admin.post("/api/registro/verifica").json()
    assert not esito["integro"] and esito["prima_riga_alterata"] == 1
    assert not admin.post("/api/backup/integrita").json()["tutto_ok"]


def test_documenti_con_impronta_e_controllo(app, cfg):
    arc = app.state.archivio
    with arc.scrittura() as s:
        doc = documenti.salva(s, cfg.cartella_documenti, b"contenuto di prova", "prova.txt", "text/plain")
        doppio = documenti.salva(s, cfg.cartella_documenti, b"contenuto di prova", "copia.txt", "text/plain")
        assert doc.id == doppio.id  # stesso contenuto, un solo file
    with arc.lettura() as s:
        assert documenti.verifica_tutti(s, cfg.cartella_documenti)["integri"]
        _, contenuto = documenti.leggi(s, cfg.cartella_documenti, doc.id)
        assert contenuto == b"contenuto di prova"
    file = documenti.percorso_file(cfg.cartella_documenti, doc.impronta)
    file.chmod(0o600)
    file.write_bytes(b"alterato")
    with arc.lettura() as s:
        esito = documenti.verifica_tutti(s, cfg.cartella_documenti)
    assert not esito["integri"] and esito["alterati"] == ["prova.txt"]


def test_backup_verifica_e_ripristino(admin, app, cfg):
    arc = app.state.archivio
    with arc.scrittura() as s:
        documenti.salva(s, cfg.cartella_documenti, b"documento importante", "verbale.pdf", "application/pdf")
    nome = admin.post("/api/backup").json()["nome"]
    assert admin.post(f"/api/backup/{nome}/verifica").json()["valido"]
    # dopo il backup si crea un utente e un nuovo documento
    nuovo_utente(admin, app, "anna", "segreteria")
    with arc.scrittura() as s:
        documenti.salva(s, cfg.cartella_documenti, b"documento successivo", "dopo.pdf")
    assert admin.post("/api/griglie/utenti/dati", {}).json()["totale"] == 2
    # conferma obbligatoria
    assert admin.post(f"/api/backup/{nome}/ripristina", {"conferma": "no"}).status_code == 400
    r = admin.post(f"/api/backup/{nome}/ripristina", {"conferma": "RIPRISTINA"})
    assert r.status_code == 200, r.text
    sicurezza = r.json()["backup_di_sicurezza"]
    assert "pre_ripristino" in sicurezza
    # tutti devono rientrare
    assert admin.get("/api/io").status_code == 401
    admin.c.post("/api/accesso", json={"username": "federico", "password": "una frase abbastanza lunga"})
    from conftest import Sessione
    admin2 = Sessione(admin.c)
    assert admin2.post("/api/griglie/utenti/dati", {}).json()["totale"] == 1  # anna non c'era nel backup
    integrita = admin2.post("/api/backup/integrita").json()
    assert integrita["tutto_ok"] and integrita["documenti"]["controllati"] == 7  # documento + due offerte + due modelli verbale DM + le due rev. 03 (R136)
    registro = admin2.post("/api/griglie/registro/dati", {"ricerca": "Ripristinato"}).json()
    assert registro["totale"] == 1
    # il backup di sicurezza permette di tornare indietro
    r = admin2.post(f"/api/backup/{sicurezza}/ripristina", {"conferma": "RIPRISTINA"})
    assert r.status_code == 200


def test_backup_alterato_non_si_ripristina(admin, cfg):
    nome = admin.post("/api/backup").json()["nome"]
    originale = cfg.cartella_backup / nome
    alterato = cfg.cartella_backup / nome.replace("manuale", "manuale_2")
    with zipfile.ZipFile(originale) as z_in, zipfile.ZipFile(alterato, "w") as z_out:
        for voce in z_in.infolist():
            dati = z_in.read(voce.filename)
            if voce.filename == "database.sqlite":
                dati = dati[:-100] + b"x" * 100
            z_out.writestr(voce, dati)
    esito = admin.post(f"/api/backup/{alterato.name}/verifica").json()
    assert not esito["valido"] and any("alterato" in p for p in esito["problemi"])
    r = admin.post(f"/api/backup/{alterato.name}/ripristina", {"conferma": "RIPRISTINA"})
    assert r.status_code == 400


def test_carica_backup_da_file(admin, cfg):
    nome = admin.post("/api/backup").json()["nome"]
    contenuto = (cfg.cartella_backup / nome).read_bytes()
    r = admin.c.post("/api/backup/carica", headers=admin.h, files={"file": ("mio backup.zip", contenuto, "application/zip")})
    assert r.status_code == 200 and "caricato" in r.json()["nome"]
    r = admin.c.post("/api/backup/carica", headers=admin.h, files={"file": ("finto.zip", b"non sono uno zip", "application/zip")})
    assert r.status_code == 400


def test_nomi_di_backup_non_validi_rifiutati(admin):
    assert admin.post("/api/backup/..%2Fdatabase.sqlite/verifica").status_code in (404, 400)
    assert admin.get("/api/backup/database.sqlite/scarica").status_code == 404


def test_riavvio_idempotente(app, cfg, admin):
    arc2 = prepara_archivio(cfg)  # come un secondo avvio del programma
    arc2.chiudi()
    assert admin.post("/api/registro/verifica").json()["integro"]


def test_database_di_versione_futura_non_si_apre(app, cfg):
    app.state.archivio.chiudi()
    _sql(cfg, "UPDATE alembic_version SET version_num='9999'")
    with pytest.raises(DatabaseTroppoNuovo):
        prepara_archivio(cfg)


def test_backup_automatici_conservati_entro_il_limite(app, cfg):
    from gestionale.moduli.backup import servizio as backup
    arc = app.state.archivio
    arc.cfg.backup_automatici_da_conservare = 3
    for _ in range(5):
        backup.crea(arc, "automatico")
    assert len(list(cfg.cartella_backup.glob("*_automatico*.zip"))) == 3


def test_backup_chiude_tutte_le_connessioni(app, monkeypatch):
    """Su Windows un file ancora aperto non si cancella: il backup deve chiudere ogni connessione
    (errore trovato sul PC dell'ufficio il 04/10/2026 durante l'importazione)."""
    import sqlite3

    from gestionale.moduli.backup import servizio as backup

    aperte = []
    originale = sqlite3.connect

    class Connessione(sqlite3.Connection):
        def close(self):
            aperte.remove(self)
            super().close()

    def connetti(*a, **kw):
        c = originale(*a, factory=Connessione, **kw)
        aperte.append(c)
        return c

    monkeypatch.setattr(backup.sqlite3, "connect", connetti)
    backup.crea(app.state.archivio, "manuale")
    assert aperte == []
