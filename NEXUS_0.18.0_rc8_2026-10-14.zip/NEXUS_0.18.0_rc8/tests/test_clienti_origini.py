"""0.12.6 · Revisione dell'11/10/2026: fusione dei clienti senza scelte silenziose, clienti doppi da confermare,
tabella delle corrispondenze con Garda (R120), scadenze AD_DM."""

from __future__ import annotations

from sqlalchemy import select
from test_garda import MINI
from test_garda_dm import MINI_DM

from gestionale.moduli.anagrafica import origini
from gestionale.moduli.anagrafica.modelli import Cliente, Origine, Sede
from gestionale.moduli.garda import dump, importa, importa_dm


def _importa(app, dm_testo=MINI_DM):
    arc = app.state.archivio
    with arc.scrittura() as s:
        importa.importa(s, None, dump.leggi(MINI, importa.TABELLE), "mini.sql")
    with arc.scrittura() as s:
        return importa_dm.importa(s, None, dump.leggi(dm_testo, importa_dm.TABELLE_DM), "mini_dm.sql")


def test_corrispondenze_registrate_dalle_importazioni(admin, app):
    esito = _importa(app)
    assert esito["importati"]["corrispondenze con Garda registrate"] == 2 + 3  # 2 clienti, 3 sedi di adsrl
    with app.state.archivio.lettura() as s:
        officina = s.scalar(select(Cliente).where(Cliente.partita_iva == "01234567897"))
        for sistema, tabella, gid, entita in ((origini.INGECERT, "clienti", 10, "cliente"), (origini.ADSRL, "clienti", 1, "cliente")):
            o = origini.trova(s, sistema, tabella, gid)
            assert (o.entita, o.entita_id) == (entita, officina.id)
        # la sede adsrl 10 unita alla sede DPR 100: le due origini portano alla stessa sede
        assert origini.trova(s, origini.ADSRL, "clienti_sedi_operative", 10).entita_id == origini.trova(s, origini.INGECERT, "clienti_sedi_operative", 100).entita_id
        for tabella in ("impianti", "preventivi", "preventivi_righe", "verifiche"):
            assert s.scalar(select(Origine).where(Origine.sistema == origini.INGECERT, Origine.tabella == tabella)) is not None, tabella
    c = admin.get(f"/api/clienti/{officina.id}").json()
    assert {(o["sistema"], o["id_origine"]) for o in c["origini"]} == {("garda_ingecert", "10"), ("garda_adsrl", "1")}


def test_fusione_solo_se_certa_e_unione_da_confermare(admin, app):
    # il cliente adsrl 1 ha la P.IVA dell'Officina (ingecert 10) ma il codice fiscale del Comune (ingecert 11): nessuna scelta silenziosa
    ambiguo = MINI_DM.replace("'OFFICINA L\\'ANCORA SRL', 'Via Roma 1', NULL, 'Torino', '10121', 'TO', 'Piemonte', '01234567897', '01234567897'",
                              "'OFFICINA L\\'ANCORA SRL', 'Via Roma 1', NULL, 'Torino', '10121', 'TO', 'Piemonte', '00000000000', '01234567897'")
    assert ambiguo != MINI_DM
    esito = _importa(app, ambiguo)
    imp = esito["importati"]
    assert imp["clienti AD_dm non fusi perché la corrispondenza non è certa (da confermare)"] == 1
    assert "clienti già presenti, fusi con AD_dm" not in imp and imp["clienti nuovi da AD_dm"] == 2
    with app.state.archivio.lettura() as s:
        nuovo = s.scalar(select(Cliente).where(Cliente.codice_esterno == "dm:1"))
        assert "corrispondenza non è certa" in nuovo.avvisi
        officina = s.scalar(select(Cliente).where(Cliente.codice_esterno == "10"))
        nuovo_id, officina_id = nuovo.id, officina.id
    coppie = admin.get("/api/clienti/doppioni").json()
    assert {(c["a"]["id"], c["b"]["id"]) for c in coppie} >= {(officina_id, nuovo_id)}
    # unione: resta l'Officina; sedi e corrispondenze passano lì
    r = admin.post(f"/api/clienti/{nuovo_id}/unisci", {"destinazione_id": officina_id})
    assert r.status_code == 200, r.text
    assert "Unito il cliente «OFFICINA L'ANCORA SRL»" in r.json()["note"] and r.json()["ambiti"] == ["DPR", "DM"]
    assert admin.get(f"/api/clienti/{nuovo_id}").status_code == 404
    with app.state.archivio.lettura() as s:
        assert s.scalar(select(Sede).where(Sede.codice_esterno == "dm:10")).cliente_id == officina_id
        assert origini.trova(s, origini.ADSRL, "clienti", 1).entita_id == officina_id
    # ora le due sedi della stessa via (DPR 100 e adsrl 10) sono proposte come doppioni di sede
    assert any(c["stesso_indirizzo"] for c in admin.get("/api/sedi/doppioni").json())
    # le coppie rimaste si dichiarano diverse e non tornano
    for c in admin.get("/api/clienti/doppioni").json():
        assert admin.post("/api/clienti/doppioni/diversi", {"a": c["a"]["id"], "b": c["b"]["id"]}).status_code == 200
    assert admin.get("/api/clienti/doppioni").json() == []


def test_migrazione_0018_recupera_le_corrispondenze(admin, app):
    from alembic import command

    from gestionale.core import migrazioni

    _importa(app)
    arc = app.state.archivio
    with arc.scrittura() as s:  # come un archivio della 0.12.5: corrispondenze solo nei campi di testo
        for o in s.scalars(select(Origine)):
            s.delete(o)
    cfg = migrazioni.config_alembic("sqlite:///" + str(arc.cfg.percorso_database))
    command.downgrade(cfg, "0017")
    migrazioni.aggiorna(arc.motore)
    assert migrazioni.revisione_database(arc.motore) == migrazioni.revisione_programma()
    with arc.lettura() as s:
        officina = s.scalar(select(Cliente).where(Cliente.partita_iva == "01234567897"))
        assert origini.trova(s, origini.INGECERT, "clienti", 10).entita_id == officina.id
        assert origini.trova(s, origini.ADSRL, "clienti", 1).entita_id == officina.id   # dalle note del cliente fuso
        assert origini.trova(s, origini.ADSRL, "clienti", 2) is not None                 # «dm:2»
        assert origini.trova(s, origini.ADSRL, "clienti_sedi_operative", 10).entita_id == origini.trova(s, origini.INGECERT, "clienti_sedi_operative", 100).entita_id
        assert origini.trova(s, origini.INGECERT, "impianti", 1000) is not None


def test_scadenze_dm_e_schede_nel_contesto_dm(admin, app):
    _importa(app)
    righe = admin.post("/api/griglie/scadenze_dm/dati", {"dimensione": 100}).json()["righe"]
    gv = [r for r in righe if r["matr_informale"] == "GV-1"]
    assert {r["componente"] for r in gv} == {"Funzionamento", "Integrità", "Visita interna", "CND"}
    assert all(r["cliente_ragione_sociale"] for r in righe) and not any(r["matr_informale"] == "G-1" for r in righe)  # la gru dismessa no
    with app.state.archivio.lettura() as s:
        caseificio = s.scalar(select(Cliente).where(Cliente.codice_esterno == "dm:2")).id
        officina = s.scalar(select(Cliente).where(Cliente.codice_esterno == "10")).id
    filtrate = admin.post("/api/griglie/scadenze_dm/dati", {"filtri": [{"campo": "cliente_id", "valore": str(officina)}]}).json()["righe"]
    assert filtrate and all(r["cliente_id"] == officina for r in filtrate)
    c = admin.get(f"/api/clienti/{caseificio}").json()
    assert c["n_attrezzature"] == 2 and c["n_impianti"] == 0
    sedi = admin.get(f"/api/clienti/{caseificio}/sedi").json()
    assert sum(x["n_attrezzature"] for x in sedi) == 2
    assert admin.get("/scadenze-tecniche").status_code == 200 and "scadenze_dm.js" in admin.get("/scadenze-tecniche").text
