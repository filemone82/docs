"""Regressioni tecniche DM su HTTP reale in memoria; attese ricavate da Garda."""
import json

import pytest

from conftest import nuovo_utente, segna_inviato
from test_dm_preventivi import gvr, gv, offerta
from test_beni import ok, nuovo
from test_anagrafica import crea_cliente, crea_sede
from gestionale.moduli.dm.modelli import IncaricoDM, ContatoreDM


@pytest.fixture(name="sede")
def sede_dm_tecnica(admin):
    return crea_sede(admin, crea_cliente(admin)["id"])


def incarico(admin, sede, a=None, comb='funz', tipo='V2'):
    # N9 (0.12.8): la PVP GVR richiede «soggetta a messa in servizio» compilato; qui «no» (art. 5) → colonna V2
    a = a or gvr(admin, sede, **({'soggetto_messa_servizio': False} if tipo == 'V1' else {}))
    p = ok(offerta(admin, sede, a, tipo, comb if a['gruppo']=='GVR' else ''))
    p = segna_inviato(admin, p)
    p = ok(admin.post(f"/api/preventivi/{p['id']}/righe/stato", {
        'versione': p['versione'], 'righe': [p['righe'][0]['id']], 'stato': 'accettata', 'evidenza_accettazione': 'Conferma scritta collaudo'}))
    ok(admin.post(f"/api/preventivi/{p['id']}/riesame", {
        'esito':'conforme', 'requisiti_chiari':True, 'competenza_strumenti':True, 'imparzialita':True, 'tempi':True}))
    xs = ok(admin.get('/api/dm/incarichi'))
    v = next(x for x in xs if x['preventivo_id']==p['id'])
    return ok(admin.get(f"/api/dm/incarichi/{v['id']}")), a, p


def assegna(admin, v, chi=None):
    chi = chi or ok(admin.get('/api/io'))['id']
    return ok(admin.post(f"/api/dm/incarichi/{v['id']}/assegna", {'versione':v['versione'], 'verificatore_id':chi}))


def salva(admin, v, **dati):
    return admin.put(f"/api/dm/incarichi/{v['id']}/bozza", {
        'versione':v['versione'], 'asset_versione':v['asset_versione'], **dati})


def registra(admin, v):
    return admin.post(f"/api/dm/incarichi/{v['id']}/registra", {'versione':v['versione']})


def pronta(admin, v, **dati):
    return ok(salva(admin, v, data_rilascio='2026-10-09', date={k:'2028-10-08' for k in v['componenti']}, **dati))


def camera(admin, a, **extra):
    return ok(admin.post(f"/api/beni/{a['id']}/camere", {'versione':a['versione'],
        'identificazione':'Camera A', 'num_fabbrica':'NF-A', 'unita':'L', 'valore':'100', **extra}))


def camera_bozza(c, **extra):
    return {k:c[k] for k in ('id','identificazione','num_fabbrica','unita','valore')} | {
        'dati_tecnici':c['attributi'], 'gvr_pes':'6 bar', 'gvr_tes':'110 °C', **extra}


def test_assegnazione_programmazione_non_obbligatoria_e_registrazione(admin, sede):
    v,a,p = incarico(admin,sede)
    assert registra(admin,v).status_code==400
    assert admin.post(f"/api/dm/incarichi/{v['id']}/assegna",{'verificatore_id':1}).status_code==400
    v=assegna(admin,v)
    assert v['stato']=='assegnata' and v['bozza']['regime']=='A2'
    assert registra(admin,v).status_code==400
    v=pronta(admin,v)
    v=ok(registra(admin,v))
    assert v['stato']=='registrata' and v['codice_verbale']=='V/GVR/0001/26'
    assert v['data_pvp']=='2028-10-08' and v['contributo']==726
    p=ok(admin.get(f"/api/preventivi/{p['id']}"))
    assert p['verifiche'][0]['stato_testo']=='Registrata'
    assert p['verifiche'][0]['codice_verbale']=='V/GVR/0001/26'
    # La chiusura esiste, ma resta bloccata finché manca il PDF confermato.
    assert admin.post(f"/api/dm/incarichi/{v['id']}/effettuata",{'versione':v['versione']}).status_code==400


def test_indipendenza_sospensione_ripresa_e_own_permission(admin,sede,app):
    t=nuovo_utente(admin,app,'dm_tecnico','tecnico_dm')
    altro=nuovo_utente(admin,app,'dm_altro','tecnico_dm')
    v,a,_=incarico(admin,sede)
    assert t.get('/api/dm/incarichi').json()==[]
    v=assegna(admin,v,t.get('/api/io').json()['id'])
    assert len(t.get('/api/dm/incarichi').json())==1
    assert altro.get(f"/api/dm/incarichi/{v['id']}").status_code==403
    assert salva(altro,v).status_code==403
    assert altro.post(f"/api/dm/incarichi/{v['id']}/assegna",{'versione':v['versione'],'verificatore_id':1}).status_code==403
    # R110 + R119 (11/10/2026): preimpostata su «Sì», la dichiara solo il tecnico assegnato; con «No» torna al RT.
    assert v['indipendenza'] is True
    assert admin.post(f"/api/dm/incarichi/{v['id']}/indipendenza",{'versione':v['versione'],'indipendenza':False}).status_code==403
    v=ok(t.post(f"/api/dm/incarichi/{v['id']}/indipendenza",{'versione':v['versione'],'indipendenza':False}))
    v=ok(admin.get(f"/api/dm/incarichi/{v['id']}"))
    assert v['stato']=='da_assegnare' and v['verificatore_id'] is None and 'NON essere indipendente' in v['indipendenza_esclusa']
    assert t.get(f"/api/dm/incarichi/{v['id']}").status_code==403  # non è più suo
    v=assegna(admin,v,t.get('/api/io').json()['id'])
    assert v['indipendenza'] is True and v['stato']=='assegnata'
    v=ok(t.post(f"/api/dm/incarichi/{v['id']}/programma",{'versione':v['versione'],'data_programmata':'2026-10-10'}))
    v=pronta(t,v)
    assert registra(t,v).status_code==200
    v=ok(t.get(f"/api/dm/incarichi/{v['id']}"))
    # dopo la registrazione non si cambia più
    r=t.post(f"/api/dm/incarichi/{v['id']}/indipendenza",{'versione':v['versione'],'indipendenza':False})
    assert r.status_code==400 and 'prima della registrazione' in r.text
    v=ok(t.post(f"/api/dm/incarichi/{v['id']}/sospendi",{'versione':v['versione'],'motivo':'Accesso impedito'}))
    assert v['stato']=='sospesa'
    assert salva(t,v).status_code==400
    v=ok(t.post(f"/api/dm/incarichi/{v['id']}/riprendi",{'versione':v['versione']}))
    assert v['stato']=='registrata' and v['indipendenza']


def test_versioni_conflitto_e_assegnazione_in_blocco_atomica(admin,sede):
    v,a,_=incarico(admin,sede)
    w,_,_=incarico(admin,sede,a,comb='integrita')
    chi=ok(admin.get('/api/io'))['id']
    r=admin.post('/api/dm/incarichi/assegna-in-blocco',{'incarichi':[{'id':v['id'],'versione':v['versione']},{'id':w['id'],'versione':0}], 'verificatore_id':chi})
    assert r.status_code==409
    assert ok(admin.get(f"/api/dm/incarichi/{v['id']}"))['stato']=='da_assegnare'
    assert ok(admin.post('/api/dm/incarichi/assegna-in-blocco',{'incarichi':[{'id':x['id'],'versione':x['versione']} for x in (v,w)], 'verificatore_id':chi}))['assegnate']==2
    assert admin.post(f"/api/dm/incarichi/{v['id']}/assegna",{'versione':v['versione'],'verificatore_id':chi}).status_code==409


def test_gvr_camere_bidirezionali_solo_pes_tes_in_verifica_e_quote_immutabili(admin,sede,app):
    a=camera(admin,gvr(admin,sede,dati_dm={'tipo_attr_verbale':'RG'}),dati_tecnici={'gvr_ps':'8','gvr_ts':'200'})
    a=ok(admin.post(f"/api/beni/{a['id']}/camere",{'versione':a['versione'], 'identificazione':'Tubo','num_fabbrica':'NF-T', 'unita':'DN','valore':'50'}))
    v,a,p=incarico(admin,sede,a)
    v=assegna(admin,v)
    assert v['bozza']['tipo_attr']=='RG'
    assert v['bozza']['volume_totale_litri']=='100'
    cams=[camera_bozza(c) for c in v['bozza']['camere']]
    cams[0]['dati_tecnici']['gvr_ps']='10';cams[0]['valore']='120,5'
    v=ok(salva(admin,v,camere=cams,tipo_attr='RV',campi={'gvr_breve_descr_funz':'Nuovo processo'}))
    a=ok(admin.get(f"/api/beni/{a['id']}"))
    assert a['attributi']['tipo_attr_verbale']=='RV' and a['attributi']['gvr_breve_descr_funz']=='Nuovo processo'
    assert a['camere'][0]['attributi']['gvr_ps']=='10'
    assert all('gvr_pes' not in c['attributi'] and 'gvr_tes' not in c['attributi'] for c in a['camere'])
    assert v['bozza']['camere'][0]['gvr_pes']=='6 bar'
    assert v['bozza']['volume_totale_litri']=='120.5'
    assert v['fotografia_preventivo']['volume_totale_litri']=='100'
    a=ok(admin.put(f"/api/beni/{a['id']}/camere/{a['camere'][0]['id']}",{'versione':a['versione'], 'identificazione':'Camera A','num_fabbrica':'NF-A','unita':'L','valore':'130','dati_tecnici':{'gvr_ps':'11'}}))
    assert salva(admin,v).status_code==409
    v=ok(admin.get(f"/api/dm/incarichi/{v['id']}"))
    assert v['bozza']['camere'][0]['gvr_pes']=='6 bar' and v['bozza']['camere'][0]['attributi']['gvr_ps']=='11'
    assert v['bozza']['volume_totale_litri']=='130'
    before=v['fotografia_preventivo']
    with app.state.archivio.lettura() as s:
        assert json.loads(s.get(IncaricoDM,v['id']).fotografia_json)==before


def test_integrita_non_copia_pes_tes_e_minima_delle_sole_componenti(admin,sede):
    a=camera(admin,gv(admin,sede))
    a=ok(admin.put(f"/api/beni/{a['id']}/scadenze",{'versione':a['versione'],'componente':'funzionamento','data_prossima':'2026-11-01'}))
    v,_,_=incarico(admin,sede,a,comb='integrita_interna')
    v=assegna(admin,v)
    assert v['bozza']['date']['funz']=='2026-11-01'
    v=ok(salva(admin,v,camere=[camera_bozza(c) for c in v['bozza']['camere']], data_rilascio='2026-10-09',date={'integrita':'2030-10-08','interna':'2027-10-08'}))
    assert all(not c['gvr_pes'] and not c['gvr_tes'] for c in v['bozza']['camere'])
    assert salva(admin,v,date={'funz':'2099-01-01'}).status_code==400
    v=ok(registra(admin,v))
    assert v['data_pvp']=='2027-10-08'


def test_validazione_registrazione_e_prove_condizionali(admin,sede):
    v,_,_=incarico(admin,sede,comb='integrita')
    v=assegna(admin,v)
    assert salva(admin,v,regime='A1').status_code==400  # V2 sola A2.
    v=pronta(admin,v,campi={'gvr_ver_attr':False,'gvr_ver_insieme':False})
    assert registra(admin,v).status_code==400
    v=ok(salva(admin,v,campi={'gvr_ver_attr':True,'gvr_ver_insieme':False,'gvr_es_spess_check':True}))
    assert registra(admin,v).status_code==400
    v=ok(salva(admin,v,campi={'gvr_es_spess_eseg':'Spessimetria','gvr_es_spess_data':'2026-10-08','gvr_es_spess_esito':'positivo'},esito='Negativo'))
    assert registra(admin,v).status_code==400
    v=ok(salva(admin,v,campi={'esito_motivi':'Perdita in esercizio'}))
    v=ok(registra(admin,v))
    assert v['stato']=='registrata'
    assert salva(admin,v,date={'integrita':None}).status_code==400
    assert ok(admin.get(f"/api/dm/incarichi/{v['id']}"))['bozza']['date']['integrita']=='2028-10-08'


def test_sc_sp_contatore_condiviso_gvr_distinto_anno_e_numeri_non_riusati(admin,sede):
    sc=nuovo(admin,sede,'SC','SC-1');sp=nuovo(admin,sede,'SP','SP-1')
    codes=[]
    for a in (sc,sp,gvr(admin,sede)):
        v,_,_=incarico(admin,sede,a)
        v=pronta(admin,assegna(admin,v),campi={'sc_sp_osservazioni':'Prova'} if a['gruppo']!='GVR' else {})
        v=ok(registra(admin,v));codes.append(v['codice_verbale'])
    assert codes==['V/SC/0001/26','V/SP/0002/26','V/GVR/0001/26']
    v=ok(salva(admin,v,data_rilascio='2027-01-05'))
    assert v['codice_verbale']=='V/GVR/0001/27'
    v=ok(salva(admin,v,data_rilascio='2026-12-01'))
    assert v['codice_verbale']=='V/GVR/0002/26'
    v=ok(admin.post(f"/api/dm/incarichi/{v['id']}/annulla",{'versione':v['versione'],'motivo':'Annullamento prova'}))
    assert v['codice_verbale']=='V/GVR/0002/26'


def test_v1_regime_contributo_tariffa_standard_non_scontata(admin,sede):
    v,_,_=incarico(admin,sede,tipo='V1')
    v=assegna(admin,v)
    assert not v['bozza']['regime']
    v=pronta(admin,v,regime='A1')
    v=ok(registra(admin,v))
    assert v['contributo']==3996  # 266.37 * 15%, centesimi arrotondati.


def test_camere_conflict_rollback_master_e_bozza(admin,sede):
    a=camera(admin,gvr(admin,sede))
    v,_,_=incarico(admin,sede,a);v=assegna(admin,v)
    cams=[camera_bozza(c) for c in v['bozza']['camere']]
    cams[0]['valore']='123'
    cams.append({**cams[0],'id':None})
    assert salva(admin,v,camere=cams).status_code==400
    assert ok(admin.get(f"/api/beni/{a['id']}"))['volume_totale_litri']=='100'
    assert ok(admin.get(f"/api/dm/incarichi/{v['id']}"))['versione']==v['versione']


def test_pagina_collegamenti_ricerca_e_maschera_tipi_garda(admin,sede):
    v,_,_=incarico(admin,sede)
    assert 'incarichi_dm.js' in admin.get('/incarichi-dm').text
    assert len(ok(admin.get('/api/dm/incarichi?q=PROVA_IMPOSSIBILE')))==0
    assert len(ok(admin.get('/api/dm/incarichi?q=GVR-001')))==1
    assert ok(admin.get('/api/dm/incarichi?q=%'))==[]
    v=assegna(admin,v)
    assert len([x for x in v['campi'] if x['nome'].startswith('sc_sp_')])==0
    assert 'gvr_check_conduttore' not in {x['nome'] for x in v['campi']}
    assert salva(admin,v,campi={'gvr_check_conduttore':True}).status_code==400
    assert '/verifiche-gvr' in admin.get('/preventivi-dm').text


def test_programmazione_reale_e_riassegnazione_azzerano_esclusione_indipendenza(admin,sede,app):
    tec=nuovo_utente(admin,app,'dm_prog','tecnico_dm')
    v,_,_=incarico(admin,sede);v=assegna(admin,v)
    v=ok(admin.post(f"/api/dm/incarichi/{v['id']}/programma",{'versione':v['versione'],'data_programmata':'2026-10-15'}))
    assert v['stato']=='programmata' and v['data_programmata']=='2026-10-15'
    v=ok(admin.post(f"/api/dm/incarichi/{v['id']}/indipendenza",{'versione':v['versione'],'indipendenza':False}))
    # R119: chi esclude l'indipendenza restituisce l'incarico al RT: niente tecnico, niente data prevista.
    v=ok(admin.get(f"/api/dm/incarichi/{v['id']}"))
    assert v['stato']=='da_assegnare' and v['data_programmata'] is None
    v=assegna(admin,v,tec.get('/api/io').json()['id'])
    assert v['indipendenza'] and v['stato']=='assegnata'
    # Il nuovo tecnico parte da «Sì» e può programmare.
    v=ok(tec.post(f"/api/dm/incarichi/{v['id']}/programma",{'versione':v['versione'],'data_programmata':'2026-10-16'}))
    assert v['data_programmata']=='2026-10-16'


def test_migrazione_0012_popolata_preserva_foto_fk_e_default(admin,app,sede):
    from alembic import command
    from gestionale.core import migrazioni
    v,a,p=incarico(admin,sede)
    arc=app.state.archivio
    cfg=migrazioni.config_alembic('sqlite:///'+str(arc.cfg.percorso_database))
    command.downgrade(cfg,'0012')
    with arc.motore.connect() as conn:
        dati=conn.exec_driver_sql('SELECT id,riga_id,asset_id,fotografia_json,versione FROM dm_incarichi').one()
        assert dati[0]==v['id'] and dati[1]==v['riga_id'] and dati[2]==a['id']
        assert json.loads(dati[3])==v['fotografia_preventivo']
        assert conn.exec_driver_sql('PRAGMA foreign_key_check').all()==[]
    migrazioni.aggiorna(arc.motore)
    dopo=ok(admin.get(f"/api/dm/incarichi/{v['id']}"))
    assert dopo['fotografia_preventivo']==v['fotografia_preventivo'] and dopo['stato']=='da_assegnare'
    assert dopo['versione']==v['versione'] and dopo['bozza']=={} and dopo['indipendenza']
    assert ok(admin.get(f"/api/preventivi/{p['id']}"))['verifiche'][0]['id']==v['id']
    assegna(admin,dopo)
    with pytest.raises(RuntimeError,match='Ritorno'):
        command.downgrade(cfg,'0012')
    assert migrazioni.revisione_database(arc.motore)=='0013'


def test_numerazione_concorrente_e_audit_coerente(admin,sede):
    from concurrent.futures import ThreadPoolExecutor
    vs=[]
    for i in range(2):
        v,_,_=incarico(admin,sede,gvr(admin,sede,matricola=f'CONC-{i}'))
        vs.append(pronta(admin,assegna(admin,v)))
    with ThreadPoolExecutor(max_workers=2) as pool:
        risultati=list(pool.map(lambda v:ok(registra(admin,v)),vs))
    assert {x['codice_verbale'] for x in risultati}=={'V/GVR/0001/26','V/GVR/0002/26'}
    assert admin.post('/api/registro/verifica').json()['integro']


def test_backup_ripristina_dm_contatore_bozza_e_documenti(admin,app,sede):
    from conftest import Sessione, PASSWORD_ADMIN
    v,_,_=incarico(admin,sede);v=ok(registra(admin,pronta(admin,assegna(admin,v))))
    nome=ok(admin.post('/api/backup'))['nome']
    assert ok(admin.post(f'/api/backup/{nome}/verifica'))['valido']
    ok(admin.post(f"/api/dm/incarichi/{v['id']}/annulla",{'versione':v['versione'],'motivo':'Prova ripristino'}))
    ok(admin.post(f'/api/backup/{nome}/ripristina',{'conferma':'RIPRISTINA'}))
    assert admin.c.post('/api/accesso',json={'username':'federico','password':PASSWORD_ADMIN}).status_code==200
    s=Sessione(admin.c)
    dopo=ok(s.get(f"/api/dm/incarichi/{v['id']}"))
    assert dopo['stato']=='registrata' and dopo['bozza']==v['bozza'] and dopo['codice_verbale']==v['codice_verbale']
    with app.state.archivio.lettura() as db:
        assert db.get(ContatoreDM,('GVR',2026)).ultimo==1
    assert ok(s.post('/api/backup/integrita'))['tutto_ok']


def test_nuove_camere_e_rimozione_propagano_a_tutti_i_lavori_aperti(admin,sede):
    a=camera(admin,gvr(admin,sede))
    v,_,_=incarico(admin,sede,a);v=assegna(admin,v)
    w,_,_=incarico(admin,sede,a,comb='integrita');w=assegna(admin,w)
    v=ok(salva(admin,v,camere=[camera_bozza(c) for c in v['bozza']['camere']]))
    w=ok(admin.get(f"/api/dm/incarichi/{w['id']}"))
    assert not w['bozza']['camere'][0]['gvr_pes']
    v=ok(salva(admin,v,camere=[{'identificazione':'Nuova','num_fabbrica':'NF-B','unita':'L','valore':'210','dati_tecnici':{'gvr_ps':'16'}}]))
    w=ok(admin.get(f"/api/dm/incarichi/{w['id']}"))
    assert len(w['bozza']['camere'])==1 and w['bozza']['camere'][0]['identificazione']=='Nuova'
    assert w['bozza']['volume_totale_litri']=='210'
    assert len(ok(admin.get(f"/api/beni/{a['id']}"))['camere'])==1


def test_salva_e_registra_e_una_sola_transazione_anche_per_il_master(admin,sede):
    a=camera(admin,gvr(admin,sede,dati_dm={'tipo_attr_verbale':'RG'}))
    v,_,_=incarico(admin,sede,a);v=assegna(admin,v)
    cams=[camera_bozza(c,valore='155') for c in v['bozza']['camere']]
    bozza={'asset_versione':v['asset_versione'],'tipo_attr':'RV','camere':cams,'data_rilascio':'2026-10-09'}
    r=admin.post(f"/api/dm/incarichi/{v['id']}/registra",{'versione':v['versione'],'bozza':bozza})
    assert r.status_code==400  # manca prossima funzionamento
    after=ok(admin.get(f"/api/beni/{a['id']}"))
    assert after['volume_totale_litri']=='100' and after['attributi']['tipo_attr_verbale']=='RG'
    assert after['versione']==a['versione']
    assert ok(admin.get(f"/api/dm/incarichi/{v['id']}"))['versione']==v['versione']
    bozza['date']={'funz':'2029-10-08'}
    v=ok(admin.post(f"/api/dm/incarichi/{v['id']}/registra",{'versione':v['versione'],'bozza':bozza}))
    assert v['codice_verbale']=='V/GVR/0001/26' and v['bozza']['volume_totale_litri']=='155'
