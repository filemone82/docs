"""Strumenti comuni dei test: ogni test ha la sua cartella dati vuota."""

from __future__ import annotations

import re
import warnings

import pytest

warnings.filterwarnings("ignore", category=DeprecationWarning)

from fastapi.testclient import TestClient  # noqa: E402

from gestionale.app import crea_app  # noqa: E402
from gestionale.core.config import Config  # noqa: E402

PASSWORD_ADMIN = "una frase abbastanza lunga"


@pytest.fixture(autouse=True)
def pdf_veloce(request, monkeypatch):
    """PDF dei preventivi finti (veloci, anche senza LibreOffice), salvo i test segnati «pdf_vero»."""
    if request.node.get_closest_marker("pdf_vero") is None:
        from gestionale.core import pdf
        monkeypatch.setattr(pdf, "da_word", lambda docx, conf="": pdf_sintetico(docx))


def segna_inviato(s, p: dict) -> dict:
    """0.7.0 (D80): come dall'interfaccia — anteprima, approvazione del documento, «Segna come inviato»."""
    r = s.post(f"/api/preventivi/{p['id']}/anteprima")
    assert r.status_code == 200, r.text
    doc = r.json()["documento"]
    if not doc["approvato"]:
        assert s.post(f"/api/preventivi/{p['id']}/documenti/{doc['pdf_documento_id']}/approva").status_code == 200
    x = s.get(f"/api/preventivi/{p['id']}").json()
    r = s.post(f"/api/preventivi/{p['id']}/inviato", {"versione": x["versione"]})
    assert r.status_code == 200, r.text
    return r.json()


@pytest.fixture
def cfg(tmp_path) -> Config:
    return Config(cartella_dati=tmp_path / "dati", iterazioni_password=1000, backup_automatico=False, apri_browser=False)


@pytest.fixture
def app(cfg):
    return crea_app(cfg)


@pytest.fixture
def client(app):
    with TestClient(app, base_url="http://testserver") as c:
        yield c


def csrf_da_pagina(c: TestClient) -> str:
    html = c.get("/profilo").text
    return re.search(r'name="csrf" content="([^"]+)"', html).group(1)


class Sessione:
    """Client con utente collegato e intestazione anti-contraffazione pronta."""

    def __init__(self, c: TestClient) -> None:
        self.c = c
        self.h = {"X-CSRF-Token": csrf_da_pagina(c)}

    def get(self, url, **kw):
        return self.c.get(url, **kw)

    def post(self, url, json=None, **kw):
        return self.c.post(url, json=json, headers=self.h, **kw)

    def put(self, url, json=None, **kw):
        return self.c.put(url, json=json, headers=self.h, **kw)

    def delete(self, url, **kw):
        return self.c.delete(url, headers=self.h, **kw)


@pytest.fixture
def admin(client) -> Sessione:
    r = client.post("/api/primo-avvio", json={"username": "federico", "nome": "Federico Amateis", "password": PASSWORD_ADMIN})
    assert r.status_code == 200, r.text
    return Sessione(client)


def ruolo_id(s: Sessione, codice: str) -> int:
    return next(r["id"] for r in s.get("/api/ruoli").json() if r["codice"] == codice)


def nuovo_utente(admin: Sessione, app, username: str, codice_ruolo: str, password: str = "password nuova personale") -> Sessione:
    """Crea un utente, entra con la password provvisoria e la cambia. Restituisce la sua sessione."""
    r = admin.post("/api/utenti", {"username": username, "nome": username.title(), "ruolo_id": ruolo_id(admin, codice_ruolo)})
    assert r.status_code == 200, r.text
    provvisoria = r.json()["password_provvisoria"]
    c = TestClient(app, base_url="http://testserver")
    assert c.post("/api/accesso", json={"username": username, "password": provvisoria}).status_code == 200
    s = Sessione(c)
    assert s.post("/api/io/password", {"attuale": provvisoria, "nuova": password}).status_code == 200
    return s


def revisore(admin: Sessione, attivita: str = "DPR") -> Sessione:
    """C28: i cicli di collaudo usano un RT distinto dall'esecutore, senza alterare le richieste."""
    nome = "revisore_" + attivita.lower()
    cache = getattr(admin, "_revisori", {})
    if nome not in cache:
        cache[nome] = nuovo_utente(admin, admin.c.app, nome,
            "responsabile_tecnico_dm" if attivita == "DM" else "responsabile_tecnico")
        admin._revisori = cache
    return cache[nome]


def pdf_sintetico(docx=b""):
    """PDF minimo strutturalmente valido; hash distinto per documento, senza LibreOffice."""
    import hashlib
    import io
    from pypdf import PdfWriter
    w = PdfWriter()
    w.add_blank_page(width=595, height=842)
    w.add_metadata({"/TestDocxSHA256": hashlib.sha256(docx).hexdigest()})
    out = io.BytesIO()
    w.write(out)
    return out.getvalue()
