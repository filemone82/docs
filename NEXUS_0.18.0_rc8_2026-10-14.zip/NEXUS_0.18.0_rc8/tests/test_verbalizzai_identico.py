"""R111 (11/10/2026): VerbalizzAI 1.0.1 rc2 è in produzione e non si modifica.

La copia dentro il gestionale deve restare identica a quella prodotta da `strumenti/aggiorna_verbalizzai.py`
dallo zip in produzione (unica differenza ammessa: import resi relativi). Le impronte sono in
`gestionale/terzi/verbalizzai/IMPRONTE_ORIGINE.json`, scritte dallo strumento al momento della copia."""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path

CARTELLA = Path(__file__).resolve().parents[1] / "gestionale" / "terzi" / "verbalizzai"


def _strumento():
    p = Path(__file__).resolve().parents[1] / "strumenti" / "aggiorna_verbalizzai.py"
    spec = importlib.util.spec_from_file_location("aggiorna_vz_contratto", p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def test_copia_incorporata_identica_alla_versione_in_produzione():
    attese = json.loads((CARTELLA / "IMPRONTE_ORIGINE.json").read_text(encoding="utf-8"))
    assert attese["versione"] == "1.0.1"
    attuali = _strumento().impronte_cartella(CARTELLA)
    modificati = sorted(k for k in attese["file"] if attuali.get(k) != attese["file"][k])
    aggiunti = sorted(set(attuali) - set(attese["file"]))
    assert not modificati and not aggiunti, (
        "VerbalizzAI incorporato non è più identico alla versione in produzione (R111). "
        f"Modificati: {modificati}; aggiunti: {aggiunti}. Non si corregge VerbalizzAI dentro il gestionale: "
        "si adatta il gestionale, oppure si aggiorna VerbalizzAI con strumenti/aggiorna_verbalizzai.py.")


def test_versione_dichiarata_coerente():
    from gestionale.terzi import verbalizzai
    assert verbalizzai.VERSIONE == "1.0.1"
