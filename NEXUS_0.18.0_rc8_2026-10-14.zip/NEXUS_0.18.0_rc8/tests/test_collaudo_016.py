"""0.16 · Note del collaudo «da zero» di Federico (documento 36): date alla registrazione (R142), accessori a parte (R141),
tipo attrezzatura del verbale solo GVR (C11), collegamenti della sede per gruppo (C8)."""

import pytest
from test_anagrafica import crea_cliente, crea_sede
from test_beni import nuovo, ok
from test_finanza import economia  # noqa: F401
from test_verifiche import accettato  # noqa: F401


@pytest.fixture
def sede(admin):
    return crea_sede(admin, crea_cliente(admin)["id"])


def test_prossima_verifica_obbligatoria_alla_registrazione(admin, sede):
    # SC senza date: rifiutata con l'attività che manca
    r = admin.post("/api/beni", {"gruppo": "SC", "sede_id": sede["id"], "matr_informale": "SC-1"})
    assert r.status_code == 400
    catalogo = ok(admin.get("/api/beni/cataloghi"))
    tipo = next(x for x in catalogo["tipi_attrezzature"] if x["gruppo"] == "SC")
    spec = next(x["id_spec_id"] for x in catalogo["compatibilita"] if x["gruppo"] == "SC" and x["tipo_attr_id"] == tipo["id"])
    base = {"gruppo": "SC", "sede_id": sede["id"], "matr_informale": "SC-1", "tipo_attr_id": tipo["id"], "id_spec_id": spec,
            "anno_matricola": "2020", "cod_att_matricola": "A", "num_matricola": "00001", "prov_immatr": "TO",
            "dati_dm": {"esente_verifiche": "F", "tipo_prox_verifica": "V1"}}
    r = admin.post("/api/beni", base)
    assert r.status_code == 400 and "verifica SC/SP" in r.json()["errore"]
    r = admin.post("/api/beni", {**base, "date_iniziali": {"scsp": {"data_ultima": "2026-05-01", "data_prossima": "2025-05-01"}}})
    assert r.status_code == 400 and "non può precedere" in r.json()["errore"]
    a = ok(admin.post("/api/beni", {**base, "date_iniziali": {"scsp": {"data_prossima": "2027-01-31", "numero_report": "verbale 12/25 altro organismo"}}}))
    sc = a["scadenze"][0]
    assert sc["componente"] == "scsp" and sc["data_prossima"] == "2027-01-31" and sc["fonte"] == "dichiarata"
    # entra subito nello scadenziario
    righe = ok(admin.post("/api/griglie/scadenze_dm/dati", {"pagina": 1, "dimensione": 50}))["righe"]
    assert any(x["asset_id"] == a["id"] for x in righe)


def test_gvr_funzionamento_integrita_e_interna_se_prevista(admin, sede):
    r = admin.post("/api/beni", {**_gvr(admin, sede, famiglia=2), "date_iniziali": {"funzionamento": {"data_prossima": "2027-01-31"},
                                                                                    "integrita": {"data_prossima": "2030-01-31"}}})
    assert r.status_code == 400 and "visita interna" in r.json()["errore"]
    a = nuovo(admin, sede, "GVR", "GVR-A1")  # recipiente (a1): niente visita interna
    assert sorted(x["componente"] for x in a["scadenze"]) == ["funzionamento", "integrita"]
    r = admin.post("/api/beni", {**_gvr(admin, sede, famiglia=1, matricola="GVR-A1-bis"),
                                 "date_iniziali": {c: {"data_prossima": "2027-01-31"} for c in ("funzionamento", "integrita", "interna")}})
    assert r.status_code == 400 and "non previste" in r.json()["errore"]


def test_senza_prossima_segnalate(admin, sede, app):
    a = nuovo(admin, sede, "GVR", "GVR-X")
    assert ok(admin.get("/api/beni/senza-prossima")) == []
    a = ok(admin.c.request("DELETE", f"/api/beni/{a['id']}/scadenze/integrita", json={"versione": a["versione"]}, headers=admin.h))
    x = ok(admin.get("/api/beni/senza-prossima"))
    assert [(y["id"], y["mancano"]) for y in x] == [(a["id"], ["integrità"])]


def test_accessorio_senza_matricola_inail_e_protegge(admin, sede):
    g = nuovo(admin, sede, "GVR", "GVR-P")
    r = admin.post("/api/beni", {"gruppo": "PSV", "sede_id": sede["id"], "matr_informale": "V-1", "anno_matricola": "2020"})
    assert r.status_code == 400 and "matricola INAIL" in r.json()["errore"]
    p = ok(admin.post("/api/beni", {"gruppo": "PSV", "sede_id": sede["id"], "matr_informale": "V-1", "costruttore": "Prova",
                                    "dati_dm": {"tip_accessorio": "valvola di sicurezza", "ptar": "10"}, "protegge": [g["id"]],
                                    "date_iniziali": {"taratura": {"data_ultima": None, "data_prossima": None}}}))
    assert [x["id"] for x in p["protegge"]] == [g["id"]] and p["scadenze"] == []
    assert [x["id"] for x in ok(admin.get(f"/api/beni/{g['id']}"))["accessori"]] == [p["id"]]
    altra = crea_sede(admin, sede["cliente_id"], denominazione="Altra sede")
    r = admin.post("/api/beni", {"gruppo": "PSV", "sede_id": altra["id"], "matr_informale": "V-2", "protegge": [g["id"]]})
    assert r.status_code == 400 and "della sua sede" in r.json()["errore"]


def test_tipo_attrezzatura_verbale_solo_gvr(admin, sede):
    c = ok(admin.get("/api/beni/cataloghi"))
    assert any(d["nome"] == "tipo_attr_verbale" for d in c["schede_dm"]["GVR"])
    assert not any(d["nome"] == "tipo_attr_verbale" for d in c["schede_dm"]["SC"])
    a = nuovo(admin, sede, "SC", "SC-T")
    r = admin.put(f"/api/beni/{a['id']}", {"versione": a["versione"], "dati_dm": {"tipo_attr_verbale": "RG"}})
    assert r.status_code == 400


def test_collegamenti_sede_per_gruppo(admin, sede):
    nuovo(admin, sede, "GVR", "G-1")
    nuovo(admin, sede, "SC", "S-1")
    nuovo(admin, sede, "SP", "S-2")
    righe = ok(admin.post("/api/griglie/sedi/dati", {"pagina": 1, "dimensione": 50}))["righe"]
    r = next(x for x in righe if x["id"] == sede["id"])
    assert (r["n_gvr"], r["n_scsp"], r["n_psv"]) == (1, 2, 0)


def _gvr(admin, sede, famiglia, matricola="GVR-GV"):
    c = ok(admin.get("/api/beni/cataloghi"))
    tipo = next(x for x in c["tipi_attrezzature"] if x["gruppo"] == "GVR" and x["famiglia_gvr_id"] == famiglia)
    spec = next(x["id_spec_id"] for x in c["compatibilita"] if x["gruppo"] == "GVR" and x["famiglia_gvr_id"] == famiglia)
    return {"gruppo": "GVR", "sede_id": sede["id"], "matr_informale": matricola, "tipo_attr_id": tipo["id"], "id_spec_id": spec,
            "anno_matricola": "2020", "cod_att_matricola": "A", "num_matricola": "00002", "prov_immatr": "TO",
            "dati_dm": {"esente_verifiche": "F", "tipo_prox_verifica": "V2"}}


def test_pvp_alla_prima_scadenza_che_entra_nel_preventivo(admin):
    from test_dm_preventivi import gvr
    from test_scadenze_preventivo_dm import _scadenze, sede_dm  # noqa: F401
    from test_anagrafica import PIVA_2
    c = crea_cliente(admin, ragione_sociale="PVP Prova S.r.l.", partita_iva=PIVA_2, codice_fiscale=PIVA_2, ambiti=["DM"])
    sd = crea_sede(admin, c["id"], denominazione="Centrale")
    gvr(admin, sd, matricola="GVR-C13", dati_dm={"tipo_prox_verifica": "V1"}, soggetto_messa_servizio=True,
            date_iniziali={"funzionamento": {"data_prossima": "2026-12-01"}, "integrita": {"data_prossima": "2026-12-01"}})
    da = {r["componente"]: r for r in _scadenze(admin, matr_informale="GVR-C13")}
    # stessa data: la PVP è sulla prima dell'elenco (funzionamento), l'altra è successiva
    assert (da["Funzionamento"]["tipo_prox_verifica"], da["Integrità"]["tipo_prox_verifica"]) == ("Prima periodica", "Successiva")
    # se nel preventivo entra solo l'integrità, la PVP è l'integrità (Federico, 17:52: «la prima che viene filtrata»)
    out = ok(admin.post("/api/dm/preventivi/da-scadenze", {"scadenze": [da["Integrità"]["id"]]}))
    p = ok(admin.get(f"/api/preventivi/{out['preventivi'][0]['id']}"))
    assert [r["tipo_verifica_dm"] for r in p["righe"]] == ["V1"]
    # aggiunto poi il funzionamento allo stesso preventivo: successiva, la PVP c'è già
    out = ok(admin.post("/api/dm/preventivi/da-scadenze", {"scadenze": [da["Funzionamento"]["id"]], "preventivo": p["codice"]}))
    p = ok(admin.get(f"/api/preventivi/{p['id']}"))
    assert sorted((r["tipo_verifica_gvr"], r["tipo_verifica_dm"]) for r in p["righe"]) == [("funz", "V2"), ("integrita", "V1")]


def test_posta_per_attivita_e_file_precedente(admin, app):
    """C15: una configurazione per AD_DPR, AD_DM, I&C; il posta.json delle versioni precedenti vale per tutte."""
    import json
    cartella = app.state.archivio.cfg.cartella_dati
    (cartella / "posta.json").write_text(json.dumps({"server": "smtp.vecchio.it", "porta": 465, "sicurezza": "ssl", "utente": "u@ad.it",
                                                     "password": "x", "mittente": "u@ad.it", "nome_mittente": "AD", "copia_ufficio": "u@ad.it"}), "utf-8")
    for a in ("DPR", "DM", "IEC"):
        assert ok(admin.get(f"/api/impostazioni/posta?attivita={a}"))["posta"]["server"] == "smtp.vecchio.it"
    base = {"server": "smtp.dm.it", "porta": 587, "sicurezza": "starttls", "utente": "dm@ad.it", "mittente": "dm@ad.it",
            "nome_mittente": "AD DM", "copia_ufficio": "dm@ad.it", "password": "segreta"}
    p = ok(admin.put("/api/impostazioni/posta?attivita=DM", base))
    assert p["server"] == "smtp.dm.it" and p["nome_attivita"] == "AD_DM" and "password" not in p and p["password_impostata"]
    assert ok(admin.get("/api/impostazioni/posta?attivita=DPR"))["posta"]["server"] == "smtp.vecchio.it"
    assert ok(admin.get("/api/impostazioni/posta?attivita=IEC"))["posta"]["server"] == "smtp.vecchio.it"
    from gestionale.core.posta import ImpostazioniPosta
    assert ImpostazioniPosta(cartella, "DM").leggi()["password"] == "segreta"
    assert ImpostazioniPosta(cartella, "DPR").leggi()["password"] == "x"


def test_commerciali_per_attivita(admin):
    a = ok(admin.post("/api/commerciali", {"nome": "Commerciale DPR"}))
    assert a["ambiti"] == ["DPR"]
    b = ok(admin.post("/api/commerciali", {"nome": "Commerciale DM", "ambiti": ["DM"]}))
    assert admin.post("/api/commerciali", {"nome": "Senza", "ambiti": []}).status_code == 400
    def nomi(ambito):
        return sorted(x["nome"] for x in ok(admin.post("/api/griglie/commerciali/dati", {"ambito": ambito}))["righe"])
    assert nomi("DM") == ["Commerciale DM"] and nomi("DPR") == ["Commerciale DPR"]
    b = ok(admin.put(f"/api/commerciali/{b['id']}", {**b, "ambiti": ["DPR", "DM"]}))
    assert nomi("DPR") == ["Commerciale DM", "Commerciale DPR"]


def test_strumenti_dm_e_configurazione_per_attivita(admin):
    r = admin.post("/api/strumenti/DPR", {"denominazione": "x"})
    assert r.status_code == 400
    s = ok(admin.post("/api/strumenti/DM", {"denominazione": "Spessimetro a ultrasuoni", "matricola": "SP-1",
                                            "data_taratura": "2026-01-10", "scadenza_taratura": "2027-01-10"}))
    assert admin.post("/api/strumenti/DM", {"denominazione": "Altro", "matricola": "sp-1"}).status_code == 400
    assert admin.post("/api/strumenti/DM", {"denominazione": "Altro", "data_taratura": "2026-02-01", "scadenza_taratura": "2026-01-01"}).status_code == 400
    s = ok(admin.put(f"/api/strumenti/DM/{s['id']}", {**s, "certificato": "LAT 123"}))
    assert s["certificato"] == "LAT 123" and s["versione"] == 2
    righe = ok(admin.post("/api/griglie/strumenti_misura/dati", {"ambito": "DM"}))["righe"]
    assert [x["denominazione"] for x in righe] == ["Spessimetro a ultrasuoni"]
    assert ok(admin.post("/api/griglie/strumenti_misura/dati", {"ambito": "IEC"}))["righe"] == []
    assert admin.get(f"/api/strumenti/IEC/{s['id']}").status_code == 404
    # Configurazione: ogni attività vede la sua
    ok(admin.post('/api/ambito-attivo', {'ambito': 'DM'}))
    dm = admin.get("/configurazione").text
    # rc8 (punto 3): firme DPR e DM in una sola pagina, «/firme», raggiungibile da entrambe le attività
    assert 'href="/firme"' in dm and "/strumenti-misura" in dm and "/cataloghi" in dm and "vista=templates" not in dm and "/verbali-importa" not in dm
    ok(admin.post('/api/ambito-attivo', {'ambito': 'DPR'}))
    dpr = admin.get("/configurazione").text
    assert "vista=templates" in dpr and "vista=instruments" in dpr and "/verbali-importa" in dpr and 'href="/firme"' in dpr and "vista=signatures" not in dpr and "/cataloghi" not in dpr
    for comune in ("/tipi-pagamento", "/aliquote-iva", "/termini-esecuzione", "/importa", "/backup"):
        assert comune in dm and comune in dpr


def test_accettazione_file_e_documenti_per_la_fattura(admin, economia, accettato):  # noqa: F811
    """R138 (0.16): file dell'accettazione o dell'ordine, dati per la fattura elettronica come Garda, passaggio in fattura."""
    from test_fattura_da_righe import _eseguita_e_riesaminata, _righe
    pid = accettato["preventivo"]["id"]
    p = ok(admin.get(f"/api/preventivi/{pid}"))
    assert any("Manca il file" in a for a in p["avvisi_accettazione"])
    r = admin.c.post(f"/api/preventivi/{pid}/allegati", files={"file": ("ordine.exe", b"MZ")}, data={"tipo": "ordine"}, headers=admin.h)
    assert r.status_code == 400 and "Formato non ammesso" in r.json()["errore"]
    r = admin.c.post(f"/api/preventivi/{pid}/allegati", files={"file": ("ordine.pdf", b"non pdf")}, data={"tipo": "ordine"}, headers=admin.h)
    assert r.status_code == 400
    p = ok(admin.c.post(f"/api/preventivi/{pid}/allegati", files={"file": ("ordine 4500.pdf", b"%PDF-1.4 ordine di prova")},
                        data={"tipo": "ordine", "descrizione": "ordine n. 4500"}, headers=admin.h))
    a = p["allegati"][0]
    assert a["tipo"] == "ordine" and not any("Manca il file" in x for x in p["avvisi_accettazione"])
    assert admin.get(f"/api/preventivi/{pid}/allegati/{a['id']}/file").content == b"%PDF-1.4 ordine di prova"
    # dati per la fattura: numero e data obbligatori; tipi di Garda compresi DDT e fattura principale
    r = admin.put(f"/api/preventivi/{pid}/documenti-collegati", {"versione": p["versione"], "documenti": [{"tipo": "OrdineAcquisto", "numero": "4500"}]})
    assert r.status_code == 400 and "data sono obbligatori" in r.json()["errore"]
    p = ok(admin.put(f"/api/preventivi/{pid}/documenti-collegati", {"versione": p["versione"], "documenti": [
        {"tipo": "OrdineAcquisto", "numero": "4500", "data": "2026-09-02", "cig": "z1a2b3c4d5"},
        {"tipo": "DDT", "numero": "DDT-7", "data": "2026-09-03"}]}))
    assert [d["tipo"] for d in p["documenti_collegati"]] == ["OrdineAcquisto", "DDT"] and p["documenti_collegati"][0]["cig"] == "Z1A2B3C4D5"
    assert p["rif_ordine"] == "n. 4500" and p["data_ordine"] == "2026-09-02"
    # passaggio in fattura
    _eseguita_e_riesaminata(admin, accettato)
    ids = sorted(r["id"] for r in _righe(admin, "righe_preventivi", preventivo_id=pid, da_fatturare="Sì"))
    f = ok(admin.post("/api/fatture/da-righe", {"righe": ids, "data": "2026-10-11"}))
    f = ok(admin.get(f"/api/fatture/{f['id']}"))
    docs = f["opzioni"]["documenti"]
    assert [(d["tipo"], d["numero"]) for d in docs] == [("OrdineAcquisto", "4500"), ("DDT", "DDT-7")]
    assert all(r['riferimenti']['documenti_collegati'] == p['documenti_collegati'] for r in f['righe'])
    # tolto il file: resta nello storico ma non vale più come evidenza
    p = ok(admin.post(f"/api/preventivi/{pid}/allegati/{a['id']}/togli", {}))
    assert p["allegati"][0]["rimosso"] and any("Manca il file" in x for x in p["avvisi_accettazione"])


def test_fattura_dalle_verifiche(admin, economia, accettato):  # noqa: F811
    """R139 (0.16): «Fattura le selezionate…» anche dalle verifiche; trasferta e a corpo si aggiungono da sole."""
    from test_fattura_da_righe import _eseguita_e_riesaminata
    v = _eseguita_e_riesaminata(admin, accettato)
    assert ok(admin.get(f"/api/verifiche/{v['id']}"))["fattura"] is None
    altra = next(x for x in accettato["preventivo"]["verifiche"] if x["id"] != v["id"])
    r = admin.post("/api/fatture/righe-da-lavori", {"verifiche": [v["id"], altra["id"]]})
    assert r.status_code == 400 and "non sono da fatturare" in r.json()["errore"]
    x = ok(admin.post("/api/fatture/righe-da-lavori", {"verifiche": [v["id"]]}))
    p = ok(admin.get(f"/api/preventivi/{accettato['preventivo']['id']}"))
    voci = {r["id"] for r in p["righe"] if r["impianto_id"] is None}
    assert x["righe"][0] == v["riga_id"] and set(x["righe"][1:]) == voci and x["voci"] == len(voci) and x["clienti"] == [p["cliente_id"]]
    f = ok(admin.post("/api/fatture/da-righe", {"righe": x["righe"], "data": "2026-10-11"}))
    assert ok(admin.get(f"/api/verifiche/{v['id']}"))["fattura"]["id"] == f["id"]
    r = admin.post("/api/fatture/righe-da-lavori", {"verifiche": [v["id"]]})
    assert r.status_code == 400   # già fatturata


def test_emissione_da_archivio_nuovo_dice_cosa_manca(admin):
    """C6 (0.16): su un archivio nuovo (Dati fiscali AD vuoti) l'emissione non dà «errore imprevisto» ma l'elenco."""
    from test_anagrafica import crea_cliente as cc
    c = cc(admin, ragione_sociale="Cliente nuovo", indirizzo="Via 1", comune="Torino", cap="10100", provincia="TO")
    so = next(x for x in ok(admin.get("/api/finanza/valori"))["societa"] if x["codice"] == "AD")
    f = ok(admin.post("/api/fatture", {"societa_id": so["id"], "cliente_id": c["id"], "data": "2026-10-12", "tipo": "TD01"}))
    assert any("almeno una riga" in m for m in ok(admin.get(f"/api/fatture/{f['id']}"))["mancanti"])
    f = ok(admin.post(f"/api/fatture/{f['id']}/righe", {"versione": f["versione"], "descrizione": "x", "prezzo": "600.00", "quantita": "1",
                                                       "aliquota": "22", "natura": "", "esigibilita": "I"}))
    # rc8 (punto 6): l'avviso nomina la società emittente e porta ai suoi dati in Configurazione, con ritorno alla bozza
    assert f["mancanti"] and "Società emittente AD" in f["mancanti"][0] and "partita IVA" in f["mancanti"][0]
    assert f["mancanti_dettaglio"][0]["chi"] == "emittente" and f["mancanti_dettaglio"][0]["url"] == f"/dati-societari?ritorno=/fatture?apri={f['id']}"
    r = admin.post(f"/api/fatture/{f['id']}/emetti", {"versione": f["versione"]})
    assert r.status_code == 400 and r.json()["errore"].startswith("Prima di emettere manca: Società emittente AD")


@pytest.mark.pdf_vero
def test_copia_di_cortesia_come_garda(admin, economia):  # noqa: F811
    """R140 (0.16): numero nel formato di Garda, PDF con intestazione, cliente, righe, riferimenti comuni in fondo."""
    import shutil
    import subprocess
    import tempfile
    from pathlib import Path

    from gestionale.moduli.finanza import stampa
    from test_finanza import emetti, nuovo as nuova, riga
    bozza = riga(admin, nuova(admin, economia))
    r = admin.get(f"/api/fatture/{bozza['id']}/pdf")
    assert r.status_code == 200 and "Bozza_fattura_del_08-10-2026" in r.headers["content-disposition"]
    f = emetti(admin, bozza)
    assert f["codice"] == "1/2026/DPR"
    r = admin.get(f"/api/fatture/{f['id']}/pdf")
    assert "Fattura_1-2026-DPR_del_08-10-2026_Cliente_collaudo.pdf" in r.headers["content-disposition"]
    if shutil.which("pdftotext") and r.content.startswith(b"%PDF") and len(r.content) > 5000:  # PDF vero (LibreOffice)
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "f.pdf"
            p.write_bytes(r.content)
            txt = subprocess.check_output(["pdftotext", "-layout", str(p), "-"]).decode()
        for atteso in ("AD collaudo S.r.l.", "TD01: fattura", "Fattura Nr. 1/2026/DPR del 08/10/2026", "Cliente", "Riepilogo IVA",
                       "Tot. documento", "Tot. dovuto", "€ 122,00", "Copia della fattura elettronica"):
            assert atteso in txt, atteso
    # riferimenti comuni a tutte le righe: una volta sola in fondo
    foto = {"righe": [{"descrizione": "Verifiche attrezzature di lavoro gruppo SC, matr. A, preventivo P_1_26, rif. ordine cliente 77",
                       "quantita": "1", "prezzo": "10", "importo": 1000, "aliquota": 2200, "natura": "", "riferimenti": {"preventivo": "P_1_26"}},
                      {"descrizione": "Verifiche attrezzature di lavoro gruppo SC, matr. B, preventivo P_1_26, rif. ordine cliente 77",
                       "quantita": "1", "prezzo": "10", "importo": 1000, "aliquota": 2200, "natura": "", "riferimenti": {"preventivo": "P_1_26"}}],
            "opzioni": {"documenti": [{"tipo": "OrdineAcquisto", "numero": "77", "data": "2026-09-02"}]}}
    righe, note = stampa.righe_stampa(foto)
    assert [r["descrizione"] for r in righe] == ["Verifiche attrezzature di lavoro gruppo SC, matr. A", "Verifiche attrezzature di lavoro gruppo SC, matr. B"]
    assert note == ["Rif. preventivo P_1_26", "(Rif. Ordine d'acquisto n. 77 del 02/09/2026)"]


def test_revisione_e_annullamento_verbale_dm(admin, app, monkeypatch):
    """R134: revisione del verbale DM emesso (stesso numero, rev. 1, motivo); R135: annulla anche il verificatore."""
    from gestionale.core import pdf
    from test_dm_documenti import pdf_di_prova
    monkeypatch.setattr(pdf, "da_word", lambda *a: pdf_di_prova())
    from conftest import nuovo_utente
    from test_dm_documenti import doc, effettua, generata, registrata
    from test_dm_tecnico import assegna, incarico, salva
    sd = crea_sede(admin, crea_cliente(admin)["id"])
    v, _, _ = registrata(admin, sd)
    v = ok(effettua(admin, generata(admin, v)))
    numero = v["codice_verbale"]
    data_originaria = v['bozza']['data_rilascio']
    assert v["stato"] == "effettuata" and numero
    r = admin.post(f"/api/dm/incarichi/{v['id']}/revisione", {"versione": v["versione"], "motivo": ""})
    assert r.status_code == 400
    v = ok(admin.post(f"/api/dm/incarichi/{v['id']}/revisione", {"versione": v["versione"], "motivo": "Matricola del generatore errata"}))
    assert v["stato"] == "registrata" and v["revisione"] == 1 and v["codice_verbale"] == numero
    assert v["revisioni"][0]["motivo"] == "Matricola del generatore errata"
    v = ok(salva(admin, v, data_rilascio='2027-01-02'))
    assert v['codice_verbale'] == numero  # R134: identità originaria anche a cavallo d'anno
    v = generata(admin, v)
    from io import BytesIO
    from zipfile import ZipFile
    from lxml import etree
    from datetime import date
    raw = admin.get(doc(v, formato='docx')['url']).content
    with ZipFile(BytesIO(raw)) as z:
        text = ''.join(etree.fromstring(z.read('word/document.xml')).itertext())
    assert 'rev. 1' in text and 'Sostituisce il verbale n. '+numero in text
    assert 'emesso il '+date.fromisoformat(data_originaria).strftime('%d/%m/%Y') in text
    assert " rev. 1" in doc(v)["nome"] and doc(v)["nome"].endswith(" - BOZZA.pdf")
    v = ok(effettua(admin, v))
    assert v["stato"] == "effettuata" and v["codice_verbale"] == numero and " rev. 1" in doc(v)["nome"]
    # annullamento: il verificatore a cui è affidato può, un altro verificatore no; il numero resta
    t = nuovo_utente(admin, app, "ver_dm_annulla", "tecnico_dm")
    altro = nuovo_utente(admin, app, "ver_dm_altro", "tecnico_dm")
    w, _, _ = incarico(admin, crea_sede(admin, sd["cliente_id"], denominazione="Seconda sede"))
    w = assegna(admin, w, ok(t.get("/api/io"))["id"])
    assert altro.post(f"/api/dm/incarichi/{w['id']}/annulla", {"versione": w["versione"], "motivo": "x"}).status_code == 403
    w = ok(t.post(f"/api/dm/incarichi/{w['id']}/annulla", {"versione": w["versione"], "motivo": "Attrezzatura non disponibile"}))
    assert w["stato"] == "annullata"


@pytest.mark.pdf_vero
@pytest.mark.parametrize("gruppo", ["GVR", "SC"])
def test_modelli_dm_rev03_grafica_verbalizzai(admin, gruppo):
    """R136 (0.16): la rev. 03 di M14/M11 entra «da approvare»; messa in uso, il verbale ha lo stesso contenuto e il
    riquadro firme resta intero; il piè di pagina dice rev. 03."""
    import os
    import zipfile
    from io import BytesIO

    from gestionale.core import pdf
    from gestionale.moduli.dm import impaginazione as imp
    from test_dm_documenti import doc, effettua, generata, registrata
    if not pdf.disponibile():
        pytest.skip("LibreOffice non installato")
    tipo = "verbale_dm_gvr" if gruppo == "GVR" else "verbale_dm_scsp"
    codice = "M14-PO01_dm" if gruppo == "GVR" else "M11-PO01_dm"
    modelli = [m for m in ok(admin.get("/api/modelli")) if m["tipo"] == tipo]
    rev03 = next(m for m in modelli if m["codice"] == codice and m["revisione"] == "03")
    assert not rev03["in_uso"] and rev03["stato"] == "da approvare"
    prima = next(m for m in modelli if m["in_uso"])
    ok(admin.post(f"/api/modelli/{rev03['id']}/in-uso"))
    stati = {m["id"]: m["stato"] for m in ok(admin.get("/api/modelli"))}
    assert stati[rev03["id"]] == "in uso" and stati[prima["id"]] == "superato"
    sd = crea_sede(admin, crea_cliente(admin)["id"])
    a = nuovo(admin, sd, gruppo, "PROVA-R136-" + gruppo) if gruppo != "GVR" else None
    v, _, _ = registrata(admin, sd, a=a)
    v = generata(admin, v)
    word = admin.get(doc(v, formato="docx")["url"]).content
    assert "rev. 03 del 12.10.2026" in zipfile.ZipFile(BytesIO(word)).read("word/footer1.xml").decode()
    assert "Calibri" in zipfile.ZipFile(BytesIO(word)).read("word/document.xml").decode()
    anteprima = admin.get(doc(v)["url"]).content
    v = ok(effettua(admin, v))
    firmato = admin.get(doc(v)["url"]).content
    assert imp.pagine(firmato) == imp.pagine(anteprima)
    cartella = os.environ.get("NEXUS_PDF_PROVA")
    if cartella:  # PDF di prova da approvare (dati inventati)
        open(os.path.join(cartella, f"Prova {codice} rev03 - anteprima BOZZA.pdf"), "wb").write(anteprima)
        open(os.path.join(cartella, f"Prova {codice} rev03 - firmato.pdf"), "wb").write(firmato)


def test_registrazione_multipla_dm(admin):
    """Documento 28, punto 13: «Registra le selezionate…» (solo AD_DM), numero alla registrazione, tutto o niente."""
    from test_dm_tecnico import assegna, incarico
    sd = crea_sede(admin, crea_cliente(admin)["id"])
    sd2 = crea_sede(admin, sd["cliente_id"], denominazione="Seconda")
    a, _, _ = incarico(admin, sd)
    b, _, _ = incarico(admin, sd2)
    a, b = assegna(admin, a), assegna(admin, b)
    a = ok(admin.get(f"/api/dm/incarichi/{a['id']}"))
    b = ok(admin.get(f"/api/dm/incarichi/{b['id']}"))
    r = admin.post("/api/dm/incarichi/registra-in-blocco", {"data_rilascio": "", "incarichi": [{"id": a["id"], "versione": a["versione"]}]})
    assert r.status_code == 400
    # una data esplicita per il funzionamento, l'integrità (non preventivata qui) non serve
    out = ok(admin.post("/api/dm/incarichi/registra-in-blocco", {"data_rilascio": "2026-10-09", "date": {"funz": "2028-10-08"},
                                                               "incarichi": [{"id": b["id"], "versione": b["versione"]}, {"id": a["id"], "versione": a["versione"]}]}))
    codici = [x["codice_verbale"] for x in out["registrati"]]
    assert [x["id"] for x in out["registrati"]] == sorted([a["id"], b["id"]]) and len(set(codici)) == 2
    a = ok(admin.get(f"/api/dm/incarichi/{a['id']}"))
    assert a["stato"] == "registrata" and a["bozza"]["date"]["funz"] == "2028-10-08" and a["bozza"]["data_rilascio"] == "2026-10-09"
    # già registrati: tutto o niente, e il messaggio dice quale
    r = admin.post("/api/dm/incarichi/registra-in-blocco", {"data_rilascio": "2026-10-09", "incarichi": [{"id": a["id"], "versione": a["versione"]}]})
    assert r.status_code == 400 and "Nessun incarico è stato registrato" in r.json()["errore"]


def test_registrazione_multipla_data_dalla_periodicita(admin):
    from test_dm_tecnico import assegna, incarico
    sd = crea_sede(admin, crea_cliente(admin)["id"])
    v, _, _ = incarico(admin, sd)
    v = ok(admin.get(f"/api/dm/incarichi/{assegna(admin, v)['id']}"))
    ok(admin.post("/api/dm/incarichi/registra-in-blocco", {"data_rilascio": "2026-10-09", "incarichi": [{"id": v["id"], "versione": v["versione"]}]}))
    v = ok(admin.get(f"/api/dm/incarichi/{v['id']}"))
    assert v["bozza"]["date"]["funz"] == "2028-10-08"  # «Verifica funzionamento: biennale» → +2 anni − 1 giorno
