"""Ciclo documentale 1.0.1 nel backend integrato, con conversione LibreOffice reale."""

from __future__ import annotations

from conftest import revisore

import base64
import io
from zipfile import ZipFile, ZIP_DEFLATED
import xml.etree.ElementTree as ET

from test_verifiche import accettato  # noqa: F401
from test_verbali import _bozza_pronta, _vz


def _ritocco(raw):
    from gestionale.terzi.verbalizzai.wordio import NS, q

    with ZipFile(io.BytesIO(raw)) as z:
        parti = {n: z.read(n) for n in z.namelist()}
    root = ET.fromstring(parti['word/document.xml'])
    margini = root.find('.//w:sectPr/w:pgMar', NS)
    assert margini is not None
    margini.set(q('w:left'), '1250')
    parti['word/document.xml'] = ET.tostring(root, encoding='utf-8', xml_declaration=True)
    out = io.BytesIO()
    with ZipFile(out, 'w', ZIP_DEFLATED) as z:
        for n, b in parti.items():
            z.writestr(n, b)
    return out.getvalue()


def test_ritocco_word_emissione_e_pdf_definitivo_conservato(admin, app, accettato, monkeypatch):  # noqa: F811
    from gestionale.terzi.verbalizzai.finalization import content_signature
    from gestionale.terzi.verbalizzai import pdfconv

    v, iid, anteprima = _bozza_pronta(admin, admin, accettato)
    arc = app.state.verbali
    raw = arc.document(anteprima['export']['data']['sha'])[1]
    ritoccato = _ritocco(raw)
    assert content_signature(raw) == content_signature(ritoccato)
    caricato = _vz(admin, 'review/upload', {
        'id': iid, 'revision': anteprima['item']['revision'], 'preview_id': anteprima['export']['id'],
        'filename': 'ritoccato.docx', 'content': base64.b64encode(ritoccato).decode(),
    })
    assert caricato.status_code == 200, caricato.text
    anteprima = caricato.json()
    r = _vz(admin, 'review/issue', {
        'id': iid, 'revision': anteprima['item']['revision'], 'preview_id': anteprima['export']['id'],
        'approved': True, 'update_plant': True,
    })
    assert r.status_code == 200, r.text
    finale = r.json()['export']
    assert finale['data']['source_mode'] == 'layout_upload'
    word_finale = arc.document(finale['data']['sha'])[1]
    with ZipFile(io.BytesIO(word_finale)) as z:
        assert b'1250' in z.read('word/document.xml')
    pdf_finale = arc.document(finale['data']['pdf_sha'])[1]
    assert pdfconv.outline(pdf_finale)[1] > 0
    incarico = admin.get(f"/api/verifiche/{v['id']}").json()
    assert incarico['stato'] == 'eseguita'
    # Il documento consultabile è l'esatto PDF emesso, anche dopo riapertura.
    ricevuto = _vz(admin, f"document?sha={finale['data']['pdf_sha']}")
    assert ricevuto.status_code == 200 and ricevuto.content == pdf_finale
    item = _vz(admin, f'inspection?id={iid}').json()['item']
    r = _vz(admin, 'draft/save', {'id': iid, 'revision': item['revision'], 'data': item['data']})
    assert r.status_code in (400, 409), r.text
    assert arc.document(finale['data']['pdf_sha'])[1] == pdf_finale
    # L'invio, simulato senza connessione SMTP, allega proprio questo PDF e
    # registra la sua impronta. Il riesame DPR resta richiesto dal gestionale.
    r = revisore(admin).post(f"/api/verifiche/{v['id']}/riesame", {
        'esito': 'conforme', 'note': '', 'versione': incarico['versione'],
    })
    assert r.status_code == 200, r.text
    assert _vz(admin, 'review/final', {
        'id': iid, 'pdf_sha': finale['data']['pdf_sha'], 'confirmed': True,
    }).status_code == 200
    app.state.posta_verbali.gestionale.salva({
        'server': 'localhost', 'porta': 2525, 'sicurezza': 'nessuna', 'utente': '',
        'mittente': 'prova@example.org', 'copia_ufficio': 'ufficio@example.org',
    })
    from gestionale.terzi.verbalizzai import mailer
    messaggi = []
    monkeypatch.setattr(mailer, 'send', lambda cfg, msg: messaggi.append(msg) or 'prova simulata')
    r = _vz(admin, 'inspection/send', {
        'id': iid, 'to': 'cliente@example.org', 'subject': 'Verbale di prova', 'body': 'Prova locale',
        'pdf_sha': finale['data']['pdf_sha'], 'save_addresses': False,
    })
    assert r.status_code == 200, r.text
    assert len(messaggi) == 1
    assert next(messaggi[0].iter_attachments()).get_payload(decode=True) == pdf_finale
    assert r.json()['mailing']['data']['attachments'][0]['sha'] == finale['data']['pdf_sha']


def test_pdf_non_verificabile_non_emette_ne_chiude_incarico(admin, app, accettato, monkeypatch):  # noqa: F811
    from gestionale.terzi.verbalizzai import pdfconv

    v, iid, anteprima = _bozza_pronta(admin, admin, accettato)
    monkeypatch.setattr(pdfconv, 'outline', lambda raw: ({}, 0))
    r = _vz(admin, 'review/issue', {
        'id': iid, 'revision': anteprima['item']['revision'], 'preview_id': anteprima['export']['id'],
        'approved': True, 'update_plant': True,
    })
    assert r.status_code == 400 and 'numero di pagine' in r.json()['error'], r.text
    assert app.state.verbali.get(iid)['data']['status'] == 'draft'
    assert admin.get(f"/api/verifiche/{v['id']}").json()['stato'] == 'registrata'
