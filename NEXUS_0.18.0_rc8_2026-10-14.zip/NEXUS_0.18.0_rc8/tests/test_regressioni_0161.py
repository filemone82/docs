"""Regressioni comportamentali della 0.16.1, incluse anche nella suite pytest.

Le prove PDF reali si eseguono con strumenti/verifica_correzioni_0161.py --pdf.
Le prove HTTP/ORM aggiuntive sono in test_collaudo_016.py e test_ruoli_attivita.py.
"""
from strumenti import verifica_correzioni_0161 as prove


class TestRevisioni(prove.Revisioni):
    pass


class TestDocumentiFattura(prove.DocumentiFattura):
    pass


class TestStampaFattura(prove.StampaFattura):
    pass


class TestPermessi(prove.Permessi):
    pass
