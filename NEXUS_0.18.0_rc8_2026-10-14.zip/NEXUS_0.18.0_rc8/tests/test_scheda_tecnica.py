"""0.12.7 · R122: una sola scheda tecnica dell'impianto, quella di VerbalizzAI. Il gestionale ne tiene solo una copia
di lettura, riallineata da sola; il verbale precompilato riparte dall'ultimo aggiornamento."""

from __future__ import annotations

from test_verbali import _firma, _registrata, _vz
from test_verifiche import accettato, verbale_m02  # noqa: F401


def _emetti(admin, accettato, descrizione, aggiorna, precedente=False):  # noqa: F811
    v = _registrata(admin, accettato)
    if precedente:  # scheda già esistente: dal Word dell'ultimo verbale caricato dalla verifica
        r = admin.c.post(f"/api/verifiche/{v['id']}/verbale/precedente",
                         files={"file": ("VP_050_24.docx", verbale_m02("VP/050/24", "10/10/2024"), "application/octet-stream")}, headers=admin.h)
        assert r.status_code == 200, r.text
    vid = admin.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).json()["verbale_id"]
    item = _vz(admin, f"inspection?id={vid}").json()["item"]
    d = item["data"]
    d["flags"]["outcome"] = {"positive": True, "negative": False}
    d["plant"]["description"] = descrizione
    rev = _vz(admin, "draft/save", {"id": vid, "data": d, "revision": item["revision"]}).json()["item"]["revision"]
    _firma(admin)
    ant = _vz(admin, "review/preview", {"id": vid, "revision": rev}).json()
    r = _vz(admin, "review/issue", {"id": vid, "revision": ant["item"]["revision"], "preview_id": ant["export"]["id"],
                                    "approved": True, "update_plant": aggiorna})
    assert r.status_code == 200, r.text
    return v, d["plant_id"]


def _voci(sc):
    return {x["etichetta"]: x["valore"] for x in sc["voci"]}


def test_emissione_aggiorna_la_scheda_unica(admin, app, accettato):  # noqa: F811
    imp = accettato["scariche"]["id"]
    _v, plant_id = _emetti(admin, accettato, "LPS esterno con due aste", True)
    sc = admin.get(f"/api/impianti/{imp}/scheda-tecnica").json()
    assert sc["fonte"] == "verbalizzai" and sc["plant_id"] == plant_id and sc["modulo"] == "M02"
    assert sc["verbale"] == "VP/001/26" and sc["confermata"] and not sc["da_riesaminare"]
    assert _voci(sc)["Descrizione dell'impianto"] == "LPS esterno con due aste"
    # la copia del gestionale (offerte, ricerche) è allineata alla stessa revisione della scheda
    x = admin.get(f"/api/impianti/{imp}").json()
    assert x["caratteristiche"]["fonte"] == "verbalizzai" and x["caratteristiche"]["revisione"] == sc["revisione"]
    assert x["ultima_verifica_numero"] == "VP/001/26"
    # esito e date restano nel verbale, non nella scheda
    assert not any("Esito" in k or "Periodicità" in k for k in _voci(sc))

    # correzione a mano nella «Scheda impianto» di VerbalizzAI → la copia del gestionale si riallinea da sola
    st = _vz(admin, f"plant/state?id={plant_id}&module=M02").json()
    stato = st["profile"]["state"]
    stato["plant"]["description"] = "LPS esterno con tre aste"
    r = _vz(admin, "plant/state/save", {"plant_id": plant_id, "module": "M02", "state": stato, "observed_date": "20/10/2026",
                                        "stamp": st["stamp"], "confirmed": True})
    assert r.status_code == 200, r.text
    x = admin.get(f"/api/impianti/{imp}").json()
    assert {c["etichetta"]: c["valore"] for c in x["caratteristiche"]["voci"]}["Descrizione dell'impianto"] == "LPS esterno con tre aste"
    sc = admin.get(f"/api/impianti/{imp}/scheda-tecnica").json()
    assert sc["origine"] == "dati inseriti a mano" and sc["data"] == "2026-10-20"
    voci = admin.post("/api/griglie/registro/dati", {"ricerca": "scheda tecnica riallineata", "dimensione": 10}).json()["righe"]
    assert voci


def test_conserva_la_scheda_non_la_cambia(admin, app, accettato):  # noqa: F811
    """«Conserva la scheda impianto» all'emissione: la scheda resta quella di prima, anche nel gestionale (prima della
    0.12.7 il gestionale prendeva comunque i dati del verbale)."""
    imp = accettato["scariche"]["id"]
    v, _plant_id = _emetti(admin, accettato, "Descrizione solo di questo verbale", False, precedente=True)
    sc = admin.get(f"/api/impianti/{imp}/scheda-tecnica").json()
    assert sc["verbale"] == "VP/050/24" and not sc["confermata"]   # storico importato: «da confermare», come in VerbalizzAI
    assert _voci(sc).get("Descrizione dell'impianto") != "Descrizione solo di questo verbale"
    x = admin.get(f"/api/impianti/{imp}").json()
    assert "Descrizione solo di questo verbale" not in str(x["caratteristiche"] or "")
    assert x["ultima_verifica_numero"] == "VP/001/26"   # le date invece vengono dal verbale emesso
    assert admin.get(f"/api/verifiche/{v['id']}").json()["stato"] == "eseguita"


def test_word_caricato_a_mano_aggiorna_la_scheda(admin, app, accettato):  # noqa: F811
    """Verbale fatto con il VerbalizzAI esterno e caricato sulla verifica: entra nell'archivio dei verbali e aggiorna la
    scheda come un'emissione, così la bozza successiva riparte da lì."""
    imp = accettato["scariche"]["id"]
    v = _registrata(admin, accettato)
    r = admin.c.post(f"/api/verifiche/{v['id']}/verbale", files={"word": ("VP_001_26.docx", verbale_m02("VP/001/26", "15/10/2026"))},
                     data={"versione": str(v["versione"])}, headers=admin.h)
    assert r.status_code == 200, r.text
    assert r.json()["stato"] == "eseguita" and not r.json().get("note_scheda")
    sc = admin.get(f"/api/impianti/{imp}/scheda-tecnica").json()
    assert sc["fonte"] == "verbalizzai" and sc["verbale"] == "VP/001/26" and sc["confermata"]
    prec = admin.get(f"/api/verifiche/{v['id']}/verbale/precedente").json()["precedente"]
    assert prec and prec["numero"] == "VP/001/26"
    # un secondo caricamento dello stesso Word non duplica nulla
    v = admin.get(f"/api/verifiche/{v['id']}").json()
    assert len([w for w in _vz(admin, "summary").json()["plants"] if w["id"] == sc["plant_id"]]) == 1


def test_apri_la_scheda_in_verbalizzai(admin, app, accettato):  # noqa: F811
    imp = accettato["scariche"]["id"]
    sc = admin.get(f"/api/impianti/{imp}/scheda-tecnica").json()
    assert sc["fonte"] == "" and sc["voci"] == [] and sc["plant_id"] is None   # mai verificato: scheda vuota
    r = admin.post(f"/api/impianti/{imp}/scheda-tecnica/apri", {}).json()
    assert r["url"] == f"/verbali?scheda={r['plant_id']}&modulo=M02" and r["modifica"]
    assert admin.get(f"/api/impianti/{imp}/scheda-tecnica").json()["plant_id"] == r["plant_id"]
    # la pagina dei verbali apre la scheda dall'indirizzo
    js = admin.c.get("/static/js/ponte_verbali.js").text
    assert "openPlantState" in js and "scheda" in js


def test_potenza_dalla_scheda():
    """La potenza della scheda (scritta da VerbalizzAI come «250 kW») alimenta le offerte; i kVA non si convertono."""
    from gestionale.moduli.verbali.scheda import _potenza

    assert [_potenza({"plant": {"power": x}}) for x in ("250 kW", "12,5", "100 kVA", "", "n.d.")] == [250.0, 12.5, None, None, None]
