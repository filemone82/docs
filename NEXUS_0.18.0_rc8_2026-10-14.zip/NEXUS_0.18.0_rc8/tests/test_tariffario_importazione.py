"""Versione 0.2.0: tariffario con versioni, importazione con anteprima, aggiornamento da un archivio 0.1.0."""

from __future__ import annotations

import io
from datetime import date, datetime, timedelta

from openpyxl import Workbook

from gestionale.app import prepara_archivio
from gestionale.core import migrazioni


# ---------------------------------------------------------------- tariffario


def _voce_terre(admin):
    righe = admin.post("/api/griglie/tariffario/dati", {}).json()["righe"]
    return admin.get(f"/api/tariffario/voci/{righe[0]['id']}").json()


def prova(admin, **dati):
    return admin.post("/api/tariffario/prova", {"tipologia": "terra_bt", **dati}).json()


def test_tariffa_terre_di_partenza(admin):
    """Tariffa terre del gestionale attuale (01/01/2026) + versione del tariffario M03-RG01_dpr rev. 01 (30/09/2026, 0.4.0)."""
    v = _voce_terre(admin)
    assert v["codice"] == "TERRA-KW" and [x["valida_dal"] for x in v["versioni"]] == ["2026-09-30", "2026-01-01"]
    assert len(v["versioni"][1]["scaglioni"]) == 13 and len(v["versioni"][0]["scaglioni"]) == 14
    assert prova(admin, potenza_kw="10")["totale"] == 15000        # «fino a 10» compreso
    assert prova(admin, potenza_kw="10,5")["totale"] == 20000      # T1: tra due scaglioni vale il superiore
    assert prova(admin, potenza_kw="1.000")["totale"] == 170000
    oltre = prova(admin, potenza_kw="1500")
    assert oltre["totale"] == 200000 and "TERRA-OLTRE-1000KW" in oltre["avvisi"][0]   # oltre 1.000 kW: a tempo con minimo
    sotto = prova(admin, potenza_kw="2")
    assert sotto["totale"] == 5000 and "TERRA-MENO-3KW" in sotto["avvisi"][0]        # sotto 3 kW: a ore, minimo € 50
    r = prova(admin, tipologia="terra_at")
    assert r["totale"] is None and r["problemi"]                   # manca la potenza


def test_tariffario_m03_rev01_scariche_ed_esplosione(admin):
    """Voci del tariffario M03-RG01_dpr rev. 01 (D.M. 07/07/2005 + fattispecie di AD); T2: aste e gabbia si sommano."""
    assert prova(admin, tipologia="scariche", asta=True, numero_aste=1)["totale"] == 10000
    assert prova(admin, tipologia="scariche", asta=True, numero_aste=3)["totale"] == 20000          # 100 + 2 × 50
    assert prova(admin, tipologia="scariche", gabbia=True, gabbia_fascia="da_101_a_350")["totale"] == 20000
    assert prova(admin, tipologia="scariche", asta=True, numero_aste=2, gabbia=True, gabbia_fascia="oltre_350")["totale"] == 45000
    esplosione = prova(admin, tipologia="esplosione", zone=["1"])
    assert esplosione["totale"] is None and "ESPL-ORE" in esplosione["problemi"][0]                 # a ore: si sceglie nel preventivo
    voci = {x["codice"]: x for x in admin.post("/api/griglie/tariffario/dati", {"pagina": 1, "dimensione": 100}).json()["righe"]}
    for codice in ("TERRA-OLTRE-1000KW", "TERRA-MENO-3KW", "TPC", "SCAR-ASTA", "SCAR-ASTA-PIU", "SCAR-GABBIA", "SCAR-STRUTT-ABB",
                   "SCAR-STRUTT", "ESPL-ORE", "STRAORD-ORE", "VUOTO", "DUPLICATO", "TRASFERTA"):
        assert codice in voci, codice


def test_versioni_e_voci_nuove(admin):
    v = _voce_terre(admin)
    in_vigore = v["versioni"][0]
    # una versione già in vigore non si modifica
    assert admin.put(f"/api/tariffario/versioni/{in_vigore['id']}", {"valida_dal": "2027-01-01", "scaglioni": []}).status_code == 400
    domani = (date.today() + timedelta(days=1)).isoformat()
    sbagliata = {"valida_dal": domani, "scaglioni": [{"fino_a": "50", "importo": "100"}, {"fino_a": "20", "importo": "50"}, {"fino_a": "", "importo": "9"}]}
    assert admin.post(f"/api/tariffario/voci/{v['id']}/versioni", sbagliata).status_code == 400  # limiti non crescenti
    senza_oltre = {"valida_dal": domani, "scaglioni": [{"fino_a": "50", "importo": "100"}]}
    assert admin.post(f"/api/tariffario/voci/{v['id']}/versioni", senza_oltre).status_code == 400
    nuova = {"valida_dal": domani, "scaglioni": [{"fino_a": "50", "importo": "320,00"}, {"fino_a": "", "importo": "2.100,00"}]}
    r = admin.post(f"/api/tariffario/voci/{v['id']}/versioni", nuova)
    assert r.status_code == 200, r.text
    assert prova(admin, potenza_kw="30")["totale"] == 30000                      # oggi vale ancora la vecchia
    assert prova(admin, potenza_kw="30", giorno=domani)["totale"] == 32000       # da domani la nuova
    futura = next(x for x in r.json()["versioni"] if x["modificabile"])
    assert admin.delete(f"/api/tariffario/versioni/{futura['id']}").status_code == 200
    # voce a prezzo unitario per le aste
    voce = admin.post("/api/tariffario/voci", {"codice": "asta", "nome": "Asta", "tipologie": ["scariche"], "criterio": "unitario",
                                               "grandezza": "numero_aste", "automatica": True}).json()
    assert voce["codice"] == "ASTA"
    admin.post(f"/api/tariffario/voci/{voce['id']}/versioni", {"valida_dal": "2026-01-01", "prezzo": "80"})
    # 3 × 80 della voce nuova + le voci del tariffario M03 rev. 01 (100 + 2 × 50)
    assert prova(admin, tipologia="scariche", asta=True, numero_aste="3")["totale"] == 24000 + 20000
    assert admin.get(f"/api/storico/tariffa_voce/{voce['id']}").json()[0]["azione"] == "tariffario.versione_crea"


# ---------------------------------------------------------------- importazione


def _xlsx(righe) -> bytes:
    wb = Workbook()
    for r in righe:
        wb.active.append(r)
    b = io.BytesIO()
    wb.save(b)
    return b.getvalue()


def file_di_prova():
    clienti = _xlsx([
        [None, None, "ALFA S.R.L.", "Via Roma 1", 10121, "Torino", "TO", "Piemonte", 1234567897, "info@alfa.it, amm@alfa.it",
         None, 1234567897, "usal8pv", "Bonifico 30gg F.M.", "22 - Imponibile 22%"],
        [None, None, None, None, "COMUNE DI BETA", "Piazza Municipio 1", 13900, "Biella", "BI", "Piemonte", 12345678903,
         "protocollo@beta.it", "comune.beta@pec.it", 12345678903, "UFXYZ1", "Bonifico 6O gg D.F. F.M.", "22sp - Imp. 22% con scissione pagamenti"],
        [None, None, "Alfa srl", "Via Roma 1", 10121, "Torino", "TO", "Piemonte", None, None, None, None, None, None, None],  # doppione
        ["Visualizzati 1-3 di 3"],
    ])
    sedi = _xlsx([
        ["ALFA S.R.L.", "Alfa - Magazzino", "Via Po 3", 10121, "Torino", "TO", "Piemonte", "Mario", None, 115627867, None],
        [None, None, "COMUNE DI BETA", "Scuola ????", "Via Dante 2", 13900, "Biella", "BI", "Piemonte", None, None, None, "chiavi in portineria"],
        [None, None, "GAMMA SNC", "Gamma - Officina", "…", "…", "…", "…", "…", None, None, None, None],
    ])
    intest = ["Codice", "Sede operativa", "Cliente", "Dismesso", "Tipologia impianto", "Anno matr.", "Cod. attività", "Num. matr.",
              "Prov. immatr.", "Denominazione impianto", "Potenza impianto", "N. di cabine di trasformazione MT/BT",
              "N. di sottostazioni AT/MT", "Codice POD", "Numero parafulmini ad asta", "Parafulmine a gabbia", "Classificazione zone",
              "Periodicità verifiche", "Ultima verif.", "Ultima verifica", "Prossima verifica"]
    impianti = _xlsx([intest,
        [101, "Alfa - Magazzino", "ALFA S.R.L.", "No", "messa a terra < 1.000 V", "2004", "5", "01627", "TO", None, 30, None, None,
         "IT001E01234567 – N. cliente: 123456789", None, None, None, 2, "VP/1/24", datetime(2024, 12, 10), datetime(2026, 12, 9)],
        [102, "Scuola ????", "COMUNE DI BETA", "No", "scariche atmosferiche", None, None, None, None, "Palestra", None, None, None,
         None, None, "Sì, superfici protette da 101 a 350 mq", None, 5, None, None, datetime(2020, 1, 1)],
        [103, "Delta - sede", "DELTA SPA", "Sì", "messa a terra > 1.000 V", None, None, None, None, None, 800, 2, 0, "IT001E07654321",
         None, None, None, None, None, None, None],
    ])
    return {"clienti": ("clienti.xlsx", clienti), "sedi": ("sedi.xlsx", sedi), "impianti": ("impianti.xlsx", impianti)}


def test_importazione_con_anteprima(admin, cfg):
    file = file_di_prova()
    r = admin.c.post("/api/importazione/anteprima", files=file, headers=admin.h)
    assert r.status_code == 200, r.text
    a = r.json()
    assert a["nuovi"] == {"clienti": 4, "sedi": 4, "impianti": 3}  # + GAMMA (dalle sedi) e DELTA (dagli impianti)
    problemi = " | ".join(p["problema"] for p in a["problemi"])
    for atteso in ("presente due volte", "caratteri illeggibili", "indirizzo incompleto", "spostato in «Note POD»",
                   "prossima verifica già passata", "periodicità mancante", "creato dal file delle sedi", "sede creata dal file degli impianti"):
        assert atteso in problemi, atteso
    assert admin.post("/api/griglie/clienti/dati", {}).json()["totale"] == 0  # l'anteprima non scrive nulla
    e = admin.post("/api/importazione/conferma", {"codice": a["codice"]}).json()
    assert e["clienti"] == 4 and e["backup"].endswith("_pre_importazione.zip") and len(e["file"]) == 3
    assert (cfg.cartella_backup / e["backup"]).exists()
    assert admin.post("/api/importazione/conferma", {"codice": a["codice"]}).status_code == 400  # anteprima già usata
    clienti = {x["ragione_sociale"]: x for x in admin.post("/api/griglie/clienti/dati", {}).json()["righe"]}
    alfa, beta = clienti["ALFA S.R.L."], clienti["COMUNE DI BETA"]
    assert alfa["partita_iva"] == "01234567897" and alfa["codice_sdi"] == "USAL8PV" and alfa["email_verbali"] == "info@alfa.it; amm@alfa.it"
    assert alfa["modalita_pagamento"] == "Bonifico 30 gg F.M." and alfa["comune"] == "Torino" and alfa["regione"] == "Piemonte"
    assert beta["tipo"] == "Pubblica amministrazione" and beta["modalita_pagamento"] == "Bonifico 60 gg F.M."
    imp = {x["codice_esterno"]: x for x in admin.post("/api/griglie/impianti/dati", {}).json()["righe"]}
    assert imp["101"]["pod"] == "IT001E01234567" and imp["101"]["pod_note"] == "N. cliente: 123456789"
    assert imp["101"]["matricola"] == "2004/5/01627/TO" and imp["101"]["prossima_verifica"] == "2026-12-09"
    assert imp["102"]["gabbia_fascia"] == "Da 101 a 350 m²" and imp["102"]["sede_note"] == "chiavi in portineria"
    assert imp["103"]["dismesso"] and imp["103"]["cliente_ragione_sociale"] == "DELTA SPA"
    sedi = {x["denominazione"]: x for x in admin.post("/api/griglie/sedi/dati", {}).json()["righe"]}
    assert sedi["Alfa - Magazzino"]["referente_telefono"] == "0115627867"
    # ripetere l'importazione non crea doppioni
    a2 = admin.c.post("/api/importazione/anteprima", files=file_di_prova(), headers=admin.h).json()
    assert a2["nuovi"] == {"clienti": 0, "sedi": 0, "impianti": 0} and a2["gia_presenti"]["impianti"] == 3
    reg = admin.post("/api/griglie/registro/dati", {"filtri": [{"campo": "azione", "valore": "anagrafica.importa"}]}).json()
    assert reg["totale"] == 1


# ---------------------------------------------------------------- aggiornamento da un archivio della 0.1.0


def test_aggiornamento_da_archivio_0_1_0(cfg):
    from alembic import command

    cfg.prepara_cartelle()
    command.upgrade(migrazioni.config_alembic(f"sqlite:///{cfg.percorso_database}"), "0001")
    arc = prepara_archivio(cfg)
    try:
        assert migrazioni.revisione_database(arc.motore) == migrazioni.revisione_programma()
        assert any("pre_aggiornamento" in p.name for p in cfg.cartella_backup.iterdir())
        with arc.lettura() as s:
            from sqlalchemy import func, select

            from gestionale.moduli.anagrafica.modelli import Comune
            assert s.execute(select(func.count()).select_from(Comune)).scalar() > 7800
    finally:
        arc.chiudi()


def test_migrazione_0003_conserva_i_collegamenti_ai_comuni(cfg):
    """L'aggiunta di «attivo» ai comuni non deve ricreare la tabella (cancellerebbe il comune delle schede)."""
    import sqlite3

    from alembic import command

    cfg.prepara_cartelle()
    command.upgrade(migrazioni.config_alembic(f"sqlite:///{cfg.percorso_database}"), "0002")
    conn = sqlite3.connect(cfg.percorso_database)
    conn.execute("INSERT INTO comuni VALUES ('001314','Volpiano','TO','Torino','Piemonte','10088','M122')")
    conn.execute("""INSERT INTO clienti (ragione_sociale, tipo, nazione, partita_iva, codice_fiscale, email_verbali, email_fatture, pec,
        codice_sdi, riferimento_amministrazione, referente_nome, referente_email, referente_telefono, banca, iban, dichiarazione_intento,
        dichiarazione_numero, sconti_ammessi, sconti_motivo, attivo, note, avvisi, codice_esterno, indirizzo, comune_istat, comune, cap,
        provincia, regione, versione, creato_il, creato_da, modificato_il, modificato_da)
        VALUES ('Prova','privato','IT','','','','','','','','','','','','',0,'',0,'',1,'','','','Via 1','001314','Volpiano','10088','TO',
        'Piemonte',1,'2026-10-04','','2026-10-04','')""")
    conn.commit()
    conn.close()
    arc = prepara_archivio(cfg)
    try:
        with arc.lettura() as s:
            from sqlalchemy import text
            assert s.execute(text("SELECT comune_istat FROM clienti")).scalar() == "001314"
            assert s.execute(text("SELECT attivo FROM comuni WHERE codice_istat='001314'")).scalar() == 1
    finally:
        arc.chiudi()
