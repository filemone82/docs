"""0.12.5 · R116: sedi doppie dello stesso cliente — riconoscerle, unirle, dichiararle diverse."""

from __future__ import annotations

from sqlalchemy import select
from test_anagrafica import PIVA_2, crea_cliente, crea_impianto, crea_sede
from test_beni import nuovo, ok

from gestionale.moduli.anagrafica import doppioni


def test_chiave_e_somiglianza():
    assert doppioni.chiave("Via Roma, n. 1") == doppioni.chiave("VIA ROMA 1") == doppioni.chiave("via Roma n°1")
    assert doppioni.chiave("Piazza Libertà 3") == doppioni.chiave("PIAZZA LIBERTA' 3")
    assert doppioni.somiglianza("via E. Fermi n. 13", "Via Enrico Fermi 13") > doppioni.somiglianza("Strada Montanara 387", "via Montanara 343/A")


def test_unione_di_due_sedi(admin, app):
    c = crea_cliente(admin)
    dpr = crea_sede(admin, c["id"], denominazione="Stabilimento", indirizzo="Via Po, n. 2", referente_nome="Rossi")
    dm = crea_sede(admin, c["id"], denominazione="STABILIMENTO SRL", indirizzo="VIA PO 2", referente_nome="Bianchi",
                   referente_telefono="011 123456", note="cancello sul retro")
    altra = crea_sede(admin, c["id"], denominazione="Magazzino", indirizzo="Via Dora 9")
    imp = crea_impianto(admin, dpr["id"])
    att = nuovo(admin, dm, "SC", "SC-1")
    p = ok(admin.post("/api/preventivi", {"ambito": "DM", "sede_id": dm["id"], "attrezzature": [{"asset_id": att["id"], "tipo_verifica_dm": "V2"}]}))
    cand = ok(admin.get("/api/sedi/doppioni"))
    assert cand[0]["stesso_indirizzo"] and {cand[0]["a"]["id"], cand[0]["b"]["id"]} == {dpr["id"], dm["id"]}
    assert any(x["b"]["id"] == altra["id"] or x["a"]["id"] == altra["id"] for x in cand)  # stesso comune: proposta, meno probabile
    # unione: resta la sede DPR, tutto passa lì
    r = ok(admin.post(f"/api/sedi/{dm['id']}/unisci", {"destinazione_id": dpr["id"]}))
    assert r["ambiti"] == ["DPR", "DM"] and r["referente_nome"] == "Rossi" and r["referente_telefono"] == "011 123456"
    assert "Unita la sede «STABILIMENTO SRL»" in r["note"] and "referente nome: Bianchi" in r["note"] and "cancello sul retro" in r["note"]
    assert admin.get(f"/api/sedi/{dm['id']}").status_code == 404
    assert ok(admin.get(f"/api/beni/{att['id']}"))["sede_id"] == dpr["id"]
    assert ok(admin.get(f"/api/impianti/{imp['id']}"))["sede_id"] == dpr["id"]
    assert ok(admin.get(f"/api/preventivi/{p['id']}"))["sede_id"] == dpr["id"]
    with app.state.archivio.lettura() as s:
        from gestionale.moduli.registro.modelli import RegistroOperazione

        voce = s.scalar(select(RegistroOperazione).where(RegistroOperazione.azione == "sede.unisci"))
        assert voce is not None and '"preventivi": 1' in voce.dettagli
    # le sedi diverse non si propongono più
    ok(admin.post("/api/sedi/doppioni/diverse", {"a": altra["id"], "b": dpr["id"]}))
    assert ok(admin.get("/api/sedi/doppioni")) == []


def test_unione_rifiutata(admin):
    c = crea_cliente(admin)
    a, b = crea_sede(admin, c["id"]), crea_sede(admin, c["id"], denominazione="Bis")
    nuovo(admin, a, "SC", "STESSA")
    nuovo(admin, b, "SC", "STESSA")
    r = admin.post(f"/api/sedi/{b['id']}/unisci", {"destinazione_id": a["id"]})
    assert r.status_code == 400 and "stessa matricola" in r.json()["errore"] and "STESSA" in r.json()["errore"]
    altro = crea_cliente(admin, ragione_sociale="Altro", partita_iva=PIVA_2, codice_fiscale=PIVA_2)
    x = crea_sede(admin, altro["id"])
    r = admin.post(f"/api/sedi/{x['id']}/unisci", {"destinazione_id": a["id"]})
    assert r.status_code == 400 and "stesso cliente" in r.json()["errore"]
