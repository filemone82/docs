"""0.12.8 · R124 revoca motivata dell'accettazione; N3 «Accetta» su righe già accettate; N5 riesame non ripetibile."""

from __future__ import annotations

from test_verifiche import accettato  # noqa: F401

CONFORME = {"esito": "conforme", "requisiti_chiari": True, "competenza_strumenti": True, "imparzialita": True, "tempi": True}


def _p(admin, p):
    return admin.get(f"/api/preventivi/{p['id']}").json()


def test_revoca_annulla_la_verifica_da_assegnare_e_chiede_un_nuovo_riesame(admin, accettato):  # noqa: F811
    p = _p(admin, accettato["preventivo"])
    riga = next(r for r in p["righe"] if r["impianto_id"] == accettato["scariche"]["id"])
    ver = next(v for v in p["verifiche"] if v["impianto_id"] == accettato["scariche"]["id"])
    # N3: accettare di nuovo non cambia nulla e lo dice; l'evidenza non si sovrascrive
    r = admin.post(f"/api/preventivi/{p['id']}/righe/stato", {"righe": [riga["id"]], "stato": "accettata", "versione": p["versione"],
                                                              "evidenza_accettazione": "altra"})
    assert r.status_code == 400 and "nessuna modifica" in r.json()["errore"]
    assert _p(admin, p)["evidenza_accettazione"] != "altra"
    # N5: senza cambiamenti il riesame non si ripete
    assert not p["riesame_necessario"]
    assert admin.post(f"/api/preventivi/{p['id']}/riesame", CONFORME).status_code == 400
    # R124: senza motivo no; con motivo la riga torna in attesa e la verifica «da assegnare» si annulla
    r = admin.post(f"/api/preventivi/{p['id']}/righe/revoca", {"righe": [riga["id"]], "motivo": "", "versione": p["versione"]})
    assert r.status_code == 400 and "motivo" in r.json()["errore"]
    p = admin.post(f"/api/preventivi/{p['id']}/righe/revoca", {"righe": [riga["id"]], "motivo": "Ordine ritirato dal cliente",
                                                              "versione": p["versione"]}).json()
    assert next(x for x in p["righe"] if x["id"] == riga["id"])["stato"] == "in_attesa"
    assert p["revoche"][0]["motivo"] == "Ordine ritirato dal cliente" and p["revoche"][0]["verifica_id"] == ver["id"]
    assert admin.get(f"/api/verifiche/{ver['id']}").json()["stato"] == "annullata"
    voci = admin.post("/api/griglie/registro/dati", {"ricerca": "revocata l'accettazione", "dimensione": 10}).json()["righe"]
    assert voci
    # riaccettata: serve un nuovo riesame, poi nasce una verifica nuova
    p = admin.post(f"/api/preventivi/{p['id']}/righe/stato", {"righe": [riga["id"]], "stato": "accettata", "versione": p["versione"],
                                                             "evidenza_accettazione": "Nuova email di conferma"}).json()
    assert p["riesame_necessario"]
    assert not [v for v in p["verifiche"] if v["impianto_id"] == accettato["scariche"]["id"] and v["stato"] != "annullata"]
    assert admin.post(f"/api/preventivi/{p['id']}/riesame", CONFORME).status_code == 200
    p = _p(admin, p)
    nuove = [v for v in p["verifiche"] if v["impianto_id"] == accettato["scariche"]["id"] and v["stato"] == "da_assegnare"]
    assert len(nuove) == 1 and nuove[0]["id"] != ver["id"] and not p["riesame_necessario"]


def test_revoca_bloccata_se_la_verifica_e_gia_affidata(admin, accettato):  # noqa: F811
    p = _p(admin, accettato["preventivo"])
    ver = next(v for v in p["verifiche"] if v["impianto_id"] == accettato["scariche"]["id"])
    v = admin.get(f"/api/verifiche/{ver['id']}").json()
    io = admin.get("/api/verifiche/valori").json()["verificatori"][0]["id"]
    admin.post(f"/api/verifiche/{v['id']}/assegna", {"verificatore_id": io, "versione": v["versione"]})
    riga = next(r for r in p["righe"] if r["impianto_id"] == accettato["scariche"]["id"])
    r = admin.post(f"/api/preventivi/{p['id']}/righe/revoca", {"righe": [riga["id"]], "motivo": "x", "versione": p["versione"]})
    assert r.status_code == 400 and "Annulla prima" in r.json()["errore"]
    assert admin.get(f"/api/verifiche/{ver['id']}").json()["stato"] == "assegnata"
