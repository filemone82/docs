"""Contratto tra il gestionale e VerbalizzAI (documento 15 § 5).

Questi test elencano ciò che il gestionale usa di VerbalizzAI. Se una nuova versione copiata con
`strumenti/aggiorna_verbalizzai.py` cambia una di queste cose, il test fallisce e dice cosa adattare nel ponte
(`gestionale/moduli/verbali`), prima di qualunque prova nel browser.
"""

from __future__ import annotations

import inspect
import re
from pathlib import Path

from gestionale.moduli.verbali import api as api_verbali
from gestionale.moduli.verbali import archivio, ponte
from gestionale.terzi import verbalizzai
from gestionale.terzi.verbalizzai import app as vz
from gestionale.terzi.verbalizzai import storage

CARTELLA = Path(verbalizzai.__file__).parent


def _parametri(funzione) -> list[str]:  # noqa: ANN001
    return list(inspect.signature(funzione).parameters)


def test_versione_dichiarata():
    assert verbalizzai.VERSIONE == storage.APP_VERSION, "Aggiornare VERSIONE in terzi/verbalizzai/__init__.py (lo fa lo script)."


def test_codice_di_verbalizzai_non_modificato_salvo_gli_import():
    """Nessun import assoluto rimasto (lo script li rende relativi) e nessun file in più o in meno inatteso."""
    locali = {p.stem for p in CARTELLA.glob("*.py")} - {"__init__"}
    nomi = "|".join(sorted(locali))
    for p in CARTELLA.glob("*.py"):
        testo = p.read_text(encoding="utf-8")
        assert not re.search(rf"^[ \t]*(from ({nomi}) import|import ({nomi})\b)", testo, re.M), p.name
    assert {"app", "storage", "finalization", "plantstate", "templates", "wordio", "forms", "rules"} <= locali


def test_server_usato_dal_ponte():
    """Il ponte sostituisce queste funzioni di app.Handler: devono esistere con questi parametri."""
    h = vz.Handler
    assert _parametri(h.send)[:5] == ["self", "status", "data", "ctype", "filename"] and "inline_pdf" in _parametri(h.send)
    assert _parametri(h.send_path) == ["self", "path", "filename", "remove"]
    assert _parametri(h.headers_common)[:2] == ["self", "filename"] and "inline_pdf" in _parametri(h.headers_common)
    assert _parametri(h.guard) == ["self", "path", "mutation"]
    for nome in ("do_GET", "do_POST", "fail"):
        assert callable(getattr(h, nome, None)), nome
    for nome in ("NEEDS", "PERM_LABEL", "PERMISSIONS", "ROLE_LABELS", "APP_VERSION", "Sessions"):
        assert hasattr(vz, nome), nome


def test_percorsi_ascoltati_dal_gestionale_esistono():
    """Dopo questi percorsi la verifica del gestionale si aggiorna: se VerbalizzAI li rinomina, il gestionale non lo saprebbe."""
    for percorso in api_verbali.EMISSIONE + api_verbali.ANNULLAMENTO:
        assert "/api/" + percorso in vz.NEEDS, percorso
    for percorso in ponte.ESCLUSE:
        assert percorso in vz.NEEDS or f"'{percorso}'" in (CARTELLA / "app.py").read_text(encoding="utf-8"), percorso


def test_ogni_permesso_di_verbalizzai_ha_una_corrispondenza():
    """Un permesso nuovo di VerbalizzAI deve essere tradotto (o escluso con None) in moduli/verbali/archivio.py."""
    nuovi = {k for k, _ in storage.PERMISSIONS} - set(archivio.PERMESSI)
    assert not nuovi, f"Permessi di VerbalizzAI senza corrispondenza nel gestionale: {sorted(nuovi)}"
    from gestionale.core.permessi import PER_CODICE
    for vz_perm, codice in archivio.PERMESSI.items():
        assert codice is None or codice in PER_CODICE, (vz_perm, codice)


def test_archivio_usato_dal_gestionale():
    """Funzioni dell'archivio di VerbalizzAI chiamate da moduli/verbali (servizio, importazione, archivio)."""
    a = storage.Archive
    attese = {"create_draft": ["self", "plant_id", "baseline_id", "inspector", "module"], "save": ["self", "oid", "data", "revision"],
              "get": None, "all": None, "where": ["self", "kind", "field", "value"], "mutate": None, "_put": None,
              "document": ["self", "digest"], "templates_for": ["self", "module"], "add_template": ["self", "original", "filename", "adapted", "info"],
              "set_actor": ["self", "username"], "users": ["self"], "user": ["self", "username"], "can": ["self", "user", "perm"],
              "perms_of": ["self", "user"], "verify_backup": None, "restore": None, "signer_for": None, "signature_image": None}
    for nome, parametri in attese.items():
        f = getattr(a, nome, None)
        assert callable(f), f"Archive.{nome} non esiste più"
        if parametri:
            assert _parametri(f)[: len(parametri)] == parametri, (nome, _parametri(f))
    assert storage.FORMAT_VERSION == 2, "Formato dell'archivio cambiato: provare la conversione su una copia (documento 15 § 4.6)."


def test_archivio_dei_verbali_della_050_si_converte(tmp_path):
    """Un archivio dei verbali creato dalla 0.5.0 (VerbalizzAI 0.3.25, formato 1) si apre: backup e conversione al formato 2."""
    import sqlite3
    import zipfile

    cartella = tmp_path / "verbali"
    cartella.mkdir()
    with zipfile.ZipFile(Path(__file__).parent / "dati" / "verbali_formato1_v050.zip") as z:
        z.extractall(cartella)
    prima = sqlite3.connect(cartella / "archivio.sqlite")
    assert prima.execute("SELECT value FROM meta WHERE key='format_version'").fetchone()[0] == "1"
    oggetti = prima.execute("SELECT kind, COUNT(*) FROM objects GROUP BY kind ORDER BY kind").fetchall()
    prima.close()
    a = archivio.ArchivioVerbali(cartella, None)
    dopo = sqlite3.connect(cartella / "archivio.sqlite")
    assert dopo.execute("SELECT value FROM meta WHERE key='format_version'").fetchone()[0] == "2"
    assert dopo.execute("SELECT kind, COUNT(*) FROM objects GROUP BY kind ORDER BY kind").fetchall() == oggetti
    assert any(p.name.startswith("prima_schema2") for p in (cartella / "backups").iterdir())
    bozza = next(iter(a.all("inspection")))
    assert bozza["data"]["status"] == "draft" and bozza["data"]["header"]["number"] == "VP/001/26"
