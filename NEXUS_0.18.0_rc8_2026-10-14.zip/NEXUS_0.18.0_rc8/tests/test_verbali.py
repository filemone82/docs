"""Verbali compilati nel gestionale (VerbalizzAI dentro il gestionale, 0.5.0, D67)."""

from __future__ import annotations

from conftest import revisore

from conftest import nuovo_utente
from test_verifiche import accettato  # noqa: F401  (fixture)


def _registrata(admin, accettato, chi=None):  # noqa: F811
    chi = chi or admin
    p = accettato["preventivo"]
    ver = {v["impianto_id"]: v for v in p["verifiche"]}[accettato["scariche"]["id"]]
    v = admin.get(f"/api/verifiche/{ver['id']}").json()
    io = next(x["id"] for x in admin.get("/api/verifiche/valori").json()["verificatori"] if x["nome"] == chi.get("/api/io").json()["nome"])
    v = admin.post(f"/api/verifiche/{v['id']}/assegna", {"verificatore_id": io, "versione": v["versione"]}).json()
    v = chi.post(f"/api/verifiche/{v['id']}/registra", {"data_esecuzione": "2026-10-15", "versione": v["versione"]}).json()
    assert v["stato"] == "registrata", v
    return v


def _firma(s):
    """Firma grafica (PNG 300 × 100 bianco con una riga nera) dell'utente della sessione."""
    import base64
    import struct
    import zlib

    w, h = 300, 100
    righe = b"".join(b"\x00" + (b"\x00" * w if y == 50 else b"\xff" * w) for y in range(h))
    def blocco(tipo, dati):
        return struct.pack(">I", len(dati)) + tipo + dati + struct.pack(">I", zlib.crc32(tipo + dati) & 0xFFFFFFFF)
    png = b"\x89PNG\r\n\x1a\n" + blocco(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 0, 0, 0, 0)) + blocco(b"IDAT", zlib.compress(righe)) + blocco(b"IEND", b"")
    r = _vz(s, "signature", {"content": base64.b64encode(png).decode(), "filename": "firma.png"})
    assert r.status_code == 200, r.text


def _vz(s, percorso, dati=None):
    me = s.get("/verbali/api/me").json()
    if dati is None:
        return s.c.get("/verbali/api/" + percorso)
    return s.c.post("/verbali/api/" + percorso, json=dati, headers={"X-AD-Token": me["csrf"]})


def test_pagina_e_percorsi(admin):
    r = admin.get("/verbali")
    assert r.status_code == 200 and "/verbali/static/app.js" in r.text and "ponte_verbali.js" in r.text
    assert "ponte_verbali.css" in r.text and admin.get("/static/css/ponte_verbali.css").status_code == 200  # anagrafica unica
    assert 'data-view="users"' not in r.text and "Torna al gestionale" in r.text
    js = admin.get("/verbali/static/app.js").text
    assert "'/verbali/api/me'" in js and "'/api/me'" not in js.replace("/verbali/api/", "")
    assert admin.get("/verbali/static/../app.py").status_code == 404
    me = admin.get("/verbali/api/me").json()
    assert me["user"]["username"] == "federico" and me["gestionale"] and "draft" in me["perms"]
    # funzioni che nel gestionale stanno altrove
    assert _vz(admin, "users").status_code == 403
    assert _vz(admin, "login", {"username": "x", "password": "y"}).status_code == 403
    # anagrafica unica (0.6.0): clienti, sedi e impianti si creano, correggono ed eliminano solo nel gestionale
    for percorso, parola in (("plant/new", "gestionale"), ("plant/update", "gestionale"), ("plant/delete", "gestionale"), ("draft/new", "Compila il verbale")):
        r = _vz(admin, percorso, {"id": "x", "client_name": "Nuovo", "address": "Via Roma 1"})
        assert r.status_code == 403 and parola in r.json()["error"], (percorso, r.text)
    assert "plant" not in me["perms"] and "plant_technical" in me["perms"]
    # senza token: rifiutato
    assert admin.c.post("/verbali/api/draft/delete", json={"id": "x"}).status_code == 403
    # modelli M01-M03 caricati all'avvio
    assert len(_vz(admin, "summary").json()["templates"]) >= 3


def test_bozza_emissione_e_verifica_eseguita(admin, app, accettato):  # noqa: F811
    v = _registrata(admin, accettato)
    r = admin.post(f"/api/verifiche/{v['id']}/verbale/bozza", {})
    assert r.status_code == 200, r.text
    vid = r.json()["verbale_id"]
    assert admin.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).json()["verbale_id"] == vid   # stessa bozza
    item = _vz(admin, f"inspection?id={vid}").json()
    d = item["item"]["data"] if "item" in item else item["data"]
    assert d["header"]["number"] == "VP/001/26" and d["header"]["report_date"] == "15/10/2026"
    assert d["plant"]["client_name"] == "Verifiche Prova S.r.l."
    rev = (item.get("item") or item)["revision"]
    d["flags"]["outcome"] = {"positive": True, "negative": False}
    r = _vz(admin, "draft/save", {"id": vid, "data": d, "revision": rev})
    assert r.status_code == 200, r.text
    rev = r.json()["item"]["revision"]
    # VerbalizzAI 0.3.31+: senza anteprima PDF non si firma né si emette
    r = _vz(admin, "inspection/issue", {"id": vid, "revision": rev, "confirm_anomalies": True})
    assert r.status_code == 400 and "anteprima" in r.json()["error"].lower()
    _firma(admin)
    r = _vz(admin, "review/preview", {"id": vid, "revision": rev})
    assert r.status_code == 200, r.text
    anteprima = r.json()
    eid = anteprima["export"]["id"]
    # il PDF dell'anteprima si apre dentro la pagina (stesso sito), non in pagine di altri siti
    pdf = admin.c.get(f"/verbali/api/document?sha={anteprima['export']['data']['pdf_sha']}&inline=1")
    assert pdf.status_code == 200 and pdf.headers["content-type"].startswith("application/pdf")
    assert pdf.headers["x-frame-options"] == "SAMEORIGIN" and pdf.headers["content-disposition"].startswith("inline")
    assert admin.get("/verbali/api/me").headers["x-frame-options"] == "DENY"
    rev = anteprima["item"]["revision"]
    r = _vz(admin, "review/issue", {"id": vid, "revision": rev, "preview_id": eid, "approved": True, "update_plant": True})
    assert r.status_code == 200, r.text
    assert any("eseguita" in n for n in r.json().get("notes", [])), r.json().get("notes")
    v = admin.get(f"/api/verifiche/{v['id']}").json()
    assert v["stato"] == "eseguita" and v["verbale_id"] == vid and v["documenti"]
    # 0.6.0: i dati vengono dal verbale compilato, non dalla rilettura del Word (niente avvisi di lettura)
    assert v["esito"] == "positivo" and not any("non riconosciuto" in a for a in v["avvisi_verbale"]), v["avvisi_verbale"]


def test_tecnico_non_compila_verifiche_altrui(admin, app, accettato):  # noqa: F811
    nuovo_utente(admin, app, "tecnico7", "tecnico")
    altro = nuovo_utente(admin, app, "tecnico8", "tecnico")
    v = _registrata(admin, accettato)
    assert altro.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).status_code == 403
    assert "users" not in altro.get("/verbali/api/me").json()["perms"]


def test_backup_del_gestionale_comprende_i_verbali(admin, app, accettato):  # noqa: F811
    v = _registrata(admin, accettato)
    vid = admin.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).json()["verbale_id"]
    nome = admin.post("/api/backup").json()["nome"]
    assert admin.post(f"/api/backup/{nome}/verifica").json()["valido"]
    assert _vz(admin, "draft/delete", {"id": vid}).status_code == 200
    r = admin.post(f"/api/backup/{nome}/ripristina", {"conferma": "RIPRISTINA"})
    assert r.status_code == 200, r.text
    from conftest import PASSWORD_ADMIN, Sessione
    admin.c.post("/api/accesso", json={"username": "federico", "password": PASSWORD_ADMIN})
    s = Sessione(admin.c)
    assert _vz(s, f"inspection?id={vid}").status_code == 200   # la bozza è tornata


def test_assegnazione_in_blocco(admin, app, accettato):  # noqa: F811
    p = accettato["preventivo"]
    nuovo_utente(admin, app, "tecnico9", "tecnico")
    chi = next(x["id"] for x in admin.get("/api/verifiche/valori").json()["verificatori"] if x["nome"] == "Tecnico9")
    ids = [v["id"] for v in p["verifiche"]]
    assert admin.post("/api/verifiche/assegna-in-blocco", {"verifiche": [], "verificatore_id": chi}).status_code == 400
    r = admin.post("/api/verifiche/assegna-in-blocco", {"verifiche": ids, "verificatore_id": chi})
    assert r.status_code == 200 and r.json()["assegnate"] == 2
    assert {admin.get(f"/api/verifiche/{i}").json()["verificatore"] for i in ids} == {"Tecnico9"}
    v = admin.get(f"/api/verifiche/{ids[0]}").json()
    admin.post(f"/api/verifiche/{ids[0]}/annulla", {"motivo": "prova", "versione": v["versione"]})
    r = admin.post("/api/verifiche/assegna-in-blocco", {"verifiche": ids, "verificatore_id": chi})
    assert r.status_code == 400 and f"n. {ids[0]}" in r.json()["errore"]


def test_o16_archivio_vuoto_e_cartella_dati(admin, cfg, tmp_path, monkeypatch):
    from gestionale.core.config import fissa_cartella_dati
    assert "archivio è <strong>vuoto</strong>" in admin.get("/").text
    f = tmp_path / "config.json"
    f.write_text('{"porta": 9000}', encoding="utf-8")
    # ambiente di prova (cartella da GESTIONALE_CARTELLA_DATI): config.json non si tocca (0.6.0)
    monkeypatch.setenv("GESTIONALE_CARTELLA_DATI", str(tmp_path / "prova"))
    assert not fissa_cartella_dati(cfg, f) and "cartella_dati" not in f.read_text(encoding="utf-8")
    monkeypatch.delenv("GESTIONALE_CARTELLA_DATI")
    assert fissa_cartella_dati(cfg, f)
    import json
    d = json.loads(f.read_text(encoding="utf-8"))
    assert d["porta"] == 9000 and d["cartella_dati"]
    assert not fissa_cartella_dati(cfg, f)   # già presente: non si tocca


def _backup_vz(tmp_path, numero="VP/050/26", giorno="10/03/2026", pod="IT001E12345678"):
    """Backup completo di un VerbalizzAI con un impianto e un verbale storico M02."""
    import json as _json

    from test_verifiche import verbale_m02

    from gestionale.terzi.verbalizzai import wordio
    from gestionale.terzi.verbalizzai.storage import Archive
    a = Archive(tmp_path / "vz")
    d = wordio.parse_word(verbale_m02(numero, giorno), "v.docx")
    d["plant"]["pod"] = pod
    pid = a.mutate(lambda c: a._put(c, "plant", {"client_name": "Verifiche Prova S.r.l.", "site_name": "", "address": d["plant"].get("address") or "Via Roma 1, Torino (TO)",
                                                  "label": "x", "complete_inventory": False}))
    d.update(plant_id=pid, status="historical", historical=True)
    d.pop("source_sha", None)
    a.mutate(lambda c: a._put(c, "inspection", d))
    _json.dumps(d)
    return a.export_backup(tmp_path / "vz.adbackup.zip", include_documents=True).read_bytes()


def test_importazione_e_collegamento(admin, app, accettato, tmp_path):  # noqa: F811
    contenuto = _backup_vz(tmp_path)
    r = admin.c.post("/api/verbali/importa", files={"file": ("vz.adbackup.zip", contenuto, "application/zip")}, headers=admin.h)
    assert r.status_code == 200, r.text
    # una seconda volta no: ci sono già dei verbali
    r = admin.c.post("/api/verbali/importa", files={"file": ("vz.adbackup.zip", contenuto, "application/zip")}, headers=admin.h)
    assert r.status_code == 400 and "una volta" in r.json()["errore"]
    elenco = admin.get("/api/verbali/collegamenti").json()
    riga = elenco["impianti"][0]
    assert elenco["verbali"] == 1 and riga["moduli"] == ["M02"] and riga["proposta"] and riga["motivo"] in ("probabile", "cliente e indirizzo")
    e = admin.post(f"/api/verbali/collegamenti/{riga['id']}", {"sede_id": riga["proposta"]["id"]}).json()
    assert e["impianti"] == {"M02": accettato["scariche"]["id"]}
    x = admin.get(f"/api/impianti/{accettato['scariche']['id']}").json()
    assert x["ultima_verifica_numero"] == "VP/050/26" and x["caratteristiche"]["verbale"] == "VP/050/26"
    assert admin.get("/api/verbali/collegamenti").json()["impianti"][0]["collegata"]
    # la bozza di una verifica di quell'impianto usa lo stesso impianto di VerbalizzAI (con lo storico)
    v = _registrata(admin, accettato)
    vid = admin.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).json()["verbale_id"]
    item = _vz(admin, f"inspection?id={vid}").json()
    assert (item.get("item") or item)["data"]["plant_id"] == riga["id"]
    assert admin.c.delete(f"/api/verbali/collegamenti/{riga['id']}", headers=admin.h).status_code == 200
    assert admin.get("/verbali-importa").status_code == 200


def _bozza_pronta(chi, admin, accettato):  # noqa: F811
    v = _registrata(admin, accettato, chi)
    vid = chi.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).json()["verbale_id"]
    item = _vz(chi, f"inspection?id={vid}").json()["item"]
    d = item["data"]
    d["flags"]["outcome"] = {"positive": True, "negative": False}
    rev = _vz(chi, "draft/save", {"id": vid, "data": d, "revision": item["revision"]}).json()["item"]["revision"]
    _firma(chi)
    anteprima = _vz(chi, "review/preview", {"id": vid, "revision": rev}).json()
    return v, vid, anteprima


def test_riallineamento_ritrova_emissione_anche_senza_collegamento_nella_verifica(
        admin, app, accettato, monkeypatch):  # noqa: F811
    """Simula la caduta dopo l'emissione e la perdita del link nel gestionale."""
    from gestionale.moduli.verbali import servizio
    from gestionale.moduli.verifiche.modelli import Verifica

    v, vid, anteprima = _bozza_pronta(admin, admin, accettato)
    originale = servizio.dopo_emissione

    def interrotto(*_a, **_kw):
        raise RuntimeError("Simulazione: commit gestionale non completato")

    with monkeypatch.context() as patch:
        patch.setattr(servizio, "dopo_emissione", interrotto)
        r = _vz(admin, "review/issue", {"id": vid, "revision": anteprima["item"]["revision"],
                                         "preview_id": anteprima["export"]["id"],
                                         "approved": True, "update_plant": True})
    assert r.status_code == 200, r.text
    assert app.state.verbali.get(vid)["data"]["status"] == "issued"
    with app.state.archivio.scrittura() as s:
        assert s.get(Verifica, v["id"]).stato == "registrata"
        s.get(Verifica, v["id"]).verbale_id = ""

    assert servizio.dopo_emissione is originale
    r = admin.post("/api/verbali/riallinea", {})
    assert r.status_code == 200, r.text
    assert any(x["verifica_id"] == v["id"] for x in r.json()["allineati"])
    aggiornato = admin.get(f"/api/verifiche/{v['id']}").json()
    assert aggiornato["stato"] == "eseguita" and aggiornato["verbale_id"] == vid
    assert admin.post("/api/verbali/riallinea", {}).status_code == 200  # idempotente


def test_stato_tecnico_solo_con_il_permesso(admin, app, accettato):  # noqa: F811
    """All'emissione VerbalizzAI aggiorna lo stato tecnico dell'impianto solo se il ruolo ha «impianti.stato_tecnico»."""
    from conftest import ruolo_id

    tec = nuovo_utente(admin, app, "tecnico5", "tecnico")
    id_tec = ruolo_id(admin, "tecnico")
    r_tec = next(x for x in admin.get("/api/permessi/matrice").json()["ruoli"] if x["id"] == id_tec)
    assert "impianti.stato_tecnico" in r_tec["permessi"]  # di partenza: RT e Tecnico
    senza = [p for p in r_tec["permessi"] if p != "impianti.stato_tecnico"]
    assert admin.put("/api/permessi/ruolo", {"ruolo_id": id_tec, "permessi": senza, "versione": r_tec["versione"]}).status_code == 200
    v, vid, anteprima = _bozza_pronta(tec, admin, accettato)
    assert "plant_technical" not in _vz(tec, "me").json()["perms"]
    dati = {"id": vid, "revision": anteprima["item"]["revision"], "preview_id": anteprima["export"]["id"], "approved": True}
    r = _vz(tec, "review/issue", dict(dati, update_plant=True))
    assert r.status_code == 403 and "stato tecnico" in r.json()["error"]
    r = _vz(tec, "review/issue", dict(dati, update_plant=False))
    assert r.status_code == 200, r.text
    assert admin.get(f"/api/verifiche/{v['id']}").json()["stato"] == "eseguita"


def test_riprendi_il_verbale_riporta_l_anagrafica_del_gestionale(admin, app, accettato):  # noqa: F811
    """Anagrafica unica (0.6.0): se nel gestionale cambia la ragione sociale, la bozza riaperta la prende."""
    from gestionale.moduli.anagrafica.modelli import Cliente

    v = _registrata(admin, accettato)
    vid = admin.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).json()["verbale_id"]
    with app.state.archivio.scrittura() as s:
        c = s.query(Cliente).filter_by(ragione_sociale="Verifiche Prova S.r.l.").one()
        c.ragione_sociale = "Verifiche Prova Nuova S.r.l."
    assert admin.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).json()["verbale_id"] == vid
    assert _vz(admin, f"inspection?id={vid}").json()["item"]["data"]["plant"]["client_name"] == "Verifiche Prova Nuova S.r.l."


def test_riesame_non_conforme_si_corregge_con_una_revisione(admin, app, accettato):  # noqa: F811
    """Riesame non conforme del verbale emesso: «Compila il verbale» apre una REVISIONE (stesso numero), non un verbale nuovo."""
    v, vid, anteprima = _bozza_pronta(admin, admin, accettato)
    r = _vz(admin, "review/issue", {"id": vid, "revision": anteprima["item"]["revision"], "preview_id": anteprima["export"]["id"],
                                    "approved": True, "update_plant": True})
    assert r.status_code == 200, r.text
    v = admin.get(f"/api/verifiche/{v['id']}").json()
    v = revisore(admin).post(f"/api/verifiche/{v['id']}/riesame", {"esito": "non_conforme", "note": "data sbagliata", "versione": v["versione"]}).json()
    assert v["stato"] == "registrata"
    nuovo = admin.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).json()["verbale_id"]
    assert nuovo != vid
    assert admin.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).json()["verbale_id"] == nuovo  # la stessa revisione
    d = _vz(admin, f"inspection?id={nuovo}").json()["item"]["data"]
    assert d["revision_of"] == vid and d["rev_index"] == 1 and d["header"]["number"] == "VP/001/26" and d["status"] == "draft"
    assert admin.get(f"/api/verifiche/{v['id']}").json()["verbale_id"] == nuovo
    # la revisione emessa rende di nuovo «eseguita» la verifica, con il verbale nuovo
    item = _vz(admin, f"inspection?id={nuovo}").json()["item"]
    ant = _vz(admin, "review/preview", {"id": nuovo, "revision": item["revision"]}).json()
    dati = {"id": nuovo, "revision": ant["item"]["revision"], "preview_id": ant["export"]["id"], "approved": True}
    # come in VerbalizzAI: la revisione nasce prima dello stato aggiornato dall'emissione → confronto, o emissione senza aggiornarlo
    assert _vz(admin, "review/issue", dict(dati, update_plant=True)).status_code == 409
    r = _vz(admin, "review/issue", dict(dati, update_plant=False))
    assert r.status_code == 200, r.text
    v = admin.get(f"/api/verifiche/{v['id']}").json()
    assert v["stato"] == "eseguita" and v["verbale_id"] == nuovo


def test_zip_che_non_e_un_backup(admin, app):
    """0.12.8: uno ZIP di verbali Word/PDF caricato al posto del backup completo dà un messaggio chiaro, non un errore imprevisto."""
    import io
    import zipfile

    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        z.writestr("VP_098_23 - verbale.docx", b"PK finto")
        z.writestr("VP_098_23.pdf", b"%PDF-1.4")
    for contenuto, atteso in ((b.getvalue(), "Importa Word storici"), (b"non zip", "non è uno ZIP")):
        r = admin.c.post("/api/verbali/importa", files={"file": ("verbali.zip", contenuto, "application/zip")}, headers=admin.h)
        assert r.status_code == 400 and atteso in r.json()["errore"], r.text
