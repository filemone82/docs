"""C17–C28: aspettative operative, API reali e regressioni della 0.17."""
import io
from datetime import date, datetime

import pytest
from openpyxl import load_workbook
from sqlalchemy import Column, Date, Integer, MetaData, String, Table, create_engine, select
from sqlalchemy.orm import Session

from conftest import nuovo_utente, revisore, ruolo_id
from gestionale.core import griglia as m
from gestionale.core.errori import ErroreUtente
from gestionale.core.pdf import da_word as DA_WORD_REALE
from gestionale.moduli.utenti.accesso import UtenteCorrente
from test_anagrafica import crea_cliente, crea_sede
from test_beni import ok
from test_dm_tecnico import incarico, assegna
from test_finanza import assegna_registra
from test_verifiche import accettato as accettato, verbale_m02


@pytest.mark.parametrize('op,val,atteso', [
    ('contiene','AL',['Alpha','AL_100%','pal']), ('inizia','AL',['Alpha','AL_100%']),
    ('finisce','AL',['pal']), ('uguale','alpha',['Alpha']), ('contiene','_',['AL_100%']),
    ('contiene','100%',['AL_100%']), ('inizia','AL_',['AL_100%']), ('finisce','100%',['AL_100%']),
])
def test_operatori_testo_sql_lista_literalita(op, val, atteso):
    e=create_engine('sqlite://'); md=MetaData(); t=Table('prova',md,Column('nome',String));md.create_all(e)
    righe=[{'nome':x} for x in ['Alpha','AL_100%','pal','nessuno',None]]
    with e.begin() as c:c.execute(t.insert(),righe)
    col=m.Colonna('nome','Nome','testo',t.c.nome);cond=m.interpreta(col,{'operatore':op,'valore':val})
    with e.connect() as c:sql=list(c.execute(select(t.c.nome).where(m.condizione_sql(col,cond))).scalars())
    lista=[x['nome'] for x in righe if m.condizione_lista(col,cond)(x)]
    assert sql==lista==atteso
    assert m.interpreta(col,'AL').tipo=='contiene'  # configurazioni precedenti


@pytest.mark.parametrize('tipo', ['data','dataora'])
def test_intervallo_date_estremi_inclusi_e_ora_italiana(tipo):
    col=m.Colonna('data','Data',tipo)
    cond=m.interpreta(col,{'operatore':'intervallo','da':'2026-03-29','a':'2026-03-29'})
    assert cond.valore==date(2026,3,29) and cond.fino==date(2026,3,30)
    pred=m.condizione_lista(col,cond)
    if tipo=='dataora':  # cambio ora legale, giornata italiana di 23 ore
        assert pred({'data':datetime(2026,3,28,23)})
        assert pred({'data':datetime(2026,3,29,21,59,59)})
        assert not pred({'data':datetime(2026,3,29,22)})
    else:
        assert pred({'data':date(2026,3,29)}) and not pred({'data':date(2026,3,30)})
    assert m.interpreta(col,{'operatore':'intervallo','da':'2026-01-01','a':''}).operatore=='>='
    assert m.interpreta(col,{'operatore':'intervallo','da':'','a':'2026-01-01'}).operatore=='<'
    assert m.interpreta(col,{'operatore':'vuoto'}).tipo=='vuoto'
    with pytest.raises(ErroreUtente):m.interpreta(col,{'operatore':'intervallo','da':'2026-05-03','a':'2026-05-01'})


def test_gruppi_urgenza_intero_risultato_paginazione_ed_excel():
    e=create_engine('sqlite://');md=MetaData();t=Table('scad',md,Column('id',Integer,primary_key=True),Column('cliente',String),Column('data',Date));md.create_all(e)
    with e.begin() as c:c.execute(t.insert(),[
        {'id':i,'cliente':'Zeta','data':date(2026,1,1) if i==1 else date(2027,1,1)} for i in range(1,29)]
        +[{'id':29,'cliente':'Alfa','data':date(2026,2,1)},{'id':30,'cliente':'Vuoto','data':None}])
    g=m.Griglia('prova','Prova', [m.Colonna('id','ID','numero',t.c.id),m.Colonna('cliente','Cliente','testo',t.c.cliente),m.Colonna('data','Data','data',t.c.data)],'prova',da=lambda:t,ordine_predefinito=[('data','asc')],gruppi_per_scadenza='data')
    req=m.Richiesta.da_json(g,{'raggruppa':'cliente','dimensione':25})
    with Session(e) as s:
        uno=m.dati(g,s,None,None,req);req.pagina=2;due=m.dati(g,s,None,None,req)
        assert [r['cliente'] for r in uno['righe']]==['Zeta']*25
        assert [r['cliente'] for r in due['righe']]==['Zeta']*3+['Alfa','Vuoto']
        raw,n=m.esporta(g,s,None,None,req,['cliente','data'])
        assert n==30 and list(load_workbook(io.BytesIO(raw)).active.values)[1][0]=='Zeta'
        # Escludendo la prima data, il minimo viene ricalcolato sui dati filtrati.
        req=m.Richiesta.da_json(g,{'raggruppa':'cliente','filtri':[{'campo':'data','valore':'>01/01/2026'}]})
        assert m.dati(g,s,None,None,req)['righe'][0]['cliente']=='Alfa'


@pytest.mark.parametrize('attivita,codice,ammesso', [('DPR','anagrafica.impianti',True),('DM','anagrafica.impianti',False),('DPR','beni.gestire',False),('DM','beni.gestire',True)])
def test_permessi_gestione_attivita_del_ruolo(attivita,codice,ammesso):
    u=UtenteCorrente(1,'rt','RT','RT',False,{codice},attivita=frozenset({attivita}),per_attivita={attivita:{codice}})
    assert u.puo(codice)==ammesso
    assert (codice in u.per_interfaccia()['permessi'])==ammesso


def test_rt_api_separati_e_ruoli_comuni(admin,app):
    dpr=nuovo_utente(admin,app,'rt_dpr017','responsabile_tecnico');dm=nuovo_utente(admin,app,'rt_dm017','responsabile_tecnico_dm')
    seg=nuovo_utente(admin,app,'seg017','segreteria')
    assert dm.post('/api/impianti',{}).status_code==403
    assert dpr.post('/api/beni',{}).status_code==403
    assert dpr.post('/api/impianti',{}).status_code!=403
    assert dm.post('/api/beni',{}).status_code!=403
    assert seg.post('/api/impianti',{}).status_code!=403 and seg.post('/api/beni',{}).status_code!=403
    # RT DPR + verificatore DM non riceve la gestione DM dal ruolo DPR.
    u=ok(admin.post('/api/utenti',{'username':'misto017','nome':'Misto','ruolo_id':ruolo_id(admin,'responsabile_tecnico'),'altri_ruoli':[ruolo_id(admin,'tecnico_dm')]}))
    from gestionale.moduli.utenti import servizio
    from gestionale.moduli.utenti.modelli import Utente
    with app.state.archivio.lettura() as s:
        x=s.get(Utente,u['id']);a={}
        for r in servizio.ruoli_di(x):
            for att in r.attivita.split(','):a.setdefault(att,set()).update(servizio.permessi_di_ruolo(s,r))
    corrente=UtenteCorrente(u['id'],'misto','Misto','Misto',False,set().union(*a.values()),per_attivita=a)
    assert corrente.puo('anagrafica.impianti') and not corrente.puo('beni.gestire')


def test_contesto_righe_non_eliminabile_filtri_excel_e_menu(admin):
    c=crea_cliente(admin,ambiti=['DPR']);p=ok(admin.post('/api/preventivi',{'cliente_id':c['id']}));q=ok(admin.post('/api/preventivi',{'cliente_id':c['id']}))
    for prev,nome in [(p,'Riga P'),(q,'Riga Q')]:ok(admin.post(f"/api/preventivi/{prev['id']}/voci",{'versione':prev['versione'],'descrizione':nome,'importo':'12,50'}))
    base='/api/griglie/righe_preventivi'
    assert admin.post(base+'/dati',{}).status_code==400
    assert admin.post(base+'/esporta',{'colonne':['riga_sede']}).status_code==400
    req={'contesto':{'preventivo_id':p['id']},'filtri':[],'dimensione':25}
    assert [r['riga_sede'] for r in ok(admin.post(base+'/dati',req))['righe']]==['Riga P']
    raw=admin.post(base+'/esporta',{**req,'colonne':['riga_sede']});assert raw.status_code==200
    assert list(load_workbook(io.BytesIO(raw.content)).active.values)==[('Sede operativa',),('Riga P',)]
    assert ok(admin.post(base+'/dati',{**req,'filtri':[{'campo':'preventivo_id','valore':q['id']}]}))['totale']==0
    assert '/righe-preventivi"' not in admin.get('/preventivi').text
    d=ok(admin.get(base+'/definizione'))
    assert d['viste_predefinite']['']['colonne']==['riga_sede','stato_riga','tipo_verifica','impianto_id','impianto_tipologia','tariffa_applicata','verifica_stato','verificatore','da_fatturare']


def test_salvataggio_scheda_atomico_profile_stale_e_rollback(admin):
    u=ok(admin.get('/api/io')); x=ok(admin.get(f"/api/utenti/{u['id']}"))
    x=ok(admin.put(f"/api/utenti/{x['id']}",{**x,'dati_tecnici':{'nome':'Tecnico','cognome':'Prova'}}))
    assert ok(admin.get(f"/api/dm/tecnici/{x['id']}/profilo"))['nome']=='Tecnico'
    old=x['versione'];prof=ok(admin.put(f"/api/dm/tecnici/{x['id']}/profilo",{'versione':old,'qualifica':'Ing.'}))
    assert admin.put(f"/api/utenti/{x['id']}",x).status_code==409
    x['versione']=prof['versione'];x['nome']='Nome coordinato';x=ok(admin.put(f"/api/utenti/{x['id']}",{**x,'dati_tecnici':{'nome':'Nuovo'}}))
    # Profilo non valido: anche il nome anagrafico deve restare invariato.
    assert admin.put(f"/api/utenti/{x['id']}",{**x,'nome':'Da annullare','dati_tecnici':{'nome':'x'*121}}).status_code==400
    assert ok(admin.get(f"/api/utenti/{x['id']}"))['nome']=='Nome coordinato'


def pronta_dpr(admin, accettato):
    v=assegna_registra(admin,next(x for x in accettato['preventivo']['verifiche'] if x['impianto_id']==accettato['scariche']['id']))
    word=verbale_m02(v['codice_verbale'],'08/10/2026')
    return v,word


def upload(admin,v,word,pdf=None):
    files={'word':('verbale.docx',word)}
    if pdf is not None:files['pdf_file']=('verbale.pdf',pdf)
    return admin.c.post(f"/api/verifiche/{v['id']}/verbale",files=files,data={'versione':v['versione']},headers=admin.h)


@pytest.mark.parametrize('ruolo', ['amministratore','responsabile_tecnico'])
def test_divieto_riesame_proprio_dpr_anche_admin_e_altro_rt(admin,accettato,app,ruolo):
    attore=admin if ruolo=='amministratore' else nuovo_utente(admin,app,'esecutore_rt017',ruolo)
    base=next(x for x in accettato['preventivo']['verifiche'] if x['impianto_id']==accettato['scariche']['id'])
    v=ok(admin.get(f"/api/verifiche/{base['id']}"))
    v=ok(admin.post(f"/api/verifiche/{v['id']}/assegna",{'versione':v['versione'],'verificatore_id':ok(attore.get('/api/io'))['id']}))
    v=ok(attore.post(f"/api/verifiche/{v['id']}/registra",{'versione':v['versione'],'data_esecuzione':'2026-10-08'}))
    word=verbale_m02(v['codice_verbale'],'08/10/2026');v=ok(upload(attore,v,word))
    r=attore.post(f"/api/verifiche/{v['id']}/riesame",{'versione':v['versione'],'esito':'conforme'})
    assert r.status_code==403 and 'tuo verbale' in r.text
    assert ok(admin.get(f"/api/verifiche/{v['id']}"))['stato']=='eseguita'
    assert revisore(admin).post(f"/api/verifiche/{v['id']}/riesame",{'versione':v['versione'],'esito':'conforme'}).status_code==200


@pytest.mark.parametrize('ruolo', ['amministratore','responsabile_tecnico_dm'])
def test_divieto_riesame_dm_blocco_misto_atomico(admin,app,ruolo):
    attore=admin if ruolo=='amministratore' else nuovo_utente(admin,app,'esecutore_dm017',ruolo)
    sede=crea_sede(admin,crea_cliente(admin)['id']);v,a,_=incarico(admin,sede);w,_,_=incarico(admin,sede,a=a,comb='integrita')
    v=assegna(admin,v,ok(attore.get('/api/io'))['id'])
    assert attore.post(f"/api/dm/incarichi/{v['id']}/riesame",{'versione':v['versione'],'esito':'C'}).status_code==403
    r=attore.post('/api/dm/incarichi/riesame-in-blocco',{'esito':'C','incarichi':[{'id':w['id'],'versione':w['versione']},{'id':v['id'],'versione':v['versione']}]})
    assert r.status_code==403
    assert ok(admin.get(f"/api/dm/incarichi/{w['id']}"))['riesami']==[]
    assert revisore(admin,'DM').post(f"/api/dm/incarichi/{v['id']}/riesame",{'versione':v['versione'],'esito':'C'}).status_code==200


@pytest.mark.parametrize('fornito,grande',[(True,False),(True,True),(False,False),(False,True)])
def test_pdf_errori_distinti_e_rollback(admin,accettato,monkeypatch,fornito,grande):
    from gestionale.core import pdf
    v,word=pronta_dpr(admin,accettato)
    raw=b'%PDF-1.4\n'+b'0'*(25*1024*1024) if grande else b'non un pdf'
    monkeypatch.setattr(pdf,'da_word',lambda *a:raw)
    r=upload(admin,v,word,raw if fornito else None)
    assert r.status_code==400
    assert ('allegato' if fornito else 'generato da LibreOffice') in r.text
    assert ('supera il limite' if grande else 'formato PDF valido') in r.text
    dopo=ok(admin.get(f"/api/verifiche/{v['id']}"));assert dopo['stato']=='registrata' and dopo['documenti']==[]


def test_word_numero_errato_blocca_prima_conversione(admin,accettato,monkeypatch):
    from gestionale.core import pdf
    v,_=pronta_dpr(admin,accettato)
    def non_convertire(*a):raise AssertionError('Conversione non necessaria')
    monkeypatch.setattr(pdf,'da_word',non_convertire)
    r=upload(admin,v,verbale_m02('VP/999/26','08/10/2026'))
    assert r.status_code==400 and 'numero scritto' in r.text


@pytest.mark.pdf_vero
def test_word_circa_1_2_mb_conversione_reale(admin,accettato,monkeypatch):
    """Documento sintetico valido: payload incomprimibile in media, senza dati reali."""
    import random
    from zipfile import ZIP_DEFLATED, ZipFile
    v,word=pronta_dpr(admin,accettato);out=io.BytesIO()
    with ZipFile(io.BytesIO(word)) as src,ZipFile(out,'w',ZIP_DEFLATED) as dst:
        for nome in src.namelist():dst.writestr(nome,src.read(nome))
        dst.writestr('word/media/payload-di-prova.bin',random.Random(17).randbytes(1_180_000))
    raw=out.getvalue();assert 1_180_000<len(raw)<1_300_000
    from gestionale.core import pdf
    chiamate=[]
    def reale(*args):
        chiamate.append(True)
        risultato=DA_WORD_REALE(*args)
        from pypdf import PdfReader
        assert len(PdfReader(io.BytesIO(risultato)).pages)>0
        return risultato
    monkeypatch.setattr(pdf,'da_word',reale)
    v=ok(upload(admin,v,raw));assert v['stato']=='eseguita' and chiamate==[True]


def test_pdf_con_intestazione_ma_troncato_rifiutato(admin,accettato):
    v,word=pronta_dpr(admin,accettato)
    r=upload(admin,v,word,b"%PDF-1.7\ntroncato")
    assert r.status_code==400 and 'incompleto' in r.text
    assert ok(admin.get(f"/api/verifiche/{v['id']}"))['stato']=='registrata'
