"""rc8 · B1/B2 (Federico, 14/10/2026): numero del verbale unico nell'anno, assegnato da NEXUS e coerente con la data.

Casi segnalati nel collaudo:
- B1: data di esecuzione scritta 14/10/0226 → anno 226 → di nuovo «VP/001/26» (stesso codice di una verifica del 2026);
- B2: numero cancellato nella bozza → non più riproposto.
Decisioni: anno ammesso solo corrente, precedente o successivo per la data che si registra; un solo progressivo annuo per
VP e VS; cambiando l'anno della data del verbale il numero diventa il primo libero di quell'anno e il vecchio resta un buco
annotato nel registro; nessuna funzione nuova.
"""

from __future__ import annotations

from datetime import date

from test_verbali import _vz
from test_verifiche import accettato  # noqa: F401  (fixture)

ANNO = date.today().year
AA = f"{ANNO % 100:02d}"


def _assegnata(admin, accettato, chiave):  # noqa: F811
    p = accettato["preventivo"]
    ver = {v["impianto_id"]: v for v in p["verifiche"]}[accettato[chiave]["id"]]
    v = admin.get(f"/api/verifiche/{ver['id']}").json()
    io = next(x["id"] for x in admin.get("/api/verifiche/valori").json()["verificatori"] if x["nome"] == admin.get("/api/io").json()["nome"])
    return admin.post(f"/api/verifiche/{v['id']}/assegna", {"verificatore_id": io, "versione": v["versione"]}).json()


def _registra(admin, v, giorno):
    return admin.post(f"/api/verifiche/{v['id']}/registra", {"data_esecuzione": giorno, "versione": v["versione"]})


def _registro(app, azione):
    from sqlalchemy import select
    from gestionale.moduli.registro.modelli import RegistroOperazione
    with app.state.archivio.lettura() as s:
        return list(s.scalars(select(RegistroOperazione.descrizione).where(RegistroOperazione.azione == azione)))


def _bozza(admin, v):
    vid = admin.post(f"/api/verifiche/{v['id']}/verbale/bozza", {}).json()["verbale_id"]
    item = _vz(admin, f"inspection?id={vid}").json()
    item = item.get("item") or item
    return vid, item["data"], item["revision"]


def test_b1_anno_della_data_registrata(admin, accettato):  # noqa: F811
    v = _assegnata(admin, accettato, "scariche")
    r = _registra(admin, v, "14/10/0226")
    assert r.status_code == 400 and "anno 226 non ammesso" in r.json()["errore"], r.text
    r = _registra(admin, v, f"14/10/{ANNO + 2}")
    assert r.status_code == 400 and "non ammesso" in r.json()["errore"]
    r = admin.post(f"/api/verifiche/{v['id']}/programma", {"data_programmata": f"20/10/{ANNO - 2}", "versione": v["versione"]})
    assert r.status_code == 400 and "Data prevista" in r.json()["errore"]
    # anno corrente, precedente e successivo sono ammessi
    r = _registra(admin, v, f"14/10/{ANNO}")
    assert r.status_code == 200 and r.json()["codice_verbale"] == f"VP/001/{AA}", r.text


def test_b1_un_solo_codice_anche_con_dati_registrati_prima_della_rc8(admin, app, accettato):  # noqa: F811
    from gestionale.moduli.verifiche.modelli import Verifica

    a = _registra(admin, _assegnata(admin, accettato, "scariche"), f"15/10/{ANNO}").json()
    b = _registra(admin, _assegnata(admin, accettato, "esplosione"), f"15/10/{ANNO}").json()
    assert (a["codice_verbale"], b["codice_verbale"]) == (f"VP/001/{AA}", f"VP/002/{AA}")
    # come nel collaudo: la seconda verifica registrata con l'anno sbagliato (prima della rc8 era possibile)
    with app.state.archivio.scrittura() as s:
        x = s.get(Verifica, b["id"])
        x.anno, x.numero, x.codice_verbale, x.data_esecuzione = ANNO - 1800, 1, f"VP/001/{AA}", date(ANNO - 1800, 10, 14)
    vid, d, rev = _bozza(admin, b)
    assert d["header"]["number"] == f"VP/001/{AA}"
    # nella bozza si corregge la data: il numero diventa il primo libero dell'anno giusto, mai un codice già usato
    d["header"]["report_date"] = f"14/10/{ANNO}"
    r = _vz(admin, "draft/save", {"id": vid, "data": d, "revision": rev})
    assert r.status_code == 200, r.text
    assert r.json()["item"]["data"]["header"]["number"] == f"VP/002/{AA}"
    x = admin.get(f"/api/verifiche/{b['id']}").json()
    assert x["codice_verbale"] == f"VP/002/{AA}" and x["data_esecuzione"] == f"{ANNO}-10-14"
    assert any(f"VP/001/{AA} → VP/002/{AA}" in r and "resta libero" in r for r in _registro(app, "verifica.numero"))


def test_b2_numero_cancellato_e_riproposto_e_bloccato(admin, accettato):  # noqa: F811
    v = _registra(admin, _assegnata(admin, accettato, "scariche"), f"15/10/{ANNO}").json()
    vid, d, rev = _bozza(admin, v)
    assert d["header"]["number"] == f"VP/001/{AA}" and d["header"]["number_seq"] == "1"
    # il tecnico cancella il numero (come nel collaudo): il salvataggio lo rimette
    d["header"]["number"], d["header"]["number_seq"] = "", ""
    r = _vz(admin, "draft/save", {"id": vid, "data": d, "revision": rev})
    assert r.status_code == 200 and r.json()["item"]["data"]["header"]["number"] == f"VP/001/{AA}", r.text
    # né un numero scritto a mano diverso da quello della verifica
    d, rev = r.json()["item"]["data"], r.json()["item"]["revision"]
    d["header"]["number"], d["header"]["number_seq"] = f"VP/649/{AA}", "649"
    r = _vz(admin, "draft/save", {"id": vid, "data": d, "revision": rev})
    assert r.json()["item"]["data"]["header"]["number"] == f"VP/001/{AA}"
    # anche riaprendo la bozza (bozza salvata da una versione precedente con il numero vuoto)
    assert _bozza(admin, v)[1]["header"]["number"] == f"VP/001/{AA}"


def test_b2_cambio_d_anno_e_tipo(admin, accettato):  # noqa: F811
    a = _registra(admin, _assegnata(admin, accettato, "scariche"), f"15/10/{ANNO}").json()
    vid, d, rev = _bozza(admin, a)
    # stesso anno: il numero non cambia
    d["header"]["report_date"] = f"16/10/{ANNO}"
    r = _vz(admin, "draft/save", {"id": vid, "data": d, "revision": rev})
    d, rev = r.json()["item"]["data"], r.json()["item"]["revision"]
    assert d["header"]["number"] == f"VP/001/{AA}"
    # periodica → straordinaria: cambia solo il prefisso
    d["flags"]["check_type"] = {"periodic": False, "extra": True}
    r = _vz(admin, "draft/save", {"id": vid, "data": d, "revision": rev})
    d, rev = r.json()["item"]["data"], r.json()["item"]["revision"]
    assert d["header"]["number"] == f"VS/001/{AA}"
    assert admin.get(f"/api/verifiche/{a['id']}").json()["codice_verbale"] == f"VS/001/{AA}"
    d["flags"]["check_type"] = {"periodic": True, "extra": False}
    # anno successivo: primo numero libero di quell'anno; il vecchio resta un buco (non riassegnato)
    d["header"]["report_date"] = f"02/01/{ANNO + 1}"
    r = _vz(admin, "draft/save", {"id": vid, "data": d, "revision": rev})
    d, rev = r.json()["item"]["data"], r.json()["item"]["revision"]
    assert d["header"]["number"] == f"VP/001/{(ANNO + 1) % 100:02d}"
    b = _registra(admin, _assegnata(admin, accettato, "esplosione"), f"15/10/{ANNO}").json()
    assert b["codice_verbale"] == f"VP/002/{AA}", "il numero lasciato libero non si riassegna"
    # un anno non ammesso nella bozza non cambia il numero e blocca l'anteprima
    d["header"]["report_date"] = "02/01/0226"
    r = _vz(admin, "draft/save", {"id": vid, "data": d, "revision": rev})
    assert r.status_code == 200 and r.json()["item"]["data"]["header"]["number"] == f"VP/001/{(ANNO + 1) % 100:02d}"
    r = _vz(admin, "review/preview", {"id": vid, "revision": r.json()["item"]["revision"]})
    assert r.status_code == 400 and "non ammesso" in r.json()["errore"], r.text


def test_d3_pagina_del_verbale_dentro_nexus(admin, accettato):  # noqa: F811
    """rc8 (D3): la pagina del verbale ha la barra di NEXUS e la striscia con la verifica di provenienza."""
    html = admin.get("/verbali").text
    assert 'id="barra-nexus"' in html and "/static/css/barra.css" in html and "/static/js/barra.js" in html
    assert 'class="in-nexus"' in html and 'id="nexus-contesto"' in html and "__CSRF_NEXUS__" not in html
    assert '<details class="nav-gruppo" data-gruppo="Verifiche" data-attivo>' in html   # «Verbali» sta in Verifiche
    v = _registra(admin, _assegnata(admin, accettato, "scariche"), f"15/10/{ANNO}").json()
    vid, _d, _rev = _bozza(admin, v)
    x = admin.get(f"/api/verbali/{vid}/verifica").json()["verifica"]
    assert x["id"] == v["id"] and x["codice_verbale"] == f"VP/001/{AA}" and x["url"] == f"/verifiche?apri={v['id']}"
    assert x["stato"] == "registrata" and x["prossimo"] and x["cliente"] == "Verifiche Prova S.r.l."
    assert admin.get("/api/verbali/sconosciuto/verifica").json() == {"verifica": None}


def test_punto3_firma_dpr_nella_scheda_del_tecnico(admin, app):
    """rc8 (punto 3): la firma DPR si carica da NEXUS e finisce nell'archivio dei verbali, dove la cerca il motore."""
    import base64
    from test_verbali import _firma

    io = admin.get("/api/io").json()
    stato = admin.get(f"/api/firme/dpr/{io['id']}").json()
    assert stato["presente"] is False and stato["tecnico_dpr"] is True
    _firma(admin)   # PNG valido, caricato come prima dalla pagina dei verbali
    png = app.state.verbali.signature_image("federico")
    app.state.verbali.remove_signature("federico")
    assert admin.get(f"/api/firme/dpr/{io['id']}").json()["presente"] is False
    r = admin.c.post(f"/api/firme/dpr/{io['id']}", files={"file": ("firma.png", png, "image/png")}, headers=admin.h)
    assert r.status_code == 200, r.text
    assert app.state.verbali.signature_image("federico") == png
    assert admin.get(f"/api/firme/dpr/{io['id']}/immagine").content == png
    r = admin.c.post(f"/api/firme/dpr/{io['id']}", files={"file": ("f.png", base64.b64decode(
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="), "image/png")},
        headers=admin.h)
    assert r.status_code == 400 and "piccola" in r.json()["errore"]
    assert admin.delete(f"/api/firme/dpr/{io['id']}").status_code == 200
    assert app.state.verbali.signature_image("federico") is None
    assert "Firme dei verificatori" in admin.get("/firme").text


def _verifica_terra(admin, tipologia="terra_bt", **extra):
    from conftest import segna_inviato
    from test_anagrafica import crea_cliente, crea_impianto, crea_sede
    c = crea_cliente(admin, ragione_sociale="Terra Prova S.r.l.")
    s = crea_sede(admin, c["id"])
    x = crea_impianto(admin, s["id"], tipologia=tipologia, potenza_kw="250", pod=["IT001E01234567"], **extra)
    p = segna_inviato(admin, admin.post("/api/preventivi", {"impianti": [x["id"]]}).json())
    p = admin.post(f"/api/preventivi/{p['id']}/righe/stato", {"righe": [r["id"] for r in p["righe"]], "stato": "accettata",
                                                             "evidenza_accettazione": "Email di conferma", "versione": p["versione"]}).json()
    assert admin.post(f"/api/preventivi/{p['id']}/riesame", {"esito": "conforme", "requisiti_chiari": True, "competenza_strumenti": True,
                                                            "imparzialita": True, "tempi": True}).status_code == 200
    p = admin.get(f"/api/preventivi/{p['id']}").json()
    v = admin.get(f"/api/verifiche/{p['verifiche'][0]['id']}").json()
    io = next(y["id"] for y in admin.get("/api/verifiche/valori").json()["verificatori"] if y["nome"] == admin.get("/api/io").json()["nome"])
    v = admin.post(f"/api/verifiche/{v['id']}/assegna", {"verificatore_id": io, "versione": v["versione"]}).json()
    return x, _registra(admin, v, f"15/10/{ANNO}").json()


def test_punto4_la_bozza_prende_gli_attributi_dall_impianto_nexus(admin, app):
    x, v = _verifica_terra(admin)
    # la potenza dell'impianto NEXUS (quella della tariffa) cambia prima della bozza: la bozza nuova la riprende
    dati = admin.get(f"/api/impianti/{x['id']}").json()
    r = admin.put(f"/api/impianti/{x['id']}", {**dati, "potenza_kw": "300", "pod": ["IT001E01234567"]})
    assert r.status_code == 200, r.text
    _vid, d, _rev = _bozza(admin, v)
    assert d["module"] == "M01" and d["plant"]["power"] == "300 kW" and d["plant"]["pod"] == "IT001E01234567"


def test_punto4_cabine_sottostazioni_e_pod_tornano_all_impianto(admin, app):
    from gestionale.moduli.anagrafica.modelli import Impianto
    from gestionale.moduli.verbali import scheda

    x = _verifica_terra(admin, "terra_at", cabine_mt_bt="1", sottostazioni_at_mt="0")[0]
    with app.state.archivio.scrittura() as s:
        imp = s.get(Impianto, x["id"])
        imp.pod.clear()
        s.flush()
        assert scheda._altri_attributi(s, imp, {"plant": {"cabins": "3", "stations": "1", "pod": "it001e 01234568"}}) is True
        assert (imp.cabine_mt_bt, imp.sottostazioni_at_mt, [p.pod for p in imp.pod]) == (3, 1, ["IT001E01234568"])
        # un POD già presente non si sostituisce; valori non numerici si ignorano
        assert scheda._altri_attributi(s, imp, {"plant": {"cabins": "tre", "pod": "IT001E99999999"}}) is False
        assert [p.pod for p in imp.pod] == ["IT001E01234568"]


def test_punto4_non_tocca_bozze_aperte_ne_storico(admin, app):
    """Vincolo di Federico (13:48): nessuna alterazione della generazione dei verbali e dello storico. Gli attributi NEXUS
    entrano solo nella bozza nuova: una bozza già aperta (con le modifiche del tecnico) e i verbali dell'archivio restano."""
    x, v = _verifica_terra(admin)
    vid, d, rev = _bozza(admin, v)
    assert d["plant"]["power"] == "250 kW"
    d["plant"]["power"] = "260 kW"   # il tecnico corregge in verifica
    assert _vz(admin, "draft/save", {"id": vid, "data": d, "revision": rev}).status_code == 200
    prima = {k: dict(o["data"]) for k, o in ((o["id"], o) for o in app.state.verbali.all("inspection"))}
    dati = admin.get(f"/api/impianti/{x['id']}").json()
    assert admin.put(f"/api/impianti/{x['id']}", {**dati, "potenza_kw": "400", "pod": ["IT001E01234567"]}).status_code == 200
    assert _bozza(admin, v)[1]["plant"]["power"] == "260 kW"          # riaprendo resta quella del tecnico
    dopo = {o["id"]: dict(o["data"]) for o in app.state.verbali.all("inspection")}
    assert dopo == prima                                               # nessun verbale dell'archivio è cambiato
