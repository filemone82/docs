"""Versione 0.2.0: anagrafica (clienti, sedi, impianti), regole automatiche, griglie collegate (D43), permessi."""

from __future__ import annotations

from datetime import date

import pytest
from conftest import nuovo_utente

from gestionale.core import validazioni as v
from gestionale.core.errori import ErroreUtente
from gestionale.moduli.anagrafica.servizio import scadenza

PIVA = "01234567897"   # partita IVA formalmente valida (cifra di controllo giusta)
PIVA_2 = "12345678903"


# ---------------------------------------------------------------- controlli di formato


def test_partita_iva_e_codice_fiscale():
    assert v.partita_iva_valida(PIVA) and v.partita_iva_valida(PIVA_2)
    assert not v.partita_iva_valida("01234567890")
    assert v.normalizza_partita_iva("IT 0123 4567 897") == PIVA
    assert v.normalizza_partita_iva(1234567897) == PIVA  # zero iniziale perso da Excel
    with pytest.raises(ErroreUtente):
        v.normalizza_partita_iva("01234567890")
    assert v.codice_fiscale_valido("RSSMRA85T10A562S")
    assert not v.codice_fiscale_valido("RSSMRA85T10A562X")
    assert v.codice_fiscale_valido(PIVA)  # società: CF numerico = P.IVA


def test_iban_pod_sdi_email_numeri():
    assert v.normalizza_iban("IT60 X054 2811 1010 0000 0123 456") == "IT60X0542811101000000123456"
    with pytest.raises(ErroreUtente):
        v.normalizza_iban("IT61X0542811101000000123456")
    assert v.normalizza_pod("it001e12345678") == "IT001E12345678"
    with pytest.raises(ErroreUtente):
        v.normalizza_pod("12345678")
    assert v.estrai_pod("IT001E01234567 – N. cliente: 123456789") == (["IT001E01234567"], "N. cliente: 123456789")
    assert v.estrai_pod("IT001E01234567 - IT001E07654321")[0] == ["IT001E01234567", "IT001E07654321"]
    assert v.normalizza_sdi("0") == "" and v.normalizza_sdi("usal8pv") == "USAL8PV"
    assert v.normalizza_email("a@b.it, c@d.it") == "a@b.it; c@d.it"
    with pytest.raises(ErroreUtente):
        v.normalizza_email("non-una-email")
    assert v.numero_italiano("1.000") == 1000 and v.numero_italiano("1.234,5") == 1234.5 and v.numero_italiano("12.5") == 12.5
    assert v.normalizza_telefono(115627867) == "0115627867" and v.normalizza_telefono(3497767486) == "3497767486"


def test_regola_della_scadenza():
    """Come il gestionale attuale: ultima verifica + periodicità − 1 giorno; 29/2 gestito."""
    assert scadenza(date(2024, 12, 10), 2) == date(2026, 12, 9)
    assert scadenza(date(2026, 9, 22), 5) == date(2031, 9, 21)
    assert scadenza(date(2024, 2, 29), 2) == date(2026, 2, 27)


# ---------------------------------------------------------------- aiuti


def crea_cliente(s, **extra):
    dati = {"ragione_sociale": "Rossi Impianti S.r.l.", "tipo": "privato", "partita_iva": PIVA, "codice_fiscale": PIVA,
            "indirizzo": "Via Roma 1", "comune_istat": "001272", "cap": "10121", "email_verbali": "verbali@rossi.it", **extra}
    r = s.post("/api/clienti", dati)
    assert r.status_code == 200, r.text
    return r.json()


def crea_sede(s, cliente_id, **extra):
    r = s.post("/api/sedi", {"cliente_id": cliente_id, "denominazione": "Stabilimento di Volpiano", "indirizzo": "Via Po 2",
                             "comune_istat": "001314", **extra})
    assert r.status_code == 200, r.text
    return r.json()


def crea_impianto(s, sede_id, **extra):
    dati = {"sede_id": sede_id, "tipologia": "terra_bt", "potenza_kw": "30", "periodicita_anni": 2, "pod": ["IT001E01234567"], **extra}
    r = s.post("/api/impianti", dati)
    assert r.status_code == 200, r.text
    return r.json()


# ---------------------------------------------------------------- clienti, sedi, impianti


def test_cliente_controlli_comune_istat_e_registro(admin):
    r = admin.post("/api/clienti", {"ragione_sociale": "X", "partita_iva": "01234567890"})
    assert r.status_code == 400 and "Partita IVA" in r.json()["errore"]
    assert admin.post("/api/clienti", {"ragione_sociale": "X"}).status_code == 400  # né P.IVA né CF
    c = crea_cliente(admin)
    assert (c["comune"], c["provincia"], c["regione"], c["cap"]) == ("Torino", "TO", "Piemonte", "10121")
    assert c["sconti_ammessi"] is False  # D38: sconti bloccati di default
    storico = admin.get(f"/api/storico/cliente/{c['id']}").json()
    assert storico[0]["azione"] == "cliente.crea"
    r = admin.put(f"/api/clienti/{c['id']}", {**c, "email_fatture": "fatture@rossi.it"})
    assert r.status_code == 200 and r.json()["versione"] == 2
    assert admin.put(f"/api/clienti/{c['id']}", {**c, "note": "vecchia versione"}).status_code == 409  # modifica concorrente
    modifiche = admin.get(f"/api/storico/cliente/{c['id']}").json()[0]["dettagli"]["modifiche"]
    assert modifiche == {"email_fatture": ["", "fatture@rossi.it"]}


def test_pa_e_sconti(admin):
    c = crea_cliente(admin, tipo="pa", codice_sdi="UFABCD", ragione_sociale="Comune di Prova")
    r = admin.post(f"/api/clienti/{c['id']}/sconti", {"ammessi": True, "motivo": "", "versione": c["versione"]})
    assert r.status_code == 400  # serve il motivo
    r = admin.post(f"/api/clienti/{c['id']}/sconti", {"ammessi": True, "motivo": "pubblica amministrazione", "versione": c["versione"]})
    assert r.status_code == 200 and r.json()["sconti_ammessi"]
    assert admin.post("/api/clienti", {"ragione_sociale": "Ente", "tipo": "pa", "partita_iva": PIVA_2, "codice_sdi": "ABCDEFG"}).status_code == 400


def test_catena_e_cancellazioni_protette(admin):
    c = crea_cliente(admin)
    s = crea_sede(admin, c["id"])
    i = crea_impianto(admin, s["id"])
    assert admin.delete(f"/api/clienti/{c['id']}").status_code == 400  # ha sedi
    assert admin.delete(f"/api/sedi/{s['id']}").status_code == 400     # ha impianti
    assert admin.delete(f"/api/impianti/{i['id']}").status_code == 200  # nessuna verifica registrata
    assert admin.delete(f"/api/sedi/{s['id']}").status_code == 200
    assert admin.delete(f"/api/clienti/{c['id']}").status_code == 200
    azioni = [x["azione"] for x in admin.get(f"/api/storico/cliente/{c['id']}").json()]
    assert azioni[0] == "cliente.elimina"


def test_regole_impianto(admin):
    s = crea_sede(admin, crea_cliente(admin)["id"])
    base = {"sede_id": s["id"], "periodicita_anni": 2}
    assert admin.post("/api/impianti", {**base, "tipologia": "terra_bt"}).status_code == 400            # manca la potenza
    assert admin.post("/api/impianti", {**base, "tipologia": "terra_bt", "potenza_kw": 20, "cabine_mt_bt": 1}).status_code == 400
    assert admin.post("/api/impianti", {**base, "tipologia": "terra_bt", "potenza_kw": 20, "periodicita_anni": 3}).status_code == 400
    assert admin.post("/api/impianti", {**base, "tipologia": "terra_bt", "potenza_kw": 20, "pod": ["IT001E1", ""]}).status_code == 400
    assert admin.post("/api/impianti", {**base, "tipologia": "scariche", "gabbia": True}).status_code == 400  # manca la fascia
    assert admin.post("/api/impianti", {**base, "tipologia": "esplosione", "polveri": True, "zone": ["1"]}).status_code == 400
    at = crea_impianto(admin, s["id"], tipologia="terra_at", potenza_kw="1.200", cabine_mt_bt=2,
                       pod=["IT001E01234567", "it001e07654321"], ultima_verifica_data="2024-12-10")
    assert at["potenza_kw"] == 1200 and at["pod"] == ["IT001E01234567", "IT001E07654321"]
    assert at["prossima_verifica"] == "2026-12-09" and at["prossima_calcolata"]
    manuale = crea_impianto(admin, s["id"], prossima_verifica="2027-03-31")
    assert manuale["prossima_verifica"] == "2027-03-31" and not manuale["prossima_calcolata"]
    sc = crea_impianto(admin, s["id"], tipologia="scariche", asta=True, numero_aste=3, gabbia=True, gabbia_fascia="da_101_a_350",
                       potenza_kw="99", pod=["IT001E01234567"])
    assert sc["potenza_kw"] is None and sc["pod"] == []  # i campi della messa a terra non valgono per le scariche
    es = crea_impianto(admin, s["id"], tipologia="esplosione", gas=True, polveri=True, zone=["22", "1", "0"])
    assert es["zone"] == "0, 1, 22"


def test_dismesso_esce_dallo_scadenziario(admin):
    s = crea_sede(admin, crea_cliente(admin)["id"])
    i = crea_impianto(admin, s["id"], ultima_verifica_data="2020-01-15")
    assert admin.post("/api/griglie/scadenze/dati", {}).json()["totale"] == 1
    riga = admin.post("/api/griglie/scadenze/dati", {}).json()["righe"][0]
    assert riga["stato_scadenza"] == "Scaduta" and riga["giorni"] < 0 and riga["tariffa"] == 30000  # 30 kW → scaglione «fino a 50» = 300 €
    assert admin.post(f"/api/impianti/{i['id']}/dismesso", {"dismesso": True, "motivo": "", "versione": i["versione"]}).status_code == 400
    assert admin.post(f"/api/impianti/{i['id']}/dismesso", {"dismesso": True, "motivo": "smantellato", "versione": i["versione"]}).status_code == 200
    assert admin.post("/api/griglie/scadenze/dati", {}).json()["totale"] == 0
    assert admin.post("/api/griglie/impianti/dati", {}).json()["totale"] == 1  # resta in archivio


def test_griglie_con_le_colonne_collegate(admin):
    """D43: in Sedi i dati del cliente, in Impianti quelli di sede e cliente, filtrabili ed esportabili."""
    c1 = crea_cliente(admin)
    c2 = crea_cliente(admin, ragione_sociale="Comune di Biella", tipo="pa", partita_iva=PIVA_2, codice_fiscale=PIVA_2)
    for c in (c1, c2):
        crea_impianto(admin, crea_sede(admin, c["id"])["id"])
    r = admin.post("/api/griglie/sedi/dati", {"filtri": [{"campo": "cliente_tipo", "valore": "Pubblica amministrazione"}]}).json()
    assert r["totale"] == 1 and r["righe"][0]["cliente_ragione_sociale"] == "Comune di Biella"
    r = admin.post("/api/griglie/impianti/dati", {"filtri": [{"campo": "cliente_partita_iva", "valore": PIVA}]}).json()
    assert r["totale"] == 1 and r["righe"][0]["sede_comune"] == "Volpiano" and r["righe"][0]["pod"] == "IT001E01234567"
    r = admin.post("/api/griglie/clienti/dati", {"ordinamenti": [{"campo": "ragione_sociale", "direzione": "asc"}]}).json()
    assert [x["n_impianti"] for x in r["righe"]] == [1, 1]
    x = admin.post("/api/griglie/impianti/esporta", {"colonne": ["id", "tariffa", "cliente_ragione_sociale"]})
    assert x.status_code == 200
    from io import BytesIO

    from openpyxl import load_workbook
    righe = list(load_workbook(BytesIO(x.content)).active.iter_rows(values_only=True))
    assert righe[0] == ("N. impianto", "Tariffa proposta", "Cliente · Ragione sociale") and righe[1][1] == 300


def test_permessi_anagrafica(admin, app):
    c = crea_cliente(admin)
    tecnico = nuovo_utente(admin, app, "tecnico1", "tecnico")
    # Il tecnico di partenza vede l'anagrafica ma non la modifica
    assert tecnico.get(f"/api/clienti/{c['id']}").status_code == 200
    assert tecnico.put(f"/api/clienti/{c['id']}", {**c, "note": "prova"}).status_code == 403
    assert tecnico.post("/api/griglie/scadenze/dati", {}).status_code == 403  # lo scadenziario no
    segreteria = nuovo_utente(admin, app, "segreteria1", "segreteria")
    assert segreteria.get(f"/api/clienti/{c['id']}").status_code == 200
    assert segreteria.post(f"/api/clienti/{c['id']}/sconti", {"ammessi": True, "motivo": "PA"}).status_code == 403  # solo admin
    assert segreteria.post("/api/importazione/conferma", {"codice": "x"}).status_code == 403
    assert segreteria.post("/api/tariffario/voci", {"codice": "X"}).status_code == 403
    assert segreteria.post("/api/griglie/tariffario/dati", {}).status_code == 200


def test_tutte_le_griglie_ogni_colonna(admin):
    """Ogni griglia, ordinata e filtrata («vuoto») su ogni colonna, risponde senza errori.
    Protegge anche da un difetto di SQLite 3.45 con le unioni annidate (si usano unioni piatte)."""
    from gestionale.core.griglia import REGISTRO_GRIGLIE

    c = crea_cliente(admin, ambiti=["DPR", "DM"])
    sede = crea_sede(admin, c["id"])
    crea_impianto(admin, sede["id"], ultima_verifica_data="2025-01-10")
    p_dpr = admin.post("/api/preventivi", {"cliente_id":c["id"]}).json()
    p_dm = admin.post("/api/preventivi", {"ambito":"DM", "sede_id":sede["id"]}).json()
    for codice, g in REGISTRO_GRIGLIE.items():
        if g.righe is not None:
            continue
        for col in g.colonne:
            corpo = {"ricerca": "a"}
            if g.contesto_campo:
                corpo["contesto"] = {"preventivo_id": (p_dm if codice.endswith("_dm") else p_dpr)["id"]}
            if col.ordinabile:
                corpo["ordinamenti"] = [{"campo": col.campo, "direzione": "desc"}]
            if col.filtrabile:
                corpo["filtri"] = [{"campo": col.campo, "valore": "vuoto"}]
            r = admin.post(f"/api/griglie/{codice}/dati", corpo)
            assert r.status_code == 200, (codice, col.campo, r.text)


def test_codice_fiscale_obbligatorio_e_comune_riconosciuto(admin):
    """D48: CF sempre obbligatorio, P.IVA facoltativa. D49: comune scritto a mano riconosciuto dall'elenco ISTAT."""
    r = admin.post("/api/clienti", {"ragione_sociale": "Solo P.IVA", "partita_iva": PIVA})
    assert r.status_code == 400 and "codice fiscale" in r.json()["errore"]
    c = admin.post("/api/clienti", {"ragione_sociale": "Mario Rossi", "tipo": "persona_fisica", "codice_fiscale": "RSSMRA85T10A562S",
                                    "comune": "volpiano"}).json()
    assert c["partita_iva"] == "" and (c["comune"], c["provincia"], c["regione"], c["cap"], c["comune_istat"]) == ("Volpiano", "TO", "Piemonte", "10088", "001314")
    estero = admin.post("/api/clienti", {"ragione_sociale": "Ditta estera", "nazione": "FR", "codice_fiscale": "FR123", "comune": "Lyon",
                                         "provincia": "", "regione": "Auvergne-Rhône-Alpes"}).json()
    assert estero["comune_istat"] is None and estero["regione"] == "Auvergne-Rhône-Alpes"


def test_menu_comuni(admin):
    nuovo = {"codice_istat": "999001", "nome": "Comune di Prova", "sigla": "TO", "provincia": "Torino", "regione": "Piemonte", "cap": "10999, 10998"}
    assert admin.post("/api/comuni", nuovo).json()["cap"] == ["10999", "10998"]
    assert admin.post("/api/comuni", nuovo).status_code == 400  # codice già presente
    assert admin.get("/api/comuni?q=comune di prova").json()[0]["codice_istat"] == "999001"
    assert admin.put("/api/comuni/999001", {**nuovo, "attivo": False}).status_code == 200
    assert admin.get("/api/comuni?q=comune di prova").json() == []  # soppresso: non più proposto
    assert admin.get("/api/storico/comune/999001").json()[0]["azione"] == "comune.modifica"
    assert admin.post("/api/griglie/comuni/dati", {"filtri": [{"campo": "sigla", "valore": "TO"}]}).json()["totale"] > 300


def test_griglie_senza_colonne_doppie(app):
    from gestionale.core.griglia import REGISTRO_GRIGLIE

    for codice, g in REGISTRO_GRIGLIE.items():
        campi = [c.campo for c in g.colonne]
        assert len(campi) == len(set(campi)), (codice, {x for x in campi if campi.count(x) > 1})
