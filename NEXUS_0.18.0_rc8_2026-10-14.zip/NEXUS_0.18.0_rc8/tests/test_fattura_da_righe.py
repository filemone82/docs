"""0.12.8 · N6 «Da fatturare» nelle verifiche e nelle righe; N7/R125 «Fattura le selezionate…» dalle righe, come in Garda."""

from __future__ import annotations

from conftest import revisore

from test_finanza import assegna_registra, economia, emetti, ok  # noqa: F401
from test_verifiche import accettato, verbale_m02  # noqa: F401


def _righe(admin, codice, preventivo_id=None, **filtri):
    corpo = {"filtri": [{"campo": k, "valore": v} for k, v in filtri.items()], "dimensione": 200}
    if codice.startswith("righe_preventivi"):
        assert preventivo_id is not None, "Il test deve indicare il singolo preventivo"
        corpo["contesto"] = {"preventivo_id": preventivo_id}
    return ok(admin.post(f"/api/griglie/{codice}/dati", corpo))["righe"]


def _eseguita_e_riesaminata(admin, accettato):  # noqa: F811
    v = assegna_registra(admin, next(x for x in accettato["preventivo"]["verifiche"] if x["impianto_id"] == accettato["scariche"]["id"]))
    v = ok(admin.c.post(f"/api/verifiche/{v['id']}/verbale", files={"word": ("v.docx", verbale_m02(v["codice_verbale"], "08/10/2026"))},
                        data={"versione": v["versione"]}, headers=admin.h))
    assert not [x for x in _righe(admin, "verifiche", da_fatturare="Sì") if x["id"] == v["id"]]   # non ancora riesaminata
    return ok(revisore(admin).post(f"/api/verifiche/{v['id']}/riesame", {"versione": v["versione"], "esito": "conforme"}))


def test_da_fatturare_e_fattura_dalle_righe(admin, economia, accettato):  # noqa: F811
    v = _eseguita_e_riesaminata(admin, accettato)
    assert [x["id"] for x in _righe(admin, "verifiche", da_fatturare="Sì")] == [v["id"]]
    pid = accettato["preventivo"]["id"]
    righe = _righe(admin, "righe_preventivi", preventivo_id=accettato["preventivo"]["id"], da_fatturare="Sì")
    ids = {r["id"] for r in righe}
    p = ok(admin.get(f"/api/preventivi/{pid}"))
    esplosione = next(r for r in p["righe"] if r["impianto_id"] == accettato["esplosione"]["id"])
    voci = [r for r in p["righe"] if r["impianto_id"] is None]
    assert v["riga_id"] in ids and esplosione["id"] not in ids          # verifica non conclusa
    assert {r["id"] for r in voci} <= ids                              # trasferta e «a corpo» insieme alla verifica fatturabile
    # una riga non pronta blocca tutto
    r = admin.post("/api/fatture/da-righe", {"righe": [v["riga_id"], esplosione["id"]]})
    assert r.status_code == 400 and "non sono da fatturare" in r.json()["errore"]
    f = ok(admin.post("/api/fatture/da-righe", {"righe": sorted(ids), "data": "2026-10-11"}))
    assert f["stato"] == "bozza" and len(f["righe"]) == len(ids) and f["cliente_id"] == p["cliente_id"]
    assert all(x["riga_preventivo_id"] in ids for x in f["righe"])
    assert _righe(admin, "righe_preventivi", preventivo_id=accettato["preventivo"]["id"], da_fatturare="Sì") == [] and _righe(admin, "verifiche", da_fatturare="Sì") == []
    # la bozza ora è proposta per aggiungere altre righe dello stesso intestatario
    assert [b["id"] for b in ok(admin.get(f"/api/bozze-fatture?cliente_id={p['cliente_id']}&ambito=DPR"))] == [f["id"]]
    # emessa e poi stornata per intero: la verifica torna da fatturare
    f = emetti(admin, f)
    nc = ok(admin.post("/api/fatture", {"societa_id": economia["societa"]["id"], "cliente_id": f["cliente_id"], "data": "2026-10-12",
                                        "tipo": "TD04", "originale_id": f["id"]}))
    for x in f["righe"]:
        nc = ok(admin.post(f"/api/fatture/{nc['id']}/righe", {"versione": nc["versione"], "origine_credito_id": x["id"],
                                                              "descrizione": x["descrizione"], "prezzo": f"{x['importo'] / 100:.2f}",
                                                              "quantita": "1", "aliquota": x["aliquota"] / 100, "natura": x["natura"],
                                                              "esigibilita": x["esigibilita"]}))
    emetti(admin, nc)
    assert [x["id"] for x in _righe(admin, "verifiche", da_fatturare="Sì")] == [v["id"]]
