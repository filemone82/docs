import os
import time
from uuid import uuid4
import pytest
from sqlalchemy.engine import make_url
from gestionale.core.config import Config


@pytest.fixture(autouse=True)
def richiede_server_postgresql():
    if not os.environ.get('NEXUS_TEST_POSTGRESQL_ADMIN_URL'):
        pytest.skip('Serve PostgreSQL nativo di collaudo: NEXUS_TEST_POSTGRESQL_ADMIN_URL')


@pytest.fixture
def cfg(tmp_path):
    import psycopg
    from psycopg import sql
    url = make_url(os.environ['NEXUS_TEST_POSTGRESQL_ADMIN_URL'])
    # Si creano e si eliminano esclusivamente database nuovi con UUID scelto qui.
    nome = 'nexustest_' + uuid4().hex
    nativa = url.set(drivername='postgresql').render_as_string(hide_password=False)
    with psycopg.connect(nativa, autocommit=True) as c:
        c.execute(sql.SQL('CREATE DATABASE {}').format(sql.Identifier(nome)))
    try:
        yield Config(cartella_dati=tmp_path/'dati', database_url=url.set(database=nome, drivername='postgresql+psycopg')
                     .render_as_string(hide_password=False), iterazioni_password=1000,
                     backup_automatico=False, apri_browser=False)
    finally:
        with psycopg.connect(nativa, autocommit=True) as c:
            # Solo i database creati da questa fixture. Non richiede superuser/pg_signal_backend:
            # FORCE tenterebbe di interrompere anche connessioni di manutenzione postgres.
            for tentativo in range(25):
                try:
                    c.execute(sql.SQL('DROP DATABASE {}').format(sql.Identifier(nome)))
                    break
                except psycopg.errors.ObjectInUse:
                    if tentativo == 24:
                        raise
                    time.sleep(.2)


@pytest.fixture
def app(cfg):
    from gestionale.app import crea_app
    applicazione = crea_app(cfg)
    try:
        yield applicazione
    finally:
        # Anche i test senza TestClient devono restituire tutte le connessioni.
        applicazione.state.archivio.chiudi()
