"""Gli stessi flussi DPR via API, con verbali e gestionale nello stesso PG."""

import pytest

from test_verifiche import accettato  # noqa: F401 - fixture dei test riutilizzati
from test_verbali import (
    test_bozza_emissione_e_verifica_eseguita,
    test_riallineamento_ritrova_emissione_anche_senza_collegamento_nella_verifica,
    test_riesame_non_conforme_si_corregge_con_una_revisione,
)


@pytest.fixture
def app(cfg):
    from gestionale.app import crea_app

    cfg.verbali_postgresql = True
    applicazione = crea_app(cfg)
    try:
        yield applicazione
    finally:
        applicazione.state.archivio.chiudi()
