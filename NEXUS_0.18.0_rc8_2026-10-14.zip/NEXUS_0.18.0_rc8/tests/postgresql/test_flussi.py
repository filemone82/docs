"""Gli stessi test funzionali, con fixture PostgreSQL e database nuovo per caso.

Nessuna copia divergente delle regole del collaudo SQLite. Sono esclusi qui i
test che ricostruiscono intenzionalmente vecchi schemi SQLite.
"""
from test_collaudo_017 import (
    test_operatori_testo_sql_lista_literalita,
    test_intervallo_date_estremi_inclusi_e_ora_italiana,
    test_gruppi_urgenza_intero_risultato_paginazione_ed_excel,
    test_rt_api_separati_e_ruoli_comuni,
    test_contesto_righe_non_eliminabile_filtri_excel_e_menu,
    test_salvataggio_scheda_atomico_profile_stale_e_rollback,
    test_divieto_riesame_proprio_dpr_anche_admin_e_altro_rt,
    test_divieto_riesame_dm_blocco_misto_atomico,
)
from test_verifiche import accettato, test_percorso_completo_della_verifica, test_da_scadenze_con_numero_e_revisione
from test_dm_tecnico import (
    sede_dm_tecnica,
    test_assegnazione_programmazione_non_obbligatoria_e_registrazione,
    test_versioni_conflitto_e_assegnazione_in_blocco_atomica,
    test_sc_sp_contatore_condiviso_gvr_distinto_anno_e_numeri_non_riusati,
    test_salva_e_registra_e_una_sola_transazione_anche_per_il_master,
)
from test_finanza import (
    economia,
    test_xml_fotografia_numerazione_ed_emissione_idempotente,
    test_incasso_unico_due_fatture_storno_e_rollback,
    test_note_credito_parziali_senza_incassi_fittizi,
    test_cliente_mutato_non_riscrive_preventivo_emesso,
)
from test_clienti_origini import test_corrispondenze_registrate_dalle_importazioni, test_fusione_solo_se_certa_e_unione_da_confermare
