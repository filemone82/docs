"""Collaudo su PostgreSQL nativo: migrazione, documenti, cronologia e rollback."""
from hashlib import sha256

import pytest

from gestionale.moduli.verbali.importa_postgresql import importa
from gestionale.moduli.verbali.attivazione import CHIAVE, verifica_archivio_precedente
from gestionale.moduli.verbali.postgresql import ArchivioPostgresql
from gestionale.terzi.verbalizzai.storage import Archive, Conflict


def test_importazione_verbali_e_attivita_successiva(cfg, tmp_path):
    # La fixture crea e distrugge SOLO un database temporaneo nexustest_<uuid>.
    from gestionale.core import migrazioni
    from gestionale.core.db import Archivio
    nexus = Archivio(cfg)
    try:
        migrazioni.aggiorna(nexus.motore)
    finally:
        nexus.chiudi()
    src = Archive(tmp_path / "standalone")
    documento = b"Word sorgente di collaudo"

    def crea(c):
        pid = src._put(c, "plant", {"client_name": "Alfa", "address": "Via A", "sede_id": 42,
                                    "profiles": {}}, action="plant_new")
        doc_sha = src.add_document(c, documento, "originale.docx")
        iid = src._put(c, "inspection", {"plant_id": pid, "header": {"number": "V/1/26"},
                                         "samples": [], "status": "draft", "source_sha": doc_sha}, action="save")
        return pid, iid, doc_sha
    pid, iid, doc_sha = src.mutate(crea)
    sorgente = tmp_path / "archivio.adbackup.zip"
    src.export_backup(sorgente, include_documents=True)
    conferma = importa(sorgente, cfg)
    assert conferma["oggetti"] == 2 and conferma["documenti"] == 1
    assert conferma["archivio_id"] == src._snapshot()["meta"]["archive_id"]
    pg = ArchivioPostgresql(cfg.cartella_dati / "verbali", cfg.database_url)
    with pg.connect() as c:
        assert c.execute("SELECT value FROM meta WHERE key=?", (CHIAVE,)).fetchone()
    verifica_archivio_precedente(pg, src.path)
    assert pg.get(iid)["data"]["plant_id"] == pid
    assert pg.document(doc_sha) == ("originale.docx", documento)
    assert pg.where("inspection", "plant_id", pid)[0]["id"] == iid
    assert pg.where("plant", "sede_id", 42)[0]["id"] == pid
    assert pg.asset_counts() == {}
    assert pg.light_inspections()[0]["number"] == "V/1/26"
    assert pg.template_usage() == {}
    with pytest.raises(ValueError, match="già dati"):
        importa(sorgente, cfg)

    rev = pg.get(iid)["revision"]
    pg.mutate(lambda c: pg._put(c, "inspection", dict(pg.get(iid)["data"],
        status="issued"), iid, rev, action="issue"))
    with pytest.raises(Conflict):
        pg.mutate(lambda c: pg._put(c, "inspection", {"plant_id": pid}, iid, rev))
    assert pg.get(iid)["data"]["status"] == "issued"
    assert pg.document(doc_sha)[1] == documento
    dest = tmp_path / "postgre.adbackup.zip"
    pg.export_backup(dest, include_documents=True)
    checked, loader, _ = Archive.verify_backup(dest)
    assert checked["meta"]["archive_id"] == conferma["archivio_id"]
    assert sha256(loader(doc_sha)).hexdigest() == doc_sha


def test_importazione_rifiuta_una_copia_senza_documenti(cfg, tmp_path):
    src = Archive(tmp_path / "standalone")
    p = tmp_path / "solo_dati.adbackup.zip"
    src.export_backup(p, include_documents=False)
    with pytest.raises(ValueError):
        importa(p, cfg)


def test_app_dpr_senza_secondo_database(cfg):
    from gestionale.app import crea_app
    cfg.verbali_postgresql = True
    app = crea_app(cfg)
    try:
        assert isinstance(app.state.verbali, ArchivioPostgresql)
        assert app.state.verbali.path is None
        assert not (cfg.cartella_dati / "verbali" / "archivio.sqlite").exists()
        assert app.state.verbali.all("template")  # inizializzazione normale dei modelli DPR
    finally:
        app.state.archivio.chiudi()


def test_attivazione_blocca_modelli_senza_importazione_e_archivio_diverso(cfg):
    from gestionale.app import crea_app
    from gestionale.terzi.verbalizzai.storage import Archive

    cfg.verbali_postgresql = True
    app = crea_app(cfg)  # Carica i modelli iniziali in PG, senza importazione.
    app.state.archivio.chiudi()
    Archive(cfg.cartella_dati / "verbali")
    with pytest.raises(RuntimeError, match="manca la conferma"):
        crea_app(cfg)


def test_attivazione_dopo_importazione_blocca_scritture_sqlite_successive(cfg, tmp_path):
    from gestionale.app import crea_app
    from gestionale.core import migrazioni
    from gestionale.core.db import Archivio

    vecchio = Archive(cfg.cartella_dati / "verbali")
    backup = tmp_path / "sorgente.adbackup.zip"
    vecchio.export_backup(backup, include_documents=True)
    arc = Archivio(cfg)
    try:
        migrazioni.aggiorna(arc.motore)
    finally:
        arc.chiudi()
    importa(backup, cfg)
    cfg.verbali_postgresql = True
    app = crea_app(cfg)
    app.state.archivio.chiudi()
    vecchio.mutate(lambda c: vecchio._put(c, "plant", {"client_name": "Nuovo"}, action="plant_new"))
    with pytest.raises(RuntimeError, match="modificato dopo"):
        crea_app(cfg)
