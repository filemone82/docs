import json
import subprocess
import sys
from pathlib import Path
import re
from urllib.parse import quote, quote_plus

import pytest
from sqlalchemy import select, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.engine import make_url

from gestionale.core import migrazioni
from gestionale.moduli.anagrafica.modelli import Cliente, Sede
from gestionale.moduli.backup import servizio as backup
from gestionale.moduli.backup.postgresql import ripristina_a_fermo
from gestionale.moduli.registro import servizio as registro
from gestionale.moduli.utenti.servizio import Attore


def cliente(admin):
    r=admin.post('/api/clienti', {'ragione_sociale':'Cliente sintetico PG','tipo':'privato','ambiti':['DPR'],
                                'partita_iva':'01234567897','codice_fiscale':'01234567897'})
    assert r.status_code==200,r.text
    return r.json()


def test_baseline_fk_e_audit_immutabile(app,admin):
    arc=app.state.archivio
    assert migrazioni.revisione_database(arc.motore)==migrazioni.revisione_programma()
    with arc.lettura() as s:
        assert {nome:s.execute(text(f'SELECT count(*) FROM {nome}')).scalar() for nome in (
            'cls_tipi_attrezzature_gvr','cls_tipi_attrezzature','cls_id_specifiche',
            'cls_tipi_attr_id_specifiche','dm_tariffe')} == {
            'cls_tipi_attrezzature_gvr':6,'cls_tipi_attrezzature':31,'cls_id_specifiche':72,
            'cls_tipi_attr_id_specifiche':162,'dm_tariffe':314}
    with pytest.raises(IntegrityError) as e:
        with arc.scrittura() as s:
            s.add(Sede(cliente_id=9999999,denominazione='Non esiste il cliente'))
    assert e.value.orig.sqlstate=='23503'
    with pytest.raises(Exception,match='registro'):
        with arc.scrittura() as s:
            s.execute(text("UPDATE registro_operazioni SET descrizione='alterata'"))
    with arc.lettura() as s:
        assert registro.verifica_catena(s)['integro']


def test_centesimi_oltre_integer32(app):
    from datetime import date
    from gestionale.moduli.tariffario.modelli import VoceTariffa,VersioneTariffa
    arc=app.state.archivio
    with arc.scrittura() as s:
        voce=s.scalar(select(VoceTariffa).limit(1))
        v=VersioneTariffa(voce_id=voce.id,valida_dal=date(2099,1,1),prezzo=3_000_000_000)
        s.add(v);s.flush();id=v.id
    with arc.lettura() as s:assert s.get(VersioneTariffa,id).prezzo==3_000_000_000


WORKER='''
import json,sys
from pathlib import Path
from gestionale import modelli
from gestionale.moduli.anagrafica import ambiti, origini
from gestionale.moduli.beni import ponte_dpr
from gestionale.core.config import Config
from gestionale.core.db import Archivio
from gestionale.core.errori import ErroreUtente
from gestionale.moduli.utenti.servizio import Attore
from gestionale.moduli.preventivi.servizio import crea
from gestionale.moduli.anagrafica.servizio import modifica_cliente
d=json.load(sys.stdin)
a=Archivio(Config(cartella_dati=Path(d['dati']),database_url=d['url'],backup_automatico=False))
out=[]
try:
 for i in range(d['numero']):
  try:
   with a.scrittura() as s:
    if d['operazione']=='preventivi':
     p=crea(s,Attore(id=None,nome='Processo sintetico'),{'cliente_id':d['cliente'],'data':'2026-10-13'})
     out.append(p.numero)
    else:
     modifica_cliente(s,Attore(id=None,nome='Processo sintetico'),d['cliente'],
                      {**d['scheda'],'versione':d['versione'],'note':d['nota']})
     out.append(200)
  except ErroreUtente as e:out.append(e.stato)
 print(json.dumps(out))
finally:a.chiudi()
'''


def due_processi(arc,**dati):
    p=[]
    try:
        for i in range(2):
            x=subprocess.Popen([sys.executable,'-c',WORKER],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                               cwd=Path(__file__).resolve().parents[2])
            p.append(x)
            payload={'url':arc.cfg.database_url,'dati':str(arc.cfg.cartella_dati),**dati,'nota':str(i)}
            x.stdin.write(json.dumps(payload).encode());x.stdin.close();x.stdin=None
        risultati=[]
        for x in p:
            out,err=x.communicate(timeout=90)
            assert x.returncode==0, errore_processo(err, arc.cfg.database_url)
            risultati.extend(json.loads(out))
        return risultati
    finally:
        # Nessun processo rimane collegato al database dopo un errore/timeout.
        for x in p:
            if x.poll() is None:
                x.kill()
            x.communicate()


def errore_processo(err, url):
    messaggio=err.decode('utf-8', errors='replace')
    password=make_url(url).password or ''
    for segreto in sorted({url,password,quote(password,safe=''),quote_plus(password)}, key=len, reverse=True):
        if segreto:
            messaggio=messaggio.replace(segreto,'[omesso]')
    messaggio=re.sub(r'postgresql(?:\+psycopg)?://[^\s]+', '[connessione omessa]', messaggio)
    return 'Processo di collaudo non completato:\n'+messaggio[-8000:]


def test_numeri_e_catena_fra_processi(app,admin):
    c=cliente(admin);arc=app.state.archivio
    numeri=due_processi(arc,cliente=c['id'],numero=10,operazione='preventivi')
    assert sorted(numeri)==list(range(1,21))
    with arc.lettura() as s:
        assert registro.verifica_catena(s)['integro']


def test_versioni_fra_processi(app,admin):
    c=cliente(admin);arc=app.state.archivio
    stati=due_processi(arc,cliente=c['id'],versione=c['versione'],scheda=c,numero=1,operazione='modifica')
    assert sorted(stati)==[200,409]


def test_backup_pg_documenti_verbali_e_ripristino_a_fermo(app,admin):
    arc=app.state.archivio;c=cliente(admin);attore=Attore(id=None,nome='Prova ripristino')
    b=backup.crea(arc,'manuale',attore)
    assert backup.verifica_file(arc,arc.cfg.cartella_backup/b['nome'])['valido']
    assert admin.put('/api/clienti/'+str(c['id']),{**c,'versione':c['versione'],'note':'Dopo il backup'}).status_code==200
    ripristina_a_fermo(arc,b['nome'],attore)
    with arc.lettura() as s:
        assert s.get(Cliente,c['id']).note!='Dopo il backup'
        assert registro.verifica_catena(s)['integro']
    assert not (arc.cfg.cartella_dati/'ripristino_postgresql_in_corso.json').exists()
    assert not arc.cfg.percorso_database.exists()
