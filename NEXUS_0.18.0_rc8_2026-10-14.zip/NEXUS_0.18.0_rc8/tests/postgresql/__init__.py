"""Collaudo nativo PostgreSQL; mai eseguito sui database operativi."""
