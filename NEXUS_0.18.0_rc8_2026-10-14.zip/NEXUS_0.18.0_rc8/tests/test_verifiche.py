"""Versione 0.4.0: verifiche (fase 5), righe del preventivo a ore / senza impianto, versione ritoccata, ⚡ con numero."""

from __future__ import annotations

import io
import zipfile
from pathlib import Path

import pytest
from conftest import nuovo_utente, segna_inviato
from test_anagrafica import crea_cliente, crea_impianto, crea_sede

from gestionale.core import pdf

MODELLO_M02 = Path(__file__).parent / "dati" / "M02-PO01_dpr_rev02.docx"


def verbale_m02(numero: str, giorno: str) -> bytes:
    """Verbale M02 di prova: il modello rev. 02 di VerbalizzAI con numero e date scritti."""
    zin, uscita = zipfile.ZipFile(MODELLO_M02), io.BytesIO()
    with zipfile.ZipFile(uscita, "w", zipfile.ZIP_DEFLATED) as z:
        for info in zin.infolist():
            dati = zin.read(info.filename)
            if info.filename.startswith("word/") and info.filename.endswith(".xml"):
                dati = dati.replace(b"VP/000/00", numero.encode()).replace(b"gg/mm/aaaa", giorno.encode())
            z.writestr(info, dati)
    return uscita.getvalue()


@pytest.fixture
def accettato(admin, monkeypatch):
    """Preventivo con un impianto di scariche, uno di esplosione (a ore) e una riga di trasferta, accettato e riesaminato."""
    from conftest import pdf_sintetico
    monkeypatch.setattr(pdf, "da_word", lambda docx, conf="": pdf_sintetico(docx))
    c = crea_cliente(admin, ragione_sociale="Verifiche Prova S.r.l.")
    s = crea_sede(admin, c["id"])
    scariche = crea_impianto(admin, s["id"], tipologia="scariche", asta=True, numero_aste="2", potenza_kw="", periodicita_anni=2)
    esplosione = crea_impianto(admin, s["id"], tipologia="esplosione", gas=True, zone=["1"], potenza_kw="", periodicita_anni=2)
    p = admin.post("/api/preventivi", {"impianti": [scariche["id"], esplosione["id"]]}).json()
    righe = {r["impianto_id"]: r for r in p["righe"]}
    assert righe[scariche["id"]]["tariffa_standard"] == 15000                   # 100 + 50 (asta in più)
    r_espl = righe[esplosione["id"]]
    assert r_espl["voce_id"] and r_espl["tariffa_standard"] == 0 and r_espl["problemi_tariffa"]   # O10: voce a ore proposta
    voce_trasferta = next(v for v in p["voci_manuali"] if v["codice"] == "TRASFERTA")
    p = admin.post(f"/api/preventivi/{p['id']}/voci", {"voce_id": voce_trasferta["id"], "quantita": "2", "versione": p["versione"]}).json()
    p = admin.post(f"/api/preventivi/{p['id']}/voci", {"descrizione": "Rimborso spese a corpo", "importo": "25,50", "versione": p["versione"]}).json()
    corpo = next(r for r in p["righe"] if r["a_corpo"])
    trasferta = next(r for r in p["righe"] if r["voce_id"] == voce_trasferta["id"])
    assert trasferta["tariffa_standard"] == 8000 and trasferta["impianto_id"] is None and corpo["tariffa_standard"] == 2550
    # ore sulla riga dell'esplosione (O10: € 93/ora)
    dati = {**p, "righe": [{"id": r["id"], "tipo_verifica": r["tipo_verifica"], "sconto": "0", **({"quantita": "8"} if r["id"] == r_espl["id"] else {})}
                           for r in p["righe"]]}
    p = admin.put(f"/api/preventivi/{p['id']}", dati).json()
    assert next(r for r in p["righe"] if r["id"] == r_espl["id"])["tariffa_standard"] == 74400
    assert p["totale"] == 15000 + 74400 + 8000 + 2550
    # documento: le righe senza impianto compaiono con il nome della voce
    doc = admin.post(f"/api/preventivi/{p['id']}/documenti", {"pdf": False}).json()
    word = next(d for d in doc["generati"] if d["formato"] == "docx")
    xml = zipfile.ZipFile(io.BytesIO(admin.get(f"/api/preventivi/{p['id']}/documenti/{word['documento_id']}").content)).read("word/document.xml").decode()
    assert "Spese di trasferta" in xml and "Rimborso spese a corpo" in xml and "8 ore" in xml
    p = segna_inviato(admin, p)
    p = admin.post(f"/api/preventivi/{p['id']}/righe/stato", {"righe": [r["id"] for r in p["righe"]], "stato": "accettata", "evidenza_accettazione": "Email di conferma del caso di collaudo", "versione": p["versione"]}).json()
    r = admin.post(f"/api/preventivi/{p['id']}/riesame", {"esito": "conforme", "requisiti_chiari": True, "competenza_strumenti": True,
                                                         "imparzialita": True, "tempi": True})
    assert r.status_code == 200, r.text
    p = admin.get(f"/api/preventivi/{p['id']}").json()
    return {"preventivo": p, "scariche": scariche, "esplosione": esplosione}


def test_verifiche_nascono_dal_riesame(admin, accettato):
    p = accettato["preventivo"]
    assert len(p["verifiche"]) == 2 and {v["stato"] for v in p["verifiche"]} == {"da_assegnare"}   # solo righe con impianto
    # un nuovo riesame non le duplica
    admin.post(f"/api/preventivi/{p['id']}/riesame", {"esito": "conforme", "requisiti_chiari": True, "competenza_strumenti": True,
                                                     "imparzialita": True, "tempi": True})
    assert len(admin.get(f"/api/preventivi/{p['id']}").json()["verifiche"]) == 2
    # una riga con verifica attiva non si rifiuta
    riga = next(r for r in p["righe"] if r["impianto_id"] == accettato["scariche"]["id"])
    r = admin.post(f"/api/preventivi/{p['id']}/righe/stato", {"righe": [riga["id"]], "stato": "rifiutata", "versione": p["versione"]})
    assert r.status_code == 400 and "Revoca accettazione" in r.json()["errore"]   # R124 (0.12.8)


def test_percorso_completo_della_verifica(admin, app, accettato):
    p = accettato["preventivo"]
    rt = nuovo_utente(admin, app, "rt5", "responsabile_tecnico")
    tecnico = nuovo_utente(admin, app, "tecnico5", "tecnico")
    altro = nuovo_utente(admin, app, "tecnico6", "tecnico")
    ver = {v["impianto_id"]: v for v in p["verifiche"]}[accettato["scariche"]["id"]]
    valori = rt.get("/api/verifiche/valori").json()
    id_tecnico = next(x["id"] for x in valori["verificatori"] if x["nome"] == "Tecnico5")
    v = rt.get(f"/api/verifiche/{ver['id']}").json()
    # il tecnico non assegna; il RT sì
    assert tecnico.post(f"/api/verifiche/{v['id']}/assegna", {"verificatore_id": id_tecnico, "versione": v["versione"]}).status_code == 403
    v = rt.post(f"/api/verifiche/{v['id']}/assegna", {"verificatore_id": id_tecnico, "versione": v["versione"]}).json()
    assert v["stato"] == "assegnata" and v["verificatore"] == "Tecnico5"
    # il tecnico vede solo le sue verifiche
    assert tecnico.post("/api/griglie/verifiche/dati", {}).json()["totale"] == 1
    assert altro.post("/api/griglie/verifiche/dati", {}).json()["totale"] == 0
    assert altro.get(f"/api/verifiche/{v['id']}").status_code == 403
    assert altro.post(f"/api/verifiche/{v['id']}/registra", {"data_esecuzione": "2026-10-15", "versione": v["versione"]}).status_code == 403
    # programma e registra: numero del verbale annuale, un solo sezionale VP/VS (D62)
    v = tecnico.post(f"/api/verifiche/{v['id']}/programma", {"data_programmata": "2026-10-14", "versione": v["versione"]}).json()
    assert v["stato"] == "programmata"
    v = tecnico.post(f"/api/verifiche/{v['id']}/registra", {"data_esecuzione": "2026-10-15", "versione": v["versione"]}).json()
    assert v["stato"] == "registrata" and v["codice_verbale"] == "VP/001/26"
    # carica il verbale: numero sbagliato → rifiutato; giusto → eseguita e impianto aggiornato
    sbagliato = {"word": ("v.docx", verbale_m02("VP/999/26", "15/10/2026"), "application/octet-stream")}
    r = tecnico.c.post(f"/api/verifiche/{v['id']}/verbale", files=sbagliato, data={"versione": v["versione"]}, headers=tecnico.h)
    assert r.status_code == 400 and "VP/001/26" in r.json()["errore"]
    giusto = {"word": ("VP_001_26.docx", verbale_m02("VP/001/26", "15/10/2026"), "application/octet-stream")}
    r = tecnico.c.post(f"/api/verifiche/{v['id']}/verbale", files=giusto, data={"versione": v["versione"]}, headers=tecnico.h)
    assert r.status_code == 200, r.text
    v = r.json()
    assert v["stato"] == "eseguita" and v["modulo"] == "M02" and v["prossima_verifica"] == "2028-10-14"   # calcolata: + 2 anni − 1 giorno
    assert any("Prossima verifica" in a for a in v["avvisi_verbale"])
    impianto = admin.get(f"/api/impianti/{accettato['scariche']['id']}").json()
    assert impianto["ultima_verifica_data"] == "2026-10-15" and impianto["ultima_verifica_numero"] == "VP/001/26"
    assert impianto["caratteristiche"]["verbale"] == "VP/001/26" and impianto["prossima_verifica"] == "2028-10-14"
    # riesame del verbale (RT): non conforme → torna registrata; poi conforme → riesaminata
    assert tecnico.post(f"/api/verifiche/{v['id']}/riesame", {"esito": "conforme", "versione": v["versione"]}).status_code == 403
    v = rt.post(f"/api/verifiche/{v['id']}/riesame", {"esito": "non_conforme", "note": "manca la firma", "versione": v["versione"]}).json()
    assert v["stato"] == "registrata"
    r = tecnico.c.post(f"/api/verifiche/{v['id']}/verbale", files=giusto, data={"versione": v["versione"]}, headers=tecnico.h)
    v = r.json()
    assert v["stato"] == "eseguita" and len([d for d in v["documenti"] if d["in_uso"]]) == 2 and len(v["documenti"]) == 4
    v = rt.post(f"/api/verifiche/{v['id']}/riesame", {"esito": "conforme", "versione": v["versione"]}).json()
    assert v["stato"] == "riesaminata"
    # la seconda verifica (straordinaria) prende il numero successivo dello stesso sezionale
    altra = {x["impianto_id"]: x for x in p["verifiche"]}[accettato["esplosione"]["id"]]
    a = admin.get(f"/api/verifiche/{altra['id']}").json()
    a = admin.post(f"/api/verifiche/{a['id']}/assegna", {"verificatore_id": id_tecnico, "versione": a["versione"]}).json()
    a = admin.post(f"/api/verifiche/{a['id']}/registra", {"data_esecuzione": "2026-10-20", "versione": a["versione"]}).json()
    assert a["codice_verbale"] == "VP/002/26"
    # verbale del modulo sbagliato (M02 su un impianto con pericolo di esplosione) → rifiutato
    r = admin.c.post(f"/api/verifiche/{a['id']}/verbale", files={"word": ("x.docx", verbale_m02("VP/002/26", "20/10/2026"), "application/octet-stream")},
                          data={"versione": a["versione"]}, headers=admin.h)
    assert r.status_code == 400 and "M03" in r.json()["errore"]
    # annullamento con motivo: il numero resta usato
    a = admin.post(f"/api/verifiche/{a['id']}/annulla", {"motivo": "impianto chiuso", "versione": a["versione"]}).json()
    assert a["stato"] == "annullata" and a["codice_verbale"] == "VP/002/26"


def test_da_scadenze_con_numero_e_revisione(admin, monkeypatch):
    """O12: dalla maschera ⚡ con il numero del preventivo; se è già inviato si crea la revisione con la data di oggi."""
    c = crea_cliente(admin, ragione_sociale="Scadenze Prova S.r.l.")
    s = crea_sede(admin, c["id"])
    i1, i2, i3 = (crea_impianto(admin, s["id"]) for _ in range(3))
    p = admin.post("/api/preventivi/da-scadenze", {"impianti": [i1["id"]], "data": "2026-10-05", "preventivo": ""}).json()
    assert p["codice"].startswith("P_") and p["data"] == "2026-10-05"
    p2 = admin.post("/api/preventivi/da-scadenze", {"impianti": [i2["id"]], "preventivo": str(p["numero"])}).json()
    assert p2["id"] == p["id"] and len(p2["righe"]) == 2
    segna_inviato(admin, p2)
    p3 = admin.post("/api/preventivi/da-scadenze", {"impianti": [i3["id"]], "preventivo": p["codice"]}).json()
    assert p3["revisione"] == 1 and len(p3["righe"]) == 3
    altro = crea_cliente(admin, ragione_sociale="Altro Cliente S.r.l.", partita_iva="12345678903", codice_fiscale="12345678903")
    s2 = crea_sede(admin, altro["id"])
    i4 = crea_impianto(admin, s2["id"])
    r = admin.post("/api/preventivi/da-scadenze", {"impianti": [i4["id"]], "preventivo": p["codice"]})
    assert r.status_code == 400 and "altro cliente" in r.json()["errore"]


def _ritocca(docx: bytes, cambia_testo: bool = False) -> bytes:
    """Come un ritocco fatto in Word: margine superiore diverso (impaginazione); con cambia_testo anche un nome cambiato."""
    import re

    zin, uscita = zipfile.ZipFile(io.BytesIO(docx)), io.BytesIO()
    with zipfile.ZipFile(uscita, "w", zipfile.ZIP_DEFLATED) as zout:
        for info in zin.infolist():
            dati = zin.read(info.filename)
            if info.filename == "word/document.xml":
                xml = dati.decode("utf-8")
                xml, n = re.subn(r'(<w:pgMar[^>]*w:top=")(\d+)"', lambda m: m.group(1) + str(int(m.group(2)) + 300) + '"', xml)
                assert n
                if cambia_testo:
                    xml = xml.replace("Ritocchi S.r.l.", "Ritocchi Due S.r.l.")
                dati = xml.encode("utf-8")
            zout.writestr(info, dati)
    return uscita.getvalue()


def test_documento_come_i_verbali(admin, app, monkeypatch):
    """0.7.0 (D80): anteprima archiviata, ritocchi di sola impaginazione con PDF rifatto dal programma, approvazione,
    invio solo del PDF approvato, nessun ritocco dopo l'invio."""
    from gestionale.core import posta

    inviati = []
    monkeypatch.setattr(posta, "invia", lambda cfg, msg, tempo=40: inviati.append(msg) or "ok")
    c = crea_cliente(admin, ragione_sociale="Ritocchi S.r.l.")
    i = crea_impianto(admin, crea_sede(admin, c["id"])["id"])
    p = admin.post("/api/preventivi", {"impianti": [i["id"]]}).json()
    # 1. anteprima: preparata e archiviata (Word + PDF), da approvare; si apre dentro la pagina (stesso sito)
    r = admin.post(f"/api/preventivi/{p['id']}/anteprima").json()
    doc = r["documento"]
    assert r["generato"] and doc["da_approvare"] and not doc["ufficiale"] and doc["word_documento_id"]
    x = admin.get(f"/api/preventivi/{p['id']}").json()
    assert len(x["documenti"]) == 2 and all(d["attuale"] for d in x["documenti"]) and x["documento_attuale"]["pdf_documento_id"] == doc["pdf_documento_id"]
    vista = admin.get(doc["indirizzo"])
    assert vista.headers["content-disposition"].startswith("inline") and vista.headers["x-frame-options"] == "SAMEORIGIN"
    assert admin.get(f"/api/preventivi/{p['id']}/documenti/{doc['pdf_documento_id']}").headers["x-frame-options"] == "DENY"
    # niente è cambiato: riapre lo stesso documento
    assert admin.post(f"/api/preventivi/{p['id']}/anteprima").json()["documento"]["pdf_documento_id"] == doc["pdf_documento_id"]
    # 2. senza approvazione non si invia né si segna inviato
    email = {"a": "cliente@esempio.invalid", "cc": "", "oggetto": "Preventivo", "testo": "In allegato."}
    assert admin.post(f"/api/preventivi/{p['id']}/email", email).status_code == 409
    assert admin.post(f"/api/preventivi/{p['id']}/inviato", {"versione": x["versione"]}).status_code == 409
    # 3. ritocco con un testo cambiato: rifiutato; ritocco di sola impaginazione: accettato, PDF rifatto dal programma, da approvare
    docx = admin.get(f"/api/preventivi/{p['id']}/documenti/{doc['word_documento_id']}").content
    def carica(contenuto):
        return admin.c.post(f"/api/preventivi/{p['id']}/documenti/ritoccati", files={"word": ("ritoccato.docx", contenuto, "application/octet-stream")},
                            data={"versione": x["versione"]}, headers=admin.h)
    r = carica(_ritocca(docx, cambia_testo=True))
    assert r.status_code == 400 and "solo ritocchi di impaginazione" in r.json()["errore"]
    assert carica(b"non sono un Word").status_code == 400
    r = carica(_ritocca(docx))
    assert r.status_code == 200, r.text
    ritocco = r.json()["documento"]
    assert ritocco["ritoccato"] and ritocco["da_approvare"] and ritocco["pdf_documento_id"] != doc["pdf_documento_id"]
    pdf_ritocco = admin.get(f"/api/preventivi/{p['id']}/documenti/{ritocco['pdf_documento_id']}").content
    assert pdf_ritocco.startswith(b"%PDF")
    # l'anteprima ora riapre il ritocco; il documento precedente non si approva più
    assert admin.post(f"/api/preventivi/{p['id']}/anteprima").json()["documento"]["pdf_documento_id"] == ritocco["pdf_documento_id"]
    assert admin.post(f"/api/preventivi/{p['id']}/documenti/{doc['pdf_documento_id']}/approva").status_code == 409
    # 4. approvazione; poi i dati cambiano → l'approvazione non vale più
    tec = nuovo_utente(admin, app, "tecnico9", "tecnico")
    assert tec.post(f"/api/preventivi/{p['id']}/documenti/{ritocco['pdf_documento_id']}/approva").status_code == 403
    r = admin.post(f"/api/preventivi/{p['id']}/documenti/{ritocco['pdf_documento_id']}/approva").json()
    assert r["documento"]["approvato"] and r["documento_attuale"]["approvato"]
    x = admin.put(f"/api/preventivi/{p['id']}", {**r, "note": "cambiata", "righe": [{"id": rr["id"], "tipo_verifica": rr["tipo_verifica"], "sconto": "0"} for rr in r["righe"]]}).json()
    assert x["documento_attuale"] is None
    assert admin.post(f"/api/preventivi/{p['id']}/email", email).status_code == 409
    # dati rimessi com'erano: torna valido il documento approvato (stessa impronta dei dati)
    x = admin.put(f"/api/preventivi/{p['id']}", {**x, "note": r["note"], "righe": [{"id": rr["id"], "tipo_verifica": rr["tipo_verifica"], "sconto": "0"} for rr in x["righe"]]}).json()
    assert x["documento_attuale"]["approvato"] and x["documento_attuale"]["pdf_documento_id"] == ritocco["pdf_documento_id"]
    # 5. invio: proprio il PDF approvato
    r = admin.post(f"/api/preventivi/{p['id']}/email", email)
    assert r.status_code == 200, r.text
    assert next(inviati[0].iter_attachments()).get_content() == pdf_ritocco
    assert admin.post(f"/api/preventivi/{p['id']}/stampa").json()["documento_id"] == ritocco["pdf_documento_id"]
    # 6. dopo l'invio: niente ritocchi; l'anteprima mostra il documento inviato
    x = admin.get(f"/api/preventivi/{p['id']}").json()
    r = admin.c.post(f"/api/preventivi/{p['id']}/documenti/ritoccati", files={"word": ("r.docx", _ritocca(docx), "application/octet-stream")},
                     data={"versione": x["versione"]}, headers=admin.h)
    assert r.status_code == 400 and "revisione" in r.json()["errore"]
    inviato = admin.post(f"/api/preventivi/{p['id']}/anteprima").json()["documento"]
    assert inviato["ufficiale"] and inviato["pdf_documento_id"] == ritocco["pdf_documento_id"] and not inviato["da_approvare"]


def test_periodicita_esplosione_sempre_due_anni(admin):
    """O8: pericolo di esplosione solo 2 anni."""
    s = crea_sede(admin, crea_cliente(admin, ragione_sociale="Esplosione S.r.l.")["id"])
    r = admin.post("/api/impianti", {"sede_id": s["id"], "tipologia": "esplosione", "gas": True, "zone": ["1"], "periodicita_anni": 5})
    assert r.status_code == 400 and "2 anni" in r.json()["errore"]
    assert crea_impianto(admin, s["id"], tipologia="esplosione", gas=True, zone=["1"], potenza_kw="", periodicita_anni="")["periodicita_anni"] == 2
