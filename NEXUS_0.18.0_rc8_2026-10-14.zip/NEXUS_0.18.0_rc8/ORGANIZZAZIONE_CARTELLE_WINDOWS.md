# Organizzazione locale dei progetti su Windows

Versione 1.0 — 9 ottobre 2026. Raccomandazione organizzativa; nessuna cartella del PC è stata spostata e nessun archivio è stato modificato.

## Due progetti attivi

**VerbalizzAI autonomo** conserva sorgente, versioni e archivio propri. **Gestionale AD integrato** è l’evoluzione del precedente AD_dpr completo: DPR è il primo ambito operativo, DM/I&C vengono completati sullo stesso progetto. Il vecchio AD_dpr va conservato come base/versione storica, senza avviare un terzo sviluppo parallelo.

Il VerbalizzAI incorporato nel gestionale è una dipendenza di quel pacchetto. Non è automaticamente la versione autonoma in produzione; attualmente l’incorporato è 0.3.32.3. Per l’adattatore futuro va acquisita la versione autonoma consolidata.

## Cartelle consigliate

Radice d’esempio `C:\AD`. Se il PC richiede l’area già autorizzata per VerbalizzAI/WatchGuard, mantenere la medesima struttura sotto quella radice consentita; non spostare un’installazione funzionante prima della verifica sul PC.

| Percorso | Contenuto |
|---|---|
| `C:\AD\VerbalizzAI\Stabile` | Programma autonomo validato nell’uso. |
| `C:\AD\VerbalizzAI\Beta` | Programma autonomo da collaudare. |
| `C:\AD\Gestionale_AD\Stabile` | Versione del gestionale validata nell’uso; per ora può rimanere vuota. |
| `C:\AD\Gestionale_AD\Beta` | Programma del gestionale in collaudo. Preferibili sottocartelle con versione, per esempio `Gestionale_AD_v0.9.1`. |
| `C:\AD\Dati\VerbalizzAI_Stabile` | Archivio dell’applicazione autonoma stabile. |
| `C:\AD\Dati\VerbalizzAI_Beta` | Copia separata per prove autonome. |
| `C:\AD\Dati\Gestionale_AD_Stabile` | Archivio del gestionale validato. |
| `C:\AD\Dati\Gestionale_AD_Beta_0.9.1` | Archivio di collaudo integrato, proveniente da una copia verificata oppure inizialmente vuoto. |
| `C:\AD\Archivio_versioni\VerbalizzAI` | ZIP, istruzioni e sorgenti autonomi per versione/data. |
| `C:\AD\Archivio_versioni\Gestionale_AD` | ZIP e sorgenti del gestionale, compreso il precedente AD_dpr; 0.8.1 resta una correzione della versione precedente. |
| `C:\AD\Backup` | Backup datati dei diversi archivi, con progetto e versione riconoscibili. |
| `C:\AD\Documentazione` | Quadro aggiornato, ripresa, requisiti, analisi e rapporti di collaudo. |

Non chiamerei le precedenti versioni “Obsoleti”: possono servire per confronti, regressioni e ripristini. Conservare almeno il pacchetto corrispondente a ogni backup che si vuole poter riaprire. Un backup sul medesimo disco non protegge dalla perdita del disco: una copia separata resta utile.

## Programma e dati sono distinti

Le etichette Stabile/Beta non bastano a separare gli archivi. Nel gestionale impostare **esplicitamente** `cartella_dati` in `config.json` per l’avvio ordinario; due installazioni possono altrimenti usare la stessa cartella dati predefinita. Esempio per l’avvio ordinario della Beta:

```json
{
  "cartella_dati": "C:\\AD\\Dati\\Gestionale_AD_Beta_0.9.1"
}
```

Integrare questa voce nella configurazione esistente, preservando le altre impostazioni. È la chiave del gestionale; non si presume che VerbalizzAI autonomo usi il medesimo file o formato di configurazione.

**Il launcher `AVVIA_COLLAUDO_WINDOWS.bat` imposta invece `Dati_Collaudo` all’interno della cartella programma.** Con quel launcher la separazione deriva dalla cartella di estrazione della versione: non presumere che usi il percorso dell’esempio. Controllare il percorso effettivo mostrato dal programma prima di iniziare le prove. Non cambiare launcher e cartella dati contemporaneamente senza individuare l’archivio che si intende aprire.

Prima di copiare un archivio chiudere il programma e usare preferibilmente la funzione di backup/verifica. Una copia del solo `.db` mentre SQLite è aperto può non includere quanto si trova nei file WAL. La copia deve comprendere documenti e, nel gestionale corrente, l’archivio del VerbalizzAI incorporato.

La Beta lavora su una copia, mai direttamente sull’archivio stabile. Le migrazioni possono rendere i dati incompatibili con una versione precedente: per tornare indietro usare il backup precedente con il programma corrispondente. La 0.8.1 conserva schema 0010; la 0.9.1 usa 0011. Non aprire un archivio 0011 con il programma 0.8.

## Uso attuale

Il gestionale nuovo resta **Beta**, anche nella parte DPR, finché non viene validato nell’uso e deciso il passaggio operativo. Garda resta operativo secondo il periodo di convivenza concordato. La consegna della 0.9.1 non significa che DM/I&C siano pronti.

Per una segnalazione conservare versione del programma, percorso dell’archivio di prova e passaggi eseguiti. Per riprendere il progetto con un’altra istanza fornire soprattutto documento 00 e quadro 04 aggiornati, oltre al pacchetto di codice corrente; non soltanto la cartella più recente per data.
