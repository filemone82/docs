> **Versione corrente 0.17.0:** leggere prima `README.md` e `MIGRAZIONE_0.17.0.md`. La documentazione sottostante conserva istruzioni e cronologia delle versioni precedenti.

> Checkpoint corrente **0.12.0-dev**, schema **0014**: verbali DM Word/PDF, conferma del definitivo, chiusura, riesame e date per componente. VerbalizzAI **1.0.1 rc2** incorporato. Leggere **STATO_IMPLEMENTAZIONE_0.12.0-dev.md** e **documentazione/27_Ciclo_tecnico_documentale_DM_2026-10-10.md**. Il traguardo resta il gestionale completo: fatturazione DM collegata, INAIL, I&C, dashboard e migrazione ancora aperti. Il checkpoint conserva lo sviluppo; non richiede una nuova installazione operativa. Le sezioni seguenti sono storiche.

> Checkpoint precedente **0.11.1-dev**: raccordo VerbalizzAI 1.0.1 rc2, schema 0013. Stato storico in STATO_IMPLEMENTAZIONE_0.11.1-dev.md; percorso complessivo nel rapporto 25.

**Installazione e avvio aggiornati per la 0.12:** leggere [README_INSTALLAZIONE.md](README_INSTALLAZIONE.md). Il README è incluso anche nelle consegne future, insieme a ogni stato di avanzamento; le istruzioni storiche sotto restano un riferimento per le funzioni precedenti.

> Sviluppo **0.11.0-dev**, incarichi tecnici DM fino alla registrazione e selettore delle attività. Leggere `STATO_IMPLEMENTAZIONE_0.11.0-dev.md`, `COLLAUDO_MANUALE_0.11.0-dev.md` e `INIZIA_QUI_WINDOWS.md`. Base 0.10 preservata; emissione/RV/fatture collegate DM e INAIL ancora aperti. Non è il rilascio completo R99.

# Gestionale AD — LEGGIMI (versione 0.8.0, collaudo Windows)

Gestionale AD_dpr in Python, con VerbalizzAI **1.0.1 rc2** incorporato e un primo modulo **fatture e incassi**. Per l’avvio di questa candidatura leggere prima **`INIZIA_QUI_WINDOWS.md`**; il perimetro effettivo e i limiti sono in **`STATO_IMPLEMENTAZIONE_0.8.0.md`**. La guida sottostante conserva le istruzioni del prototipo per le funzioni già presenti. Le eventuali indicazioni storiche di funzioni future vanno lette insieme allo stato aggiornato. Il sistema non è ancora il sostituto operativo di Garda.

Documentazione di progetto (decisioni, modello dei dati, piano): documenti 01–15 del progetto «Gestionale completo AD_dpr» su claude.ai. Le sigle D1, D2… nel codice e qui rimandano al documento 02 «Registro delle decisioni».

---

## 1. Cosa serve sul PC (Windows)

1. **Python 3.12** da https://www.python.org/downloads/ — durante l'installazione spunta **«Add python.exe to PATH»**.
2. Connessione a Internet **solo durante l'installazione** (scarica i componenti elencati in `requirements.txt`). Poi il programma funziona senza Internet.
3. **LibreOffice** (gratuito, libreoffice.org) per i PDF dei preventivi: lo stesso usato da VerbalizzAI. Se non è nella cartella standard, indica il percorso di `soffice.exe` in `config.json` alla voce `"libreoffice"`.

## 2. Installazione

1. Scompatta lo zip **dentro la cartella di VerbalizzAI** (altrimenti WatchGuard lo blocca), accanto all'app di VerbalizzAI e mai dentro i suoi file: per esempio `C:\VerbalizzAI\Gestionale_AD_v0.8.0`. Attenzione: «Estrai tutto» di Windows può creare una cartella doppia (`Gestionale_AD_v0.8.0\Gestionale_AD_v0.8.0`); in quel caso i dati finirebbero dentro la prima. Per evitarlo indica la cartella dei dati in `config.json` (sotto).
2. Doppio clic su **`INSTALLA_WINDOWS.bat`** e attendi «Installazione completata» (4 passaggi numerati). Se un'installazione precedente si era interrotta, il programma se ne accorge e rifà l'ambiente Python da solo; se qualcosa non va scrive **[ERRORE]** con il motivo: fai uno screenshot della finestra.

I dati (database, documenti, backup) vanno in una cartella **separata dal programma**: `GestionaleAD_dati`, accanto alla cartella del programma (nell'esempio `C:\VerbalizzAI\GestionaleAD_dati`). Così aggiornare il programma non tocca mai i dati. In alternativa si indica un percorso fisso in `config.json` (`cartella_dati`).

## 3. Avvio e primo accesso

1. Doppio clic su **`AVVIA_WINDOWS.bat`**: si apre una finestra nera (è il programma: **non chiuderla** finché lavori) e il browser su `http://localhost:8462`.
2. Al **primo avvio** il programma chiede di creare l'**amministratore** (nome, nome utente, password di almeno 10 caratteri: va bene una frase facile da ricordare).
3. Per chiudere il programma chiudi la finestra nera.

## 4. Cosa c'è in questa versione

| Funzione | Dove | Note |
|---|---|---|
| Accesso con utente e password | — | 5 password sbagliate → blocco di 15 minuti; la sessione si chiude dopo 60 minuti senza attività |
| Utenti | Sistema › Utenti | Nuovo utente con **password provvisoria** (va cambiata al primo accesso), modifica, disattiva/riattiva (mai cancellati), sblocca, nuova password provvisoria |
| Ruoli | Sistema › Ruoli e permessi › Ruoli | Ruoli **creabili** (D37), anche copiando i permessi di un altro; un ruolo usato non si elimina, si disattiva |
| Permessi a grana fine | Sistema › Ruoli e permessi › Permessi per ruolo | Una riga per **ogni operazione** (D24), una colonna per ruolo; le voci «in arrivo» riguardano le prossime fasi e si possono già assegnare. L'Amministratore ha sempre tutto |
| Registro delle operazioni | Sistema › Registro operazioni | Chi, quando, cosa, prima/dopo. Non si modifica né si cancella; le righe sono legate a catena da impronte digitali |
| Backup e integrità | Sistema › Backup e integrità | Backup manuale e automatico, scarica, carica da file, **verifica**, **ripristino** con conferma, controllo di integrità |
| Griglia comune | in tutti gli elenchi | Ricerca, filtro e ordinamento per colonna, colonne visibili, spostamento colonne, raggruppamento, **viste salvate per utente**, **esportazione Excel della vista** (solo colonne visibili, con i filtri) |
| **Clienti** | Lavoro › Clienti | Scheda con linguette (dati generali, fatturazione, contatti e note, sedi, storico). Due email: verbali e fatture (D41); tipo di cliente (D42); comune con suggerimenti dall'elenco ISTAT (compila CAP, provincia, regione, sempre modificabili); **codice fiscale obbligatorio**, partita IVA facoltativa (D48); controllo di partita IVA, codice fiscale, codice SDI, IBAN; sconti bloccati, sbloccabili con motivo (D38); disattiva/riattiva; elimina solo se senza sedi |
| **Sedi operative** | Lavoro › Sedi operative | Collegate al cliente; nell'elenco ci sono anche tutte le colonne del cliente (D43). Destinatari dei verbali propri (prevalgono su quelli del cliente); note di accesso; «copia l'indirizzo della sede legale»; chiudi/riapri; elimina solo se senza impianti |
| **Impianti** | Lavoro › Impianti | Campi diversi per tipologia (terra fino/oltre 1.000 V, scariche atmosferiche, pericolo di esplosione); matricola INAIL in 4 parti; **più POD per impianto** (G35); periodicità 2/5 anni; **prossima verifica calcolata** (ultima verifica + periodicità − 1 giorno, come il gestionale attuale); **tariffa proposta** dal tariffario; dismetti con motivo (D10). Nell'elenco anche le colonne di sede e cliente |
| **Scadenze** | Lavoro › Scadenze | Impianti non dismessi per prossima verifica, con stato (scaduta, entro 30/90 giorni, entro 1 anno…), giorni alla scadenza e tariffa proposta; pulsanti rapidi di filtro |
| **Tariffario** | Lavoro › Tariffario | Voci create da menu (D29): a chi si applicano, criterio (scaglioni, prezzo × quantità, prezzo fisso) e dato dell'impianto; **importi in versioni con data di validità** (quelle già in vigore non si cambiano); «Prova il calcolo». Caricata la tariffa terre del gestionale attuale |
| Commerciali | Lavoro › Commerciali | Commerciali di AD (D35), scelti nella scheda del cliente |
| Elenchi di valori | Sistema › Elenchi di valori | Modalità di pagamento e aliquote IVA proposte nelle schede |
| Comuni (ISTAT) | Sistema › Comuni (ISTAT) | Elenco usato nella ricerca del comune: correggere, aggiungere, togliere i soppressi (D49) |
| **Azioni sulla riga** | prima colonna di ogni elenco | ✎ apri/modifica · 🗑 elimina · ⇄ elementi collegati (apre l'altro elenco già filtrato, es. Impianti ← Cliente) (D50) |
| **Importazione dati** | Sistema › Importazione dati | Vedi § 4-bis |
| **Preventivi** | Lavoro › Preventivi | Nuovo preventivo intestato al cliente con impianti di più sedi; numero P_001_26 per anno; righe con tipo di verifica, tariffa standard copiata dal tariffario, sconto % (solo clienti sbloccati), tariffa applicata; stati calcolati dalle righe (accetta / rifiuta / annulla riga); **fissato** dopo un'accettazione; **revisioni** dopo l'invio; **riesame del contratto**; **Word e PDF** dal modello; **invio email**; storico |
| Righe dei preventivi | Lavoro › Righe dei preventivi | Una riga per impianto preventivato con stato di accettazione (es. «Accettate (da organizzare)») |
| ⚡ dalle scadenze | Lavoro › Scadenze | Seleziona una o più scadenze dello stesso cliente → «⚡ Preventivo»: nuovo o aggiunta a un preventivo «creato» |
| Impostazioni email | Sistema › Impostazioni email | Server di posta (password nel file `posta.json` della cartella dati, fuori da database e backup), testi standard, prova di invio |
| Modelli Word | Sistema › Modelli Word | Modelli in uso / superati; carica una nuova revisione (il programma controlla i segnaposto) |
| **🖨 Stampa** (0.3.1) | in basso nella scheda del preventivo | Apre il PDF in una nuova scheda del browser, da cui si stampa. Preventivo già inviato → il PDF inviato; altrimenti l'ultimo PDF se nulla è cambiato, oppure ne genera uno nuovo e lo archivia; con modifiche non salvate chiede di salvare (D58) |
| **Misura del testo** (0.3.1) | Il mio profilo | Normale (16 punti) o Grande (18 punti), per ciascun utente (D57). In più, in ogni momento: Ctrl e + / Ctrl e 0 nel browser |
| **Verifiche** (0.4.0) | Lavoro › Verifiche | Nascono dalle righe accettate dopo il riesame del contratto conforme. Da assegnare → assegnata (RT) → programmata (data prevista) → registrata (numero del verbale VP/VS annuale) → eseguita (si carica il Word del verbale emesso con VerbalizzAI: aggiorna l'impianto) → riesaminata dal RT (da fatturare). Il verificatore vede solo le sue |
| Caratteristiche ed elementi (0.4.0) | scheda dell'impianto | Caratteristiche tecniche ed elementi provati dall'ultimo verbale caricato; verifiche dell'impianto |
| Righe a ore e senza impianto (0.4.0) | scheda del preventivo › Righe | Pericolo di esplosione e altri casi a ore (€ 93/ora): ore scritte nella riga. «＋ Voce / a corpo»: trasferta, sopralluogo a vuoto, duplicato, strutture metalliche, importo a corpo |
| 👁 Anteprima (0.4.0; **0.7.0**) | in basso nella scheda del preventivo | Dalla 0.7.0 (D80) apre «**Controlla il documento**»: Word e PDF preparati con i dati attuali e **archiviati**, il PDF si vede nella finestra; «**Approvo questo documento**» registra la presa visione. Se i dati non cambiano riapre lo stesso documento |
| Ritocchi di impaginazione (0.4.0; **0.7.0**) | Controlla il documento › «Scarica il Word» / «Carica il Word ritoccato…» | Dalla 0.7.0 (D80) si ricarica **solo il Word**: il programma controlla che testo, numeri e immagini siano identici a quelli dell'anteprima (sono ammessi margini, spazi, interruzioni di pagina) e **rifà il PDF** con LibreOffice; il documento ritoccato va approvato. Solo prima dell'invio |
| **Invio solo del PDF approvato** (0.7.0) | Invia email… / Segna come inviato | Si invia (o risulta inviato) **esattamente** il PDF approvato; se i dati del preventivo cambiano dopo l'approvazione, il documento va ricontrollato. Dopo l'invio il documento non cambia più: per correggerlo serve una revisione |
| Salva e chiudi (0.4.0) | tutte le schede laterali | Accanto a «Salva» |
| **Verbali** (0.5.0) | Lavoro › Verbali | VerbalizzAI dentro il gestionale, con utenti e permessi del gestionale: bozze, controlli, Word e PDF, emissione con firma, revisioni, annullamento, strumenti, firme, invio per email. «← Torna al gestionale» in basso a sinistra |
| Compila il verbale (0.5.0) | Verifica registrata | Crea la bozza già compilata (numero, date, verificatore, dati del gestionale); all'emissione la verifica diventa «eseguita» da sola. Dalla 0.6.0, dopo un riesame non conforme apre la revisione del verbale emesso |
| **Verbali di VerbalizzAI** (0.5.0) | Sistema › Verbali di VerbalizzAI | Importazione del backup completo di VerbalizzAI e collegamento di ogni suo impianto a una sede del gestionale |
| Sconto (con revisione) (0.5.0) | preventivo inviato | Revisione automatica con lo sconto (O15) |
| Assegna le selezionate (0.5.0) | Lavoro › Verifiche | Caselle a sinistra delle righe (O17) |
| **Verbali con VerbalizzAI 0.3.32.1** (0.6.0) | Lavoro › Verbali | La versione di VerbalizzAI che va in produzione: stato tecnico dell'impianto per modulo, **anteprima PDF obbligatoria prima della firma** («Anteprima PDF» → «Firma ed emetti» dentro l'anteprima), all'emissione si sceglie se confermare lo stato dell'impianto per le verifiche future |
| **Un'anagrafica sola** (0.6.0) | Lavoro › Clienti / Sedi / Impianti | Nella pagina Verbali non ci sono più «Nuovo impianto», «Modifica», «Elimina impianto» e «Nuova verifica»: clienti, sedi e impianti si creano e correggono nel gestionale, il verbale nasce **solo** dalla verifica («Compila il verbale»), che gli dà il numero. Il server rifiuta comunque quelle funzioni con un messaggio che dice dove andare |
| Stato tecnico dell'impianto (0.6.0) | permesso «Confermare e correggere lo stato tecnico degli impianti» | RT e Tecnico. Senza questo permesso si emette il verbale ma senza aggiornare lo stato dell'impianto |
| Storico di ogni scheda | linguetta «Storico» | Chi ha cambiato cosa e quando (prima → dopo), dal registro delle operazioni |
| «Da controllare» | in ogni scheda e colonna delle griglie | Segnalazioni (es. dall'importazione) da sistemare; «Ho controllato» le toglie |

### Come si scrivono i filtri nelle griglie
- **Testo**: una parte del testo (maiuscole e minuscole indifferenti).
- **Numeri**: `100`, `>100`, `>=100`, `<50`, `10..20` (da 10 a 20); la virgola decimale va bene.
- **Date**: `04/10/2026` (giorno), `10/2026` (mese), `2026` (anno), `>01/01/2026`, `<=31/12/2025`, `01/01/2026..31/03/2026`.
- **vuoto**: trova i campi non compilati.

**Raggruppa** lavora sulle righe della pagina visualizzata: per raggruppare tante righe aumenta «Righe per pagina» (fino a 500).

## 4-bis. Importazione dei dati dal gestionale attuale

Sistema › Importazione dati (permesso «Importare anagrafiche», di partenza solo l'amministratore).

1. Scegli i file (anche uno solo): **Clienti** e **Sedi operative** copiati dalla griglia con copia e incolla (le righe sfalsate si riallineano da sole; se c'è una riga di intestazione con i nomi delle colonne si usa quella), **Impianti** dall'esportazione Excel.
2. **Mostra l'anteprima**: quanti clienti, sedi e impianti nuovi, quanti già presenti, l'elenco delle segnalazioni. Nulla è ancora scritto.
3. **Importa**: il programma fa prima un backup «Prima di un'importazione», poi scrive tutto in un colpo solo (o tutto o niente). I file importati restano nell'archivio documenti con la loro impronta.

Regole: si **aggiunge solo ciò che manca** (stesso nome di cliente, stessa sede dello stesso cliente, stesso codice impianto = già presente, non viene toccato), quindi si può ripetere, per esempio dopo aver ricopiato una pagina mancante. I collegamenti cliente → sede → impianto si fanno **per nome**. Partita IVA, codice fiscale, CAP e telefoni che hanno perso gli zeri iniziali in Excel vengono recuperati. I dati dubbi non fermano l'importazione: finiscono nel campo **«Da controllare»** di ogni scheda (colonna filtrabile in tutte le griglie). Il tipo di cliente viene proposto in automatico (split payment o codice ufficio di 6 caratteri → pubblica amministrazione; «condominio» nel nome → condominio; solo codice fiscale di persona → persona fisica). Per le prossime verifiche: se c'è l'ultima verifica la prossima viene ricalcolata (e, se diversa da quella del gestionale attuale, segnalata); se non c'è resta quella del gestionale attuale.

## 5. Permessi di partenza

Al primo avvio i quattro ruoli (Amministratore, Responsabile tecnico, Tecnico, Segreteria) ricevono i permessi approvati nel documento 07: il Responsabile tecnico assegna le verifiche e fa il riesame dei verbali, il Tecnico (verificatore) programma, registra e carica il verbale delle proprie verifiche, la Segreteria fa preventivi e fatture, il riesame del contratto lo possono fare entrambi; esportare in Excel e sbloccare gli sconti solo l'Amministratore. Si cambiano da «Ruoli e permessi» e valgono subito.

Dalla 0.6.0 c'è il permesso «**Confermare e correggere lo stato tecnico degli impianti**» (RT e Tecnico): è il permesso di VerbalizzAI 0.3.32.1 che, all'emissione, aggiorna le caratteristiche e gli elementi dell'impianto riproposti alla verifica successiva. Su un archivio esistente il permesso viene aggiunto da solo ai ruoli RT e Tecnico.

Dalla 0.2.0 sono attive anche: vedere l'anagrafica (RT, Tecnico, Segreteria), modificare clienti, sedi, impianti e dismettere (RT, Segreteria), disattivare clienti e sedi e gestire i commerciali (Segreteria), vedere tariffario e scadenze (RT, Segreteria), gestire il tariffario, importare, impostazioni/elenchi e sbloccare gli sconti (solo Amministratore). Chi non ha il permesso di modifica vede le schede in sola lettura.

## 6. Backup e ripristino

- **Automatici**: uno all'avvio se l'ultimo ha più di 24 ore, poi uno ogni 4 ore di uso. Si conservano gli ultimi 30 automatici; gli altri backup (manuali, caricati, «prima di un ripristino», «prima di un aggiornamento») il programma non li cancella mai.
- **Dove**: cartella `GestionaleAD_dati\backup`. **Copia regolarmente questa cartella fuori dal PC** (chiavetta, NAS, cloud): un backup che sta sullo stesso disco non protegge da un guasto del disco.
- **Ripristino**: Backup e integrità › clic sul backup › «Ripristina…» › scrivi RIPRISTINA. Il programma prima **verifica** il backup (impronte, integrità del database, versione), poi salva lo stato attuale in un backup «Prima di un ripristino» (così si torna indietro), poi ripristina. Dopo, tutti devono accedere di nuovo.
- **Controllo di integrità**: verifica database, collegamenti tra i dati, catena del registro e impronte dei documenti (con molti anni di registro può richiedere qualche secondo).

**Procedura di ripristino da provare periodicamente** (condizione 1 del documento 01): crea un backup, scaricalo, caricalo con «Carica backup…», verificalo, ripristinalo, controlla i dati, fai il controllo di integrità.

Dalla 0.5.0 il backup comprende anche l'**archivio dei verbali** (`verbali\verbali.adbackup.zip` dentro il file di backup, con tutti i documenti) e il ripristino lo riporta indietro insieme al resto. VerbalizzAI fa inoltre le sue copie automatiche in `GestionaleAD_dati\verbali\backups`.

## 7. Aggiornare a una nuova versione

1. Chiudi il programma (finestra nera).
2. Scompatta la nuova versione **accanto** alla vecchia (es. `C:\VerbalizzAI\Gestionale_AD_v0.2.0` accanto a `C:\VerbalizzAI\Gestionale_AD_v0.1.0`).
3. Esegui `INSTALLA_WINDOWS.bat` nella nuova cartella e avvia da lì: dalla 0.4.0 copia da solo il `config.json` della versione precedente (cartelle `Gestionale_AD_v*` accanto). **Tieni la cartella dei dati fuori dalle cartelle delle versioni** (`cartella_dati` in `config.json`): così ogni versione nuova ritrova lo stesso archivio.
4. Il programma ritrova i dati in `GestionaleAD_dati`; se la struttura dei dati cambia, **fa da solo un backup «Prima di un aggiornamento»** e poi aggiorna.
5. Se si apre un database creato da una versione più nuova del programma, il programma si ferma senza toccare nulla.
6. Dalla 0.5.0 il programma scrive da solo in `config.json` la cartella dei dati in uso (`cartella_dati`), se manca; se l'archivio è vuoto lo dice all'avvio e nella pagina iniziale (O16).
7. **Dalla 0.5.0 alla 0.6.0** (VerbalizzAI 0.3.25 → 0.3.32.1): al primo avvio l'archivio dei verbali viene **convertito da solo al formato nuovo** (formato 2, stato tecnico per modulo), dopo averne fatto una copia `prima_schema2_….adbackup.zip` in `GestionaleAD_dati\verbali\backups`. Le **bozze aperte prima della conversione** chiedono una conferma: in Verbali, nella bozza, «**Confronta stato impianto**» (oppure, all'emissione, non aggiornare lo stato dell'impianto); senza, l'emissione risponde che lo stato dell'impianto è cambiato. È il comportamento previsto da VerbalizzAI.
8. **Modelli Word dei verbali**: un archivio **nuovo** riceve i modelli M01, M02, M03 rev. 02 di VerbalizzAI 0.3.32.1; un archivio **esistente tiene i suoi** (nessun modello viene sostituito di nascosto). Per usare i nuovi: Verbali › Risorse › Template Word, caricando i file `gestionale\terzi\verbalizzai\modelli\M0?-PO01_dpr_rev02.docx`.

## 8. Archivio di prova (velocità)

`AVVIA_PROVA_WINDOWS.bat` crea (la prima volta, circa 15 secondi) e apre un archivio **separato** `GestionaleAD_dati_PROVA` con 300.000 righe di registro simulate, pari a circa 10 anni. Utente `prova`, password `archivio simulato 2016`. Serve a provare la velocità delle griglie; non tocca mai l'archivio vero.

## 8-bis. Ambiente di prova dei verbali (0.6.0)

`AVVIA_TEST_WINDOWS.bat` apre un archivio **separato**, `GestionaleAD_dati_TEST` (accanto alla cartella del programma), con dati **finti** pronti per provare il percorso completo preventivo → verifica → verbale. Non tocca mai l'archivio vero (`GestionaleAD_dati`) né quello per la velocità (`GestionaleAD_dati_PROVA`). La prima volta installa gli strumenti di prova (`requirements-sviluppo.txt`) e crea i dati (circa 20 secondi); le volte successive riapre lo stesso archivio, con quello che hai fatto. `RICREA_AMBIENTE_DI_PROVA_WINDOWS.bat` lo cancella e lo ricrea da zero (chiede di scrivere SI).

| Utente | Ruolo | Cosa trova |
|---|---|---|
| `admin` | Amministratore | tutto |
| `responsabile` | Responsabile tecnico | verifiche da assegnare (preventivi P3 e P4), riesami |
| `tecnico1` | Tecnico | **2 verifiche registrate** (VP/001, VP/002): «Compila il verbale» |
| `tecnico2` | Tecnico | 1 verifica registrata, 1 solo assegnata (da programmare e registrare) |
| `segreteria` | Segreteria | clienti, preventivi (uno ancora «creato» da completare) |

Password per tutti: **`password di prova`**. Firme grafiche finte (una riga) già caricate per admin, responsabile, tecnico1 e tecnico2. Quattro clienti finti (un'azienda, una con due sedi, un Comune come pubblica amministrazione, una con pericolo di esplosione), 8 impianti (terra fino e oltre 1.000 V, scariche atmosferiche, esplosione), indirizzi email `@esempio.invalid` (nessuna email parte davvero: il server di posta non è impostato).

Percorso consigliato: entra come `tecnico1` → Lavoro › Verifiche → ✎ su VP/001 → «Compila il verbale» → nel verbale (M01) compila almeno **Potenza** e l'**esito** (Positivo/Negativo; senza esito «Firma ed emetti» resta spento) → «Anteprima PDF» → «Firma ed emetti» → «← Torna al gestionale»: la verifica è **eseguita**. Poi entra come `responsabile` per il riesame del verbale (prova anche «Non conforme»: la verifica torna «registrata» e «Compila il verbale» apre la revisione).

Si può crearlo anche altrove: `.venv\Scripts\python.exe strumenti\crea_ambiente_di_prova.py --cartella C:\percorso`.

## 8-ter. Archivio importato dal database di Garda (0.7.1)

Crea un archivio **nuovo e separato** (`GestionaleAD_dati_GARDA`, accanto alla cartella del programma) con i dati veri di AD_dpr presi dal **dump del database di Garda** (`ingecert`, esportazione SQL completa fatta con HeidiSQL). Il database di Garda non viene toccato: si legge solo il file.

1. Doppio clic su **`IMPORTA_DA_GARDA_WINDOWS.bat`** e trascina nella finestra il file `.sql` (oppure trascina il file sopra il .bat). In pochi secondi crea l'archivio e mostra il riepilogo.
2. **Scrivi la password provvisoria di `admin`** che compare alla fine: non viene salvata da nessuna parte. Al primo accesso il programma chiede di cambiarla.
3. Doppio clic su **`AVVIA_GARDA_WINDOWS.bat`** e accedi come `admin`.
4. Il rapporto completo è in `GestionaleAD_dati_GARDA\importazione_garda.txt`: cosa è stato importato, le segnalazioni «da controllare» (anche nelle schede e nelle griglie, colonna «Da controllare») e la **quadratura dei totali** dei preventivi con quelli di Garda.

Cosa entra:
- **utenti** di AD (non quello di Garda Informatica) **disattivati**: le password di Garda non si possono riusare. Da Sistema › Utenti si riattivano e si dà a ciascuno una password provvisoria; ruoli: Responsabile tecnico e Sostituto → Responsabile tecnico, Tecnico → Tecnico, Referente commerciale → Segreteria, Amministratore → Amministratore;
- **commerciali**, modalità di pagamento e aliquote IVA usate;
- **clienti, sedi operative, impianti** (POD, matricole, zone, aste e gabbie), con il **codice di Garda** in «Riferimento nel gestionale attuale» e i collegamenti per codice, non per nome. Ultima e prossima verifica **come sono in Garda** (la data la scriveva il tecnico, documento 11 R1);
- **preventivi e righe** con gli stessi numeri, stati, tariffe e sconti; **contributo INAIL 5%** e **indennità di trasferta** come righe «a corpo», così il totale è quello di Garda; riesame del contratto; CIG, CUP, documento d'ordine e «fatturato» nelle note. Il preventivo 454/2025 doppio in Garda (serie «2025_annullato») entra come rev. 1;
- **verifiche** con gli stessi numeri di verbale VP/VS, stato (effettuata + riesame conforme = «riesaminata»), verificatore, date, esito, riesame; nelle note affiancamento, dichiarazione di assenza di conflitti e **se è già fatturata in Garda**. Il PDF del verbale resta nell'archivio di Garda: nella verifica c'è il nome del file.
- Le **numerazioni proseguono** da sole dall'ultimo numero importato (preventivi e verbali, D76).

Non entra (per ora): fatture e pagamenti (fase 6), i PDF dei verbali (archivio S3 di Garda), l'archivio di VerbalizzAI (si aggiunge con Sistema › Verbali di VerbalizzAI).

**Dalla 0.12.4 anche AD_dm.** `IMPORTA_DA_GARDA_WINDOWS.bat`, dopo il file di ingecert, chiede quello di `adsrl` (Invio per saltarlo); su un archivio GARDA già creato si aggiunge con `AGGIUNGI_ADSRL_WINDOWS.bat`, una volta sola. Entrano: clienti (fusi con quelli di ingecert se hanno la stessa partita IVA o lo stesso codice fiscale, con una nota; gli altri con «Rif. gestionale attuale» `dm:<codice>`), sedi operative (quelle chiuse in Garda come non attive; dalla 0.12.5 quella con lo stesso indirizzo di una sede DPR dello stesso cliente si unisce a quella, le altre coppie probabili si confermano in Sedi operative › «Possibili doppioni»), attrezzature SC/SP/GVR con matricole, classificazione, dati della scheda, camere GVR, date ultima/prossima per componente (funzionamento, integrità, interna, CND, SC/SP, supplementare) come **date iniziali dichiarate** con il numero dell'ultimo verbale di Garda nella nota, accessori con tarature e collegamenti. Rapporto: `importazione_garda_adsrl.txt`, con la quadratura. Non entrano ancora: preventivi, verbali e fatture AD_dm; il database `iec`.

Per rifarla da capo: chiudi il programma, cancella la cartella `GestionaleAD_dati_GARDA` e rilancia `IMPORTA_DA_GARDA_WINDOWS.bat`. A riga di comando: `.venv\Scripts\python.exe strumenti\importa_da_garda.py dump.sql --cartella C:\altra\cartella`.

## 9. Test automatici

`ESEGUI_TEST_WINDOWS.bat` installa gli strumenti di prova ed esegue i 107 test automatici (circa due minuti). Devono risultare tutti «passed». Coprono: accesso e blocco, protezioni anti-contraffazione, permessi controllati dal server, password provvisoria, ruoli, ultimo amministratore, modifiche concorrenti, registro non modificabile e catena di impronte, documenti con impronta, backup/verifica/ripristino (anche di un backup alterato), migrazioni, filtri ed esportazione delle griglie, velocità con 300.000 righe (ogni pagina sotto mezzo secondo); dalla 0.2.0 anche controlli di P.IVA, CF, IBAN, POD, regole degli impianti e della scadenza, cancellazioni protette, griglie con le colonne collegate (ogni colonna di ogni griglia ordinata e filtrata), tariffario con versioni e scaglioni, importazione con anteprima (senza doppioni se ripetuta), aggiornamento di un archivio della 0.1.0; dalla 0.6.0 anche il **contratto tra gestionale e VerbalizzAI** (`tests/test_ponte_contratto.py`: versione dichiarata, codice di VerbalizzAI non modificato salvo gli import, funzioni e permessi usati dal ponte, conversione di un archivio dei verbali della 0.5.0) e l'anteprima obbligatoria prima della firma. Il loro esito è un'evidenza per la validazione ISO/IEC 17020 § 6.2.9.

## 10. Prova di accettazione della 0.7.1

1. `IMPORTA_DA_GARDA_WINDOWS.bat` con il dump di `ingecert`: il riepilogo deve dire 1.910 clienti, 2.674 sedi, 2.694 impianti, 1.009 preventivi, 1.866 righe, 1.438 verifiche e **0 differenze** nella quadratura dei totali.
2. `AVVIA_GARDA_WINDOWS.bat`, accesso come `admin` (cambio della password provvisoria).
3. Controlla a campione 5 clienti, 5 impianti e 5 preventivi confrontandoli con Garda (numeri, stati, importi, righe INAIL e trasferta).
4. Verifiche: controlla che numeri VP/VS, verificatore ed esito coincidano con Garda; nelle note di quelle fatturate «FATTURATA in Garda».
5. Scadenze: le prossime verifiche coincidono con lo scadenziario di Garda.
6. Sistema › Utenti: riattiva il tuo utente con una password provvisoria ed entra con quello.
7. Nuovo preventivo: prende il numero successivo all'ultimo di Garda.

### Prova di accettazione della 0.7.0

1. Ambiente di prova (§ 8-bis), utente `segreteria`: Lavoro › Preventivi, apri il preventivo P_005 («Creato»), linguetta Documenti e invii: «Non ancora preparato».
2. «👁 Anteprima»: si apre «Controlla il documento» con il PDF; nella linguetta compaiono Word e PDF «attuali». Chiudi e riapri: è lo stesso documento (non ne prepara un altro).
3. **Ritocco**: «Scarica il Word», aprilo in Word, cambia **solo** un margine o aggiungi un a capo vuoto, salva; «Carica il Word ritoccato…»: accettato, il PDF nuovo è da approvare. Riprova cambiando una parola o un importo nel Word: **rifiutato**.
4. «Invia email…» o «Segna come inviato» **prima** di approvare: il programma apre il documento da controllare. «Approvo questo documento», poi «Segna inviato»: in Documenti e invii il PDF risulta approvato e nell'elenco degli invii «segnato come inviato a mano».
5. Su un altro preventivo «creato»: approva, poi cambia le note e salva → il documento non vale più (va ricontrollato); rimetti le note com'erano → torna valido quello approvato.
6. Preventivo già inviato: «👁 Anteprima» mostra il documento inviato, senza ritocchi né approvazione; «Stampa» stampa quello.
7. Test automatici tutti superati.

### Prova di accettazione della 0.6.0

1. **Ambiente di prova** (§ 8-bis): fai tutto il percorso con `tecnico1` fino alla verifica «eseguita»; controlla nella scheda della verifica esito, prossima verifica e documenti (Word e PDF firmati).
2. Nella pagina Verbali **non** ci sono «Nuovo impianto», «Modifica» dell'impianto, «Nuova verifica»: l'anagrafica si cambia solo nel gestionale. Cambia l'indirizzo di una sede nel gestionale e riapri il verbale con «Riprendi il verbale»: l'indirizzo nuovo c'è.
3. Togli al ruolo Tecnico il permesso «Confermare e correggere lo stato tecnico degli impianti»: `tecnico2` emette lo stesso il suo verbale, ma senza aggiornare lo stato dell'impianto. Rimetti il permesso.
4. **Archivio vero della 0.5.0** (copia!): avvia la 0.6.0 su una **copia** della cartella dei dati: l'archivio dei verbali si converte (copia `prima_schema2_…` in `verbali\backups`), i verbali emessi si aprono, una bozza vecchia chiede «Confronta stato impianto».
5. Test automatici tutti superati (`ESEGUI_TEST_WINDOWS.bat`).

### Prova di accettazione della 0.5.0

1. **Importazione**: Sistema › Verbali di VerbalizzAI › carica il backup completo di VerbalizzAI (in VerbalizzAI: Backup e ripristino › «Backup completo»). Controlla il riepilogo delle proposte.
2. «**Collega le proposte sicure**»; poi controlla alcune «probabili» (Collega) e alcune «da scegliere» (Scegli…). Apri la scheda di un impianto collegato: ultima e prossima verifica, caratteristiche ed elementi dall'ultimo verbale.
3. **Verbali**: apri Lavoro › Verbali e controlla clienti e impianti, storico, strumenti, firme (carica la tua firma), modelli Word.
4. **Verifica → verbale**: assegna (prova «Assegna le selezionate…» con due verifiche), registra, «**Compila il verbale**»: numero, data, verificatore, cliente e indirizzo sono già scritti, i dati vengono dal verbale precedente. Compila, «Emetti verbale», poi «← Torna al gestionale»: la verifica è «eseguita» e l'impianto aggiornato.
5. Dal verbale emesso «Invia per email» (con il server di posta impostato in Sistema › Impostazioni email).
6. **Annulla** il verbale emesso in Verbali: la verifica torna «registrata»; ricompila ed emetti di nuovo.
7. **Backup**: crea un backup, controlla che sia valido; ripristinalo e controlla che i verbali ci siano.
8. **O15**: preventivo inviato → «Sconto (con revisione)…» → nasce la rev. 1 con lo sconto e la data di oggi; la rev. 0 resta com'era.
9. **O16**: avvia la nuova versione e controlla in `config.json` la riga `cartella_dati`.
10. Test automatici tutti superati.

### Prova di accettazione della 0.4.0 (documento 10)

1. **Tariffario**: controlla le voci nuove (valide dal 30/09/2026) con «Prova il calcolo»: 2 kW → € 50 con avviso «a ore»; scariche con 3 aste → € 200; gabbia 101–350 m² → € 200.
2. **Preventivo**: dallo scadenziario ⚡ con la data e il campo «Preventivo» vuoto (nuovo); poi ⚡ di nuovo scrivendo il numero di quel preventivo (si aggiunge). Prova un impianto con pericolo di esplosione: la riga è «a ore», scrivi le ore e salva. «＋ Voce / a corpo»: trasferta (scegli la voce dell'elenco) e un importo a corpo.
3. **Anteprima** e **Stampa**; poi «Genera Word», sistemalo in Word, salva anche il PDF da Word e caricali con «Carica versione ritoccata»: Stampa ora apre quello.
4. Modello **rev. 04**: controlla l'impaginazione (riquadro sotto «Volpiano, lì», condizioni a pagina 2) e approvalo o correggilo.
5. Segna inviato, accetta le righe, **riesame del contratto conforme** → nella linguetta Riesame compaiono le verifiche.
6. **Verifiche**: «Da assegnare» → assegna a un verificatore (RT) → entra come verificatore: vede solo le sue; programma, poi **registra** (numero VP/001/26).
7. Fai il verbale in **VerbalizzAI** scrivendo quel numero, emettilo e **carica il Word** nella verifica: diventa «eseguita», nella scheda dell'impianto compaiono ultima e prossima verifica, caratteristiche ed elementi. Prova anche un Word con numero sbagliato (deve essere rifiutato).
8. **Riesame del verbale** (RT): non conforme → torna «registrata»; ricarica e riesame conforme → «riesaminata (da fatturare)».
9. «Salva e chiudi» in una scheda; «Nuova sede» da «Sedi ← Cliente» (cliente già scelto); un impianto con pericolo di esplosione non accetta 5 anni.
10. Test automatici tutti superati.

### Prova di accettazione della 0.3.1

1. Leggibilità: le pagine usano il testo più grande (variante B). In «Il mio profilo» prova «Grande» e torna a «Normale».
2. Negli elenchi, passa col mouse su una cella tagliata («Messa a terra fino a 1.00…»): compare il testo intero.
3. Preventivo: «🖨 Stampa» in basso → il PDF si apre in una nuova scheda; stampalo. Ripeti: si riapre lo stesso PDF (nessuna copia nuova in «Documenti e invii»). Cambia un dato senza salvare e premi Stampa → chiede di salvare.
4. Preventivo già inviato: «Stampa» apre il PDF inviato al cliente.
5. Modello M01-RG01_dpr rev. 03: codice e revisione ora in calce a sinistra (all'altezza di «pag. 1»), non più in alto. L'aggiornamento della rev. 03 fornita dal programma è automatico (resta nel registro).

### Prova di accettazione della 0.3.0 (documento 09)

1. Impostazioni email: server, password, «Invia una email di prova» a te stesso.
2. Modelli Word: scarica la rev. 03 e confrontala con la rev. 02 (cambia solo la tariffa applicata in tabella e la revisione nel piè di pagina); approvala o carica la tua.
3. Scadenze: filtro «Da preventivare», seleziona più impianti dello stesso cliente (es. un Comune), «⚡ Preventivo» → nuovo preventivo con le righe e i prezzi giusti.
4. Nel preventivo: cambia modalità di pagamento e termine, aggiungi/togli impianti, «Genera Word e PDF», controlla il documento.
5. Sconto: prima rifiutato (cliente bloccato), poi sblocca gli sconti sul cliente e applicalo.
6. «Invia email…» a un tuo indirizzo → stato «inviato»; prova a cambiare una riga (rifiutato) → «Crea revisione» → rev. 1.
7. Accetta una riga → «accettato parzialmente», preventivo fissato; registra il riesame; controlla «Righe dei preventivi» → «Accettate (da organizzare)».
8. Annulla un preventivo con motivo; elimina un preventivo mai inviato.
9. Test automatici tutti superati.

### Prova di accettazione della 0.2.0 (documento 08)

1. Aggiornamento: avviare la 0.2.0 sull'archivio della 0.1.0 → in «Backup e integrità» c'è il backup «Prima di un aggiornamento»; utenti e ruoli sono rimasti.
2. Importazione dei tre file → anteprima → importa; controllare i numeri e qualche scheda a campione rispetto al gestionale attuale (clienti con molte sedi, una PA, un impianto oltre 1.000 V, uno con più POD, uno con gabbia, uno dismesso).
3. Clienti / sedi / impianti: creare, modificare (vedere lo storico), provare dati sbagliati (P.IVA, POD, cabine su impianto fino a 1.000 V), eliminare uno senza collegamenti, disattivare uno con collegamenti.
4. Prossima verifica: inserire un'ultima verifica e controllare la data calcolata; dismettere un impianto e verificare che sparisca dalle scadenze.
5. Griglie: in Sedi e Impianti filtrare per un dato del cliente (es. tipo «Pubblica amministrazione»), salvare una vista, esportare in Excel.
6. Tariffario: «Prova il calcolo» con alcune potenze; aggiungere una versione futura degli importi e controllare che oggi valga ancora la vecchia.
7. Permessi: un utente Tecnico vede l'anagrafica ma non la modifica e non vede le scadenze.
8. Test automatici tutti superati.

### Prova di accettazione della 0.1.0 (documento 07)

1. Avvio con doppio clic, creazione dell'amministratore, accesso.
2. Creare un ruolo nuovo, assegnargli permessi, creare un utente con quel ruolo; entrare con quell'utente e verificare che veda/possa fare solo ciò che ha.
3. 5 password sbagliate → blocco; sblocco dall'amministratore.
4. Registro: trovare le operazioni appena fatte, filtrare, nascondere colonne, salvare una vista, esportare in Excel solo le colonne visibili.
5. Backup manuale → verifica → ripristino.
6. Test automatici tutti superati.

## 11. Per la persona tecnica di riferimento

- **Tecnologia** (D30–D33): Python 3.12, FastAPI, SQLAlchemy 2 + Alembic (migrazioni in `gestionale/migrazioni/versions`), SQLite in modalità WAL con chiavi esterne, Jinja2, Tabulator 6.6.1 (MIT, copiato in `static/vendor`), openpyxl. Dipendenze a versione bloccata in `requirements.txt`.
- **Struttura**: `gestionale/core` (configurazione, database, permessi, sicurezza, motore delle griglie, migrazioni), `gestionale/moduli/<modulo>` (modelli, servizio = regole, api = interfaccia JSON, griglie), `gestionale/web` (pagine e controlli comuni), `templates`, `static`, `tests`.
- **Regole**: le regole stanno nei servizi lato server; ogni scrittura passa da `Archivio.scrittura()` (transazione, un solo scrittore: il programma gira in **un solo processo**); ogni operazione critica scrive nel registro; nessuna cancellazione distruttiva; importi in centesimi, date in UTC nel database.
- **Sicurezza**: password PBKDF2-SHA256 600.000 iterazioni; sessione in cookie HttpOnly SameSite=Strict (Secure con `"https": true`); codice anti-contraffazione per ogni richiesta di modifica; controllo dell'origine; intestazioni CSP senza script e stili in linea; nessuna risorsa da Internet.
- **Nuovo modulo**: modelli in `moduli/<x>/modelli.py` + importazione in `gestionale/modelli.py`; migrazione con `alembic revision --autogenerate` (controllare a mano); nuove micro-attività in `core/permessi.py`; griglie con `core.griglia.registra(...)`; test in `tests/`.
- **Griglie con tabelle collegate**: usare unioni «piatte» (`a.join(b).join(c).outerjoin(d)`), mai unioni annidate con LEFT JOIN dentro parentesi: SQLite 3.45.1 (quello di Ubuntu 24.04) va in crash. Il test `test_tutte_le_griglie_ogni_colonna` lo controlla.
- **Colonne calcolate** (es. tariffa proposta): `Colonna(..., calcolata=True)` + `Griglia(arricchisci=...)`; non si filtrano né si ordinano.
- **Dati di riferimento**: elenco dei comuni in `gestionale/dati/comuni_istat.csv`, caricato al primo avvio. Fonte: archivio ISTAT (licenza CC BY 3.0 IT) nella versione raccolta da github.com/matteocontrini/comuni-json (ottobre 2026); i CAP di quella raccolta vengono da fonti varie senza licenza dichiarata: uso interno, da verificare se il programma venisse distribuito ad altri. Vedi `gestionale/dati/LEGGIMI_DATI.md`.
- **VerbalizzAI incorporato (D67, D78)**: copia di **VerbalizzAI 0.3.32.1** in `gestionale/terzi/verbalizzai` (modificati solo gli `import`, resi relativi; vedi `VERSIONI_VerbalizzAI.md`). Il gestionale ne usa l'archivio (`storage.Archive`, sottoclasse `moduli/verbali/archivio.py`: utenti e permessi dal gestionale), il server (`app.Handler` richiamato in memoria da `moduli/verbali/ponte.py`, che esclude login, utenti, backup, creazione/modifica/eliminazione degli impianti e bozze nate fuori da una verifica) e la pagina (`static/`, servita da `/verbali` con «/api/» → «/verbali/api/»; `static/css/ponte_verbali.css` nasconde i pulsanti dell'anagrafica). Chi possiede cosa (documento 15): il **gestionale** anagrafica, numeri dei verbali, tariffe e scadenze; **VerbalizzAI** lo stato tecnico e gli elementi degli impianti. All'emissione il gestionale prende esito, prossima verifica e caratteristiche **dai dati del verbale compilato** (non rilegge il Word).
- **Aggiornare VerbalizzAI** (versioni future): `python strumenti/aggiorna_verbalizzai.py <cartella o zip di VerbalizzAI>` copia i file, toglie quelli che non ci sono più, rende relativi gli import, controlla che nessun import assoluto resti e che tutto si compili, aggiorna `VERSIONE` e `VERSIONI_VerbalizzAI.md`. Poi **tutti i test**: `tests/test_ponte_contratto.py` dice subito se la nuova versione ha cambiato qualcosa che il gestionale usa (firme delle funzioni, percorsi, permessi, formato dell'archivio); infine l'ambiente di prova nel browser.
- **VPS (più avanti, D28)**: dietro un proxy HTTPS (es. nginx) con `"https": true` e `"indirizzo": "127.0.0.1"`; servizio di sistema che esegue `python -m gestionale`; backup notturno della cartella `backup` verso l'ufficio.

## 12. Limiti noti della 0.7.1
- Archivio importato da Garda: le verifiche già fatturate in Garda risultano «Riesaminate (da fatturare)» (lo dicono le note): con la fase 6 entreranno anche le fatture e questo si sistema.
- Le verifiche «assegnate» e «programmate» in Garda sono assegnate a utenti disattivati finché non li riattivi.
- I PDF dei verbali di Garda non sono copiati (sono sullo storage S3 di Garda).

### Limiti noti della 0.7.0
- **Ritocchi fatti in Word**: il controllo confronta testo, caselle, campi e immagini. Se Word, salvando, ricomprime un'immagine (es. il logo), il ritocco viene rifiutato: in Word, File › Opzioni › Impostazioni avanzate › Dimensioni e qualità immagine › «Non comprimere le immagini nel file». Il PDF lo rifà LibreOffice: l'impaginazione può differire di poco da quella vista in Word (scelta A di D80).
- Preventivi inviati prima della 0.7.0 senza PDF archiviato («segnati come inviati»): l'anteprima ricostruisce il PDF dai dati una volta, poi usa sempre quello.
- Per preparare il documento serve LibreOffice (come prima per il PDF).

### Limiti noti della 0.6.0
- Il numero del verbale del gestionale riparte da 1 (ambiente di prova): il numero di partenza si imposta al passaggio.
- Un **impianto nuovo** (mai verbalizzato) apre la prima bozza con i dati tecnici vuoti: potenza, tensione, POD scritti nella scheda dell'impianto del gestionale **non** vengono ancora copiati nel verbale (chi possiede lo stato tecnico è una delle domande aperte del documento 15).
- **Per VerbalizzAI** (il suo codice qui non si tocca): il lettore dei Word di VerbalizzAI 0.3.32.1 non riconosce 10 gruppi di caselle dei modelli rev. 02 (protezioni, DiCo, progetto, DiRi, …). Nel gestionale non pesa per i verbali compilati qui (si usano i dati, non il Word); pesa per «Oppure carica il verbale già fatto in Word» e per l'importazione di Word storici rev. 02 in VerbalizzAI.
- Le bozze aperte prima della conversione al formato 2 vanno confermate con «Confronta stato impianto» (§ 7).
- Dopo un **riesame non conforme** «Compila il verbale» apre la **revisione** del verbale emesso; se il verbale precedente aveva aggiornato lo stato dell'impianto, per emetterla VerbalizzAI chiede «Confronta stato impianto» (oppure emissione senza aggiornare lo stato).
- «Unisci più verifiche in un verbale» (casi rari, V4) non c'è ancora. Fatturazione: fase 6.

### Limiti noti della 0.5.0
- Il numero del verbale del gestionale riparte da 1 (ambiente di prova): il numero di partenza si imposta al passaggio, dopo l'importazione dell'archivio di VerbalizzAI.
- Nella pagina Verbali alcune voci di VerbalizzAI restano nel gestionale: utenti, password, backup e correzione dell'anagrafica (cliente, sede, indirizzo) si fanno dal gestionale; «Impostazioni email» di VerbalizzAI mostra il server del gestionale e permette solo di cambiare i testi.
- Un verbale nuovo creato direttamente nella pagina Verbali (senza passare dalla verifica) non aggiorna nessuna verifica: si parte sempre da «Compila il verbale» (dalla 0.6.0 non si può più crearlo).
- Collegamento dell'archivio: gli impianti di scariche (M02) e pericolo di esplosione (M03) mancanti nella sede vanno creati a mano (servono dati per la tariffa che il verbale non ha); poi «Scegli…» di nuovo.
- «Unisci più verifiche in un verbale» (casi rari, V4) non c'è ancora. Fatturazione: fase 6.

### Limiti noti della 0.4.0
- Il verbale si compilava ancora in VerbalizzAI (superato dalla 0.5.0).

### Limiti noti della 0.3.1
- La stampa apre il PDF nel browser: la stampa vera e propria si avvia con l'icona della stampante o Ctrl+P (per sicurezza il programma non stampa da solo).
- Le viste salvate prima della 0.3.1 mantengono le larghezze di colonna di allora: se le colonne risultano strette, allargale e salva di nuovo la vista.

### Limiti noti della 0.3.0
- Il riesame non blocca ancora nulla: lo farà con gli incarichi (fase 5).
- Righe senza impianto (es. sopralluogo a vuoto) non previste (da decidere).
- Fatturazione dei preventivi: fase 6.

### Limiti noti della 0.2.0
- Raggruppamento solo sulle righe della pagina visualizzata.
- L'ultima verifica degli impianti si scrive ancora a mano (o arriva dall'importazione): il calcolo dai verbali emessi arriva con il collegamento a VerbalizzAI (fase 5).
- Tariffario: caricata solo la tariffa terre del gestionale attuale; le altre voci (aste, gabbie, cabine, zone, sopralluogo a vuoto) vanno create da menu quando avremo il tariffario M03-RG01_dpr.
- Nei campi data il formato dipende dalla lingua del browser (su Windows in italiano: gg/mm/aaaa).

## Ambienti operativi e indirizzi di accesso

Un backend e un database applicativo comuni, tre ambienti di navigazione: **AD_DPR**, **AD_DM** (GVR/SC/SP) e **I&C S.r.l.** Il selettore Attività mantiene le anagrafiche comuni, filtra il menu e non concede permessi. Le API continuano a controllare ruoli e titolarità dei lavori. La preferenza di navigazione non determina emittente, sezionale o contabilità.

Ingressi locali già disponibili: `/ad-dpr`, `/ad-dm`, `/iec`; selezionano direttamente l’ambiente, anche arrivando da un collegamento. Le pagine comuni conservano la scelta; le pagine operative DPR/DM la rendono coerente con il modulo aperto. I&C mostra una pagina esplicita di funzioni ancora da realizzare; non espone la fatturazione DPR come se fosse I&C. Nell’ambiente DM non viene presentata la fatturazione DPR come fatturazione DM.

**Chiarimento dell’utente:** nella versione definitiva vuole indirizzi distinti per i tre ambienti, o almeno un accesso AD_DPR/AD_DM e uno separato I&C. Questo è acquisito. Due o tre URL/nomi host sono configurazioni di ingresso della stessa applicazione, non tre gestionali da mantenere. La configurazione dei domini, del proxy e delle autorizzazioni per ambito in produzione è ancora da realizzare; gli ingressi locali non sono una prova di separazione dei domini o di isolamento dei dati. Il selettore è utile al collaudo e agli utenti autorizzati su più attività.

Sviluppo: una sola installazione/avvio, un archivio di prova, passaggio fra le attività senza riavviare. Collaudo e produzione usano archivi distinti. AD_DM e AD_DPR appartengono ad AD S.r.l.; I&C S.r.l. mantiene emittente/contabilità distinti. Nessuna fusione di preventivi o fatture DM/DPR introdotta da questa navigazione.
