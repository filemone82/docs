@echo off
setlocal
set GESTIONALE_DATABASE_URL=
setlocal
cd /d "%~dp0"
set "GESTIONALE_CARTELLA_DATI=%~dp0Dati_Collaudo"
echo Archivio di prova: %GESTIONALE_CARTELLA_DATI%
call AVVIA_WINDOWS.bat
endlocal
