# Incremento di sviluppo 0.11.0-dev — incarichi tecnici DM

Versione 1.0 — 9 ottobre 2026. Base: checkpoint 0.10.0-dev preservato, migrazione 0013. Sviluppo del progetto unico DPR–DM–I&C; non è ancora la versione completa richiesta da R99.

## Risultato disponibile

Nuova voce **DM → Incarichi DM**, collegata anche alla scheda del preventivo. Un incarico per riga accettata dopo riesame conforme; nessuna fusione automatica delle prestazioni. Ricerca per cliente/sede/bene/matricola/codice, filtro stato e propri lavori, paginazione; assegnazione singola o multipla atomica.

Stati disponibili: da assegnare → assegnata → programmata (facoltativa) → registrata; sospensione/ripresa e annullamento con motivo. La dichiarazione di indipendenza è preselezionata, escludibile: esclusa impedisce programmazione/registrazione. Permessi comuni del DPR riutilizzati; il tecnico vede e modifica i propri lavori, chi assegna interviene per suo conto. Controllo riga accettata, ultimo RC conforme e bene/sede/cliente attivi anche nelle API.

Scheda tecnica pertinente a SC/SP o GVR, con 38 definizioni provenienti dai metadati Garda; visualizzazione condizionata per famiglia/componente. Esito, regime A1/A2 (V2 solo A2), data rilascio e prossime date della prestazione. Scelta esclusiva attrezzatura/insieme GVR, motivazione esito negativo/sospeso e dati delle prove selezionate controllati alla registrazione. Le caselle tecniche Garda inizializzate False non sono trasformate in obblighi di risposta positiva.

Il **tipo attrezzatura verbale è un campo manuale**, ad esempio RG/RV/GV/INS/TUB; disponibile nella classificazione del bene e nella bozza, distinto dall’all.7. Non è derivato dalla descrizione di catalogo. Il cambio nella bozza aggiorna il campo del bene, secondo Garda.

Camere: configurazione comune PS/TS/fluidi, litri o DN; Pes/Tes appartenenti al lavoro. Il salvataggio dalla bozza aggiorna il master e gli altri incarichi aperti nella stessa transazione. Le modifiche del master aggiornano le bozze assegnate/programmate/registrate, anche se già salvate. Chiave descrizione+numero fabbrica normalizzata; Pes/Tes mantenuti solo su chiave corrispondente e con funzionamento, mai copiati automaticamente da un precedente. Rimozioni dalla configurazione completa esplicita si propagano al master; i DN non si sommano ai litri. Non si aggiunge uno storico dei montaggi PSV.

Versioni richieste per incarico e attrezzatura impediscono sovrascritture concorrenti. **Salva e registra è una sola transazione**, comprese modifiche del bene, numero e audit: se i dati non sono validi non si registra nessuna di queste modifiche. Salva scheda tecnica conserva invece una bozza anche incompleta.

Numerazione annuale: GVR ha un contatore distinto; SC/SP condividono SC-SP. Codici tecnici `V/GVR/0001/26`, `V/SC/0001/26`, `V/SP/0002/26`. Cambio dell’anno di rilascio assegna un nuovo numero; annullamento/cambio anno non rendono riutilizzabile il precedente. Contributi in centesimi, A1 15% e A2 5% della tariffa standard della riga, secondo gli hook del backup. Non è una certificazione normativa attuale.

`data_pvp` è la minima delle prossime date delle componenti **del singolo incarico**, non la prima scadenza dell’intero bene. La registrazione non aggiorna ancora lo scadenzario come se il lavoro fosse effettuato. La fotografia commerciale del preventivo rimane separata e non viene riscritta dalla scheda corrente.

## Ambienti operativi e indirizzi di accesso

Un backend e un database applicativo comuni, tre ambienti di navigazione: **AD_DPR**, **AD_DM** (GVR/SC/SP) e **I&C S.r.l.** Il selettore Attività mantiene le anagrafiche comuni, filtra il menu e non concede permessi. Le API continuano a controllare ruoli e titolarità dei lavori. La preferenza di navigazione non determina emittente, sezionale o contabilità.

Ingressi locali già disponibili: `/ad-dpr`, `/ad-dm`, `/iec`; selezionano direttamente l’ambiente, anche arrivando da un collegamento. Le pagine comuni conservano la scelta; le pagine operative DPR/DM la rendono coerente con il modulo aperto. I&C mostra una pagina esplicita di funzioni ancora da realizzare; non espone la fatturazione DPR come se fosse I&C. Nell’ambiente DM non viene presentata la fatturazione DPR come fatturazione DM.

**Chiarimento dell’utente:** nella versione definitiva vuole indirizzi distinti per i tre ambienti, o almeno un accesso AD_DPR/AD_DM e uno separato I&C. Questo è acquisito. Due o tre URL/nomi host sono configurazioni di ingresso della stessa applicazione, non tre gestionali da mantenere. La configurazione dei domini, del proxy e delle autorizzazioni per ambito in produzione è ancora da realizzare; gli ingressi locali non sono una prova di separazione dei domini o di isolamento dei dati. Il selettore è utile al collaudo e agli utenti autorizzati su più attività.

Sviluppo: una sola installazione/avvio, un archivio di prova, passaggio fra le attività senza riavviare. Collaudo e produzione usano archivi distinti. AD_DM e AD_DPR appartengono ad AD S.r.l.; I&C S.r.l. mantiene emittente/contabilità distinti. Nessuna fusione di preventivi o fatture DM/DPR introdotta da questa navigazione.

## Limiti e lavoro successivo

Registrata non significa effettuata/emessa. Non sono ancora disponibili emissione Word/PDF DM, allegati e schede V1, riesame DM, invio/fatturazione collegata, aggiornamenti da lavori effettuati e pacchetti trimestrali INAIL. I nomi ordinari/archiviati/INAIL N01–N14 restano da applicare ai documenti, senza confonderli con il codice tecnico.

Lo storico tecnico Garda non è ancora importato nel modulo: non vengono inventati precedenti. Riproposizione selettiva dei 19 campi dai precedenti F/I/N, tecnico affiliato, dati CND della verifica e ulteriori azioni rimangono nella lista di completamento. Il JSON di bozza dichiara precedenti non disponibili. Le date CND/report già dichiarabili sulla scheda comune restano preservate. L’assenza di queste funzioni è un lavoro aperto, non una deroga approvata.

I&C, EX, completamento tariffari/azioni, import completo dei dump, motore incrementale e modello operativo Excel restano da completare. Non è stato modificato VerbalizzAI autonomo o il VPS, né richiesto S3. Incorporato ancora 0.3.32.3.

## Migrazione e prove

0013 estende `dm_incarichi` e aggiunge `dm_contatori`; nessuna riscrittura dei preventivi o delle fotografie. Test su schema 0012 popolato: ID, FK, fotografia, versione e default preservati. Il downgrade che perderebbe dati tecnici viene impedito; per riprovare la 0.10 usare il suo archivio/copia precedente.

**Prove finali:** 189 test passati nella suite completa (168 della base, 16 nuovi tecnici DM e 5 ambienti), Linux/Python 3.12.14/SQLite, 1 avviso di deprecazione del test client. Controllati schema/migrazioni rispetto ai modelli, migrazione 0012 popolata, numerazione concorrente, backup/ripristino, autorizzazioni e atomicità delle modifiche. Due prove DOM+HTTP passate con JavaScript/backend effettivi: schede/date/PSV/preventivi DM e assegnazione/programmazione/scheda tecnica/registrazione. Controlli Ruff E9/F sui file modificati e sintassi dei cinque JavaScript interessati passati. La diagnostica più ampia conserva segnalazioni preesistenti di base/terzi; VerbalizzAI incorporato non modificato. Conversione PDF delle offerte simulata nei server di prova, Windows/produzione/PostgreSQL e LibreOffice DM reale non osservati.

La prova DOM/HTTP usa JavaScript e backend effettivi: assegnazione, programmazione, dati/camere, registrazione, codice e fotografia. Conversione delle offerte simulata nel solo server di test; nessun verbale DM emesso. Windows/grafica, LibreOffice DM reale, PostgreSQL e produzione non osservati. Gli strumenti aggiuntivi sono in `report_collaudo/strumenti`; la suite ordinaria non richiede Node.

Fonti rilette: adsrl `_custom.php` salvataggio/copie/aggiornamenti/numerazione, batch generazione verifiche, `meta/verifiche.js`, `meta/attrezzature.js`, `gi_views.php`; rapporti 06/07/11, quadro 1.92 e stato 0.10. La macchina di riesame DPR non è stata applicata automaticamente al DM.
