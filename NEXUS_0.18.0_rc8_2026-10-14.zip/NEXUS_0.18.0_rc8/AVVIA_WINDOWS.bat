@echo off
chcp 65001 >nul
cd /d "%~dp0"
title NEXUS
if not exist ".venv\Scripts\python.exe" (
  echo  Prima esegui INSTALLA_WINDOWS.bat
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -c "import gestionale, fastapi" >nul 2>nul
if errorlevel 1 (
  echo  Installazione incompleta: esegui di nuovo INSTALLA_WINDOWS.bat
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m gestionale
pause
