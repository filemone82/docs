## 0.18.0 rc8 — 14 ottobre 2026

Interfaccia DPR unificata e correzioni dal collaudo di Federico del 14/10. Barra di navigazione in alto al posto del menu laterale (D3); pagina del verbale dentro NEXUS con striscia della verifica e ritorno; firma DPR e firma DM nella scheda del tecnico, pagina unica «Firme dei verificatori»; destinazioni dei documenti sul server in Configurazione (D2, copia attiva per il DM); dati della società e modalità di pagamento in Configurazione, avvisi della fattura con emittente/cliente e collegamenti; numero del verbale assegnato da NEXUS, anno della data registrata limitato a corrente ±1, codice unico, buchi annotati (B1, B2); potenza, POD, cabine e sottostazioni dell'impianto NEXUS nella bozza nuova (D1). Schema 0029 invariato. 433 test (PostgreSQL nativo compreso). Dettagli: `PASSAGGIO_CONSEGNE_NEXUS_0.18.0_rc8.md` e `PASSAGGIO_INTEGRALE_NEXUS_DPR_2026-10-14_rev4.md`.

## 0.18.0 rc1–rc7 — 13–14 ottobre 2026

Porting PostgreSQL del gestionale (rc1–rc3, migrazione 0028 dei cataloghi DM) e dei verbali DPR incorporati (rc4–rc7: schema `verbali` nella migrazione 0029, adattatore del motore, importatore dei backup completi, blocco dell'attivazione su un archivio diverso, prove native). Dettagli nei file `PASSAGGIO_CONSEGNE_NEXUS_0.18.0_rc4.md`…`rc7.md`, `COLLAUDO_POSTGRESQL_RC2.md`, `COLLAUDO_POSTGRESQL_RC3.md`, `NEXUS_DPR_POSTGRESQL_COLLAUDO.md` e documenti 46–50.

## 0.17.0 — 13 ottobre 2026

Correzioni C17–C26 e divieto di riesame del proprio verbale C28. Schema 0027 invariato. PostgreSQL e importazione completa Garda approvati come lavoro successivo. Dettagli e test effettivi: documento 44; ripresa: documento 45.

## 0.16.0 — 12 ottobre 2026

Note del collaudo «da zero» di Federico (documento di progetto 36), XML esclusi (rimandati alla fine). Date di ultima e prossima verifica alla registrazione delle attrezzature (R142, la prossima obbligatoria, «Attrezzature senza prossima verifica»); maschere delle attrezzature (sede già proposta e con suggerimenti, gruppo GVR fisso o SC/SP, «Tipo attrezzatura verbale» solo GVR) e accessori PSV a parte senza matricola INAIL (R141); PVP alla prima scadenza che entra nel preventivo (C13); collegamenti della sede per GVR, SC/SP e PSV; ambito solo sul cliente, ereditato dalle sedi (R137); più ruoli per utente a caselle (R143); accettazione e ordine sul preventivo con file e dati per la fattura elettronica, DDT e fattura principale, passaggio in fattura, avviso PA, importazione da Garda (R138); fattura anche dalle verifiche e dagli incarichi DM (R139); copia di cortesia come Garda e numero 390/2026/DPR (R140); «Prima di emettere manca: …» (C6); posta e configurazione per attività, commerciali per attività, strumenti di misura DM e I&C, firme DM (C15, C16); «Tipi e tariffe» in Configurazione; revisione e annullamento dei verbali DM (R134, R135); modelli M14 e M11 rev. 03 con la grafica di VerbalizzAI, da approvare (R136); registrazione multipla DM. Migrazioni 0023–0027. 317 test. Dettagli: `documentazione/43_Differenze_0.16.0_2026-10-12.md`.

## 0.15.0 — 12 ottobre 2026

Verbali DM come in VerbalizzAI: anteprima «BOZZA» con spazio firma riservato, riquadro firme intero e in fondo alla pagina (misura su LibreOffice), nessuna pagina bianca finale; firma DM obbligatoria; «Firma ed emetti» con la firma al posto dello spazio e controllo delle pagine; «Aggiorna / Conserva i dati del verbale». Modelli M14 e M11 di AD invariati. Schema 0022 invariato. 297 test. Dettagli: `documentazione/42_Differenze_0.15.0_2026-10-12.md`.

## 0.14.0 — 12 ottobre 2026

Fatture DPR complete pari a Garda: dati fiscali del cedente (REA, contatti) e riferimento amministrazione nell'XML; documenti collegati (ordine, contratto, convenzione, ricezione, fattura collegata) con CIG, CUP e commessa; modalità di pagamento con le regole di Garda (MP, rate, fine mese, giorno del mese dopo, spostamento 31/8 e 31/12, salda subito, predefinita) e scadenze calcolate dal preventivo, cliente o predefinita, anche importate da Garda; nome file SdI con progressivo di 5 caratteri; ricevute SdI da file (RC, NS, MC, AT, NE, DT); XML in blocco; Scadenze di pagamento; avvisi del bollo e della PA. Migrazione 0022. 292 test. Dettagli: `documentazione/41_Differenze_0.14.0_2026-10-12.md`.

## 0.13.1 — 12 ottobre 2026

Il gestionale integrato si chiama NEXUS (R133): logo e icona. Ruoli distinti per attività (R132): RT DPR, RT DM, Verificatore DPR, DM, DM e DPR; segreteria e amministratore comuni; affidamenti, riesami, elenchi, VerbalizzAI e menu per attività. Rilievi AD-REV-006 (osservazioni del combinato dall'ultimo funzionamento), 007 (nome INAIL GVR con l'attività, nessuna sovrascrittura), 008 (limite della firma DM). Migrazione 0021. 284 test. Dettagli: `documentazione/40_Differenze_0.13.1_2026-10-12.md`.

## 0.13.0 — 12 ottobre 2026

VerbalizzAI_DM, prima parte (R123): dati del verbale come attributi dell'attrezzatura (linguetta «Dati del verbale»: gruppi con provenienza, correzione a mano e storico), bozza del verbale dalla scheda (stessa regola di Garda), Pes/Tes del funzionamento precedente per confronto, firma DPR e firma DM distinte per ogni utente, copia del PDF definitivo nella cartella `cartella_verbali_dm` con nome INAIL e nome leggibile. Migrazione 0020. 276 test. Dettagli: `documentazione/39_Differenze_0.13.0_2026-10-12.md`.

## 0.12.10 — 12 ottobre 2026

Maschere AD_DM dettate da Federico (documento di progetto 30): viste di partenza per attività (colonne, raggruppamento, filtri); Clienti e Sedi; «Attrezzature GVR» e «Attrezzature SC/SP» raggruppate per sede operativa con le date per componente e le dismesse nascoste; Scadenze per sede con tipo verifica e tipo scadenza; Preventivi con fatturato e riesame; «Verifiche GVR» e «Verifiche SC/SP» con regime, fattura ed esportazione INAIL; Fatture sulla griglia con stampa rapida del PDF di cortesia, nuova pagina Fatture AD_DM. Schema 0019 invariato. 272 test. Dettagli: `documentazione/38_Differenze_0.12.10_2026-10-12.md`.

## 0.12.9 — 12 ottobre 2026

Note di collaudo del 12/10 (documento di progetto 28), uniformate fra DPR e DM. Preventivo DM solo con le verifiche dell'allegato VII D.Lgs. 81/08 di attrezzature non esenti; in Scadenze colonna «Regime», filtri «Da preventivare DM» e «Attività EX» (R129). Schede ridimensionabili, larghe in proporzione alla finestra, «a tutto schermo» (R130). Affidamento dalla linguetta «Righe» del preventivo con selezione multipla e preventivo precedente/successivo; stessa finestra di affidamento ovunque. Verifiche AD_DM sulla griglia standard con «seleziona tutte». Dati del tecnico nella scheda utente e nel profilo; nell'incarico DM la linguetta «Verbale». Termini di esecuzione configurabili. Residui del revisore AD-REV-002 (parità di data) e AD-REV-005 (righe tolte e cascate). Schema 0019 invariato. 269 test. Dettagli: `documentazione/37_Differenze_0.12.9_2026-10-12.md`.

## 0.12.8 — 11 ottobre 2026

Note di collaudo N1–N9. Revoca motivata dell'accettazione delle righe (R124), «Accetta» ripetuto senza effetto, colonna di selezione distinta dallo stato, riesame conforme non ripetibile senza motivo. Filtro «Da fatturare» e «Fattura le selezionate…» dalle righe dei preventivi, come in Garda (R125). Scadenze AD_DM selezionabili con «Prepara preventivo DM…» (una riga per scadenza, un preventivo per sede); prima periodica dalla scheda, blocco senza «soggetta a messa in servizio», colonna di tariffa visibile; sconto predefinito AD_DM del cliente (AD-13). Menu richiudibile, Gestione › Configurazione, «Tipi e tariffe» in una schermata, Utenti e permessi come in VerbalizzAI. Rilievi del revisore AD-REV-001…005 corretti e provati. ZIP di verbali al posto del backup: messaggio chiaro. Migrazione 0019. 263 test. Dettagli: `documentazione/36_Differenze_0.12.8_2026-10-11.md`.

## 0.12.7 — 11 ottobre 2026

Una sola scheda tecnica per l'impianto (R122): fa fede la «Scheda impianto» di VerbalizzAI, da cui riparte il verbale successivo; il gestionale ne tiene una copia di lettura che si riallinea da sola dopo emissione (anche con «Conserva la scheda»), correzioni e adozioni in VerbalizzAI, annullamenti, collegamenti e Word caricati; il Word caricato a mano su una verifica entra nell'archivio dei verbali e aggiorna la scheda; linguetta «Scheda tecnica» con «Modifica scheda tecnica» che apre la Scheda impianto di VerbalizzAI; potenza «250 kW» letta per le offerte. Schema 0018 invariato. 251 test. Dettagli: `documentazione/35_Differenze_0.12.7_2026-10-11.md`.

## 0.12.6 — 11 ottobre 2026

Indipendenza dichiarata solo dal verificatore assegnato, con «No» la verifica torna al RT (R119); affidamento dall'elenco delle righe dei preventivi DPR e DM; verbale precedente caricato dalla verifica e data di emissione; LibreOffice di `config.json` anche per i verbali; fusione dei clienti senza scelte silenziose e possibili doppioni dei clienti; tabella delle corrispondenze con Garda (R120, migrazione 0018); schede Cliente/Sede e Scadenze nel contesto AD_DM; correzione dei doppioni di sede; ruoli di base Amministratore, Responsabile tecnico, Verificatore (R121). 246 test. Dettagli: `documentazione/34_Differenze_0.12.6_2026-10-11.md`.

## 0.12.5 — 11 ottobre 2026

Menu per attività con le sezioni di Garda (R117): Clienti, Impianti o Attrezzature, Scadenze, Preventivi, Verifiche, Fatture, Gestione; in AD_DM elenchi completi di attrezzature e valvole di sicurezza e cataloghi Garda in sola lettura. Sedi doppie (R116, migrazione 0017): unione automatica nell'importazione adsrl delle sedi con lo stesso indirizzo di una sede DPR (71 sul dump reale), elenco dei possibili doppioni da confermare, funzione «Unisci con…». Preventivi solo nel proprio ambito (R115). Quadratura degli accoppiamenti nell'importazione (R118). 237 test. Dettagli: `documentazione/33_Differenze_0.12.5_2026-10-11.md`.

## 0.12.4 — 11 ottobre 2026

Codice da provare con i dati veri. Importazione di AD_dm (database `adsrl` di Garda) nell'archivio di prova creato da `ingecert`: clienti fusi per partita IVA/codice fiscale, sedi, 9.346 attrezzature SC/SP/GVR con camere, 3.311 accessori con tarature e collegamenti, date per componente come date iniziali dichiarate; quadratura tabella per tabella e del volume delle camere (`IMPORTA_DA_GARDA_WINDOWS.bat` chiede anche adsrl; `AGGIUNGI_ADSRL_WINDOWS.bat`). Ambiti di lavoro su clienti e sedi (R114, migrazione 0016): anagrafica unica, elenchi Clienti e Sedi filtrati sull'attività scelta in alto, indicatori accesi automaticamente da impianti, attrezzature e preventivi. Campi degli accessori nella scheda. 231 test. Dettagli: `documentazione/32_Differenze_0.12.4_2026-10-11.md`.

## 0.12.3 — 11 ottobre 2026

Correzioni dalla prima prova su Windows: ambiente di prova (`AVVIA_TEST_WINDOWS.bat`) allineato alle regole R38/R98 e arricchito con dati AD_dm; lettura in UTF-8 dell'elenco colonne INAIL e dei file nei test; soglia realistica del test di velocità del registro; ambiente di prova interrotto riconosciuto. 224 test. Dettagli: `documentazione/31_Differenze_0.12.3_2026-10-11.md`.

## 0.12.2 — 11 ottobre 2026

Passo A del documento 18 (Claude). Indipendenza bloccante in DPR e DM su programmazione, registrazione ed esecuzione (R110); riesame negativo DM: nota in evidenza per il tecnico, date CND ripristinate alla riapertura e all'annullamento, nuova chiusura con nuovo riesame (R108/R109); storico dei riesami del preventivo nell'API e nella scheda (R109); visita interna solo per famiglie GVR a2/a3, GV e INS GV (DM-07); impronte di VerbalizzAI 1.0.1 rc2 e test di identità (R111); prova della migrazione 0015 con dati e del ritorno bloccato. Schema 0015 invariato. 222 test passati. Dettagli: `documentazione/30_Differenze_0.12.2_2026-10-11.md`.

## 0.12.1-wip1 — 11 ottobre 2026

Codice in lavorazione su base 0.12.0-dev, schema 0015. Backend finanza DM, PDF fiscali e lotti INAIL presenti ma privi di test dedicati completi e nuove interfacce; transizioni tecniche DM modificate. Suite esistente: 215 passati, 1 avviso. Delta, prove e limiti nel documento 29 e nel README aggiornato. Prima di questa consegna non è stata recuperata una consegna software successiva alla 0.12. Il checkpoint non è la candidata completa.

## 0.12.0-dev — 10 ottobre 2026

Checkpoint interno con migrazione 0014: precedenti nativi selettivi, Word/PDF GVR/SC/SP dai modelli Garda originali e controllati, etichette di stampa, firma comune, ritocco controllato, PDF definitivo, chiusura/riesame DM, aggiornamento delle date per componente, CND e percorso email del definitivo. VerbalizzAI 1.0.1 rc2 conservato. Fatturazione DM collegata, INAIL, I&C, dashboard e migrazione completa ancora aperti. Stato 0.12 e rapporto 27 descrivono prove e confini; nessun rilascio in produzione.

## 0.11.1-dev — 10 ottobre 2026

Checkpoint interno di prosecuzione verso il gestionale completo. VerbalizzAI incorporato aggiornato alla 1.0.1 rc2; aggiornamento degli import multipli e sostituzione del generatore preceduta da validazione completa, con recupero della precedente versione in caso di errore di sostituzione. Schema 0013 invariato; nessun nuovo flusso DM/I&C o dashboard dichiarato completo. Vincoli e percorso nel rapporto 25, inventario iniziale delle regole e dei metadati nel rapporto 26. Le sezioni seguenti descrivono le versioni precedenti.

> 0.11.0-dev comprende anche tre ambienti selezionabili e gli ingressi locali /ad-dpr, /ad-dm, /iec. Stessa applicazione/archivio; I&C ancora da realizzare.

## 0.11.0-dev — 9 ottobre 2026

Blocco tecnico DM fino a registrata, migrazione 0013, stato e collaudo dedicati. Base 0.10 conservata; non è DM completo. Vedere `STATO_IMPLEMENTAZIONE_0.11.0-dev.md`.

## 0.9.0 — 9 ottobre 2026

Primo incremento B1a: parco comune, cataloghi Garda, camere L/DN, PSV condivise, date tecniche dichiarate, migrazione 0011 e proiezione DPR transazionale. Dodici test nuovi; flussi completi DM/I&C/INAIL ancora da realizzare. Vedi STATO_IMPLEMENTAZIONE_0.9.0.md.

# Gestionale AD — Versioni

## 0.18.0 rc3 — 14 ottobre 2026

Correzione della migrazione PostgreSQL 0028 dopo l'errore nativo di rc2: i campi `tipo_ver_gvr_1/2/3` passano da `VARCHAR(20)` a `TEXT` prima di importare le descrizioni storiche (massimo 36, 29 e 24 caratteri); modello e snapshot verificati senza troncamenti. La migrazione 0028 fallita su rc2 era transazionale e dovrebbe lasciare lo schema alla 0027; verificarlo su Windows prima di riavviare. Nessun dato cliente/sede o file viene modificato da questa correzione. Prove PostgreSQL nativo ancora da ripetere. Guida: `COLLAUDO_POSTGRESQL_RC3.md`.

## 0.18.0 rc2 — 14 ottobre 2026

Schema 0028: cataloghi e tariffe DM congelati dalle migrazioni SQLite, aggiunti se mancanti all'archivio PostgreSQL; valori già presenti conservati e identità incompatibili bloccate. Corrette fixture e gestione di connessioni/processi nella suite nativa. Suite locale: 374 passati, 35 saltati (nativi PostgreSQL), 1 avviso, 11 subtest passati. La verifica PostgreSQL 18 su Windows è ancora da eseguire; vedere `COLLAUDO_POSTGRESQL_RC2.md`. Nessuna importazione di Garda o porting PostgreSQL dell'archivio Verbali in questa rc.

Questo file è incluso in ogni pacchetto e descrive **tutte** le versioni, dalla più recente. Le istruzioni d'uso della versione contenuta nel pacchetto sono in `LEGGIMI.md`.

| Versione | Data | Uso previsto | Stato |
|---|---|---|---|
| 0.8.0 | 09/10/2026 | Collaudo locale Windows | Candidatura con VerbalizzAI 0.3.32.3, fatture/incassi e revisioni dei flussi; integrazioni ancora aperte |
| 0.7.1 | 08/10/2026 | Prove in locale su Windows (poi VPS) | Prototipo precedente. Importazione dal database di Garda in un archivio a parte |
| 0.7.0 | 07/10/2026 | Prove in locale su Windows (poi VPS) | Prototipo. Documenti dei preventivi come i verbali (D80) |
| 0.6.1 | 07/10/2026 | Prove in locale su Windows (poi VPS) | Prototipo. Correzione: «Nuovo» precompilato dagli elenchi filtrati (O5) |
| 0.6.0 | 07/10/2026 | Prove in locale su Windows (poi VPS) | Prototipo. VerbalizzAI 0.3.32.1 come modulo dei verbali; anagrafica unica; ambiente di prova |
| 0.5.0 | 05/10/2026 | Prove in locale su Windows (poi VPS) | Prototipo. Verbali compilati nel gestionale (VerbalizzAI 0.3.25 incorporato); importazione dell'archivio di VerbalizzAI; O15–O17 |
| 0.4.0 | 05/10/2026 | Prove in locale su Windows (poi VPS) | Prototipo. Fase 5 «Verifiche»; tariffario M03-RG01 rev. 01; osservazioni O5–O14 |
| 0.3.2 | 04/10/2026 | Prove in locale su Windows (poi VPS) | Prototipo. Installazione più robusta |
| 0.3.1 | 04/10/2026 | Prove in locale su Windows (poi VPS) | Prototipo. Leggibilità, stampa del preventivo |
| 0.3.0 | 04/10/2026 | Prove in locale su Windows (poi VPS) | Prototipo. Fase 4: preventivi, Word/PDF, email |
| 0.2.2 | 04/10/2026 | Prove in locale su Windows | Prototipo. Osservazioni O1–O4 di Federico |
| 0.2.1 | 04/10/2026 | Prove in locale su Windows | Prototipo. Correzione dei backup su Windows |
| 0.2.0 | 04/10/2026 | Prove in locale su Windows | Prototipo. Fasi 2 e 3: anagrafica, tariffario, scadenze, importazione |
| 0.1.0 | 04/10/2026 | Prove in locale su Windows | Prototipo. Fase 1 «Fondamenta» |

## 0.8.0 — 09/10/2026 — Candidatura AD_dpr con fatture e incassi

Riuso della base Python 0.7.1 e aggiornamento del modulo VerbalizzAI alla 0.3.32.3; nessuna modifica dei sorgenti PHP Garda. TD01/TD02/TD04, intestatario terzo, righe libere o da preventivo, XML/versioni/esiti, scadenze, incassi ripartiti e rettifiche del credito. Fotografie degli emessi, evidenza scritta dell'accettazione, sospensione/ripresa, indipendenza e storico RV; VS senza spostamento della periodicità. Migrazioni 0009/0010 con backup precedente, sostituzione transazionale delle tabelle SQLite e controllo dei collegamenti.

Avvio dedicato `AVVIA_COLLAUDO_WINDOWS.bat`. Stato e verifiche in `STATO_IMPLEMENTAZIONE_0.8.0.md` e `report_collaudo/risultati.md`. Import economico/incrementale, acquisizione Aruba, schema fiscale corrente e attivazioni DM/I&C restano da completare. Non è un rilascio di produzione.

## 0.7.1 — 08/10/2026 — Importazione dal database di Garda

Richiesta di Federico dell'08/10/2026: «partire dal database del gestionale esistente e popolare la 0.7.0». Scelte: anagrafica **e** storico (preventivi e verifiche; fatture con la fase 6), in un **archivio nuovo a parte**. Decisione: D81.

**Nuovo**
- `IMPORTA_DA_GARDA_WINDOWS.bat` / `strumenti/importa_da_garda.py`: dal dump SQL completo di `ingecert` (HeidiSQL) crea `GestionaleAD_dati_GARDA` con utenti (disattivati), commerciali, modalità di pagamento, aliquote, clienti, sedi, impianti con POD, preventivi e righe, riesami, verifiche. Collegamenti con i codici interni di Garda; dati dubbi in «Da controllare»; rapporto `importazione_garda.txt` con la quadratura dei totali. Tutto o niente (una sola transazione). `AVVIA_GARDA_WINDOWS.bat` lo apre.
- Lettore dei dump MySQL/MariaDB senza server (`gestionale/moduli/garda/dump.py`): legge solo i valori, non esegue nulla.
- Contributo INAIL 5% e indennità di trasferta dei preventivi di Garda come righe «a corpo» (totale = righe × 1,05 + trasferta, come in Garda).

**Prova sul dump del 07/10/2026**: 1.910 clienti, 2.674 sedi, 2.694 impianti, 1.009 preventivi (1.866 righe, 678 righe INAIL, 98 trasferte), 1.438 verifiche, 6 utenti; **0 differenze** sui totali dei preventivi; nessun collegamento rotto. 1.175 segnalazioni da controllare, soprattutto clienti senza codice SDI né PEC (464), POD con altro testo (205), codice fiscale mancante (158), indirizzi incompleti (147). Circa 10 secondi.

107 test automatici (nuovo `tests/test_garda.py` con un dump di prova). Nessuna migrazione.

## 0.7.0 — 07/10/2026 — Documenti dei preventivi come i verbali

Richiesta di Federico del 07/10/2026: usare per i preventivi lo stesso metodo dei verbali di VerbalizzAI (anteprima, Word per i ritocchi, ricarica, revisioni). Scelta **A** (PDF rifatto dal programma). Decisione: **D80** (modifica D60 e O13).

**Prima (0.4.0–0.6.1)**: l'anteprima era un PDF con la scritta «ANTEPRIMA», non archiviato; l'invio rigenerava un PDF che nessuno aveva visto; la «versione ritoccata» erano Word + PDF salvato da Word, senza controllo del contenuto (si poteva cambiare un prezzo nel Word) e caricabile anche dopo l'invio.

**Adesso**
- **«👁 Anteprima» → «Controlla il documento»**: Word e PDF si preparano con i dati attuali e si **archiviano** con l'impronta dei dati stampati (cliente, righe, importi, testata); il PDF si vede nella finestra. Se i dati non cambiano si riapre lo stesso documento.
- **«Approvo questo documento»**: presa visione registrata (chi e quando, anche nel registro delle operazioni).
- **Si invia solo il PDF approvato**: «Invia email…» allega esattamente quel PDF; «Segna come inviato» registra quel PDF come inviato (nell'elenco degli invii). Senza approvazione, o se i dati sono cambiati dopo, il programma apre il documento da controllare.
- **Ritocchi di sola impaginazione**: si scarica il Word dell'anteprima, si sistema in Word, si ricarica **solo il Word**. Il programma lo confronta con quello dell'anteprima con lo stesso controllo dei verbali (testo, caselle, campi, immagini identici; niente macro, oggetti incorporati o revisioni Word) e **rifà il PDF con LibreOffice**; il documento ritoccato va approvato.
- **Dopo l'invio il documento non cambia più**: niente ritocchi né nuove anteprime; «Anteprima» e «Stampa» mostrano il PDF inviato. Per correggere serve una revisione (come prima: stesso numero, rev. +1, il precedente resta com'era).
- Linguetta «Documenti e invii»: stato del documento da inviare, colonne «Preparato» e «Approvato», documento «attuale».
- Il PDF del preventivo si può mostrare dentro la pagina del programma (solo per quell'indirizzo, come per i verbali).
- Ambiente di prova: i preventivi accettati passano da anteprima e approvazione; senza LibreOffice i PDF di prova sono pagine vuote (con avviso).

**Archivi precedenti**: i preventivi inviati prima della 0.7.0 senza PDF archiviato ricostruiscono il PDF dai dati una sola volta, poi usano sempre quello.

Migrazione **0008** (automatica, con backup «Prima di un aggiornamento»): quattro colonne nuove nei documenti dei preventivi. 104 test automatici (il test della versione ritoccata è sostituito da quello del nuovo percorso: anteprima archiviata, ritocco con testo cambiato rifiutato, ritocco di impaginazione accettato, approvazione, dati cambiati, invio del PDF approvato, niente ritocchi dopo l'invio). I test usano PDF finti salvo quello segnato «pdf_vero».

## 0.6.1 — 07/10/2026 — Correzione: «Nuovo» precompilato dagli elenchi filtrati

Segnalazione di Federico durante la prova della 0.6.0.
- **Corretto (O5, dalla 0.4.0)**: aprendo un elenco filtrato dal menu ⇄ della riga (es. «Sedi operative ← Cliente», «Impianti ← Sede», «Preventivi ← Cliente») e premendo «Nuovo», cliente o sede **non** venivano proposti: la griglia toglieva il filtro dall'indirizzo prima che «Nuovo» lo leggesse. Ora la pagina lo ricorda finché il filtro resta («Togli il filtro» lo dimentica). Provato nel browser su sedi, impianti e preventivi; i pulsanti «＋ Nuova sede per questo cliente» e «＋ Nuovo impianto in questa sede» delle schede funzionavano già.
- Programma e dati per il resto invariati; nessuna migrazione.

## 0.6.0 — 07/10/2026 — Un'anagrafica sola, VerbalizzAI 0.3.32.1 come modulo dei verbali

Piano: documento 15 «AD_dpr completo su VerbalizzAI 0.3.32.1». Richiesta di Federico del 07/10/2026: ambiente di prova in locale per il gestionale adattato a VerbalizzAI 0.3.32.1; il prodotto finale avrà **un'anagrafica sola** e VerbalizzAI sarà **solo il modulo di verbalizzazione**. Decisione: D78.

**Nuovo — VerbalizzAI 0.3.32.1 dentro il gestionale** (era la 0.3.25)
- È la versione che va in produzione a fine ottobre. Copiata **senza modifiche** (solo gli import resi relativi) con lo strumento nuovo `strumenti/aggiorna_verbalizzai.py`, che servirà anche per le versioni future.
- **Anteprima PDF obbligatoria prima della firma**: «Anteprima PDF» → controlli → «Firma ed emetti» dentro l'anteprima. Il PDF dell'anteprima si vede dentro la pagina (solo per quell'indirizzo il gestionale permette la visualizzazione incorporata).
- **Stato tecnico dell'impianto per modulo**: all'emissione si sceglie se confermare caratteristiche ed elementi per le verifiche successive. Permesso nuovo «**Confermare e correggere lo stato tecnico degli impianti**» (RT e Tecnico; aggiunto da solo anche agli archivi esistenti). Corretto un difetto del ponte per cui nessuno avrebbe potuto aggiornare lo stato tecnico (l'utente dell'emissione arrivava senza permessi).
- All'emissione il gestionale prende esito, prossima verifica e caratteristiche **dai dati del verbale compilato** invece di rileggere il Word: niente avvisi di lettura (il lettore dei Word di VerbalizzAI 0.3.32.1 non riconosce 10 gruppi dei modelli rev. 02; vedi Limiti noti).
- **Conversione automatica** dell'archivio dei verbali al formato 2, con copia `prima_schema2_…` prima di convertire. Le bozze aperte prima della conversione si confermano con «Confronta stato impianto».
- Modelli Word rev. 02 di VerbalizzAI 0.3.32.1 caricati negli archivi **nuovi**; quelli esistenti tengono i propri.

**Nuovo — Un'anagrafica sola**
- Nella pagina Verbali spariscono «Nuovo impianto», modifica ed eliminazione dell'impianto e «Nuova verifica»; il server le rifiuta comunque, con il messaggio che dice dove farle nel gestionale. Il verbale nasce **solo** dalla verifica registrata, che gli dà il numero.
- «Riprendi il verbale» riporta nella bozza ragione sociale, sede e indirizzo attuali del gestionale.
- Testi delle Verifiche aggiornati (il verbale si compila nel gestionale; lo stato si chiama «Eseguita (verbale emesso)»).
- **Riesame del verbale non conforme**: «Compila il verbale» apre una **revisione** del verbale emesso (stesso numero, rev. 1, 2…), come in VerbalizzAI, invece di un verbale nuovo con lo stesso numero (difetto della 0.5.0). All'emissione della revisione, se l'impianto è stato aggiornato dal verbale precedente, VerbalizzAI chiede «Confronta stato impianto» oppure di emettere senza aggiornarlo.

**Nuovo — Ambiente di prova dei verbali**
- `AVVIA_TEST_WINDOWS.bat` (e `RICREA_AMBIENTE_DI_PROVA_WINDOWS.bat`): archivio separato `GestionaleAD_dati_TEST` con 5 utenti (password «password di prova»), firme finte, 4 clienti, 8 impianti, preventivi accettati e riesaminati, verifiche in tutti i passi. Creato con `strumenti/crea_ambiente_di_prova.py` passando dalle stesse funzioni del browser. Vedi LEGGIMI § 8-bis.

**Corretto**: avviando per primo un archivio di prova (`AVVIA_PROVA_WINDOWS.bat`, `AVVIA_TEST_WINDOWS.bat`) il programma scriveva quella cartella in `config.json` (O16), e il successivo `AVVIA_WINDOWS.bat` avrebbe aperto l'archivio di prova. Ora la cartella scelta per un solo avvio non viene mai scritta.

**Test**: nuovo `tests/test_ponte_contratto.py` (il «contratto» tra gestionale e VerbalizzAI: se una versione futura cambia qualcosa che il gestionale usa, il test lo dice subito) con un archivio dei verbali della 0.5.0 da convertire; emissione con anteprima; stato tecnico solo con il permesso; anagrafica aggiornata alla ripresa della bozza; revisione dopo il riesame non conforme. 104 test automatici. Nessuna migrazione del database del gestionale.

## 0.5.0 — 05/10/2026 — Il verbale dentro il gestionale

Piano: documento 10 § B.8 (verbale nel gestionale) e § B.10 (importazione dell'archivio); scelte di Federico del 05/10/2026 (strumenti e firme, invio per email, importazione dell'archivio, note O15–O17). Decisioni: D67–D71.

**Nuovo — Verbali (VerbalizzAI dentro il gestionale, D67)**
- Menu **Lavoro › Verbali**: è VerbalizzAI 0.3.25, la stessa pagina e le stesse regole (controlli del verbale, Word dal modello M01/M02/M03, anteprima PDF, emissione con firma, revisioni, annullamento), con **utenti, permessi e posta del gestionale**: niente accesso, password o utenti di VerbalizzAI.
- Nella verifica **registrata**: «**Compila il verbale**» crea la bozza con numero, data, verificatore, ragione sociale, sede e indirizzo **presi dal gestionale** e i dati del verbale precedente dello stesso impianto; «Riprendi il verbale» la riapre. Quando si **emette**, la verifica diventa **eseguita** da sola e l'impianto si aggiorna (come caricando il Word, D63). Se il verbale emesso viene **annullato**, la verifica torna «registrata».
- Il caricamento del Word fatto a parte resta possibile («Oppure carica il verbale … già fatto in Word»).
- **Strumenti e firme**: le pagine di VerbalizzAI (tarature, firme grafiche dei verificatori), con permessi nuovi «Strumenti e firme» (vedere: RT e Tecnico; gestire: RT). Permesso nuovo «Revisione di un verbale emesso» (RT).
- **Invio del verbale per email** dalla pagina del verbale, con il server di posta del gestionale (Sistema › Impostazioni email) e la copia all'ufficio.
- I verbali stanno nella cartella dei dati (`verbali\`) e **finiscono nei backup del gestionale** (anche il ripristino li riporta indietro).

**Nuovo — Importazione dell'archivio di VerbalizzAI (Sistema › Verbali di VerbalizzAI)**
- Si carica il **backup completo** di VerbalizzAI (…adbackup.zip): tutti i verbali, i modelli, gli strumenti e le firme entrano nel gestionale. Si fa una volta, al passaggio.
- **Collegamento alle sedi**: per ogni impianto di VerbalizzAI il programma propone la sede del gestionale (per **POD**, per **cliente e indirizzo**, «probabile», «da scegliere»); «Collega le proposte sicure» in un colpo, le altre una per una con «Collega» o «Scegli…». Collegando, ogni modulo va sull'impianto dello stesso tipo della sede, che si aggiorna con l'ultimo verbale; una messa a terra mancante viene creata con i dati del verbale (da controllare). Prova sull'archivio di Federico (293 impianti, 363 verbali validi): 213 collegati in automatico, 43 probabili, 24 da scegliere, 13 senza proposta.

**Nuovo — osservazioni**
- **O15** Sconto chiesto dopo l'invio: «**Sconto (con revisione)…**» nel preventivo inviato crea da solo la revisione con la data di oggi e lo sconto, da reinviare; il prezzo inviato resta com'era. Dopo l'accettazione il prezzo non si tocca più.
- **O16** Avvio con archivio vuoto: avviso nella pagina iniziale e nella finestra nera con la cartella dei dati in uso; il programma scrive da solo `cartella_dati` in `config.json`, così la versione successiva ritrova sempre i dati.
- **O17** **Assegnazione in blocco**: in Verifiche si spuntano le righe e «Assegna le selezionate…» a un verificatore (tutte o nessuna).

Migrazione 0007 (automatica, con backup). 94 test automatici.

## 0.4.0 — 05/10/2026 — Verifiche, tariffario completo, osservazioni O5–O14

Piano: documento 10 (fase 5 «Verifiche», approvato da Federico il 05/10/2026). Decisioni: D60–D66. Comprende quella che era stata annunciata come 0.3.3.

**Nuovo — Verifiche (fase 5)**
- Menu **Lavoro › Verifiche**. Ogni riga accettata di un preventivo diventa una verifica «da assegnare» quando si registra il **riesame del contratto conforme** (D61). Nessuna verifica senza preventivo.
- Percorso: **da assegnare** → il RT sceglie il verificatore (**assegnata**) → il verificatore segna la data prevista (**programmata**, facoltativo) → **registrata**: prende il **numero del verbale** (VP/001/26, VS/002/26… un solo sezionale annuale per VP e VS, D62) e fissa la data di esecuzione → **eseguita** solo caricando il **Word del verbale emesso con VerbalizzAI** (D63) → **riesaminata** dal RT, pronta per la fatturazione (D64). Annullamento con motivo (il numero resta usato).
- Il verbale caricato viene letto con le stesse parti di VerbalizzAI 0.3.25 (copiate in `gestionale/terzi/verbalizzai`): controlla che numero e modulo (M01 terra, M02 scariche, M03 esplosione) coincidano, legge esito e prossima verifica e **aggiorna l'impianto**: ultima verifica e numero, prossima verifica, periodicità, **caratteristiche tecniche** ed **elementi provati** (quadri, differenziali, protezioni, continuità).
- Scheda dell'impianto: nuova linguetta «Caratteristiche ed elementi» con le verifiche dell'impianto.
- Permessi nuovi: vedere tutte / le proprie, assegnare, eseguire, riesame del verbale, annullare (al posto degli «incarichi» in arrivo). Il verificatore vede solo le sue verifiche.
- Collegamenti «Verifiche ←» da clienti, impianti e preventivi; nel preventivo, linguetta Riesame: le verifiche nate dal preventivo.

**Nuovo — Tariffario M03-RG01_dpr rev. 01 (D65)**
- Caricate tutte le voci, valide dal 30/09/2026: terre per kW (sotto 3 kW e oltre 1.000 kW con avviso «a ore»), oltre 1.000 kW e sotto 3 kW a ore con minimo, tensioni di passo e contatto, parafulmine ad asta e aste in più, gabbia per superficie, strutture metalliche, **pericolo di esplosione a ore (€ 93/ora)**, straordinarie a ore, sopralluogo a vuoto, duplicato, **trasferta** (tabella tempo × distanza).
- Nel tariffario: **importo minimo**, **avvisi** sugli scaglioni, **elenchi a scelta** (es. trasferta), voci **a ore**.
- Nel preventivo: riga di un impianto calcolata **a ore** (ore scritte nella riga; per il pericolo di esplosione è proposta da sola), **righe senza impianto** (voce del tariffario o **importo a corpo**) con «＋ Voce / a corpo».

**Nuovo — osservazioni di Federico**
- **O5** «Nuovo» precompilato dagli elenchi filtrati (sede ← cliente, impianto ← sede, preventivo ← cliente).
- **O6** L'installazione copia il `config.json` della versione precedente (cartelle `Gestionale_AD_v*` accanto).
- **O7** **«Salva e chiudi»** (e «Crea e chiudi») accanto a «Salva» in tutte le schede laterali.
- **O8** Pericolo di esplosione: periodicità sempre **2 anni**; l'importazione segnala quelli a 5 anni. **O9** Periodicità di partenza 2 anni (D66).
- **O12** ⚡ dalle scadenze: **data del preventivo** precompilata e **numero del preventivo** (vuoto = nuovo; con un numero si aggiunge a quel preventivo del cliente; se già inviato si crea la revisione; mai su un accettato). La revisione ha sempre la data del giorno in cui si crea.
- **O13** **👁 Anteprima**: il PDF come uscirebbe, con la scritta «ANTEPRIMA», non archiviato.
- **O14 / D60** Modello **M01-RG01_dpr rev. 04** (da approvare): tabella con colonne ribilanciate e righe che non si spezzano, riquadro «Si prega di inviare l'accettazione» dentro la tabella delle firme (non scivola più a pagina 2), condizioni da pagina nuova. Sostituisce da sola la rev. 03 di sistema. **Versione ritoccata a mano**: in «Documenti e invii» si caricano il Word sistemato e il PDF salvato da Word; da quel momento si stampa e si invia quel PDF, finché il preventivo non cambia.

**Corretto**
- Piede degli elenchi: il numero «Trovati» poteva restare quello di un filtro precedente.
- Testo intero al passaggio del mouse sulle celle tagliate: niente più «false» e testo mostrato sempre come testo.

Migrazione 0006 (automatica, con backup). 86 test automatici.

## 0.3.2 — 04/10/2026 — Installazione più robusta

Segnalazione di Federico: installando la 0.3.1 compariva «No module named pip» e poi «controlla la connessione a Internet», che non era la causa (ambiente Python `.venv` rimasto a metà).

**Cambiato**
- `INSTALLA_WINDOWS.bat`: quattro passaggi numerati; se la `.venv` esiste ma è incompleta prova a ripararla, altrimenti la cancella e la ricrea; controlla ogni passaggio e in caso di problema scrive **[ERRORE]** con il motivo vero (Python mancante, ambiente non creabile, pip mancante, librerie non scaricate, cartella bloccata da un Gestionale ancora aperto); alla fine verifica che il programma si avvii.
- `AVVIA_WINDOWS.bat`: se l'installazione è incompleta lo dice invece di mostrare un errore tecnico.
- Nessuna modifica al programma né ai dati rispetto alla 0.3.1. 80 test automatici (nuovo: i file .bat restano in formato Windows).

## 0.3.1 — 04/10/2026 — Leggibilità e stampa del preventivo

Richieste di Federico del 04/10/2026. Decisioni: D57, D58, D59.

**Cambiato**
- **Testo più leggibile** (D57, variante B scelta da Federico): testo normale 16 punti e mai sotto i 14 per ciò che si legge lavorando (prima tabelle a 12 e titoli delle colonne a 10,5); grigi scuriti fino al contrasto minimo WCAG 2.2 di 4,5:1; pulsanti della riga di almeno 28×28 px (WCAG 2.5.8 chiede 24); colonne più larghe in proporzione.
- **Misura del testo per utente** in «Il mio profilo»: Normale (16) o Grande (18), salvata con l'utente (vale su ogni PC).
- Negli elenchi, al passaggio del mouse su una **cella tagliata** compare il testo intero.
- Modello **M01-RG01_dpr rev. 03** (da approvare): codice e revisione spostati **in calce a sinistra**, all'altezza di «pag. 1» (prima erano in un riquadro in alto a sinistra, nascosto dietro il logo nel PDF) (D59). La rev. 03 caricata dalla 0.3.0 si aggiorna da sola; i modelli caricati dagli utenti non vengono toccati.

**Nuovo**
- **🖨 Stampa** in basso nella scheda del preventivo (D58): apre il PDF in una nuova scheda del browser. Se il preventivo è già inviato si stampa il PDF inviato; altrimenti si riusa l'ultimo PDF se nulla è cambiato, oppure se ne genera uno nuovo (archiviato); con modifiche non salvate chiede di salvare.

**Corretto**
- Piede degli elenchi: «Totale Totale standard» → «Totale standard».

Migrazione 0005 (automatica, con backup). 79 test automatici.

## 0.3.0 — 04/10/2026 — Preventivi

Piano: documento 09. Decisioni: D13–D19, D26, D36, D38, D39, D51–D54.

**Nuovo**
- **Preventivi** intestati al cliente con righe su impianti di sedi diverse (D39); numero progressivo annuo **P_001_26** (riparte ogni anno); modalità di pagamento e termine di esecuzione proposti dal cliente e modificabili; commerciale; rif. e data dell'ordine (D36); note.
- **Righe**: tipo di verifica (periodica / straordinaria), sede e descrizione copiate, **tariffa standard dal tariffario copiata nella riga** con il dettaglio delle voci, sconto % solo per clienti sbloccati e utenti abilitati (D38), tariffa applicata (D26); «Ricalcola tariffe».
- **Stati** (D13): creato → inviato → accettato parzialmente / totalmente (calcolati dalle righe), rifiutato, annullato (con motivo). Stato riga: in attesa, accettata, rifiutata, annullata. Con una riga accettata il preventivo è **fissato** (D19).
- **Revisioni** (D16): da un preventivo inviato si crea «rev. 1, 2…»; la precedente resta com'era («sostituito»).
- **Riesame del contratto** ISO/IEC 17020 (D17): esito, quattro punti di controllo, note; RT o Segreteria.
- **Word e PDF** dal modello in uso (M01-RG01_dpr **rev. 03** = rev. 02 con la tariffa applicata, da approvare); file conservati con impronta; nome «P_001_26 - Ragione sociale».
- **Invio email** del PDF con testo standard modificabile; registro degli invii; il preventivo diventa «inviato».
- **Scadenziario**: colonne del preventivo collegato, filtro «Da preventivare», selezione di più scadenze dello stesso cliente e pulsante **⚡ Preventivo** (nuovo o aggiunta a uno aperto, D19).
- Elenchi **Preventivi** e **Righe dei preventivi** con colonne del cliente (e di impianto e sede), filtri rapidi (code di lavoro), azioni sulla riga e collegamenti.
- Menu **Impostazioni email** (server di posta in `posta.json`, fuori da database e backup; testi; prova di invio) e **Modelli Word** (in uso / superati, caricamento di nuove revisioni con controllo dei segnaposto).
- Cliente: nuovo campo «Termine di esecuzione».
- Migrazione 0004 (automatica, con backup). Nuova dipendenza: lxml (lettura sicura dei Word). 75 test automatici.

**Corretto**
- Filtri sì/no delle griglie su colonne calcolate (davano errore).

## 0.2.2 — 04/10/2026 — Prime osservazioni di Federico (O1–O4)

**Cambiato**
- **Comune** (O1, D49): un solo campo «Comune» con i suggerimenti dell'elenco ISTAT; scegliendo si compilano CAP (elenco dei CAP per le città che ne hanno più d'uno), **provincia e regione, ora sempre visibili e modificabili**. Se il nome è scritto a mano senza scegliere, il comune viene riconosciuto da solo (anche dal server). I comuni non in elenco (es. esteri) restano come scritti.
- **Codice fiscale sempre obbligatorio**, partita IVA facoltativa (O3, D48). L'importazione segnala i clienti senza codice fiscale.
- **Azioni sulla riga** in Clienti, Sedi, Impianti, Scadenze, Commerciali (O4, D50): ✎ apri/modifica, 🗑 elimina (solo se non ci sono dati collegati), ⇄ menu degli elementi collegati che apre l'altro elenco già filtrato (es. Impianti ← Cliente, Scadenze ← Sede, Cliente → scheda), con l'avviso «Elenco filtrato… Togli il filtro».

**Nuovo**
- Menu **Sistema › Comuni (ISTAT)** (O2, D49): consultare, correggere (CAP, dati), aggiungere comuni, togliere dall'elenco quelli soppressi; storico delle modifiche. Lo vede chi vede l'anagrafica, lo modifica chi ha «Impostazioni».
- Migrazione 0003 (comuni «in elenco» sì/no), fatta senza ricreare la tabella per non perdere il comune delle schede (con test). 66 test automatici.

## 0.2.1 — 04/10/2026 — Correzione dei backup su Windows

**Corretto**
- Su Windows ogni backup (manuale, automatico, «prima di un aggiornamento», «prima di un'importazione») falliva con «Errore imprevisto»: una connessione al database copiato restava aperta e Windows non permetteva di cancellare la cartella temporanea. Per questo anche l'importazione si fermava (fa un backup prima di scrivere; nessun dato era stato scritto). Su Linux il problema non si vedeva. Nuovo test che controlla che il backup chiuda tutte le connessioni (63 test).

## 0.2.0 — 04/10/2026 — Anagrafica, tariffario, scadenze, importazione

Riepilogo e prova di accettazione: documento 08. Decisioni implementate: D7–D10, D11/D29, D35, D38 (sblocco sconti sul cliente), D39 (base), D41–D44, D45 (provvisoria), D46.

**Nuovo**
- Clienti, sedi operative, impianti, commerciali con tutti gli attributi decisi; scheda di dettaglio con linguette e storico delle modifiche (dal registro).
- Griglie con tutte le colonne dell'entità e delle entità collegate (D43): in Sedi i dati del cliente, in Impianti quelli di sede e cliente.
- Comune scelto dall'elenco ISTAT (compila provincia, regione, CAP).
- Controlli: partita IVA e codice fiscale (cifra di controllo), codice SDI, IBAN, POD, email anche multiple, coerenza dei campi per tipologia d'impianto (cabine solo oltre 1.000 V, aste/gabbia, zone gas/polveri).
- Più POD per impianto (G35); matricola INAIL in 4 parti; fasce gabbia 100/350 m² (D44).
- Prossima verifica calcolata: ultima verifica + periodicità − 1 giorno, come il gestionale attuale (D45, da confermare).
- Dismissione con motivo: l'impianto esce dalle scadenze ma resta in archivio (D10). Clienti e sedi si disattivano; si elimina solo ciò che non ha dati collegati (e resta nel registro).
- Sconti bloccati, sbloccabili sul cliente con motivo (D38).
- Tariffario da menu: voci con criterio (scaglioni / prezzo × quantità / fisso), importi in versioni con data di validità (le versioni in vigore non si modificano), «Prova il calcolo»; caricata la tariffa terre del gestionale attuale.
- Scadenziario: stato della scadenza, giorni mancanti, tariffa proposta; filtri rapidi.
- Elenchi di valori da menu: modalità di pagamento, aliquote IVA.
- Importazione da gestionale attuale (D46): anteprima, solo aggiunte, abbinamenti per nome, recupero degli zeri persi da Excel, segnalazioni nel campo «Da controllare», backup prima, file conservati nell'archivio documenti.
- Pagina iniziale con scadute / entro 30 giorni e numeri dell'anagrafica.
- 15 test automatici nuovi (62 in tutto).

**Corretto**
- Verifica di un backup con il database così danneggiato da non potersi aprire: ora viene segnalato come non valido invece di dare errore.

**Note tecniche**
- Migrazione dello schema 0002 (automatica, con backup «Prima di un aggiornamento»).
- Le griglie usano unioni «piatte»: con unioni annidate SQLite 3.45.1 va in crash (trovato durante le prove).

## 0.1.0 — 04/10/2026 — Fase 1 «Fondamenta»

Piano: documento 07. Decisioni implementate: D18, D22, D23, D24, D30, D31, D32, D33, D34, D37, D40 (parte comune); D27 (sviluppo autonomo da VerbalizzAI).

**Nuovo**
- Primo avvio guidato con creazione dell'amministratore.
- Accesso con utente e password; blocco dopo 5 tentativi sbagliati; sessione che scade per inattività; password provvisoria da cambiare al primo accesso.
- Utenti: creazione, modifica, disattivazione/riattivazione (mai cancellazione), sblocco, nuova password provvisoria. Deve restare sempre almeno un amministratore attivo.
- Ruoli creabili dall'amministratore (anche copiando i permessi); un ruolo usato non si elimina.
- Tabella dei permessi a grana fine: 36 micro-attività (5 attive, le altre «in arrivo» per le fasi 2–6) con i valori di partenza approvati.
- Registro delle operazioni non modificabile, a catena di impronte SHA-256, con verifica.
- Archivio documenti con impronta SHA-256 fuori dal database (pronto per le fasi successive).
- Backup completo (database + documenti + manifest con impronte), automatico e manuale; verifica; caricamento da file; ripristino con conferma, backup di sicurezza preventivo e rientro automatico in caso di errore; controllo di integrità.
- Migrazioni automatiche dello schema con backup preventivo; blocco se il database è di una versione più nuova.
- Griglia comune (Tabulator): ricerca, filtri per colonna con sintassi per numeri e date, ordinamento, colonne visibili e spostabili, raggruppamento, viste salvate per utente con vista predefinita, totali, esportazione Excel della vista corrente; paginazione e filtri lato server.
- Interfaccia con caratteri e colori di VerbalizzAI; menu con le fasi in arrivo.
- Archivio di prova con 300.000 righe; 47 test automatici.
