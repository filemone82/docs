@echo off
setlocal
set GESTIONALE_DATABASE_URL=
chcp 65001 >nul
cd /d "%~dp0"
title NEXUS - ricrea l'ambiente di prova
if not exist ".venv\Scripts\python.exe" (
  echo  Prima esegui INSTALLA_WINDOWS.bat
  pause
  exit /b 1
)
echo.
echo  Cancella TUTTO l'ambiente di prova (..\GestionaleAD_dati_TEST) e lo ricrea da zero.
echo  L'archivio vero (GestionaleAD_dati) NON viene toccato.
echo  Chiudi prima AVVIA_TEST_WINDOWS.bat se e' aperto.
echo.
set /p RISPOSTA= Scrivi SI per continuare: 
if /i not "%RISPOSTA%"=="SI" (
  echo  Annullato.
  pause
  exit /b 0
)
if exist "..\GestionaleAD_dati_TEST" rmdir /s /q "..\GestionaleAD_dati_TEST"
if exist "..\GestionaleAD_dati_TEST" (
  echo  Non riesco a cancellare la cartella: il gestionale di prova e' ancora aperto?
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -c "import httpx" >nul 2>nul
if errorlevel 1 ".venv\Scripts\python.exe" -m pip install -r requirements-sviluppo.txt
".venv\Scripts\python.exe" strumenti\crea_ambiente_di_prova.py
pause
