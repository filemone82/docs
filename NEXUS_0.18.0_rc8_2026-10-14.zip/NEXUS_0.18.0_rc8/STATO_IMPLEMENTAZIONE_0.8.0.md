# AD_dpr 0.8.0 — stato del codice e limiti del collaudo

Aggiornamento: 9 ottobre 2026, ora italiana. Questa versione avvia l'implementazione richiesta; **non costituisce il cutover di Garda né un rilascio fiscale validato in produzione**.

## Codice riutilizzato e nuovo

La base è Gestionale_AD 0.7.1: Python, FastAPI, SQLAlchemy/Alembic, SQLite e HTML/JavaScript. Restano le anagrafiche, il tariffario, i preventivi Word/PDF, gli incarichi, l'autenticazione, i permessi e i backup. VerbalizzAI incorporato è aggiornato alla 0.3.32.3. Il PHP Garda non è stato modificato o adattato; viene consultato come riferimento delle regole. Lo schema XML storico presente nei materiali Garda è riutilizzato come prima risorsa di validazione, con il limite descritto sotto.

Il modulo economico introduce società emittente, fatture/righe/scadenze, esportazioni XML immutabili, esiti, incassi e attribuzioni. Importi monetari in centesimi interi; quantità e prezzi unitari come decimali esatti. FK dichiarate, controllo della versione nelle modifiche, transazioni e registro delle operazioni.

| Area | Disponibile in questa versione | Da completare o validare |
|---|---|---|
| Offerta | Anteprima LibreOffice, ritocco Word, approvazione; fotografia dei nuovi documenti inviati; riferimento scritto richiesto per l'accettazione; accettazione parziale e RC | Archiviazione strutturata delle evidenze di accettazione; validazione dei modelli e delle procedure aziendali |
| Incarico | Indipendenza preselezionata/escludibile e blocchi nel servizio; sospensione/ripresa conservando numero; VP/VS con progressivo annuale comune | Prova operativa con tutti e quattro i tecnici e continuità delle numerazioni al cutover |
| Verbale e RV | PDF richiesto alla finalizzazione; storico RV con autore, note e documento; RV negativo → registrata; invio VerbalizzAI bloccato senza RV conforme sullo stesso PDF | Collaudo completo M01/M02/M03 e revisioni sul PC Windows, firme e procedure effettive |
| Stato tecnico | Fotografia storica; riuso delle caratteristiche senza risultati precedenti; tutela dello stato più recente; VS non sposta la scadenza periodica | Validazione di impianti reali complessi e dei mapping di importazione |
| Fatture | TD01, TD02 e TD04; righe libere o da preventivo; più prestazioni nello stesso documento; terzo intestatario; IVA, split payment, bollo, ritenuta, scadenze; foto e XML del tentativo | Validazione fiscale aggiornata, casi storici e scelta delle serie definitive; righe negative storiche non supportate |
| Rettifiche | Note totali/parziali collegate; riduzione del credito non incassato; controlli su importi e riferimenti originari | Caso raro di nota dopo pagamento e relativa procedura di rimborso/compensazione |
| Incassi | Registrazione manuale; un movimento su più fatture dello stesso intestatario/società; residui, ripartizione e storno tracciato | Import estratti conto successivo; dettaglio dell'anzianità dei residui per singola rata |
| Esiti | Contratto interno per esiti e tentativi, identificativo univoco della ricevuta; scarto, correzione e rigenerazione conservando numero e vecchi XML | Connettore/importatore Aruba: modalità ancora da definire, nessuna acquisizione reale implementata |
| Garda | Importazione iniziale anagrafiche/preventivi/verifiche del prototipo; audit contabile in sola lettura | Importazione economica e pratiche aperte collaudate; ID canonici per tutte le sorgenti e riallineamento incrementale |
| DM e I&C | Separazione della società emittente nel nucleo economico; confini dei moduli | Modello comune definitivo dei beni e flussi DM/EX/I&C, permessi per ambito e relative attivazioni |

La TD02 associata a una prestazione riduce l'importo disponibile per il saldo della stessa prestazione; un incasso è un movimento distinto. Un acconto libero, senza riferimenti alla prestazione, richiede un'associazione esplicita prima di poter essere dedotto automaticamente: non è dedotto cercando soltanto nome del cliente o descrizione.

## Confine di VerbalizzAI e infrastruttura

L'applicazione presenta un solo accesso e usa le anagrafiche/ID del gestionale. **VerbalizzAI conserva ancora il proprio archivio SQLite**, separato dal database relazionale principale. Non è già realizzato l'adattatore `Archive` sul futuro schema comune di asset/verbali.

L'acquisizione dell'emissione è idempotente rispetto a documento e impronta; l'API `POST /api/verbali/riallinea`, con permesso di riesame, recupera emissioni persistite nel modulo ma non ancora acquisite nel nucleo. Questo limita gli effetti di un'interruzione fra i due archivi; non trasforma le due scritture in una transazione atomica. Il backup gestisce entrambi gli archivi secondo la struttura già presente nel prototipo.

Per il collaudo: **Windows locale, Python 3.12, un solo processo del server, SQLite, LibreOffice e browser**. Il file di avvio usa localhost. PostgreSQL, hosting pubblico, più processi applicativi e continuità di servizio non sono stati implementati o verificati in questa versione. Il lucchetto delle scritture e la numerazione dipendono dall'uso di un unico processo; non avviare più istanze sullo stesso archivio.

## Validazione fiscale e audit Garda

L'XML è validato localmente contro lo schema incluso **1.2.2** (FPR12/FPA12), non contro una versione corrente verificata delle specifiche. Vedere `gestionale/moduli/finanza/schemi/LEGGIMI.md`. Il successo del test XSD non prova l'accettazione SdI. Prima dell'uso fiscale occorrono lo schema ufficiale pertinente, i controlli extra-XSD e prove concordate nel percorso Aruba, senza trasmettere documenti sintetici come fatture reali.

L'audit in sola lettura dello staging ingecert ha rilevato **473 fatture, 1.123 righe, nessuna riga orfana, una riga negativa**. Totale documenti: **€ 385.061,37**; totale dovuto e totale scadenze: entrambi **€ 375.480,58**. Una fattura richiede la spiegazione della differenza fra imponibile/IVA/bollo e totale: non è classificata automaticamente come errore.

Sono stati confrontati **zero XML originali**: i record del dump non sono i file XML. Il rapporto aggregato è incluso; l'audit non importa incassi, non accede ad Aruba e non scarica S3. La regressione sui 473 XML storici proposta in precedenza rimane da fare quando i file saranno disponibili.

## Collaudo e percorso verso l'esercizio

I risultati osservati sono in `report_collaudo/risultati.md`. I test comprendono regressioni del prototipo e nuove prove economiche/operative. Una prova del DOM con backend HTTP ha esercitato creazione fattura, riga, emissione XML e attribuzione incasso; non sostituisce la verifica grafica in un browser Windows. I PDF di cortesia sono stati prodotti davvero con LibreOffice.

Prima di sostituire ingecert sono necessari: collaudo Windows e casi aziendali, modello comune definitivo e import incrementale, migrazione contabile quadrata e numerazioni iniziali, recupero degli esiti Aruba, validazione fiscale corrente, prova delle pratiche aperte e ripristino completo con documenti. Gli originali S3 possono restare fuori dal presente pacchetto e venire trattati nella fase degli allegati. Il rinvio non elimina gli allegati necessari alle pratiche di produzione.

Il requisito «DPR completo di fatturazione e incassi» resta valido. La 0.8.0 è una base eseguibile di collaudo di quel perimetro, non una dichiarazione che tutte le integrazioni e migrazioni siano concluse.
