# Checkpoint interno 0.12.0-dev — documenti e chiusura DM

10 ottobre 2026. Base 0.11.1-dev conservata, VerbalizzAI incorporato 1.0.1 rc2, migrazione applicativa **0014**. È un avanzamento del prodotto unico richiesto, non il gestionale completo pronto a sostituire Garda.

Istruzioni aggiornate di installazione, avvio e aggiornamento: **README_INSTALLAZIONE.md**, incluso nel pacchetto. Ogni successivo stato di avanzamento sarà accompagnato dal proprio README, come richiesto da Federico.

## Cosa è disponibile

Gli incarichi AD_dm possono proseguire dalla registrazione alla produzione del verbale GVR/SC/SP, al controllo e alla conferma del PDF, alla chiusura e al riesame. Le prossime date del bene provengono dall’ultima verifica effettuata pertinente a ciascuna componente; non viene dedotta una periodicità generica.

- Precompilazione selettiva dai precedenti effettuati nell’archivio nuovo, soltanto prima del primo salvataggio della bozza. Provenienza consultabile per campo.
- Word/PDF dai due modelli Garda inclusi nel backup, conservati identici. Il parametro di stampa `l=1` riproduce le etichette originali delle caselle. Nome/cognome e firma riusano utente e archivio VerbalizzAI comuni.
- Modelli DM controllati in Sistema › Modelli Word, con revisioni e modello in uso. Impronta del modello e della firma nella fotografia del documento. I modelli dell’utente non vengono sovrascritti all’avvio.
- Ritocco dell’impaginazione Word con confronto del contenuto, oppure caricamento PDF conservato byte per byte. Cambiare dati, caselle o immagini richiede aggiornamento della scheda e rigenerazione.
- PDF corrente consultabile e chiusura legata a ID, impronta del file, versione dell’incarico e fotografia dei dati. Per V1 serve anche la scheda tecnica PDF caricata. Se scheda, modello o firma cambiano prima della chiusura, il documento va rigenerato o ricaricato.
- Nomi dei PDF chiusi secondo lo schema INAIL Garda, storico dei documenti e conservazione del definitivo. Il percorso email usa gli stessi file archiviati e registra destinatari e allegati.
- Riesame DM singolo o multiplo: qualunque stato; N non riapre e la chiusura non azzera il riesame. Operazione multipla atomica con controllo delle versioni.
- Affiancamento e dati CND nelle condizioni pertinenti; confronto delle date secondo Garda. In assenza di nuovo numero di report, il riferimento già registrato resta conservato.

L’impronta del PDF esterno identifica il file controllato dall’operatore; non ne certifica automaticamente il contenuto tecnico. Nessun generatore autonomo di schede V1 o di rapporti CND è dichiarato realizzato.

## Verifiche eseguite

**Regressione passata: 213 test nella suite generale e quattro scenari CND supplementari (due aggiuntivi), per 215 casi distinti.** Risultati definitivi in `report_collaudo/pytest_finale_0.12.0-dev.txt` e `.xml`.

Prove su GVR/SC/SP, requisiti V1, PDF errato/obsoleto, ritocchi, permessi, invio simulato con confronto dei byte, riesame, precedenti, date per componente, lavoro retrodatato, annullamento e CND. Migrazione da 0013 popolata con conservazione di bozze/collegamenti, confronto schema/modelli e backup/ripristino anche del PDF definitivo e della firma comune.

La prova DOM+HTTP esercita JavaScript e backend reali fino a chiusura e riesame, con convertitore simulato nel solo processo di prova. Tre test DM usano LibreOffice reale. Ispezionate tutte le quattro pagine dei tre campioni sintetici GVR/SC/SP, con caselle, etichette, camere, firma, date, testata e piè di pagina. La suite ordinaria conserva la conversione simulata delle offerte dei collaudi precedenti. Nessuna email esterna inviata.

Ambiente Linux, Python 3.12.14, SQLite, Node 24.19.0/jsdom 26.1.0. Non effettuati collaudi Windows/Microsoft Word, configurazione dei domini, deploy sul VPS o migrazione completa dei tre dump.

## Copertura ancora aperta

Fatturazione/incassi DM collegati, EX, pacchetti INAIL, I&C, dashboard DM, storico/import completo e incrementale, intero perimetro di autorizzazioni e azioni Garda. L’eccezione ai PDF nella modifica multipla e le correzioni dei verbali già effettuati restano aperte. Non sono rinunce autorizzate. Rapporto 27 e matrice 26 distinguono implementazione e parità verificata.

La base DM 0.11 aveva già ereditato il blocco di indipendenza DPR; adsrl non applica quel controllo (AD-31). Qui resta come comportamento ereditato, **senza certificarlo come parità o deroga approvata**. R63 nasce dal primo DPR: allineamento da chiudere prima della candidata completa. Anche protezione manuale delle date derivate, collegamenti all’ultima verifica e filtri commerciali/clienti vanno verificati sui sorgenti.

VerbalizzAI conserva il proprio archivio SQLite nel gruppo dati/backup del backend integrato, raccordato al principale. Nessuna unificazione fisica o perdita dello storico. Gli ingressi `/ad-dpr`, `/ad-dm`, `/iec` rimangono ambienti della stessa applicazione; I&C non è ancora completo.

## Ripresa

Continuare sul codice 0.12 e rapporto 27 con fatturazione DM collegata e INAIL, poi I&C e riconciliazione dei dati. Conservare R101–R106 e tutte le funzioni compatibili. I documenti di stato precedenti sono evidenze storiche. Non occorre installare questo checkpoint come nuovo gestionale operativo.
