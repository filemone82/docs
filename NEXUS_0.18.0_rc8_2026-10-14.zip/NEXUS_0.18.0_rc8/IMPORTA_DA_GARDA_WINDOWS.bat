@echo off
setlocal
set GESTIONALE_DATABASE_URL=
chcp 65001 >nul
cd /d "%~dp0"
title NEXUS - importazione dal database di Garda
if not exist ".venv\Scripts\python.exe" (
  echo  Prima esegui INSTALLA_WINDOWS.bat
  pause
  exit /b 1
)
echo.
echo  Crea un archivio NUOVO (..\GestionaleAD_dati_GARDA) con i dati dei gestionali di Garda.
echo  I database di Garda NON vengono toccati: si legge solo il file .sql.
echo.
echo  1) AD_dpr (ingecert): clienti, sedi, impianti, preventivi e verifiche. Obbligatorio.
echo  2) AD_dm (adsrl): clienti (fusi con quelli di ingecert), sedi, attrezzature SC/SP/GVR,
echo     camere, accessori, date iniziali. Facoltativo.
echo.
set "DUMP=%~1"
if "%DUMP%"=="" set /p "DUMP= Trascina qui il file .sql di INGECERT e premi Invio: "
set "DUMP=%DUMP:"=%"
if not exist "%DUMP%" (
  echo  File non trovato: %DUMP%
  pause
  exit /b 1
)
set "ADSRL=%~2"
if "%ADSRL%"=="" set /p "ADSRL= Trascina qui il file .sql di ADSRL (oppure solo Invio per saltare): "
if defined ADSRL set "ADSRL=%ADSRL:"=%"
if defined ADSRL if not exist "%ADSRL%" (
  echo  File non trovato: %ADSRL%
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -c "import httpx" >nul 2>nul
if errorlevel 1 ".venv\Scripts\python.exe" -m pip install -r requirements-sviluppo.txt
if defined ADSRL (
  ".venv\Scripts\python.exe" strumenti\importa_da_garda.py "%DUMP%" --adsrl "%ADSRL%"
) else (
  ".venv\Scripts\python.exe" strumenti\importa_da_garda.py "%DUMP%"
)
echo.
echo  Per aprirlo: AVVIA_GARDA_WINDOWS.bat
pause
