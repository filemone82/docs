# Catalogo Garda — iec (I&C S.r.l.): allegato dei campi

**Versione 1.0 · 9 ottobre 2026.** Allegato a `catalogo/iec_01_regole_e_strutture.md`. Elenco completo, generato automaticamente, di ogni entità e di ogni campo.

Generato automaticamente dai metadati (`cust/meta/*.js`) e dal dump del 07/10/2026. Colonna *Dati*: record valorizzati / totali; per enum e booleani la distribuzione dei valori.


## `_rp_fatture_clienti` — 

- tipo meta: report
- hook: php_gi_rpt_global_data_modify=`php_gi_rpt_global_data_fatture_clienti_modify`
- altre proprietà: {"label": "Fattura cliente", "category": "fatture_clienti", "meta": [{"name": "fatture_clienti", "alias": "f"}, {"name": "configurazioni", "which_record": "t.id = 1", "alias": "a"}], "page_width": "210", "page_height": "297", "css": {"width": "210mm", "padding": "10mm"}}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `header` | container |  |  | — |  |
| `numero` | container |  |  | — |  |
| `addresses` | container |  |  | — |  |
| `righe` | rows |  |  | — |  |
| `footer` | container |  |  | — |  |
| `paginazione_diciture` | container |  |  | — |  |

## `_rp_preventivi_word` — 

- tipo meta: report
- altre proprietà: {"label": "Preventivo", "category": "preventivi", "word_show_template_fields": false, "word": "gi_cust_modello_preventivi_get()", "report_format": "docx", "meta": [{"name": "preventivi", "alias": "p"}, {"name": "npreventivi_ext", "alias": "pe", "php_which_record": "gi_preventivi_php_which_record_preventivi_ext($p.id)", "inline_meta": {"label_s": "preventivi_ext", "label_p": "preventivi_ext", "fie…

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui` — 

- tipo meta: menu
- altre proprietà: {"submenus": ["_ui_dashboard", "_ui_admin", "_ui_clienti", "_ui_scadenze", "_ui_preventivi", "_ui_attivita", "_ui_fatture", "_ui_fatture_collaboratori", "_ui_user"], "show_loginbg": true, "footer_links": [{"name": "privacy", "label": "Privacy", "type": "link", "href": "http://www.iec.net", "target": "_blank"}, {"name": "terms", "label": "Termini", "type": "link", "href": "http://www.iec.net", "ta…

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_admin` — 

- tipo meta: submenu
- altre proprietà: {"label": "Gestione", "icon": "_ui_admin.png", "items": [{"name": "utenti", "label": "Utenti", "type": "page", "icon": "_ui_admin_utenti.png", "widgets": [{"type": "tab_container", "name": "tr_utenti", "widgets": [{"name": "tab_utenti", "type": "tab", "label": "Utenti", "widgets": [{"name": "g_utenti", "type": "grid", "meta": "utenti"}]}, {"name": "tab_utenti_collaboratori_percentuali", "type": "…

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_attivita` — 

- tipo meta: submenu
- altre proprietà: {"label": "Attivita", "icon": "_ui_attivita.png", "items": [{"name": "pg_attivita", "label": "Attivita", "type": "page", "icon": "_ui_attivita.png", "widgets": [{"name": "g_attivita", "type": "grid", "meta": "attivita"}]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_clienti` — 

- tipo meta: submenu
- altre proprietà: {"label": "Clienti", "icon": "_ui_clienti.png", "items": [{"name": "pg_clienti", "label": "Clienti", "type": "page", "icon": "_ui_clienti.png", "widgets": [{"name": "g_clienti", "type": "grid", "meta": "clienti"}]}, {"name": "pg_clienti_sedi_operative", "label": "Sedi operative", "type": "page", "icon": "_ui_clienti_sedi_operative.png", "widgets": [{"name": "g_clienti_sedi_operative", "type": "gr…

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_clienti_sedi_operative` — 

- tipo meta: submenu
- altre proprietà: {"label": "Sedi operative", "icon": "_ui_clienti_sedi_operative.png", "items": [{"name": "pg_clienti_sedi_operative", "label": "Sedi operative", "type": "page", "icon": "_ui_clienti_sedi_operative.png", "widgets": [{"name": "g_clienti_sedi_operative", "type": "grid", "meta": "clienti_sedi_operative"}]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_dashboard` — 

- tipo meta: submenu
- altre proprietà: {"label": "Dashboard", "icon": "_ui_dashboard.png", "items": [{"name": "dashboard", "label": "Dashboard", "type": "page", "icon": "_ui_dashboard.png", "home_page": true, "widgets": [{"type": "widget_row", "name": "dashboard_riga1", "widgets": [{"name": "scad_da_prev", "type": "aggregate", "icon": "glyphicon-calendar", "css_class": "primary", "cols": 3, "label_go": "Vai alle Scadenze", "link": "pg…

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_fatture` — 

- tipo meta: submenu
- altre proprietà: {"label": "Fatture Clienti", "icon": "_ui_fatture.png", "items": [{"name": "pg_fatture_clienti", "type": "page", "label": "Fatture clienti", "icon": "_ui_documenti.png", "widgets": [{"name": "tc_fatture_clienti", "type": "tab_container", "widgets": [{"name": "tab_fatture_clienti", "type": "tab", "label": "Fatture clienti", "widgets": [{"name": "g_fatture_clienti", "type": "grid", "meta": "fatture…

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_fatture_collaboratori` — 

- tipo meta: submenu
- altre proprietà: {"label": "Fatture Collaboratori", "icon": "_ui_fatture_collaboratori.png", "items": [{"name": "pg_fatture_collaboratori", "type": "page", "label": "Fatture Collaboratori", "icon": "_ui_fatture_collaboratori.png", "widgets": [{"name": "g_fatture_collaboratori", "type": "grid", "meta": "fatture_collaboratori"}]}, {"name": "pg_importi_collaboratori", "type": "page", "label": "Importi Collaboratori"…

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_preventivi` — 

- tipo meta: submenu
- altre proprietà: {"label": "Preventivi", "icon": "_ui_preventivi.png", "items": [{"name": "pg_preventivi", "label": "Preventivi", "type": "page", "icon": "_ui_preventivi.png", "widgets": [{"type": "tab_container", "name": "tr_preventivi", "widgets": [{"name": "tab_preventivi", "type": "tab", "label": "Preventivi", "widgets": [{"name": "g_preventivi", "type": "grid", "meta": "preventivi"}]}, {"name": "tab_righe", …

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_scadenze` — 

- tipo meta: submenu
- altre proprietà: {"label": "Scadenze", "icon": "_ui_scadenze.png", "items": [{"name": "pg_scadenze", "label": "Scadenze", "type": "page", "icon": "_ui_scadenze.png", "widgets": [{"name": "g_scadenze", "type": "grid", "meta": "scadenze"}]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_user` — 

- tipo meta: submenu
- altre proprietà: {"label": "Utente", "icon": "_ui_user.png", "icon_logout": "_ui_user_esci.png", "items": [{"name": "login", "label": "Login", "type": "page", "visible": false, "widgets": [{"name": "login", "type": "login"}]}, {"name": "profilo", "label": "Profilo Utente", "type": "page", "icon": "_ui_user.png", "widgets": [{"name": "profilo", "type": "form", "meta": "utenti", "which_record": "t.id = #id"}], "req…

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `articoli` — Articoli

- tipo meta: table · lettura: `articoli` · decodifica: `articoli_dec` · record: 33
- univoci: ['titolo']
- indici: ['tip_prezzo']
- ordinamento: {'by': 'titolo', 'dir': 'asc'}
- permessi: `show_articoli`; `edit_articoli`; `new_articoli`; `delete_articoli`
- azioni: show←show_articoli; edit←edit_articoli; new←new_articoli; delete←delete_articoli

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 33/33 |
| `titolo` | string | Titolo | obbl. | text NN | 33/33 |
| `descrizione` | string | Descrizione |  | text | 33/33 |
| `tip_prezzo` | enum | Tipologia Prezzo | obbl.; default S; valori {"S": "Prezzo singolo", "C": "Prezzo a corpo"} | enum('S','C') NN | 33/33 · S=30, C=3 |
| `nota_finale` | string | Nota Finale |  | text | 21/33 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull) | int(11) | 33/33 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 33/33 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 33/33)

## `attivita` — Attività

- tipo meta: table · lettura: `attivita_read` · decodifica: `attivita_dec` · record: 2842
- hook: php_gi_record_save_before=`gi_attivita_save_before`
- ordinamento: {'by': 'preventivo', 'dir': 'desc'}
- permessi: `show_attivita`; `edit_attivita` [cond: t.stato_attivita <> 'effettuata' OR t.fattura IS NULL]; `multiedit_attivita` [cond: t.stato_attivita <> 'effettuata' OR t.fattura IS NULL]; `export_attivita`
- azioni: show←show_attivita; edit←edit_attivita; multiedit←multiedit_attivita; export←export_attivita
- altre proprietà: {"ddl": false, "show_stats": false}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 2842/2842 |
| `n_riga` | integer | N° riga | visibile se false; no multiedit | int(11) NN | 2842/2842 |
| `attivita` | reference | Attivita | →attivita (noaction); visibile se false; calcolato in vista | vista |  |
| `stato_attivita` | enum | Stato attività | obbl.=$preventivo!=""; default da_programmare; valori {"da_programmare": "Da programmare", "programmata": "Programmata", "effettuata": "Effettuata", "annullata": "Annullata"} | enum('da_programmare','programmata','effettuata','annullata') | 1753/2842 · effettuata=1177, ∅=1089, da_programmare=535, annullata=35, programmata=6 |
| `data_program` | date | Data programmazione | obbl.=$stato_attivita=="programmata" | date | 367/2842 |
| `preventivo` | reference | Preventivo | sola lettura; →preventivi (cascade); no multiedit | int(11) NN | 2842/2842 |
| `cliente` | reference | Cliente | →clienti (noaction); calcolato in vista; no multiedit | vista |  |
| `sede_operativa` | reference | Sede operativa | →clienti_sedi_operative (noaction); calcolato in vista; no multiedit | vista |  |
| `collaboratore` | reference | Collaboratore | →utenti (noaction); calcolato in vista; no multiedit | vista |  |
| `descrizione` | string | Descrizione | sola lettura; no multiedit | text | 2841/2842 |
| `attrezzatura` | integer | Id Attrezzatura | obbl.; visibile se false | int(11) NN | 2842/2842 |
| `valvola` | integer | Id Valvola di sicurezza | visibile se false | int(11) | 622/2842 |
| `tipo_scad` | enum | Tipo scadenza | sola lettura; valori {"cnd": "Controlli non distruttivi (GVR)", "suppl": "Indagine supplementare (SC/SP)", "taratura": "Taratura (Valvole di sicurezza)", "altro": "Altro"}; no multiedit | enum('cnd','suppl','taratura','altro') | 2226/2842 · altro=1150, taratura=622, ∅=616, cnd=408, suppl=46 |
| `data_esecuzione` | date | Data esecuzione | obbl.=$stato_attivita == "effettuata" | date | 1189/2842 |
| `data_prox_scadenza` | date | Data prossima scadenza | obbl.=$stato_attivita == "effettuata" && ($tipo_scad=="cnd" \|\| $tipo_scad=="suppl" \|\| $tipo_scad=="taratura"); visibile se $tipo_scad=="cnd" \|\| $tipo_scad=="suppl" \|\| $tipo_scad=="taratura" | date | 619/2842 |
| `note` | string | Note |  | text | 41/2842 |
| `fattura` | reference | Fattura | sola lettura; →fatture_clienti (setnull); no multiedit | int(11) | 1201/2842 |
| `fattura_saldata` | boolean | Fattura cliente saldata | calcolato in vista; no multiedit | vista |  |
| `da_sinc_adsrl` | enum | Da sincronizzare su ADSRL | sola lettura; default gi_preventivi_righe_da_sinc_adsrl_defau…; valori {"T": "Sì", "F": "No", "S": "Sincronizzato"}; visibile se $tip_riga=="S"; no multiedit | enum('T','F','S') | 2226/2842 · F=1607, ∅=616, S=579, T=40 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull); no multiedit | int(11) | 2842/2842 |
| `last_update_ts` | datetime | Data modifica | sola lettura; no multiedit | datetime | 2842/2842 |

Colonne fisiche senza campo nei metadati: `tip_riga` (enum('P','S'); 2842/2842), `n_riga_sottopunto` (int(11); 2226/2842), `punto` (int(11); 2226/2842), `stato_riga` (enum('da_accettare','accettata','rifiutata'); 2226/2842), `cerca_articolo` (int(11); 569/2842), `titolo` (varchar(191); 616/2842), `scadenza` (int(11); 0/2842), `tip_prezzo` (enum('S','C'); 2842/2842), `imp_netto` (decimal(12,2); 2190/2842), `nota_finale` (text; 550/2842), `inser_scadenze` (int(11); 0/2842), `last_update_nr` (int(11); 2842/2842), `sconto` (decimal(12,2); 219/2842), `tipo_sconto` (enum('P','A'); 219/2842), `imp_scontato` (decimal(12,2); 2201/2842), `imp_finale` (decimal(12,2); 2201/2842), `perc_collab` (decimal(12,2); 160/2842), `fattura_collab` (int(11); 0/2842), `almeno_un_sottopunto_accettato` (enum('F','T'); 2842/2842), `almeno_un_sottopunto_effettuato` (enum('F','T'); 2842/2842), `almeno_un_sottopunto_fatturato` (enum('F','T'); 2842/2842), `lettera` (varchar(191); 0/2842), `importo_totale_punto` (decimal(12,2); 0/2842), `importo_totale_scontato_punto` (decimal(12,2); 0/2842), `almeno_un_sottopunto_scontato` (enum('F','T'); 2842/2842), `descr_sottopunti` (text; 603/2842)

## `clienti` — Clienti

- tipo meta: table · lettura: `clienti` · decodifica: `clienti_dec` · record: 814
- hook: php_gi_record_save_before=`gi_clienti_save_before`
- univoci: ['rag_soc']
- ordinamento: {'by': 'rag_soc', 'dir': 'asc'}
- permessi: `show_clienti`; `show_clienti_propri` [cond: t.collaboratore=#id]; `edit_clienti`; `new_clienti`; `delete_clienti`
- azioni: show←show_clienti|show_clienti_propri; edit←edit_clienti; new←new_clienti; delete←delete_clienti

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura; visibile se false | int(11) NN | 814/814 |
| `rag_soc` | string | Ragione Sociale | obbl.; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 80 | varchar(80) NN | 814/814 |
| `indirizzo` | string | Indirizzo | obbl.; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 60 | varchar(60) NN | 814/814 |
| `cerca_comune` | reference | Cerca comune | →comuni (setnull); trascina ['cap', 'prov', 'comune', 'regione', 'nazione'] | int(11) | 770/814 |
| `comune` | string | Comune | obbl.; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 40 | varchar(40) NN | 814/814 |
| `cap` | string | CAP | obbl.; max 5 | varchar(5) NN | 814/814 |
| `prov` | string | Provincia | obbl.; max 2 | varchar(2) NN | 814/814 |
| `regione` | string | Regione | obbl.; max 21 | varchar(21) NN | 814/814 |
| `nazione` | reference | Nazione | →nazioni (restrict) | int(11) | 92/814 |
| `email` | string | E-mail | check emails; aiuto: Inserire una o più email separate da virgola | varchar(191) | 659/814 |
| `pec` | string | PEC | check emails | varchar(191) | 83/814 |
| `cod_fis` | string | Codice Fiscale | obbl.; check cf bloccante; max 16 | varchar(16) NN | 814/814 |
| `p_iva` | string | Partita IVA | obbl.=warning; check piva bloccante; max 30 | varchar(30) | 812/814 |
| `collaboratore` | reference | Collaboratore | →utenti (restrict); accesso {"show": ["show_clienti"]} | int(11) | 311/814 |
| `sdi_pec` | string | Codice SDI/PEC | valori ["0000000", "XXXXXXX", "M5UXCR1", "USAL8PV", "W7YVJK9", "KRRH6B9", "A4707H7", "T04ZHR3", "X2PH38J", "5RUO82D", "T9K4ZHO", "P62QHVQ", "SUBM70N", "5W4A8J1", "UE2LXTM", "BA6ET11", "JHBM40P", "fe.dylogbuffetti@sicurezzapostale.it"]; aiuto: Codice destinatario o PEC per fattura elettronica.  | varchar(191) | 668/814 |
| `rif_amministrazione` | string | Riferimento amministrazione fatt. elett… | regex `/^p{IsBasicLatin}+$/` bloccante; max 20; accesso {"show": ["show_clienti"]}; aiuto: Eventuale riferimento utile al destinatario per automatizzare la gestione amministrativa dell'operazione in fattura | varchar(20) | 2/814 |
| `istituto_finanziario` | string | Banca cliente | regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 80; accesso {"show": ["show_clienti"]}; aiuto: Serve ad esempio nel caso di nota di credito | varchar(80) | 1/814 |
| `iban` | string | IBAN banca cliente | check iban bloccante; max 34; accesso {"show": ["show_clienti"]}; aiuto: Serve ad esempio nel caso di nota di credito | varchar(34) | 1/814 |
| `dich_intento` | boolean | Dichiarazione intento | obbl.; default F; accesso {"show": ["show_clienti"]} | enum('F','T') NN | 814/814 · F=813, T=1 |
| `dich_intento_n` | string | N° dichiarazione intento | max 60; accesso {"show": ["show_clienti"]}; aiuto: Protocollo di ricezione della dichiarazione d'intento e il suo progressivo separato dal segno "-" (es. 08060120341234567-000001) | varchar(60) | 1/814 |
| `dich_intento_data` | date | Data dichiarazione intento | accesso {"show": ["show_clienti"]} | date | 1/814 |
| `rit_acc_str` | string | Ritenuta d'acconto (aliquota) | valori ["4%", "20%", "23% sul 50%"]; accesso {"show": ["show_clienti"]} | varchar(191) | 0/814 |
| `note` | string | Note | accesso {"show": ["show_clienti"]} | text | 41/814 |
| `pagamento` | reference | Pagamento | →tipi_pagamento (restrict); accesso {"show": ["show_clienti"]} | int(11) | 557/814 |
| `iva` | reference | Aliquota Iva | →iva (restrict); accesso {"show": ["show_clienti"]} | int(11) | 755/814 |
| `id_cliente_adsrl` | integer | Id Cliente ADSRL | sola lettura; visibile se false; accesso {"show": ["show_clienti"]} | int(11) | 484/814 |
| `last_update_user` | reference | Utente Modifica | sola lettura; →utenti (setdefault); accesso {"show": ["show_clienti"]} | int(11) | 132/814 |
| `last_update_ts` | datetime | Data Modifica | sola lettura; accesso {"show": ["show_clienti"]} | datetime | 802/814 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 814/814), `sconto_def` (decimal(12,2); 798/814)

## `clienti_sedi_operative` — Sedi operative

- tipo meta: table · lettura: `clienti_sedi_operative_read` · decodifica: `clienti_sedi_operative_dec` · record: 1047
- univoci: ['cliente', 'nome_sede']
- indici: ['cliente']; ['cerca_comune']
- ordinamento: {'by': 'nome_sede', 'dir': 'asc'}
- permessi: `show_clienti_sedi_operative`; `show_clienti_sedi_operative_propri` [cond: t.collaboratore=#id]; `show_clienti_sedi_operative_utente_cliente` [cond: t.utente_cliente=#id]; `edit_clienti_sedi_operative`; `new_clienti_sedi_operative`; `delete_clienti_sedi_operative`
- azioni: show←show_clienti_sedi_operative|show_clienti_sedi_operative_propri|show_clienti_sedi_operative_utente_cliente; edit←edit_clienti_sedi_operative; new←new_clienti_sedi_operative; delete←delete_clienti_sedi_operative

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 1047/1047 |
| `inattiva` | boolean | Sede inattiva | obbl.; default F | enum('F','T') NN | 1047/1047 · F=1038, T=9 |
| `cliente` | reference | Cliente | obbl.; →clienti (cascade) | int(11) NN | 1047/1047 |
| `utente_cliente` | reference | Utente del cliente | →utenti (restrict); accesso {"show": ["show_clienti_sedi_operative"]} | int(11) | 0/1047 |
| `collaboratore` | reference | Collaboratore | →utenti (noaction); calcolato in vista; accesso {"show": ["show_clienti_sedi_operative"]} | vista |  |
| `nome_sede` | string | Denominazione sede operativa | obbl. | varchar(191) NN | 1047/1047 |
| `indirizzo` | string | Indirizzo | obbl.; max 60 | varchar(60) NN | 1047/1047 |
| `cerca_comune` | reference | Cerca comune | →comuni (restrict); trascina ['comune', 'cap', 'prov', 'regione'] | int(11) | 983/1047 |
| `comune` | string | Comune | obbl.; max 40 | varchar(40) NN | 1047/1047 |
| `cap` | string | CAP | obbl.; max 5 | varchar(5) NN | 1047/1047 |
| `prov` | string | Prov. | obbl.; max 2 | varchar(2) NN | 1047/1047 |
| `regione` | string | Regione | obbl.; max 21 | varchar(21) NN | 1047/1047 |
| `nome_referente` | string | Nome referente |  | varchar(191) | 342/1047 |
| `email_ref` | string | Email referente | check emails bloccante | varchar(191) | 687/1047 |
| `tel_ref` | string | Tel. referente | check tels | varchar(191) | 233/1047 |
| `note` | string | Note | accesso {"show": ["show_clienti_sedi_operative"]} | text | 584/1047 |
| `id_sede_adsrl` | integer | Id Sede ADSRL | sola lettura; visibile se false | int(11) | 551/1047 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull); accesso {"show": ["show_clienti_sedi_operative"]} | int(11) | 105/1047 |
| `last_update_ts` | datetime | Data modifica | sola lettura; accesso {"show": ["show_clienti_sedi_operative"]} | datetime | 1020/1047 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 1047/1047)

## `comuni` — Comuni

- tipo meta: table · lettura: `comuni` · decodifica: `comuni_dec` · record: 8464
- hook: php_gi_ddl_table_create_custom=`gi_ddl_table_create_comuni`
- univoci: ['comune', 'cap']
- ordinamento: {'by': 'regione', 'dir': 'asc'}
- permessi: `show_comuni`; `edit_comuni`; `new_comuni`; `copy_comuni`; `delete_comuni`
- azioni: show←show_comuni; edit←edit_comuni; new←new_comuni; copy←copy_comuni; delete←delete_comuni
- altre proprietà: {"blank_on_copy": ["comune"], "list_mobile": [{"field": "regione", "title": "regione", "left": "regione", "subtitle": ["nazione"]}, {"field": "provincia", "title": "provincia", "left": "provincia", "subtitle": ["regione", "nazione"]}, {"field": "id", "title": "comune", "left": "comune", "subtitle": ["regione", "nazione"], "right_top": ["cap"], "right_bottom": ["provincia"]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | ID | sola lettura; visibile se false | int(11) NN | 8464/8464 |
| `comune` | string | Comune | obbl. | varchar(191) NN | 8464/8464 |
| `cap` | string | CAP |  | varchar(191) | 8464/8464 |
| `provincia` | string | Provincia | regex `/^[A-Z-]{0,2}$/` bloccante; aiuto: Per la provincia mettere la sigla (2 lettere maiuscole, EE per stato estero e `-` se non c'è la provincia) | varchar(191) | 8464/8464 |
| `cod_fisco` | string | Codice comune |  | varchar(191) | 8463/8464 |
| `regione` | string | Regione |  | varchar(191) | 8464/8464 |
| `nazione` | reference | Nazione | obbl.; →nazioni (restrict) | int(11) NN | 8464/8464 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault) | int(11) | 0/8464 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 8464/8464 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 8464/8464)

## `configurazioni` — Configurazioni

- tipo meta: table · lettura: `configurazioni` · decodifica: `configurazioni_dec` · record: 1
- hook: php_gi_ddl_table_create_custom=`gi_ddl_table_create_configurazioni`
- ordinamento: {'by': 'id', 'dir': 'asc'}
- permessi: `show_configurazioni` [cond: 1 = t.id]; `edit_configurazioni` [cond: 1 = t.id]
- azioni: show←show_configurazioni; edit←edit_configurazioni
- altre proprietà: {"list_mobile": [{"field": "id", "title": "id"}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura; visibile se false | int(11) NN | 1/1 |
| `fe_denominazione` | string | Denominazione | obbl.; default ; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 80 | varchar(80) NN | 1/1 |
| `fe_piva` | string | Partita Iva | obbl.; default ; check piva bloccante; max 30 | varchar(30) NN | 1/1 |
| `fe_cf` | string | Codice fiscale | obbl.; default ; check cf bloccante; max 16 | varchar(16) NN | 1/1 |
| `fe_regime_fiscale` | enum | Regime fiscale | obbl.; default RF01; valori {"RF01": "RF01: Ordinario", "RF02": "RF02: Contribuenti minimi (art.1, c.96-117, L. 244/07) ", "RF04": "RF04: Agricoltura e attività connesse e pesca (artt.34 e 34-bis, DPR 633/72) ", "RF05": "RF05: Vendita sali e tabacchi (art.74, c.1, DPR. 633/72) ", "RF06": "RF06: Commercio fiammiferi (art.74, c.1, DPR  633/72) ", "RF07": "RF07: Editoria (art.74, c.1, DPR  633/72)", "RF08": "RF08: Gestione ser… | enum('RF01','RF02','RF04','RF05','RF06','RF07','RF08','RF09','RF10','RF11','RF12','RF13','RF14','RF15','RF16','RF17','RF18','RF19') NN | 1/1 · RF01=1 |
| `fe_rit_acc_tipo` | enum | Tipo ritenuta d'acconto | obbl.; default RT02; valori {"RT01": "RT01 Ritenuta persone fisiche (ditte individuali, società di persone)", "RT02": "RT02 Ritenuta persone giuridiche (società di capitali, enti, cooperative)"} | enum('RT01','RT02') NN | 1/1 · RT02=1 |
| `fe_rit_acc_caus` | enum | Causale ritenuta d'acconto | obbl.; default A; valori {"A": "A – prestazioni di lavoro autonomo rientranti nell'esercizio di arte o professione abituale", "B": "B – utilizzazione economica, da parte dell'autore o dell'inventore, di opere dell'ingegno, di brevetti industriali e di processi, formule o informazioni relativi ad esperienze acquisite in campo industriale, commerciale o scientifico", "C": "C – utili derivanti da contratti di associazione i… | enum('A','B','C','D','E','G','H','I','L','L1','M','M1','M2','N','O','O1','P','Q','R','S','T','U','V','V1','W','X','Y','ZO') NN | 1/1 · A=1 |
| `fe_indirizzo` | string | Indirizzo | obbl.; default ; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 60 | varchar(60) NN | 1/1 |
| `fe_cap` | string | CAP | obbl.; default ; max 5 | varchar(5) NN | 1/1 |
| `fe_comune` | string | Comune | obbl.; default ; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 60 | varchar(60) NN | 1/1 |
| `fe_provincia` | string | Provincia | obbl.; default ; max 2 | varchar(2) NN | 1/1 |
| `fe_rea_ufficio` | string | REA Ufficio | max 2; aiuto: Obbligatorio per società soggette al vincolo dell’iscrizione nel registro delle imprese | varchar(2) | 1/1 |
| `fe_rea_numero` | string | REA Numero | max 20; aiuto: Obbligatorio per società soggette al vincolo dell’iscrizione nel registro delle imprese | varchar(20) | 1/1 |
| `fe_capitale_sociale` | decimal | Capitale sociale | aiuto: Obbligatorio nei soli casi di società di capitali (SpA, SApA, SRL) | decimal(12,2) | 0/1 |
| `fe_socio_unico` | enum | Socio unico | default SM; valori {"SU": "socio unico", "SM": "più soci"}; aiuto: Obbligatorio nei soli casi di SpA e SRL | enum('SU','SM') | 1/1 · SU=1 |
| `fe_stato_liquidazione` | enum | Stato liquidazione | obbl.; default LN; valori {"LS": "in liquidazione", "LN": "non in liquidazione"} | enum('LS','LN') NN | 1/1 · LN=1 |
| `fe_telefono` | string | Telefono | obbl.; default ; regex `/^p{IsBasicLatin}+$/` bloccante; max 12 | varchar(12) NN | 1/1 |
| `fe_email` | string | E-mail | obbl.; default  | varchar(191) NN | 1/1 |
| `fe_fax` | string | Fax |  | varchar(191) | 0/1 |
| `fe_istituto_finanziario` | string | Banca | obbl.; default ; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 80 | varchar(80) NN | 1/1 |
| `fe_iban` | string | IBAN | obbl.; default ; check iban bloccante; max 34 | varchar(34) NN | 1/1 |
| `fe_codice_articolo_tipo` | string | Tipo codifica codici articolo | obbl.; default AswArtFor; regex `/^p{IsBasicLatin}+$/` bloccante; max 35; aiuto: AswArtFor per codifica del fornitore, AswArtCli se si usa la codifica del cliente, AswCodEan se si usa la codifica del codice a barre, oppure la codifica uffic… | varchar(35) NN | 1/1 |
| `fe_sdi_pec` | string | Codice SDI/PEC | valori ["0000000", "XXXXXXX", "M5UXCR1", "USAL8PV", "W7YVJK9", "KRRH6B9", "A4707H7", "T04ZHR3", "X2PH38J", "5RUO82D", "T9K4ZHO", "P62QHVQ", "SUBM70N", "5W4A8J1", "UE2LXTM", "BA6ET11", "JHBM40P", "fe.dylogbuffetti@sicurezzapostale.it"]; aiuto: Usato come recapito per integrazioni e autofatture di acquisto | varchar(191) | 0/1 |
| `fe_cf_trasmittente` | string | Codice fiscale Trasmittente | obbl.; default ; regex `/^p{IsBasicLatin}+$/` bloccante; max 28; aiuto: Es. nel caso di invio con intermediario Aruba PEC S.p.A. mettere 01879020517 | varchar(28) NN | 1/1 |
| `mod_word_prev` | files | Modello Word Preventivo | file server | text | 1/1 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull) | int(11) | 1/1 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 1/1 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 1/1)

## `fatture_clienti` — Fatture clienti

- tipo meta: table · lettura: `fatture_clienti_read` · decodifica: `fatture_clienti_dec` · record: 231
- hook: php_gi_record_save_before=`gi_fatture_clienti_save_before`, php_gi_record_save_after=`gi_fatture_clienti_save_after`, php_gi_record_change_after=`gi_fatture_clienti_change_after`
- univoci: ['serie_fattura', 'tipo_fatt', 'numero_fattura']
- indici: ['tipo_fatt']; ['cliente', 'rif_lav_gen_fatture_clienti']
- ordinamento: {'by': 'anno_numero_fattura', 'dir': 'desc'}
- permessi: `show_fatture_clienti`; `show_fatture_clienti_collaboratore` [cond: EXISTS(SELECT 1 FROM preventivi_righe r LEFT OUTER JOIN preventivi p ON p.id=r.preventivo WHERE r.fattura=t.id AND p.collaboratore=#id LIMI…]; `edit_fatture_clienti` [cond: t.generata_fatt_elettronica='F' AND t.almeno_un_importo_fattura_collab = 'F']; `edit_generata_fatt_elettronica_fatture_clienti` [cond: t.almeno_un_importo_fattura_collab = 'F']; `new_fatture_clienti`; `copy_fatture_clienti`; `delete_fatture_clienti` [cond: t.almeno_un_importo_fattura_collab = 'F']; `genera_xml_fatture_clienti` [cond: t.generata_fatt_elettronica='F']; `print_fatture_clienti`
- azioni: show←show_fatture_clienti|show_fatture_clienti_collaboratore; edit←edit_fatture_clienti|edit_generata_fatt_elettronica_fatture_clienti; new←new_fatture_clienti; copy←copy_fatture_clienti; delete←delete_fatture_clienti; print←; fatture_clienti_genera_xml←genera_xml_fatture_clienti (Genera fatture elettroniche XML)
- altre proprietà: {"blank_on_copy": ["serie_fattura", "numero_fattura", "data_fattura", "generata_fatt_elettronica"], "show_stats": true}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 231/231 |
| `stampa` | files | Stampa | sola lettura; accesso {"show": ["show_fatture_clienti"]}; file s3 | text | 227/231 |
| `tipo_fatt` | enum | Tipo fattura | obbl.; default TD01; valori {"TD01": "TD01: fattura", "TD02": "TD02: acconto/anticipo su fattura", "TD03": "TD03: acconto/anticipo su parcella", "TD04": "TD04: nota di credito", "TD05": "TD05: nota di debito", "TD06": "TD06: parcella", "TD16": "TD16: integrazione fattura reverse charge interno", "TD20": "TD20: autofattura per regolarizzazione e integrazione delle fatture (ex art.6 c.8 d.lgs. 471/97  o  art.46 c.5 D.L. 331/9…; accesso {"edit": ["edit_fatture_clienti"]} | enum('TD01','TD02','TD03','TD04','TD05','TD06','TD16','TD20','TD21','TD22','TD23','TD24','TD25','TD26','TD27') NN | 231/231 · TD01=228, TD04=3 |
| `data_fattura` | date | Data fattura | obbl.; default gi_date_default(); accesso {"edit": ["edit_fatture_clienti"]} | date NN | 231/231 |
| `numero_fattura` | integer | Numero fattura | obbl.; default gi_nextcode_get($id,$serie_fattura); dipende ['serie_fattura']; accesso {"edit": ["edit_fatture_clienti"]} | int(11) NN | 231/231 |
| `serie_fattura` | string | Serie fattura | obbl.; default gi_serie_documento_get($data_fattura,$t…; dipende ['data_fattura', 'tipo_fatt'] | varchar(191) NN | 231/231 |
| `anno_numero_fattura` | string | Numero fattura | visibile se false; calcolato in vista | vista |  |
| `decodifica` | string | Numero | visibile se false; calcolato in vista | vista |  |
| `cliente` | reference | Cliente | →clienti (restrict); trascina ['termini_di_pagamento', 'cli_rag_soc', 'cli_indirizzo', 'cli_cerca_comune', 'cli_comune', 'cli_cap', 'cli_prov', 'cli_nazione', 'cli_cod_fis', 'cli_p_iva', 'cli_sdi_pec', 'cli_rif_amministrazione', 'cli_istituto_finanziario', 'cli_iban', 'cli_dich_intento', 'cli_dich_intento_n', 'cli_dich_intento_data', 'rit_acc_str']; accesso {"edit": ["edit_fatture_clienti"]} | int(11) | 231/231 |
| `termini_di_pagamento` | reference | Termini di pagamento | default gi_reference_default_get('predefinito'); →tipi_pagamento (restrict); accesso {"edit": ["edit_fatture_clienti"]} | int(11) | 231/231 |
| `causale_fatt_elettronica` | string | Causale fatt. elettronica | regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 200; accesso {"show": ["show_fatture_clienti"]} | varchar(200) | 0/231 |
| `bollo_virtuale` | boolean | Bollo virtuale | obbl.; default F; accesso {"show": ["show_fatture_clienti"]} | enum('F','T') NN | 231/231 · F=228, T=3 |
| `bollo_importo` | decimal | Importo bollo | accesso {"show": ["show_fatture_clienti"]} | decimal(12,2) | 3/231 |
| `rit_acc_str` | string | Ritenuta d'acconto (aliquota) | valori ["4%", "20%", "23% sul 50%"]; accesso {"show": ["show_fatture_clienti"]} | varchar(191) | 0/231 |
| `rit_acc_aliq` | decimal | Ritenuta d'acconto (aliquota) | visibile se false; accesso {"show": ["show_fatture_clienti"]} | decimal(12,0) | 0/231 |
| `fattura_saldata` | boolean | Fattura saldata | sola lettura; default F; accesso {"show": ["show_fatture_clienti"]} | enum('F','T') NN | 231/231 · T=141, F=90 |
| `generata_fatt_elettronica` | boolean | Generata fatt. elettronica | obbl.; default F; accesso {"show": ["show_fatture_clienti"]} | enum('F','T') NN | 231/231 · T=197, F=34 |
| `lavoro_generazione_xml` | reference | Lavoro generazione XML | sola lettura; →fatture_clienti_genera_xml (restrict); accesso {"show": ["show_fatture_clienti"]} | int(11) | 0/231 |
| `log_generazione_fattura` | string | Log generazione XML fattura | sola lettura; accesso {"show": ["show_fatture_clienti"]} | mediumtext | 197/231 |
| `nome_file` | string | Nome file generato | sola lettura; accesso {"show": ["show_fatture_clienti"]} | varchar(191) | 197/231 |
| `riepilogo_iva` | inline_grid | Riepilogo IVA | sola lettura; accesso {"show": ["show_fatture_clienti"]} | text | 0/231 |
| `totale_netto` | decimal | Totale imponibile | sola lettura | decimal(12,2) | 231/231 |
| `totale_iva` | decimal | Totale IVA | sola lettura | decimal(12,2) | 231/231 |
| `totale_documento` | decimal | Totale documento | sola lettura | decimal(12,2) | 231/231 |
| `iva_non_dovuta` | decimal | IVA non dovuta | sola lettura; default 0 | decimal(12,2) | 231/231 |
| `rit_acc_tot` | decimal | Ritenuta d'acconto | sola lettura; accesso {"show": ["show_fatture_clienti"]} | decimal(12,2) | 231/231 |
| `rit_acc_imp` | decimal | Ritenuta d'acconto (imponibile) | sola lettura; accesso {"show": ["show_fatture_clienti"]} | decimal(12,2) | 231/231 |
| `totale_dovuto` | decimal | Totale dovuto | sola lettura | decimal(12,2) | 231/231 |
| `totale_netto_r` | decimal | Totale imponibile | visibile se false; calcolato in vista | vista |  |
| `totale_iva_r` | decimal | Totale IVA | visibile se false; calcolato in vista | vista |  |
| `totale_documento_r` | decimal | Totale documento | visibile se false; calcolato in vista | vista |  |
| `iva_non_dovuta_r` | decimal | IVA non dovuta | visibile se false; calcolato in vista | vista |  |
| `totale_dovuto_r` | decimal | Totale dovuto | visibile se false; calcolato in vista | vista |  |
| `rif_lav_gen_fatture_clienti` | reference | Rif. lav. gen. fatture clienti | sola lettura; →lavori_batch (restrict) | int(11) | 223/231 |
| `cli_rag_soc` | string | Ragione Sociale | obbl.; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 80 | varchar(80) NN | 231/231 |
| `cli_indirizzo` | string | Indirizzo | obbl.; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 60 | varchar(60) NN | 231/231 |
| `cli_cerca_comune` | reference | Cerca comune | →comuni (setnull); trascina ['cli_cap', 'cli_prov', 'cli_comune', 'cli_nazione'] | int(11) | 230/231 |
| `cli_comune` | string | Comune | obbl.; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 60 | varchar(60) NN | 231/231 |
| `cli_cap` | string | CAP |  | varchar(191) | 231/231 |
| `cli_prov` | string | Provincia | max 2 | varchar(2) | 231/231 |
| `cli_nazione` | reference | Nazione | →nazioni (restrict) | int(11) | 41/231 |
| `cli_cod_fis` | string | Codice Fiscale | check cf bloccante; max 16 | varchar(16) | 231/231 |
| `cli_p_iva` | string | Partita IVA | check piva bloccante; max 30 | varchar(30) | 231/231 |
| `cli_sdi_pec` | string | Codice SDI/PEC | accesso {"show": ["show_fatture_clienti"]}; aiuto: Codice destinatario o PEC per fattura elettronica.  | varchar(191) | 226/231 |
| `cli_rif_amministrazione` | string | Riferimento amministrazione fatt. elett… | regex `/^p{IsBasicLatin}+$/` bloccante; max 20; accesso {"show": ["show_fatture_clienti"]}; aiuto: Eventuale riferimento utile al destinatario per automatizzare la gestione amministrativa dell'operazione in fattura | varchar(20) | 3/231 |
| `cli_istituto_finanziario` | string | Banca cliente | regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 80; accesso {"show": ["show_fatture_clienti"]}; aiuto: Serve ad esempio nel caso di nota di credito | varchar(80) | 0/231 |
| `cli_iban` | string | IBAN banca cliente | check iban bloccante; max 34; accesso {"show": ["show_fatture_clienti"]}; aiuto: Serve ad esempio nel caso di nota di credito | varchar(34) | 0/231 |
| `cli_dich_intento` | boolean | Dichiarazione intento | obbl.; default F; accesso {"show": ["show_fatture_clienti"]} | enum('F','T') NN | 231/231 · F=226, T=5 |
| `cli_dich_intento_n` | string | N° dichiarazione intento | max 60; accesso {"show": ["show_fatture_clienti"]}; aiuto: Protocollo di ricezione della dichiarazione d’intento e il suo progressivo separato dal segno "-" (es. 08060120341234567-000001) | varchar(60) | 5/231 |
| `cli_dich_intento_data` | date | Data dichiarazione intento | accesso {"show": ["show_fatture_clienti"]} | date | 5/231 |
| `documento_emesso_in_seguito_a` | inline_grid | Documento emesso in seguito a | accesso {"show": ["show_fatture_clienti"]} | text | 107/231 |
| `almeno_un_importo_fattura_collab` | boolean | Almeno un importo con fattura collabora… | sola lettura; visibile se false; aiuto: Se tra gli importi collaboratori in cui viene referenziata questa fattura ce ne almeno uno con anche la fattura collaboratore | enum('F','T') NN | 231/231 · F=231 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull); accesso {"show": ["show_fatture_clienti"]} | int(11) | 231/231 |
| `last_update_ts` | datetime | Data modifica | sola lettura; accesso {"show": ["show_fatture_clienti"]} | datetime | 231/231 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 231/231)

## `fatture_clienti_doc_collegati` — Doc. collegati (fattura cliente)

- tipo meta: table · lettura: `fatture_clienti_doc_collegati` · decodifica: `fatture_clienti_doc_collegati_dec` · record: 129
- hook: php_gi_record_change_after=`gi_fatture_clienti_doc_collegati_change_after`
- indici: ['fattura']
- ordinamento: {'by': 'n_documento', 'dir': 'asc'}
- permessi: `show_fatture_clienti_doc_collegati`; `edit_fatture_clienti_doc_collegati`; `new_fatture_clienti_doc_collegati`; `delete_fatture_clienti_doc_collegati`
- azioni: show←show_fatture_clienti_doc_collegati; edit←edit_fatture_clienti_doc_collegati; new←new_fatture_clienti_doc_collegati; delete←delete_fatture_clienti_doc_collegati

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 129/129 |
| `fattura` | reference | Fattura | obbl.; →fatture_clienti (cascade) | int(11) NN | 129/129 |
| `tipo_documento` | enum | Tipo doc. | obbl.; valori {"OrdineAcquisto": "Ordine d'acquisto", "Contratto": "Contratto", "Convenzione": "Convenzione", "Ricezione": "Ricezione", "FattureCollegate": "Fattura collegata", "DDT": "Doc. di trasporto", "FatturaPrincipale": "Fattura principale"} | enum('OrdineAcquisto','Contratto','Convenzione','Ricezione','FattureCollegate','DDT','FatturaPrincipale') NN | 129/129 · OrdineAcquisto=112, Contratto=12, Ricezione=3, FattureCollegate=2 |
| `n_documento` | string | N° | obbl.; regex `/^p{IsBasicLatin}+$/` bloccante; max 20 | varchar(20) NN | 129/129 |
| `data_documento` | date | Data | obbl. | date NN | 129/129 |
| `cig` | string | CIG | regex `/^p{IsBasicLatin}+$/` bloccante; max 15 | varchar(15) | 5/129 |
| `cup` | string | CUP | regex `/^p{IsBasicLatin}+$/` bloccante; max 15 | varchar(15) | 1/129 |
| `commessa_convenzione` | string | Commessa / Convenzione | regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 100 | varchar(100) | 6/129 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull); visibile se false | int(11) | 129/129 |
| `last_update_ts` | datetime | Data modifica | sola lettura; visibile se false | datetime | 129/129 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 129/129)

## `fatture_clienti_genera_xml` — Lavori generazione XML fatture clienti

- tipo meta: table · lettura: `fatture_clienti_genera_xml` · decodifica: `fatture_clienti_genera_xml_dec` · record: 22
- ordinamento: {'by': 'inizio', 'dir': 'desc'}
- permessi: `gestione_fatture_clienti_genera_xml`
- azioni: show←gestione_fatture_clienti_genera_xml; new←gestione_fatture_clienti_genera_xml; start←gestione_fatture_clienti_genera_xml

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura | int(11) NN | 22/22 |
| `utente` | reference | Utente | obbl.; sola lettura; default #id; →utenti (restrict); accesso {"show": ["gestione_fatture_clienti_genera_xml"]} | int(11) NN | 22/22 |
| `files` | files | Files | sola lettura; file server | text | 22/22 |
| `inizio` | datetime | Inizio | sola lettura; default gi_date_default() | datetime | 22/22 |
| `fine` | datetime | Fine | sola lettura | datetime | 22/22 |
| `execution_type` | enum | Tipo Esecuzione | obbl.; sola lettura; default B; valori {"I": "Immediata", "B": "Batch"} | enum('I','B') NN | 22/22 · B=22 |
| `stato` | enum | Stato | sola lettura; valori {"A": "In elaborazione", "TS": "Terminato con successo", "TW": "Terminato con warning", "TE": "Terminato con errore"} | enum('A','TS','TW','TE') | 22/22 · TS=22 |
| `num_righe_proc` | integer | N° righe | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 22/22 |
| `num_righe_succ` | integer | Successo | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 22/22 |
| `num_righe_err` | integer | Errore | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 22/22 |
| `which_items` | enum | Voci | obbl.; valori {"selected": "Selezionate con spunta", "all": "Tutte (filtrate)"} | enum('selected','all') NN | 22/22 · selected=22 |
| `json` | custom | Json | obbl.; visibile se false | mediumtext NN | 22/22 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault) | int(11) | 22/22 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 22/22 |
| `progress` | integer | Progresso | sola lettura; default 0 | int(11) | 22/22 |
| `log` | log | Messaggi | sola lettura | — |  |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 22/22)

## `fatture_clienti_iva` — Riepilogo IVA (fattura cliente)

- tipo meta: table · lettura: `fatture_clienti_iva` · decodifica: `fatture_clienti_iva_dec` · record: 232
- univoci: ['fattura', 'codice_iva']
- ordinamento: {'by': 'iva', 'dir': 'desc'}
- permessi: `show_fatture_clienti_iva`
- azioni: show←show_fatture_clienti_iva

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 232/232 |
| `fattura` | reference | Fattura | obbl.; →fatture_clienti (cascade) | int(11) NN | 232/232 |
| `codice_iva` | reference | Codice IVA | obbl.; →iva (restrict) | int(11) NN | 232/232 |
| `imponibile` | decimal | Imponibile | obbl.; default 0 | decimal(12,2) NN | 232/232 |
| `iva` | decimal | IVA | obbl.; default 0 | decimal(12,2) NN | 232/232 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull); visibile se false | int(11) | 232/232 |
| `last_update_ts` | datetime | Data modifica | sola lettura; visibile se false | datetime | 232/232 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 232/232)

## `fatture_clienti_righe` — Righe (fattura cliente)

- tipo meta: table · lettura: `fatture_clienti_righe_read` · decodifica: `fatture_clienti_righe_dec` · record: 1171
- hook: php_gi_record_save_before=`gi_fatture_clienti_righe_save_before`, php_gi_record_change_after=`gi_fatture_clienti_righe_change_after`, js_gi_form_create_and_show_after=`js_gi_form_create_and_show_fatture_clienti_righe_after`, js_gi_form_create_and_show_form_fields_set_after=`js_gi_form_create_and_show_fatture_clienti_righe_after`
- univoci: ['fattura', 'n_riga']
- indici: ['fattura']; ['codice_iva']
- ordinamento: {'by': 'n_riga', 'dir': 'asc'}
- permessi: `show_fatture_clienti_righe`; `edit_fatture_clienti_righe` [cond: t.almeno_un_importo_fattura_collab = 'F']; `new_fatture_clienti_righe`; `delete_fatture_clienti_righe` [cond: t.almeno_un_importo_fattura_collab = 'F']
- azioni: show←show_fatture_clienti_righe; edit←edit_fatture_clienti_righe; new←new_fatture_clienti_righe; delete←delete_fatture_clienti_righe
- altre proprietà: {"show_stats": true}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 1171/1171 |
| `fattura` | reference | Fattura | obbl.; →fatture_clienti (cascade); trascina ['codice_iva'] | int(11) NN | 1171/1171 |
| `n_riga` | integer | N° riga | obbl.; default gi_nextcode_get($id,$fattura) | int(11) NN | 1171/1171 |
| `tipo_riga` | enum | Tipo riga | obbl.; default RG; valori {"RG": "Normale", "TX": "Nota libera", "AC": "Spesa accessoria"} | enum('RG','TX','AC') NN | 1171/1171 · RG=1170, AC=1 |
| `codice_articolo` | string | Cod. Articolo | regex `/^p{IsBasicLatin}+$/` bloccante; max 35 | varchar(35) | 0/1171 |
| `descrizione` | string | Descrizione | obbl.; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante | text NN | 1171/1171 |
| `quantita` | decimal | Quantità | obbl.; default 1 | decimal(12,2) NN | 1171/1171 |
| `unita_misura` | string | UM | valori ["nr", "kg", "lt", "mt", "ore", "pz"]; regex `/^p{IsBasicLatin}+$/` bloccante; max 10 | varchar(10) | 0/1171 |
| `prezzo_unitario` | decimal | Prezzo | obbl.; default 0 | decimal(12,2) NN | 1171/1171 |
| `totale_netto` | decimal | Totale netto | sola lettura | decimal(12,2) | 1171/1171 |
| `codice_iva` | reference | Cod. IVA | obbl.; default gi_reference_default_get('predefinito'); →iva (restrict) | int(11) NN | 1171/1171 |
| `rit_acc_flag` | boolean | Ritenuta d'acconto | default fw_documenti_righe_rit_acc_flag("fattur… | enum('F','T') NN | 1171/1171 · F=1171 |
| `preventivo` | reference | Preventivo | sola lettura; →preventivi (restrict) | int(11) | 1156/1171 |
| `almeno_un_importo_fattura_collab` | boolean | Almeno un importo con fattura collabora… | visibile se false; calcolato in vista; aiuto: Se tra gli importi collaboratori in cui viene referenziata questa fattura ce ne almeno uno con anche la fattura collaboratore | vista |  |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull) | int(11) | 1171/1171 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 1171/1171 |

Colonne fisiche senza campo nei metadati: `verifica` (int(11); 0/1171), `tecnico` (int(11); 0/1171), `tecnico_aff` (int(11); 0/1171), `codice_verifica` (varchar(191); 0/1171), `last_update_nr` (int(11); 1171/1171)

## `fatture_collaboratori` — Fatture Collaboratori

- tipo meta: table · lettura: `fatture_collaboratori_read` · decodifica: `fatture_collaboratori_dec` · record: 3
- univoci: ['numero_fattura', 'data_fattura', 'collaboratore']
- indici: ['collaboratore']; ['data_fattura']
- ordinamento: {'by': 'data_fattura', 'dir': 'desc'}
- permessi: `show_fatture_collaboratori`; `show_fatture_collaboratori_collaboratore` [cond: t.collaboratore=#id]; `edit_fatture_collaboratori`; `new_fatture_collaboratori`; `delete_fatture_collaboratori`
- azioni: show←show_fatture_collaboratori|show_fatture_collaboratori_collaboratore; edit←edit_fatture_collaboratori; new←new_fatture_collaboratori; delete←delete_fatture_collaboratori

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 3/3 |
| `collaboratore` | reference | Collaboratore | obbl.; →utenti (restrict) | int(11) NN | 3/3 |
| `numero_fattura` | string | Numero Fattura | obbl. | varchar(191) NN | 3/3 |
| `data_fattura` | date | Data Fattura | obbl. | date NN | 3/3 |
| `imponibile` | decimal | Imponibile | obbl.; default 0 | decimal(12,2) NN | 3/3 |
| `totale` | decimal | Totale | obbl.; default 0 | decimal(12,2) NN | 3/3 |
| `differenza` | decimal | Differenza | sola lettura; accesso {"show": ["show_fatture_collaboratori"]}; aiuto: Imponibile fattura - somma importi collaboratori associati a questa fattura | decimal(12,2) | 0/3 |
| `alert_differenza` | enum | Alert Differenza | valori {"differente": "Differente", "non_differente": "Non differente"}; visibile se false; calcolato in vista; accesso {"show": ["show_fatture_collaboratori"]} | vista |  |
| `saldata` | boolean | Saldata | accesso {"show": ["show_fatture_collaboratori"]} | enum('F','T') NN | 3/3 · T=3 |
| `allegati` | files | Allegati | file s3 | text | 3/3 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull); accesso {"show": ["show_fatture_collaboratori"]} | int(11) | 3/3 |
| `last_update_ts` | datetime | Data modifica | sola lettura; accesso {"show": ["show_fatture_collaboratori"]} | datetime | 3/3 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 3/3)

## `gi_exports` — Esportazioni

- tipo meta: table · lettura: `gi_exports_batch` · decodifica: `gi_exports_dec` · record: 9
- ordinamento: {'by': 'id', 'dir': 'desc'}
- permessi: `gestione_esportazioni`; `gestione_esportazioni_proprie` [cond: #id = t.utente]
- azioni: show←gestione_esportazioni|gestione_esportazioni_proprie; new←gestione_esportazioni|gestione_esportazioni_proprie; start←gestione_esportazioni|gestione_esportazioni_proprie
- altre proprietà: {"list_mobile": [{"field": "id", "left": "stato", "title": "meta_name", "subtitle": ["utente"], "right_top": ["progress"], "right_bottom": ["fine"]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura | int(11) NN | 9/9 |
| `utente` | reference | Utente | obbl.; sola lettura; default #id; →utenti (restrict); accesso {"show": ["gestione_esportazioni"]} | int(11) NN | 9/9 |
| `files` | files | Files | sola lettura; file s3 | text | 9/9 |
| `files_link` | custom | Files | sola lettura; visibile se false | mediumtext | 9/9 |
| `inizio` | datetime | Inizio | sola lettura; default gi_date_default() | datetime | 9/9 |
| `fine` | datetime | Fine | sola lettura | datetime | 9/9 |
| `execution_type` | enum | Tipo Esecuzione | obbl.; valori {"I": "Immediata", "B": "Batch"} | enum('I','B') NN | 9/9 · I=9 |
| `stato` | enum | Stato | sola lettura; valori {"A": "In elaborazione", "TS": "Terminato con successo", "TW": "Terminato con warning", "TE": "Terminato con errore"} | enum('A','TS','TW','TE') | 9/9 · TS=9 |
| `num_righe_proc` | integer | N° righe | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 9/9 |
| `num_righe_succ` | integer | Successo | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 9/9 |
| `num_righe_err` | integer | Errore | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 9/9 |
| `meta_name` | string | Anagrafica | obbl. | varchar(191) NN | 9/9 |
| `export_format` | enum | Formato | obbl.; valori {"csv": "CSV (Più veloce e Compatibile)", "xls": "XLS (Excel 95 in poi)", "xlsx": "XLSX (Excel 2007 in poi)", "ods": "ODS (Libre/OpenOffice Calc)"} | enum('csv','xls','xlsx','ods') NN | 9/9 · xlsx=9 |
| `incude_attachments` | boolean | Includi allegati? | obbl.; default F | enum('F','T') NN | 9/9 · F=9 |
| `which_items` | enum | Voci | obbl.; valori {"selected": "Selezionate con spunta", "all": "Tutte (filtrate)"} | enum('selected','all') NN | 9/9 · all=8, selected=1 |
| `json` | custom | Json | obbl.; visibile se false | mediumtext NN | 9/9 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault) | int(11) | 9/9 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 9/9 |
| `progress` | integer | Progresso | sola lettura; default 0 | int(11) | 9/9 |
| `log` | log | Messaggi | sola lettura | — |  |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 9/9)

## `gi_i18n` — 

- tipo meta: i18n
- altre proprietà: {"locales": [{"name": "it", "lc_messages": "it_IT", "tinymce_language": "it", "datetimepicker_language": "it", "label": "Ita (IT)", "timezone": "Europe/Rome", "date_format": "d/m/Y", "time_format": "H:i:s", "date_mask": "__/__/____", "time_mask": "__:__:__", "csv_delimiter": ";", "csv_enclosure": "\"", "decimal": ","}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `gi_imports` — Importazioni

- tipo meta: table · lettura: `gi_imports` · decodifica: `gi_imports_dec`
- ordinamento: {'by': 'id', 'dir': 'desc'}
- permessi: `gestione_importazioni`; `gestione_importazioni_proprie` [cond: #id = t.utente]
- azioni: show←gestione_importazioni|gestione_importazioni_proprie; new←gestione_importazioni|gestione_importazioni_proprie; start←gestione_importazioni|gestione_importazioni_proprie
- altre proprietà: {"list_mobile": [{"field": "id", "left": "stato", "title": "meta_name", "subtitle": ["utente"], "right_top": ["progress"], "right_bottom": ["fine"]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura | — |  |
| `utente` | reference | Utente | obbl.; sola lettura; default #id; →utenti (restrict); accesso {"show": ["gestione_importazioni"]} | — |  |
| `file_to_process` | files | Upload | obbl.; file s3 | — |  |
| `inizio` | datetime | Inizio | sola lettura; default gi_date_default() | — |  |
| `fine` | datetime | Fine | sola lettura | — |  |
| `stato` | enum | Stato | sola lettura; valori {"A": "In elaborazione", "TS": "Terminato con successo", "TW": "Terminato con warning", "TE": "Terminato con errore"} | — |  |
| `num_righe_proc` | integer | N° righe | obbl.; sola lettura; default 0; visibile se false | — |  |
| `num_righe_succ` | integer | Successo | obbl.; sola lettura; default 0; visibile se false | — |  |
| `num_righe_err` | integer | Errore | obbl.; sola lettura; default 0; visibile se false | — |  |
| `meta_name` | string | Anagrafica | obbl. | — |  |
| `json` | custom | Json | obbl. | — |  |
| `last_update_user` | reference | Utente Modifica | sola lettura; →utenti (setdefault) | — |  |
| `last_update_ts` | datetime | Data Modifica | sola lettura | — |  |
| `progress` | integer | Progresso | sola lettura; default 0 | — |  |
| `log` | log | Messaggi | sola lettura | — |  |

## `gi_mails` — E-mail

- tipo meta: table · lettura: `gi_mails_read` · decodifica: `gi_mails_dec` · record: 190
- ordinamento: {'by': 'inizio', 'dir': 'desc'}
- permessi: `gestione_mails`; `gestione_mails_proprie` [cond: #id = t.utente]
- azioni: show←gestione_mails|gestione_mails_proprie; new←gestione_mails|gestione_mails_proprie; start←gestione_mails|gestione_mails_proprie
- altre proprietà: {"list_mobile": [{"field": "id", "left": "stato", "title": "meta_name", "subtitle": ["emails_to", "email_subject", "utente"], "right_top": ["progress"], "right_bottom": ["fine"]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura; visibile se false | int(11) NN | 190/190 |
| `utente` | reference | Utente | obbl.; default #id; →utenti (restrict); accesso {"show": ["gestione_mails"]} | int(11) NN | 190/190 |
| `email_cfg` | string | email_cfg | sola lettura; visibile se false | text | 190/190 |
| `emails_to` | tags | A | check emails bloccante | text | 190/190 |
| `emails_cc` | tags | Cc | check emails bloccante | text | 190/190 |
| `emails_bcc` | tags | Ccn | check emails bloccante | text | 190/190 |
| `emails_reply_to` | string | emails_reply_to | sola lettura; visibile se false | varchar(191) | 0/190 |
| `email_subject` | string | Oggetto |  | varchar(191) | 190/190 |
| `email_body` | string | Corpo | visibile se false | text | 190/190 |
| `email_body_read` | string | Corpo | calcolato in vista | vista |  |
| `email_altbody` | string | email_altbody | sola lettura; visibile se false | text | 0/190 |
| `email_is_html` | boolean | email_is_html | sola lettura; visibile se false | enum('F','T') NN | 190/190 · T=190 |
| `email_body_basedir` | string | email_body_basedir | sola lettura; visibile se false | varchar(191) | 0/190 |
| `email_custom_headers` | string | email_custom_headers | sola lettura; visibile se false | text | 190/190 |
| `allegati` | files | Allegati | file server | text | 190/190 |
| `email_attachments` | custom | Files | sola lettura; visibile se false | mediumtext | 190/190 |
| `inizio` | datetime | Inizio invio | sola lettura; default gi_date_default() | datetime | 190/190 |
| `fine` | datetime | Fine invio | sola lettura | datetime | 190/190 |
| `stato` | enum | Stato | sola lettura; valori {"A": "In invio", "TS": "Inviata con successo", "TW": "Inviata con warning", "TE": "Errore durante l'invio"} | enum('A','TS','TW','TE') | 190/190 · TS=190 |
| `progress` | integer | Progresso | sola lettura; default 0 | int(11) | 190/190 |
| `log` | log | Messaggi | sola lettura | — |  |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault) | int(11) | 190/190 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 190/190 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 190/190)

## `gi_multiedits` — Modifiche multiple

- tipo meta: table · lettura: `gi_multiedits` · decodifica: `gi_multiedits_dec` · record: 700
- ordinamento: {'by': 'id', 'dir': 'desc'}
- permessi: `gestione_modifiche_multiple`; `gestione_modifiche_multiple_proprie` [cond: #id = t.utente]
- azioni: show←gestione_modifiche_multiple|gestione_modifiche_multiple_proprie; new←gestione_modifiche_multiple|gestione_modifiche_multiple_proprie; start←gestione_modifiche_multiple|gestione_modifiche_multiple_proprie
- altre proprietà: {"list_mobile": [{"field": "id", "left": "stato", "title": "meta_name", "subtitle": ["utente"], "right_top": ["progress"], "right_bottom": ["fine"]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura; visibile se false | int(11) NN | 700/700 |
| `utente` | reference | Utente | obbl.; sola lettura; default #id; →utenti (restrict); accesso {"show": ["gestione_modifiche_multiple"]} | int(11) NN | 700/700 |
| `inizio` | datetime | Inizio | sola lettura; default gi_date_default() | datetime | 700/700 |
| `fine` | datetime | Fine | sola lettura | datetime | 700/700 |
| `stato` | enum | Stato | sola lettura; valori {"A": "In elaborazione", "TS": "Terminato con successo", "TW": "Terminato con warning", "TE": "Terminato con errore"} | enum('A','TS','TW','TE') | 700/700 · TS=681, TE=14, TW=5 |
| `num_righe_proc` | integer | N° righe | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 700/700 |
| `num_righe_succ` | integer | Successo | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 700/700 |
| `num_righe_err` | integer | Errore | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 700/700 |
| `meta_name` | string | Anagrafica | obbl. | varchar(191) NN | 700/700 |
| `json` | custom | Json | obbl. | mediumtext NN | 700/700 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault) | int(11) | 700/700 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 700/700 |
| `progress` | integer | Progresso | sola lettura; default 0 | int(11) | 700/700 |
| `log` | log | Messaggi | sola lettura | — |  |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 700/700)

## `gi_reports` — Stampe

- tipo meta: table · lettura: `gi_reports_batch` · decodifica: `gi_reports_dec` · record: 624
- ordinamento: {'by': 'id', 'dir': 'desc'}
- permessi: `gestione_stampe`; `gestione_stampe_proprie` [cond: #id = t.utente]
- azioni: show←gestione_stampe|gestione_stampe_proprie; new←gestione_stampe|gestione_stampe_proprie; start←gestione_stampe|gestione_stampe_proprie
- altre proprietà: {"list_mobile": [{"field": "id", "left": "stato", "title": "meta_name", "subtitle": ["utente"], "right_top": ["progress"], "right_bottom": ["fine"]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura | int(11) NN | 624/624 |
| `utente` | reference | Utente | obbl.; sola lettura; default #id; →utenti (restrict); accesso {"show": ["gestione_stampe"]} | int(11) NN | 624/624 |
| `files` | files | Files | sola lettura; file server | text | 624/624 |
| `files_data` | custom | Files | sola lettura; visibile se false | mediumtext | 624/624 |
| `inizio` | datetime | Inizio | sola lettura; default gi_date_default() | datetime | 624/624 |
| `fine` | datetime | Fine | sola lettura | datetime | 624/624 |
| `execution_type` | enum | Tipo esecuzione | obbl.; valori {"I": "Immediata", "B": "Batch"} | enum('I','B') NN | 624/624 · I=624 |
| `stato` | enum | Stato | sola lettura; valori {"A": "In stampa", "TS": "Terminata con successo", "TW": "Terminata con warning", "TE": "Terminata con errore"} | enum('A','TS','TW','TE') | 624/624 · TS=624 |
| `num_righe_proc` | integer | N° righe | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 624/624 |
| `num_righe_succ` | integer | Successo | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 624/624 |
| `num_righe_err` | integer | Errore | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 624/624 |
| `meta_name` | string | Anagrafica | obbl. | varchar(191) NN | 624/624 |
| `template_meta_name` | string | Modello Stampa | obbl. | varchar(191) NN | 624/624 |
| `which_items` | enum | Voci | obbl.; valori {"selected": "Selezionate con spunta", "all": "Tutte (filtrate)"} | enum('selected','all') NN | 624/624 · selected=624 |
| `json` | custom | Json | obbl.; visibile se false | mediumtext NN | 624/624 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault) | int(11) | 624/624 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 624/624 |
| `progress` | integer | Progresso | sola lettura; default 0 | int(11) | 624/624 |
| `log` | log | Messaggi | sola lettura | — |  |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 624/624)

## `gi_user_settings` — Impostazioni utenti

- tipo meta: table · lettura: `gi_user_settings` · record: 56
- univoci: ['utente', 'session_key', 'entity']
- ordinamento: {'by': 'id', 'dir': 'desc'}
- altre proprietà: {"show_stats": false}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | obbl.; sola lettura; visibile se false | int(11) NN | 56/56 |
| `utente` | reference | Utente | obbl.; →utenti (cascade) | int(11) NN | 56/56 |
| `session_key` | string | Chiave Sessione | obbl. | varchar(191) NN | 56/56 |
| `entity` | string | Entità | obbl. | varchar(191) NN | 56/56 |
| `json` | custom | Json |  | mediumtext | 56/56 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 56/56)

## `importi_collaboratori` — Importi collaboratori

- tipo meta: table · lettura: `importi_collaboratori_read` · decodifica: `importi_collaboratori_dec` · record: 2842
- hook: php_gi_record_save_before=`gi_importi_collaboratori_save_before`, php_gi_record_change_after=`gi_importi_collaboratori_change_after`
- ordinamento: {'by': 'preventivo', 'dir': 'desc'}
- permessi: `show_importi_collaboratori`; `show_importi_collaboratori_collaboratore` [cond: t.collaboratore=#id]; `edit_importi_collaboratori`; `multiedit_importi_collaboratori`; `export_importi_collaboratori`
- azioni: show←show_importi_collaboratori|show_importi_collaboratori_collaboratore; edit←edit_importi_collaboratori; multiedit←multiedit_importi_collaboratori; export←export_importi_collaboratori
- altre proprietà: {"ddl": false, "group": {"by": "collaboratore", "dir": "asc"}, "show_stats": true}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 2842/2842 |
| `collaboratore` | reference | Collaboratore | →utenti (noaction); calcolato in vista; no multiedit | vista |  |
| `perc_collab_punto_sottop` | decimal | Percentuale collaboratore | calcolato in vista; no multiedit | vista |  |
| `imp_finale` | decimal | Prezzo finale | calcolato in vista; no multiedit | decimal(12,2) | 2201/2842 |
| `imp_collaboratore` | decimal | Importo collaboratore | calcolato in vista; no multiedit | vista |  |
| `stato_importo` | enum | Stato importo | valori {"assegnato": "Assegnato", "fatturabile": "Fatturabile", "fatturato": "Fatturato"}; calcolato in vista; no multiedit | vista |  |
| `cliente` | reference | Cliente | →clienti (noaction); calcolato in vista; no multiedit | vista |  |
| `sede_operativa` | reference | Sede operativa | →clienti_sedi_operative (noaction); calcolato in vista; no multiedit | vista |  |
| `preventivo` | reference | Preventivo | →preventivi (noaction); calcolato in vista; no multiedit | int(11) NN | 2842/2842 |
| `riga_preventivo` | reference | Riga Preventivo | →preventivi_righe (noaction); calcolato in vista; no multiedit | vista |  |
| `fattura` | reference | Fattura cliente | →fatture_clienti (noaction); calcolato in vista; no multiedit | int(11) | 1201/2842 |
| `fattura_saldata` | boolean | Fattura cliente saldata | calcolato in vista; accesso {"show": ["show_importi_collaboratori"]}; no multiedit | vista |  |
| `fattura_collab` | reference | Fattura collaboratore | sola lettura se $stato_importo == "assegnato"; →fatture_collaboratori (setnull); visibile se $stato_importo != "assegnato" | int(11) | 0/2842 |
| `fattura_collab_saldata` | boolean | Fattura collaboratore saldata | calcolato in vista; accesso {"show": ["show_importi_collaboratori"]}; no multiedit | vista |  |
| `titolo_punto` | string | Titolo (punto) | calcolato in vista; no multiedit | vista |  |
| `descrizione_sottopunto` | string | Descrizione (sottopunto) | calcolato in vista; no multiedit | vista |  |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull); accesso {"show": ["show_importi_collaboratori"]}; no multiedit | int(11) | 2842/2842 |
| `last_update_ts` | datetime | Data modifica | sola lettura; accesso {"show": ["show_importi_collaboratori"]}; no multiedit | datetime | 2842/2842 |

Colonne fisiche senza campo nei metadati: `tip_riga` (enum('P','S'); 2842/2842), `n_riga` (int(11); 2842/2842), `n_riga_sottopunto` (int(11); 2226/2842), `punto` (int(11); 2226/2842), `stato_riga` (enum('da_accettare','accettata','rifiutata'); 2226/2842), `cerca_articolo` (int(11); 569/2842), `titolo` (varchar(191); 616/2842), `scadenza` (int(11); 0/2842), `descrizione` (text; 2841/2842), `attrezzatura` (int(11); 2842/2842), `valvola` (int(11); 622/2842), `tipo_scad` (enum('cnd','suppl','taratura','altro'); 2226/2842), `tip_prezzo` (enum('S','C'); 2842/2842), `imp_netto` (decimal(12,2); 2190/2842), `nota_finale` (text; 550/2842), `inser_scadenze` (int(11); 0/2842), `stato_attivita` (enum('da_programmare','programmata','effettuata','annullata'); 1753/2842), `data_program` (date; 367/2842), `last_update_nr` (int(11); 2842/2842), `data_esecuzione` (date; 1189/2842), `data_prox_scadenza` (date; 619/2842), `note` (text; 41/2842), `sconto` (decimal(12,2); 219/2842), `tipo_sconto` (enum('P','A'); 219/2842), `imp_scontato` (decimal(12,2); 2201/2842), `perc_collab` (decimal(12,2); 160/2842), `da_sinc_adsrl` (enum('T','F','S'); 2226/2842), `almeno_un_sottopunto_accettato` (enum('F','T'); 2842/2842), `almeno_un_sottopunto_effettuato` (enum('F','T'); 2842/2842), `almeno_un_sottopunto_fatturato` (enum('F','T'); 2842/2842), `lettera` (varchar(191); 0/2842), `importo_totale_punto` (decimal(12,2); 0/2842), `importo_totale_scontato_punto` (decimal(12,2); 0/2842), `almeno_un_sottopunto_scontato` (enum('F','T'); 2842/2842), `descr_sottopunti` (text; 603/2842)

## `iva` — Aliquote IVA

- tipo meta: table · lettura: `iva` · decodifica: `iva_dec` · record: 32
- hook: php_gi_ddl_table_create_custom=`gi_ddl_table_create_iva`, php_gi_record_change_after=`php_gi_predefinito_change_after`
- univoci: ['codice']
- ordinamento: {'by': 'codice', 'dir': 'asc'}
- permessi: `show_iva`; `edit_iva`; `new_iva`; `delete_iva`
- azioni: show←show_iva; edit←edit_iva; new←new_iva; delete←delete_iva

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | ID | sola lettura; visibile se false | int(11) NN | 32/32 |
| `predefinito` | boolean | Predefinito | obbl.; default F | enum('F','T') NN | 32/32 · F=31, T=1 |
| `codice` | string | Codice Iva | obbl. | varchar(191) NN | 32/32 |
| `perc_iva` | decimal | Imposta | obbl.; default 0 | decimal(12,2) NN | 32/32 |
| `perc_iva_indetr` | decimal | Indetr. | obbl.; default 0 | decimal(12,2) NN | 32/32 |
| `classe_iva` | enum | Classe Iva | obbl.; default Imponibile; valori {"Imponibile": "Imponibile", "N1": "N1:  Escluso art. 15", "N2.1": "N2.1:  Non soggetto art. 7-7septis", "N2.2": "N2.2:  Non soggetto (altri casi) / Escluso / Fuori campo", "N2.2to": "N2.2:  Non soggetto (ma riportato nel \"Tot. operazioni\" in Liq. Iva)", "N3.1": "N3.1:  Non imponibile (esportazioni)", "N3.2": "N3.2:  Non imponibile (cessioni UE)", "N3.3": "N3.3:  Non imponibile (cessioni San Ma… | enum('Imponibile','N1','N2.1','N2.2','N2.2to','N3.1','N3.2','N3.3','N3.4','N3.5','N3.6','N4','N5','N6.1','N6.2','N6.3','N6.4','N6.5','N6.6','N6.7','N6.8','N6.9','N7','SplitPayment') NN | 32/32 · Imponibile=7, SplitPayment=4, N4=3, N2.2=3, N3.1=2, N2.1=2, N6.7=1, N6.6=1 |
| `descrizione` | string | Descrizione |  | varchar(191) | 32/32 |
| `note` | string | Note uso interno |  | text | 24/32 |
| `last_update_user` | reference | Utente Modifica | sola lettura; →utenti (setdefault) | int(11) | 0/32 |
| `last_update_ts` | datetime | Data Modifica | sola lettura | datetime | 1/32 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 32/32)

## `lavori_batch` — Lavori batch

- tipo meta: table · lettura: `lavori_batch` · decodifica: `lavori_batch_dec` · record: 612
- hook: php_gi_record_save_before=`gi_lavori_batch_save_before`
- ordinamento: {'by': 'id', 'dir': 'desc'}
- permessi: `show_lavori_batch`; `show_lavori_batch_propri` [cond: t.utente = #id]; `new_lavori_batch`; `delete_lavori_batch` [cond: t.stato <> 'A']; `start_lavori_batch`
- azioni: show←show_lavori_batch|show_lavori_batch_propri; new←new_lavori_batch; delete←delete_lavori_batch; start←start_lavori_batch

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `procedura` | enum | Procedura | obbl.; default Azione Custom; valori {"Azione Custom": "Azione da griglia"} | enum('Azione NN | 612/612 · Azione Custom=612 |
| `file_to_process` | files | Upload/Download | file s3 | text | 612/612 |
| `stato` | enum | Stato | sola lettura; valori {"A": "Attivo", "TS": "Terminato con Successo", "TW": "Terminato con Warning", "TE": "Terminato con Errore"} | enum('A','TS','TW','TE') | 612/612 · TS=340, TW=146, TE=126 |
| `progress` | integer | Progresso | sola lettura; default 0 | int(11) | 612/612 |
| `log` | log | Messaggi | sola lettura | — |  |
| `inizio` | datetime | Inizio | sola lettura; default gi_date_default() | datetime | 612/612 |
| `fine` | datetime | Fine | sola lettura | datetime | 612/612 |
| `id` | integer | Codice | sola lettura | int(11) NN | 612/612 |
| `utente` | reference | Utente avvio | obbl.; sola lettura; default #id; →utenti (restrict) | int(11) NN | 612/612 |
| `action_name` | string | Azione | sola lettura | varchar(191) | 612/612 |
| `meta_name` | string | Sorgente | sola lettura | varchar(191) | 612/612 |
| `which_items` | string | Elementi sorgente | sola lettura; visibile se false | varchar(191) | 612/612 |
| `json` | string | Parametri di lancio | sola lettura; visibile se false | mediumtext | 612/612 |
| `last_update_user` | reference | Utente Modifica | sola lettura; →utenti (setdefault) | int(11) | 612/612 |
| `last_update_ts` | datetime | Data Modifica | sola lettura | datetime | 612/612 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 612/612)

## `nazioni` — Nazioni

- tipo meta: table · lettura: `nazioni` · decodifica: `nazioni_dec` · record: 223
- hook: php_gi_ddl_table_create_custom=`gi_ddl_table_create_comuni`
- univoci: ['nazione']
- ordinamento: {'by': 'nazione', 'dir': 'asc'}
- permessi: `show_nazioni`; `edit_nazioni`; `new_nazioni`; `delete_nazioni`
- azioni: show←show_nazioni; edit←edit_nazioni; new←new_nazioni; delete←delete_nazioni
- altre proprietà: {"list_mobile": [{"field": "id", "left": "nazione", "title": "nazione"}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | ID | sola lettura; visibile se false | int(11) NN | 223/223 |
| `nazione` | string | Nazione | obbl. | varchar(191) NN | 223/223 |
| `codice_at` | string | Codice AT | aiuto: Serve per il calcolo del codice fiscale per i nati all'estero | varchar(191) | 215/223 |
| `codice_iso_alpha2` | string | Codice ISO 3166 alpha2 | obbl.; max 2 | varchar(2) NN | 223/223 |
| `codice_iso_alpha3` | string | Codice ISO 3166 alpha3 | obbl.; max 3 | varchar(3) NN | 223/223 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault) | int(11) | 0/223 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 223/223 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 223/223)

## `pagamenti` — Pagamenti

- tipo meta: table · lettura: `pagamenti_read` · decodifica: `pagamenti_dec` · record: 231
- hook: php_gi_record_save_before=`gi_pagamenti_save_before`
- ordinamento: {'by': 'data_scadenza', 'dir': 'asc'}
- permessi: `show_pagamenti`; `edit_pagamenti` [cond: NOT EXISTS(SELECT 1 FROM importi_collaboratori_read c WHERE c.fattura = t.fattura_cliente AND c.fattura_collab IS NOT NULL LIMIT 1)]; `new_pagamenti`; `delete_pagamenti` [cond: NOT EXISTS(SELECT 1 FROM importi_collaboratori_read c WHERE c.fattura = t.fattura_cliente AND c.fattura_collab IS NOT NULL LIMIT 1)]
- azioni: show←show_pagamenti; edit←edit_pagamenti; new←new_pagamenti; delete←delete_pagamenti
- altre proprietà: {"show_stats": true}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura; visibile se false | int(11) NN | 231/231 |
| `data_scadenza` | date | Data scadenza | obbl. | date NN | 231/231 |
| `fattura_cliente` | reference | Fattura cliente | obbl.; →fatture_clienti (cascade); trascina ['cliente']; accesso {"edit": ["__never__"]} | int(11) NN | 231/231 |
| `cliente` | reference | Cliente | →clienti (noaction); calcolato in vista | vista |  |
| `descrizione` | string | Descrizione |  | varchar(191) | 231/231 |
| `rif_pagamento` | string | Rif. pagamento (Es. Assegno nr ..., CRO… |  | varchar(191) | 0/231 |
| `tipo_pagamento` | enum | Tipo pagamento | obbl.; valori {"E": "Entrata", "U": "Uscita"} | enum('E','U') NN | 231/231 · E=228, U=3 |
| `importo` | decimal | Importo |  | decimal(12,2) | 231/231 |
| `entrata` | decimal | Entrata | visibile se false; calcolato in vista | vista |  |
| `uscita` | decimal | Uscita | visibile se false; calcolato in vista | vista |  |
| `saldato` | boolean | Saldato | obbl.; default F | enum('F','T') NN | 231/231 · T=141, F=90 |
| `note` | string | Note |  | text | 150/231 |
| `last_update_user` | reference | Utente Modifica | sola lettura; →utenti (setdefault) | int(11) | 231/231 |
| `last_update_ts` | datetime | Data Modifica | sola lettura | datetime | 231/231 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 231/231)

## `pagamenti_flat` — Pagamenti

- tipo meta: table
- altre proprietà: {"extends_meta": "pagamenti"}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `preventivi` — Preventivi

- tipo meta: table · lettura: `preventivi_read` · decodifica: `preventivi_dec` · record: 349
- hook: php_gi_record_save_before=`gi_preventivi_save_before`
- univoci: ['serie_preventivo', 'numero_preventivo']
- indici: ['cliente']
- ordinamento: {'by': 'anno_numero_preventivo', 'dir': 'desc'}
- permessi: `show_preventivi`; `show_preventivi_collaboratore` [cond: t.collaboratore=#id]; `edit_preventivi`; `new_preventivi`; `delete_preventivi`; `print_preventivi` [cond: t.n_righe_anomale IS NULL OR t.n_righe_anomale = 0]
- azioni: show←show_preventivi|show_preventivi_collaboratore; edit←edit_preventivi; new←new_preventivi; delete←delete_preventivi; print←
- altre proprietà: {"show_stats": true}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 349/349 |
| `stato_preventivo` | enum | Stato preventivo | obbl.; default creato; valori {"creato": "Creato", "inviato": "Inviato", "accettato": "Accettato", "accettato_parzialmente": "Accettato parzialmente", "rifiutato": "Rifiutato", "annullato": "Annullato"} | enum('creato','inviato','accettato','accettato_parzialmente','rifiutato','annullato') NN | 349/349 · accettato=255, inviato=67, creato=15, accettato_parzialmente=8, rifiutato=4 |
| `rif_ord_cli` | string | Rif. ordine cliente | accesso {"show": ["show_preventivi"]}; aiuto: Se compilato viene riportato sulla fattura | varchar(191) | 119/349 |
| `fatt_preventivo` | enum | Fatturato | sola lettura; valori {"parziale": "Parziale", "totale": "Totale"} | enum('parziale','totale') | 214/349 · totale=172, ∅=135, parziale=42 |
| `data_preventivo` | date | Data preventivo | obbl.; default gi_date_default() | date NN | 349/349 |
| `serie_preventivo` | string | Serie preventivo | obbl.; default gi_year_get($data_preventivo); dipende ['data_preventivo'] | varchar(191) NN | 349/349 |
| `numero_preventivo` | integer | Numero preventivo | obbl.; default gi_nextcode_get($id,$serie_preventivo); dipende ['serie_preventivo'] | int(11) NN | 349/349 |
| `anno_numero_preventivo` | string | Anno/Numero | visibile se false; calcolato in vista | vista |  |
| `decodifica` | string | Decodifica | visibile se false; calcolato in vista | vista |  |
| `cliente` | reference | Cliente | obbl.; →clienti (restrict); trascina ['termini_di_pagamento', 'collaboratore']; accesso {"edit": ["__never__"]} | int(11) NN | 349/349 |
| `sede_operativa` | reference | Sede operativa | obbl.; →clienti_sedi_operative (restrict); trascina ['cliente']; accesso {"edit": ["__never__"]} | int(11) NN | 349/349 |
| `collaboratore` | reference | Collaboratore | sola lettura; →utenti (noaction); accesso {"show": ["show_preventivi"]} | int(11) | 106/349 |
| `oggetto` | string | Oggetto del preventivo | default Preventivo per attività tecnico-profess…; accesso {"show": ["show_preventivi"]} | text | 349/349 |
| `termini_di_pagamento` | reference | Termini di pagamento | default gi_reference_default_get('predefinito'); →tipi_pagamento (restrict); accesso {"show": ["show_preventivi"]} | int(11) | 336/349 |
| `termine_esecuzione` | string | Termine fatturazione | accesso {"show": ["show_preventivi"]} | varchar(191) | 162/349 |
| `totale_netto` | decimal | Totale netto | sola lettura | decimal(12,2) | 349/349 |
| `totale_scontato_righe` | decimal | Totale con sconti di riga applicati | sola lettura | decimal(12,2) | 349/349 |
| `sconto` | decimal | Sconto | sola lettura se $stato_preventivo=="accettato" \|\| $stato_preventivo=="accettato_parzialmente" | decimal(12,2) | 18/349 |
| `tipo_sconto` | enum | Tipo sconto | obbl.=$sconto != null && $sconto != "" && $stato_preventivo!="accettato" && $stato_preventivo!="accettato_parzialmente"; sola lettura se $stato_preventivo=="accettato" \|\| $stato_preventivo=="accettato_parzialmente"; valori {"P": "%", "A": "€"} | enum('P','A') | 18/349 · ∅=331, A=12, P=6 |
| `totale_finale` | decimal | Totale finale | sola lettura | decimal(12,2) | 349/349 |
| `note_interne` | string | Note Interne | accesso {"show": ["show_preventivi"]} | text | 25/349 |
| `tipo_documento` | enum | Tipo doc. | valori {"OrdineAcquisto": "Ordine d'acquisto", "Contratto": "Contratto", "Convenzione": "Convenzione", "Ricezione": "Ricezione", "FattureCollegate": "Fattura collegata", "DDT": "Doc. di trasporto", "FatturaPrincipale": "Fattura principale"}; accesso {"show": ["show_preventivi"]}; aiuto: Obbligatorio se vuoi che esca in fattura | enum('OrdineAcquisto','Contratto','Convenzione','Ricezione','FattureCollegate','DDT','FatturaPrincipale') | 125/349 · ∅=224, OrdineAcquisto=123, Contratto=2 |
| `n_documento` | string | N° | regex `/^p{IsBasicLatin}+$/` bloccante; max 20; accesso {"show": ["show_preventivi"]}; aiuto: Obbligatorio se vuoi che esca in fattura | varchar(20) | 127/349 |
| `data_documento` | date | Data | accesso {"show": ["show_preventivi"]}; aiuto: Obbligatorio se vuoi che esca in fattura | date | 126/349 |
| `cig` | string | CIG | regex `/^p{IsBasicLatin}+$/` bloccante; max 15; accesso {"show": ["show_preventivi"]} | varchar(15) | 9/349 |
| `cup` | string | CUP | regex `/^p{IsBasicLatin}+$/` bloccante; max 15; accesso {"show": ["show_preventivi"]} | varchar(15) | 1/349 |
| `commessa_convenzione` | string | Commessa / Convenzione | regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 100; accesso {"show": ["show_preventivi"]} | varchar(100) | 5/349 |
| `rif_lav_gen_prev` | reference | Rif. lav. gen. preventivo | sola lettura; →lavori_batch (restrict); accesso {"show": ["show_preventivi"]} | int(11) | 0/349 |
| `n_righe_anomale` | integer | N° righe anomale (senza prezzo) | sola lettura; default 0; accesso {"show": ["show_preventivi"]} | int(11) | 349/349 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull); accesso {"show": ["show_preventivi"]} | int(11) | 349/349 |
| `last_update_ts` | datetime | Data modifica | sola lettura; accesso {"show": ["show_preventivi"]} | datetime | 349/349 |

Colonne fisiche senza campo nei metadati: `totale` (decimal(12,2); 0/349), `last_update_nr` (int(11); 349/349)

## `preventivi_righe` — Preventivi righe

- tipo meta: table · lettura: `preventivi_righe_read` · decodifica: `preventivi_righe_dec` · record: 2842
- hook: php_gi_record_save_before=`gi_preventivi_righe_save_before`, php_gi_record_change_after=`gi_preventivi_righe_change_after`, js_gi_form_create_and_show_after=`js_gi_form_create_and_show_preventivi_righe_after`, js_gi_form_create_and_show_form_fields_set_after=`js_gi_form_create_and_show_preventivi_righe_after`, js_gi_form_fields_check=`js_gi_form_fields_preventivi_righe_check`
- indici: ['preventivo']
- ordinamento: {'by': 'n_riga', 'dir': 'asc'}
- permessi: `show_preventivi_righe`; `edit_preventivi_righe` [cond: t.modificabile = "T"]; `new_preventivi_righe`; `delete_preventivi_righe` [cond: t.almeno_un_sottopunto_accettato = "F"]; `multiedit_preventivi_righe` [cond: t.modificabile_stato = "T"]; `export_preventivi_righe`; `inserisci_a_punto_preventivi_righe` [cond: t.tip_riga = "P" AND t.modificabile_stato="T"]; `custom_preventivi_righe_fattura_cliente_genera` [cond: t.tip_riga = 'S' AND t.attivita IS NOT NULL AND t.stato_attivita='effettuata' AND t.fattura IS NULL]
- azioni: show←show_preventivi_righe; edit←edit_preventivi_righe; new←new_preventivi_righe; delete←delete_preventivi_righe; multiedit←multiedit_preventivi_righe; export←export_preventivi_righe; inserisci_a_punto_preventivi_righe←inserisci_a_punto_preventivi_righe (Inserisci sottopunto al punto); preventivi_righe_fattura_cliente_genera←custom_preventivi_righe_fattura_cliente_genera (Genera fattura)
- altre proprietà: {"group": {"by": "n_riga", "dir": "asc"}, "show_stats": true}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 2842/2842 |
| `decodifica` | string | Decodifica | visibile se false; calcolato in vista | vista |  |
| `preventivo` | reference | Preventivo | obbl.; →preventivi (cascade); trascina ['sede_operativa']; visibile se false; no multiedit | int(11) NN | 2842/2842 |
| `sede_operativa` | integer | Sede operativa | visibile se false; calcolato in vista; no multiedit | vista |  |
| `tip_riga` | enum | Tipologia Riga | obbl.; default P; valori {"P": "Punto", "S": "Sottopunto"}; accesso {"edit": ["__never__"]}; no multiedit | enum('P','S') NN | 2842/2842 · S=2226, P=616 |
| `n_riga` | integer | N° riga | obbl.; sola lettura se $stato_riga=="accettata"; default gi_preventivi_righe_n_riga_default_calc…; no multiedit | int(11) NN | 2842/2842 |
| `n_riga_sottopunto` | integer | N° sottopunto | obbl.=$tip_riga=="S"; sola lettura se $tip_riga!="S"; default gi_preventivi_righe_n_riga_sottopunto_d…; no multiedit | int(11) | 2226/2842 |
| `punto` | reference | Punto | sola lettura; default gi_preventivi_righe_punto_default_calc(…; →preventivi_righe (cascade); trascina ['almeno_un_sottopunto_accettato']; visibile se false; no multiedit | int(11) | 2226/2842 |
| `stato_riga` | enum | Stato riga | obbl.=$tip_riga=="S" && $modificabile_stato == "T"; sola lettura se $modificabile_stato == "F"; default da_accettare; valori {"da_accettare": "Non ancora accettata", "accettata": "Accettata", "rifiutata": "Rifiutata"}; visibile se $tip_riga=="S" | enum('da_accettare','accettata','rifiutata') | 2226/2842 · accettata=1753, ∅=616, da_accettare=437, rifiutata=36 |
| `cerca_articolo` | reference | Cerca articolo | sola lettura se $tip_riga!="P" \|\| $modificabile_stato=="F" \|\| $modificabile_stato==null \|\| $modificabile_stato==""; →articoli (setnull); trascina ['titolo', 'descrizione', 'nota_finale']; visibile se $tip_riga=="P"; no multiedit | int(11) | 569/2842 |
| `titolo` | string | Titolo | obbl.=$tip_riga=="P"; sola lettura se $tip_riga!="P"; visibile se $tip_riga=="P"; no multiedit | varchar(191) | 616/2842 |
| `scadenza` | reference | Cerca Scadenza | →scadenze (noaction); trascina ['attrezzatura', 'valvola', 'tipo_scad']; dipende ['sede_operativa']; visibile se $tip_riga=="S" && $stato_riga != "accettata"; no multiedit | int(11) | 0/2842 |
| `descrizione` | string | Descrizione | obbl.=$tip_riga=="S"; default gi_preventivi_righe_descrizione_default…; no multiedit | text | 2841/2842 |
| `descrizione_rp` | string | Descrizione | visibile se false; calcolato in vista | vista |  |
| `descrizione_punto_rp` | string | Descrizione | visibile se false; calcolato in vista | vista |  |
| `descr_sottopunti` | string | Concatenazione descrizione sottopunti | sola lettura; visibile se false; no multiedit | text | 603/2842 |
| `attrezzatura` | integer | Id Attrezzatura | obbl.; visibile se false | int(11) NN | 2842/2842 |
| `valvola` | integer | Id Valvola di sicurezza | visibile se false | int(11) | 622/2842 |
| `tipo_scad` | enum | Tipo scadenza | sola lettura; default gi_preventivi_righe_tipo_scad_default_c…; valori {"cnd": "Controlli non distruttivi (GVR)", "suppl": "Indagine supplementare (SC/SP)", "taratura": "Taratura (Valvole di sicurezza)", "altro": "Altro"}; visibile se $tip_riga=="S"; no multiedit | enum('cnd','suppl','taratura','altro') | 2226/2842 · altro=1150, taratura=622, ∅=616, cnd=408, suppl=46 |
| `nota_finale` | string | Nota Finale | sola lettura se $tip_riga!="P"; visibile se $tip_riga=="P"; no multiedit | text | 550/2842 |
| `tip_prezzo` | enum | Tipologia Prezzo | obbl.=$tip_riga=="P"; sola lettura se $tip_riga!="P"; default gi_preventivi_righe_tip_prezzo_default_…; valori {"S": "Prezzo singolo", "C": "Prezzo a corpo"}; accesso {"edit": ["__never__"]}; no multiedit | enum('S','C') | 2842/2842 · S=2727, C=115 |
| `imp_netto` | decimal | Prezzo netto | obbl.=(($tip_riga=="P" && $tip_prezzo=="C") \|\| ($tip_riga=="S" && $tip_prezzo!="C")) && (($sconto != null && $sconto != "") \|\| ($stato_riga == "accettata")); sola lettura se ($tip_riga=="P" && $tip_prezzo=="S") \|\| ($tip_riga=="S" && $tip_prezzo=="C") \|\| ($tip_prezzo=="" \|\| $tip_prezzo==…; no multiedit | decimal(12,2) | 2190/2842 |
| `sconto` | decimal | Sconto | visibile se ($tip_riga=="P" && $tip_prezzo=="C") \|\| ($tip_riga=="S" && $tip_prezzo!="C") | decimal(12,2) | 219/2842 |
| `tipo_sconto` | enum | Tipo sconto | obbl.=(($tip_riga=="P" && $tip_prezzo=="C") \|\| ($tip_riga=="S" && $tip_prezzo!="C")) && $sconto != null && $sconto != ""; valori {"P": "%", "A": "€"}; visibile se ($tip_riga=="P" && $tip_prezzo=="C") \|\| ($tip_riga=="S" && $tip_prezzo!="C") | enum('P','A') | 219/2842 · ∅=2623, P=153, A=66 |
| `imp_scontato` | decimal | Prezzo scontato | sola lettura; no multiedit | decimal(12,2) | 2201/2842 |
| `imp_finale` | decimal | Prezzo finale | sola lettura; no multiedit | decimal(12,2) | 2201/2842 |
| `collaboratore` | reference | Collaboratore | →utenti (noaction); visibile se $tip_riga=="P"; calcolato in vista; no multiedit | vista |  |
| `perc_collab` | decimal | Percentuale collaboratore | default gi_preventivi_righe_perc_collab_default…; visibile se $tip_riga=="P"; no multiedit | decimal(12,2) | 160/2842 |
| `inser_scadenze` | reference | Inserisci una o più scadenze | →scadenze (setnull); dipende ['sede_operativa']; visibile se $tip_riga=="P" && $id!="" && $id!=NULL && $modificabile_stato=="T"; no multiedit | int(11) | 0/2842 |
| `modificabile_stato` | boolean | Stato modificabile | default T; visibile se false; calcolato in vista | vista |  |
| `modificabile` | boolean | modificabile | visibile se false; calcolato in vista | vista |  |
| `attivita` | reference | Attivita | →attivita (noaction); visibile se $tip_riga=="S"; calcolato in vista; no multiedit | vista |  |
| `stato_attivita` | enum | Stato attività | sola lettura; valori {"da_programmare": "Da programmare", "programmata": "Programmata", "effettuata": "Effettuata", "annullata": "Annullata"}; visibile se $tip_riga=="S"; no multiedit | enum('da_programmare','programmata','effettuata','annullata') | 1753/2842 · effettuata=1177, ∅=1089, da_programmare=535, annullata=35, programmata=6 |
| `data_program` | date | Data programmazione | sola lettura; visibile se false; no multiedit | date | 367/2842 |
| `data_esecuzione` | date | Data esecuzione | sola lettura; visibile se false; no multiedit | date | 1189/2842 |
| `data_prox_scadenza` | date | Data prossima scadenza | sola lettura; visibile se false; no multiedit | date | 619/2842 |
| `da_sinc_adsrl` | enum | Da sincronizzare su ADSRL | sola lettura; default gi_preventivi_righe_da_sinc_adsrl_defau…; valori {"T": "Sì", "F": "No", "S": "Sincronizzato"}; visibile se $tip_riga=="S"; no multiedit | enum('T','F','S') | 2226/2842 · F=1607, ∅=616, S=579, T=40 |
| `fattura` | reference | Fattura | sola lettura; →fatture_clienti (setnull); no multiedit | int(11) | 1201/2842 |
| `fattura_saldata` | boolean | Fattura cliente saldata | calcolato in vista | vista |  |
| `importo_collaboratore` | reference | Importo collaboratore | →importi_collaboratori (noaction); calcolato in vista; no multiedit | vista |  |
| `stato_importo` | enum | Stato importo | valori {"assegnato": "Assegnato", "fatturabile": "Fatturabile", "fatturato": "Fatturato"}; calcolato in vista; no multiedit | vista |  |
| `fattura_collab` | reference | Fattura collaboratore | sola lettura; →fatture_collaboratori (setnull); no multiedit | int(11) | 0/2842 |
| `fattura_collab_saldata` | boolean | Fattura collaboratore saldata | calcolato in vista | vista |  |
| `almeno_un_sottopunto_accettato` | boolean | Almeno un sottopunto accettato | sola lettura; visibile se false; aiuto: Se il punto ha almeno un sottopunto figlio accettato o se il sottopunto è accettato | enum('F','T') NN | 2842/2842 · T=2200, F=642 |
| `almeno_un_sottopunto_effettuato` | boolean | Almeno un sottopunto effettuato (e acce… | sola lettura; visibile se false; aiuto: Se il punto ha almeno un sottopunto figlio effettuato o se il sottopunto è effettuato | enum('F','T') NN | 2842/2842 · T=1499, F=1343 |
| `almeno_un_sottopunto_fatturato` | boolean | Almeno un sottopunto fatturato | sola lettura; visibile se false; aiuto: Se tra i sottopunti figli/fratelli almeno uno è stato fatturato | enum('F','T') NN | 2842/2842 · T=1499, F=1343 |
| `rp_sconto_dec` | string | rp_sconto_dec | visibile se false; calcolato in vista | vista |  |
| `lettera` | string | Lettera punto | sola lettura; visibile se false | varchar(191) | 0/2842 |
| `importo_totale_punto` | decimal | Importo totale punto | sola lettura; visibile se false | decimal(12,2) | 0/2842 |
| `importo_totale_scontato_punto` | decimal | Importo totale scontato punto | sola lettura; visibile se false | decimal(12,2) | 0/2842 |
| `almeno_un_sottopunto_scontato` | boolean | Se almeno un sottopunto del punto ha un… | sola lettura; default F; visibile se false | enum('F','T') NN | 2842/2842 · F=2842 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull); no multiedit | int(11) | 2842/2842 |
| `last_update_ts` | datetime | Data modifica | sola lettura; no multiedit | datetime | 2842/2842 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 2842/2842), `note` (text; 41/2842)

## `ruoli` — Ruoli

- tipo meta: table · lettura: `ruoli` · decodifica: `ruoli_dec` · record: 3
- hook: php_gi_ddl_table_create_custom=`gi_ddl_table_create_ruoli`, php_gi_record_change_after=`php_gi_predefinito_change_after`
- univoci: ['ruolo']
- ordinamento: {'by': 'ruolo', 'dir': 'asc'}
- permessi: `show_ruoli`; `edit_ruoli`; `new_ruoli`; `copy_ruoli`; `delete_ruoli`
- azioni: show←show_ruoli; edit←edit_ruoli; new←new_ruoli; copy←copy_ruoli; delete←delete_ruoli
- altre proprietà: {"list_mobile": [{"field": "id", "left": "ruolo", "title": "ruolo", "right_top": ["predefinito"]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura; visibile se false | int(11) NN | 3/3 |
| `predefinito` | boolean | Predefinito nuovi utenti | obbl.; default F | enum('F','T') NN | 3/3 · F=2, T=1 |
| `ruolo` | string | Ruolo | obbl. | varchar(191) NN | 3/3 |
| `permessi` | custom | Permessi | obbl. | mediumtext NN | 3/3 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault) | int(11) | 3/3 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 3/3 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 3/3)

## `scadenze` — Scadenze

- tipo meta: table · lettura: `scadenze_read` · decodifica: `scadenze_dec` · record: 9196
- univoci: ['attrezzatura', 'tipo_scad', 'valvola']
- indici: ['attrezzatura']; ['valvola']; ['data_ult_attivita']; ['data_scad_attivita']
- ordinamento: {'by': 'data_scad_attivita', 'dir': 'asc'}
- permessi: `show_scadenze`; `show_scadenze_collaboratore` [cond: t.collaboratore=#id]; `show_scadenze_utente_cliente` [cond: t.utente_cliente=#id]; `export_scadenze`; `sincronizza_scadenze`; `inserisci_sottopunti_scadenze`
- azioni: show←show_scadenze|show_scadenze_collaboratore|show_scadenze_utente_cliente; export←export_scadenze; sincronizza_scadenze←sincronizza_scadenze (Sincronizza scadenze); inserisci_sottopunti_scadenze←inserisci_sottopunti_scadenze (Inserisci come sottopunti)
- altre proprietà: {"grid_rows_per_page": [25, 50, 100, 200, 500], "filters": {"inattiva": {"values": ["F"]}, "dismessa": {"values": ["F"]}}, "filters_reset_to_empty": true, "group": {"by": "cliente", "dir": "asc"}}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 9196/9196 |
| `decodifica` | string | Decodifica | visibile se false; calcolato in vista | vista |  |
| `cliente` | reference | Cliente | →clienti (noaction); calcolato in vista | vista |  |
| `utente_cliente` | reference | Utente del cliente | →utenti (noaction); calcolato in vista; accesso {"show": ["show_scadenze"]} | vista |  |
| `collaboratore` | reference | Collaboratore | →utenti (noaction); calcolato in vista; accesso {"show": ["show_scadenze"]} | vista |  |
| `sede_operativa` | reference | Sede operativa | →clienti_sedi_operative (noaction) | int(11) | 9196/9196 |
| `inattiva` | boolean | Sede inattiva | obbl.; default F; calcolato in vista | vista |  |
| `attrezzatura` | integer | Id Attrezzatura | obbl.; visibile se false | int(11) NN | 9196/9196 |
| `attrezzatura_dec` | string | Attrezzatura | obbl. | varchar(191) NN | 9196/9196 |
| `dismessa` | boolean | Dismessa | obbl.; default F | enum('F','T') NN | 9196/9196 · F=8730, T=466 |
| `valvola` | integer | Id Valvola di sicurezza | visibile se false | int(11) | 3320/9196 |
| `valvola_dec` | string | Valvola di sicurezza |  | varchar(191) | 3320/9196 |
| `tipo_scad` | enum | Tipo scadenza | obbl.; valori {"cnd": "Controlli non distruttivi (GVR)", "suppl": "Indagine supplementare (SC/SP)", "taratura": "Taratura (Valvole di sicurezza)"} | enum('cnd','suppl','taratura') NN | 9196/9196 · cnd=5163, taratura=3320, suppl=713 |
| `data_ult_attivita` | date | Data ultima attività |  | date | 6371/9196 |
| `data_scad_attivita` | date | Data scadenza attività |  | date | 8887/9196 |
| `preventivo` | reference | Preventivo | →preventivi (noaction); calcolato in vista | vista |  |
| `preventivo_riga` | reference | Riga preventivo | →preventivi_righe (noaction); calcolato in vista; accesso {"show": ["show_scadenze"]} | vista |  |
| `stato_preventivo` | enum | Stato preventivo | valori {"creato": "Creato", "inviato": "Inviato", "accettato": "Accettato", "accettato_parzialmente": "Accettato parzialmente", "rifiutato": "Rifiutato", "annullato": "Annullato"}; calcolato in vista | vista |  |
| `stato_riga` | enum | Stato riga | valori {"da_accettare": "Non ancora accettata", "accettata": "Accettata", "rifiutata": "Rifiutata"}; calcolato in vista; accesso {"show": ["show_scadenze"]} | vista |  |
| `attivita` | reference | Attivita | →attivita (noaction); calcolato in vista; accesso {"show": ["show_scadenze"]} | vista |  |
| `stato_attivita` | enum | Stato attività | valori {"da_programmare": "Da programmare", "programmata": "Programmata", "effettuata": "Effettuata", "annullata": "Annullata"}; calcolato in vista; accesso {"show": ["show_scadenze"]} | vista |  |
| `att_reparto` | string | Reparto | visibile se false | varchar(191) | 5521/9196 |
| `att_rif_interno` | string | Rif. interno | visibile se false | varchar(191) | 4589/9196 |
| `att_num_fabbrica` | string | Num. fabbrica | visibile se false | varchar(191) | 9196/9196 |
| `att_matr_informale` | string | Matr. informale | visibile se false | varchar(191) | 9196/9196 |
| `att_modello` | string | Modello | visibile se false | varchar(191) | 9196/9196 |
| `att_rag_soc_costr` | string | Rag. soc. costruttore | visibile se false | varchar(191) | 9196/9196 |
| `att_anno_costr` | string | Anno costruzione | visibile se false | varchar(191) | 8168/9196 |
| `att_descr_attr` | string | Descrizione | visibile se false | text | 9157/9196 |
| `att_ps_attr_gvr` | string | PS attr. GVR | visibile se false | varchar(191) | 7979/9196 |
| `att_volume_attr_gvr` | string | Volume attr. GVR | visibile se false | varchar(191) | 7896/9196 |
| `att_ts_attr_gvr` | string | TS attr. GVR | visibile se false | varchar(191) | 222/9196 |
| `att_sup_risc_attr_gvr` | string | Sup. risc. attr. GVR | visibile se false | varchar(191) | 677/9196 |
| `att_prod_attr_gvr` | string | Prod. attr. GVR | visibile se false | varchar(191) | 530/9196 |
| `att_portata_attr_sc_sp` | string | Portata attr. SC/SP | visibile se false | varchar(191) | 706/9196 |
| `vs_matricola` | string | Matr. Valvola di sicurezza | visibile se false | varchar(191) | 3305/9196 |
| `tip_accessorio` | enum | Tipologia accessorio | valori {"valvola di sicurezza": "valvola di sicurezza", "disco di rottura": "disco di rottura", "valvola intercettazione combustibile": "valvola intercettazione combustibile"} | enum('valvola | 2489/9196 · ∅=6707, valvola di sicurezza=2328, valvola intercettazione combustibile=122, disco di rottura=39 |
| `vs_fabbr` | string | Fabbricante Valvola | visibile se false | varchar(191) | 3209/9196 |
| `vs_modello` | string | Modello Valvola | visibile se false | varchar(191) | 1930/9196 |
| `vs_dn` | string | DN Valvola | visibile se false | varchar(191) | 1163/9196 |
| `vs_ptar` | string | Ptar Valvola | visibile se false | varchar(191) | 3197/9196 |
| `lav_batch_mod` | reference | Rif. lavoro import. scad. | →lavori_batch (setnull) | int(11) | 9196/9196 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 9196/9196)

## `tipi_pagamento` — Tipi Pagamento

- tipo meta: table · lettura: `tipi_pagamento` · decodifica: `tipi_pagamento_dec` · record: 16
- hook: php_gi_ddl_table_create_custom=`gi_ddl_table_create_tipi_pagamento`, php_gi_record_change_after=`php_gi_predefinito_change_after`
- univoci: ['nome_pagamento']
- ordinamento: {'by': 'nome_pagamento', 'dir': 'asc'}
- permessi: `show_tipi_pagamenti`; `edit_tipi_pagamenti`; `new_tipi_pagamenti`; `delete_tipi_pagamenti`
- azioni: show←show_tipi_pagamenti; edit←edit_tipi_pagamenti; new←new_tipi_pagamenti; delete←delete_tipi_pagamenti

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | ID | sola lettura; visibile se false | int(11) NN | 16/16 |
| `predefinito` | boolean | Predefinito | obbl.; default F | enum('F','T') NN | 16/16 · F=15, T=1 |
| `nome_pagamento` | string | Nome pagamento | obbl. | varchar(191) NN | 16/16 |
| `modalita` | enum | Modalità | obbl.; valori {"MP01": "MP01: contanti", "MP02": "MP02: assegno", "MP03": "MP03: assegno circolare", "MP05": "MP05: bonifico", "MP06": "MP06: vaglia cambiario", "MP07": "MP07: bollettino bancario", "MP08": "MP08: carta di pagamento", "MP09": "MP09: RID", "MP10": "MP10: RID utenze", "MP11": "MP11: RID veloce", "MP12": "MP12: RIBA", "MP13": "MP13: MAV", "MP14": "MP14: quietanza erario", "MP15": "MP15: giroconto … | enum('MP01','MP02','MP03','MP05','MP06','MP07','MP08','MP09','MP10','MP11','MP12','MP13','MP14','MP15','MP16','MP17','MP19','MP20','MP21','MP22','MP23') NN | 16/16 · MP05=10, MP12=5, MP01=1 |
| `salda_subito` | boolean | Salda subito documento con questo pagam… | obbl.; default F | enum('F','T') NN | 16/16 · F=15, T=1 |
| `fm_paga_dopo` | integer | Se "Fine Mese", paga il giorno indicato… |  | int(11) | 0/16 |
| `sposta_scadenze` | boolean | Sposta le scadenze al 31/8 o 31/12 al 1… | obbl.; default F | enum('F','T') NN | 16/16 · F=16 |
| `last_update_user` | reference | Utente Modifica | sola lettura; →utenti (setdefault) | int(11) | 1/16 |
| `last_update_ts` | datetime | Data Modifica | sola lettura | datetime | 2/16 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 16/16)

## `tipi_pagamento_scadenze` — Scadenze Tipi Pagamento

- tipo meta: table · lettura: `tipi_pagamento_scadenze` · decodifica: `tipi_pagamento_scadenze_dec` · record: 19
- hook: php_gi_ddl_table_create_custom=`gi_ddl_table_create_tipi_pagamento`
- univoci: ['tipo_pagamento', 'giorni']
- ordinamento: {'by': 'giorni', 'dir': 'asc'}
- permessi: `show_tipi_pagamento_scadenze`; `edit_tipi_pagamento_scadenze`; `new_tipi_pagamento_scadenze`; `delete_tipi_pagamento_scadenze`
- azioni: show←show_tipi_pagamento_scadenze; edit←edit_tipi_pagamento_scadenze; new←new_tipi_pagamento_scadenze; delete←delete_tipi_pagamento_scadenze

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | ID | sola lettura; visibile se false | int(11) NN | 19/19 |
| `tipo_pagamento` | reference | Tipo Pagamento | obbl.; →tipi_pagamento (cascade) | int(11) NN | 19/19 |
| `giorni` | integer | Giorni | obbl.; default 0 | int(11) NN | 19/19 |
| `perc_totale` | decimal | % del Totale | obbl.; default 0 | decimal(12,2) NN | 19/19 |
| `fine_mese` | boolean | Fine mese? | obbl.; default F | enum('F','T') NN | 19/19 · T=12, F=7 |
| `last_update_user` | reference | Utente Modifica | sola lettura; →utenti (setdefault) | int(11) | 0/19 |
| `last_update_ts` | datetime | Data Modifica | sola lettura | datetime | 0/19 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 19/19)

## `utenti` — Utenti

- tipo meta: table · lettura: `utenti_read` · decodifica: `utenti_dec` · record: 6
- hook: php_gi_ddl_table_create_custom=`gi_ddl_table_create_utenti`
- univoci: ['utente']
- ordinamento: {'by': 'utente', 'dir': 'asc'}
- permessi: `show_nomi_utenti`; `show_utenti`; `edit_utenti`; `new_utenti`; `delete_utenti`; `show_profilo` [cond: #id = t.id]; `edit_profilo` [cond: #id = t.id]; `__never__`
- azioni: show←show_nomi_utenti|show_utenti|show_profilo; edit←edit_utenti|edit_profilo; new←new_utenti; delete←delete_utenti
- altre proprietà: {"list_mobile": [{"field": "id", "left": "utente", "title": "utente", "subtitle": ["ruolo"], "right_top": ["attivo"]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura; visibile se false | int(11) NN | 6/6 |
| `decodifica` | string | Decodifica | visibile se false; calcolato in vista | vista |  |
| `attivo` | boolean | Attivo | obbl.; default T; accesso {"show": ["show_utenti"]} | enum('F','T') NN | 6/6 · T=6 |
| `utente` | string | E-mail | obbl.; check email bloccante; accesso {"show": ["show_utenti", "show_profilo"], "edit": ["edit_utenti"]} | varchar(191) NN | 6/6 |
| `password` | password | Password | obbl.; regex `/^.{8,}$/` bloccante; accesso {"show": ["show_utenti", "show_profilo"]} | varchar(191) NN | 6/6 |
| `ruolo` | reference | Ruolo | obbl.; default gi_reference_default_get('predefinito'); →ruoli (restrict); accesso {"show": ["show_utenti"]} | int(11) NN | 6/6 |
| `registrazione` | datetime | Data Registrazione | sola lettura; default gi_date_default(); accesso {"show": ["show_utenti"]} | datetime | 6/6 |
| `ultima_login` | datetime | Data Ultimo Utilizzo | sola lettura; accesso {"show": ["show_utenti"]} | datetime | 2/6 |
| `qualifica` | string | Qualifica | aiuto: Es. Ing., Sig. ecc. | varchar(191) | 1/6 |
| `cognome` | string | Cognome | obbl.; max 60 | varchar(60) NN | 6/6 |
| `nome` | string | Nome | obbl.; max 60 | varchar(60) NN | 6/6 |
| `cf` | string | C.F. | check cf bloccante; accesso {"show": ["show_utenti", "show_profilo"]} | varchar(191) | 0/6 |
| `tel` | string | Telefono | check tel; accesso {"show": ["show_utenti", "show_profilo"]}; aiuto: es. +39 030 6898477 | varchar(191) | 1/6 |
| `cell` | string | Cellulare | check tel; accesso {"show": ["show_utenti", "show_profilo"]}; aiuto: es. +39 366 4314707 | varchar(191) | 3/6 |
| `firma` | files | Firma | file server | text | 6/6 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault); accesso {"show": ["show_utenti"]} | int(11) | 6/6 |
| `last_update_ts` | datetime | Data modifica | sola lettura; accesso {"show": ["show_utenti"]} | datetime | 6/6 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 6/6)

## `utenti_collaboratori_percentuali` — Percentuali Collaboratori

- tipo meta: table · lettura: `utenti_collaboratori_percentuali` · decodifica: `utenti_collaboratori_percentuali_dec` · record: 132
- hook: php_gi_record_save_before=`gi_utenti_collaboratori_percentuali_save_before`
- univoci: ['utente', 'articolo']
- indici: ['utente']; ['articolo']
- ordinamento: {'by': 'articolo', 'dir': 'asc'}
- permessi: `show_utenti_collaboratori_percentuali`; `edit_utenti_collaboratori_percentuali`
- azioni: show←show_utenti_collaboratori_percentuali; edit←edit_utenti_collaboratori_percentuali

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 132/132 |
| `utente` | reference | Utente | obbl.; →utenti (cascade) | int(11) NN | 132/132 |
| `articolo` | reference | Articolo | obbl.; →articoli (cascade) | int(11) NN | 132/132 |
| `percentuale` | decimal | Percentuale | obbl.; default 0 | decimal(12,2) NN | 132/132 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull) | int(11) | 16/132 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 16/132 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 132/132)
