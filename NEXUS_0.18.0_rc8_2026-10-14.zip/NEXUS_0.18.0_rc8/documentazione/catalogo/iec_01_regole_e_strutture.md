# Catalogo Garda — iec (I&C S.r.l.): regole e strutture

**Versione 1.0 · 9 ottobre 2026.** Terzo dei tre cataloghi, dopo ingecert e adsrl. Stesso metodo e stessa destinazione: la matrice di parità.

**Fonte:** `backup_gestionale.7z`, codice PHP/JS e dump MariaDB di iec del 07/10/2026. Conteggi principali: 814 clienti, 1.047 sedi, 9.196 scadenze (copiate da AD), 349 preventivi, 2.842 righe (616 punti, 2.226 sottopunti), 1.753 attività, 231 fatture elettroniche, 6 utenti.

**Legenda delle evidenze**
- **[C]** letto nel codice, con file e funzione.
- **[D]** misurato sul dump.
- **[I]** dedotto, da confermare.

Gli ID sono quelli di iec (IE-xx). Le regole uguali a quelle degli altri due sistemi rimandano a IC-xx (ingecert) o AD-xx (adsrl). **Allegato:** `catalogo/iec_02_campi.md` riporta ogni campo di ogni entità, con vincoli e riempimento reale.

---

## 0. Sintesi

iec è il gestionale commerciale e amministrativo di I&C. Copre le attività che non sono verifiche periodiche:
- controlli non distruttivi (CND) sulle GVR;
- indagini supplementari sui sollevamenti;
- tarature e revisioni delle valvole di sicurezza;
- pratiche INAIL, progettazione, forniture e altre prestazioni a listino.

**iec non ha beni propri.** Attrezzature e valvole stanno in adsrl. iec ne tiene una copia delle scadenze CND, supplementari e tarature, aggiornata da una sincronizzazione che riporta poi in AD le date delle attività eseguite.

La catena è: scadenza (da AD) → preventivo a punti e sottopunti → attività → fattura → date restituite ad AD. Non ci sono verifica, verbale, tecnico o riesame.

| File | Contenuto |
|---|---|
| `cust/meta/*.js` (48 file: 8 solo di iec, 17 modificati rispetto ad adsrl, 23 uguali a meno di spazi) | Strutture, permessi, condizioni delle azioni. |
| `cust/_custom.php` (1.772 righe) | Preventivi a punti e sottopunti, sconti a due livelli, stato del preventivo, attività, provvigioni dei collaboratori, stampa del preventivo. |
| `cust/lavori_batch_cli.php` (590) | Sincronizzazione con adsrl e generazione delle fatture dalle righe. |
| `cust/inserisci_sottopunti_scadenze_ajax.php` (130) | Inserimento di più scadenze come sottopunti di un punto. |
| `cust/gi_views.php` (287) | Campi derivati: copertura delle scadenze, attività, importi dei collaboratori. |
| `cust/__*.php` (4 script) | Manutenzione una tantum: ricalcolo di righe anomale, descrizioni, flag e collaboratori sui dati iniziali. |
| `_doc_fiscali_common.php`, `fatture_clienti_genera_xml_cli.php` | **Identici ad adsrl**, salvo, nel primo, la serie `/AAAA` e il blocco sulle fatture già oggetto di provvigione. |
| `gi_config_custom.php` | Parametri di connessione ad adsrl: indirizzo, chiavi, mappa referenti AD → collaboratori iec. I valori non sono riportati qui. |

**Le evidenze più rilevanti per il progetto**

1. **Lo scadenzario di iec è una fotografia di AD.** A ogni sincronizzazione le scadenze vengono riscritte e quelle non ricevute si cancellano. Oggi coincidono con AD all'ultimo lancio (02/10, 07:50 UTC); le 46 differenze (22 scadenze nuove, 9 superate, 15 con date cambiate) sono tutte modifiche fatte in AD dopo. [C][D]
2. **Le due anagrafiche si collegano per nome.** Clienti per ragione sociale, sedi per cliente e nome. Dopo il collegamento i dati non si riallineano: su 484 clienti collegati, 46 hanno un pagamento diverso da AD, 21 un'email diversa e 11 un codice SDI diverso. [C][D]
3. **iec è nato come copia di adsrl.** 770 clienti su 814 corrispondono a un cliente AD per ragione sociale o id (44 sono solo di iec; 40 se si confrontano anche P.IVA e CF). Il database conserva colonne di AD senza uso, come `sconto_def` e i campi verifica/tecnico nelle righe di fattura. [D][I]
4. **Il modello commerciale è il più ricco dei tre.** Le righe sono punti e sottopunti, con prezzo singolo o a corpo e sconti percentuali o assoluti sia sulla riga sia sul preventivo (ripartiti in proporzione). Il ricalcolo è coerente su tutte le righe e su tutti i 349 preventivi. [C][D]
5. **L'attività non è un'entità propria**: è il sottopunto accettato, con stato e date. Non c'è un esito, un rapporto tecnico o un operatore che la esegue. [C]
6. **Le date tornano ad AD senza confronto** (AD-45). Se si modifica un'attività già sincronizzata, iec avvisa soltanto che la correzione va fatta a mano su AD. [C]
7. **Il sistema è usato da una sola persona.** L'account I&C ha lanciato 601 dei 612 lavori batch ed è l'ultimo ad aver modificato tutti i 349 preventivi. I 4 collaboratori non sono mai entrati e non esistono utenti cliente. [D]
8. **Un preventivo interamente rifiutato risulta "fatturato totale"**, per un errore nella formula: oggi 4 casi. [C][D]
9. **Tutte le 1.177 attività effettuate sono fatturate**, e un'attività effettuata e fatturata non si modifica più. [C][D]
10. **Le provvigioni dei collaboratori sono calcolate ma non chiuse.** Ci sono 120 importi su righe fatturate, per 22.616 € (64 assegnati, 56 fatturabili), e 3 fatture di un collaboratore mai collegate agli importi. [D]

---

## 1. Perimetro dell'installazione

| Gruppo | Entità | Record |
|---|---|---|
| Anagrafiche | `clienti`, `clienti_sedi_operative` | 814 (484 collegati ad AD) · 1.047 (551 collegate, 9 inattive) |
| Scadenzario (copia di AD) | `scadenze`, con i dati di attrezzatura e valvola ricopiati | 9.196: CND 5.163, tarature 3.320, supplementari 713 |
| Listino | `articoli` | 33 (30 a prezzo singolo, 3 a corpo) |
| Commerciale | `preventivi`, `preventivi_righe` | 349 · 2.842 |
| Attività | vista `attivita_read` sui sottopunti accettati | 1.753 |
| Collaboratori | `utenti_collaboratori_percentuali`, vista `importi_collaboratori_read`, `fatture_collaboratori` | 132 (4 collaboratori × 33 articoli) · 120 importi su righe fatturate · 3 |
| Fatture | `fatture_clienti` e collegate, `pagamenti` | 231 (228 fatture, 3 note di credito) · 1.171 righe · 231 pagamenti |
| Utenti | `utenti`, `ruoli` | 6 · 3 |
| Framework | lavori batch, modifiche multiple, stampe, mail | 612 (315 sincronizzazioni, 297 generazioni di fattura) · 700 · 624 · 190 |

L'avvio operativo risale al 9 aprile 2026, data del primo lavoro batch. 82 preventivi con data precedente sono stati ricaricati per proseguire il lavoro aperto [D].

Anche qui il database non ha chiavi esterne. L'unico caso di record orfani: 4 scadenze puntano alla sede 951, cancellata in iec dopo l'ultima sincronizzazione [D].

**Vincoli di unicità** [C]:
- `clienti.rag_soc`;
- sedi (`cliente`, `nome_sede`): unico **per cliente**, mentre in AD è unico su tutto l'archivio;
- scadenze (`attrezzatura`, `tipo_scad`, `valvola`);
- preventivi (serie, numero);
- fatture (serie, tipo documento, numero); righe di fattura (fattura, `n_riga`);
- `articoli.titolo`; percentuali (utente, articolo); fatture dei collaboratori (numero, data, collaboratore).

Le righe di preventivo non hanno un indice univoco: l'unicità dei numeri di punto e sottopunto la garantisce il codice (IE-10).

---

## 2. Strutture

### 2.1 Relazioni

```
clienti 1─N sedi 1─N scadenze (attrezzatura e valvola = id di AD, dati ricopiati)
clienti.collaboratore → utenti (ruolo Collaboratore) ; collaboratore × articolo → percentuale
preventivi (cliente + sede) 1─N righe: punto (P) 1─N sottopunti (S)
sottopunto → (attrezzatura, valvola, tipo scadenza) = chiave della scadenza AD, oppure "altro" (nessun bene)
sottopunto accettato = attività (stato, date) → fattura cliente ; importo collaboratore → fattura collaboratore
attività effettuata (CND, supplementare, taratura) → sincronizzazione → adsrl
```

Rispetto ad AD e ingecert:
- **non ci sono beni**: il bene è un numero che rimanda ad adsrl, con descrizione e dati tecnici ricopiati nella scadenza;
- **la riga di preventivo ha due livelli** ed è insieme offerta e attività;
- **il referente commerciale** di AD qui è il **collaboratore**, che ha una provvigione per articolo.

### 2.2 Campi che portano regole

**`clienti`**
- Come adsrl, con `collaboratore` (311 clienti) al posto del referente commerciale e `id_cliente_adsrl` (484).
- I collaboratori in uso sono 4: 138, 112, 60 e 1 clienti [D].

**`clienti_sedi_operative`**
- `id_sede_adsrl` (551).
- `utente_cliente` non è mai valorizzato: il portale clienti non è in uso [D].

**`scadenze`**
- `tipo_scad`: CND, supplementare, taratura. "Altro" non esiste nello scadenzario.
- Date `data_ult_attivita` e `data_scad_attivita`; flag `dismessa`.
- Campi ricopiati: dati dell'attrezzatura (`att_*`: matricola, fabbrica, costruttore, PS, volume…) e della valvola (`vs_*`: matricola, fabbricante, DN, Ptar).
- `lav_batch_mod`: il lancio di sincronizzazione che ha scritto la riga.

**`articoli`**: titolo, descrizione, tipologia di prezzo, nota finale; si trascinano nel punto. Gli articoli più usati sono CND spessimetrici (139), prova a banco delle valvole (86), pratiche INAIL sul portale CIVA (79) e messa in servizio di attrezzature a pressione (69) [D]. Il listino comprende anche prestazioni vicine al perimetro di ingecert (denuncia e comunicazione dell'impianto di terra secondo il DPR 462/01) e montacarichi (DPR 162/99) [D].

**`preventivi`**
- Come adsrl: cliente e sede obbligatori e non modificabili; riferimento all'ordine del cliente e documento collegato (tipo, numero, data, CIG, CUP, commessa), che passano in fattura.
- In più: `sconto` e `tipo_sconto` di testata; totali netto, scontato sulle righe e finale; `n_righe_anomale`; `collaboratore` trascinato dal cliente; oggetto con testo predefinito; "Termine fatturazione".
- In meno: niente riesame del contratto, licenza gestionale o sottototali per gruppo.

**`preventivi_righe`**

| Gruppo di campi | Contenuto |
|---|---|
| Struttura | `tip_riga` P/S, `n_riga`, `n_riga_sottopunto`, `punto` |
| Punto | `cerca_articolo`, `titolo`, `nota_finale`, `perc_collab`, `descr_sottopunti` (concatenazione) |
| Sottopunto | `descrizione`, `attrezzatura`, `valvola`, `tipo_scad` (CND, supplementare, taratura, altro), `stato_riga` |
| Prezzo | `tip_prezzo` S/C, `imp_netto`, `sconto`, `tipo_sconto` P/A, `imp_scontato`, `imp_finale` |
| Attività | `stato_attivita`, `data_program`, `data_esecuzione`, `data_prox_scadenza`, `note`, `da_sinc_adsrl` (Sì / No / Sincronizzato) |
| Fatturazione | `fattura`, `fattura_collab`, flag `almeno_un_sottopunto_accettato` / `effettuato` / `fatturato` |
| Campi d'appoggio, sempre svuotati | `scadenza`, `inser_scadenze` |

**`fatture_clienti`**: come adsrl, più `almeno_un_importo_fattura_collab`.

---

## 3. Regole

### 3.1 Anagrafiche e sincronizzazione con adsrl

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| IE-01 | Il collaboratore di un cliente deve avere un ruolo che rientra nella condizione "collaboratore" della configurazione. | `gi_clienti_save_before` | [C] |
| IE-02 | **Invio delle date.** L'azione "Sincronizza scadenze" invia ad AD le righe con flag "Sì", tipo diverso da "altro" ed entrambe le date. Quelle che AD non segnala come non sincronizzate passano a "Sincronizzato"; le altre restano "Sì" e si riprovano al lancio successivo. | `gi_scadenze_sincronizza` (init) | [C]. Lato AD: AD-44, AD-45. |
| IE-03 | **Clienti.** Si cercano per ragione sociale. Se non si trovano per nome ma si trovano per id AD, si aggiorna solo la ragione sociale. Altrimenti il cliente si crea copiando i campi di AD. Nazione, pagamento e IVA si accettano solo se esistono anche in iec (entro una soglia di id configurata), altrimenti restano vuoti con un avviso. Il referente commerciale AD diventa collaboratore tramite la mappa in configurazione. | `gi_import_clienti_da_adsrl` | [C] |
| IE-04 | Per un cliente trovato per nome **si aggiorna solo l'id AD**: indirizzo, pagamento, email, SDI e collaboratore non si riallineano. | idem | [C]. Su 484 collegati: 46 pagamenti, 21 email, 11 SDI, 3 indirizzi, 1 P.IVA diversi da AD; 4 con ragione sociale diversa [D]. |
| IE-05 | **Sedi.** Si cercano per cliente e nome, poi per id AD (aggiornando il nome); se mancano si creano. Lo stato attiva/inattiva non si allinea e genera solo un avviso. | `gi_import_clienti_sedi_operative_da_adsrl` | [C]. 6 sedi con stato diverso da AD: 5 segnalate a ogni lancio, la sesta cambiata in AD dopo l'ultimo [D]. |
| IE-06 | **Scadenze.** Si inseriscono o aggiornano per chiave (attrezzatura, valvola, tipo); cliente e sede si risolvono per nome. Se non si trovano, quella scadenza va in errore. | `gi_scadenze_sincronizza` (process) | [C] |
| IE-07 | **A fine lancio si cancellano tutte le scadenze non scritte dal lancio stesso**, comprese quelle andate in errore. Lo scadenzario iec è quindi la fotografia di AD all'ultima sincronizzazione. | idem (end) | [C]. Tutte le 9.196 portano l'id dell'ultimo lancio (02/10, 07:50 UTC); differenze con AD: 22 scadenze nuove, 9 superate e 15 con date cambiate, tutte modificate in AD dopo il lancio. 113 lanci falliti tra aprile e luglio, nessun errore dal 21 luglio [D]. |
| IE-08 | **Copertura della scadenza.** Una scadenza è coperta se esiste una riga con la stessa chiave, non rifiutata, in un preventivo non rifiutato né annullato, con attività vuota, da programmare o programmata. Vale anche se l'attività è effettuata ma non ancora sincronizzata e la nuova prossima data supera quella della scadenza. | vista `scadenze_read` | [C]. È diversa da AD-41: lì si guarda il tipo di verifica, qui lo stato dell'attività e della sincronizzazione. |

### 3.2 Preventivi: punti, sottopunti, prezzi

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| IE-09 | **Due livelli.** Il punto porta titolo, articolo, tipologia di prezzo, nota finale e percentuale del collaboratore; il sottopunto porta descrizione, bene, tipo di scadenza, stato e, se il prezzo è singolo, il prezzo. Il punto non ha mai stato né date. | `gi_preventivi_righe_save_before` | [C]. Nessun punto con stato [D]. |
| IE-10 | **Numerazione a passi di 10.** Nuovo punto = massimo del preventivo arrotondato alla decina + 10; nuovo sottopunto = massimo del punto + 10. Il numero di punto è unico nel preventivo e quello di sottopunto nel punto; un sottopunto richiede un punto con lo stesso numero. Rinumerare un punto rinumera i suoi sottopunti. | default `gi_preventivi_righe_n_riga_*`; save_before; change_after | [C]. Nessun duplicato, tutti multipli di 10 [D]. |
| IE-11 | **Tipologia di prezzo.** S = prezzo su ogni sottopunto, C = prezzo sul punto. Si propone dall'articolo, i sottopunti la ereditano e non si cambia dopo la creazione. Un prezzo inserito sul livello sbagliato si azzera. | default `gi_preventivi_righe_tip_prezzo_*`; save_before | [C]. S 2.727, C 115; nessun sottopunto con tipologia diversa dal punto [D]. |
| IE-12 | Prezzo netto ≥ 0, sconto ≥ 0, sconto percentuale ≤ 100, sconto assoluto ≤ prezzo netto. Uno sconto pari a 0 o vuoto cancella anche il tipo. **Solo in maschera**: la modifica multipla salta questi controlli e cancella il tipo solo se lo sconto è vuoto. | idem (ramo `$is_multiedit`) | [C]. 48 sottopunti in 3 preventivi con sconto 0 e tipo "€" [D]. |
| IE-13 | **Sconto di testata.** Se percentuale si applica a ogni riga; se assoluto si ripartisce in proporzione al prezzo scontato di ogni riga e non può superare il totale scontato. Non si modifica su un preventivo accettato o parzialmente accettato. | `gi_preventivi_totali_recalc`; `gi_preventivi_save_before`; meta | [C]. Ricalcolo coerente su tutte le righe e tutti i preventivi; 18 preventivi con sconto di testata (12 assoluti, 6 percentuali) [D]. |
| IE-14 | Totali del preventivo: netto = somma dei prezzi netti, scontato = somma dei prezzi scontati, finale = somma dei prezzi finali, arrotondati a 2 decimali per riga. | idem | [C][D] |
| IE-15 | **Righe anomale**: righe da prezzare (sottopunti a prezzo singolo e punti a corpo) senza prezzo o con prezzo ≤ 0. Con righe anomale il preventivo non si stampa e non passa a "inviato". | `gi_preventivi_n_righe_anomale_recalc`; `gi_preventivi_save_before`; permesso di stampa | [C]. Oggi 5 preventivi creati con 11 righe anomale e 1 parzialmente accettato con 2 [D]. |
| IE-16 | Stato del preventivo calcolato dai sottopunti come IC-15 e IC-16. L'utente sceglie solo "creato" o "inviato". | `gi_preventivi_stato_recalc` | [C]. Coerente in 349 preventivi su 349 [D]. |
| IE-17 | **Fatturazione del preventivo**: totale se i sottopunti fatturati sono pari a quelli non rifiutati, parziale se almeno uno. A differenza di IC-17, le righe rifiutate sono escluse dal conteggio: un preventivo tutto rifiutato risulta quindi "totale". | idem | [C]. Coerente sui 349; i 4 preventivi rifiutati sono tutti "fatturato totale" [D]. |
| IE-18 | Un sottopunto si accetta solo se c'è il prezzo: il proprio se singolo, quello del punto se a corpo. In modifica multipla il controllo vale solo per il prezzo singolo. | save_before (anche ramo modifica multipla) | [C] |
| IE-19 | **A corpo, tutto insieme.** I sottopunti di un punto a corpo cambiano stato insieme. Aggiungere un sottopunto riporta tutti i fratelli "da accettare", perdendo le date di programmazione (con un avviso in maschera). Non si aggiungono sottopunti a un punto a corpo accettato con almeno un sottopunto effettuato. | change_after; `gi_inserisci_sottopunto_da_scadenza_punto`; `js_gi_form_fields_preventivi_righe_check` | [C]. Nessun punto a corpo con stati misti [D]. |
| IE-20 | Una riga fatturata non può perdere lo stato "accettata". Una riga con almeno un sottopunto fatturato non si modifica; si cancella solo se nessun sottopunto è accettato. | save_before; permessi | [C] |
| IE-21 | **Divieto di ripreventivare** (come IC-20): una riga rifiutata non si riattiva se la scadenza ha già un'altra riga; una scadenza già coperta non si inserisce di nuovo. Il primo controllo non vale in modifica multipla. | save_before; `gi_inserisci_sottopunto_da_scadenza_punto` | [C]. Nessuna scadenza con due righe aperte [D]. |
| IE-22 | **Sottopunti dalle scadenze.** Dal punto si scelgono una o più scadenze della sede. Ognuna diventa un sottopunto "da accettare", con flag di sincronizzazione No e descrizione composta: per le tarature tipo di accessorio, fabbricante, matricola e Ptar, poi descrizione e numero di fabbrica dell'attrezzatura; per CND e supplementari descrizione, costruttore, numero di fabbrica, matricola, anno e modello. I valori "n.a." si escludono. Con prezzo singolo si ricorda di inserire il prezzo. | `gi_inserisci_sottopunto_da_scadenza_punto`; `gi_preventivi_righe_descrizione_default_calc`; ajax | [C] |
| IE-23 | Un sottopunto senza scadenza è di tipo "altro" (predefinito) e non è legato a nessun bene. | default `gi_preventivi_righe_tipo_scad_*` | [C]. 1.150 sottopunti "altro", tutti con attrezzatura 0 [D]. |
| IE-24 | La percentuale del collaboratore sul punto si propone dalla tabella collaboratore × articolo del collaboratore del cliente. | default `gi_preventivi_righe_perc_collab_*` | [C]. 160 punti valorizzati: 66 a 0, 94 tra 10% e 60% [D]. |
| IE-25 | Il collaboratore del preventivo viene dal cliente al momento della creazione e non si aggiorna dopo. | meta (`values_dragging`) | [C]. 2 preventivi senza collaboratore benché il cliente lo abbia [D]. |
| IE-26 | **Numerazione del preventivo**: serie = anno della data, numero = ultimo della serie + 1, modificabile. | meta (`gi_nextcode_get`) | [C]. Nel 2026, 325 preventivi con numeri da 4 a 424 di cui 96 mancanti, non in ordine di data (il n. 14 è dell'8 giugno). 17 preventivi del 2024–2025 ricaricati con il loro numero. Serie "2026/1"…"2026/4" usate come revisioni: il preventivo 11 ne ha quattro [D]. Che i numeri vengano da un registro esterno è da confermare [I]. |
| IE-27 | **Stampa del preventivo** da un modello Word configurabile. I punti diventano lettere (A, B, … poi AA); per ogni punto si stampano totale e totale scontato, e in fondo il totale come "A+B+C" con lo sconto decodificato. | `gi_cust_modello_preventivi_get`; `php_gi_rpt_rows_preventivi_righe_punti_modify`; `gi_preventivi_php_which_record_preventivi_ext` | [C]. 414 stampe [D]. |

### 3.3 Attività

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| IE-28 | **L'attività è il sottopunto accettato.** Accettare la riga crea l'attività "da programmare"; togliere l'accettazione cancella stato e date. | `gi_attivita_da_programmare_calc`; vista `attivita_read` | [C]. 1.753 attività = 1.753 sottopunti accettati [D]. |
| IE-29 | **Stato dalle date.** Una data di programmazione porta a "programmata"; una data di esecuzione, con la prossima scadenza se il tipo non è "altro", porta a "effettuata". Non vale per le attività annullate. | `gi_attivita_save_before` | [C] |
| IE-30 | Programmata richiede la data di programmazione. Effettuata richiede la data di esecuzione e, se non è "altro", la prossima scadenza. "Altro" non ha mai prossima scadenza. | idem | [C]. Nessuna violazione [D]. |
| IE-31 | **Flag di sincronizzazione**: un'attività effettuata non "altro" passa a "Sì"; se torna non effettuata prima dell'invio, "No"; dopo l'invio, "Sincronizzato", che resta tale anche se l'attività torna indietro. Se si cambiano le date di un'attività già sincronizzata compare solo un avviso: la correzione va riportata a mano su AD. | idem | [C]. Sincronizzate 579, in attesa 40 (modificate il 02/10 dopo l'ultimo lancio); nessuna sincronizzata tornata indietro [D]. |
| IE-32 | Un'attività effettuata e fatturata non si modifica più. | permesso `edit_attivita` | [C]. Tutte le 1.177 effettuate sono fatturate [D]. |
| IE-33 | **Nessun controllo sulle date**: né date future né ordine tra programmazione, esecuzione e prossima scadenza. Lo stato si può inoltre reimpostare a mano lasciando le date. | assenza di controllo | [C]. 3 attività con esecuzione nel 2036 (refuso), 5 tarature eseguite il 10/10/2026 (dopo la data del dump), 16 "da programmare" con data di programmazione, 12 aperte con data di esecuzione [D]. |

### 3.4 Fatturazione

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| IE-34 | Il motore fiscale è **identico ad adsrl e ingecert** (AD-52, §5 del catalogo ingecert). Serie `/AAAA`; il cedente è I&C, con codice fiscale proprio. | confronto dei file | [C] |
| IE-35 | **Genera fattura** dalle righe: solo sottopunti accettati, effettuati e non fatturati, tutti dello stesso cliente; si può integrare una fattura esistente. Con prezzo a corpo: una riga per punto con titolo e descrizioni dei sottopunti, prezzo del punto, punto e sottopunti segnati come fatturati. Con prezzo singolo: una riga per sottopunto con titolo del punto e descrizione. | `gi_preventivi_righe_fattura_cliente_genera` | [C]. 297 lanci, 13 falliti (cliente diverso, campi in errore) [D]. |
| IE-36 | In descrizione si aggiungono "preventivo …" e "rif. ordine cliente …"; i caratteri fuori dal Latin-1 si eliminano e il testo si tronca a 1.000 caratteri. Prezzo = prezzo finale della riga. IVA del cliente o quella predefinita. Per una fattura nuova: pagamento del preventivo, poi del cliente, poi il predefinito; documento collegato dal primo preventivo che ha tipo, numero e data. Integrando una fattura esistente, pagamento e documento collegato restano quelli della fattura. | idem | [C]. 125 fatture con documento collegato [D]. |
| IE-37 | Una fattura può raccogliere sottopunti di più preventivi dello stesso cliente. | idem | [D] 8 fatture. |
| IE-38 | La riga del preventivo risulta fatturata **per intero** anche se l'importo in fattura viene ridotto a mano: non esistono acconti o fatturazione parziale di una riga. | assenza di logica | [C]. Fattura 108: 2.500 € in fattura contro 12.500 € in riga [D]. Altre differenze: fattura 67 manuale, note di credito con riemissione (171–172, 260–263), un arrotondamento (257), una spesa accessoria (278). |
| IE-39 | Fatture e note di credito condividono la numerazione di serie, come AD-54. | `gi_nextcode_get` | [D] /2026 da 66 (aprile 2026; i numeri precedenti sono del sistema di prima) a 299. Mancano 137, 199 e 206. 3 note di credito. 34 fatture del 29/09 senza XML al 07/10. |
| IE-40 | Fattura saldata = almeno un pagamento e nessun pagamento aperto. | `gi_fatture_clienti_fattura_saldata_recalc` | [C]. Coerente in 231 su 231; un pagamento per fattura [D]. |
| IE-41 | Il nome dei file XML segue lo stesso schema di adsrl, compresa la parte aggiunta per AD ("HACK ADSRL"). Il codice fiscale di I&C non collide con nessun altro. | `fatture_clienti_genera_xml_cli.php` | [C][D] |

### 3.5 Collaboratori e provvigioni

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| IE-42 | Ogni collaboratore ha una percentuale per ogni articolo (0 di default). Un nuovo articolo aggiunge la riga a tutti i collaboratori; un cambio di ruolo crea o cancella le righe dell'utente. La percentuale è tra 0 e 100. | `gi_utenti_collaboratori_percentuali_*` | [C]. 132 righe, 16 diverse da 0 [D]. |
| IE-43 | **Importo del collaboratore** = prezzo finale × percentuale del punto (o del sottopunto), solo sulle righe fatturate. Stato: assegnato se la fattura cliente non è saldata, fatturabile se è saldata, fatturato se c'è la fattura del collaboratore. | vista `importi_collaboratori_read`; `preventivi_righe_read` | [C]. 120 importi per 22.616 € [D]. |
| IE-44 | La fattura del collaboratore si collega solo a importi dello stesso collaboratore. La differenza = imponibile − somma degli importi; se negativa compare un avviso. | `gi_importi_collaboratori_*`; `gi_fatture_collaboratori_differenza_recalc` | [C]. 3 fatture, nessun importo collegato [D]. |
| IE-45 | **Blocco a cascata.** Una fattura cliente che contiene un importo già fatturato dal collaboratore non si modifica, non si cancella, non riceve nuove righe e i suoi pagamenti restano fermi. | permessi; `_doc_fiscali_common.php`; `gi_pagamenti_save_before` | [C]. Nessun caso oggi [D]. |

---

## 4. Processi e azioni da griglia

| Azione | Precondizione | Parametri | Effetto | Uso [D] |
|---|---|---|---|---|
| Sincronizza scadenze | amministrazione | — | IE-02…IE-07 | 315 (fino a 22 in un giorno: il 25/06, 17 falliti) |
| Inserisci come sottopunti | punto senza sottopunti accettati ed effettuati | scadenze della sede | IE-22 | — |
| Inserisci sottopunto al punto | idem | — | nuovo sottopunto precompilato | — |
| Genera fattura | IE-35 | fattura da integrare | IE-35, IE-36 | 297 |
| Genera XML | come ingecert | — | — | 22 ZIP |

**Modifiche multiple nel lavoro quotidiano** [D]:
- 383 cambi di stato delle righe (337 accettazioni, 38 ritorni a "da accettare", 8 rifiuti);
- 18 interventi sugli sconti, 12 dei quali insieme al cambio di stato;
- circa 290 aggiornamenti di date e stato delle attività: è il modo in cui si registrano le esecuzioni.

**Cruscotto** [C]:
- scadenze da preventivare nei prossimi 91 giorni (sede attiva, bene non dismesso, nessun preventivo);
- preventivi inviati;
- pagamenti scaduti;
- attività da programmare;
- attività programmate.

L'operatore ha salvato filtri personali come "DA FATTURARE" e "REPORT DA ELABORARE" [D]: il rapporto tecnico si produce fuori dal gestionale [I].

---

## 5. Ruoli e permessi reali

| Ruolo (utenti attivi) | In sostanza [D] |
|---|---|
| Amministrazione (2: Garda e I&C) | Tutto. L'account I&C ha lanciato 601 dei 612 lavori batch (§0, punto 7). |
| Collaboratore (4, mai entrati; 2 con indirizzo AD) | Solo lettura di clienti, sedi, scadenze, preventivi, fatture e importi propri; export degli importi. |
| Cliente (nessun utente) | Sedi e scadenze proprie. È il **ruolo predefinito** per i nuovi utenti. |

Non esiste un ruolo tecnico: chi esegue CND e tarature non usa il gestionale [D][I]. I due collaboratori con indirizzo AD corrispondono ai referenti commerciali AD della mappa in configurazione [I].

---

## 6. Uscite

- **Preventivo** da modello Word configurabile (`MODELLO_PREVENTIVO.docx`), con punti a lettere, sconti e totali (IE-27). Nome file: "Preventivo ‹numero›-‹anno› del ‹data› ‹cliente›".
- **Fattura** in PDF e XML FatturaPA, come adsrl; la mail parte verso il cliente. 190 mail inviate, tutte di fatture [D].
- **Export** da griglia di righe, attività e scadenze (9).

---

## 7. Anomalie e punti da decidere per il nuovo sistema

| # | Tema | Classe | Proposta |
|---|---|---|---|
| E1 | Sincronizzazione tra due database con collegamento per nome; le scadenze in errore si cancellano; le correzioni dopo l'invio vanno rifatte a mano (IE-02…IE-07, IE-31). | **Da decidere** | Nel nucleo comune la sincronizzazione sparisce: un solo bene e una sola scadenza, l'attività I&C scrive la data direttamente. Resta da fissare la regola di prevalenza (B8 di adsrl). |
| E2 | Anagrafica duplicata e non allineata (IE-04). | Osservazione (migrazione) | Anagrafica unica deduplicata su CF/P.IVA, con dati commerciali per società (pagamento, referente o collaboratore, sconto). |
| E3 | I beni sono numeri di un altro database, con dati ricopiati nella scadenza. | Osservazione | Riferimento diretto al bene comune; niente copie. |
| E4 | Preventivo tutto rifiutato segnato "fatturato totale" (IE-17). | Da correggere | Formula unica per i tre sistemi. |
| E5 | Niente acconti né fatturazione parziale: la riga risulta fatturata per intero (IE-38). | Da decidere | Fatturazione per importo (acconti, SAL) collegata alla riga. |
| E6 | Nessun controllo sulle date; stato reimpostabile a mano contro le date (IE-33). | Da correggere | Stato derivato dalle date; date future e ordine controllati. |
| E7 | Numerazione dei preventivi manuale e serie usate come revisioni (IE-26). | Da decidere | Numero automatico e revisioni esplicite del documento. |
| E8 | Modifica multipla con controlli ridotti su prezzo, sconti e riattivazione delle righe (IE-12, IE-18, IE-21); attività registrate quasi solo in modifica multipla. | Da correggere | Stessi controlli in maschera e in modifica multipla, come B6 di adsrl. |
| E9 | Provvigioni calcolate ma mai riconciliate (IE-43, IE-44). | Da decidere | Capire se il modulo serve; in caso, un unico concetto di agente o referente per le tre società. |
| E10 | Endpoint di sincronizzazione con chiavi statiche nel file di configurazione (B15 di adsrl). | **Bloccante** (sicurezza) | Rotazione delle chiavi; nessun endpoint tra moduli dello stesso backend. |
| E11 | Ruolo Cliente predefinito per i nuovi utenti. | Osservazione | Ruolo predefinito senza accessi. |
| E12 | Piccoli difetti: il calcolo del numero di punto usa una variabile sbagliata quando il massimo non è multiplo di 10 (finora mai capitato); messaggio dei pagamenti copiato da quello delle righe; filtri preimpostati con nomi di colonna di AD; 4 scadenze orfane di una sede cancellata. | Osservazione | Nessuna azione oltre alla bonifica in migrazione. |

---

## 8. Cosa non è stato verificato

- Il processo operativo di I&C fuori dal gestionale: chi esegue CND e tarature e dove si produce il rapporto.
- Se le attività I&C rientrano in un accreditamento (in quel caso servirebbero tracciabilità e controlli come in AD).
- Il significato delle serie "2026/1"…"2026/4" e l'origine dei numeri di preventivo.
- I valori della configurazione di collegamento (soglie di id, mappa dei referenti): esistono ma non sono riportati.
- Il contenuto del modello Word e dei PDF delle fatture.

---

## 9. Cosa porta iec nel nucleo comune

- **Anagrafica**: clienti e sedi sono in gran parte gli stessi di AD. Un'unica anagrafica con dati commerciali per società elimina IE-03…IE-05.
- **Beni e scadenze**: CND, supplementari e tarature diventano scadenze dello stesso bene di AD, eseguite da I&C. La sincronizzazione sparisce.
- **Documento commerciale**: il modello a punti e sottopunti, con prezzo singolo o a corpo e sconti su due livelli, è il più completo e può contenere anche le righe semplici di ingecert e adsrl.
- **Attività**: in iec l'attività ha solo stato e date; in AD e ingecert è una verifica con verbale e riesame. Serve un'attività comune (stato, date, fatturazione) con un'estensione "verifica" per AD.
- **Fatturazione**: stesso motore per tre cedenti; serie e contatori per società. AD ha un codice fiscale condiviso tra ingecert e adsrl, I&C uno proprio.
- **Referenti e collaboratori**: il referente commerciale di AD e il collaboratore di iec sono la stessa figura, qui con provvigione.

---

## Storico

| Versione | Data | Contenuto |
|---|---|---|
| 1.0 | 9 ottobre 2026 | Prima stesura completa per iec: strutture, 45 regole, sincronizzazione con adsrl, fatturazione, provvigioni, permessi reali, uscite, anomalie, apporto al nucleo comune. |
