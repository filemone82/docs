# Catalogo Garda — adsrl (AD_dm): regole e strutture

**Versione 1.0 · 9 ottobre 2026.** Secondo dei tre cataloghi, dopo ingecert. Stesso metodo e stessa destinazione: la matrice di parità.

**Fonte:** `backup_gestionale.7z`, codice PHP/JS e dump MariaDB di adsrl del 07/10/2026. Conteggi principali: 776 clienti, 1.080 sedi, 9.346 attrezzature, 3.311 valvole, 1.849 preventivi, 9.878 righe, 8.700 verifiche, 728 fatture elettroniche.

**Legenda delle evidenze**
- **[C]** letto nel codice, con file e funzione.
- **[D]** misurato sul dump.
- **[I]** dedotto, da confermare.

Gli ID sono quelli di adsrl. Le regole uguali a ingecert rimandano al codice IC-xx del catalogo ingecert. **Allegato:** `catalogo/adsrl_02_campi.md` riporta ogni campo di ogni entità, con vincoli e riempimento reale.

---

## 0. Sintesi

adsrl gestisce le verifiche periodiche del D.M. 11.04.2011 su tre gruppi di attrezzature:
- **GVR**: apparecchi a pressione;
- **SC**: sollevamento cose;
- **SP**: sollevamento persone.

La catena è la stessa di ingecert (scadenza → preventivo → verifica → fattura) con tre aggiunte:
- il **verbale strutturato** dentro la verifica, stampato da modello Word;
- l'**export verso il portale INAIL**;
- le **valvole di sicurezza** con le loro tarature, alimentate da I&C.

| File | Contenuto |
|---|---|
| `cust/meta/*.js` (56 file, 22 diversi da ingecert) | Strutture, permessi, condizioni delle azioni. |
| `cust/_custom.php` (3.195 righe) | Hook, scadenze multi-tipologia, tariffe GVR/SC-SP, numerazione, contributo INAIL, copia dei dati tra attrezzatura e verifica, tabelle di riferimento dell'Allegato VII. |
| `cust/lavori_batch_cli.php` (2.080) | Generazioni, export INAIL, import Excel di attrezzature/valvole/dati tecnici, copia attrezzature. |
| `cust/iec_sincronizza_scadenze.php` (184) | Endpoint che riceve da iec le date di CND, indagini supplementari e tarature. |
| `cust/gi_views.php` (385) | Campi derivati, comprese le caselle del verbale. |
| `_doc_fiscali_common.php`, `fatture_clienti_genera_xml_cli.php` | **Identici a ingecert**, salvo la serie `/AAAA/DM`. |

**Le evidenze più rilevanti per il progetto**

1. **La dichiarazione di indipendenza non è controllata.** Il campo esiste con default "Sì", ma nessuna regola blocca programmazione o chiusura: 232 verifiche effettuate hanno "No". [C][D]
2. **L'esito nasce "Positivo".** La generazione delle verifiche imposta l'esito prima del sopralluogo: 593 verifiche ancora assegnate hanno già esito positivo. [C][D]
3. **Il riesame non funziona come in ingecert.** Un esito N non riporta la verifica in "registrata" e la chiusura non azzera il riesame. Il permesso di riesame vale in qualsiasi stato. [C]
4. **Il riesame del contratto non ha un permesso dedicato.** Chi modifica il preventivo, compreso il referente commerciale, può registrarlo. [C]
5. **Nella numerazione dei verbali ci sono 29 buchi** in totale, più contatori aperti su anni inesistenti (2027, 2029, 2034). [D]
6. **Attrezzatura e verifica si aggiornano a vicenda.** I dati tecnici dell'attrezzatura entrano nelle verifiche aperte e i dati rilevati in verifica tornano sull'attrezzatura. È lo stesso tema dello "stato tecnico" di VerbalizzAI. [C]
7. **La modifica multipla salta l'obbligo del verbale PDF**, ed è usata per riesami in blocco (circa 130 lotti) e per riaprire l'export INAIL (159). [C][D]
8. **Le date di I&C sovrascrivono quelle di AD senza confronto.** Le date di CND e tarature ricevute da I&C sostituiscono quelle presenti; quelle registrate in verifica da AD invece vengono confrontate. [C]
9. **Fatturazione con tre serie AD:** `/AAAA/DM`, `/AAAA/EX`, `/AAAA/ex` (stessa serie scritta in due modi). Note di credito e fatture condividono la numerazione; mancano 3 numeri nel 2026/DM e 4 nel 2026/EX. [D]
10. **Gli allegati hanno due registrazioni non allineate.** La stringa `verbale` della verifica vale "," in 3.129 effettuate, mentre la tabella dei file ha il PDF per tutte tranne una. Per la migrazione la fonte affidabile è la tabella dei file. [D]

---

## 1. Perimetro dell'installazione

| Gruppo | Entità | Record |
|---|---|---|
| Anagrafiche | `clienti`, `clienti_sedi_operative` | 776 · 1.080 (14 inattive) |
| Beni | `attrezzature`, `valvole_sicurezza`, `attrezzature_vds` (associazione N:N) | 9.346 · 3.311 · 3.399 |
| Tabelle Allegato VII e INAIL | `tipi_attrezzature` (31), `tipi_attrezzature_gvr` (6), `id_specifiche` (72), `tipi_attr_id_specifiche` (162) | — |
| Listini | `tariffe_gvr` (132 = 33 specifiche × 4 colonne), `tariffe_sc_sp` (182) | — |
| Scadenzario (derivato) | `scadenze` | 24.375 |
| Commerciale | `preventivi`, `preventivi_righe` | 1.849 · 9.878 |
| Verifiche | `verifiche` (147 colonne), `verifiche_verbale`, `verifiche_scheda_tecnica` | 8.700 · 7.715 · 669 |
| Fatture | `fatture` (registro), `fatture_clienti` e collegate, `pagamenti` | 1.054 · 728 · 728 |
| Utenti | `utenti` (con `firma` e `qualifica`), `utenti_firma`, `ruoli` | 27 · 7 · 5 |
| Framework | lavori batch, mail, stampe, export, modifiche multiple | 7.107 lavori · 720 mail · 7.814 stampe · 1.641 modifiche multiple |

Anche qui il database non ha chiavi esterne e nessuna delle 12 relazioni controllate presenta record orfani [D].

**Vincoli di unicità** [C][D]:
- `clienti.rag_soc`; `clienti_sedi_operative.nome_sede`, unico su tutto l'archivio;
- attrezzature (`sede_operativa`, `matr_informale`); valvole (`sede_operativa`, `matricola`);
- `attrezzature_vds` (`attrezzatura`, `valvola_sicurezza`);
- scadenze (`attrezzatura`, `tipo_scad`, `valvola`);
- preventivi (serie, numero); righe (preventivo, `n_riga`);
- `verifiche.codice_verifica`;
- fatture (serie, tipo documento, numero);
- tariffe GVR (`id_spec`, `tipo_ver`) e SC/SP (`tipo_attr_id_spec`, `tipo_ver`).

---

## 2. Strutture

### 2.1 Relazioni

```
clienti 1─N sedi 1─N attrezzature (gruppo GVR/SC/SP) N─N valvole_sicurezza (attrezzature_vds)
attrezzature → tipi_attrezzature (Allegato VII) → tipi_attrezzature_gvr ; attrezzature → id_specifiche
tipi_attr_id_specifiche (tipo × specifica) ← tariffe_sc_sp ; id_specifiche ← tariffe_gvr
attrezzature 1─N scadenze (funz, integrita, interna, cnd | scsp, suppl) + 1 scadenza "taratura" per ogni valvola attiva collegata
preventivi (cliente + SEDE) 1─N righe N─1 attrezzature ; riga 1─0..1 verifica
verifiche N─1 attrezzature · → fatture | fatture_clienti · → lavoro di export INAIL
```

Rispetto a ingecert:
- **il preventivo è per sede**, non solo per cliente (527 clienti, 804 sedi);
- l'oggetto verificato ha **più scadenze indipendenti**;
- esiste un **secondo bene** (la valvola) collegato N:N: 98 valvole servono più attrezzature [D].

### 2.2 Campi che portano regole

**`clienti`**
- Come ingecert, più `sconto_def`: sconto predefinito copiato nelle righe di preventivo. 138 clienti al 15%, 11 al 10% [D].
- Le righe con lo sconto predefinito del cliente sono 9.203 su 9.878 [D].

**`clienti_sedi_operative`**
- `inattiva`: una sede inattiva esclude dallo scadenzario le valvole e, nei filtri predefiniti, le scadenze.
- `utente_cliente` è valorizzato in 15 sedi: il **portale clienti è in uso**, con 14 utenti cliente [D].

**`attrezzature`**

| Gruppo di campi | Contenuto |
|---|---|
| Identità | matricola formale **obbligatoria** con regex bloccanti (anno, codice attività, numero a 5 cifre, provincia); `matr_informale` obbligatoria e unica per sede; `num_fabbrica`, costruttore, modello, anno, descrizione, reparto, riferimento interno, marcatura CE. Matricole formali duplicate tra attrezzature non dismesse: 117 [D]. |
| Stato | `dismessa` (491); `esente_verifiche` No / Sì / **"ISO17020"** (424 Sì, 1.087 ISO17020) [D]. Il significato operativo di "ISO17020" va chiarito [I]. |
| Classificazione | `gruppo_attr` GVR / SC / SP, non modificabile dopo la creazione (GVR 7.729, SC 1.359, SP 258) [D]; `tipo_attr` (codice Allegato VII); `id_spec` (specifica INAIL); `tipo_attr_verbale` (RG, RV, GV, INS, TUB…). |
| Dati GVR | PS, volume, TS, superficie riscaldata, producibilità, `sogg_messa_servizio_gvr` (decide la colonna di tariffa), gruppo fluido, categoria PED, `matr_insieme` (formato AAAA/F/NNNNN/PR), `id_pacco_bombola`, breve descrizione del funzionamento. |
| Configurazione GVR | `gvr_conf_dati_tecnici`: elenco di camere e componenti con n. fabbrica, PS, TS, natura, stato e gruppo del fluido, volume, DN. |
| Dati SC/SP | portata, numero panieri degli idroestrattori. |
| Date per tipologia | `ultima_/data_ult_/data_prox_` per funzionamento, integrità, visita interna, verifica SC/SP; date **manuali** di CND e indagine supplementare; campi di riepilogo valvole (`valv_sicurezza`, ultima e prossima taratura). |
| `tipo_prox_verifica` | V1 prima periodica / V2 successiva; diventa V2 dopo la prima verifica effettuata. |
| Campi derivati in vista | Codici INAIL (`tipo_attr_inail`, `tipo_attr_gvr_inail`, `id_spec_inail`) e `alert_tipo_attr` (vedi AD-04). |

**`valvole_sicurezza`**
- Sede obbligatoria, `matricola` obbligatoria e unica per sede.
- `tip_accessorio`: valvola di sicurezza 2.343, intercettazione combustibile 133, disco di rottura 25, vuota in 810 [D].
- Fabbricante, modello, DN, diametro, area, Ptar, `ultima_tar`/`prossima_tar` (tarature biennali in 2.676 casi su 2.912 con entrambe le date) [D].
- 159 valvole non sono collegate a nessuna attrezzatura; 9 associazioni collegano valvola e attrezzatura di sedi diverse [D].

**`tariffe_gvr`**: per ogni specifica INAIL quattro colonne.

| Colonna | Quando si applica |
|---|---|
| V1 | prima periodica di attrezzatura soggetta a messa in servizio |
| V2 | prima periodica di attrezzatura non soggetta |
| V3 | successiva di funzionamento o visita interna |
| V4 | successiva di integrità o verifica multipla |

Valori da 66,58 € a 6.913,47 € [D].

**`tariffe_sc_sp`**: per coppia tipo Allegato VII × specifica, colonne V1 e V2 (145,28 €–575,12 €) [D].

**`preventivi`**
- In più rispetto a ingecert: `sede_operativa` obbligatoria e non modificabile dopo la creazione; `lic_gest`/`prz_lic_gest` (licenza del software gestionale venduta in offerta: 12 preventivi, 4.020 € in tutto) [D]; sottototali `tot_gvr_pvp`, `tot_gvr_vps`, `tot_scsp_pvp`, `tot_scsp_vps`.
- In meno: non c'è trasferta né INAIL 5%.
- `old_stato_preventivo` è una colonna storica, con valori come "concluso" [D].

**`preventivi_righe`**
- `tipo_verifica` V1 o V2.
- `tipo_verifica_gvr`: funzionamento, integrità, visita interna e le quattro combinazioni. **Le combinazioni non sono mai usate**: ogni tipologia ha la propria riga [D].
- `sconto` predefinito dal cliente (15% in 3.753 righe; **−15% in 8 righe**, cioè una maggiorazione) [D].
- Gli altri campi sono come in ingecert.

**`verifiche`** (147 colonne, in cinque strati mescolati)
1. **Processo**: stato, `dichiaro_che`, tecnico, tecnico in affiancamento (656 casi), data di programmazione, riferimenti a preventivo e fattura, `esp_inail` con lotto di export, riesame, note interne.
2. **Dati di verifica**:
   - `tipo_verifica` e `tipo_verifica_gvr` copiati dalla riga;
   - `regime_verifica` A1 (affidamento INAIL) o A2 (affidamento del datore di lavoro);
   - esito, motivazione di sospensione, data di rilascio;
   - prossime date per tipologia, date CND;
   - `data_pvp`, calcolata come la più vicina delle prossime date.
3. **Economico**: tariffa standard ed effettiva, `contributo_al_sogg_titolare`.
4. **Contenuto del verbale GVR**:
   - scelta "attrezzatura" o "insieme";
   - configurazione e dati tecnici con pressioni e temperature di esercizio, capacità calcolata;
   - parametri acqua e conduttore abilitato (solo generatori di vapore);
   - accessori di sicurezza, dispositivi di controllo e regolazione, altri accessori, valvole di intercettazione;
   - esame visivo ed esami di stabilità, verifiche di integrità di recipiente, generatore e insieme;
   - esame spessimetrico con data ed esito, altre prove, prove sulle tubazioni, stato di conservazione, osservazioni.
5. **Contenuto del verbale SC/SP**: condizioni generali, esame degli organi principali, prove di funzionamento, configurazione e dati tecnici, osservazioni.

Completano la verifica i file `verbale` e `scheda_tecnica` (obbligatoria per le V1) e le caselle del modello calcolate in vista (gru, ponte mobile, piattaforma, …).

---

## 3. Regole

### 3.1 Attrezzature, valvole e tabelle

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| AD-01 | I campi di un gruppo si azzerano sulle attrezzature dell'altro gruppo: dati GVR e date funzionamento/integrità/visita interna/CND sulle SC/SP; portata, panieri e date SC/SP sulle GVR. | `gi_attrezzature_save_before` | [C] |
| AD-02 | Dopo la prima verifica effettuata di una tipologia, data ultima e prossima di quella tipologia e `tipo_prox_verifica` non si modificano più a mano. | idem; `ricalcola_scadenze_attrezzatura` | [C] |
| AD-03 | Il codice tipo e la specifica si scelgono solo tra quelli del gruppo. Per lo stesso gruppo, nella tabella tipo × specifica è obbligatorio il tipo GVR oppure il tipo SC/SP. | meta; `gi_tipi_attr_id_specifiche_save_before` | [C] |
| AD-04 | Un sollevamento SC classificato "non antecedente 10 anni" (codici a2, a4, b2) con più di 10 anni di costruzione segnala che il codice va cambiato. | vista `attrezzature_read` (`alert_tipo_attr`) | [C]. 3 casi oggi [D]. |
| AD-05 | Ogni modifica di attrezzatura, valvola o associazione ricalcola le scadenze dell'attrezzatura. Aggiorna inoltre le verifiche aperte: date non pertinenti, dati copiati dalla verifica precedente, dati tecnici. | `gi_attrezzature_change_after`, `gi_valvole_sicurezza_change_after`, `gi_attrezzature_vds_change_after` | [C] |
| AD-06 | Cambiare lo stato attivo/inattivo di una sede ricalcola le scadenze di tutte le sue attrezzature. | `gi_clienti_sedi_operative_change_after` | [C] |
| AD-07 | "Copia attrezzature e dismetti" copia anche le valvole attive. Riusa una valvola uguale già presente nella sede di destinazione, altrimenti la crea e dismette l'originale. | `gi_copia_attrezzature_dismetti` | [C]. Usata 10 volte [D]. |
| AD-08 | Import Excel di attrezzature e valvole: la sede si trova **per nome**, l'attrezzatura per sede e matricola informale; i codici Allegato VII e la specifica sono convalidati sulle tabelle. | `gi_migra_attrezzature`, `gi_migra_valvole_sicurezza` | [C]. **Strumento d'uso corrente**: 581 import attrezzature, 94 valvole, 4 di dati tecnici GVR da scraping [D]. |

### 3.2 Tariffe e preventivi

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| AD-09 | **Tariffa GVR**: la colonna si sceglie come in §2.2 (V1, V2, V3 o V4), cercando la specifica INAIL dell'attrezzatura. Senza tariffa a listino: errore. | `calcola_tariffa_standard` | [C] |
| AD-10 | **Tariffa SC/SP** dalla coppia tipo Allegato VII × specifica e dal tipo di verifica V1 o V2. | idem | [C]. 2.645 righe hanno una tariffa diversa dal listino attuale, cioè il prezzo storico conservato nella riga [D]. |
| AD-11 | Per le GVR la tipologia è obbligatoria in riga; per SC/SP viene azzerata. | `gi_preventivi_righe_save_before` | [C] |
| AD-12 | Divieto di ripreventivare, come IC-20, ma per attrezzatura, tipo di verifica **e tipologia GVR**. Una riga combinata viene scomposta per il controllo, ma un'offerta già combinata non viene trovata quando si preventiva la singola tipologia. | idem | [C]. Nessun doppione aperto [D]. |
| AD-13 | Lo sconto proposto in riga è lo `sconto_def` del cliente, trascinato dalla decodifica dell'attrezzatura. | vista `attrezzature_dec`; batch | [C][D] |
| AD-14 | Totali = somma delle righe + licenza gestionale, con sottototali per gruppo e per prima o successiva verifica. Nessun INAIL o trasferta. | `gi_preventivo_totali_update` | [C] |
| AD-15 | Stato e stato di fatturazione del preventivo sono calcolati dalle righe, come IC-15…IC-17. | `gi_preventivo_stato_update` | [D] coerente in 1.849 preventivi su 1.849. |
| AD-16 | **Riesame del contratto**: se fatto, esito obbligatorio e nota obbligatoria se N; utente e data automatici. **Non esiste un permesso di riesame separato**: basta `edit_preventivi`. | `gi_preventivi_save_before`; meta | [C]. 555 riesami registrati dall'account amministratore AD, 1 da un referente; 57 preventivi hanno esito C senza "riesame fatto" [D]. |
| AD-17 | Il preventivo si stampa dal modello nel codice `modelli/preventivo.docx` ("Preventivo DM n. …"), non configurabile come in ingecert. La frase del totale distingue verifiche e licenza software. | `_rp_preventivo_word.js`, `php_gi_rpt_global_data_preventivo_modify` | [C] |

### 3.3 Verifiche

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| AD-18 | Generando la verifica da una riga si impostano stato "assegnata", tecnico scelto, **esito "Positivo"**, regime A2 se la verifica è successiva, tariffe dalla riga. Si copiano i dati della verifica precedente e quelli dell'attrezzatura. | `gi_preventivi_righe_verifiche_genera` | [C]. 593 assegnate hanno già esito positivo [D]. |
| AD-19 | Campi compilabili secondo il caso: per le GVR solo le prossime date delle tipologie della verifica; per SC/SP solo la prossima verifica SC/SP; CND solo se integrità con CND in corso. Gli altri si azzerano. | `gi_verifiche_save_before` | [C] |
| AD-20 | In "registrata" o "effettuata" sono obbligatori esito, data di rilascio con anno di 4 cifre, regime e prossime date pertinenti. Per le GVR si sceglie "attrezzatura" oppure "insieme", non entrambi. | idem | [D] nessuna violazione sulle effettuate. |
| AD-21 | In "effettuata" sono obbligatori il PDF del verbale e, per le prime periodiche, la scheda tecnica, **tranne in modifica multipla**. | idem (`$is_multiedit`) | [C]. Una verifica effettuata senza file del verbale (376, V/SC/0509/24) [D]. |
| AD-22 | `data_pvp` = la più vicina tra le prossime date della verifica. Viene esportata a INAIL e dà il nome ai file. | idem | [D] 36 verifiche non allineate. |
| AD-23 | **Contributo al soggetto titolare**: 15% della tariffa standard se A1, 5% se A2, ricalcolato a ogni salvataggio. | `gi_verifiche_change_after` | [D] coerente su tutte le effettuate. 97 assegnate o annullate mai risalvate sono a 0. |
| AD-24 | **Numerazione** all'ingresso in registrata o effettuata, con le stesse condizioni di IC-27. Contatore `GVR<anno>` oppure `SC-SP<anno>`, condiviso da SC e SP. Codice = `V/GVR/NNNN/AA` o `V/SC/…`, `V/SP/…`. | idem | [D] 29 buchi: GVR 2024 4, GVR 2025 15, GVR 2026 1, SC-SP 2024 2, SC-SP 2025 3. Contatori `GVR2027`, `GVR2029`, `GVR2034` senza verifiche. 95 verifiche annullate hanno già un numero. |
| AD-25 | All'ingresso in effettuata i PDF di verbale e scheda tecnica si rinominano con lo schema INAIL: "verbale ‹matricola senza separatori›‹ggmmaaaa di data_pvp›.pdf". | idem; `gi_inail_filename_gen` | [C] |
| AD-26 | **Dalla verifica all'attrezzatura.** Su una verifica aperta, o appena chiusa, i dati tecnici (senza pressioni e temperature di esercizio), la breve descrizione e il tipo da verbale tornano sull'attrezzatura. | idem | [C] |
| AD-27 | **Dall'attrezzatura alle verifiche aperte.** I dati tecnici e il tipo da verbale si ricopiano sulle verifiche aperte, mantenendo pressioni e temperature di esercizio solo se la verifica comprende il funzionamento. | `copia_dati_attrezzatura_su_verifiche_non_effettuate` | [C] |
| AD-28 | **Precompilazione dalla verifica precedente**, solo per le verifiche mai salvate. Per le GVR: attrezzatura o insieme, liste di controllo dell'ultima verifica della stessa tipologia, stato delle tubazioni, osservazioni della più recente pertinente. Per SC/SP: i cinque testi del verbale. | `copia_dati_precedente_verifica` | [C] |
| AD-29 | La data dei prossimi CND passa all'attrezzatura solo se successiva a quella registrata; altrimenti compare un avviso. | `gi_verifiche_change_after` | [C] |
| AD-30 | Capacità GVR = somma dei volumi; senza funzionamento, pressioni e temperature di esercizio si svuotano. | `gi_verifiche_save_before` | [C] |
| AD-31 | La dichiarazione di indipendenza **non è controllata** (in ingecert vale IC-25). | assenza di controllo | [C]. Verifiche con "No": 232 effettuate, 188 annullate, 34 assegnate, 5 programmate, 1 registrata [D]. |
| AD-32 | Il riesame (`edit_riesame`) è possibile **in qualunque stato**. Un esito N non cambia lo stato e la chiusura non azzera il riesame (in ingecert valgono IC-28 e IC-29). | meta; assenza di logica | [C]. 16 annullate e 2 registrate risultano riesaminate. Riesami: Responsabile tecnico 7.681, amministratore 3; mai dallo stesso tecnico [D]. |
| AD-33 | Solo chi ha `edit_verifiche` può annullare. Una data di programmazione porta "assegnata" in "programmata". Ogni salvataggio ricalcola scadenze e preventivi. | idem | [C] |
| AD-34 | La stampa del verbale si può fare solo da registrata o effettuata e con `data_pvp`. Il modello Word è configurabile, uno per le GVR e uno per SC/SP. | condizione `print_verifiche`; `gi_verbale_word_get` | [C] |
| AD-35 | Nella stampa del verbale le sezioni non pertinenti alla tipologia si barrano con "///"; i campi conduttore e parametri acqua compaiono solo per i generatori di vapore. | `php_gi_rpt_global_data_verbale_modify` | [C] |
| AD-36 | Il default del regime in maschera non funziona (variabile scritta male) e resta vuoto. Il regime A2 arriva solo dalla generazione. | `gi_regime_verifica_default` | [C]. 95 prime periodiche senza regime, tutte ferme prima della registrazione [D][I]. |

### 3.4 Scadenzario

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| AD-37 | Scadenze per attrezzatura: GVR funzionamento, integrità, visita interna, CND; SC/SP verifica e indagine supplementare. Una scadenza esiste se l'attrezzatura ha la data corrispondente. | `ricalcola_scadenze_attrezzatura` | [D] funz 6.400, integrità 6.779, interna 414, CND 5.167, SC/SP 1.573, supplementare 716. |
| AD-38 | In più, **una scadenza "taratura" per ogni valvola collegata**, non dismessa e di sede attiva, con le date della valvola. | idem | [D] 3.326; 309 senza data. |
| AD-39 | Le ultime date per tipologia vengono dall'ultima verifica effettuata che la comprende. Le date CND e supplementari sono manuali o arrivano da I&C. | idem | [C] |
| AD-40 | La scadenza più vicina eredita il tipo della prossima verifica dell'attrezzatura (V1 o V2); le altre sono V2. | idem | [C] |
| AD-41 | La copertura commerciale funziona come IC-37, ma con riga dello stesso tipo V1/V2 e con tipologia compatibile (una combinata copre ciascuna componente). **CND, supplementari e tarature non hanno mai copertura**: non sono attività di AD. | idem | [D] coperte: funz 751, integrità 295, interna 73, SC/SP 309; 0 per CND, supplementari e tarature. |
| AD-42 | "Crea preventivo" vale solo per funzionamento, integrità, visita interna e SC/SP, se la scadenza non è coperta, l'attrezzatura non è dismessa e **non è esente** (né Sì né ISO17020). | condizione `custom_scadenze_preventivi_crea` | [C] |
| AD-43 | Una riga creata dallo scadenzario ha tipo V1/V2 dalla scadenza, tipologia GVR = tipo di scadenza (righe separate per tipologia) e sconto predefinito del cliente. Il preventivo è uno per cliente e sede per lotto. | `gi_scadenze_preventivi_crea` | [C]. 2.292 lanci [D]. |

### 3.5 Integrazione con iec

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| AD-44 | **Ricezione.** Endpoint POST autenticato con chiave e segreto statici (CORS aperto a tutti), con modalità di prova. Per CND e supplementari scrive le date su attrezzatura e scadenze; per le tarature le scrive sulla valvola. | `iec_sincronizza_scadenze.php` | [C] |
| AD-45 | Le date ricevute **sostituiscono** quelle presenti senza confronto. Le date CND registrate in verifica invece passano solo se successive (AD-29). | idem | [C] |
| AD-46 | **Invio a iec.** La stessa chiamata restituisce tutte le scadenze CND, supplementari e tarature di AD con i relativi clienti e sedi, che iec usa per allineare la propria anagrafica. | idem | [C] |

### 3.6 Export INAIL

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| AD-47 | Si esportano solo verifiche **effettuate, non già esportate e fatturate**: la fattura in PDF è un allegato obbligatorio. | `gi_verifiche_esporta_inail` | [C]. 6.638 effettuate esportate, 1.045 ancora da esportare [D]. |
| AD-48 | **Uscita**: un Excel con il tracciato del portale INAIL (oltre 60 colonne) e tre ZIP (verbali, schede tecniche, fatture), con nomi file secondo lo schema INAIL. | idem | [C] |
| AD-49 | **Controlli prima dell'export**: campi obbligatori (con le varianti per GVR, sospensione, idroestrattori, prime periodiche) e lunghezze massime. Il CF del tecnico è obbligatorio; il CF di AD è scritto nel codice. Se manca la P.IVA del datore si usa il CF, e viceversa. | idem | [C] |
| AD-50 | Il tipo di verifica GVR esportato è il testo di periodicità della tabella dei tipi (per esempio "Verifica funzionamento: biennale"), composto per le combinazioni. | idem | [C] |
| AD-51 | Per riesportare si rimette a "No" il flag di export: è stato fatto in blocco 159 volte. | condizione + modifica multipla | [D] |

### 3.7 Fatturazione

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| AD-52 | Il motore fiscale (IVA, split payment, bollo, ritenuta, rate, XML, nome file, immutabilità) è **identico a ingecert**. Vedi §5 del catalogo ingecert. | confronto dei file | [C] |
| AD-53 | Serie proposta `/AAAA/DM`; in uso anche `/AAAA/EX` (77 fatture) e la variante minuscola `/AAAA/ex` (3). Il significato di EX va chiarito [I]. | `gi_serie_documento_get`; dati | [D] |
| AD-54 | Fatture e note di credito condividono la numerazione di serie: il numero proposto è l'ultimo+1 senza distinguere il tipo. | `gi_nextcode_get` | [D] buchi effettivi: 2026/DM 58, 348, 430; 2026/EX 6, 17, 42, 68; 2025/EX 54. 6 note di credito. |
| AD-55 | Descrizione della riga: "Verifiche attrezzature di lavoro gruppo ‹G›, matr. …, reparto …, rif. interno …, n.f. …, prima verifica periodica / verifica periodica successiva, ‹tipologia GVR›, preventivo …, rif. ordine cliente …". Nessuna riga INAIL o trasferta. | `gi_preventivi_righe_fattura_cliente_genera` | [C] |
| AD-56 | Il registro "fatture" pre-SDI va da giugno 2024 a dicembre 2025, con serie disomogenee: `2024`, `2024/1`, `2024/PA`, `2025`, `2025/EX`, `2025bis`. I collegamenti verifica → fattura sono stati fatti anche a mano in modifica multipla. | dati | [D] |
| AD-57 | Prezzo in fattura = tariffa applicata, salvo modifiche manuali. | idem | [D] 34 righe diverse. |

---

## 4. Processi e azioni da griglia

| Azione | Precondizione | Parametri | Effetto | Uso [D] |
|---|---|---|---|---|
| Crea preventivo | AD-42 | data; preventivo "creato" della stessa sede (facoltativo) | AD-43 | 2.292 |
| Genera verifiche | riga accettata, senza verifica, attrezzatura non dismessa, riesame del preventivo conforme. **Diversamente da ingecert non serve la tariffa presente.** | tecnico | AD-18 | 1.996 |
| Genera fattura (registro) | effettuata, riesame conforme, non fatturata | fattura da integrare | imponibile = righe, IVA 22% | 1.297 (fino a dic. 2025) |
| Genera fattura cliente | come sopra | fattura da integrare | AD-55 | 780 |
| Esporta INAIL | AD-47 | — | AD-48 | 53 |
| Genera XML | come ingecert | — | — | 184 ZIP |
| Import Excel attrezzature / valvole / dati tecnici GVR | amministratore | file `.xlsx` | AD-08 | 581 / 94 / 4 |
| Copia attrezzature e dismetti | amministratore | due sedi | AD-07 | 10 |

**Modifiche multiple nel lavoro quotidiano** [D]:
- 1.149 accettazioni di righe;
- circa 130 riesami di verifiche in blocco;
- 159 riaperture dell'export INAIL;
- circa 80 cambi di sconto o di ricalcolo della tariffa;
- 61 date di programmazione, 25 delle quali insieme alla dichiarazione;
- 13 collegamenti a fatture.

**Cruscotto** [C]:
- scadenze da preventivare nei prossimi 91 giorni (senza escludere le esenti);
- preventivi inviati non ancora accettati;
- pagamenti scaduti da più di 15 giorni;
- verifiche da programmare;
- verifiche da verbalizzare (programmate fino a oggi).

---

## 5. Ruoli e permessi reali

| Ruolo (utenti attivi) | In sostanza [D] |
|---|---|
| Amministratore (2: Garda, account AD) | Tutto, **compreso riesame e modifica di tutti i verbali**. Unico che fattura e genera gli XML. |
| Responsabile tecnico (1) | Riesame, modifica di tutti i verbali, generazione delle verifiche, export INAIL, preventivi; nessuna fatturazione. |
| Tecnico (6, tutti con CF e firma) | Vede solo le proprie verifiche, ma ha `edit_verifiche` e `delete_verifiche`. Può quindi **modificare in qualunque stato e cancellare** le proprie verifiche, superando il limite di stato di `edit_verifiche_proprie`. Gestisce le valvole e le loro associazioni. |
| Referente commerciale (4) | Attrezzature, valvole, preventivi, scadenze dei propri clienti; può registrare il **riesame del contratto** (AD-16). |
| Cliente (14) | Attrezzature, valvole, scadenze e verifiche della propria sede; export. |

Due account tecnici hanno lo stesso cognome (id 4 e 8): da verificare se sono un duplicato [I]. La password iniziale dell'amministratore Garda è scritta nel codice d'installazione, come in ingecert [C].

---

## 6. Uscite

- **Verbale GVR** (`verbale-gvr.docx`, configurato).
  - Dati dell'attrezzatura e della sede; tecnico con nome, cognome e qualifica.
  - Tabella della configurazione con pressioni e temperature di esercizio.
  - Tutti i campi del verbale (§2.2), prossime date, esito.
  - La firma del tecnico viene dal file `utenti.firma`.
- **Verbale SC/SP** (`verbale-sc-sp.docx`): 21 segnaposto.
- **Preventivo DM**: sezioni separate per GVR e SC/SP, sottototali, licenza gestionale facoltativa.
- **Nome file del verbale**: "‹gruppo›_‹numero›-‹anno› - ‹cliente› - ‹matricola informale› - ‹tipo verifica›". La mail va alla sede (`email_ref`).
- **Export INAIL**: Excel e ZIP con i nomi file dello schema INAIL (AD-48).

---

## 7. Anomalie e punti da decidere per il nuovo sistema

| # | Tema | Classe | Proposta |
|---|---|---|---|
| B1 | Dichiarazione di indipendenza non controllata (AD-31). | **Bloccante** (17020) | Stessa regola per tutte le attività, come atto del verificatore con autore e data. |
| B2 | Esito "Positivo" impostato alla generazione (AD-18). | **Bloccante** (17020) | L'esito nasce vuoto e lo registra il tecnico. |
| B3 | Riesame in qualunque stato, senza ritorno a "registrata" e senza azzeramento (AD-32). | Da correggere | Unico ciclo di riesame per DPR e DM. |
| B4 | Riesame del contratto senza permesso dedicato (AD-16). | Da correggere | Permesso di riesame separato dalla modifica del preventivo. |
| B5 | Buchi e contatori su anni errati nella numerazione dei verbali (AD-24). | Da decidere | Numero immutabile dopo l'emissione; niente cancellazioni di verifiche numerate; annullamento tracciato. |
| B6 | Obbligo del PDF saltato in modifica multipla (AD-21). | Da correggere | Stessi controlli per maschera e modifica multipla. |
| B7 | Tecnici con modifica e cancellazione oltre lo stato (§5). | Da correggere | Permessi per stato e ruolo. |
| B8 | Date di I&C sovrascritte senza confronto (AD-45). | Da decidere | Un'unica attività nel nucleo comune: la sincronizzazione sparisce, la regola di prevalenza resta da fissare. |
| B9 | Aggiornamento reciproco attrezzatura ↔ verifica (AD-26, AD-27). | Da decidere | Stessa scelta di VerbalizzAI: stato tecnico con un solo proprietario; la verifica conserva la propria fotografia. |
| B10 | Due registrazioni degli allegati non allineate (§0 punto 10). | Osservazione (migrazione) | Importare dalla tabella dei file, non dalla stringa. |
| B11 | Serie `EX` ed `ex`, buchi nelle fatture, numerazione condivisa con le note di credito. | Da decidere | Serie da tabella; chiarire cosa rappresenta EX. |
| B12 | Valvole su sedi diverse da quelle dell'attrezzatura (9 casi) e valvole non collegate (159). | Osservazione | Regola di coerenza sede; verifica in migrazione. |
| B13 | 117 matricole formali duplicate tra attrezzature non dismesse; 21 date CND con scarti di −90 anni. | Osservazione | Bonifica in migrazione. |
| B14 | Default del regime non funzionante (AD-36). | Osservazione | Regime proposto da tipo e affidamento. |
| B15 | Endpoint con chiavi statiche e CORS aperto; chiavi S3 in chiaro e ACL `public-read`, come in ingecert. | **Bloccante** (sicurezza) | Rotazione delle chiavi; nel nuovo sistema niente endpoint tra moduli dello stesso backend. |
| B16 | Contributo INAIL fissato al 15% e al 5% nel codice; CF di AD scritto nel codice dell'export. | Osservazione | Parametri configurabili per società. |

---

## 8. Cosa non è stato verificato

- Il contenuto dei PDF su S3 e la loro corrispondenza con le verifiche.
- Il tracciato INAIL attualmente in vigore: il codice segue la versione che conosce.
- Il significato operativo di "ISO17020" su `esente_verifiche` e della serie EX.
- Gli import "scraping" dei dati tecnici GVR (origine dei file).
- L'uso reale del portale clienti oltre ai login registrati.
- Il comportamento interno del framework (modifica multipla, generazione Word).

---

## Storico

| Versione | Data | Contenuto |
|---|---|---|
| 1.0 | 9 ottobre 2026 | Prima stesura completa per adsrl: strutture, 57 regole, processi, export INAIL, integrazione iec, permessi reali, uscite, anomalie. |
