# Catalogo Garda — ingecert (AD_dpr): allegato dei campi

**Versione 1.0 · 9 ottobre 2026.** Allegato a `catalogo/ingecert_01_regole_e_strutture.md`. Elenco completo, generato automaticamente, di ogni entità e di ogni campo.

Generato automaticamente dai metadati (`cust/meta/*.js`) e dal dump del 07/10/2026. Colonna *Dati*: record valorizzati / totali; per enum e booleani la distribuzione dei valori.


## `_rp_fatture_clienti` — 

- tipo meta: report
- hook: php_gi_rpt_global_data_modify=`php_gi_rpt_global_data_fatture_clienti_modify`
- altre proprietà: {"label": "Fattura cliente", "category": "fatture_clienti", "meta": [{"name": "fatture_clienti", "alias": "f"}, {"name": "configurazioni", "which_record": "t.id = 1", "alias": "a"}], "page_width": "210", "page_height": "297", "css": {"width": "210mm", "padding": "10mm"}}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `header` | container |  |  | — |  |
| `numero` | container |  |  | — |  |
| `addresses` | container |  |  | — |  |
| `righe` | rows |  |  | — |  |
| `footer` | container |  |  | — |  |
| `paginazione_diciture` | container |  |  | — |  |

## `_rp_preventivo_word` — 

- tipo meta: report
- hook: php_gi_rpt_global_data_modify=`php_gi_rpt_global_data_preventivo_modify`
- altre proprietà: {"label": "Preventivo", "category": "preventivi", "meta": [{"name": "preventivi", "alias": "p"}, {"name": "clienti", "which_record": "t.id = $p.cliente", "alias": "cli"}, {"name": "preventivi_righe", "which_record": "t.preventivo = $p.id", "alias": "r", "type": "rows", "php_gi_rpt_rows_data_modify": "php_gi_rpt_rows_preventivi_righe_modify", "order_by": [{"column": "n_riga", "dir": "asc"}]}], "wo…

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui` — 

- tipo meta: menu
- altre proprietà: {"submenus": ["_ui_admin", "_ui_clienti", "_ui_impianti", "_ui_scadenze", "_ui_preventivi", "_ui_verifiche", "_ui_fatture", "_ui_user"], "show_loginbg": true, "footer_links": [{"name": "privacy", "label": "Privacy", "type": "link", "href": "https://www.ingecert.it/", "target": "_blank"}, {"name": "terms", "label": "Termini", "type": "link", "href": "https://www.ingecert.it/", "target": "_blank"},…

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_admin` — 

- tipo meta: submenu
- altre proprietà: {"label": "Gestione", "icon": "_ui_admin.png", "items": [{"name": "utenti", "label": "Utenti", "type": "page", "icon": "_ui_admin_utenti.png", "widgets": [{"name": "utenti", "type": "grid", "meta": "utenti"}], "required_one": ["show_utenti"]}, {"name": "ruoli", "label": "Ruoli", "type": "page", "icon": "_ui_admin_ruoli.png", "widgets": [{"name": "ruoli", "type": "grid", "meta": "ruoli"}], "requir…

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_clienti` — 

- tipo meta: submenu
- altre proprietà: {"label": "Clienti", "icon": "_ui_clienti.png", "items": [{"name": "pg_clienti", "label": "Clienti", "type": "page", "icon": "_ui_clienti.png", "home_page": true, "home_page_menu_item": true, "widgets": [{"name": "g_clienti", "type": "grid", "meta": "clienti"}]}, {"name": "pg_clienti_sedi_operative", "label": "Sedi operative", "type": "page", "icon": "_ui_clienti_sedi_operative.png", "widgets": […

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_clienti_sedi_operative` — 

- tipo meta: submenu
- altre proprietà: {"label": "Sedi operative", "icon": "_ui_clienti_sedi_operative.png", "items": [{"name": "pg_clienti_sedi_operative", "label": "Sedi operative", "type": "page", "icon": "_ui_clienti_sedi_operative.png", "widgets": [{"name": "g_clienti_sedi_operative", "type": "grid", "meta": "clienti_sedi_operative"}]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_dashboard` — 

- tipo meta: submenu
- altre proprietà: {"label": "Dashboard", "icon": "_ui_dashboard.png", "items": [{"name": "dashboard", "label": "Dashboard", "type": "page", "icon": "_ui_dashboard.png", "home_page": true, "widgets": [{"type": "widget_row", "name": "dashboard_riga1", "widgets": [{"name": "bottone_crea_utente", "type": "button", "required_one": ["gestione_utenti"], "icon": "glyphicon-user", "css_class": "default", "cols": 2, "label"…

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_fatture` — 

- tipo meta: submenu
- altre proprietà: {"label": "Fatture", "icon": "_ui_fatture.png", "items": [{"name": "pg_fatture", "label": "Fatture", "type": "page", "icon": "_ui_fatture.png", "widgets": [{"name": "g_fatture", "type": "grid", "meta": "fatture"}]}, {"name": "pg_fatture_clienti", "type": "page", "label": "Fatture clienti", "icon": "_ui_documenti.png", "widgets": [{"name": "tc_fatture_clienti", "type": "tab_container", "widgets": …

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_impianti` — 

- tipo meta: submenu
- altre proprietà: {"label": "Impianti", "icon": "_ui_impianti.png", "items": [{"name": "pg_impianti", "label": "Impianti", "type": "page", "icon": "_ui_impianti.png", "widgets": [{"name": "g_impianti", "type": "grid", "meta": "impianti"}]}, {"name": "pg_tariffe_terre", "label": "Tariffe terre", "type": "page", "icon": "_ui_tariffe_terre.png", "widgets": [{"name": "g_tariffe_terre", "type": "grid", "meta": "tariffe…

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_preventivi` — 

- tipo meta: submenu
- altre proprietà: {"label": "Preventivi", "icon": "_ui_preventivi.png", "items": [{"name": "pg_preventivi", "label": "Preventivi", "type": "page", "icon": "_ui_preventivi.png", "widgets": [{"type": "tab_container", "name": "tr_preventivi", "widgets": [{"name": "tab_preventivi", "type": "tab", "label": "Preventivi", "widgets": [{"name": "g_preventivi", "type": "grid", "meta": "preventivi"}]}, {"name": "tab_righe", …

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_scadenze` — 

- tipo meta: submenu
- altre proprietà: {"label": "Scadenze", "icon": "_ui_scadenze.png", "items": [{"name": "pg_scadenze", "label": "Scadenze", "type": "page", "icon": "_ui_scadenze.png", "widgets": [{"name": "g_scadenze", "type": "grid", "meta": "scadenze"}]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_user` — 

- tipo meta: submenu
- altre proprietà: {"label": "Utente", "icon": "_ui_user.png", "icon_logout": "_ui_user_esci.png", "items": [{"name": "login", "label": "Login", "type": "page", "visible": false, "widgets": [{"name": "login", "type": "login"}]}, {"name": "profilo", "label": "Profilo Utente", "type": "page", "icon": "_ui_user.png", "widgets": [{"name": "profilo", "type": "form", "meta": "utenti", "which_record": "t.id = #id"}], "req…

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `_ui_verifiche` — 

- tipo meta: submenu
- altre proprietà: {"label": "Verifiche", "icon": "_ui_verifiche.png", "items": [{"name": "pg_verifiche", "label": "Verifiche", "type": "page", "icon": "_ui_verifiche.png", "widgets": [{"name": "g_verifiche", "type": "grid", "meta": "verifiche"}]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `clienti` — Clienti

- tipo meta: table · lettura: `clienti` · decodifica: `clienti_dec` · record: 1910
- hook: php_gi_record_save_before=`gi_clienti_save_before`
- univoci: ['rag_soc']
- ordinamento: {'by': 'rag_soc', 'dir': 'asc'}
- permessi: `show_clienti`; `show_clienti_propri` [cond: t.referente_commerciale=#id]; `edit_clienti`; `new_clienti`; `delete_clienti`
- azioni: show←show_clienti|show_clienti_propri; edit←edit_clienti; new←new_clienti; delete←delete_clienti

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura; visibile se false | int(11) NN | 1910/1910 |
| `rag_soc` | string | Ragione Sociale | obbl.; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 80 | varchar(80) NN | 1909/1910 |
| `indirizzo` | string | Indirizzo | obbl.; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 60 | varchar(60) NN | 1907/1910 |
| `cerca_comune` | reference | Cerca comune | →comuni (setnull); trascina ['cap', 'prov', 'comune', 'regione', 'nazione'] | int(11) | 1804/1910 |
| `comune` | string | Comune | obbl.; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 40 | varchar(40) NN | 1905/1910 |
| `cap` | string | CAP | obbl.; max 5 | varchar(5) NN | 1905/1910 |
| `prov` | string | Provincia | obbl.; max 2 | varchar(2) NN | 1905/1910 |
| `regione` | string | Regione | obbl.; max 21 | varchar(21) NN | 1905/1910 |
| `nazione` | reference | Nazione | →nazioni (restrict) | int(11) | 161/1910 |
| `email` | string | E-mail | check emails; aiuto: Inserire una o più email separate da virgola | varchar(191) | 1563/1910 |
| `pec` | string | PEC | check emails | varchar(191) | 186/1910 |
| `cod_fis` | string | Codice Fiscale | obbl.; check cf bloccante; max 16 | varchar(16) NN | 1752/1910 |
| `p_iva` | string | Partita IVA | obbl.=warning; check piva bloccante; max 30 | varchar(30) | 1727/1910 |
| `referente_commerciale` | reference | Referente commerciale | →utenti (restrict); accesso {"show": ["show_clienti"]} | int(11) | 7/1910 |
| `nome_referente` | string | Nome referente |  | varchar(191) | 76/1910 |
| `email_ref` | string | Email referente | check emails bloccante | varchar(191) | 126/1910 |
| `tel_ref` | string | Tel. referente | check tels | varchar(191) | 25/1910 |
| `sdi_pec` | string | Codice SDI/PEC | valori ["0000000", "XXXXXXX", "M5UXCR1", "USAL8PV", "W7YVJK9", "KRRH6B9", "A4707H7", "T04ZHR3", "X2PH38J", "5RUO82D", "T9K4ZHO", "P62QHVQ", "SUBM70N", "5W4A8J1", "UE2LXTM", "BA6ET11", "JHBM40P", "fe.dylogbuffetti@sicurezzapostale.it"]; aiuto: Codice destinatario o PEC per fattura elettronica.  | varchar(191) | 1460/1910 |
| `rif_amministrazione` | string | Riferimento amministrazione fatt. elett… | regex `/^p{IsBasicLatin}+$/` bloccante; max 20; aiuto: Eventuale riferimento utile al destinatario per automatizzare la gestione amministrativa dell'operazione in fattura | varchar(20) | 2/1910 |
| `istituto_finanziario` | string | Banca cliente | regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 80; aiuto: Serve ad esempio nel caso di nota di credito | varchar(80) | 2/1910 |
| `iban` | string | IBAN banca cliente | check iban bloccante; max 34; aiuto: Serve ad esempio nel caso di nota di credito | varchar(34) | 3/1910 |
| `dich_intento` | boolean | Dichiarazione intento | obbl.; default F | enum('F','T') NN | 1910/1910 · F=1908, T=2 |
| `dich_intento_n` | string | N° dichiarazione intento | max 60; aiuto: Protocollo di ricezione della dichiarazione d'intento e il suo progressivo separato dal segno "-" (es. 08060120341234567-000001) | varchar(60) | 2/1910 |
| `dich_intento_data` | date | Data dichiarazione intento |  | date | 2/1910 |
| `rit_acc_str` | string | Ritenuta d'acconto (aliquota) | valori ["4%", "20%", "23% sul 50%"] | varchar(191) | 52/1910 |
| `note` | string | Note |  | text | 38/1910 |
| `pagamento` | reference | Pagamento | →tipi_pagamento (restrict) | int(11) | 721/1910 |
| `iva` | reference | Aliquota Iva | →iva (restrict) | int(11) | 1827/1910 |
| `last_update_user` | reference | Utente Modifica | sola lettura; →utenti (setdefault) | int(11) | 1910/1910 |
| `last_update_ts` | datetime | Data Modifica | sola lettura | datetime | 1910/1910 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 1910/1910)

## `clienti_sedi_operative` — Sedi operative

- tipo meta: table · lettura: `clienti_sedi_operative_read` · decodifica: `clienti_sedi_operative_dec` · record: 2674
- univoci: ['nome_sede']
- indici: ['cliente']; ['cerca_comune']
- ordinamento: {'by': 'nome_sede', 'dir': 'asc'}
- permessi: `show_clienti_sedi_operative`; `show_clienti_sedi_operative_propri` [cond: t.referente_commerciale=#id]; `show_clienti_sedi_operative_utente_cliente` [cond: t.utente_cliente=#id]; `edit_clienti_sedi_operative`; `new_clienti_sedi_operative`; `delete_clienti_sedi_operative`
- azioni: show←show_clienti_sedi_operative|show_clienti_sedi_operative_propri|show_clienti_sedi_operative_utente_cliente; edit←edit_clienti_sedi_operative; new←new_clienti_sedi_operative; delete←delete_clienti_sedi_operative

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 2674/2674 |
| `cliente` | reference | Cliente | obbl.; →clienti (cascade) | int(11) NN | 2674/2674 |
| `utente_cliente` | reference | Utente del cliente | →utenti (restrict); accesso {"show": ["show_clienti_sedi_operative"]} | int(11) | 0/2674 |
| `referente_commerciale` | reference | Referente commerciale | →utenti (noaction); calcolato in vista; accesso {"show": ["show_clienti_sedi_operative"]} | vista |  |
| `nome_sede` | string | Denominazione sede operativa | obbl. | varchar(191) NN | 2674/2674 |
| `indirizzo` | string | Indirizzo | obbl.; max 60 | varchar(60) NN | 2667/2674 |
| `cerca_comune` | reference | Cerca comune | →comuni (restrict); trascina ['comune', 'cap', 'prov', 'regione'] | int(11) | 2639/2674 |
| `comune` | string | Comune | obbl.; max 40 | varchar(40) NN | 2668/2674 |
| `cap` | string | CAP | obbl.; max 5 | varchar(5) NN | 2668/2674 |
| `prov` | string | Prov. | obbl.; max 2 | varchar(2) NN | 2668/2674 |
| `regione` | string | Regione | obbl.; max 21 | varchar(21) NN | 2668/2674 |
| `nome_referente` | string | Nome referente |  | varchar(191) | 165/2674 |
| `email_ref` | string | Email referente | check emails bloccante | varchar(191) | 153/2674 |
| `tel_ref` | string | Tel. referente | check tels | varchar(191) | 45/2674 |
| `note` | string | Note | accesso {"show": ["show_clienti_sedi_operative"]} | text | 19/2674 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull); accesso {"show": ["show_clienti_sedi_operative"]} | int(11) | 2674/2674 |
| `last_update_ts` | datetime | Data modifica | sola lettura; accesso {"show": ["show_clienti_sedi_operative"]} | datetime | 2674/2674 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 2674/2674)

## `comuni` — Comuni

- tipo meta: table · lettura: `comuni` · decodifica: `comuni_dec` · record: 8463
- hook: php_gi_ddl_table_create_custom=`gi_ddl_table_create_comuni`
- univoci: ['comune', 'cap']
- ordinamento: {'by': 'regione', 'dir': 'asc'}
- permessi: `show_comuni`; `edit_comuni`; `new_comuni`; `copy_comuni`; `delete_comuni`
- azioni: show←show_comuni; edit←edit_comuni; new←new_comuni; copy←copy_comuni; delete←delete_comuni
- altre proprietà: {"blank_on_copy": ["comune"], "list_mobile": [{"field": "regione", "title": "regione", "left": "regione", "subtitle": ["nazione"]}, {"field": "provincia", "title": "provincia", "left": "provincia", "subtitle": ["regione", "nazione"]}, {"field": "id", "title": "comune", "left": "comune", "subtitle": ["regione", "nazione"], "right_top": ["cap"], "right_bottom": ["provincia"]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | ID | sola lettura; visibile se false | int(11) NN | 8463/8463 |
| `comune` | string | Comune | obbl. | varchar(191) NN | 8463/8463 |
| `cap` | string | CAP |  | varchar(191) | 8463/8463 |
| `provincia` | string | Provincia | regex `/^[A-Z-]{0,2}$/` bloccante; aiuto: Per la provincia mettere la sigla (2 lettere maiuscole, EE per stato estero e `-` se non c'è la provincia) | varchar(191) | 8463/8463 |
| `cod_fisco` | string | Codice comune |  | varchar(191) | 8463/8463 |
| `regione` | string | Regione |  | varchar(191) | 8463/8463 |
| `nazione` | reference | Nazione | obbl.; →nazioni (restrict) | int(11) NN | 8463/8463 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault) | int(11) | 8463/8463 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 8463/8463 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 8463/8463)

## `configurazioni` — Configurazioni

- tipo meta: table · lettura: `configurazioni` · decodifica: `configurazioni_dec` · record: 1
- hook: php_gi_ddl_table_create_custom=`gi_ddl_table_create_configurazioni`
- ordinamento: {'by': 'id', 'dir': 'asc'}
- permessi: `show_configurazioni` [cond: 1 = t.id]; `edit_configurazioni` [cond: 1 = t.id]
- azioni: show←show_configurazioni; edit←edit_configurazioni
- altre proprietà: {"list_mobile": [{"field": "id", "title": "id"}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura; visibile se false | int(11) NN | 1/1 |
| `fe_denominazione` | string | Denominazione | obbl.; default ; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 80 | varchar(80) NN | 1/1 |
| `fe_piva` | string | Partita Iva | obbl.; default ; check piva bloccante; max 30 | varchar(30) NN | 1/1 |
| `fe_cf` | string | Codice fiscale | obbl.; default ; check cf bloccante; max 16 | varchar(16) NN | 1/1 |
| `fe_regime_fiscale` | enum | Regime fiscale | obbl.; default RF01; valori {"RF01": "RF01: Ordinario", "RF02": "RF02: Contribuenti minimi (art.1, c.96-117, L. 244/07) ", "RF04": "RF04: Agricoltura e attività connesse e pesca (artt.34 e 34-bis, DPR 633/72) ", "RF05": "RF05: Vendita sali e tabacchi (art.74, c.1, DPR. 633/72) ", "RF06": "RF06: Commercio fiammiferi (art.74, c.1, DPR  633/72) ", "RF07": "RF07: Editoria (art.74, c.1, DPR  633/72)", "RF08": "RF08: Gestione ser… | enum('RF01','RF02','RF04','RF05','RF06','RF07','RF08','RF09','RF10','RF11','RF12','RF13','RF14','RF15','RF16','RF17','RF18','RF19') NN | 1/1 · RF01=1 |
| `fe_rit_acc_tipo` | enum | Tipo ritenuta d'acconto | obbl.; default RT02; valori {"RT01": "RT01 Ritenuta persone fisiche (ditte individuali, società di persone)", "RT02": "RT02 Ritenuta persone giuridiche (società di capitali, enti, cooperative)"} | enum('RT01','RT02') NN | 1/1 · RT02=1 |
| `fe_rit_acc_caus` | enum | Causale ritenuta d'acconto | obbl.; default A; valori {"A": "A – prestazioni di lavoro autonomo rientranti nell'esercizio di arte o professione abituale", "B": "B – utilizzazione economica, da parte dell'autore o dell'inventore, di opere dell'ingegno, di brevetti industriali e di processi, formule o informazioni relativi ad esperienze acquisite in campo industriale, commerciale o scientifico", "C": "C – utili derivanti da contratti di associazione i… | enum('A','B','C','D','E','G','H','I','L','L1','M','M1','M2','N','O','O1','P','Q','R','S','T','U','V','V1','W','X','Y','ZO') NN | 1/1 · A=1 |
| `fe_indirizzo` | string | Indirizzo | obbl.; default ; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 60 | varchar(60) NN | 1/1 |
| `fe_cap` | string | CAP | obbl.; default ; max 5 | varchar(5) NN | 1/1 |
| `fe_comune` | string | Comune | obbl.; default ; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 60 | varchar(60) NN | 1/1 |
| `fe_provincia` | string | Provincia | obbl.; default ; max 2 | varchar(2) NN | 1/1 |
| `fe_rea_ufficio` | string | REA Ufficio | max 2; aiuto: Obbligatorio per società soggette al vincolo dell’iscrizione nel registro delle imprese | varchar(2) | 1/1 |
| `fe_rea_numero` | string | REA Numero | max 20; aiuto: Obbligatorio per società soggette al vincolo dell’iscrizione nel registro delle imprese | varchar(20) | 1/1 |
| `fe_capitale_sociale` | decimal | Capitale sociale | aiuto: Obbligatorio nei soli casi di società di capitali (SpA, SApA, SRL) | decimal(12,2) | 1/1 |
| `fe_socio_unico` | enum | Socio unico | default SM; valori {"SU": "socio unico", "SM": "più soci"}; aiuto: Obbligatorio nei soli casi di SpA e SRL | enum('SU','SM') | 1/1 · SU=1 |
| `fe_stato_liquidazione` | enum | Stato liquidazione | obbl.; default LN; valori {"LS": "in liquidazione", "LN": "non in liquidazione"} | enum('LS','LN') NN | 1/1 · LN=1 |
| `fe_telefono` | string | Telefono | obbl.; default ; regex `/^p{IsBasicLatin}+$/` bloccante; max 12 | varchar(12) NN | 1/1 |
| `fe_email` | string | E-mail | obbl.; default  | varchar(191) NN | 1/1 |
| `fe_fax` | string | Fax |  | varchar(191) | 0/1 |
| `fe_istituto_finanziario` | string | Banca | obbl.; default ; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 80 | varchar(80) NN | 1/1 |
| `fe_iban` | string | IBAN | obbl.; default ; check iban bloccante; max 34 | varchar(34) NN | 1/1 |
| `fe_codice_articolo_tipo` | string | Tipo codifica codici articolo | obbl.; default AswArtFor; regex `/^p{IsBasicLatin}+$/` bloccante; max 35; aiuto: AswArtFor per codifica del fornitore, AswArtCli se si usa la codifica del cliente, AswCodEan se si usa la codifica del codice a barre, oppure la codifica uffic… | varchar(35) NN | 1/1 |
| `fe_sdi_pec` | string | Codice SDI/PEC | valori ["0000000", "XXXXXXX", "M5UXCR1", "USAL8PV", "W7YVJK9", "KRRH6B9", "A4707H7", "T04ZHR3", "X2PH38J", "5RUO82D", "T9K4ZHO", "P62QHVQ", "SUBM70N", "5W4A8J1", "UE2LXTM", "BA6ET11", "JHBM40P", "fe.dylogbuffetti@sicurezzapostale.it"]; aiuto: Usato come recapito per integrazioni e autofatture di acquisto | varchar(191) | 0/1 |
| `fe_cf_trasmittente` | string | Codice fiscale Trasmittente | obbl.; default ; regex `/^p{IsBasicLatin}+$/` bloccante; max 28; aiuto: Es. nel caso di invio con intermediario Aruba PEC S.p.A. mettere 01879020517 | varchar(28) NN | 1/1 |
| `mod_word_prev` | files | Modello Word Preventivo | file server | text | 1/1 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull) | int(11) | 1/1 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 1/1 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 1/1)

## `fatture` — Fatture

- tipo meta: table · lettura: `fatture_read` · decodifica: `fatture_dec` · record: 320
- hook: php_gi_record_save_before=`gi_fatture_save_before`
- univoci: ['serie_fattura', 'numero_fattura']
- indici: ['cliente']
- ordinamento: {'by': 'anno_numero_fattura', 'dir': 'desc'}
- permessi: `show_fatture`; `show_fatture_ref_comm` [cond: t.referente_commerciale=#id]; `edit_fatture`; `new_fatture`; `delete_fatture`; `export_fatture`
- azioni: show←show_fatture|show_fatture_ref_comm; edit←edit_fatture; new←new_fatture; delete←delete_fatture; export←export_fatture

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 320/320 |
| `decodifica` | string | Decodifica | visibile se false; calcolato in vista | vista |  |
| `cliente` | reference | Cliente | obbl.; →clienti (restrict) | int(11) NN | 320/320 |
| `referente_commerciale` | reference | Referente commerciale | →utenti (noaction); calcolato in vista | vista |  |
| `data_fattura` | date | Data fattura | obbl.; default gi_date_default() | date NN | 320/320 |
| `serie_fattura` | string | Serie fattura | obbl.; default gi_year_get($data_fattura); dipende ['data_fattura'] | varchar(191) NN | 320/320 |
| `numero_fattura` | integer | Numero fattura | obbl.; default gi_nextcode_get($id,$serie_fattura); dipende ['serie_fattura'] | int(11) NN | 320/320 |
| `anno_numero_fattura` | string | Anno/Numero | visibile se false; calcolato in vista | vista |  |
| `decodifica` | string | Decodifica | visibile se false; calcolato in vista | vista |  |
| `allegato` | files | Allegato | obbl.=warning; file s3 | text | 320/320 |
| `numero_offerta` | string | Numero offerta |  | varchar(191) | 318/320 |
| `sconto` | string | Sconto |  | varchar(191) | 2/320 |
| `imponibile` | decimal | Imponibile |  | decimal(12,2) | 319/320 |
| `iva` | decimal | IVA | sola lettura | decimal(12,2) | 320/320 |
| `importo_totale` | decimal | Importo totale | sola lettura | decimal(12,2) | 320/320 |
| `scad_data_fattura` | date | Scadenza data fattura |  | date | 311/320 |
| `importo_pagato` | decimal | Importo pagato |  | decimal(12,2) | 292/320 |
| `data_pagamento` | date | Data pagamento |  | date | 295/320 |
| `tecnico_coll` | string | Tecnico/Collaboratore |  | text | 315/320 |
| `verbali_rif_note` | string | Verbali di riferimento/note |  | text | 318/320 |
| `stato_fattura` | enum | Stato fattura | valori {"I": "In pagamento", "S": "Scaduta", "P": "Pagata"} | enum('I','S','P') | 307/320 · P=296, ∅=13, S=10, I=1 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull) | int(11) | 320/320 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 320/320 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 320/320)

## `fatture_clienti` — Fatture clienti

- tipo meta: table · lettura: `fatture_clienti_read` · decodifica: `fatture_clienti_dec` · record: 473
- hook: php_gi_record_save_before=`gi_fatture_clienti_save_before`, php_gi_record_save_after=`gi_fatture_clienti_save_after`, php_gi_record_change_after=`gi_fatture_clienti_change_after`
- univoci: ['serie_fattura', 'tipo_fatt', 'numero_fattura']
- indici: ['tipo_fatt']; ['cliente', 'rif_lav_gen_fatture_clienti']
- ordinamento: {'by': 'anno_numero_fattura', 'dir': 'desc'}
- permessi: `show_fatture_clienti`; `edit_fatture_clienti` [cond: t.generata_fatt_elettronica='F']; `edit_generata_fatt_elettronica_fatture_clienti`; `new_fatture_clienti`; `copy_fatture_clienti`; `delete_fatture_clienti`; `genera_xml_fatture_clienti` [cond: t.generata_fatt_elettronica='F']; `print_fatture_clienti`
- azioni: show←show_fatture_clienti; edit←edit_fatture_clienti|edit_generata_fatt_elettronica_fatture_clienti; new←new_fatture_clienti; copy←copy_fatture_clienti; delete←delete_fatture_clienti; print←; fatture_clienti_genera_xml←genera_xml_fatture_clienti (Genera fatture elettroniche XML)
- altre proprietà: {"blank_on_copy": ["serie_fattura", "numero_fattura", "data_fattura", "generata_fatt_elettronica"], "show_stats": true}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 473/473 |
| `stampa` | files | Stampa | sola lettura; file s3 | text | 473/473 |
| `tipo_fatt` | enum | Tipo fattura | obbl.; default TD01; valori {"TD01": "TD01: fattura", "TD02": "TD02: acconto/anticipo su fattura", "TD03": "TD03: acconto/anticipo su parcella", "TD04": "TD04: nota di credito", "TD05": "TD05: nota di debito", "TD06": "TD06: parcella", "TD16": "TD16: integrazione fattura reverse charge interno", "TD20": "TD20: autofattura per regolarizzazione e integrazione delle fatture (ex art.6 c.8 d.lgs. 471/97  o  art.46 c.5 D.L. 331/9…; accesso {"edit": ["edit_fatture_clienti"]} | enum('TD01','TD02','TD03','TD04','TD05','TD06','TD16','TD20','TD21','TD22','TD23','TD24','TD25','TD26','TD27') NN | 473/473 · TD01=473 |
| `data_fattura` | date | Data fattura | obbl.; default gi_date_default(); accesso {"edit": ["edit_fatture_clienti"]} | date NN | 473/473 |
| `numero_fattura` | integer | Numero fattura | obbl.; default gi_nextcode_get($id,$serie_fattura); dipende ['serie_fattura']; accesso {"edit": ["edit_fatture_clienti"]} | int(11) NN | 473/473 |
| `serie_fattura` | string | Serie fattura | obbl.; default gi_serie_documento_get($data_fattura,$t…; dipende ['data_fattura', 'tipo_fatt'] | varchar(191) NN | 473/473 |
| `anno_numero_fattura` | string | Numero fattura | visibile se false; calcolato in vista | vista |  |
| `decodifica` | string | Numero | visibile se false; calcolato in vista | vista |  |
| `cliente` | reference | Cliente | →clienti (restrict); trascina ['termini_di_pagamento', 'cli_rag_soc', 'cli_indirizzo', 'cli_cerca_comune', 'cli_comune', 'cli_cap', 'cli_prov', 'cli_nazione', 'cli_cod_fis', 'cli_p_iva', 'cli_sdi_pec', 'cli_rif_amministrazione', 'cli_istituto_finanziario', 'cli_iban', 'cli_dich_intento', 'cli_dich_intento_n', 'cli_dich_intento_data', 'rit_acc_str']; accesso {"edit": ["edit_fatture_clienti"]} | int(11) | 473/473 |
| `termini_di_pagamento` | reference | Termini di pagamento | default gi_reference_default_get('predefinito'); →tipi_pagamento (restrict); accesso {"edit": ["edit_fatture_clienti"]} | int(11) | 473/473 |
| `causale_fatt_elettronica` | string | Causale fatt. elettronica | regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 200 | varchar(200) | 0/473 |
| `bollo_virtuale` | boolean | Bollo virtuale | obbl.; default F | enum('F','T') NN | 473/473 · F=472, T=1 |
| `bollo_importo` | decimal | Importo bollo |  | decimal(12,2) | 1/473 |
| `rit_acc_str` | string | Ritenuta d'acconto (aliquota) | valori ["4%", "20%", "23% sul 50%"] | varchar(191) | 43/473 |
| `rit_acc_aliq` | decimal | Ritenuta d'acconto (aliquota) | visibile se false | decimal(12,0) | 43/473 |
| `generata_fatt_elettronica` | boolean | Generata fatt. elettronica | obbl.; default F | enum('F','T') NN | 473/473 · T=473 |
| `lavoro_generazione_xml` | reference | Lavoro generazione XML | sola lettura; →fatture_clienti_genera_xml (restrict) | int(11) | 0/473 |
| `log_generazione_fattura` | string | Log generazione XML fattura | sola lettura | mediumtext | 473/473 |
| `nome_file` | string | Nome file generato | sola lettura | varchar(191) | 473/473 |
| `riepilogo_iva` | inline_grid | Riepilogo IVA | sola lettura | text | 0/473 |
| `totale_netto` | decimal | Totale imponibile | sola lettura | decimal(12,2) | 473/473 |
| `totale_iva` | decimal | Totale IVA | sola lettura | decimal(12,2) | 473/473 |
| `totale_documento` | decimal | Totale documento | sola lettura | decimal(12,2) | 473/473 |
| `iva_non_dovuta` | decimal | IVA non dovuta | sola lettura; default 0 | decimal(12,2) | 473/473 |
| `rit_acc_tot` | decimal | Ritenuta d'acconto | sola lettura | decimal(12,2) | 439/473 |
| `rit_acc_imp` | decimal | Ritenuta d'acconto (imponibile) | sola lettura | decimal(12,2) | 439/473 |
| `totale_dovuto` | decimal | Totale dovuto | sola lettura | decimal(12,2) | 473/473 |
| `totale_netto_r` | decimal | Totale imponibile | visibile se false; calcolato in vista | vista |  |
| `totale_iva_r` | decimal | Totale IVA | visibile se false; calcolato in vista | vista |  |
| `totale_documento_r` | decimal | Totale documento | visibile se false; calcolato in vista | vista |  |
| `iva_non_dovuta_r` | decimal | IVA non dovuta | visibile se false; calcolato in vista | vista |  |
| `totale_dovuto_r` | decimal | Totale dovuto | visibile se false; calcolato in vista | vista |  |
| `rif_lav_gen_fatture_clienti` | reference | Rif. lav. gen. fatture clienti | sola lettura; →lavori_batch (restrict) | int(11) | 471/473 |
| `cli_rag_soc` | string | Ragione Sociale | obbl.; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 80 | varchar(80) NN | 473/473 |
| `cli_indirizzo` | string | Indirizzo | obbl.; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 60 | varchar(60) NN | 473/473 |
| `cli_cerca_comune` | reference | Cerca comune | →comuni (setnull); trascina ['cli_cap', 'cli_prov', 'cli_comune', 'cli_nazione'] | int(11) | 464/473 |
| `cli_comune` | string | Comune | obbl.; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 60 | varchar(60) NN | 473/473 |
| `cli_cap` | string | CAP |  | varchar(191) | 473/473 |
| `cli_prov` | string | Provincia | max 2 | varchar(2) | 473/473 |
| `cli_nazione` | reference | Nazione | →nazioni (restrict) | int(11) | 121/473 |
| `cli_cod_fis` | string | Codice Fiscale | check cf bloccante; max 16 | varchar(16) | 466/473 |
| `cli_p_iva` | string | Partita IVA | check piva bloccante; max 30 | varchar(30) | 422/473 |
| `cli_sdi_pec` | string | Codice SDI/PEC | aiuto: Codice destinatario o PEC per fattura elettronica.  | varchar(191) | 422/473 |
| `cli_rif_amministrazione` | string | Riferimento amministrazione fatt. elett… | regex `/^p{IsBasicLatin}+$/` bloccante; max 20; aiuto: Eventuale riferimento utile al destinatario per automatizzare la gestione amministrativa dell'operazione in fattura | varchar(20) | 4/473 |
| `cli_istituto_finanziario` | string | Banca cliente | regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 80; aiuto: Serve ad esempio nel caso di nota di credito | varchar(80) | 2/473 |
| `cli_iban` | string | IBAN banca cliente | check iban bloccante; max 34; aiuto: Serve ad esempio nel caso di nota di credito | varchar(34) | 2/473 |
| `cli_dich_intento` | boolean | Dichiarazione intento | obbl.; default F | enum('F','T') NN | 473/473 · F=472, T=1 |
| `cli_dich_intento_n` | string | N° dichiarazione intento | max 60; aiuto: Protocollo di ricezione della dichiarazione d’intento e il suo progressivo separato dal segno "-" (es. 08060120341234567-000001) | varchar(60) | 1/473 |
| `cli_dich_intento_data` | date | Data dichiarazione intento |  | date | 1/473 |
| `documento_emesso_in_seguito_a` | inline_grid | Documento emesso in seguito a |  | text | 62/473 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull) | int(11) | 473/473 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 473/473 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 473/473)

## `fatture_clienti_doc_collegati` — Doc. collegati (fattura cliente)

- tipo meta: table · lettura: `fatture_clienti_doc_collegati` · decodifica: `fatture_clienti_doc_collegati_dec` · record: 101
- hook: php_gi_record_change_after=`gi_fatture_clienti_doc_collegati_change_after`
- indici: ['fattura']
- ordinamento: {'by': 'n_documento', 'dir': 'asc'}
- permessi: `show_fatture_clienti_doc_collegati`; `edit_fatture_clienti_doc_collegati`; `new_fatture_clienti_doc_collegati`; `delete_fatture_clienti_doc_collegati`
- azioni: show←show_fatture_clienti_doc_collegati; edit←edit_fatture_clienti_doc_collegati; new←new_fatture_clienti_doc_collegati; delete←delete_fatture_clienti_doc_collegati

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 101/101 |
| `fattura` | reference | Fattura | obbl.; →fatture_clienti (cascade) | int(11) NN | 101/101 |
| `tipo_documento` | enum | Tipo doc. | obbl.; valori {"OrdineAcquisto": "Ordine d'acquisto", "Contratto": "Contratto", "Convenzione": "Convenzione", "Ricezione": "Ricezione", "FattureCollegate": "Fattura collegata", "DDT": "Doc. di trasporto", "FatturaPrincipale": "Fattura principale"} | enum('OrdineAcquisto','Contratto','Convenzione','Ricezione','FattureCollegate','DDT','FatturaPrincipale') NN | 101/101 · OrdineAcquisto=84, Contratto=17 |
| `n_documento` | string | N° | obbl.; regex `/^p{IsBasicLatin}+$/` bloccante; max 20 | varchar(20) NN | 101/101 |
| `data_documento` | date | Data | obbl. | date NN | 101/101 |
| `cig` | string | CIG | regex `/^p{IsBasicLatin}+$/` bloccante; max 15 | varchar(15) | 36/101 |
| `cup` | string | CUP | regex `/^p{IsBasicLatin}+$/` bloccante; max 15 | varchar(15) | 0/101 |
| `commessa_convenzione` | string | Commessa / Convenzione | regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 100 | varchar(100) | 5/101 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull); visibile se false | int(11) | 101/101 |
| `last_update_ts` | datetime | Data modifica | sola lettura; visibile se false | datetime | 101/101 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 101/101)

## `fatture_clienti_genera_xml` — Lavori generazione XML fatture clienti

- tipo meta: table · lettura: `fatture_clienti_genera_xml` · decodifica: `fatture_clienti_genera_xml_dec` · record: 178
- ordinamento: {'by': 'inizio', 'dir': 'desc'}
- permessi: `gestione_fatture_clienti_genera_xml`
- azioni: show←gestione_fatture_clienti_genera_xml; new←gestione_fatture_clienti_genera_xml; start←gestione_fatture_clienti_genera_xml

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura | int(11) NN | 178/178 |
| `utente` | reference | Utente | obbl.; sola lettura; default #id; →utenti (restrict); accesso {"show": ["gestione_fatture_clienti_genera_xml"]} | int(11) NN | 178/178 |
| `files` | files | Files | sola lettura; file server | text | 177/178 |
| `inizio` | datetime | Inizio | sola lettura; default gi_date_default() | datetime | 178/178 |
| `fine` | datetime | Fine | sola lettura | datetime | 178/178 |
| `execution_type` | enum | Tipo Esecuzione | obbl.; sola lettura; default B; valori {"I": "Immediata", "B": "Batch"} | enum('I','B') NN | 178/178 · B=178 |
| `stato` | enum | Stato | sola lettura; valori {"A": "In elaborazione", "TS": "Terminato con successo", "TW": "Terminato con warning", "TE": "Terminato con errore"} | enum('A','TS','TW','TE') | 178/178 · TS=177, TE=1 |
| `num_righe_proc` | integer | N° righe | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 178/178 |
| `num_righe_succ` | integer | Successo | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 178/178 |
| `num_righe_err` | integer | Errore | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 178/178 |
| `which_items` | enum | Voci | obbl.; valori {"selected": "Selezionate con spunta", "all": "Tutte (filtrate)"} | enum('selected','all') NN | 178/178 · selected=173, all=5 |
| `json` | custom | Json | obbl.; visibile se false | mediumtext NN | 178/178 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault) | int(11) | 178/178 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 178/178 |
| `progress` | integer | Progresso | sola lettura; default 0 | int(11) | 178/178 |
| `log` | log | Messaggi | sola lettura | — |  |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 178/178)

## `fatture_clienti_iva` — Riepilogo IVA (fattura cliente)

- tipo meta: table · lettura: `fatture_clienti_iva` · decodifica: `fatture_clienti_iva_dec` · record: 473
- univoci: ['fattura', 'codice_iva']
- ordinamento: {'by': 'iva', 'dir': 'desc'}
- permessi: `show_fatture_clienti_iva`
- azioni: show←show_fatture_clienti_iva

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 473/473 |
| `fattura` | reference | Fattura | obbl.; →fatture_clienti (cascade) | int(11) NN | 473/473 |
| `codice_iva` | reference | Codice IVA | obbl.; →iva (restrict) | int(11) NN | 473/473 |
| `imponibile` | decimal | Imponibile | obbl.; default 0 | decimal(12,2) NN | 473/473 |
| `iva` | decimal | IVA | obbl.; default 0 | decimal(12,2) NN | 473/473 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull); visibile se false | int(11) | 473/473 |
| `last_update_ts` | datetime | Data modifica | sola lettura; visibile se false | datetime | 473/473 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 473/473)

## `fatture_clienti_righe` — Righe (fattura cliente)

- tipo meta: table · lettura: `fatture_clienti_righe_read` · decodifica: `fatture_clienti_righe_dec` · record: 1123
- hook: php_gi_record_save_before=`gi_fatture_clienti_righe_save_before`, php_gi_record_change_after=`gi_fatture_clienti_righe_change_after`, js_gi_form_create_and_show_after=`js_gi_form_create_and_show_fatture_clienti_righe_after`, js_gi_form_create_and_show_form_fields_set_after=`js_gi_form_create_and_show_fatture_clienti_righe_after`
- univoci: ['fattura', 'n_riga']
- indici: ['fattura']; ['codice_iva']
- ordinamento: {'by': 'n_riga', 'dir': 'asc'}
- permessi: `show_fatture_clienti_righe`; `edit_fatture_clienti_righe`; `new_fatture_clienti_righe`; `delete_fatture_clienti_righe`
- azioni: show←show_fatture_clienti_righe; edit←edit_fatture_clienti_righe; new←new_fatture_clienti_righe; delete←delete_fatture_clienti_righe
- altre proprietà: {"show_stats": true}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 1123/1123 |
| `fattura` | reference | Fattura | obbl.; →fatture_clienti (cascade); trascina ['codice_iva'] | int(11) NN | 1123/1123 |
| `n_riga` | integer | N° riga | obbl.; default gi_nextcode_get($id,$fattura) | int(11) NN | 1123/1123 |
| `tipo_riga` | enum | Tipo riga | obbl.; default RG; valori {"RG": "Normale", "TX": "Nota libera", "AC": "Spesa accessoria"} | enum('RG','TX','AC') NN | 1123/1123 · RG=1123 |
| `codice_articolo` | string | Cod. Articolo | regex `/^p{IsBasicLatin}+$/` bloccante; max 35 | varchar(35) | 0/1123 |
| `descrizione` | string | Descrizione | obbl.; regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante | text NN | 1123/1123 |
| `quantita` | decimal | Quantità | obbl.; default 1 | decimal(12,2) NN | 1123/1123 |
| `unita_misura` | string | UM | valori ["nr", "kg", "lt", "mt", "ore", "pz"]; regex `/^p{IsBasicLatin}+$/` bloccante; max 10 | varchar(10) | 0/1123 |
| `prezzo_unitario` | decimal | Prezzo | obbl.; default 0 | decimal(12,2) NN | 1123/1123 |
| `totale_netto` | decimal | Totale netto | sola lettura | decimal(12,2) | 1123/1123 |
| `codice_iva` | reference | Cod. IVA | obbl.; default gi_reference_default_get('predefinito'); →iva (restrict) | int(11) NN | 1123/1123 |
| `rit_acc_flag` | boolean | Ritenuta d'acconto | default fw_documenti_righe_rit_acc_flag("fattur… | enum('F','T') NN | 1123/1123 · F=1044, T=79 |
| `preventivo` | reference | Preventivo | sola lettura; →preventivi (restrict) | int(11) | 1114/1123 |
| `verifica` | reference | Verifica | sola lettura; →verifiche (restrict) | int(11) | 1114/1123 |
| `tecnico` | reference | Tecnico | sola lettura; →utenti (restrict) | int(11) | 1114/1123 |
| `tecnico_aff` | reference | Tecnico in affiancamento | sola lettura; →utenti (restrict) | int(11) | 0/1123 |
| `codice_verifica` | string | Verbale | sola lettura | varchar(191) | 1114/1123 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull) | int(11) | 1123/1123 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 1123/1123 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 1123/1123)

## `gi_exports` — Esportazioni

- tipo meta: table · lettura: `gi_exports_batch` · decodifica: `gi_exports_dec` · record: 26
- ordinamento: {'by': 'id', 'dir': 'desc'}
- permessi: `gestione_esportazioni`; `gestione_esportazioni_proprie` [cond: #id = t.utente]
- azioni: show←gestione_esportazioni|gestione_esportazioni_proprie; new←gestione_esportazioni|gestione_esportazioni_proprie; start←gestione_esportazioni|gestione_esportazioni_proprie
- altre proprietà: {"list_mobile": [{"field": "id", "left": "stato", "title": "meta_name", "subtitle": ["utente"], "right_top": ["progress"], "right_bottom": ["fine"]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura | int(11) NN | 26/26 |
| `utente` | reference | Utente | obbl.; sola lettura; default #id; →utenti (restrict); accesso {"show": ["gestione_esportazioni"]} | int(11) NN | 26/26 |
| `files` | files | Files | sola lettura; file s3 | text | 26/26 |
| `files_link` | custom | Files | sola lettura; visibile se false | mediumtext | 26/26 |
| `inizio` | datetime | Inizio | sola lettura; default gi_date_default() | datetime | 26/26 |
| `fine` | datetime | Fine | sola lettura | datetime | 26/26 |
| `execution_type` | enum | Tipo Esecuzione | obbl.; valori {"I": "Immediata", "B": "Batch"} | enum('I','B') NN | 26/26 · I=17, B=9 |
| `stato` | enum | Stato | sola lettura; valori {"A": "In elaborazione", "TS": "Terminato con successo", "TW": "Terminato con warning", "TE": "Terminato con errore"} | enum('A','TS','TW','TE') | 26/26 · TS=26 |
| `num_righe_proc` | integer | N° righe | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 26/26 |
| `num_righe_succ` | integer | Successo | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 26/26 |
| `num_righe_err` | integer | Errore | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 26/26 |
| `meta_name` | string | Anagrafica | obbl. | varchar(191) NN | 26/26 |
| `export_format` | enum | Formato | obbl.; valori {"csv": "CSV (Più veloce e Compatibile)", "xls": "XLS (Excel 95 in poi)", "xlsx": "XLSX (Excel 2007 in poi)", "ods": "ODS (Libre/OpenOffice Calc)"} | enum('csv','xls','xlsx','ods') NN | 26/26 · xlsx=26 |
| `incude_attachments` | boolean | Includi allegati? | obbl.; default F | enum('F','T') NN | 26/26 · F=26 |
| `which_items` | enum | Voci | obbl.; valori {"selected": "Selezionate con spunta", "all": "Tutte (filtrate)"} | enum('selected','all') NN | 26/26 · all=25, selected=1 |
| `json` | custom | Json | obbl.; visibile se false | mediumtext NN | 26/26 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault) | int(11) | 26/26 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 26/26 |
| `progress` | integer | Progresso | sola lettura; default 0 | int(11) | 26/26 |
| `log` | log | Messaggi | sola lettura | — |  |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 26/26)

## `gi_i18n` — 

- tipo meta: i18n
- altre proprietà: {"locales": [{"name": "it", "lc_messages": "it_IT", "tinymce_language": "it", "datetimepicker_language": "it", "label": "Ita (IT)", "timezone": "Europe/Rome", "date_format": "d/m/Y", "time_format": "H:i:s", "date_mask": "__/__/____", "time_mask": "__:__:__", "csv_delimiter": ";", "csv_enclosure": "\"", "decimal": ","}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `gi_imports` — Importazioni

- tipo meta: table · lettura: `gi_imports` · decodifica: `gi_imports_dec`
- ordinamento: {'by': 'id', 'dir': 'desc'}
- permessi: `gestione_importazioni`; `gestione_importazioni_proprie` [cond: #id = t.utente]
- azioni: show←gestione_importazioni|gestione_importazioni_proprie; new←gestione_importazioni|gestione_importazioni_proprie; start←gestione_importazioni|gestione_importazioni_proprie
- altre proprietà: {"list_mobile": [{"field": "id", "left": "stato", "title": "meta_name", "subtitle": ["utente"], "right_top": ["progress"], "right_bottom": ["fine"]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura | — |  |
| `utente` | reference | Utente | obbl.; sola lettura; default #id; →utenti (restrict); accesso {"show": ["gestione_importazioni"]} | — |  |
| `file_to_process` | files | Upload | obbl.; file s3 | — |  |
| `inizio` | datetime | Inizio | sola lettura; default gi_date_default() | — |  |
| `fine` | datetime | Fine | sola lettura | — |  |
| `stato` | enum | Stato | sola lettura; valori {"A": "In elaborazione", "TS": "Terminato con successo", "TW": "Terminato con warning", "TE": "Terminato con errore"} | — |  |
| `num_righe_proc` | integer | N° righe | obbl.; sola lettura; default 0; visibile se false | — |  |
| `num_righe_succ` | integer | Successo | obbl.; sola lettura; default 0; visibile se false | — |  |
| `num_righe_err` | integer | Errore | obbl.; sola lettura; default 0; visibile se false | — |  |
| `meta_name` | string | Anagrafica | obbl. | — |  |
| `json` | custom | Json | obbl. | — |  |
| `last_update_user` | reference | Utente Modifica | sola lettura; →utenti (setdefault) | — |  |
| `last_update_ts` | datetime | Data Modifica | sola lettura | — |  |
| `progress` | integer | Progresso | sola lettura; default 0 | — |  |
| `log` | log | Messaggi | sola lettura | — |  |

## `gi_mails` — E-mail

- tipo meta: table · lettura: `gi_mails_read` · decodifica: `gi_mails_dec` · record: 444
- ordinamento: {'by': 'inizio', 'dir': 'desc'}
- permessi: `gestione_mails`; `gestione_mails_proprie` [cond: #id = t.utente]
- azioni: show←gestione_mails|gestione_mails_proprie; new←gestione_mails|gestione_mails_proprie; start←gestione_mails|gestione_mails_proprie
- altre proprietà: {"list_mobile": [{"field": "id", "left": "stato", "title": "meta_name", "subtitle": ["emails_to", "email_subject", "utente"], "right_top": ["progress"], "right_bottom": ["fine"]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura; visibile se false | int(11) NN | 444/444 |
| `utente` | reference | Utente | obbl.; default #id; →utenti (restrict); accesso {"show": ["gestione_mails"]} | int(11) NN | 444/444 |
| `email_cfg` | string | email_cfg | sola lettura; visibile se false | text | 444/444 |
| `emails_to` | tags | A | check emails bloccante | text | 444/444 |
| `emails_cc` | tags | Cc | check emails bloccante | text | 444/444 |
| `emails_bcc` | tags | Ccn | check emails bloccante | text | 444/444 |
| `emails_reply_to` | string | emails_reply_to | sola lettura; visibile se false | varchar(191) | 0/444 |
| `email_subject` | string | Oggetto |  | varchar(191) | 444/444 |
| `email_body` | string | Corpo | visibile se false | text | 444/444 |
| `email_body_read` | string | Corpo | calcolato in vista | vista |  |
| `email_altbody` | string | email_altbody | sola lettura; visibile se false | text | 0/444 |
| `email_is_html` | boolean | email_is_html | sola lettura; visibile se false | enum('F','T') NN | 444/444 · T=444 |
| `email_body_basedir` | string | email_body_basedir | sola lettura; visibile se false | varchar(191) | 0/444 |
| `email_custom_headers` | string | email_custom_headers | sola lettura; visibile se false | text | 444/444 |
| `allegati` | files | Allegati | file server | text | 444/444 |
| `email_attachments` | custom | Files | sola lettura; visibile se false | mediumtext | 444/444 |
| `inizio` | datetime | Inizio invio | sola lettura; default gi_date_default() | datetime | 444/444 |
| `fine` | datetime | Fine invio | sola lettura | datetime | 444/444 |
| `stato` | enum | Stato | sola lettura; valori {"A": "In invio", "TS": "Inviata con successo", "TW": "Inviata con warning", "TE": "Errore durante l'invio"} | enum('A','TS','TW','TE') | 444/444 · TS=444 |
| `progress` | integer | Progresso | sola lettura; default 0 | int(11) | 444/444 |
| `log` | log | Messaggi | sola lettura | — |  |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault) | int(11) | 444/444 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 444/444 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 444/444)

## `gi_multiedits` — Modifiche multiple

- tipo meta: table · lettura: `gi_multiedits` · decodifica: `gi_multiedits_dec` · record: 199
- ordinamento: {'by': 'id', 'dir': 'desc'}
- permessi: `gestione_modifiche_multiple`; `gestione_modifiche_multiple_proprie` [cond: #id = t.utente]
- azioni: show←gestione_modifiche_multiple|gestione_modifiche_multiple_proprie; new←gestione_modifiche_multiple|gestione_modifiche_multiple_proprie; start←gestione_modifiche_multiple|gestione_modifiche_multiple_proprie
- altre proprietà: {"list_mobile": [{"field": "id", "left": "stato", "title": "meta_name", "subtitle": ["utente"], "right_top": ["progress"], "right_bottom": ["fine"]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura; visibile se false | int(11) NN | 199/199 |
| `utente` | reference | Utente | obbl.; sola lettura; default #id; →utenti (restrict); accesso {"show": ["gestione_modifiche_multiple"]} | int(11) NN | 199/199 |
| `inizio` | datetime | Inizio | sola lettura; default gi_date_default() | datetime | 199/199 |
| `fine` | datetime | Fine | sola lettura | datetime | 199/199 |
| `stato` | enum | Stato | sola lettura; valori {"A": "In elaborazione", "TS": "Terminato con successo", "TW": "Terminato con warning", "TE": "Terminato con errore"} | enum('A','TS','TW','TE') | 199/199 · TS=195, TW=3, TE=1 |
| `num_righe_proc` | integer | N° righe | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 199/199 |
| `num_righe_succ` | integer | Successo | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 199/199 |
| `num_righe_err` | integer | Errore | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 199/199 |
| `meta_name` | string | Anagrafica | obbl. | varchar(191) NN | 199/199 |
| `json` | custom | Json | obbl. | mediumtext NN | 199/199 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault) | int(11) | 199/199 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 199/199 |
| `progress` | integer | Progresso | sola lettura; default 0 | int(11) | 199/199 |
| `log` | log | Messaggi | sola lettura | — |  |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 199/199)

## `gi_reports` — Stampe

- tipo meta: table · lettura: `gi_reports_batch` · decodifica: `gi_reports_dec` · record: 1792
- ordinamento: {'by': 'id', 'dir': 'desc'}
- permessi: `gestione_stampe`; `gestione_stampe_proprie` [cond: #id = t.utente]
- azioni: show←gestione_stampe|gestione_stampe_proprie; new←gestione_stampe|gestione_stampe_proprie; start←gestione_stampe|gestione_stampe_proprie
- altre proprietà: {"list_mobile": [{"field": "id", "left": "stato", "title": "meta_name", "subtitle": ["utente"], "right_top": ["progress"], "right_bottom": ["fine"]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura | int(11) NN | 1792/1792 |
| `utente` | reference | Utente | obbl.; sola lettura; default #id; →utenti (restrict); accesso {"show": ["gestione_stampe"]} | int(11) NN | 1792/1792 |
| `files` | files | Files | sola lettura; file s3 | text | 1789/1792 |
| `files_data` | custom | Files | sola lettura; visibile se false | mediumtext | 1789/1792 |
| `inizio` | datetime | Inizio | sola lettura; default gi_date_default() | datetime | 1792/1792 |
| `fine` | datetime | Fine | sola lettura | datetime | 1792/1792 |
| `execution_type` | enum | Tipo esecuzione | obbl.; valori {"I": "Immediata", "B": "Batch"} | enum('I','B') NN | 1792/1792 · I=1792 |
| `stato` | enum | Stato | sola lettura; valori {"A": "In stampa", "TS": "Terminata con successo", "TW": "Terminata con warning", "TE": "Terminata con errore"} | enum('A','TS','TW','TE') | 1792/1792 · TS=1789, TE=3 |
| `num_righe_proc` | integer | N° righe | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 1792/1792 |
| `num_righe_succ` | integer | Successo | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 1792/1792 |
| `num_righe_err` | integer | Errore | obbl.; sola lettura; default 0; visibile se false | int(11) NN | 1792/1792 |
| `meta_name` | string | Anagrafica | obbl. | varchar(191) NN | 1792/1792 |
| `template_meta_name` | string | Modello Stampa | obbl. | varchar(191) NN | 1792/1792 |
| `which_items` | enum | Voci | obbl.; valori {"selected": "Selezionate con spunta", "all": "Tutte (filtrate)"} | enum('selected','all') NN | 1792/1792 · selected=1790, all=2 |
| `json` | custom | Json | obbl.; visibile se false | mediumtext NN | 1792/1792 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault) | int(11) | 1792/1792 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 1792/1792 |
| `progress` | integer | Progresso | sola lettura; default 0 | int(11) | 1792/1792 |
| `log` | log | Messaggi | sola lettura | — |  |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 1792/1792)

## `gi_user_settings` — Impostazioni utenti

- tipo meta: table · lettura: `gi_user_settings` · record: 75
- univoci: ['utente', 'session_key', 'entity']
- ordinamento: {'by': 'id', 'dir': 'desc'}
- altre proprietà: {"show_stats": false}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | obbl.; sola lettura; visibile se false | int(11) NN | 75/75 |
| `utente` | reference | Utente | obbl.; →utenti (cascade) | int(11) NN | 75/75 |
| `session_key` | string | Chiave Sessione | obbl. | varchar(191) NN | 75/75 |
| `entity` | string | Entità | obbl. | varchar(191) NN | 75/75 |
| `json` | custom | Json |  | mediumtext | 75/75 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 75/75)

## `impianti` — Impianti

- tipo meta: table · lettura: `impianti_read` · decodifica: `impianti_dec` · record: 2694
- hook: php_gi_record_change_after=`gi_impianti_change_after`
- univoci: ['sede_operativa', 'tipo_impianto']
- ordinamento: {'by': 'id', 'dir': 'desc'}
- permessi: `show_impianti`; `show_impianti_ref_comm` [cond: t.referente_commerciale=#id]; `show_impianti_utente_cliente` [cond: t.utente_cliente=#id]; `show_impianti_proprie` [cond: EXISTS (SELECT 1 FROM verifiche WHERE verifiche.impianto=t.id AND verifiche.tecnico=#id LIMIT 1)]; `edit_impianti`; `new_impianti`; `delete_impianti`; `export_impianti`
- azioni: show←show_impianti|show_impianti_proprie|show_impianti_ref_comm|show_impianti_utente_cliente; edit←edit_impianti; new←new_impianti; delete←delete_impianti; export←export_impianti

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura | int(11) NN | 2694/2694 |
| `sede_operativa` | reference | Sede operativa | obbl.; →clienti_sedi_operative (restrict); trascina ['cliente'] | int(11) NN | 2694/2694 |
| `tipo_impianto` | enum | Tipologia impianto | obbl.; valori {"area 1": "scariche atmosferiche", "area 2": "messa a terra < 1.000 V", "area 3": "messa a terra > 1.000 V", "area 4": "pericolo di esplosione"} | enum('area NN | 2694/2694 · area 2=2370, area 3=289, area 1=19, area 4=16 |
| `cliente` | reference | Cliente | obbl.; →clienti (restrict); calcolato in vista | vista |  |
| `utente_cliente` | reference | Utente del cliente | →utenti (noaction); calcolato in vista; accesso {"show": ["show_impianti"]} | vista |  |
| `referente_commerciale` | reference | Referente commerciale | →utenti (noaction); calcolato in vista; accesso {"show": ["show_impianti"]} | vista |  |
| `anno_matricola` | string | Anno matr. | regex `/^[0-9]{4}$/` bloccante; max 4 | varchar(4) | 111/2694 |
| `cod_att_matricola` | string | Cod. attività | regex `/^[a-zA-Z0-9]{1}$/` bloccante; max 1 | varchar(1) | 110/2694 |
| `num_matricola` | string | Num. matr. | regex `/^[0-9]{5}$/` bloccante; max 5 | varchar(5) | 109/2694 |
| `prov_immatr` | string | Prov. immatr. | regex `/^[a-zA-Z]{2}$/` bloccante; max 2 | varchar(2) | 110/2694 |
| `dismessa` | boolean | Dismesso | obbl.; default F | enum('F','T') NN | 2694/2694 · F=2684, T=10 |
| `den_impianto` | string | Denominazione impianto |  | varchar(191) | 531/2694 |
| `pot_impianto` | decimal | Potenza impianto | visibile se ($tipo_impianto=="area 2" \|\| $tipo_impianto=="area 3") | decimal(12,2) | 2654/2694 |
| `n_cab_trasf_mt_bt` | integer | N. di cabine di trasformazione MT/BT | visibile se ($tipo_impianto=="area 2" \|\| $tipo_impianto=="area 3") | int(11) | 1077/2694 |
| `n_sott_at_mt` | integer | N. di sottostazioni AT/MT | visibile se ($tipo_impianto=="area 2" \|\| $tipo_impianto=="area 3") | int(11) | 1005/2694 |
| `codice_pod` | string | Codice POD | visibile se ($tipo_impianto=="area 2" \|\| $tipo_impianto=="area 3") | varchar(191) | 1067/2694 |
| `par_ad_asta` | boolean | Parafulmine ad asta | visibile se ($tipo_impianto=="area 1") | enum('F','T') NN | 2694/2694 · F=2694 |
| `num_par_ad_asta` | integer | Numero parafulmini ad asta | visibile se ($tipo_impianto=="area 1" && $par_ad_asta=="T") | int(11) | 0/2694 |
| `par_gabbia` | enum | Parafulmine a gabbia | valori {"no": "No", "si100": "Sì, superficie fino a 100 mq", "si350": "Sì, superfici protette da 101 a 350 mq", "sioltre350": "Sì, superfici protette oltre 350 mq"}; visibile se ($tipo_impianto=="area 1") | enum('no','si100','si350','sioltre350') | 19/2694 · ∅=2675, sioltre350=17, si350=1, si100=1 |
| `zona_0` | boolean | Zona 0 | visibile se ($tipo_impianto=="area 4") | enum('F','T') NN | 2694/2694 · F=2690, T=4 |
| `zona_1` | boolean | Zona 1 | visibile se ($tipo_impianto=="area 4") | enum('F','T') NN | 2694/2694 · F=2683, T=11 |
| `zona_2` | boolean | Zona 2 | visibile se ($tipo_impianto=="area 4") | enum('F','T') NN | 2694/2694 · F=2682, T=12 |
| `zona_20` | boolean | Zona 20 | visibile se ($tipo_impianto=="area 4") | enum('F','T') NN | 2694/2694 · F=2690, T=4 |
| `zona_21` | boolean | Zona 21 | visibile se ($tipo_impianto=="area 4") | enum('F','T') NN | 2694/2694 · F=2688, T=6 |
| `zona_22` | boolean | Zona 22 | visibile se ($tipo_impianto=="area 4") | enum('F','T') NN | 2694/2694 · F=2686, T=8 |
| `class_zone` | string | Classificazione zone | visibile se false; calcolato in vista | vista |  |
| `periodicita_verifiche` | integer | Periodicità verifiche |  | int(11) | 2659/2694 |
| `ultima_verifica` | reference | Ultima verif. | sola lettura; →verifiche (restrict) | int(11) | 1258/2694 |
| `data_ult_verifica` | date | Ultima verifica | sola lettura se $ultima_verifica!=null && $ultima_verifica!="" | date | 1324/2694 |
| `data_prox_verifica` | date | Prossima verifica | sola lettura se $ultima_verifica!=null && $ultima_verifica!="" | date | 2681/2694 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull); accesso {"show": ["show_impianti"]} | int(11) | 2694/2694 |
| `last_update_ts` | datetime | Data modifica | sola lettura; accesso {"show": ["show_impianti"]} | datetime | 1874/2694 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 2694/2694)

## `iva` — Aliquote IVA

- tipo meta: table · lettura: `iva` · decodifica: `iva_dec` · record: 32
- hook: php_gi_ddl_table_create_custom=`gi_ddl_table_create_iva`, php_gi_record_change_after=`php_gi_predefinito_change_after`
- univoci: ['codice']
- ordinamento: {'by': 'codice', 'dir': 'asc'}
- permessi: `show_iva`; `edit_iva`; `new_iva`; `delete_iva`
- azioni: show←show_iva; edit←edit_iva; new←new_iva; delete←delete_iva

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | ID | sola lettura; visibile se false | int(11) NN | 32/32 |
| `predefinito` | boolean | Predefinito | obbl.; default F | enum('F','T') NN | 32/32 · F=31, T=1 |
| `codice` | string | Codice Iva | obbl. | varchar(191) NN | 32/32 |
| `perc_iva` | decimal | Imposta | obbl.; default 0 | decimal(12,2) NN | 32/32 |
| `perc_iva_indetr` | decimal | Indetr. | obbl.; default 0 | decimal(12,2) NN | 32/32 |
| `classe_iva` | enum | Classe Iva | obbl.; default Imponibile; valori {"Imponibile": "Imponibile", "N1": "N1:  Escluso art. 15", "N2.1": "N2.1:  Non soggetto art. 7-7septis", "N2.2": "N2.2:  Non soggetto (altri casi) / Escluso / Fuori campo", "N2.2to": "N2.2:  Non soggetto (ma riportato nel \"Tot. operazioni\" in Liq. Iva)", "N3.1": "N3.1:  Non imponibile (esportazioni)", "N3.2": "N3.2:  Non imponibile (cessioni UE)", "N3.3": "N3.3:  Non imponibile (cessioni San Ma… | enum('Imponibile','N1','N2.1','N2.2','N2.2to','N3.1','N3.2','N3.3','N3.4','N3.5','N3.6','N4','N5','N6.1','N6.2','N6.3','N6.4','N6.5','N6.6','N6.7','N6.8','N6.9','N7','SplitPayment') NN | 32/32 · Imponibile=7, SplitPayment=4, N4=3, N2.2=3, N3.1=2, N2.1=2, N6.7=1, N6.6=1 |
| `descrizione` | string | Descrizione |  | varchar(191) | 32/32 |
| `note` | string | Note uso interno |  | text | 24/32 |
| `last_update_user` | reference | Utente Modifica | sola lettura; →utenti (setdefault) | int(11) | 0/32 |
| `last_update_ts` | datetime | Data Modifica | sola lettura | datetime | 0/32 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 32/32)

## `lavori_batch` — Lavori batch

- tipo meta: table · lettura: `lavori_batch` · decodifica: `lavori_batch_dec` · record: 2848
- hook: php_gi_record_save_before=`gi_lavori_batch_save_before`, js_gi_form_create_and_show_after=`js_gi_form_create_and_show_lavori_batch_after`, js_gi_form_create_and_show_form_fields_set_after=`js_gi_form_create_and_show_lavori_batch_after`
- ordinamento: {'by': 'id', 'dir': 'desc'}
- permessi: `show_lavori_batch`; `show_lavori_batch_propri` [cond: t.utente = #id]; `new_lavori_batch`; `delete_lavori_batch` [cond: t.stato <> 'A']; `start_lavori_batch`
- azioni: show←show_lavori_batch|show_lavori_batch_propri; new←new_lavori_batch; delete←delete_lavori_batch; start←start_lavori_batch

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `procedura` | enum | Procedura | obbl.; default Migrazione Excel Impianti; valori {"Migrazione Excel Impianti": "Migrazione Excel Impianti", "Copia Impianti e Dismetti": "Copia Impianti e Dismetti", "Azione Custom": "Azione da griglia"} | enum('Migrazione NN | 2848/2848 · Azione Custom=2847, Migrazione Excel Impianti=1 |
| `file_to_process` | files | Upload/Download | file s3 | text | 2848/2848 |
| `sede_sorgente` | reference | Vecchia sede cliente | →clienti_sedi_operative (restrict) | int(11) | 0/2848 |
| `sede_dest` | reference | Nuova sede cliente | →clienti_sedi_operative (restrict) | int(11) | 0/2848 |
| `stato` | enum | Stato | sola lettura; valori {"A": "Attivo", "TS": "Terminato con Successo", "TW": "Terminato con Warning", "TE": "Terminato con Errore"} | enum('A','TS','TW','TE') | 2848/2848 · TS=2803, TW=36, TE=9 |
| `progress` | integer | Progresso | sola lettura; default 0 | int(11) | 2848/2848 |
| `log` | log | Messaggi | sola lettura | — |  |
| `inizio` | datetime | Inizio | sola lettura; default gi_date_default() | datetime | 2848/2848 |
| `fine` | datetime | Fine | sola lettura | datetime | 2848/2848 |
| `id` | integer | Codice | sola lettura | int(11) NN | 2848/2848 |
| `utente` | reference | Utente avvio | obbl.; sola lettura; default #id; →utenti (restrict) | int(11) NN | 2848/2848 |
| `action_name` | string | Azione | sola lettura | varchar(191) | 2847/2848 |
| `meta_name` | string | Sorgente | sola lettura | varchar(191) | 2847/2848 |
| `which_items` | string | Elementi sorgente | sola lettura; visibile se false | varchar(191) | 2847/2848 |
| `json` | string | Parametri di lancio | sola lettura; visibile se false | mediumtext | 2847/2848 |
| `last_update_user` | reference | Utente Modifica | sola lettura; →utenti (setdefault) | int(11) | 2848/2848 |
| `last_update_ts` | datetime | Data Modifica | sola lettura | datetime | 2848/2848 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 2848/2848)

## `nazioni` — Nazioni

- tipo meta: table · lettura: `nazioni` · decodifica: `nazioni_dec` · record: 223
- hook: php_gi_ddl_table_create_custom=`gi_ddl_table_create_comuni`
- univoci: ['nazione']
- ordinamento: {'by': 'nazione', 'dir': 'asc'}
- permessi: `show_nazioni`; `edit_nazioni`; `new_nazioni`; `delete_nazioni`
- azioni: show←show_nazioni; edit←edit_nazioni; new←new_nazioni; delete←delete_nazioni
- altre proprietà: {"list_mobile": [{"field": "id", "left": "nazione", "title": "nazione"}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | ID | sola lettura; visibile se false | int(11) NN | 223/223 |
| `nazione` | string | Nazione | obbl. | varchar(191) NN | 223/223 |
| `codice_at` | string | Codice AT | aiuto: Serve per il calcolo del codice fiscale per i nati all'estero | varchar(191) | 215/223 |
| `codice_iso_alpha2` | string | Codice ISO 3166 alpha2 | obbl.; max 2 | varchar(2) NN | 223/223 |
| `codice_iso_alpha3` | string | Codice ISO 3166 alpha3 | obbl.; max 3 | varchar(3) NN | 223/223 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault) | int(11) | 223/223 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 223/223 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 223/223)

## `pagamenti` — Pagamenti

- tipo meta: table · lettura: `pagamenti_read` · decodifica: `pagamenti_dec` · record: 473
- ordinamento: {'by': 'data_scadenza', 'dir': 'asc'}
- permessi: `show_pagamenti`; `edit_pagamenti`; `new_pagamenti`; `delete_pagamenti`
- azioni: show←show_pagamenti; edit←edit_pagamenti; new←new_pagamenti; delete←delete_pagamenti
- altre proprietà: {"show_stats": true}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura; visibile se false | int(11) NN | 473/473 |
| `data_scadenza` | date | Data scadenza | obbl. | date NN | 473/473 |
| `fattura_cliente` | reference | Fattura cliente | obbl.; →fatture_clienti (cascade); trascina ['cliente']; accesso {"edit": ["__never__"]} | int(11) NN | 473/473 |
| `cliente` | reference | Cliente | →clienti (noaction); calcolato in vista | vista |  |
| `descrizione` | string | Descrizione |  | varchar(191) | 473/473 |
| `rif_pagamento` | string | Rif. pagamento (Es. Assegno nr ..., CRO… |  | varchar(191) | 0/473 |
| `tipo_pagamento` | enum | Tipo pagamento | obbl.; valori {"E": "Entrata", "U": "Uscita"} | enum('E','U') NN | 473/473 · E=473 |
| `importo` | decimal | Importo |  | decimal(12,2) | 473/473 |
| `entrata` | decimal | Entrata | visibile se false; calcolato in vista | vista |  |
| `uscita` | decimal | Uscita | visibile se false; calcolato in vista | vista |  |
| `saldato` | boolean | Saldato | obbl.; default F | enum('F','T') NN | 473/473 · T=423, F=50 |
| `note` | string | Note |  | text | 435/473 |
| `last_update_user` | reference | Utente Modifica | sola lettura; →utenti (setdefault) | int(11) | 473/473 |
| `last_update_ts` | datetime | Data Modifica | sola lettura | datetime | 473/473 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 473/473)

## `pagamenti_flat` — Pagamenti

- tipo meta: table
- altre proprietà: {"extends_meta": "pagamenti"}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|

## `preventivi` — Preventivi

- tipo meta: table · lettura: `preventivi_read` · decodifica: `preventivi_dec` · record: 1009
- hook: php_gi_record_save_before=`gi_preventivi_save_before`, php_gi_record_change_after=`gi_preventivi_change_after`
- univoci: ['serie_preventivo', 'numero_preventivo']
- indici: ['cliente']
- ordinamento: {'by': 'anno_numero_preventivo', 'dir': 'desc'}
- permessi: `show_preventivi`; `show_preventivi_ref_comm` [cond: t.referente_commerciale=#id]; `edit_preventivi`; `edit_preventivi_riesame`; `new_preventivi`; `delete_preventivi`; `print_preventivi`
- azioni: show←show_preventivi|show_preventivi_ref_comm; edit←edit_preventivi|edit_preventivi_riesame; new←new_preventivi; delete←delete_preventivi; print←
- altre proprietà: {"show_stats": true}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 1009/1009 |
| `stato_preventivo` | enum | Stato preventivo | obbl.; default creato; valori {"creato": "Creato", "inviato": "Inviato", "accettato": "Accettato", "accettato_parzialmente": "Accettato parzialmente", "rifiutato": "Rifiutato", "annullato": "Annullato"}; accesso {"edit": ["edit_preventivi"]} | enum('creato','inviato','accettato','accettato_parzialmente','rifiutato','annullato') NN | 1009/1009 · accettato=830, inviato=130, rifiutato=31, creato=9, annullato=6, accettato_parzialmente=3 |
| `rif_ord_cli` | string | Rif. ordine cliente | accesso {"edit": ["edit_preventivi"]}; aiuto: Se compilato viene riportato sulla fattura nel campo 'Verbali di riferimento/note' | varchar(191) | 86/1009 |
| `fatt_preventivo` | enum | Fatturato | sola lettura; valori {"parziale": "Parziale", "totale": "Totale"} | enum('parziale','totale') | 773/1009 · totale=755, ∅=236, parziale=18 |
| `data_preventivo` | date | Data preventivo | obbl.; default gi_date_default(); accesso {"edit": ["edit_preventivi"]} | date NN | 1009/1009 |
| `serie_preventivo` | string | Serie preventivo | obbl.; default gi_year_get($data_preventivo); dipende ['data_preventivo']; accesso {"edit": ["edit_preventivi"]} | varchar(191) NN | 1009/1009 |
| `numero_preventivo` | integer | Numero preventivo | obbl.; default gi_nextcode_get($id,$serie_preventivo); dipende ['serie_preventivo']; accesso {"edit": ["edit_preventivi"]} | int(11) NN | 1009/1009 |
| `anno_numero_preventivo` | string | Anno/Numero | visibile se false; calcolato in vista | vista |  |
| `decodifica` | string | Decodifica | visibile se false; calcolato in vista | vista |  |
| `cliente` | reference | Cliente | obbl.; →clienti (restrict); trascina ['termini_di_pagamento']; accesso {"edit": ["__never__"]} | int(11) NN | 1009/1009 |
| `referente_commerciale` | reference | Referente commerciale | →utenti (noaction); calcolato in vista | vista |  |
| `termini_di_pagamento` | reference | Termini di pagamento | default gi_reference_default_get('predefinito'); →tipi_pagamento (restrict); accesso {"edit": ["edit_preventivi"]} | int(11) | 975/1009 |
| `termine_esecuzione` | string | Termine esecuzione | accesso {"edit": ["edit_preventivi"]} | varchar(191) | 560/1009 |
| `ind_trasferta` | decimal | Indennità di trasferta | default gi_preventivi_default_calc($cliente,$id) | decimal(12,2) | 106/1009 |
| `contr_inail` | boolean | Contributo INAIL 5% | obbl.; default gi_preventivi_default_calc($cliente,$id) | enum('F','T') NN | 1009/1009 · T=697, F=312 |
| `totale_standard` | decimal | Totale standard | sola lettura | decimal(12,2) | 1009/1009 |
| `totale_scontato` | decimal | Totale scontato | sola lettura | decimal(12,2) | 1009/1009 |
| `note_interne` | string | Note Interne | accesso {"edit": ["edit_preventivi"]} | text | 69/1009 |
| `riesame_fatto` | boolean | Riesame fatto | obbl.; default F; accesso {"edit": ["edit_preventivi_riesame"]} | enum('F','T') NN | 1009/1009 · T=838, F=171 |
| `riesame_esito` | enum | Esito riesame | obbl.=$riesame_fatto=="T"; valori {"C": "Conforme", "N": "Non conforme"}; visibile se $riesame_fatto=="T"; accesso {"edit": ["edit_preventivi_riesame"]} | enum('C','N') | 838/1009 · C=838, ∅=171 |
| `riesame_nota` | string | Nota riesame | obbl.=$riesame_fatto=="T" && $riesame_esito=="N"; visibile se $riesame_fatto=="T"; accesso {"edit": ["edit_preventivi_riesame"]} | text | 494/1009 |
| `ult_riesame_utente` | reference | Utente ult. riesame | sola lettura; →utenti (setnull) | int(11) | 458/1009 |
| `ult_riesame_data` | date | Data ult. riesame | sola lettura | date | 458/1009 |
| `tipo_documento` | enum | Tipo doc. | valori {"OrdineAcquisto": "Ordine d'acquisto", "Contratto": "Contratto", "Convenzione": "Convenzione", "Ricezione": "Ricezione", "FattureCollegate": "Fattura collegata", "DDT": "Doc. di trasporto", "FatturaPrincipale": "Fattura principale"}; aiuto: Obbligatorio se vuoi che esca in fattura | enum('OrdineAcquisto','Contratto','Convenzione','Ricezione','FattureCollegate','DDT','FatturaPrincipale') | 88/1009 · ∅=921, OrdineAcquisto=64, Contratto=24 |
| `n_documento` | string | N° | regex `/^p{IsBasicLatin}+$/` bloccante; max 20; aiuto: Obbligatorio se vuoi che esca in fattura | varchar(20) | 83/1009 |
| `data_documento` | date | Data | aiuto: Obbligatorio se vuoi che esca in fattura | date | 81/1009 |
| `cig` | string | CIG | regex `/^p{IsBasicLatin}+$/` bloccante; max 15 | varchar(15) | 27/1009 |
| `cup` | string | CUP | regex `/^p{IsBasicLatin}+$/` bloccante; max 15 | varchar(15) | 0/1009 |
| `commessa_convenzione` | string | Commessa / Convenzione | regex `/^[p{IsBasicLatin}p{IsLatin-1Supplement…` bloccante; max 100 | varchar(100) | 7/1009 |
| `rif_lav_gen_prev` | reference | Rif. lav. gen. preventivo | sola lettura; →lavori_batch (restrict) | int(11) | 1008/1009 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull) | int(11) | 1009/1009 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 1009/1009 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 1009/1009)

## `preventivi_righe` — Preventivi righe

- tipo meta: table · lettura: `preventivi_righe_read` · decodifica: `preventivi_righe_dec` · record: 1866
- hook: php_gi_record_save_before=`gi_preventivi_righe_save_before`, php_gi_record_change_after=`gi_preventivi_righe_change_after`, js_gi_form_create_and_show_after=`js_gi_form_create_and_show_preventivi_righe_after`, js_gi_form_create_and_show_form_fields_set_after=`js_gi_form_create_and_show_preventivi_righe_after`
- univoci: ['preventivo', 'n_riga']
- indici: ['preventivo']
- ordinamento: {'by': 'n_riga', 'dir': 'asc'}
- permessi: `show_preventivi_righe`; `edit_preventivi_righe` [cond: t.verifica IS NULL]; `edit_preventivi_righe_stato_riga` [cond: t.verifica IS NULL]; `new_preventivi_righe`; `delete_preventivi_righe` [cond: t.verifica IS NULL]; `custom_preventivi_righe_verifiche_genera` [cond: t.verifica IS NULL AND t.dismessa='F' AND t.stato_riga='accettata' AND t.tariffa_applicata IS NOT NULL AND t.riesame_prev_fatto = 'T' AND t…]; `custom_preventivi_righe_fattura_genera` [cond: t.verifica IS NOT NULL AND t.stato_verifica='effettuata' AND t.fattura IS NULL AND t.fattura_cliente IS NULL AND t.tariffa_applicata IS NOT…]; `custom_preventivi_righe_fattura_cliente_genera` [cond: t.verifica IS NOT NULL AND t.stato_verifica='effettuata' AND t.fattura IS NULL AND t.fattura_cliente IS NULL AND t.tariffa_applicata IS NOT…]; `multiedit_preventivi_righe` [cond: t.verifica IS NULL]
- azioni: show←show_preventivi_righe; edit←edit_preventivi_righe_stato_riga|edit_preventivi_righe; new←new_preventivi_righe; delete←delete_preventivi_righe; multiedit←multiedit_preventivi_righe; preventivi_righe_verifiche_genera←custom_preventivi_righe_verifiche_genera (Genera verifiche); preventivi_righe_fattura_genera←custom_preventivi_righe_fattura_genera (Genera fattura); preventivi_righe_fattura_cliente_genera←custom_preventivi_righe_fattura_cliente_genera (Genera fattura cliente)
- altre proprietà: {"show_stats": true}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 1866/1866 |
| `preventivo` | reference | Preventivo | obbl.; →preventivi (cascade); trascina ['cliente']; visibile se false | int(11) NN | 1866/1866 |
| `stato_preventivo` | enum | Stato preventivo | valori {"creato": "Creato", "inviato": "Inviato", "accettato": "Accettato", "accettato_parzialmente": "Accettato parzialmente", "rifiutato": "Rifiutato", "annullato": "Annullato"}; visibile se false; calcolato in vista | vista |  |
| `stato_riga` | enum | Stato riga | obbl.; default da_accettare; valori {"da_accettare": "Non ancora accettata", "accettata": "Accettata", "rifiutata": "Rifiutata"}; accesso {"edit": ["edit_preventivi_righe_stato_riga"]} | enum('da_accettare','accettata','rifiutata') NN | 1866/1866 · accettata=1439, da_accettare=330, rifiutata=97 |
| `cliente` | reference | Cliente | →clienti (noaction); visibile se false; calcolato in vista | vista |  |
| `n_riga` | integer | N° riga | obbl.; default gi_nextcode_get($id,$preventivo); accesso {"edit": ["edit_preventivi_righe"]}; no multiedit | int(11) NN | 1866/1866 |
| `decodifica` | string | Decodifica | visibile se false; calcolato in vista | vista |  |
| `impianto` | reference | Impianto | obbl.; →impianti (restrict); trascina ['tipo_impianto', 'den_impianto', 'pot_impianto', 'n_cab_trasf_mt_bt', 'n_sott_at_mt', 'codice_pod', 'par_ad_asta', 'num_par_ad_asta', 'par_gabbia', 'class_zone']; dipende ['cliente']; accesso {"edit": ["edit_preventivi_righe"]}; no multiedit | int(11) NN | 1866/1866 |
| `dismessa` | boolean | Dismessa | obbl.; default F; calcolato in vista; no multiedit | vista |  |
| `tipo_verifica` | enum | Tipo verifica | obbl.; valori {"VP": "Verifica periodica", "VS": "Verifica straordinaria"}; accesso {"edit": ["edit_preventivi_righe"]}; no multiedit | enum('VP','VS') NN | 1866/1866 · VP=1865, VS=1 |
| `ric_tar` | boolean | Ricalcola tariffa | obbl.; default T; accesso {"edit": ["edit_preventivi_righe"]} | enum('F','T') NN | 1866/1866 · F=1866 |
| `tariffa_standard` | decimal | Tariffa standard | default 0; accesso {"edit": ["edit_preventivi_righe"]} | decimal(12,2) | 1865/1866 |
| `sconto` | decimal | Sconto | obbl.; default 0; accesso {"edit": ["edit_preventivi_righe"]} | decimal(12,2) NN | 1866/1866 |
| `tariffa_applicata` | decimal | Tariffa applicata | sola lettura; default 0; no multiedit | decimal(12,2) | 1865/1866 |
| `verifica` | reference | Verifica | sola lettura; →verifiche (restrict); dipende ['impianto']; no multiedit | int(11) | 1438/1866 |
| `stato_verifica` | enum | Stato verifica | valori {"assegnata": "Assegnata", "programmata": "Programmata", "registrata": "Registrata", "effettuata": "Effettuata", "annullata": "Annullata"}; calcolato in vista; no multiedit | vista |  |
| `fattura` | reference | Fattura | →fatture (noaction); calcolato in vista; no multiedit | vista |  |
| `fattura_cliente` | reference | Fattura cliente | →fatture_clienti (noaction); calcolato in vista; no multiedit | vista |  |
| `tipo_impianto` | enum | Tipologia impianto | obbl.; valori {"area 1": "scariche atmosferiche", "area 2": "messa a terra < 1.000 V", "area 3": "messa a terra > 1.000 V", "area 4": "pericolo di esplosione"}; visibile se false; calcolato in vista | vista |  |
| `den_impianto` | string | Denominazione impianto | calcolato in vista; no multiedit | vista |  |
| `pot_impianto` | decimal | Potenza impianto | visibile se ($tipo_impianto=="area 2" \|\| $tipo_impianto=="area 3"); calcolato in vista; no multiedit | vista |  |
| `n_cab_trasf_mt_bt` | integer | N. di cabine di trasformazione MT/BT | visibile se ($tipo_impianto=="area 2" \|\| $tipo_impianto=="area 3"); calcolato in vista; no multiedit | vista |  |
| `n_sott_at_mt` | integer | N. di sottostazioni AT/MT | visibile se ($tipo_impianto=="area 2" \|\| $tipo_impianto=="area 3"); calcolato in vista; no multiedit | vista |  |
| `codice_pod` | string | Codice POD | visibile se ($tipo_impianto=="area 2" \|\| $tipo_impianto=="area 3"); calcolato in vista; no multiedit | vista |  |
| `par_ad_asta` | boolean | Parafulmine ad asta | visibile se ($tipo_impianto=="area 1"); calcolato in vista; no multiedit | vista |  |
| `num_par_ad_asta` | integer | Numero parafulmini ad asta | visibile se ($tipo_impianto=="area 1" && $par_ad_asta=="T"); calcolato in vista; no multiedit | vista |  |
| `par_gabbia` | enum | Parafulmine a gabbia | valori {"no": "No", "si100": "Sì, superficie fino a 100 mq", "si350": "Sì, superfici protette da 101 a 350 mq", "sioltre350": "Sì, superfici protette oltre 350 mq"}; visibile se ($tipo_impianto=="area 1"); calcolato in vista; no multiedit | vista |  |
| `class_zone` | string | Classificazione zone | visibile se ($tipo_impianto=="area 4"); calcolato in vista; no multiedit | vista |  |
| `rpt_nome_sede` | string | Denominazione sede operativa | visibile se false; calcolato in vista | vista |  |
| `rpt_indirizzo` | string | Indirizzo | visibile se false; calcolato in vista | vista |  |
| `rpt_comune` | string | Comune | visibile se false; calcolato in vista | vista |  |
| `rpt_tipo_impianto` | string | Tipologia impianto | visibile se false; calcolato in vista | vista |  |
| `rpt_pot_impianto` | decimal | Potenza impianto | visibile se false; calcolato in vista | vista |  |
| `rif_lav_gen_prev` | reference | Rif. lav. gen. preventivo | sola lettura; →lavori_batch (restrict); no multiedit | int(11) | 1864/1866 |
| `riesame_prev_fatto` | boolean | Riesame preventivo fatto | visibile se false; calcolato in vista | vista |  |
| `riesame_prev_esito` | enum | Esito riesame preventivo | valori {"C": "Conforme", "N": "Non conforme"}; visibile se false; calcolato in vista | vista |  |
| `riesame_ver_fatto` | boolean | Riesame verifica fatto | visibile se false; calcolato in vista | vista |  |
| `riesame_ver_esito` | enum | Esito riesame verifica | valori {"C": "Conforme", "N": "Non conforme"}; visibile se false; calcolato in vista | vista |  |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull); no multiedit | int(11) | 1866/1866 |
| `last_update_ts` | datetime | Data modifica | sola lettura; no multiedit | datetime | 1866/1866 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 1866/1866)

## `ruoli` — Ruoli

- tipo meta: table · lettura: `ruoli` · decodifica: `ruoli_dec` · record: 6
- hook: php_gi_ddl_table_create_custom=`gi_ddl_table_create_ruoli`, php_gi_record_change_after=`php_gi_predefinito_change_after`
- univoci: ['ruolo']
- ordinamento: {'by': 'ruolo', 'dir': 'asc'}
- permessi: `show_ruoli`; `edit_ruoli`; `new_ruoli`; `copy_ruoli`; `delete_ruoli`
- azioni: show←show_ruoli; edit←edit_ruoli; new←new_ruoli; copy←copy_ruoli; delete←delete_ruoli
- altre proprietà: {"list_mobile": [{"field": "id", "left": "ruolo", "title": "ruolo", "right_top": ["predefinito"]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura; visibile se false | int(11) NN | 6/6 |
| `predefinito` | boolean | Predefinito nuovi utenti | obbl.; default F | enum('F','T') NN | 6/6 · F=5, T=1 |
| `ruolo` | string | Ruolo | obbl. | varchar(191) NN | 6/6 |
| `permessi` | custom | Permessi | obbl. | mediumtext NN | 6/6 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault) | int(11) | 6/6 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 6/6 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 6/6)

## `scadenze` — Scadenze

- tipo meta: table · lettura: `scadenze_read` · decodifica: `scadenze_dec` · record: 2681
- univoci: ['impianto']
- indici: ['impianto']; ['ultima_verifica']; ['data_ult_verifica']; ['data_scad_verifica']; ['preventivo_riga']
- ordinamento: {'by': 'data_scad_verifica', 'dir': 'asc'}
- permessi: `show_scadenze`; `show_scadenze_ref_comm` [cond: t.referente_commerciale=#id]; `show_scadenze_utente_cliente` [cond: t.utente_cliente=#id]; `export_scadenze`; `custom_scadenze_preventivi_crea` [cond: t.preventivo_riga IS NULL AND t.dismessa='F']
- azioni: show←show_scadenze|show_scadenze_ref_comm|show_scadenze_utente_cliente; scadenze_preventivi_crea←custom_scadenze_preventivi_crea (Crea preventivo); export←export_scadenze

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 2681/2681 |
| `decodifica` | string | Decodifica | visibile se false; calcolato in vista | vista |  |
| `cliente` | reference | Cliente | →clienti (noaction); calcolato in vista | vista |  |
| `utente_cliente` | reference | Utente del cliente | →utenti (noaction); calcolato in vista; accesso {"show": ["show_scadenze"]} | vista |  |
| `referente_commerciale` | reference | Referente commerciale | →utenti (noaction); calcolato in vista; accesso {"show": ["show_scadenze"]} | vista |  |
| `sede_operativa` | reference | Sede operativa | →clienti_sedi_operative (noaction); calcolato in vista | vista |  |
| `impianto` | reference | Impianto | obbl.; →impianti (cascade) | int(11) NN | 2681/2681 |
| `dismessa` | boolean | Dismessa | obbl.; default F; calcolato in vista | vista |  |
| `ultima_verifica` | reference | Ultima verifica | →verifiche (cascade) | int(11) | 1258/2681 |
| `data_ult_verifica` | date | Data ultima verifica |  | date | 1323/2681 |
| `data_scad_verifica` | date | Data scadenza verifica |  | date | 2681/2681 |
| `preventivo` | reference | Preventivo | →preventivi (noaction); calcolato in vista | vista |  |
| `preventivo_riga` | reference | Riga preventivo | →preventivi_righe (setnull) | int(11) | 489/2681 |
| `verifica_affidata` | reference | Verifica affidata | →verifiche (noaction); calcolato in vista | vista |  |
| `stato_preventivo` | enum | Stato preventivo | valori {"creato": "Creato", "inviato": "Inviato", "accettato": "Accettato", "accettato_parzialmente": "Accettato parzialmente", "rifiutato": "Rifiutato", "annullato": "Annullato"}; calcolato in vista | vista |  |
| `stato_riga` | enum | Stato riga | valori {"da_accettare": "Non ancora accettata", "accettata": "Accettata", "rifiutata": "Rifiutata"}; calcolato in vista | vista |  |
| `stato_verifica` | enum | Stato verifica | valori {"assegnata": "Assegnata", "registrata": "Registrata", "effettuata": "Effettuata", "annullata": "Annullata"}; calcolato in vista | vista |  |
| `imp_tipo_impianto` | enum | Tipologia impianto | obbl.; valori {"area 1": "scariche atmosferiche", "area 2": "messa a terra < 1.000 V", "area 3": "messa a terra > 1.000 V", "area 4": "pericolo di esplosione"}; visibile se false; calcolato in vista | vista |  |
| `imp_den_impianto` | string | Denominazione impianto | visibile se false; calcolato in vista | vista |  |
| `imp_pot_impianto` | decimal | Potenza impianto | visibile se false; calcolato in vista | vista |  |
| `imp_n_cab_trasf_mt_bt` | integer | N. di cabine di trasformazione MT/BT | visibile se false; calcolato in vista | vista |  |
| `imp_n_sott_at_mt` | integer | N. di sottostazioni AT/MT | visibile se false; calcolato in vista | vista |  |
| `imp_codice_pod` | string | Codice POD | visibile se false; calcolato in vista | vista |  |
| `imp_par_ad_asta` | boolean | Parafulmine ad asta | visibile se false; calcolato in vista | vista |  |
| `imp_num_par_ad_asta` | integer | Numero parafulmini ad asta | visibile se false; calcolato in vista; no multiedit | vista |  |
| `imp_par_gabbia` | enum | Parafulmine a gabbia | valori {"no": "No", "si100": "Sì, superficie fino a 100 mq", "si350": "Sì, superfici protette da 101 a 350 mq", "sioltre350": "Sì, superfici protette oltre 350 mq"}; visibile se false; calcolato in vista; no multiedit | vista |  |
| `imp_class_zone` | string | Classificazione zone | visibile se ($imp_tipo_impianto=="area 4"); calcolato in vista; no multiedit | vista |  |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 2681/2681)

## `tariffe_terre` — Tariffe Terre

- tipo meta: table · lettura: `tariffe_terre` · decodifica: `tariffe_terre_dec` · record: 13
- hook: php_gi_ddl_table_create_custom=`gi_ddl_table_create_tariffe_terre`
- ordinamento: {'by': 'scaglione', 'dir': 'asc'}
- permessi: `show_tariffe_terre`; `edit_tariffe_terre`; `new_tariffe_terre`; `delete_tariffe_terre`
- azioni: show←show_tariffe_terre; edit←edit_tariffe_terre; new←new_tariffe_terre; delete←delete_tariffe_terre

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 13/13 |
| `scaglione` | decimal | Scaglione | obbl. | decimal(12,2) NN | 13/13 |
| `tariffa_std` | decimal | Tariffa standard | obbl.; default 0 | decimal(12,2) NN | 13/13 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull) | int(11) | 0/13 |
| `last_update_ts` | datetime | Data modifica | sola lettura | datetime | 0/13 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 13/13)

## `tipi_pagamento` — Tipi Pagamento

- tipo meta: table · lettura: `tipi_pagamento` · decodifica: `tipi_pagamento_dec` · record: 25
- hook: php_gi_ddl_table_create_custom=`gi_ddl_table_create_tipi_pagamento`, php_gi_record_change_after=`php_gi_predefinito_change_after`
- univoci: ['nome_pagamento']
- ordinamento: {'by': 'nome_pagamento', 'dir': 'asc'}
- permessi: `show_tipi_pagamenti`; `edit_tipi_pagamenti`; `new_tipi_pagamenti`; `delete_tipi_pagamenti`
- azioni: show←show_tipi_pagamenti; edit←edit_tipi_pagamenti; new←new_tipi_pagamenti; delete←delete_tipi_pagamenti

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | ID | sola lettura; visibile se false | int(11) NN | 25/25 |
| `predefinito` | boolean | Predefinito | obbl.; default F | enum('F','T') NN | 25/25 · F=24, T=1 |
| `nome_pagamento` | string | Nome pagamento | obbl. | varchar(191) NN | 25/25 |
| `modalita` | enum | Modalità | obbl.; valori {"MP01": "MP01: contanti", "MP02": "MP02: assegno", "MP03": "MP03: assegno circolare", "MP05": "MP05: bonifico", "MP06": "MP06: vaglia cambiario", "MP07": "MP07: bollettino bancario", "MP08": "MP08: carta di pagamento", "MP09": "MP09: RID", "MP10": "MP10: RID utenze", "MP11": "MP11: RID veloce", "MP12": "MP12: RIBA", "MP13": "MP13: MAV", "MP14": "MP14: quietanza erario", "MP15": "MP15: giroconto … | enum('MP01','MP02','MP03','MP05','MP06','MP07','MP08','MP09','MP10','MP11','MP12','MP13','MP14','MP15','MP16','MP17','MP19','MP20','MP21','MP22','MP23') NN | 25/25 · MP05=14, MP12=5, MP01=2, MP21=1, MP20=1, MP08=1, MP02=1 |
| `salda_subito` | boolean | Salda subito documento con questo pagam… | obbl.; default F | enum('F','T') NN | 25/25 · F=23, T=2 |
| `fm_paga_dopo` | integer | Se "Fine Mese", paga il giorno indicato… |  | int(11) | 0/25 |
| `sposta_scadenze` | boolean | Sposta le scadenze al 31/8 o 31/12 al 1… | obbl.; default F | enum('F','T') NN | 25/25 · F=25 |
| `last_update_user` | reference | Utente Modifica | sola lettura; →utenti (setdefault) | int(11) | 7/25 |
| `last_update_ts` | datetime | Data Modifica | sola lettura | datetime | 7/25 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 25/25)

## `tipi_pagamento_scadenze` — Scadenze Tipi Pagamento

- tipo meta: table · lettura: `tipi_pagamento_scadenze` · decodifica: `tipi_pagamento_scadenze_dec` · record: 24
- hook: php_gi_ddl_table_create_custom=`gi_ddl_table_create_tipi_pagamento`
- univoci: ['tipo_pagamento', 'giorni']
- ordinamento: {'by': 'giorni', 'dir': 'asc'}
- permessi: `show_tipi_pagamento_scadenze`; `edit_tipi_pagamento_scadenze`; `new_tipi_pagamento_scadenze`; `delete_tipi_pagamento_scadenze`
- azioni: show←show_tipi_pagamento_scadenze; edit←edit_tipi_pagamento_scadenze; new←new_tipi_pagamento_scadenze; delete←delete_tipi_pagamento_scadenze

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | ID | sola lettura; visibile se false | int(11) NN | 24/24 |
| `tipo_pagamento` | reference | Tipo Pagamento | obbl.; →tipi_pagamento (cascade) | int(11) NN | 24/24 |
| `giorni` | integer | Giorni | obbl.; default 0 | int(11) NN | 24/24 |
| `perc_totale` | decimal | % del Totale | obbl.; default 0 | decimal(12,2) NN | 24/24 |
| `fine_mese` | boolean | Fine mese? | obbl.; default F | enum('F','T') NN | 24/24 · T=12, F=12 |
| `last_update_user` | reference | Utente Modifica | sola lettura; →utenti (setdefault) | int(11) | 0/24 |
| `last_update_ts` | datetime | Data Modifica | sola lettura | datetime | 0/24 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 24/24)

## `utenti` — Utenti

- tipo meta: table · lettura: `utenti` · decodifica: `utenti_dec` · record: 7
- hook: php_gi_ddl_table_create_custom=`gi_ddl_table_create_utenti`
- univoci: ['utente']
- ordinamento: {'by': 'utente', 'dir': 'asc'}
- permessi: `show_nomi_utenti`; `show_utenti`; `edit_utenti`; `new_utenti`; `delete_utenti`; `show_profilo` [cond: #id = t.id]; `edit_profilo` [cond: #id = t.id]; `__never__`
- azioni: show←show_nomi_utenti|show_utenti|show_profilo; edit←edit_utenti|edit_profilo; new←new_utenti; delete←delete_utenti
- altre proprietà: {"list_mobile": [{"field": "id", "left": "utente", "title": "utente", "subtitle": ["ruolo"], "right_top": ["attivo"]}]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Codice | sola lettura; visibile se false | int(11) NN | 7/7 |
| `attivo` | boolean | Attivo | obbl.; default T; accesso {"show": ["show_utenti"]} | enum('F','T') NN | 7/7 · T=7 |
| `utente` | string | E-mail | obbl.; check email bloccante; accesso {"show": ["show_utenti", "show_profilo"], "edit": ["edit_utenti"]} | varchar(191) NN | 7/7 |
| `password` | password | Password | obbl.; regex `/^.{8,}$/` bloccante; accesso {"show": ["show_utenti", "show_profilo"]} | varchar(191) NN | 7/7 |
| `ruolo` | reference | Ruolo | obbl.; default gi_reference_default_get('predefinito'); →ruoli (restrict); accesso {"show": ["show_utenti"]} | int(11) NN | 7/7 |
| `registrazione` | datetime | Data Registrazione | sola lettura; default gi_date_default(); accesso {"show": ["show_utenti"]} | datetime | 7/7 |
| `ultima_login` | datetime | Data Ultimo Utilizzo | sola lettura; accesso {"show": ["show_utenti"]} | datetime | 6/7 |
| `cognome` | string | Cognome | obbl.; max 60 | varchar(60) NN | 7/7 |
| `nome` | string | Nome | obbl.; max 60 | varchar(60) NN | 7/7 |
| `cf` | string | C.F. | check cf bloccante; accesso {"show": ["show_utenti", "show_profilo"]} | varchar(191) | 4/7 |
| `tel` | string | Telefono | check tel; accesso {"show": ["show_utenti", "show_profilo"]}; aiuto: es. +39 030 6898477 | varchar(191) | 1/7 |
| `cell` | string | Cellulare | check tel; accesso {"show": ["show_utenti", "show_profilo"]}; aiuto: es. +39 366 4314707 | varchar(191) | 0/7 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setdefault); accesso {"show": ["show_utenti"]} | int(11) | 7/7 |
| `last_update_ts` | datetime | Data modifica | sola lettura; accesso {"show": ["show_utenti"]} | datetime | 7/7 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 7/7)

## `verifiche` — Verifiche

- tipo meta: table · lettura: `verifiche_read` · decodifica: `verifiche_dec` · record: 1438
- hook: php_gi_record_save_before=`gi_verifiche_save_before`, php_gi_record_change_after=`gi_verifiche_change_after`
- univoci: ['codice_verifica']
- indici: ['impianto']; ['tecnico']; ['fattura_cliente']
- ordinamento: {'by': 'codice_verifica', 'dir': 'desc'}
- permessi: `show_verifiche`; `show_verifiche_ref_comm` [cond: t.referente_commerciale=#id]; `show_verifiche_utente_cliente` [cond: t.utente_cliente=#id]; `edit_verifiche`; `edit_verifiche_riesame` [cond: t.stato_verifica='effettuata']; `edit_verifiche_proprie` [cond: t.tecnico=#id AND (t.stato_verifica='assegnata' OR t.stato_verifica='programmata' OR t.stato_verifica='registrata')]; `show_verifiche_proprie` [cond: t.tecnico=#id]; `show_verifiche_tariffe`; `delete_verifiche`; `multiedit_verifiche` [cond: t.stato_verifica='effettuata' OR t.stato_verifica='assegnata']; `export_verifiche`
- azioni: show←show_verifiche|show_verifiche_proprie|show_verifiche_ref_comm|show_verifiche_utente_cliente; edit←edit_verifiche|edit_verifiche_proprie|edit_verifiche_riesame; delete←delete_verifiche; multiedit←multiedit_verifiche; export←export_verifiche
- altre proprietà: {"show_stats": ["show_verifiche"]}

| Campo | Tipo | Etichetta | Vincoli e regole | DB | Dati |
|---|---|---|---|---|---|
| `id` | integer | Id | sola lettura; visibile se false | int(11) NN | 1438/1438 |
| `dichiaro_che` | boolean | il sottoscritto Verificatore dichiara c… | default T; aiuto: Dichiarazione obbligatoria per poter programmare/registrare/effettuare la verifica | enum('F','T') NN | 1438/1438 · T=1390, F=48 |
| `stato_verifica` | enum | Stato verifica | obbl.; valori {"assegnata": "Assegnata", "programmata": "Programmata", "registrata": "Registrata", "effettuata": "Effettuata", "annullata": "Annullata"}; no multiedit | enum('assegnata','programmata','registrata','effettuata','annullata') NN | 1438/1438 · effettuata=1256, assegnata=81, programmata=71, annullata=23, registrata=7 |
| `data_progr` | date | Data programmazione |  | date | 822/1438 |
| `impianto` | reference | Impianto | obbl.; sola lettura; →impianti (restrict); trascina ['cliente', 'sede_operativa']; no multiedit | int(11) NN | 1438/1438 |
| `cliente` | reference | Cliente | →clienti (restrict); visibile se false; calcolato in vista; accesso {"show": ["show_verifiche"]}; no multiedit | vista |  |
| `utente_cliente` | reference | Utente del cliente | →utenti (noaction); visibile se false; calcolato in vista; accesso {"show": ["show_verifiche"]} | vista |  |
| `referente_commerciale` | reference | Referente commerciale | →utenti (noaction); visibile se false; calcolato in vista; accesso {"show": ["show_verifiche"]} | vista |  |
| `sede_operativa` | reference | Sede operativa | →clienti_sedi_operative (restrict); visibile se false; calcolato in vista; accesso {"show": ["show_verifiche"]}; no multiedit | vista |  |
| `nome_sede` | string | Denominazione sede operativa | calcolato in vista; no multiedit | vista |  |
| `indirizzo` | string | Indirizzo | calcolato in vista; no multiedit | vista |  |
| `comune` | string | Comune | calcolato in vista; no multiedit | vista |  |
| `cap` | string | CAP | calcolato in vista; no multiedit | vista |  |
| `prov` | string | Prov. | calcolato in vista; no multiedit | vista |  |
| `codice_verifica` | string | Progressivo verifica | sola lettura; no multiedit | varchar(191) | 1265/1438 |
| `numero_verifica` | integer | Numero verifica | sola lettura; visibile se false | int(11) | 1265/1438 |
| `anno_verifica` | string | Anno verifica | sola lettura; visibile se false | varchar(191) | 1265/1438 |
| `decodifica` | string | Decodifica | visibile se false; calcolato in vista | vista |  |
| `tecnico` | reference | Tecnico | obbl.; →utenti (restrict); accesso {"show": ["show_verifiche"], "edit": ["edit_verifiche"]}; no multiedit | int(11) NN | 1438/1438 |
| `tecnico_aff` | reference | Tecnico in affiancamento | →utenti (restrict); accesso {"show": ["show_verifiche"], "edit": ["edit_verifiche"]}; no multiedit | int(11) | 1/1438 |
| `imp_tipo_impianto` | enum | Tipologia impianto | obbl.; valori {"area 1": "scariche atmosferiche", "area 2": "messa a terra < 1.000 V", "area 3": "messa a terra > 1.000 V", "area 4": "pericolo di esplosione"}; calcolato in vista; no multiedit | vista |  |
| `imp_den_impianto` | string | Denominazione impianto | calcolato in vista; no multiedit | vista |  |
| `imp_pot_impianto` | decimal | Potenza impianto | visibile se ($imp_tipo_impianto=="area 2" \|\| $imp_tipo_impianto=="area 3"); calcolato in vista; no multiedit | vista |  |
| `imp_n_cab_trasf_mt_bt` | integer | N. di cabine di trasformazione MT/BT | visibile se ($imp_tipo_impianto=="area 2" \|\| $imp_tipo_impianto=="area 3"); calcolato in vista; no multiedit | vista |  |
| `imp_n_sott_at_mt` | integer | N. di sottostazioni AT/MT | visibile se ($imp_tipo_impianto=="area 2" \|\| $imp_tipo_impianto=="area 3"); calcolato in vista; no multiedit | vista |  |
| `imp_codice_pod` | string | Codice POD | visibile se ($imp_tipo_impianto=="area 2" \|\| $imp_tipo_impianto=="area 3"); calcolato in vista; no multiedit | vista |  |
| `imp_par_ad_asta` | boolean | Parafulmine ad asta | visibile se ($imp_tipo_impianto=="area 1"); calcolato in vista; no multiedit | vista |  |
| `imp_num_par_ad_asta` | integer | Numero parafulmini ad asta | visibile se ($imp_tipo_impianto=="area 1" && $imp_par_ad_asta=="T"); calcolato in vista; no multiedit | vista |  |
| `imp_par_gabbia` | enum | Parafulmine a gabbia | valori {"no": "No", "si100": "Sì, superficie fino a 100 mq", "si350": "Sì, superfici protette da 101 a 350 mq", "sioltre350": "Sì, superfici protette oltre 350 mq"}; visibile se ($imp_tipo_impianto=="area 1"); calcolato in vista; no multiedit | vista |  |
| `imp_class_zone` | string | Classificazione zone | visibile se ($imp_tipo_impianto=="area 4"); calcolato in vista; no multiedit | vista |  |
| `tipo_verifica` | enum | Tipo verifica | obbl.; sola lettura; valori {"VP": "Verifica periodica", "VS": "Verifica straordinaria"}; no multiedit | enum('VP','VS') NN | 1438/1438 · VP=1437, VS=1 |
| `esito_verifica` | enum | Esito verifica | obbl.=$stato_verifica=="effettuata"; valori {"Positivo": "Positivo", "Negativo": "Negativo", "Sospeso": "Sospeso", "A vuoto": "A vuoto"}; accesso {"edit": ["edit_verifiche", "edit_verifiche_proprie"]}; no multiedit | enum('Positivo','Negativo','Sospeso','A | 1265/1438 · Positivo=1264, ∅=173, Negativo=1 |
| `motivazione_sospensione` | string | Motivazione sospensione | obbl.=$esito_verifica == "Sospeso"; max 150; visibile se $esito_verifica == "Sospeso"; accesso {"edit": ["edit_verifiche", "edit_verifiche_proprie"]}; no multiedit | varchar(150) | 0/1438 |
| `data_rilascio_verbale` | date | Data rilascio verbale | obbl.=$stato_verifica=="effettuata" \|\| $stato_verifica=="registrata"; accesso {"edit": ["edit_verifiche", "edit_verifiche_proprie"]}; no multiedit | date | 1265/1438 |
| `data_consegna` | date | Data consegna | accesso {"show": ["show_verifiche"], "edit": ["edit_verifiche"]} | date | 578/1438 |
| `data_prox_verifica` | date | Data Prossima Verifica | obbl.=$tipo_verifica == "VP" && $stato_verifica=="effettuata"; visibile se $tipo_verifica == "VP"; accesso {"edit": ["edit_verifiche", "edit_verifiche_proprie"]}; no multiedit | date | 1264/1438 |
| `tariffa_standard` | decimal | Tariffa standard | sola lettura; accesso {"show": ["show_verifiche_tariffe"]}; no multiedit | decimal(12,2) | 1438/1438 |
| `tariffa_effettiva` | decimal | Tariffa effettiva | sola lettura; accesso {"show": ["show_verifiche_tariffe"]}; no multiedit | decimal(12,2) | 1438/1438 |
| `verbale` | files | Verbale | obbl.=$stato_verifica=="effettuata"; accesso {"edit": ["edit_verifiche", "edit_verifiche_proprie"]}; file s3; no multiedit; aiuto: Il file non deve superare 1 MB di occupazione. Scansiona in scala di grigi, max 200dpi | text | 1359/1438 |
| `preventivo` | reference | Preventivo | →preventivi (noaction); calcolato in vista; no multiedit | vista |  |
| `preventivo_riga` | reference | Riga preventivo | sola lettura; →preventivi_righe (restrict); no multiedit | int(11) | 1438/1438 |
| `fattura` | reference | Fattura | →fatture (setnull); dipende ['cliente']; accesso {"show": ["show_verifiche"], "edit": ["edit_verifiche"]} | int(11) | 495/1438 |
| `fattura_cliente` | reference | Fattura cliente | →fatture_clienti (setnull); dipende ['cliente']; accesso {"show": ["show_verifiche"], "edit": ["edit_verifiche"]} | int(11) | 749/1438 |
| `riesame_fatto` | boolean | Riesame fatto | obbl.; default F; accesso {"edit": ["edit_verifiche_riesame"], "show": ["show_verifiche", "show_verifiche… | enum('F','T') NN | 1438/1438 · T=1255, F=183 |
| `riesame_esito` | enum | Esito riesame | obbl.=$riesame_fatto=="T"; valori {"C": "Conforme", "N": "Non conforme"}; visibile se $riesame_fatto=="T"; accesso {"edit": ["edit_verifiche_riesame"], "show": ["show_verifiche", "show_verifiche… | enum('C','N') | 1255/1438 · C=1255, ∅=183 |
| `riesame_nota` | string | Nota riesame | obbl.=$riesame_fatto=="T" && $riesame_esito=="N"; visibile se $riesame_fatto=="T"; accesso {"edit": ["edit_verifiche_riesame"], "show": ["show_verifiche", "show_verifiche… | text | 728/1438 |
| `ult_riesame_utente` | reference | Utente ult. riesame | sola lettura; →utenti (setnull) | int(11) | 693/1438 |
| `ult_riesame_data` | date | Data ult. riesame | sola lettura | date | 693/1438 |
| `rif_lav_gen_verifica` | reference | Rif. lav. gen. verifica | sola lettura; →lavori_batch (restrict); accesso {"show": ["show_verifiche"]}; no multiedit | int(11) | 1438/1438 |
| `last_update_user` | reference | Utente modifica | sola lettura; →utenti (setnull); accesso {"show": ["show_verifiche"]}; no multiedit | int(11) | 1438/1438 |
| `last_update_ts` | datetime | Data modifica | sola lettura; accesso {"show": ["show_verifiche"]}; no multiedit | datetime | 1438/1438 |

Colonne fisiche senza campo nei metadati: `last_update_nr` (int(11); 1438/1438)
