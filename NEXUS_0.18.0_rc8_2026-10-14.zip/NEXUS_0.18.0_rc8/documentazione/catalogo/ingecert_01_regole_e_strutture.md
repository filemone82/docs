# Catalogo Garda — ingecert (AD_dpr): regole e strutture

**Versione 1.0 · 9 ottobre 2026.** Primo dei tre cataloghi (seguiranno adsrl e iec). Serve come base della matrice di parità: ogni regola qui elencata dovrà ricevere un esito nel nuovo gestionale (conservata, cambiata con decisione, non ancora implementata, eliminata con motivo).

**Fonte:** `backup_gestionale.7z`, codice PHP/JS e dump MariaDB di ingecert del 07/10/2026, ricaricato ed estratto il 9 ottobre. I conteggi coincidono con quelli dell'analisi 01 (1.910 clienti, 2.674 sedi, 2.694 impianti, 1.009 preventivi, 1.866 righe, 1.438 verifiche, 473 fatture elettroniche).

**Legenda delle evidenze**
- **[C]** letto nel codice, con file e funzione.
- **[D]** misurato sul dump.
- **[I]** dedotto, da confermare con l'uso o con Garda.

Gli ID citati (verifica 1417, fattura 182, ecc.) sono quelli di ingecert. **Allegato:** `catalogo/ingecert_02_campi.md` riporta, generato dai metadati e dal dump, ogni campo di ogni entità con tipo, vincoli, colonna fisica e riempimento reale. Questo documento ne riprende solo i campi che portano regole.

---

## 0. Sintesi

ingecert gestisce questa catena: **cliente → sede operativa → impianto → scadenza → preventivo e righe → verifica → fattura → XML SDI tramite Aruba.**

La logica di dominio sta in pochi file:

| File | Contenuto |
|---|---|
| `cust/meta/*.js` (47 file) | Strutture, vincoli dei campi, permessi e **condizioni delle azioni**. |
| `cust/_custom.php` (1.397 righe) | Hook di salvataggio, stati, numerazione, scadenze, tariffe, ruoli iniziali. |
| `cust/lavori_batch_cli.php` (1.105) | Generazioni: preventivi da scadenze, verifiche da righe, fatture da righe, import Excel, copia impianti. |
| `cust/gi_views.php` (337) | Viste `_read`/`_dec`: tutti i campi derivati mostrati nelle griglie. |
| `cust/_doc_fiscali_common.php` (1.202) | IVA, split payment, bollo, ritenuta, rate di pagamento, controlli fiscali. |
| `cust/fatture_clienti_genera_xml_cli.php` (1.710) | Generazione XML FatturaPA e ZIP. |
| `cust/meta/_custom.js` (690) | Finestre di lancio delle azioni (tecnico, data, preventivo o fattura da integrare). |
| `_migra.php`, `_migra2.php`, `_update.php` | Script di migrazione una tantum, non più in uso. |

**Le dieci evidenze più rilevanti per il progetto**

1. **Il flusso 17020 è scritto soprattutto nei permessi condizionati delle azioni.** Si generano verifiche solo da righe accettate di preventivi con riesame conforme. Si fatturano solo verifiche effettuate con riesame conforme. [C]
2. **Il numero del verbale nasce già in "registrata"**, non solo in "effettuata". Il sezionale è unico per VP e VS e per anno di rilascio, e il numero cambia se cambia l'anno della data di rilascio. [C][D]
3. **La dichiarazione di indipendenza vale "Sì" per default**, nel DB e nei metadati. Ogni verifica generata nasce quindi già dichiarata, senza autore né data della dichiarazione. [C][D]
4. **Niente impedisce al tecnico di riesaminare la propria verifica.** Nei dati non accade mai (0 casi sui 693 riesami con utente registrato): è prassi, non regola. [C][D]
5. **Il ruolo Tecnico reale è molto più ampio di quello previsto dal codice.** Può modificare e cancellare qualunque verifica, non solo le proprie. [D]
6. **Lo scadenzario considera solo le VP effettuate.** Una riga di preventivo anche solo "da accettare" basta a considerare coperta la scadenza. [C][D]
7. **Due flussi di fatturazione convivono:** il registro "fatture" (aprile–novembre 2025) e la fattura elettronica nativa (dal 4 dicembre 2025, serie `/AAAA/DPR`). Nella serie 2026 mancano i numeri 145 e 154. [D]
8. **AD emette da due gestionali con lo stesso codice fiscale e contatori di invio separati.** 470 progressivi di file XML coincidono tra ingecert e adsrl; i nomi si distinguono solo per un suffisso aggiunto da un "hack". [C][D]
9. **Gli allegati su S3 sono caricati con ACL `public-read`**, e le chiavi di accesso sono in chiaro nella configurazione. [C]
10. **Parte del codice comune non è adattata a ingecert.** La cancellazione di una fattura elettronica aggiorna colonne di `preventivi` che qui non esistono. [C][D]

---

## 1. Perimetro dell'installazione

| Gruppo | Entità | Record |
|---|---|---|
| Anagrafiche | `clienti`, `clienti_sedi_operative`, `comuni`, `nazioni` | 1.910 · 2.674 · 8.463 · 223 |
| Oggetto verificato | `impianti` | 2.694 |
| Listino | `tariffe_terre` | 13 scaglioni |
| Scadenzario (derivato) | `scadenze` | 2.681 |
| Commerciale | `preventivi`, `preventivi_righe` | 1.009 · 1.866 |
| Verifiche | `verifiche`, `verifiche_verbale` (file) | 1.438 · 1.261 |
| Fatture "registro" | `fatture`, `fatture_allegato` | 320 · 315 |
| Fattura elettronica | `fatture_clienti`, `_righe`, `_iva`, `_doc_collegati`, `_stampa`, `pagamenti`, `iva`, `tipi_pagamento`, `tipi_pagamento_scadenze`, `fatture_clienti_genera_xml` | 473 · 1.123 · 473 · 101 · 475 · 473 · 32 · 25 · 24 · 178 |
| Configurazione | `configurazioni` (1 record), `utenti`, `ruoli` | 1 · 7 · 6 |
| Framework | `lavori_batch` (+log), `gi_mails`, `gi_reports`, `gi_exports`, `gi_multiedits`, `gi_numerators`, `gi_tags`, impostazioni utente | 2.848 lavori, 444 mail, 1.792 stampe, 199 modifiche multiple |

**Integrità referenziale.** Il database **non ha chiavi esterne**: i vincoli `restrict`/`cascade`/`setnull` dei metadati sono applicati dal framework [C][D]. Sul dump non ci sono record orfani in nessuna delle 16 relazioni controllate [D]. Il nuovo sistema deve dichiarare le FK nel database.

**Vincoli di unicità effettivi nel DB** [D]:

| Tabella | Chiave unica |
|---|---|
| `clienti` | `rag_soc` |
| `clienti_sedi_operative` | `nome_sede`, unica su tutto il sistema e non per cliente |
| `impianti` | (`sede_operativa`, `tipo_impianto`): al massimo un impianto per tipologia per sede |
| `scadenze` | `impianto` |
| `preventivi` | (`serie_preventivo`, `numero_preventivo`) |
| `preventivi_righe` | (`preventivo`, `n_riga`) |
| `verifiche` | `codice_verifica` |
| `fatture` | (`serie_fattura`, `numero_fattura`) |
| `fatture_clienti` | (`serie_fattura`, `tipo_fatt`, `numero_fattura`) |
| `fatture_clienti_righe` | (`fattura`, `n_riga`) |

---

## 2. Strutture

### 2.1 Relazioni

```
clienti 1─N clienti_sedi_operative 1─N impianti (max 1 per tipologia per sede)
impianti 1─1 scadenze ─0..1→ preventivi_righe
preventivi 1─N preventivi_righe N─1 impianti
preventivi_righe 1─0..1 verifiche (riga.verifica ↔ verifica.preventivo_riga)
verifiche N─1 impianti · verifiche ─0..1→ fatture (registro) · ─0..1→ fatture_clienti
impianti ─0..1→ verifiche (ultima_verifica, ridondante)
fatture_clienti 1─N righe (ognuna con preventivo e verifica) · 1─N iva · 1─N doc_collegati · 1─N pagamenti
utenti N─1 ruoli · verifiche.tecnico / tecnico_aff → utenti · sedi.utente_cliente → utenti (accesso del cliente)
```

### 2.2 Campi che portano regole, per entità

Per l'elenco completo vedi l'allegato. Qui compaiono solo i campi con vincoli, automatismi o effetti su altri dati.

**`clienti`**
- `rag_soc` obbligatoria e unica. Su indirizzo e ragione sociale sono ammessi solo caratteri latini (regex bloccante).
- `cod_fis` obbligatorio con controllo formale; `p_iva` con controllo formale e mancanza segnalata come avviso. Su 1.910 clienti, 38 P.IVA sono duplicate [D].
- `sdi_pec` (codice destinatario o PEC), `rif_amministrazione`, `iban`/`istituto_finanziario` del cliente (usati per le note di credito), `dich_intento`/`_n`/`_data`, `rit_acc_str` (4%, 20%, 23% sul 50%), `pagamento` (termini predefiniti), `iva` (aliquota predefinita).
- `referente_commerciale`: un referente che crea un cliente ne diventa automaticamente il referente (`gi_clienti_save_before`) [C]. Valorizzato in 7 clienti [D].
- `email` riceve le fatture, `email_ref` riceve i preventivi [C].

**`clienti_sedi_operative`**
- `cliente` è obbligatorio; la cancellazione del cliente cancella a cascata le sedi.
- `nome_sede` è unico su tutto l'archivio.
- `utente_cliente` serve all'accesso del cliente, ma è vuoto in tutte le sedi [D].
- `referente_commerciale` è derivato dal cliente nella vista.

**`impianti`**
- `tipo_impianto`: area 1 scariche atmosferiche (19), area 2 terra < 1 kV (2.370), area 3 terra > 1 kV (289), area 4 pericolo di esplosione (16) [D].
- Campi visibili secondo la tipologia:

| Tipologia | Campi |
|---|---|
| Area 2 e 3 | `pot_impianto` (kW), `n_cab_trasf_mt_bt`, `n_sott_at_mt`, `codice_pod` |
| Area 1 | `par_ad_asta` e `num_par_ad_asta`, `par_gabbia` (no / ≤100 / 101–350 / >350 m²) |
| Area 4 | zone 0, 1, 2, 20, 21, 22; la vista le ricompone in `class_zone` |

- Matricola (anno 4 cifre, codice attività 1 carattere, numero 5 cifre, provincia 2 lettere), con regex bloccanti. Compilata in circa 110 impianti [D].
- `periodicita_verifiche` (2 o 5 anni) è informativa: la prossima scadenza **non** si calcola da qui, salvo che nell'import Excel [C].
- `dismessa`: 10 impianti dismessi [D].
- `ultima_verifica`, `data_ult_verifica`, `data_prox_verifica` sono ricalcolati dalle verifiche. Diventano non modificabili appena esiste una verifica collegata; prima si possono inserire a mano (date iniziali degli impianti importati) [C]. 66 impianti hanno una data di ultima verifica senza verifica collegata [D].

**`tariffe_terre`**
- 13 scaglioni di potenza (fino a 10 kW 150 €, 15 kW 200 €, 25 kW 250 €, 50 kW 300 €, 100 kW 500 €, 150 kW 600 €, 200 kW 700 €, 250 kW 850 €, 400 kW 1.200 €, 650 kW 1.350 €, 800 kW 1.500 €, 1.000 kW 1.700 €, oltre 2.000 €).
- Valori uguali tra creazione iniziale e dump [C][D].

**`scadenze`** (tabella derivata, una per impianto)
- `ultima_verifica`, `data_ult_verifica`, `data_scad_verifica`, `preventivo_riga`.
- Nella vista vengono aggiunti stato della riga, del preventivo e della verifica affidata, più i dati dell'impianto.

**`preventivi`**
- `stato_preventivo`: creato (9) · inviato (130) · accettato (830) · accettato parzialmente (3) · rifiutato (31) · annullato (6) [D].
- `fatt_preventivo` (parziale/totale), calcolato.
- `serie_preventivo` = anno della data; `numero_preventivo` = ultimo+1 nella serie, proposto e modificabile.
- `termini_di_pagamento` (predefinito dal cliente), `termine_esecuzione`, `rif_ord_cli` (riportato nelle note della fattura del registro).
- `ind_trasferta` e `contr_inail` sono proposti copiando il precedente preventivo dello stesso cliente. In uso: INAIL in 697 preventivi, trasferta in 98 [D].
- `totale_standard` e `totale_scontato`, calcolati.
- Riesame del contratto: `riesame_fatto`, `riesame_esito` C/N, `riesame_nota` (obbligatoria se N), `ult_riesame_utente`/`_data` automatici. In nessun preventivo l'esito è N [D].
- Dati per la fattura elettronica: `tipo_documento` (Ordine d'acquisto, Contratto, ecc.), `n_documento`, `data_documento`, `cig`, `cup`, `commessa_convenzione`.
- `rif_lav_gen_prev` indica il lavoro batch che ha creato il preventivo: 1.008 preventivi su 1.009 nascono dallo scadenzario [D].

**`preventivi_righe`**
- `stato_riga`: da accettare (330) · accettata (1.439) · rifiutata (97) [D].
- `impianto` obbligatorio e filtrato per cliente; `tipo_verifica` VP (1.865) o VS (1) [D].
- `ric_tar` (ricalcola tariffa) torna a "Sì" quando cambia l'impianto e rende la tariffa non modificabile [C]; nel DB vale sempre "No" perché il salvataggio lo azzera.
- `tariffa_standard`, `sconto` % (0 in 1.818 righe; 10% in 41, 15% in 6, 29,16% in 1) [D], `tariffa_applicata` calcolata.
- `verifica` (sola lettura), `n_riga` = ultimo+1 nel preventivo.
- La vista aggiunge stato e date della verifica, riferimenti alle fatture, riesame del preventivo e della verifica, e i dati dell'impianto per la stampa.

**`verifiche`**
- `stato_verifica`: assegnata (81) · programmata (71) · registrata (7) · effettuata (1.256) · annullata (23) [D].
- `dichiaro_che` (dichiarazione di indipendenza del verificatore), default "Sì".
- `impianto` e `tipo_verifica` copiati dalla riga e non modificabili.
- `tecnico` obbligatorio, `tecnico_aff` in affiancamento (usato una volta) [D].
- `data_progr`, `esito_verifica` (Positivo, Negativo, Sospeso, A vuoto; obbligatorio se effettuata), `motivazione_sospensione` (obbligatoria se Sospeso).
- `data_rilascio_verbale` è obbligatoria se registrata o effettuata.
- `data_prox_verifica` è obbligatoria per una VP effettuata ed è **digitata**, non calcolata [C]. Sulle effettuate: +2 anni in 738 casi, +5 in 490, scarti minori negli altri [D].
- `data_consegna` (578 valorizzate) [D].
- `tariffa_standard`/`tariffa_effettiva` copiate dalla riga, in sola lettura, visibili solo con il permesso tariffe.
- `verbale` è un file PDF su S3, obbligatorio se effettuata (limite 1 MB, scansione in grigi a 200 dpi).
- `codice_verifica`/`numero_verifica`/`anno_verifica` sono calcolati.
- `fattura` (registro) o `fattura_cliente` (elettronica): mai entrambe [D].
- Riesame: `riesame_fatto`, `riesame_esito`, `riesame_nota`, `ult_riesame_utente`/`_data`.
- `rif_lav_gen_verifica` indica il lotto di generazione.

**`fatture`** (registro, pre-SDI)
- Fatture prodotte fuori dal gestionale e registrate con PDF allegato.
- IVA fissa al 22% calcolata sull'imponibile (`gi_fatture_save_before`).
- Campi testuali `numero_offerta`, `tecnico_coll`, `verbali_rif_note`; stato pagato/insoluto; data e importo pagati.
- Serie `2025` (224), `2025/EL` (82) e `2025/el` (14): la stessa serie compare con maiuscole e minuscole [D].

**`fatture_clienti`** e collegate: vedi §5.

**`configurazioni`** (un solo record)
- Dati dell'emittente per la fattura elettronica: denominazione, P.IVA, CF, regime fiscale, indirizzo, REA, capitale, socio unico, liquidazione, contatti, banca e IBAN.
- Tipo e causale della ritenuta, codifica articoli, codice SDI proprio, **CF del trasmittente (Aruba)**.
- `mod_word_prev`: il modello Word del preventivo.

---

## 3. Regole

### 3.1 Anagrafiche

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| IC-01 | Ragione sociale unica; nome sede unico su tutto l'archivio. | meta `clienti`, `clienti_sedi_operative`; indici DB | [D] nessun duplicato. Il vincolo sul nome sede globale è più restrittivo del necessario [I]. |
| IC-02 | Un referente commerciale senza visibilità su tutti i clienti diventa referente del cliente che crea. | `_custom.php` `gi_clienti_save_before` | [C] |
| IC-03 | La ritenuta deve avere il formato `N%` o `N% sul M%`. | `_doc_fiscali_common.php` `fw_rit_acc_str_check` | [C] |
| IC-04 | La visibilità per referente commerciale, utente cliente e tecnico si propaga dal cliente a sedi, impianti, scadenze, preventivi e verifiche. | condizioni `show_*_ref_comm`, `*_utente_cliente`, `*_proprie` nei meta | [C]. Accesso cliente predisposto ma mai usato: `utente_cliente` è vuoto ovunque [D]. |

### 3.2 Impianti

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| IC-05 | Al massimo un impianto per tipologia per sede. | indice unico | [D] |
| IC-06 | Le date di ultima e prossima verifica diventano non modificabili appena esiste una verifica VP effettuata; prima si inseriscono a mano. | meta `impianti`; `ricalcola_scadenze_impianto` | [C] |
| IC-07 | Ogni modifica a un impianto ricalcola la sua scadenza. | `gi_impianti_change_after` | [C]. Due scadenze non allineate all'impianto (impianti 478 e 1073), segno di modifiche passate senza hook [D]. |
| IC-08 | "Copia impianti e dismetti" copia gli impianti non dismessi di una sede su un'altra, azzera l'ultima verifica della copia e dismette l'originale. Lo storico verifiche resta sull'impianto vecchio. | `lavori_batch_cli.php` `gi_copia_impianti_dismetti` | [C]. Mai usata [D]. |

### 3.3 Tariffe e prezzi

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| IC-09 | Per le aree 2 e 3 la tariffa standard è quella del primo scaglione con potenza ≥ potenza dell'impianto. Per le aree 1 e 4 non c'è calcolo (tariffa manuale). Senza potenza: avviso e tariffa manuale. | `calcola_tariffa_standard` | [C]. 28 righe di area 2/3 hanno una tariffa diversa dallo scaglione (inserita a mano) [D]. |
| IC-10 | Il ricalcolo usa la potenza **attuale** dell'impianto, letta al salvataggio della riga. | idem | [C]. È già la regola tariffaria voluta. |
| IC-11 | Tariffa applicata = standard × (1 − sconto/100), arrotondata a 2 decimali. | `gi_preventivo_riga_tariffa_applicata_update` | [C] |
| IC-12 | La tariffa standard deve essere > 0 al salvataggio da maschera. | `gi_preventivi_righe_save_before` | [C]. I batch non passano da questo controllo: la riga 2576 (preventivo 1148) ha tariffa nulla [D]. |
| IC-13 | Totali del preventivo = somma delle righe, + 5% INAIL se attivo, + trasferta se > 0, sia sullo standard sia sullo scontato. | `gi_preventivo_totali_update` | [C] |
| IC-14 | Trasferta e INAIL di un nuovo preventivo si copiano dall'ultimo preventivo del cliente; senza precedenti, nessuna trasferta e INAIL "No". | `gi_preventivi_default_calc`; `gi_scadenze_preventivi_crea` | [C] |

### 3.4 Preventivi e righe

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| IC-15 | L'utente può scegliere solo "creato" o "inviato". Accettato, parzialmente accettato, rifiutato e annullato li calcola il sistema. | `gi_preventivi_save_before` | [C] |
| IC-16 | Stato calcolato dalle righe: tutte le verifiche annullate → annullato; tutte le righe accettate → accettato; tutte rifiutate → rifiutato; almeno una accettata → accettato parzialmente; altrimenti resta creato/inviato (o diventa inviato). | `gi_preventivo_stato_update` | [D] coerente in 1.009 preventivi su 1.009. |
| IC-17 | Fatturato totale se tutte le righe hanno una verifica fatturata (registro o elettronica), parziale se almeno una. | idem | [D] coerente al 100%. |
| IC-18 | Si possono aggiungere righe solo se il preventivo è "creato". | `_custom.js` `js_new_preventivi_righe_is_visible` | [C] solo nell'interfaccia. |
| IC-19 | Una riga con verifica non si modifica, non si cancella e non torna a "da accettare" o "rifiutata"; va prima annullata la verifica. | condizioni `edit_/delete_preventivi_righe`; `gi_preventivi_righe_save_before` | [C] |
| IC-20 | **Divieto di ripreventivare.** Non si salva una riga se esiste un'altra riga accettata per lo stesso impianto e tipo di verifica con verifica assente o aperta (assegnata, programmata, registrata). | `gi_preventivi_righe_save_before` | [C]. Nessun doppione aperto [D]. Vale anche per le righe nuove da accettare. |
| IC-21 | Il riesame del preventivo registra in automatico utente e data a ogni cambio di fatto o esito. | `gi_ult_riesame_update` | [C] |
| IC-22 | Il preventivo si stampa con il modello Word M01-RG01 rev. 02 (§7). Una riga aggiuntiva per la trasferta "Tariffario ISPESL 07.07.2005" e una per l'INAIL 5% sullo standard. Con un solo sconto comune la frase totale lo cita; altrimenti c'è solo il totale scontato. | `php_gi_rpt_rows_preventivi_righe_modify`, `php_gi_rpt_global_data_preventivo_modify` | [C] |

### 3.5 Verifiche

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| IC-23 | Stati: assegnata → programmata → registrata → effettuata, oppure annullata. Non ci sono transizioni vietate nel codice, salvo le regole IC-24…IC-28. | meta `verifiche`; hook | [C] |
| IC-24 | Una data di programmazione su una verifica "assegnata" la porta automaticamente in "programmata". | `gi_verifiche_change_after` | [C] |
| IC-25 | Senza dichiarazione di indipendenza non si passa a programmata, registrata o effettuata. | `gi_verifiche_save_before` | [C]. **La dichiarazione vale "Sì" per default** (DB e meta): nasce già spuntata. 48 verifiche hanno "No", tutte assegnate o annullate [D]. |
| IC-26 | Solo chi ha `edit_verifiche` può annullare. | `gi_verifiche_save_before` | [C]. Il ruolo Tecnico reale ce l'ha (§6). |
| IC-27 | **Numerazione.** Entrando in registrata o effettuata, se manca il numero o cambia l'anno della data di rilascio, si prende il prossimo numero del contatore `VPVS<anno>`. Codice = `tipo/NNN/AA` (es. VP/303/25). VP e VS condividono il sezionale. | `gi_verifiche_change_after`; `gi_next_number_get` (contatore atomico) | [D] nessun buco nel 2025 (268–835) né nel 2026 (1–697), nessun doppione. Le 7 registrate sono già numerate. Esiste un contatore `VPVS2028` = 1 senza verifiche: numero preso per un anno digitato per errore [D][I]. |
| IC-28 | All'ingresso in effettuata il riesame si azzera e il PDF del verbale viene rinominato `VP-NNN-AA.pdf`. | `gi_verifiche_change_after`, `gi_file_rename` | [C] |
| IC-29 | Un riesame con esito N riporta la verifica in "registrata"; il tecnico ricarica il PDF e la rimette in effettuata, e il riesame riparte da capo. | idem (commento esplicito nel codice) | [C]. Nessun esito N nei dati [D]. |
| IC-30 | Il riesame è possibile solo su verifiche effettuate e con il permesso apposito; utente e data si registrano in automatico. | condizione `edit_verifiche_riesame`; `gi_ult_riesame_update` | [C]. L'utente è registrato dall'8 gennaio 2026: 693 riesami (Amateis 366, Rovagna 195, Preacco 132); 562 riesami precedenti non hanno autore [D]. |
| IC-31 | Il riesame da parte del tecnico della stessa verifica **non è impedito**. | assenza di controllo | [C]. 0 casi sui 693 riesami con autore [D]. |
| IC-32 | Il tecnico vede e modifica le proprie verifiche solo se assegnate, programmate o registrate. | condizioni `show_/edit_verifiche_proprie` | [C]. Non efficace per il ruolo reale, che ha `edit_verifiche` (§6). |
| IC-33 | Ogni salvataggio di una verifica ricalcola la scadenza dell'impianto e lo stato dei preventivi collegati. | `gi_verifiche_change_after` | [C] |
| IC-34 | La data di consegna non ha vincoli rispetto a rilascio e riesame. | assenza di controllo | [D] 4 consegne prima del rilascio (227, 229, 379, 567) e 2 prima del riesame (313, 1333). Esistono 3 effettuate senza riesame (1288, 1391, 1416). |

### 3.6 Scadenzario

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| IC-35 | La scadenza esiste se l'impianto ha una prossima verifica; è una per impianto. | `ricalcola_scadenze_impianto`; `gi_db_records_synch` | [D] nessun impianto con data senza scadenza. |
| IC-36 | L'ultima verifica è l'ultima **VP effettuata** per data di rilascio. Le VS non spostano la scadenza. | idem | [D] coerente al 100%. |
| IC-37 | **Copertura commerciale.** La scadenza è "presa in carico" dall'ultima riga VP dello stesso impianto non rifiutata, con verifica assente o aperta. Viene mantenuta quella già collegata finché resta compatibile. | idem | [D] scadenze collegate: 329 a righe da accettare, 81/71/7 a verifiche assegnate/programmate/registrate, 1 a riga accettata senza verifica, 2.192 libere. |
| IC-38 | Una riga **da accettare** (offerta inviata senza risposta) basta a coprire la scadenza e toglie l'azione "Crea preventivo". | idem + condizione `custom_scadenze_preventivi_crea` | [C]. Comportamento da decidere: l'obbligo tecnico resta aperto. |
| IC-39 | Le scadenze degli impianti dismessi restano nello scadenzario, ma senza azione di preventivo. | vista + condizione | [D] 10 scadenze di impianti dismessi. |

### 3.7 Fatturazione: regole di dominio

| ID | Regola | Fonte | Riscontro |
|---|---|---|---|
| IC-40 | Si fattura solo una verifica effettuata, con riesame conforme, non ancora fatturata e con tariffa. | condizioni `custom_preventivi_righe_fattura*_genera` | [C]. 9 verifiche riesaminate e non ancora fatturate [D]. |
| IC-41 | Prezzo in fattura = tariffa applicata della riga, quantità 1. Nessun ricalcolo a consuntivo. | `gi_preventivi_righe_fattura_cliente_genera` | [D] 1 riga diversa (fattura 182: 3.674 € contro 2.000 €), modificata a mano dopo la generazione. |
| IC-42 | Descrizione della riga: "‹sede›: verifica periodica/straordinaria di ‹tipologia estesa› - verbale ‹codice› - rif. preventivo ‹n/aaaa del gg/mm/aaaa›", con caratteri limitati al Latin-1. | idem; `gi_filter_non_latin_chars` | [C] |
| IC-43 | INAIL: una sola riga "5% INAIL" = somma del 5% di ogni tariffa applicata, arrotondata alla fine. Integrando una fattura esistente, la riga si aggiorna. | idem | [D] 346 righe, 8.544,15 €. Il 5% per riga è calcolato in virgola mobile in SQL [C]. |
| IC-44 | Trasferta: al massimo una riga per fattura, presa dal primo preventivo con trasferta. **Non si controlla se la trasferta è già stata fatturata** con una fattura precedente dello stesso preventivo (il flusso "registro" lo controllava). | idem; confronto con `gi_preventivi_righe_fattura_genera` | [C]. Nessun caso doppio nei dati [D]. |
| IC-45 | Cliente unico per fattura; termini di pagamento dal preventivo, poi dal cliente, poi il predefinito; aliquota dal cliente o la predefinita. | idem | [C] |
| IC-46 | I documenti collegati (ordine, contratto, CIG/CUP/commessa) passano in fattura solo se il preventivo ha tipo, numero e data. Si prende il primo preventivo che li ha, e solo su una fattura nuova. | idem | [C]. 84 ordini e 17 contratti collegati [D]. |
| IC-47 | La fattura si salva in transazione, ma i collegamenti verifica → fattura e lo stato dei preventivi si aggiornano **dopo** il commit. | idem | [C]. Le verifiche 804–807 puntano alla fattura 210 senza righe corrispondenti; le fatture 444 e 451 hanno righe con verifica non ricollegata [D]. |
| IC-48 | Cancellando una riga di fattura si scollega la verifica e si ricalcola il preventivo. | `gi_fatture_clienti_righe_change_after` | [C] |
| IC-49 | Cancellando una fattura si aggiornano `preventivi.fattura_generata` e `rif_fattura_cliente`, colonne che in ingecert **non esistono**. | `gi_fatture_clienti_delete_after` | [C][D]. Probabile errore se si tenta la cancellazione [I]. |

---

## 4. Processi e azioni da griglia

Tutti passano dalla coda `lavori_batch` (2.848 lavori; stati TS 2.803, TW 36, TE 9, letti come successo, avvisi, errore [I]) [D]. I lanci avvengono da griglia, su righe selezionate o su tutte quelle filtrate.

| Azione | Precondizione sulla singola voce | Parametri di lancio | Effetto | Ripetibilità | Uso [D] |
|---|---|---|---|---|---|
| **Crea preventivo** (da scadenze) | scadenza senza riga collegata, impianto non dismesso | data preventivi (default oggi); preventivo "creato" da integrare (facoltativo) | Un preventivo per cliente per lotto, oppure quello scelto. Righe VP da accettare con tariffa calcolata e sconto 0; scadenza collegata. | Non duplica la riga per lo stesso impianto nello stesso preventivo. Non applica i controlli di maschera (IC-12, IC-20). | 1.147 lanci, mar. 2025–ott. 2026 |
| **Genera verifiche** (da righe) | riga accettata, senza verifica, impianto non dismesso, tariffa presente, riesame del preventivo fatto e conforme | tecnico (qualunque utente) | Verifica "assegnata" con tecnico, tipo e tariffe dalla riga; riga collegata; ricalcolo di scadenza e preventivo. | Non duplica per impianto e lotto, né se la riga ha già una verifica. | 847 lanci |
| **Genera/integra fattura** (registro) | verifica effettuata, riesame conforme, non fatturata | fattura da integrare (facoltativa) | Crea o aggiorna una fattura del registro con imponibile (righe + trasferta una volta per preventivo + INAIL), IVA 22%, elenco offerte, tecnici e verbali. | Riprende e aggiorna i testi esistenti. | 320 lanci, fino al 23/04/2026 |
| **Genera fattura cliente** (elettronica) | come sopra | fattura elettronica da integrare (facoltativa) | §3.7 e §5. | Integra se indicata. | 533 lanci, da dic. 2025 |
| **Genera fatture elettroniche XML** | fattura con XML non ancora generato | selezione o filtro | ZIP con un XML per fattura; segna la fattura come generata. | Le già generate vengono saltate (con "tutte") o rifiutate (con "selezionate"). | 178 ZIP |
| Migrazione Excel impianti | amministratore | file `.xlsx` con colonne fisse | Crea impianti cercando la sede **per nome**; data prossima da file o da ultima + periodicità. | Non duplica sede e tipologia; aggiorna la data prossima se più avanti. | 1 lancio |
| Copia impianti e dismetti | amministratore; sedi sorgente e destinazione diverse | due sedi | IC-08 | — | 0 |

Le modifiche multiple fanno parte del lavoro quotidiano [D]: 160 per accettare righe, 15 per registrare riesami in blocco, 18 per date di programmazione (7 con la dichiarazione). Il nuovo sistema deve consentire queste operazioni di gruppo.

---

## 5. Fatturazione elettronica

### 5.1 Numerazione e serie

- Serie = `/AAAA/DPR`, personalizzata per AD (`gi_serie_documento_get`). Numero = ultimo+1 nella serie, proposto e modificabile; unicità su serie + tipo documento + numero [C].
- Nel 2025 i numeri vanno da 99 a 132, in prosecuzione della serie `2025/EL` del registro (1–98); prima fattura elettronica il 5 dicembre 2025. Nel 2026 da 1 a 441, **mancano 145 e 154** [D]. La causa non è nel codice: cancellazione o modifica manuale [I].
- Tutte le 473 fatture sono TD01. Il tipo TD04 (nota di credito) è gestito ma mai usato [D].

### 5.2 Calcoli

| Elemento | Regola | Fonte |
|---|---|---|
| Totale riga | quantità × prezzo, 2 decimali. Le righe di solo testo (TX) si azzerano e non hanno IVA. | `fw_doc_righe_save_before` |
| Riepilogo IVA | per codice IVA: imponibile = somma, imposta = imponibile × % / 100 a 2 decimali | `fw_doc_calcola_iva_totali` |
| Split payment | l'IVA dei codici di classe SplitPayment diventa "IVA non dovuta" negativa; totale dovuto = documento − IVA non dovuta | idem |
| Ritenuta | imponibile = righe con flag ritenuta (non TX), ridotto della percentuale "sul M%"; importo negativo; sottratto dal dovuto | idem |
| Rate | dalle scadenze del tipo di pagamento; 30/60/90 giorni = mesi; "fine mese" con eventuale giorni dopo; 31/08 e 31/12 spostati di 10 giorni se previsto; l'ultima rata assorbe gli arrotondamenti; le rate già saldate si conservano | idem |
| Bollo | proposto e attivato se le operazioni non soggette superano 77,47 €; aggiunge la riga "Bolli in fattura" di 2 € (codice X15/N1); il bollo non si addebita alla PA | `fw_fattura_cliente_righe_change_after` |
| PA | codice di 6 caratteri → formato FPA12; avvisi se mancano CIG/CUP/commessa o se c'è una riga non in split payment | idem |
| Dichiarazione d'intento | formato del numero controllato (17+6 o 11+7 cifre); data obbligatoria; natura N3.5 senza dichiarazione = errore nell'XML | `fw_fattura_cliente_check`; XML |
| Estero | SDI `XXXXXXX`, P.IVA fittizia "ISO#ragione sociale", CAP 00000 se non valido | `fw_fattura_cliente_nazione_formato_sdi_get`; XML |

Uso reale [D]: codici IVA 22 (914 righe), 22sp split payment (205 righe in 37 fatture), N8c/N3.5 (4); ritenuta 4% su 43 fatture (−335,40 €); un solo bollo; pagamenti 423 saldati e 50 aperti.

### 5.3 XML e invio

- **Trasmittente** = CF configurato (Aruba PEC, 01879020517); `ProgressivoInvio` = contatore `FATTCLIXML` in base 36 su 10 caratteri [C][D].
- **Nome file** = `IT<CF AD>_<progressivo base 36 su 5>` + ` - f_<numero>_<aa>_dpr.xml` (blocco "HACK ADSRL"). Lo ZIP si chiama `IT<CF>_<contatore FATTCLIZIP>.zip` [C][D].
- **Collisione con adsrl.** adsrl usa lo stesso CF con contatori propri: **470 progressivi coincidono** [D]. Il suffisso rende diversi i nomi, ma il nome di SDI previsto dalle specifiche è `IT<CF>_<progressivo>.xml`. Probabilmente Aruba riassegna nome e progressivo: va verificato con Aruba prima di decidere il contatore unico per AD [I].
- **Contenuto dell'XML:**
  - Cedente: dati da `configurazioni`.
  - Cessionario: dati copiati in testata al momento della fattura (`cli_*`); P.IVA con prefisso del paese separato.
  - Riepilogo IVA raggruppato per aliquota, esigibilità e natura.
  - `ImportoTotaleDocumento` con IVA anche in split payment.
  - Pagamenti: TP02 se una rata, TP01 se più rate; banca e IBAN di AD con bonifico, del cliente sulle note di credito.
  - Documenti collegati: DatiOrdineAcquisto, Contratto, Convenzione, Ricezione, FattureCollegate, DDT, FatturaPrincipale.
- **Immutabilità.** Una volta generato l'XML la fattura non si modifica, salvo per chi ha `edit_generata_fatt_elettronica_fatture_clienti`: Amministratore, RT e SRT possono rimettere il flag e modificarla [C][D].
- **Stampa PDF.** Aggiunge in coda le note sulla dichiarazione d'intento, sul bollo virtuale, sui documenti collegati e la frase "Copia della fattura elettronica disponibile nella Sua area riservata…" per i clienti privati italiani [C].
- **Note di credito.** Copiando una TD01 in una TD04 si collega automaticamente la fattura d'origine [C].

---

## 6. Ruoli e permessi reali

I ruoli nel database **non coincidono** con quelli che il codice crea all'installazione. Il ruolo "Riesame" non esiste; esiste invece "Sostituto Responsabile Tecnico", con permessi identici al Responsabile tecnico. [C][D]

| Ruolo (utenti) | Cosa può fare in sostanza |
|---|---|
| Amministratore (2: Garda, AD) | Tutto, tranne riesame e cancellazione delle verifiche. Fa anche il riesame dei preventivi. È l'unico che genera la fattura elettronica dalle righe. |
| Responsabile tecnico (Amateis, Rovagna) | Riesame di preventivi e verifiche, generazione di verifiche e fatture del registro, preventivi, impianti, XML. Può rimettere modificabile una fattura già generata. |
| Sostituto RT (Preacco) | Come il Responsabile tecnico. |
| Tecnico (Carretta) | **Vede, modifica, cancella ed esporta tutte le verifiche** (`edit_verifiche`, `delete_verifiche`, `show_verifiche`) e ne vede le tariffe; non ha `edit_verifiche_proprie`. Il default del codice prevedeva solo le proprie. |
| Referente commerciale (Rostan, mai entrato) | Clienti, sedi, impianti, scadenze e preventivi propri; nessun riesame. |
| Cliente (nessun utente) | Sedi, impianti, scadenze e verifiche della propria sede, in sola lettura. |

Altri elementi sull'accesso:
- L'utente è attivo o non attivo.
- La password ha almeno 8 caratteri ed è conservata come SHA-1 (40 caratteri esadecimali per tutti i 7 utenti); il codice d'installazione la calcola senza sale [C][D].
- Il codice d'installazione contiene la password iniziale dell'amministratore Garda.

---

## 7. Uscite

- **Preventivo Word.** Modello configurato `M01-RG01_dpr_Offerta rev. 02 del 30.09.2026`, documento controllato del sistema di gestione.
  - Segnaposto: `cli.rag_soc/indirizzo/cap/comune`; `p.anno_numero_preventivo`, `p.data_preventivo`, `p.termini_di_pagamento`, `p.termine_esecuzione`, `p.totale_dec`; per ogni riga `r.rpt_nome_sede`, `rpt_indirizzo`, `rpt_comune`, `rpt_tipo_impianto`, `rpt_pot_impianto`, `tariffa_standard`.
  - Firma prevista: Amministratore Unico. Accettazione richiesta a elettrico@adsrl.net.
  - Il modello di riserva in `cust/modelli` è una versione precedente che usa ancora `p.condizioni_pagamento` [C].
- **Mail.** Preventivo a `clienti.email_ref`, fatture a `clienti.email`, oggetto = decodifica del documento, testo fisso "Spett.le … Alleghiamo…". Sono state inviate 444 mail con allegati [C][D].
- **Nomi file.** "Preventivo N-AAAA del gg-mm-aaaa ‹cliente›", "Fattura N-AAAA-DPR del … ‹cliente›", troncati a 80 caratteri [C].
- **Export e stampe** di griglia sono generici del framework: 1.792 stampe, 26 export [D].

---

## 8. Funzioni del framework usate dalla logica di dominio

Da rifare per funzione, non da tradurre:

| Funzione | Uso in ingecert | Comportamento da riprodurre |
|---|---|---|
| `gi_next_number_get` | numeri dei verbali, progressivi XML e ZIP | contatore atomico con ritentativo; un numero preso non si restituisce |
| `gi_nextcode_get` / `gi_year_get` | numeri di preventivi e fatture, `n_riga` | ultimo+1 nella serie, proposto e modificabile; unicità garantita dall'indice |
| `gi_db_records_synch` | scadenze, riepilogo IVA | allinea l'insieme dei figli a quello calcolato (inserisce, aggiorna, cancella) |
| Permessi condizionati | visibilità e azioni | condizione SQL per singolo record, valutata sia in griglia sia sull'azione |
| Viste `_read` | tutti i campi derivati | da sostituire con query o viste del nuovo modello |
| Modifica multipla | accettazioni, riesami, programmazione | operazione di gruppo che passa dagli stessi controlli della maschera [I] |
| Report Word/PDF, mail, export, allegati S3, coda batch | stampe, invii, archivio | — |

---

## 9. Anomalie e punti da decidere per il nuovo sistema

Classi del protocollo di review: **Bloccante**, **Da correggere**, **Da decidere**, **Osservazione**. Si riferiscono a come il nuovo sistema deve comportarsi, non a interventi su Garda.

| # | Tema | Classe | Proposta |
|---|---|---|---|
| A1 | Chiavi S3 in chiaro e ACL `public-read` sui verbali (§0 punto 9). | **Bloccante** (riservatezza) | Ruotare subito le chiavi; verificare la policy del bucket. Nel nuovo sistema: accesso solo autenticato o con link temporanei. |
| A2 | Contatore SDI per AD diviso tra due gestionali (5.3). | Da decidere | Un solo contatore per emittente nel nucleo; prima verificare con Aruba come tratta nome e progressivo. |
| A3 | Dichiarazione di indipendenza preimpostata (IC-25). | Da decidere | Dichiarazione come atto del verificatore, con autore e data, richiesta per programmare; da rivalutare se cambia il tecnico. |
| A4 | Riesame non impedito al tecnico della verifica (IC-31). | Da decidere | Vincolo strutturato, coerente con le procedure 17020. |
| A5 | Ruolo Tecnico con modifica e cancellazione di tutte le verifiche (§6). | Da correggere | Permessi per ruolo e per stato; niente cancellazione di verifiche numerate. |
| A6 | Numero del verbale preso in "registrata" e ripreso al cambio d'anno (IC-27). | Da decidere | Stabilire il momento della numerazione; evitare numeri consumati da date errate. |
| A7 | Una riga "da accettare" copre la scadenza (IC-38). | Da decidere | Già nel quadro (§12): mostrare separatamente offerta inviata e obbligo tecnico. |
| A8 | Controlli di maschera saltati dai batch (IC-12, IC-20). | Da correggere | Stesse regole per maschera, batch, import e modifica multipla. |
| A9 | Collegamenti fattura → verifica aggiornati fuori transazione (IC-47). | Da correggere | Un'unica transazione; casi 804–807, 444, 451 da riconciliare in migrazione. |
| A10 | Trasferta fatturabile più volte (IC-44). | Da decidere | Trasferta come voce del preventivo con stato di fatturazione propria. |
| A11 | Consegna prima del rilascio o del riesame (IC-34). | Da decidere | Ordine delle date secondo le procedure; avviso o blocco. |
| A12 | Buchi nella numerazione fatture 2026 (145, 154). | Osservazione | Numerazione fiscale non modificabile a mano; giustificazione dei salti. |
| A13 | Serie con maiuscole diverse nel registro (`2025/EL` e `2025/el`). | Osservazione | Serie da tabella, non da testo libero; normalizzare in migrazione. |
| A14 | Cancellazione fattura su colonne inesistenti (IC-49). | Osservazione | Documenti emessi non cancellabili; si annullano con nota di credito. |
| A15 | Nome sede unico su tutto l'archivio (IC-01). | Da decidere | Unicità per cliente. |
| A16 | Data della prossima verifica digitata (+2/+5 nella quasi totalità, 1 caso uguale alla data di rilascio: VP/637/25). | Da decidere | Proporla dalla periodicità e chiedere conferma delle eccezioni. |
| A17 | Password conservate in SHA-1. | Da correggere | Hash moderno (argon2 o bcrypt) e reimpostazione al primo accesso. |

---

## 10. Cosa non è stato verificato

- **Il comportamento interno del framework** è dedotto dalle chiamate. Per esempio, che la modifica multipla esegua gli stessi hook della maschera è dedotto e non provato.
- **Prassi d'uso fuori dal gestionale**, come chi decide il tecnico o come si gestiscono i sospesi: richiede conferma operativa.
- **Contenuto degli allegati S3** (verbali, PDF): esclusi per scelta, come stabilito.
- **Trattamento di nome file e progressivo da parte di Aruba.**
- **Crontab reale:** in configurazione è vuoto e i batch partono dal watchdog.
- **Eventuali modifiche** fatte su Garda dopo il 07/10/2026.

---

## Storico

| Versione | Data | Contenuto |
|---|---|---|
| 1.0 | 9 ottobre 2026 | Prima stesura completa per ingecert: strutture, 49 regole, processi, fatturazione, permessi reali, uscite, anomalie. |
