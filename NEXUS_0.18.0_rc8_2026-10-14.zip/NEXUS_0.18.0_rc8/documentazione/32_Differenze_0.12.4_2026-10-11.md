# 32 · Differenze della 0.12.4 rispetto alla 0.12.3

11/10/2026 · Redatto da Claude · Schema Alembic **0016** (nuovo). Richieste di Federico dell'11/10/2026: «vorrei vedere un codice da testare» con i dati veri di Garda; anagrafica clienti unica ma distinta per ambiti.

## 1. Importazione di AD_dm (database `adsrl` di Garda)

Nuovo `gestionale/moduli/garda/importa_dm.py`. Si aggiunge a un archivio già creato da `ingecert` (prima AD_dpr, poi AD_dm). Il dump non viene mai eseguito: si leggono solo i valori. Tutto in una transazione: o entra tutto o niente. Si fa una volta sola: la seconda viene rifiutata.

| Cosa | Come entra |
|---|---|
| Clienti | Se esiste già un cliente con la stessa partita IVA o lo stesso codice fiscale si **fonde**: stesso record, nota «Anche cliente AD_dm in Garda (adsrl codice N…)». Altrimenti nuovo, con «Rif. gestionale attuale» `dm:<codice>`. Stessi controlli dell'importazione ingecert (P.IVA, CF, SDI, comune ISTAT). |
| Sedi operative | Sotto il cliente giusto, «Rif.» `dm:<codice>`. Le sedi «inattive» in Garda entrano non attive. Una sede con lo stesso indirizzo di una sede DPR dello stesso cliente **non si unisce**: si segnala in «Da controllare». |
| Attrezzature SC, SP, GVR | Matricola INAIL e informale, costruttore, modello, fabbrica, anno, classificazione (apparecchi all. 7, famiglia GVR, ID specifica: stessi ID dei cataloghi Garda), dati della scheda DM. Le dismesse restano dismesse. Valori storici non conformi alle regole attuali si **conservano e si segnalano**. |
| Camere GVR | Dal campo JSON di Garda: identificazione, n. fabbrica, volume in litri o DN, PS, TS, natura, stato, gruppo. |
| Date per componente | Ultima e prossima di funzionamento, integrità, visita interna, CND, verifica SC/SP, indagine supplementare, come **date iniziali dichiarate**: nessun verbale viene fabbricato. Nella nota c'è il numero dell'ultimo verbale di Garda. |
| Accessori | Valvole di sicurezza, dischi di rottura, valvole di intercettazione combustibile, con tipologia, DN, diametro, area, Ptar, taratura ultima/prossima e collegamenti alle attrezzature. |

Ogni bene conserva l'origine (`asset_origini`: sistema `garda_adsrl`, tabella, id) per i riallineamenti futuri.

**Non entrano ancora:** preventivi, verifiche/verbali, fatture AD_dm (passo D). Il database `iec` non si importa perché il modulo I&C non esiste ancora.

### Prova con il dump reale `adsrl_2026-10-07.sql` (dopo `ingecert_2026-10-07.sql`)

Eseguita qui; l'archivio risultante è rimasto in un'area di lavoro temporanea, non pubblicata. Tempo totale delle due importazioni: circa 40 secondi.

| Voce | Numero |
|---|---|
| Clienti adsrl | 776 = 176 fusi con clienti AD_dpr + 600 nuovi |
| Sedi | 1.080 (14 chiuse; 35 con lo stesso indirizzo di una sede DPR, segnalate) |
| Attrezzature | 7.729 GVR, 1.359 SC, 258 SP (491 dismesse) |
| Camere GVR | 5.460 |
| Accessori / collegamenti | 3.311 / 3.399 |
| Date iniziali | funzionamento 6.416, integrità 6.785, CND 5.188, interna 422, SC/SP 1.581, supplementare 716, taratura 3.040 |
| Segnalazioni da controllare | 1.186, di cui 810 «tipologia dell'accessorio non indicata in Garda» |

**Quadratura:** righe lette = righe importate per clienti, sedi, attrezzature e accessori. Il volume totale delle camere coincide al decimo di litro (37.252.774,6 l).

Da notare nei dati di Garda:
- 4 clienti adsrl hanno la stessa partita IVA di un altro cliente adsrl. Per questo i 176 clienti fusi diventano 172 clienti dell'anagrafica.
- 41 attrezzature hanno date di visita interna pur essendo di una famiglia che non la prevede.
- 40 camere non hanno né volume né DN leggibili.

## 2. Ambiti di lavoro su clienti e sedi (R114)

Richiesta: anagrafica clienti **unica**, ma negli elenchi ogni attività deve vedere solo i suoi clienti e le sue sedi. Ci sono clienti solo AD_dpr (impianti), clienti solo AD_dm o I&C (attrezzature) e clienti con entrambi.

- **Dati.** Cliente e sede hanno tre indicatori: AD_DPR, AD_DM, I&C (`ambito_dpr`, `ambito_dm`, `ambito_iec`, con indice). Migrazione **0016**.
- **Si accendono da soli** nella stessa transazione, per ogni scrittura del programma, importazioni comprese (`gestionale/moduli/anagrafica/ambiti.py`):
  - un impianto accende AD_DPR sulla sua sede e sul cliente;
  - un'attrezzatura o un accessorio SC/SP/GVR/PSV accende AD_DM;
  - un preventivo accende il suo ambito sul cliente (e sulla sede, se è un preventivo DM).
  - Una sede accesa accende sempre il suo cliente.
- **A mano.** Nella scheda del cliente e della sede ci sono le caselle «Ambiti di lavoro». Un cliente o una sede nuovi partono dall'attività scelta in alto (un prospect AD_dm senza attrezzature è già AD_DM). Una sede creata senza indicazione prende gli ambiti del cliente.
- **Si spengono solo se non servono più.** Un cliente non perde un ambito che una sua sede ha ancora. Una sede non perde AD_DPR se ha impianti non dismessi, né AD_DM se ha attrezzature o accessori non dismessi. Il messaggio spiega il motivo. Il cambio a mano resta nel registro con il prima e il dopo.
- **Elenchi.** In Clienti e Sedi operative c'è il pulsante «Solo AD_DM ✓», che segue l'«Attività» scelta in alto. Con un clic si passa a «Tutti gli ambiti»: la scelta si ricorda per quell'elenco su quel browser. Arrivando da un collegamento (es. «Sedi ← Cliente») si vede tutto. Il filtro vale anche per l'esportazione Excel. Le colonne AD_DPR / AD_DM / I&C e «N. attrezzature DM» si possono accendere, filtrare ed esportare.
- **Non è un controllo di autorizzazione.** Chi vede l'anagrafica vede tutto togliendo il filtro. Il permesso per ambito arriverà con i tre frontend.
- **Archivi esistenti (migrazione 0016).** Impianti → AD_DPR; attrezzature → AD_DM; preventivi → il loro ambito. Un cliente senza nulla diventa AD_DPR, perché fino alla 0.12.3 gli archivi erano di AD_dpr; una sede vuota prende gli ambiti del cliente.
- **Importazioni.** Tutto ingecert è AD_DPR, compresi i clienti senza impianti. Tutto adsrl è AD_DM.
- **Esito sui dati veri:**

  | Elenco | Solo AD_DPR | Solo AD_DM | Entrambi |
  |---|---|---|---|
  | Clienti | 1.738 | 600 | 172 |
  | Sedi | 2.674 | 1.080 | — |

- **Impianti, scadenze e verifiche DPR** restano elenchi solo DPR, già separati dal menu per attività. I&C non ha ancora oggetti propri: per ora l'indicatore si gestisce solo a mano.

## 3. Altro

- **Scheda accessori:** tipologia (valvola di sicurezza, disco di rottura, valvola di intercettazione combustibile), DN, diametro, area, pressione di taratura. Erano solo nel database di Garda (`adsrl/cust/meta/valvole_sicurezza.js`); ora si vedono e si salvano.
- **Password provvisoria.** `strumenti/importa_da_garda.py` mostra la password provvisoria di `admin` per **ultima**, dopo i rapporti, così non si perde nello scorrimento.
- **Nuovi file:** `AGGIUNGI_ADSRL_WINDOWS.bat` (adsrl in un archivio GARDA esistente). `IMPORTA_DA_GARDA_WINDOWS.bat` chiede anche il file adsrl.
- **Correzione trovata dai test nuovi:** con una configurazione delle camere illeggibile in Garda, la quadratura si fermava con un errore. Ora la camera si segnala e la quadratura prosegue.

## Test nuovi

| File | Test | Cosa controllano |
|---|---|---|
| `tests/test_garda_dm.py` | 4 | Dump finto con le stesse colonne di adsrl: fusione dei clienti, sedi chiuse e doppioni, classificazione, attributi, camere e volumi in formato italiano, date per componente e numero del verbale, attrezzatura senza sede, matricole doppie, JSON illeggibile, accessori, tarature, collegamenti doppi o mancanti, quadratura, ambiti, rifiuto della seconda importazione e di adsrl prima di ingecert; scheda degli accessori. |
| `tests/test_ambiti.py` | 3 | Accensione automatica da impianto, attrezzatura e preventivo; spegnimento rifiutato quando serve ancora; I&C a mano; elenchi ed esportazione filtrati per ambito; migrazione 0016 da dati esistenti. |

Aggiornato `tests/test_finanza.py`: dopo l'aggiornamento lo schema è 0016.

## Prove

| Prova | Esito |
|---|---|
| Suite completa, Linux, Python 3.13.16 | **231 passati** (`report_collaudo/pytest_0.12.4.txt`) |
| Importazione reale ingecert + adsrl | Quadratura senza differenze (§ 1) |
| Interfaccia (Chromium, ambiente di prova) | Clienti e Sedi con attività AD_DM: 1 cliente (DELTA, l'unico con attrezzature), 4 con «Tutti gli ambiti»; caselle nella scheda; nessun errore JavaScript |
| ruff sui file nuovi | Passato (restano gli avvisi preesistenti) |

## Domande aperte per Federico

1. Quando si sceglie la sede per un **nuovo preventivo DM**, la ricerca mostra tutte le sedi. Un cliente solo AD_dpr può diventare cliente AD_dm proprio così. Va bene, o preferisci vedere prima quelle AD_DM?
2. Le 35 sedi adsrl con lo stesso indirizzo di una sede DPR dello stesso cliente sono probabilmente la stessa sede. Le uniamo nella migrazione vera (passo B), con una tua conferma una per una?
