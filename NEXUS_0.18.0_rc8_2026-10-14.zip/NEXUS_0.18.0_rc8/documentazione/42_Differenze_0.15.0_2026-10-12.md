# 42 · Differenze della 0.15.0 rispetto alla 0.14.0

12/10/2026 · Redatto da Claude · Schema Alembic **0022** invariato: nessuna migrazione.

Richiesta di Federico (12/10/2026, 13:29): «verbali dm finiti (chiedi nel dubbio)». Riferimenti:
- R123 e documento 24 § 5;
- documento 28, punti 16–18: «esattamente come in VerbalizzAI», «anteprima pdf, ritocco eventuale in word», «firme», «PDF definitivo».

Questa versione porta il **percorso di emissione dei verbali DM** al livello di VerbalizzAI. Revisione e annullamento dei verbali emessi aspettano le risposte di Federico (§ 6).

## 1. I modelli restano quelli di AD

I verbali si generano dai modelli di AD già in uso: M14-PO01_dm rev. 02 per i GVR, M11-PO01_dm rev. 02 per SC/SP. I sette verbali di riferimento di Federico vengono da questi stessi modelli. Sono documenti del sistema di gestione, quindi **non sono stati modificati**: struttura, sezioni 1–4 (GVR) e punti 1–5 (SC/SP), testi, intestazione e piè di pagina restano uguali. Cambia solo il modo in cui il programma li impagina alla generazione (§ 2).

**PDF di prova da approvare**, con dati inventati, inviati con la consegna:
- anteprima e verbale firmato GVR;
- verbale firmato SC.

Se Federico vuole altre modifiche grafiche, come il numero «pag. X di Y» o il numero del verbale nel piè di pagina, servirà una nuova revisione dei modelli M14 e M11: è una decisione del sistema di gestione.

## 2. Anteprima come in VerbalizzAI

«**Genera anteprima PDF**» (linguetta Documenti dell'incarico registrato) produce Word e PDF con il nome «… - BOZZA»:
- **spazio della firma riservato**: al posto della firma c'è un riquadro tratteggiato con lo stesso ingombro della firma DM del tecnico, così all'emissione nulla si sposta;
- **riquadro firme intero**: le tabelle «Luogo, data», «Firme» e «Data della prossima verifica» non si dividono fra due pagine;
- **riquadro firme in fondo alla pagina**: come VerbalizzAI 1.0.0 rc3, una prima conversione misura dove cade il riquadro e la generazione aggiunge sopra lo spazio che manca al fondo dell'area di testo. La misura usa LibreOffice; se non riesce, il riquadro resta dove cade, sempre intero;
- **niente pagine bianche finali**: il paragrafo vuoto che chiude il modello si riduce a 1 punto.

**Firma DM obbligatoria.** Senza la firma DM del tecnico l'anteprima non si genera, e il messaggio dice dove caricarla.

**Ritocco Word**, come prima: si scarica il Word dell'anteprima, si cambia solo l'impaginazione e lo si ricarica. Il controllo dei dati resta quello della 0.12. Il riquadro tratteggiato della firma va lasciato al suo posto.

## 3. Firma ed emissione

«**Firma ed emetti il verbale**» compare dopo aver controllato l'anteprima, il cui PDF è mostrato nella scheda.

1. **Presa visione:** si conferma l'anteprima vista, con lo stesso documento e la stessa impronta.
2. **Firma:** la firma DM del tecnico prende il posto del riquadro tratteggiato, con lo stesso ingombro. Il PDF firmato deve avere **lo stesso numero di pagine** dell'anteprima; se no, l'emissione si ferma e chiede di rigenerare l'anteprima.
3. **Controlli:**
   - se il ritocco Word ha tolto il riquadro della firma, l'emissione si ferma e lo spiega;
   - se dati o firma sono cambiati dopo l'anteprima, l'emissione si ferma e chiede di rigenerarla.
4. **Emissione:** il verbale firmato (Word e PDF) diventa il definitivo. L'anteprima resta in archivio come sostituita. Seguono le scadenze, i CND, la copia nella cartella dei verbali DM con nome INAIL e nome leggibile, e l'invio.

La firma, che richiede LibreOffice, si prepara fuori dalla transazione di scrittura, come la generazione: il programma non resta bloccato durante la conversione.

Un **PDF caricato già pronto** (firmato a parte) si emette com'è, come prima.

## 4. «Aggiorna / Conserva i dati del verbale»

All'emissione si sceglie (documento 24 § 4.2):
- **Aggiorna** (predefinito): i dati che passano da un verbale al successivo (accessori, acqua e conduttore, conservazione, osservazioni, testi SC/SP) diventano quelli di questo verbale, come prima;
- **Conserva**: l'attrezzatura mantiene i dati che aveva. Si registra una versione «conservata» con la data del verbale, visibile in «Dati del verbale» con la provenienza. È utile quando un verbale ha dati validi solo per sé (es. una valvola provvisoria). Il verbale emesso resta con i suoi dati.

## 5. Prove

| Prova | Esito |
|---|---|
| `tests/test_verbali_dm_finiti.py` (nuovo, 5 test) | emissione rifiutata se con la firma le pagine passano da 1 a 2; ritocco Word che toglie il riquadro firma: anteprima «BOZZA» accettata, emissione rifiutata con spiegazione; «conserva» mantiene gli accessori precedenti con provenienza «conservata» mentre il verbale tiene i suoi dati, scelta non valida rifiutata; riquadro firme con righe non divisibili, distanziatore «mantieni con il successivo», segnalibro di misura; **LibreOffice reale**: riquadro già in fondo nell'anteprima e stesse pagine fra anteprima e firmato |
| `tests/test_dm_documenti.py` (aggiornati) | senza firma DM niente anteprima; anteprima con spazio riservato e senza firma; dopo l'emissione la firma DM è nel Word definitivo («firmato»); i test di prova caricano la firma DM del tecnico |
| PDF di prova con LibreOffice reale (GVR e SC, dati inventati; ambiente di prova con le firme DM dei tecnici) | riquadro firme in fondo alla pagina, firma al posto del riquadro, nessuna pagina bianca; GVR 2 pagine, SC 1 pagina, uguali fra anteprima e firmato |
| Prova dell'interfaccia con Chromium | Verifiche GVR e scheda dell'incarico senza errori JavaScript |
| Suite completa | **297 test passati** (Linux, Python 3.13, LibreOffice reale per i test «pdf_vero»), `report_collaudo/pytest_0.15.0.txt` |

## 6. Non fatto in questa versione

- **Revisione** di un verbale DM emesso (stesso numero, «sostituisce il verbale n. … emesso il …», rimessa in rendicontazione INAIL?) e **annullamento** di un verbale emesso: domande inviate a Federico il 12/10. Si fanno nella 0.15.1 con le sue risposte. Resta valido il riesame negativo, che riapre il verbale come prima (R108).
- **Verifiche storiche di adsrl** (0.13.3 del piano precedente): richiedono l'importazione di preventivi, verifiche e fatture AD_dm dai dump, che finora entrano solo come anagrafiche e attrezzature. La metto con l'importazione completa e la migrazione a secco dei tre database (documento 18 § 7), che va provata sui dump veri del PC di Federico.
