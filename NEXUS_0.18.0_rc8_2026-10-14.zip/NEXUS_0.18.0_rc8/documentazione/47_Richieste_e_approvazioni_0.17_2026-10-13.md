# Richieste e approvazioni dopo la 0.16 — 13/10/2026

Estratto delle note originali: analisi e richieste, non attestazione di collaudo. Lo stato finale è nel documento 45. C17–C19 si leggono nel documento 36 consegnato. Nessuna assegnazione autonoma di R144 e seguenti.

## C20 · Permessi Impianti AD_DPR e Attrezzature AD_DM distinti e riconoscibili (13/10, 10:53)

**Solo annotato e ragionato. Nessuna modifica al codice.** Base letta: NEXUS 0.16.0, schema 0027. Federico allega la schermata «Permessi per ruolo».

**Testo esatto di Federico:** «aggiungo degli elementi. quando nei permessi si parla di "Impianti" (creare e modificare, etc.) si parla di AD_dpr, giusto? e per le attrezzature (GVR, sc, sp)? non scrivere codice, annota e ragiona»

**Riscontro sui sorgenti, non prova applicativa:**
- «Creare e modificare impianti» è `anagrafica.impianti`; «Segnare un impianto come dismesso» è `anagrafica.dismetti`. Le API protette sono quelle degli impianti DPR, non delle attrezzature GVR/SC/SP.
- Per le attrezzature esiste già il gruppo **Attrezzature (AD_DM)**: `beni.vedere`, `beni.gestire`, `beni.scadenze`, `beni.dismetti`. La modifica comprende attrezzature, camere e associazioni con gli accessori; la dismissione riguarda attrezzature e accessori. I permessi sono comuni ai gruppi GVR, SC, SP e PSV: non esistono permessi distinti per ciascun gruppo.
- Clienti e sedi sono anagrafiche condivise. Gli impianti DPR e le attrezzature DM sono oggetti diversi, con permessi diversi.
- **Assegnazione da valutare:** nella schermata anche RT DM ha spuntato «Creare e modificare impianti» e «Segnare un impianto come dismesso». È coerente con l'inizializzazione attuale: i ruoli RT DPR e RT DM ereditano questi permessi. Le API degli impianti richiedono il relativo permesso ma non l'attività DPR; i permessi delle anagrafiche e `beni.*` non fanno parte dell'insieme `TECNICI` a cui si applica la separazione per attività. Non basta quindi rinominare una voce per circoscrivere chi può usarla.

**Proposta da valutare, non decisione acquisita:** rendere la matrice leggibile con gruppi **Anagrafiche comuni**, **Impianti AD_DPR**, **Attrezzature AD_DM**, **Accessori PSV** e operazioni con nomi pertinenti. Prima di modificare assegnazioni o controlli, chiarire se la gestione del parco è comune a entrambi gli RT o limitata all'attività del ruolo. Questa scelta è distinta dai permessi di esecuzione e riesame, già separati per attività. Nessuna richiesta di separare ulteriormente GVR da SC/SP viene dedotta dalla domanda.

**File letti:** `gestionale/core/permessi.py`, `gestionale/moduli/utenti/accesso.py`, `gestionale/web/dipendenze.py`, `gestionale/moduli/anagrafica/api.py`, `gestionale/moduli/beni/api.py`.

---

## C21 · Posizione e logica dei pulsanti nelle griglie (13/10, 10:54)

**Solo annotato e ragionato. Nessuna modifica al codice.** Federico allega la barra dell'elenco Verifiche AD_DPR.

**Testo esatto di Federico:** «la posizione dei pulsanti non mi convince molto, dobbiamo trovare un logica»

**Cosa si vede e riscontro sui sorgenti:** ricerca, raggruppamento, Colonne, Configurazioni, Azzera filtri, Esporta Excel, Aggiorna, filtri rapidi e azioni sulle verifiche sono nella stessa barra, che va a capo. «Fattura le selezionate…» precede «Affida le selezionate…», benché l'affidamento preceda la fatturazione nel flusso. `static/js/verifiche.js` passa filtri e azioni nella stessa lista `pulsanti`; `static/js/griglia.js` li aggiunge tutti a `griglia-barra`.

**Proposta di logica comune alle griglie, da valutare:**
1. **Filtri di lavoro:** una zona dedicata a Tutte, Da assegnare, Le mie, Da registrare, Programmate, Verbale da compilare, Da riesaminare, Da fatturare. Ordine pertinente al percorso di lavoro; stato attivo riconoscibile. «Le mie» è un criterio personale, non uno stato della verifica: va distinto visivamente.
2. **Comandi della griglia:** ricerca, raggruppamento, colonne e viste salvate nella zona della consultazione; Esporta e Aggiorna come comandi secondari. Restano separati dalle operazioni che cambiano i dati. Si coordina con C17–C19 per filtri, raggruppamenti e prime colonne.
3. **Azioni sulle righe selezionate:** barra separata vicina alla tabella, con il numero di righe selezionate. Le azioni mantengono una posizione stabile e sono ordinate secondo il flusso: nella schermata allegata Affida precede Fattura. Si mostrano solo le azioni consentite dal ruolo; si abilitano quando la selezione è compatibile, spiegando altrimenti il motivo. Non vengono introdotte operazioni multiple oggi assenti solo per riempire la barra.

La proposta va applicata in modo coerente a DPR e DM, preventivi, verifiche, attrezzature e scadenze, con le azioni pertinenti a ciascuna pagina. Le azioni della singola scheda restano nella scheda; la selezione di righe non equivale a cambiare lo stato o ad accettarle. Non è ancora un'impaginazione approvata e non cambia permessi o controlli del backend.

---

## C22 · Casella cumulativa per i requisiti del riesame del contratto con esclusioni individuali (13/10, 10:56)

**Solo annotato e ragionato. Nessuna modifica al codice.** Federico allega «Nuovo riesame del contratto», con quattro requisiti, esito, note e «Registra il riesame».

**Testo esatto di Federico:** «da aggiungere flag cumulativo, con possibilità di deflag parziale (in caso di esito non cofnorme)»

**Richiesta annotata:** aggiungere una casella generale **Seleziona tutti i requisiti**, che permette di spuntare insieme i quattro requisiti del riesame. Le singole caselle devono restare modificabili, così si possono deselezionare i requisiti non soddisfatti senza perdere quelli conformi. La richiesta riguarda i requisiti di un riesame, non il riesame in blocco di più preventivi.

**Proposta di comportamento:**
- tutte le caselle spuntate: casella generale spuntata;
- alcune spuntate e altre no: casella generale nello stato di selezione parziale;
- nessuna spuntata: casella generale non spuntata;
- il comando generale seleziona o deseleziona tutte; modificare una casella individuale aggiorna lo stato di quella generale;
- l'esito resta una scelta esplicita. Il flag generale non registra il riesame, non rende automaticamente conforme l'esito e non sostituisce «Registra il riesame»;
- restano i controlli esistenti: conforme solo con tutti i requisiti soddisfatti; per non conforme, note su motivo e azione decisa. Non viene dedotta una modifica dei requisiti o del loro valore nello storico.

**Riscontro sul codice:** `static/js/preventivi.js` costruisce quattro caselle distinte nel modulo del riesame; non c'è una casella generale per i requisiti. Da coordinare con il servizio del riesame e con lo storico già richiesto, per DPR e DM.

---

## C23 · Righe del preventivo nel contesto del singolo preventivo e colonne essenziali (13/10, 10:58)

**Solo annotato e ragionato. Nessuna modifica al codice.** Federico allega l'elenco «Righe dei preventivi» con righe di più preventivi.

**Testo esatto di Federico:** «righe dei preventivo "globale" non ha senso, deve essere sempre accessibvile dagli elementi collegati di preventivo e puntare alle righe del singolo preventivo. n.b. le colonne da visualizzare sono sede operativa, stato riga, tipo verifica, impianto tipologia tariffa applicata, stato verifica, verificatore, da fatturare»

**Richiesta annotata:**
1. La vista globale «Righe dei preventivi» non deve essere proposta come elenco autonomo. L'accesso parte dagli **elementi collegati del preventivo** e porta sempre alle righe di **quel solo preventivo**.
2. Il preventivo di contesto deve restare riconoscibile nel titolo e durante ricerca, filtri, raggruppamento, selezione ed esportazione. Il vincolo del preventivo deve rimanere anche usando Tutte o Azzera filtri, altrimenti si torna alla vista globale che Federico ha escluso.
3. La vista iniziale mostra, in quest'ordine, le colonne richieste. La sequenza «impianto tipologia tariffa applicata» è trascritta sopra esattamente; qui viene letta come tre colonne distinte:
   - Sede operativa;
   - Stato riga;
   - Tipo verifica;
   - Impianto;
   - Tipologia;
   - Tariffa applicata;
   - Stato verifica;
   - Verificatore;
   - Da fatturare.
4. Caselle di selezione e comandi di riga restano strumenti operativi, separati dalle colonne informative. Identificativi tecnici, tariffa standard e sconto non occupano la vista iniziale richiesta.

**Riscontro sui sorgenti:** oggi esistono le voci di menu globali `/righe-preventivi` e `/righe-preventivi-dm`. Nell'elenco preventivi esiste già il collegamento «Righe ← Preventivo», che passa il filtro `preventivo_id`. La modifica richiesta riguarda accesso e contesto dell'elenco: il semplice filtro eliminabile non basta a garantire il vincolo del singolo preventivo. File interessati dalla lettura: `web/pagine.py`, `static/js/preventivi.js`, `static/js/righe_preventivi.js`, `moduli/preventivi/griglie.py`, `static/js/griglia.js`.

**Effetti da coordinare, senza dedurre nuove decisioni:** la fatturazione e l'affidamento dalle righe continuano nel contesto del preventivo; il punto aggiorna la presentazione del percorso R125. La fatturazione dalla verifica prevista da R139 è un altro punto di accesso già esistente e non viene revocata da questa osservazione. Per il corrispondente elenco DM, valutare l'etichetta Attrezzatura al posto di Impianto e i campi GVR/SC/SP pertinenti, conservando lo stesso principio del singolo preventivo.

---

## C24 · Affidamento della verifica e utenti importati inattivi (13/10, 11:00)

**Solo analizzato e annotato. Nessuna modifica al codice o agli utenti.** Federico allega Utenti e permessi e la finestra «Affidare la verifica?».

**Testo esatto di Federico:** «qualcosa non va con i permessi, perché non riesco ad affidare l'incarico di verifica ad un verificatore?»

**Riscontro:** nella schermata i verificatori e RT importati mostrati sono **Attivo: No**; i due utenti selezionabili nella finestra sono amministratori attivi. `moduli/verifiche/servizio.py::verificatori` prende solo utenti attivi, con almeno un ruolo attivo pertinente all'attività e il permesso `verifiche.esegui`. Il ruolo Amministratore comprende quel permesso. L'importatore `moduli/garda/importa.py` crea intenzionalmente gli utenti importati con `attivo=False`, password generata e cambio password richiesto.

**Diagnosi del caso mostrato:** il verificatore atteso è escluso perché inattivo; le immagini non mostrano un errore di autorizzazione di chi affida. Serve aprire la scheda dell'utente destinato alle prove, verificare il ruolo DPR o DM pertinente e riattivarlo; quindi aggiornare l'elenco di affidamento. Per eventuale accesso dell'utente si gestisce la sua password provvisoria dal programma. Non sono state usate credenziali né modificati utenti.

**Miglioramento proposto per la prossima versione:** rendere evidente nell'importazione e nell'affidamento che gli utenti importati sono inattivi, con indicazione su dove riattivarli. Distinguere i due requisiti: chi affida deve poter assegnare nell'attività; chi riceve deve essere attivo e poter eseguire nell'attività. I controlli esistenti restano applicati; non viene dedotta una richiesta di attivazione automatica di tutti gli utenti importati.

---

## Valutazione congiunta C17–C26 prima della versione successiva (13/10, 11:01; aggiornata alle 11:09)

**Richiesta esatta di Federico:** «ora analizza tutti i punti emersi sinora, discutiamo eventuali problematiche o scelte dicrezionali poi scriviamo e testiamo il codice della versione successiva.»

**Fase attuale:** analisi per il confronto con Federico. Il codice NEXUS 0.16.0 è inalterato; i controlli seguenti sono lettura dei sorgenti e delle schermate, non nuovi test passati. La prossima versione proposta è **0.17.0**; versione e migrazione definitive si confermano sul cambiamento effettivo. La numerazione R resta nel registro unico del progetto; non vengono assegnati nuovi R qui.

### Problemi e vincoli di realizzazione

1. **C17, filtri.** I filtri testuali attuali del motore trattano il testo come «contiene». Per Inizia con, Finisce con e Uguale a servono anche operatori nel backend, oltre al controllo della colonna. I periodi di date esistono già con la sintassi testuale: la finestra Da/A e i pulsanti rapidi devono usare gli stessi limiti, includere tutto l'ultimo giorno e mantenere il corretto fuso nelle colonne data/ora. Ricerca, export e viste salvate devono usare lo stesso filtro. Le configurazioni già salvate vanno conservate e lette con il significato precedente.
2. **C17, ordine.** Scadenze DPR e DM hanno già la prossima data ascendente come ordine del backend. Il cambio di raggruppamento in `griglia.js`, però, sostituisce l'ordinamento con il solo campo del gruppo, perdendo la data. Le attrezzature sono invece ordinate per sede/reparto/matricola. Non basta cambiare le colonne: vanno composti raggruppamento e ordine per prossima data.
3. **C17–C19, gruppi e colonne.** Cliente e Sede operativa vanno proposti prima degli altri raggruppamenti sensati. Nelle Scadenze, la prima colonna informativa è Cliente nel DPR e Sede operativa nel DM. Le caselle di selezione e le azioni non contano come colonne informative. Oggi il raggruppamento è applicato alla singola pagina; ordinamento e paginazione devono essere coerenti e non presentare i conteggi della pagina come totali dell'intero gruppo.
4. **C20, permessi.** I nomi vanno resi espliciti, ma la questione delle assegnazioni è distinta: oggi anagrafiche e gestione dei beni sono comuni nei controlli, anche quando l'oggetto è DPR o DM. Serve la scelta operativa sotto indicata prima di cambiare i permessi di RT e verificatori. Clienti e sedi restano condivisi; l'ambito del cliente non è un'autorizzazione.
5. **C21, pulsanti.** Filtri di lavoro, controlli della vista e azioni sulle righe selezionate devono avere tre zone stabili. I comandi sulle righe sono ordinati secondo il flusso e dipendono da ruolo e selezione. La stessa regola vale nelle griglie DPR e DM, con le azioni già supportate da ciascuna pagina.
6. **C22, casella cumulativa.** Il flag generale agevola la compilazione dei quattro requisiti; non cambia la registrazione o l'esito. Nel servizio esistono già i blocchi per conforme con requisiti incompleti e non conforme senza nota: vanno mantenuti e provati anche dopo il nuovo controllo.
7. **C23, contesto delle righe.** Oggi il collegamento del preventivo imposta un normale filtro di colonna. `Tutte`, `Azzera filtri`, il pulsante Togli il filtro e l'applicazione di una vista salvata possono rimuoverlo. Per la nuova vista del singolo preventivo serve un contesto distinto dai filtri dell'utente, applicato a dati ed esportazione. La vista globale va tolta dagli accessi ordinari. Le nove colonne richieste diventano la vista iniziale DPR; in DM il riferimento è all'attrezzatura e alla sua attività. Affidamento e fatturazione restano collegati alle stesse righe commerciali.
8. **C24, affidamento.** Il caso mostrato dipende dagli utenti inattivi. Si propone un'indicazione chiara per l'operatore, conservando il filtro degli utenti attivi e i controlli per attività. La riattivazione effettiva degli utenti di Federico si fa sul suo archivio, non nel codice né automaticamente dall'import.
9. **C25, Salva e chiudi. Priorità alta.** La scheda Utente ha salvataggi separati che condividono la versione dell'utente ma non la aggiornano tutti nell'interfaccia. Il controllo di concorrenza può quindi scattare dopo un salvataggio effettuato dallo stesso operatore. Vanno coordinati i dati anagrafici/ruoli, il profilo tecnico e la firma, preservando i conflitti reali fra operatori. Proposta: Salva e Salva e chiudi seguono un solo percorso coerente per i dati della scheda; gli eventuali caricamenti immediati della firma riallineano la versione comune e non eliminano le modifiche in corso. Il caso va riprodotto, senza considerare l'analisi del sorgente una prova già passata.
10. **C26, caricamento Word. Priorità alta.** L'errore osservato viene dal controllo sul PDF allegato o ottenuto da LibreOffice, non dal limite del Word. Lo stesso messaggio copre formato PDF non riconoscibile e dimensione PDF oltre 25 MB. Serve riprodurre il caso, distinguere le cause e rendere chiaro il percorso Word precedente rispetto a definitivo della verifica corrente. Modulo e numero si verificano nel contenuto del Word; per il definitivo devono corrispondere alla verifica. La correzione appartiene all'integrazione NEXUS e non autorizza modifiche a VerbalizzAI.

### Due scelte da discutere

**Gestione del parco per ruolo.** Proposta: RT DPR gestisce gli impianti DPR; RT DM gestisce attrezzature e accessori DM; amministratore e segreteria restano comuni. Alternativa: mantenere la gestione anagrafica del parco comune a entrambi gli RT, con nomi e gruppi chiari nella matrice. La scelta riguarda la gestione del parco; non modifica la separazione di esecuzione e riesame già prevista da R132/R143.

**Ordine dei gruppi nelle Scadenze.** Proposta: clienti/sedi ordinati per la prima scadenza filtrata del gruppo, dalla più urgente; dentro ogni gruppo date crescenti e valori mancanti in fondo. Alternativa: gruppi alfabetici, sempre con date crescenti dentro il gruppo. Una lista piatta totalmente cronologica e una lista a gruppi rispondono a due criteri diversi: il programma può offrire entrambe le viste, ma serve definire la predefinita.

### Verifiche previste prima della consegna

- Filtri testuali nei quattro modi, caratteri speciali e risultati uguali fra elenco ed Excel; date singole e intervalli con limiti inclusivi, fine mese/anno e date/ora.
- Ordine delle scadenze dentro i gruppi e fra pagine, gruppi predefiniti, prime colonne e configurazioni salvate preesistenti.
- Permessi per ruoli singoli e multipli, controlli sulle API oltre ai pulsanti, utenti inattivi esclusi e ruoli dell'attività corretta nell'affidamento.
- Flag generale del riesame nei tre stati, esclusioni individuali e conferma dei controlli backend su esito e note.
- Scheda Utente: dati tecnici e firma seguiti da Salva/Salva e chiudi, sequenza inversa, clic ripetuti e conflitto reale fra due sessioni; nessuna perdita delle modifiche e una sola registrazione dell'operazione richiesta.
- Word DPR: caricamento senza PDF con conversione LibreOffice reale, PDF valido allegato, PDF non valido e oltre limite; DOCX di circa 1,2 MB; numerazione o modello errati; mancata conversione. Messaggi distinti e nessuna chiusura o archivio parziale in errore. Il DOCX effettivo e i log dell'ambiente di Federico non sono ancora disponibili.
- Due preventivi distinti: Tutte, Azzera, viste salvate, paginazione ed esportazione non fanno uscire dal preventivo di contesto; righe, affidamento e fatturazione pertinenti.
- Prova dell'interfaccia alle larghezze di uso, con barre stabili e nessun errore JavaScript, seguita dalla suite completa.

**Consegna prevista:** ZIP NEXUS della versione successiva, README, differenze rispetto alla 0.16.0, comandi e risultati delle prove effettive, note e ripresa aggiornate. Restano fuori da questo incremento XML/Aruba, nuove funzioni I&C/EX e modifiche a VerbalizzAI, salvo nuova istruzione di Federico.

---

## C25 · Salva e chiudi nella scheda Utente genera un conflitto di versione (13/10, 11:05)

**Solo analizzato e annotato. Nessuna modifica al codice.** Federico allega la scheda Utente, con dati tecnici e firma DM, e il messaggio di conflitto. I dati personali e l'immagine della firma non vengono riportati in questo documento.

**Testo esatto di Federico:** «se faccio salva e chiudi mi da questo errore»

**Messaggio osservato:** «Il dato è stato modificato da un altro utente mentre lo stavi modificando: ricarica la pagina e ripeti la modifica.»

**Riscontro sui sorgenti:**
- `static/js/utenti.js` conserva l'utente letto all'apertura e invia `u.versione` con il PUT dei dati anagrafici/ruoli.
- `static/js/schede.js::datiTecnico` conserva una propria variabile `versione`; i salvataggi del profilo tecnico e della firma DM aggiornano questa variabile, ma non quella della scheda Utente che contiene il pulsante principale.
- Il backend usa la stessa riga Utente e incrementa `Utente.versione` sia per anagrafica/ruoli sia per profilo tecnico e firma.
- `base.js::conChiudi` esegue la stessa azione del pulsante Salva e poi chiude la scheda: il conflitto non dimostra che un'altra persona abbia effettivamente modificato il dato.

**Percorso che può produrre il problema:** scheda aperta alla versione N → salvataggio di profilo tecnico o firma DM, versione N+1 → Salva e chiudi invia ancora N → conflitto. Il meccanismo è riscontrato nel codice; la sequenza esatta compiuta da Federico non è stata acquisita e non è ancora stata eseguita una prova di riproduzione. Anche i salvataggi anagrafici e tecnici nell'ordine inverso devono essere verificati.

**Correzione proposta per la prossima versione:** coordinare tutti i salvataggi della scheda e la versione corrente, non togliere il controllo di concorrenza. Salva e Salva e chiudi devono avere lo stesso significato sui dati della scheda; la differenza è la chiusura dopo il successo. In errore la scheda conserva i dati inseriti e resta aperta. Va impedita la doppia esecuzione durante una richiesta in corso. I caricamenti immediati della firma devono riallineare la versione senza cancellare le modifiche anagrafiche non ancora salvate.

**Rimedio temporaneo:** chiudere e riaprire la scheda, verificare quali dati sono già salvati e ripetere solo ciò che manca. La riattivazione dell'utente resta un'azione distinta (C24): nella schermata l'utente è ancora inattivo.

---

## C26 · Caricamento Word di circa 1,2 MB con errore riferito al PDF (13/10, 11:09)

**Solo analizzato e annotato. Nessuna modifica al codice.** Federico allega il caricamento del Word nella scheda di una verifica DPR. Il file Word non è allegato a questa analisi; sono disponibili la schermata e la dimensione dichiarata.

**Testo esatto di Federico:** «se carico un word che pesa circa 1,2 Mb mi da questo errore!»

**Messaggio osservato:** «Il PDF non è valido (massimo 25 MB).»

**Riscontro sui sorgenti:**
- `static/js/verifiche.js` invia il DOCX nel campo `word`; invia `pdf_file` solo se l'operatore ha selezionato un PDF.
- `moduli/verifiche/api.py` legge Word e PDF separatamente, fino a 25 MB più un byte; in assenza del PDF passa `None` al servizio.
- `moduli/verifiche/servizio.py::carica_verbale` genera il PDF con `core/pdf.py::da_word` se non è stato fornito. Poi produce il messaggio osservato se i byte non iniziano con `%PDF` **oppure** se il PDF supera 25 MB.
- `core/pdf.py` usa LibreOffice e restituisce il file generato; i messaggi per LibreOffice mancante, timeout o nessun PDF sono diversi da quello osservato.

**Conclusione verificabile:** l'errore arriva al controllo del PDF. Non dimostra che il Word di 1,2 MB sia troppo grande. Le due cause del messaggio attuale sono indistinguibili nella schermata. Non si può stabilire quale si sia verificata senza il PDF o i dettagli della conversione; non è stata eseguita una riproduzione del caso.

**Ulteriore verifica sul percorso usato:** il nome del Word nella schermata richiama un verbale precedente, con anno e numero diversi dalla verifica aperta. Il nome da solo non prova il contenuto. Per precompilare dalla verifica precedente il percorso è «Carica il verbale precedente»; per caricare il definitivo, il modulo e il numero letti **dentro il Word** devono corrispondere alla verifica registrata, come controlla già il servizio. L'errore sul PDF viene prima di questi controlli, quindi può nascondere il successivo errore di corrispondenza.

**Intervento proposto per la prossima versione:** separare dimensione e formato di Word e PDF nei messaggi, verificare il Word e i suoi riferimenti prima di una conversione inutile, verificare il risultato della conversione e conservare i dettagli tecnici nel log. Rendere più chiaro in interfaccia il caricamento del Word precedente rispetto a quello del definitivo. Mantenere i limiti e i controlli di corrispondenza; nessuna modifica a VerbalizzAI viene dedotta da questo caso. I test della conversione devono usare un DOCX sintetico, senza dati reali di clienti.

---

## C27 …

(altre osservazioni del collaudo della 0.16.0 a seguire)


## Approvazioni del 13/10/2026 — versione successiva

Testi esatti di Federico, successivi all’analisi C17–C26:

> per gruppi scadenze ok

> per gestione parco come hai indicato tu. proceci

> procedi pure

Scelte approvate: gruppi delle scadenze ordinati dalla prima scadenza più urgente, date crescenti dentro ciascun gruppo; gestione impianti AD_DPR riservata ai ruoli DPR e gestione attrezzature AD_DM (GVR, SC, SP, PSV) ai ruoli DM, mantenendo i ruoli comuni secondo i permessi assegnati. Autorizzata l’implementazione e il collaudo della versione successiva. Nessun numero R attribuito qui: registrazione definitiva nel registro canonico da R144.


## C27 — PostgreSQL e importazione completa Garda (13/10/2026)

Richiesta esatta:

> ora un tema "delicato", mi è stato sconsigliato di usare sqlite per lo sviluppo del gestionale integrato, ma usare postgre. tieni anche conto che quando andremo in produzione sarà ESSENZIALE riuscire a fare un'importazione completa e coerente del database (MariaDB) del gestionale garda informatica. come mi consigli di procedere per minimizzare gli errori?

Approvazione esatta:

> ok concordo procediamo prima con 0.17 con correzioni approvate e dopo passaggio a postgreSQL. nmi raccomando documenta tutto a latere così che io possa proseguire con un'altra istanza di LLM

Decisione: chiudere prima 0.17 su SQLite; subito dopo dedicare una versione al database principale PostgreSQL, usato anche in sviluppo e collaudo, prima di ulteriori funzioni. Nessun supporto PostgreSQL implementato o collaudato in 0.17. VerbalizzAI 1.0.1 rc2 preservato: archivio SQLite interno da valutare separatamente, non convertito automaticamente.

Analisi del codice: dipendenze SQLite nella connessione/PRAGMA, query date e group_concat, backup/ripristino; serializzazione delle scritture tramite RLock del singolo processo. Numerazioni, registro a catena e controllo delle versioni vanno verificati con transazioni e più processi PostgreSQL. SQLAlchemy/Alembic aiutano ma non rendono portabile automaticamente il prodotto.

Percorso raccomandato: inventario completo schema e allegati Garda; estrazione coerente MariaDB su copia fedele immutabile; trasformazioni versionate e mappa (archivio, tabella, ID originale) → ID NEXUS; importazione diretta nel modello PostgreSQL senza passaggio dal modello SQLite NEXUS. Ogni tabella/campo deve avere una destinazione o un'esclusione motivata approvata. Storico senza generare effetti operativi nuovi. Controlli automatici di collegamenti, duplicati, date, codifiche, stati, numerazioni, allegati/hash e riconciliazione economica; nessuno scarto silenzioso. Prove ripetibili, riesecuzione senza duplicati, prova generale su copia recente completa, backup e ripristino verificati. Al passaggio finale: sospensione scritture Garda, estrazione finale, importazione, riconciliazione e apertura NEXUS; ritorno a Garda prima della riapertura o procedura per recuperare eventuali nuove scritture NEXUS. Importatore attuale non completo.

Fonti primarie consultate: https://www.sqlite.org/whentouse.html ; https://www.postgresql.org/docs/current/ddl-constraints.html ; https://mariadb.com/docs/server/clients-and-utilities/backup-restore-and-import-clients/mariadb-dump . Snapshot --single-transaction coerente per tabelle transazionali, con attenzione alle modifiche DDL; non promessa per intero archivio senza inventario dei motori delle tabelle.

## C28 — Vietato riesaminare il proprio verbale (13/10/2026)

Richiesta esatta:

> aggiungo un elemnento: il verificatore (RT Federico nell'esempio) NON deve poter riesaminare il proprio vverbale!

Screenshot letto: esecutore e autore del riesame coincidono nell'esempio DPR. Non si riportano dati del cliente né si incorpora lo screenshot. Regola autorizzata: nessun verificatore, anche RT o amministratore, può riesaminare il proprio verbale; occorre un altro utente con permesso di riesame nell'attività. Protezione server, interfaccia e operazioni DM in blocco (tutto o niente). Non si alterano retroattivamente i riesami esistenti: individuazione e rimedio degli eventuali casi pregressi richiedono verifica separata dell'archivio operativo, qui non fornito.
