# NEXUS 0.17.0 — sole differenze rispetto alla 0.16.0

13 ottobre 2026. Base: ZIP `NEXUS_0.16.0_2026-10-12_1.zip`, SHA-256 `9f715435fc3f27dcf37e5d11b534ba1b277b2046c81a0ff5595009d876e69639`. Versione applicativa **0.17.0**, schema **0027 invariato**, VerbalizzAI **1.0.1 rc2 invariato byte per byte**. Nessun database operativo o account reale modificato.

## Funzioni modificate

| Punto | Differenza effettiva |
|---|---|
| C17 filtri | Tre comandi sopra ogni colonna: filtra, cancella, nascondi; testo contiene/inizia/finisce/uguale, caratteri `%` e `_` trattati letteralmente. Filtri strutturati anche sul server e sugli elenchi in memoria. Vecchie stringhe salvate mantengono «contiene». |
| C17 date | Intervallo Da/A inclusivo, anche con un solo limite; Non valorizzato; Ieri/Oggi/Domani, mesi e anni precedente/corrente/successivo, ultimi/prossimi 8 giorni. Date/ora per intere giornate italiane, compreso cambio ora legale. |
| C17–C19 scadenze | Cliente DPR e sede DM in prima colonna informativa Scadenze; gruppi iniziali corrispondenti. Ordine dei gruppi dalla prima data dell'intero risultato filtrato, date crescenti all'interno, senza data in fondo. Attrezzature GVR/SC/SP e griglia Attrezzature ordinate per prossima scadenza, anche con raggruppamento. Il conteggio visibile del gruppo resta quello della pagina ed è indicato come tale. |
| C18 | Cliente e sede fra le prime scelte; elenco raggruppamenti ridotto ai campi sensati. Gruppi di vecchie viste salvate conservati anche se fuori dalle scelte consigliate. |
| C20 | Gestione impianti e dismissione implicano DPR; gestione attrezzature, date iniziali e dismissione implicano DM. Il permesso viene dal ruolo dell'attività, anche con ruoli multipli. API protette e UI coerente; etichette esplicite e matrice «altra attività». Amministratore/segreteria e ruoli comuni secondo concessioni. Permessi di lettura delle anagrafiche non ulteriormente ristretti. |
| C21 | Filtri di lavoro, strumenti della vista e azioni sulla selezione in zone distinte; Le mie distinto come filtro personale. Conteggio delle selezionate, azioni nell'ordine affida/registrazione/riesame/fattura ove già supportate, disabilitazione con motivo nei casi verificabili dal dato della riga. Controlli finali sempre sul server. Nessuna nuova operazione in blocco inventata. |
| C22 | Casella cumulativa dei quattro requisiti del riesame contratto, deflag singoli e stato parziale. Esito manuale; nessuna dichiarazione automatica di conformità. Controlli e storico esistenti mantenuti. |
| C23 | Tolto il menu globale delle righe e i collegamenti globali da altri oggetti; accesso dagli elementi collegati di ogni preventivo DPR/DM. Context ID obbligatorio sul server per dati/Excel, verificato nell'attività; Tutte/Azzera/configurazioni/ricerca/pagine non lo eliminano. Nove colonne DPR richieste; analogo DM con gruppo e attività GVR pertinenti. Contesto e gruppo registrati anche nell'audit dell'export. |
| C24 | L'assenza dei verificatori importati disattivati resta corretta: nessuna riattivazione automatica. Aggiunta spiegazione nel selettore. Corretto anche un difetto distinto: la finestra comune di affidamento DM chiamava i valori DPR; ora usa `/api/dm/incarichi/valori`, funziona con un RT DM senza ruolo DPR. |
| C25 | Salva e Salva e chiudi della scheda Utente includono anagrafica e dati tecnici nella stessa transazione. Operazioni della scheda serializzate, versione condivisa dopo profilo/firma; bozza preservata. Controllo versione anche sulla firma quando fornita dal client nuovo. Conflitti reali 409 mantenuti senza chiudere/perdere i campi. |
| C26 | Controllo dimensione e identità del Word prima della conversione; errori distinti per PDF allegato/generato, formato/struttura/dimensione. PDF leggibile, con pagine e non protetto; limiti 25 MiB invariati. Log conversione con dimensioni ed esito del processo, senza contenuti o nominativi. |
| C28 | L'esecutore non può riesaminare il proprio verbale DPR o DM, anche se RT/amministratore. Protezione API e servizi, UI con spiegazione; selezione DM mista rifiutata senza riesami parziali. Riesami pregressi non alterati. |

Viste personali conservate: le nuove viste iniziali si adottano con Configurazioni → Vista iniziale della versione corrente. Nel DPR una riga a corpo usa ancora il campo sede/voce già previsto nel modello: non è stata riscritta la semantica delle righe economiche.

## Test effettivamente eseguiti

Ambiente: Linux, Python **3.12.3**, dipendenze applicative ricevute mantenute, pytest **9.1.1**, pytest-xdist **3.8.0**, Chromium **134.0.6998.35** / Playwright **1.51.0**, LibreOfficeDev **26.8.0.0.alpha0**. I risultati non attestano il collaudo sulla macchina Windows dell'utente o sulla sua versione LibreOffice. La dipendenza xdist è solo per i test; le dipendenze applicative non cambiano.

| Verifica | Comando/risultato |
|---|---|
| Base 0.16 ricevuta | `python -m pytest -q`: **317 passed, 1 warning**, 679,43 s, rieseguita qui |
| Suite completa 0.17 | `python -m pytest -q -n 4 --dist loadfile`: **346 passed, 5 warnings**, 200,32 s |
| Ultima modifica audit export | `python -m pytest -q tests/test_griglie.py tests/test_collaudo_017.py::test_contesto_righe_non_eliminabile_filtri_excel_e_menu`: **14 passed, 1 warning**, 19,97 s, dopo la piccola aggiunta al log del contesto/gruppo |
| Browser del pacchetto | `python strumenti/collaudo_browser_017.py`: **11 percorsi PASS**, zero errori JavaScript e zero risposte 500 nei percorsi provati |
| Aggiornamento | Due processi, prima codice 0.16 poi 0.17 su stesso archivio sintetico: **PASS**, contenuto di **63 tabelle preservato**, escluso solo il catalogo etichette permessi che viene aggiornato; schema 0027; concessioni storiche preservate e nuovo controllo efficace |
| Word circa 1,2 MB | Test `pdf_vero`: documento Word sintetico valido con payload incomprimibile nell'archivio DOCX, conversione LibreOffice reale verificata e PDF leggibile con pagine. Non è una riproduzione del file reale dell'utente né un test di tutte le possibili immagini incorporate. |
| Controlli statici | Tutti i **37 JavaScript** con `node --check`; `compileall` di gestionale/tests/strumenti; Ruff isolato E9/F63/F7/F82 sui Python funzionali modificati: **PASS** |

I cinque warning della suite parallela sono la stessa deprecazione FastAPI/Starlette TestClient ripetuta nel processo principale e nei quattro lavoratori. Le conversioni rapide degli altri test usano PDF sintetici validi: non sono prove LibreOffice reali. La suite contiene anche i test `pdf_vero` esistenti e quello nuovo, con la conversione reale esplicitamente ripristinata nel nuovo caso.

Percorsi browser: operatori testo/pulisci/nascondi/ripristina; Scadenze DPR e date; Attrezzature/Scadenze DM; RC cumulativo/parziale/negativo; contesto preventivo con Tutte/Azzera/vista salvata; tecnico poi Salva e chiudi; firma poi Salva preservando la bozza; vero conflitto 409; divieto riesame proprio DPR; barre/selezione/azioni non ammissibili; RT DM senza ruolo DPR che affida tramite lista DM.

## Esiti delle iterazioni precedenti, conservati

I log precedenti restano in `report_collaudo/0.17.0/`, non vanno scambiati per l'esito finale. Prima suite 0.17: **339 pass e 4 fail**; corretti test che usavano l'elenco globale, attese dei permessi RT prima della separazione e il campo descrizione del dato di prova. Successiva suite sequenziale: **344 pass e 2 fail**, dovuti al nuovo test di autoriesame che leggeva `versione` dalla sintesi del preventivo invece che dalla scheda Verifica; corretto il test. Suite parallela finale: tutti i 346 casi passano. I singoli cicli mirati e i loro fallimenti sono riportati nei rispettivi log.

La prima esecuzione della copia portabile del runner di aggiornamento è fallita perché la directory corrente faceva importare il codice nuovo anche nella fase di semina; corretto il runner fissando directory e versione del codice in ciascun processo. Riesecuzione del runner del pacchetto: PASS, 63 tabelle preservate. Il log del tentativo fallito resta `017-upgrade-package-first.txt`.

La prima esecuzione della copia portabile del runner di aggiornamento è fallita perché la directory corrente faceva importare il codice nuovo anche nella fase di semina; corretto il runner fissando directory e versione del codice in ciascun processo. Riesecuzione del runner del pacchetto: PASS, 63 tabelle preservate. Il log del tentativo fallito resta `017-upgrade-package-first.txt`.

La prova browser iniziale ha trovato le icone non cliccabili nelle colonne strette: disposizione corretta e prove ripetute superate. Una verifica Ruff con regole generali dell'ambiente ha dato 217 rilievi di stile/altro, non trattati come collaudo superato; il controllo di errori critici isolato sopra è passato. Non è stata svolta una bonifica generale di stile del progetto.

## Rimasto aperto / fuori da questa versione

- **File Word reale da 1,2 MB:** non ricevuto; diagnosi specifica e riproduzione non dimostrate. Screenshot e nuovo test sintetico non consentono di dire che il suo caso reale è risolto.
- **PostgreSQL / importazione completa MariaDB Garda (C27):** autorizzati come lavoro successivo, nessun supporto o importatore completo implementato/collaudato qui. Piano e criteri nel documento 46.
- **Riesami pregressi fatti dall'esecutore:** non modificati; occorre verificare e gestire separatamente l'archivio operativo.
- **Windows, configurazione e volumi reali dell'utente:** non provati in questa sessione. Nessun benchmark nuovo di un archivio Garda completo.
- Modelli DM rev.03 già ricevuti e relativa approvazione, XML/Aruba differiti, I&C/EX e gli altri limiti della 0.16 non sono completamenti della 0.17.

## Documentazione e decisioni

`README.md`, `MIGRAZIONE_0.17.0.md`, documento 45 (ripresa), documento 46 (PostgreSQL/Garda), documento 47 (richieste/approvazioni), quattro fonti effettivamente ricevute in `documentazione/fonti_ricevute_2026-10-13`. Documento 36 aggiornato con chiusura del collaudo. Registro canonico fino a **R143**; nessun nuovo numero R assegnato in questa istanza. Riportare C17–C28 nel registro canonico con i testi originali, senza trasformare proposte non approvate in decisioni.
