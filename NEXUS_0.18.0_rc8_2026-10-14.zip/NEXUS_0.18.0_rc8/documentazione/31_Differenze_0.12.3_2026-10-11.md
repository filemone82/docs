# 31 · Differenze della 0.12.3 rispetto alla 0.12.2

11/10/2026 · Redatto da Claude · Schema invariato (Alembic 0015). Correzioni nate dalla prima prova su Windows di Federico (0.12.2: 220 test passati e 2 falliti; `AVVIA_TEST_WINDOWS.bat` si fermava).

## Correzioni

1. **`AVVIA_TEST_WINDOWS.bat` / `strumenti/crea_ambiente_di_prova.py` si fermava.**
   - **Causa:** lo script non era stato aggiornato a due regole introdotte dalla 0.8.0 in poi. L'accettazione del preventivo richiede l'evidenza scritta (R38), e non si fa un secondo preventivo sulla stessa scadenza già preventivata (R98).
   - **Correzione:** lo script indica l'evidenza («email di conferma, dati di prova») e prepara il preventivo «da completare» su un impianto non ancora preventivato.
2. **L'ambiente di prova ora contiene anche dati AD_dm**, nella sede di DELTA:
   - un serbatoio GVR (famiglia a1, senza visita interna) con incarico **chiuso** e PDF definitivo, pronto per provare il riesame;
   - un generatore di vapore (famiglia a2, con visita interna) con incarico assegnato a tecnico2;
   - un preventivo DM accettato e riesaminato.

   Se LibreOffice non è trovato, il primo incarico resta «registrato» e lo script lo dice.
3. **Codifica dei file su Windows.** Su Windows Python legge i file di testo con la codifica di sistema (cp1252) se non gliela si indica.
   - **Programma:** `gestionale/moduli/dm/inail.py` leggeva così l'elenco delle 62 colonne INAIL. Le intestazioni con uno spazio non separabile sarebbero uscite alterate nell'Excel INAIL. Ora legge in UTF-8.
   - **Test:** stessa correzione in tre test (cataloghi Garda, tariffe DM, installazione) e nei file di prova dello strumento di aggiornamento di VerbalizzAI. Il test dei cataloghi falliva su Windows per questo motivo: i dati nel database erano corretti, era il test a leggere male il file di riferimento.
   - **Controllo:** la suite completa è stata rieseguita con `-X warn_default_encoding`. Nessuna lettura o scrittura di file senza codifica resta nel codice del gestionale; l'unico avviso residuo è interno alla libreria openpyxl.
4. **Test di velocità del registro (`test_griglie.py`).** Su Windows la ricerca «contiene» su 300.000 righe ha richiesto 0,55 s contro una soglia di 0,5 s. Non è un difetto: quella ricerca deve leggere tutto il registro e la durata dipende dal PC. La soglia diventa **1 secondo**, misurato come migliore di tre tentativi per non dipendere da un picco momentaneo (antivirus, disco).

5. **Ambiente di prova interrotto.** Se la creazione si fermava a metà (come nella prova dell'11/10), restava un archivio incompleto che al lancio successivo si apriva come se fosse buono. Ora la creazione completa scrive `AMBIENTE_DI_PROVA_COMPLETO.txt`. `AVVIA_TEST_WINDOWS.bat` ricrea l'ambiente solo se quel file manca; se trova un archivio senza quel file, si ferma e chiede di usare `RICREA_AMBIENTE_DI_PROVA_WINDOWS.bat`.

## Test nuovi

`tests/test_ambiente_di_prova.py` (2 test): il primo crea l'intero ambiente di prova come fa `AVVIA_TEST_WINDOWS.bat` e controlla che ci siano verifiche DPR nei vari stati, il preventivo da completare e i due incarichi DM. Così lo script non può più restare indietro rispetto alle regole senza che un test lo segnali. Il secondo controlla che un archivio interrotto venga riconosciuto.

## Prove

| Prova | Esito |
|---|---|
| Suite completa, Linux, Python 3.13.16, con `-X warn_default_encoding` | **223 passati** (`report_collaudo/pytest_0.12.3.txt`), più il test dell'archivio interrotto aggiunto dopo: **224** in totale |
| `crea_ambiente_di_prova.py` con LibreOffice reale | Ambiente creato; incarico DM chiuso con verbale GVR generato da LibreOffice |
| ruff E9/F sui file modificati | Passato |
