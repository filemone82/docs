# 33 · Differenze della 0.12.5 rispetto alla 0.12.4

11/10/2026 · Redatto da Claude · Schema Alembic **0017** (nuova). Decisioni di Federico dell'11/10/2026, 11:56 e 13:55.

## 1. Preventivi solo nel proprio ambito (R115)

Decisione: «quando creo un preventivo DM la ricerca delle sedi dovrebbe mostrare solo quelle associate a clienti AD_DM […] al limite si modifica dall'anagrafico l'attributo "ambito"».

- **Nuovo preventivo DM:** la ricerca mostra solo le sedi AD_DM. **Nuovo preventivo DPR:** solo i clienti AD_DPR.
- **Fuori ambito:** il server rifiuta il preventivo e indica dove cambiare l'ambito («Sedi operative › Ambiti di lavoro», «Clienti › Dati generali › Ambiti di lavoro»).
- **Eccezione:** una sede diventa comunque AD_DM da sola quando le si aggiunge un'attrezzatura (R114).
- **API:** `/api/sedi/cerca` e `/api/clienti/cerca` accettano `ambito=DPR|DM|IEC`. Senza il parametro restituiscono tutto (anagrafica).

## 2. Sedi doppie (R116)

Decisione: «sì va bene unire le sedi con stesso indirizzo»; per ora un solo referente tecnico e una sola email per i verbali.

### Nell'importazione adsrl

Una sede adsrl si unisce **da sola** alla sede già presente quando valgono insieme tre condizioni:
- stesso cliente;
- stesso indirizzo e stesso comune, a parte maiuscole, accenti, punteggiatura, «n.» e «civ.»;
- una e una sola sede corrispondente.

Effetti dell'unione:
- resta la sede DPR, con gli ambiti AD_DPR e AD_DM;
- attrezzature, accessori e preventivi passano sotto di lei;
- i campi vuoti si completano con quelli di adsrl (referente, telefono, email…);
- i dati diversi vanno nelle note («Dati diversi dell'altra sede: …»);
- «Rif. gestionale attuale» diventa `<id ingecert> · dm:<id adsrl>`, per i riallineamenti futuri.

### Possibili doppioni

Sedi operative › **Possibili doppioni** elenca le coppie di sedi che soddisfano tutte queste condizioni:
- stesso cliente e stesso comune;
- ambiti diversi: una AD_DPR, l'altra AD_DM (lo stesso stabilimento arrivato dai due gestionali);
- non escluse in precedenza.

Le coppie sono ordinate per somiglianza dell'indirizzo (nome della via e numero civico). Per ciascuna si può scegliere:
- **Unisci**, scegliendo quale delle due sedi resta;
- **Sono sedi diverse**: la coppia non verrà più proposta (tabella `sedi_doppioni_esclusi`, migrazione 0017).

### Unisci con…

Nella scheda di una sede, **Unisci con…** unisce due sedi qualsiasi dello stesso cliente.

### Regole dell'unione

`gestionale/moduli/anagrafica/doppioni.py`:
- sposta **ogni** riferimento alla sede, trovato dallo schema e non da un elenco scritto a mano: impianti, attrezzature e accessori, preventivi;
- rifiuta l'unione se due beni avrebbero la stessa matricola nella stessa sede, e indica quali;
- rifiuta l'unione di sedi di clienti diversi;
- elimina la sede unita;
- scrive nel registro i dati delle due sedi, le righe spostate e i dati diversi.

### Sul dump reale (ingecert + adsrl del 07/10)

| Voce | Numero |
|---|---|
| Sedi adsrl unite automaticamente | 71 |
| Coppie proposte in «Possibili doppioni» | 83 |
| …di cui probabili (somiglianza ≥ 60%) | 42 |
| …di cui con lo stesso indirizzo ma più sedi DPR candidate (es. una ditta con «palazzina uffici» e «magazzino» allo stesso civico) | 2 |
| Elaborazione dell'elenco | 0,2 s |

**Da sapere:** in ingecert lo stesso indirizzo non vuol dire sempre la stessa sede. Ci sono 99 gruppi di sedi DPR dello stesso cliente allo stesso indirizzo, per 244 sedi, quasi sempre volute: forniture distinte («Fornitura 1», «Fornitura 2») o edifici distinti. Per questo:
- l'unione automatica avviene solo con **una** sede corrispondente;
- le coppie DPR-DPR non sono proposte come doppioni.

Se qualcuna va unita, c'è «Unisci con…».

## 3. Importazione senza errori, duplicazioni o accoppiamenti mancati (R118)

Il rapporto `importazione_garda_adsrl.txt` controlla ora anche gli **accoppiamenti**:

| Controllo | Esito sul dump reale |
|---|---|
| Sedi nell'archivio, attese = prima + adsrl − unite | 2.674 + 1.080 − 71 = **3.683, presenti 3.683** |
| Attrezzature e accessori nella sede giusta | **12.657 su 12.657** |
| Collegamenti attrezzatura-accessorio (`attrezzature_vds`) | **lette 3.399, importate 3.399, scartate 0** |
| Clienti, sedi, attrezzature, valvole | Righe lette = righe importate |
| Volume delle camere | **37.252.774,6 l = 37.252.774,6 l** |

Ogni differenza compare in maiuscolo («DIFFERENZA», «NELLA SEDE SBAGLIATA»).

## 4. Menu per attività con le sezioni di Garda (R117)

Decisione: la vista AD_DM non convinceva («parco comune», «attrezzature e accessori» poco coerenti); i gestionali di Garda sono divisi in Gestione, Clienti, Attrezzature, Scadenze, Preventivi, Verifiche, Fatture.

| Attività | Sezioni del menu |
|---|---|
| **AD_DM** | **Clienti** (clienti, sedi operative, commerciali, tipi di pagamento, aliquote IVA) · **Attrezzature** (attrezzature, valvole di sicurezza, tipi di attrezzature, tipi attrezzature GVR, ID specifiche, tipi attr./ID specifiche, tariffe SC/SP, tariffe GVR) · **Scadenze** · **Preventivi** · **Verifiche** · **Fatture** (in arrivo, passo D) · **Gestione** |
| **AD_DPR** | Clienti · **Impianti** (impianti, tariffario) · Scadenze · Preventivi (con righe) · Verifiche (con verbali) · Fatture · Gestione (con «Verbali di VerbalizzAI») |
| **I&C** | Clienti · I&C (in arrivo, passo E) · Gestione |

**Gestione** contiene: utenti, ruoli e permessi, elenchi di valori, impostazioni email, modelli Word, comuni, importazione dati, registro, backup.

- **Attrezzature** e **Valvole di sicurezza** sono ora elenchi come Clienti e Sedi: filtri sotto i titoli, colonne a scelta, configurazioni salvate, Excel.
  - Colonne delle attrezzature: gruppo, matricole, costruttore, modello, tipo all. 7, tipo GVR, ID specifica, attributi della scheda, volume e numero delle camere, numero di valvole, prossima scadenza e stato, ultima/prossima per ciascuna attività, sede e cliente.
  - Colonne delle valvole: tipologia, DN, Ptar, taratura ultima/prossima, «collegata a».
  - Il clic sulla riga apre la scheda.
  - Il vecchio indirizzo `/beni` porta ad «Attrezzature».
- **Cataloghi di Garda** in sola lettura, con gli stessi ID di Garda: 31 tipi, 6 tipi GVR, 72 ID specifiche, 162 compatibilità, 314 tariffe.
- I titoli delle pagine riportano la sezione del menu: CLIENTI, ATTREZZATURE, PREVENTIVI…

**Non cambia ancora:** la **scheda** dell'attrezzatura resta quella della 0.12.4. Va rifatta sui mockup accettati come prima approssimazione (documento 18, § 5.8) nel passo D, insieme a preventivo e verifica DM.

## Test nuovi

| File | Test | Cosa controlla |
|---|---|---|
| `tests/test_doppioni.py` | 3 | Confronto degli indirizzi; unione con spostamento di impianto, attrezzatura e preventivo, campi completati, note, registro, «sono diverse»; rifiuti (stessa matricola, clienti diversi) |
| `tests/test_menu_attivita.py` | 2 | Sezioni del menu DM e DPR; pagine dei cataloghi; elenchi attrezzature e valvole con dati e filtri; numeri dei cataloghi |
| `tests/test_ambiti.py` | +1 | Preventivi solo nel proprio ambito |
| `tests/test_garda_dm.py` | aggiornato | Sede unita nell'importazione; controlli di accoppiamento |

`test_tutte_le_griglie_ogni_colonna` ordina e filtra anche le 8 griglie nuove su ogni colonna.

## Prove

| Prova | Esito |
|---|---|
| Suite completa, Linux, Python 3.13.16 | **237 passati** (`report_collaudo/pytest_0.12.5.txt`) |
| Importazione reale ingecert + adsrl | Tutte le quadrature senza differenze (§ 3) |
| Interfaccia su archivio reale (Chromium) | Menu AD_DM, 9.346 attrezzature, 3.311 valvole, tariffe, possibili doppioni, scheda: nessun errore JavaScript |
| ruff sui file nuovi | Passato |

## Ancora aperto

- **Destinatari dei verbali diversi per ambito sulla stessa sede.** Per ora non si fa (decisione del 13:55): un solo referente e una sola email. Se servirà, i dati dell'altra sede sono già conservati nelle note della sede unita.
- **Nome definitivo di «ambito».** Da decidere.
