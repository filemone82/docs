# Gestionale integrato — documento quadro

**Versione del documento:** 1.53. **Aggiornamento:** 9 ottobre 2026, ora italiana. **Ambito:** sintesi della conversazione disponibile, dei materiali ricevuti, delle proposte e delle decisioni acquisite, con avvio dell’implementazione AD_dpr.

Questo è il riferimento unitario del progetto. Le analisi precedenti restano evidenze di dettaglio; questo documento ne riporta gli esiti attuali e le successive correzioni. “Verificato” indica un riscontro sui materiali o una prova eseguita; “proposto” non equivale ad approvato o implementato.

**Situazione attuale:** sono stati analizzati i tre gestionali Garda, VerbalizzAI e la migrazione v0.2; il prototipo Gestionale_AD v0.7.1 è stato utilizzato come base della nuova candidatura 0.8.0, con VerbalizzAI 0.3.32.3 e un primo modulo economico. È iniziata l’implementazione Python richiesta dall’utente. La candidatura è destinata al collaudo locale Windows; non è stato eseguito un passaggio in produzione e il gestionale integrato delle tre attività non è ancora completato.

**Lettura breve attuale:** la sezione 30 descrive il codice della candidatura 0.8.0, le prove osservate e i limiti; la sezione 29 conserva la sintesi funzionale precedente. Il registro R01–R69 conserva le decisioni; le proposte precedenti vanno lette con i successivi chiarimenti e non diventano implementazioni per il solo fatto di essere documentate.

## 1. Obiettivo e perimetro

Ricostruire un gestionale integrato che conservi dati, storia e regole utili delle tre attività e riduca duplicazioni, ricopiature e passaggi manuali. **Prima definiamo come devono lavorare le persone; poi scegliamo quali componenti esistenti realizzano quel funzionamento.** Le tabelle e le maschere Garda non diventano automaticamente il modello del nuovo sistema.

| Nome del gestionale attuale | Nome usato nella conversazione | Attività | Società |
|---|---|---|---|
| ingecert | AD_dpr | Verifiche DPR 462 | AD S.r.l. |
| adsrl | AD_dm | Verifiche su attrezzature a pressione e sollevamento | AD S.r.l. |
| iec | I&C | Consulenza, controlli e tarature | I&C S.r.l. |

Direzione di lavoro: un nucleo comune e interfacce dedicate alle tre attività. AD e I&C S.r.l. restano distinte per emissione e contabilità. La precedente incorporazione di I&C snc in AD nel 2025 non implica la disattivazione di I&C S.r.l.

La sequenza discussa è: rilascio autonomo di VerbalizzAI con il proprio collaudo; costruzione del gestionale integrato; avvio limitato ad AD_dpr; estensione ad AD_dm e I&C quando il funzionamento DPR è validato nell’uso. **DM e I&C entrano nel progetto del nucleo fin dall’inizio**, anche se saranno attivati dopo.

## 2. Requisiti e indirizzi raccolti

| Rif. | Requisito o indirizzo | Stato |
|---|---|---|
| R01 | Progettare inefficienze, mancanze e semplificazioni prima di scrivere altro codice applicativo. | Richiesta esplicita attuale. |
| R02 | Coprire le tre attività in un sistema integrato, con funzioni e viste pertinenti a ciascuna. | Obiettivo del progetto; dettaglio da definire. |
| R03 | Preservare dati storici, collegamenti, numeri, documenti e importi. | Necessità emersa dalla revisione; verifiche ancora da completare. |
| R04 | Tenere distinto il rilascio di VerbalizzAI dalla sostituzione del gestionale. | Percorso discusso e raccomandato; lo stato del rilascio reale non è attestato qui. |
| R05 | Attivare prima AD_dpr, poi AD_dm e I&C dopo validazione nell’uso. | Sequenza di riferimento discussa. |
| R06 | Riutilizzare Gestionale_AD v0.7.1 dove utile, senza assumere tutte le sue scelte come definitive. | Riuso avviato nella 0.8.0: nucleo Python, anagrafiche, preventivi, incarichi, permessi, backup e innesto VerbalizzAI. Nuovo modulo economico e correzioni dei flussi. Confine fisico degli archivi e integrazione futura ancora da completare. |
| R07 | Eliminare la ricopiatura e la sincronizzazione manuale dei dati condivisi AD_dm/I&C. | Miglioramento proposto su inefficienza verificata. |
| R08 | Distinguere avanzamento, riesame, documento consegnato e fatturazione; rendere affidabili scadenze e rettifiche. | Proposta concettuale da validare. |
| R09 | Conservare controlli utili già presenti, inclusa l’indipendenza del verificatore, con evidenze verificabili. | Regola Garda accertata; comportamento futuro da definire con le procedure. |
| R10 | Abbinare VerbalizzAI all’anagrafica tramite riferimenti stabili, preservando UUID, versioni e contenuti. | Ponte minimo proposto, non implementato nel sorgente autonomo esaminato. |
| R11 | Riallineare i dati durante la convivenza senza ricreare le identità canoniche. | Requisito tecnico proposto; import incrementale non ancora disponibile. |
| R12 | Mantenere un documento aggiornabile di requisiti, analisi, decisioni e progresso. | Richiesta esplicita; aggiornato alla versione 1.53, con requisiti, codice e prove distinti. |
| R13 | Procedere senza fornire adesso gli originali S3, per motivi di spazio. | Vincolo esplicito dell’utente. Recupero e verifica dei contenuti rinviati; analisi dei processi e dei metadati prosegue. |
| R14 | Nel DPR predisporre normalmente un nuovo contratto a ogni scadenza; supportare come eccezione gli affidamenti pluriennali, ad esempio dei Comuni. | Prassi dichiarata dall’utente: circa 99 casi su 100 con contratto a scadenza. Requisito raccolto; dettagli dell’eccezione da definire. |
| R15 | Per AD_dpr usare ISPESL 2005 per terra e scariche atmosferiche; tariffa oraria per luoghi con pericolo di esplosione. | Regola operativa dichiarata dall’utente; tariffe normalmente uguali al ciclo precedente. Per ATEX vale l’importo del preventivo, come precisato in R17. |
| R16 | Prevedere la possibilità di sconti DPR, citata per gare verso la PA. | Possibilità dichiarata dall’utente; criteri, modalità e autorizzazioni da precisare. Non è attestata qui una prassi abituale di sconto. |
| R17 | Per ATEX assumere l’importo concordato nel preventivo senza variazioni a consuntivo. | Regola esplicita dell’utente; coerente con il percorso Garda preventivo–verifica–fattura esaminato. |
| R18 | Prima di registrare ogni elemento concordato, verificare se ingecert o gli altri gestionali Garda lo implementano già. Conservare le funzioni utili e migliorare le carenze, senza reinventare la logica. Chiedere chiarimenti sulla prassi non desumibile, sulle ambiguità e sulle modifiche desiderate. | Metodo esplicito ribadito dall’utente: ogni requisito deve riportare il riscontro nel sorgente, il comportamento da conservare e il miglioramento richiesto, oppure dichiarare che il riscontro non è ancora concluso. Presenza nel codice e funzionamento collaudato restano distinti. |
| R19 | Per i preventivi DPR adottare il flusso documentale apprezzato in VerbalizzAI: anteprima PDF via LibreOffice, eventuale correzione del Word, ricaricamento, nuova anteprima e iterazione fino alla versione corretta. | Richiesta esplicita; buona parte del ciclo è già presente nel prototipo 0.7.1. |
| R20 | Definire il nome automatico del file finalizzato e il download automatico, con destinazioni da stabilire. | Richiesta esplicita; nome già generato nella 0.7.1, convenzione finale e automatismo di download da progettare. |
| R21 | Prevedere firma e finalizzazione del documento prima dell’invio, secondo il flusso richiesto dall’utente. | Richiesta recepita; nel percorso preventivi della 0.7.1 è verificata l’approvazione, non una funzione equivalente di firma del mittente. Modalità da definire. |
| R22 | Usare “preventivo” come termine nell’interfaccia e raccogliere separatamente i dettagli che non incidono sull’architettura, decidendoli alla fine. | Richiesta esplicita. Resta corretto parlare di riesame del contratto e di accordi commerciali quando ci si riferisce a quei concetti. |
| R23 | Arrivare rapidamente a una struttura minima praticabile mediante domande mirate sulle decisioni strutturali. | Richiesta esplicita; proposta di architettura e cinque domande nella sezione 20. |
| R24 | Il primo AD_dpr deve includere il modulo completo di fatturazione e incassi. | Decisione esplicita dell’utente. Il perimetro non viene ridotto a sola esportazione XML o incassi essenziali. |
| R25 | L’intestatario fattura può differire dall’intestatario del preventivo, che costituisce la proposta normale. | Prassi e requisito espliciti; verificata la sezione Garda con dati fiscali di intestazione distinti. |
| R26 | Mantenere per ora distinta la programmazione delle attività. | Decisione dell’utente: nessuna agenda operativa unificata DPR/DM/I&C nel primo rilascio. |
| R27 | Preventivo creato → inviato → accettato, salvo rifiuto/annullamento; dopo l’accettazione riesame obbligatorio e solo successivamente affidamento al tecnico. | Flusso esplicito dell’utente, che richiama ISO 17020:2026. Riscontrato il vincolo di accettazione e riesame conforme nelle condizioni Garda per generare verifiche. |
| R28 | Il primo rilascio funziona online; non sono previste bozze offline. | Decisione esplicita dell’utente. Nessuna copia operativa locale, coda offline o sincronizzazione dei dispositivi nel perimetro iniziale. |
| R29 | Prassi attuale dichiarata: verbalizzazione, riesame del verbale, invio e poi fatturazione. Valutare rilascio immediato soprattutto DPR, raro DM e praticamente assente per I&C S.r.l. | Chiarimento dell’utente. Proposta di due percorsi nella sezione 24; attivazione dell’eccezione ancora da decidere. |
| R30 | Mantenere semplici il flusso e la logica del gestionale; evitare che la distinzione dei controlli aumenti il lavoro operativo. | Richiesta esplicita. Percorso ordinario unico, eccezione DPR circoscritta e stati derivati; criterio di progetto nella sezione 24.6. |
| R31 | Nel DPR datore di lavoro, committente, intestatario del preventivo e del verbale coincidono nel processo indicato. L’eventuale intestatario terzo si sceglie soltanto alla generazione della fattura, con default dal cliente. | Chiarimento esplicito: mantenere il funzionamento Garda, senza introdurre prima un committente distinto. |
| R32 | Discutere prima ogni cambiamento alle logiche, entità o relazioni Garda, partendo dal comportamento attuale e da un motivo concreto. | Vincolo esplicito. Le proposte del documento non autorizzano da sole una modifica del modello o dell’applicazione. |
| R33 | L’aggiornamento del cliente non deve modificare l’intestazione o i dati nei verbali e preventivi già emessi. | Requisito esplicito; conservarne file e dati validi all’emissione, anche per consultazione e ristampa. Il comportamento del subentro resta da decidere. |
| R34 | Nel subentro DPR di un’altra azienda mantenere lo stesso impianto fisico, con nuovo cliente e passaggio tracciato; emessi precedenti riferiti al vecchio soggetto e ai dati originali. | Proposta approvata dall’utente con “ok”; comportamento da specificare e implementare, non modifica già eseguita. |
| R35 | Valvola–attrezzatura: mantenere l’abbinamento corrente e modificarlo manualmente quando necessario, conservando tarature e documenti; non introdurre nel primo perimetro uno storico strutturato dei montaggi. | Scelta esplicita di semplicità, coerente con la prassi dichiarata. Non elimina le evidenze già conservate nei documenti. |
| R36 | Chi può modificare le anagrafiche si gestisce con la configurazione dei ruoli e permessi; non è una decisione architetturale da chiudere con una domanda separata. | Chiarimento esplicito dell’utente. Le regole di integrità e conservazione degli emessi valgono per ogni operatore autorizzato. |
| R37 | DPR: aggiornare la prossima scadenza alla verifica effettuata/emissione, senza attendere il RV conforme; tenerla coerente con eventuali modifiche del verbale in revisione. | Regola approvata dall’utente. La nuova revisione emessa aggiorna i dati pertinenti; un ritocco solo grafico non modifica la scadenza. |
| R38 | Accettazione DPR con preventivo controfirmato oppure almeno email di conferma; le conferme telefoniche non fanno parte della prassi ammessa descritta. | Requisito esplicito. Collegare la risposta scritta alla versione/prestazioni pertinenti; il modo pratico di conservarla non è ancora definito. |
| R39 | Il contenuto commerciale del preventivo accettato non si modifica. Le prestazioni aggiuntive richiedono un nuovo preventivo integrativo; prestazioni di preventivi diversi possono essere riunite in un’unica fattura nel flusso compatibile discusso. Le prestazioni DM ed EX restano su fatture separate (R49). | Requisito esplicito. L’aggregazione in fattura conserva una funzione già presente in Garda (generazione dalla riga preventivo con scelta della fattura da integrare), non introduce una nuova logica. Conservare offerta ed evidenza originarie e la provenienza delle prestazioni fatturate. |
| R40 | Garda permette di preventivare la prossima scadenza, non anche quelle successive di un affidamento pluriennale. Questi affidamenti sono rari: la loro gestione deve evitare di complicare o alterare la logica ordinaria. | Limite e priorità dichiarati dall’utente. Raccomandazione: rinviare una gestione dedicata e trattare manualmente i casi rari nel primo DPR, senza automatismi di copertura. Modalità concreta da verificare sul caso effettivo. |
| R41 | DPR: verifica assegnata, eventuale programmazione, registrazione in occasione dell’esecuzione; stato eseguita soltanto dopo finalizzazione e caricamento del verbale nel gestionale. Per una verifica che non può essere eseguita, introdurre lo stato sospesa. | Flusso e aggiunta richiesti dall’utente. Programmazione facoltativa. Confermata la ripresa sullo stesso incarico, mantenendo l’eventuale numero di verbale già assegnato. Transizioni puntuali e trattamento economico da consolidare; nessuna implementazione eseguita. |
| R42 | Prevedere la possibilità di addebitare un sopralluogo a vuoto quando, dopo l’uscita, la verifica non viene conclusa e viene definitivamente annullata. | Esigenza nuova: l’utente dichiara che oggi non è gestita e ritiene corretto l’addebito. Nessun importo, criterio di applicazione o automatismo approvato. Proposta minima: voce economica manuale distinta dalla verifica non eseguita. |
| R43 | Nel DPR la fattura di acconto prima dell’esecuzione non è la prassi ordinaria, ma può capitare e deve essere supportata. | Prassi esplicita dell’utente. Distinguere acconto fatturato e relativo incasso, collegare il documento alle prestazioni pertinenti e tenerne conto nel saldo. Non trasformare l’acconto in un passaggio obbligatorio delle verifiche. |
| R44 | Trasmissione elettronica DPR attuale: download dell’XML dal gestionale e caricamento manuale nel servizio Fatturazione Elettronica Aruba. | Prassi esplicita dell’utente. Conservare questo canale nel primo DPR, rinviando l’invio automatico. Generazione/download non equivalgono a trasmissione riuscita; esiti oggi consultati su Aruba, importazione nel nuovo gestionale richiesta (R47), modalità tecnica da definire. |
| R45 | Gli incassi e le fatture ancora da pagare vengono oggi registrati e controllati in Garda. | Prassi esplicita dell’utente. Conservare queste funzioni nel primo AD_dpr; il caricamento degli XML su Aruba non trasferisce al servizio esterno la gestione operativa dei crediti. Non equivale ad approvare nuove relazioni dei movimenti o una riconciliazione bancaria automatica. |
| R46 | Normalmente un pagamento viene associato a una fattura; nei rari casi deve essere possibile associare lo stesso pagamento a due o più fatture. | Comportamento chiarito dall’utente. Pagamento unico, con importo attribuito a ciascuna fattura e totale non duplicato. Estensione della normale associazione, senza flusso dedicato. Rappresentazione tecnica ancora da definire; nessuna implementazione eseguita. |
| R47 | Gli esiti delle fatture elettroniche vengono oggi consultati su Aruba e non lasciano traccia in Garda. Importarli nel nuovo AD_dpr, rendendo visibile una fattura scartata e la necessità di correggerla/ripresentarla. | Mancanza segnalata e requisito esplicito dell’utente. Collegare gli esiti alla fattura e conservare tentativi ed evidenze precedenti; modalità di recupero/importazione da definire. Approvato dall’utente il criterio futuro: correggere nel nuovo gestionale e rigenerare l’XML, conservando versioni ed esiti dei tentativi; nuovo caricamento su Aruba. Nessuna implementazione eseguita. |
| R48 | La serie EX di adsrl / AD comprende CND delle attrezzature GVR, verifiche di efficienza delle valvole di sicurezza (accessori GVR) e verifiche ispettive volontarie SC, SP e GVR. | Significato operativo esplicito dell’utente. Conservare le denominazioni delle prestazioni e la società emittente oltre alla serie; “efficienza delle valvole” non viene trasformata in “taratura”. Prestazioni DM ed EX fatturate separatamente, con serie distinte anche per i preventivi (R49). |
| R49 | Per uno stesso cliente le prestazioni DM ed EX generano due fatture separate, perché anche le serie dei relativi preventivi sono separate. | Regola e prassi esplicite dell’utente. Conservare la separazione commerciale e fiscale DM/EX. Non estendere automaticamente la fattura unica acquisita per più preventivi a questo abbinamento; gli altri eventuali abbinamenti non sono decisi da questa risposta. |
| R50 | Per ora il primo AD_dpr mantiene l’invio del verbale dopo riesame; il rilascio immediato resta una possibilità futura da attivare con una scelta successiva. | Risposta dell’utente al perimetro del primo DPR; precisato “invio” dopo riesame. Non introdurre l’opzione immediata nel primo esercizio previsto. La compatibilità futura non richiede un secondo flusso applicativo adesso. |
| R51 | Un RV negativo riporta la verifica a registrata. Il verificatore ripete l’attività e/o modifica il verbale, lo ricarica e riporta la verifica a eseguita per un nuovo RV. | Flusso esplicito dell’utente, conservando il comportamento Garda. Invio e fatturazione ordinaria restano subordinati al nuovo RV conforme. Ricaricare il documento non rende automaticamente conforme il riesame. |
| R52 | Il verificatore deve vedere la nota del RT in caso di RV negativo; ogni verbale deve avere lo storico dei riesami. | Requisito esplicito. Conservare esito, nota, autore, data/ora e versione esaminata per ogni RV, anche dopo ricaricamento e nuovo controllo. Nota negativa obbligatoria come già previsto in Garda; nessuna sovrascrittura dello storico con il solo esito corrente. |
| R53 | Al passaggio al nuovo AD_dpr l’utente preferisce importare anche gli incarichi già aperti, ma considera la scelta ancora da valutare. | Preferenza acquisita, non cutover definitivo approvato. Predisporre l’importazione delle pratiche attive e verificarla con una prova sugli stati, collegamenti e documenti; decidere il perimetro effettivo in base al risultato. |
| R54 | La verifica straordinaria DPR è preventivata a parte, con un proprio incarico e verbale VS anziché VP. Il ricontrollo dopo sistemazione dell’impianto è distinto dalla correzione del verbale conseguente a RV negativo sullo stesso incarico. | Prassi confermata dall’utente. Garda già distingue VP/VS nelle righe preventivo e nel codice verbale. Numerazione confermata dall’utente: un solo progressivo annuale per tutte le verifiche DPR 462, con prefisso VP per le periodiche e VS per le straordinarie. Si conserva il criterio già implementato da ingecert; nessun contatore separato. |
| R55 | La verifica straordinaria DPR non determina automaticamente la periodicità né ricalcola la scadenza della verifica periodica. | Regola confermata dall’utente: mantenere il comportamento ingecert, nel quale il ricalcolo usa l’ultima VP effettuata. Nessun nuovo ciclo periodico automatico alla finalizzazione di una VS. |
| R56 | Segnare un impianto dismesso non annulla automaticamente gli incarichi già aperti: la loro chiusura resta manuale. | Conferma esplicita dell’utente. Conservare il flag dismessa e i vincoli Garda sulle nuove generazioni; stato dell’impianto e stato dell’incarico restano distinti. La chiusura manuale consente di valutare un eventuale sopralluogo a vuoto già svolto, senza addebiti automatici. |
| R57 | Conservare l’accettazione parziale del preventivo DPR: con più impianti/prestazioni si può procedere soltanto sulle righe accettate, mantenendo lo stesso preventivo e dopo il riesame. | Conferma esplicita dell’utente. Funzione già presente in ingecert: stato per riga, riepilogo accettato_parzialmente e controllo della riga accettata per generare la verifica. Nessun nuovo preventivo obbligatorio per accettare una parte dell’offerta esistente. |
| R58 | Per semplicità, il riesame del preventivo DPR copre tutta l’offerta invariata, comprese le prestazioni già incluse che il cliente accetti successivamente. | Scelta esplicita dell’utente su un caso mai capitato. Coerente con RC sulla testata Garda: nessun nuovo riesame per la sola accettazione successiva di una riga già offerta. Restano necessarie accettazione scritta della prestazione e RC conforme valido prima dell’affidamento; le prestazioni nuove richiedono preventivo integrativo e relativo RC. |
| R59 | Nel primo AD_dpr gli incassi vengono registrati manualmente e associati alle fatture, con controllo dei residui. L’import degli estratti conto è un modulo necessario, da realizzare successivamente. | Decisione esplicita dell’utente: rinvio temporale, non esclusione definitiva né funzione facoltativa. Resta il requisito di fatturazione e incassi completi nel primo AD_dpr; restano già acquisiti uno stesso pagamento su più fatture e il recupero degli esiti SdI come questione distinta dall’import bancario. |
| R60 | Chiudere ora il DPR operativo, verificando la compatibilità strutturale del nucleo con DM e I&C. I flussi applicativi dettagliati DM/I&C saranno approfonditi prima dei rispettivi moduli, dopo la validazione del DPR nell’uso. | Perimetro confermato dall’utente. Nucleo integrato fin dall’inizio, primo AD_dpr completo di VerbalizzAI, fatturazione e incassi. Non si richiede un questionario completo su DM/I&C prima dell’ossatura DPR; restano da verificare le strutture comuni che sarebbe costoso modificare dopo. |
| R61 | Ogni verbale emesso conserva lo stato storico dell’impianto. La scheda corrente segue le modifiche rilevate e il nuovo verbale ripropone la situazione fotografata nell’ultimo, inclusi potenza, alimentazione ed elementi censiti. | Regola confermata dall’utente. La nuova bozza riparte dalle caratteristiche riutilizzabili dell’ultima situazione pertinente; misure ed esiti sono propri della nuova verifica. Revisioni/import di informazioni più vecchie non devono sovrascrivere uno stato più recente. Mapping e protezione dalla concorrenza sono lavoro tecnico, senza nuovo flusso di approvazione della scheda. |
| R62 | Nessuna matrice delle abilitazioni o filtro dedicato delle qualifiche nell’assegnazione del primo AD_dpr. | L’utente considera il controllo superfluo perché i tecnici abilitati sono soltanto quattro. L’assegnazione rimane una scelta dell’operatore autorizzato; non si aggiungono registri, scadenze o un workflow di qualificazione. Ruoli, permessi e dichiarazione personale d’indipendenza restano questioni distinte. |
| R63 | Dichiarazione d’indipendenza preselezionata come in Garda, escludibile dal tecnico; se esclusa, quel tecnico non può svolgere la verifica. | Scelta esplicita dell’utente, che conserva il default T già presente in ingecert e il blocco operativo quando il campo è F. Superata la proposta di spunta inizialmente vuota. Nessuna nuova approvazione; registrare le modifiche e il tecnico pertinente senza inventare una conferma personale distinta per il solo default. |
| R64 | Il primo AD_dpr deve supportare note di credito sia totali sia parziali. | L’utente conferma che emette anche note di credito parziali. Conservare i percorsi TD04 e il collegamento alla fattura originaria già presenti in Garda; trattamento dei residui, delle somme già incassate e delle eventuali compensazioni da consolidare e collaudare. |
| R65 | Fattura e nota di credito possono essere create anche «in bianco», con righe personalizzate, senza associazione obbligatoria a verbali o verifiche esistenti. | Funzione richiesta anche se rara, da includere nel primo AD_dpr. Già riscontrata nei metadati Garda la creazione diretta del documento e delle righe, con riferimenti operativi non obbligatori. Mantenere il normale ciclo fiscale, documentale ed economico, senza inventare un incarico per consentire l’emissione. |
| R66 | Nella prassi descritta la nota di credito riguarda una fattura non ancora pagata. | Chiarimento dell’utente: normalmente non si pone il rimborso/compensazione di somme già incassate. Caso ordinario: rettifica del credito ancora da riscuotere. Non è un divieto assoluto di emettere una nota su fattura pagata né l’approvazione di una procedura dedicata di rimborso. |
| R67 | Importare nel gestionale gli esiti della fatturazione elettronica da Aruba è una funzione da realizzare; la modalità non viene approfondita ora. | L’utente rinvia la scelta del meccanismo, mantenendo il requisito. Non è approvata l’importazione manuale proposta, né un collegamento automatico. Resta R47: esiti e scarti visibili, tentativi e correzioni conservati. Il rinvio dell’analisi non elimina la funzione dal progetto o la rende facoltativa. |
| R68 | Implementare il nuovo AD_dpr a partire da VerbalizzAI e dal prototipo Python, coerente con il futuro nucleo comune per DM e I&C. Il PHP Garda è riferimento logico e fonte dei dati, non codice da modificare/adattare. | Richiesta esplicita di procedere al codice. Candidatura 0.8.0 realizzata per collaudo; nessun sorgente PHP Garda modificato. Non implica che l’intero gestionale integrato sia già concluso. |
| R69 | I primi test e lo sviluppo si svolgono in locale su Windows. | Vincolo esplicito acquisito. Avvio dedicato con archivio separato, Python 3.12, SQLite e LibreOffice. Hosting rinviato; nessuna bozza offline introdotta. |

Non sono ancora specificati compiutamente: carichi di lavoro, utenti contemporanei, disponibilità richiesta, tempi di recupero, regole di conservazione, collegamenti esterni e tutti i casi economici. Vanno raccolti quando incidono sulle scelte, senza introdurre ora requisiti presunti.

## 3. Materiali disponibili

| Materiale | Contenuto e uso |
|---|---|
| `backup_gestionale.7z` | Sorgenti PHP/JS, dump dei tre database del 7 ottobre 2026 e allegati locali disponibili. Base delle verifiche Garda. |
| `gestionale_poc.zip` e schema/mapping/quadratura v0.1 | Prima prova di migrazione e modello unificato; analizzati come progetto sperimentale. |
| `gestionale_poc_v0.2.zip` e recepimento v0.2 | Migrazione rivista, rieseguita e controllata; presenta ancora punti aperti. |
| `VerbalizzAI_AD_v0.3.32.3.zip` | Sorgente autonomo verificato; nessun archivio operativo completo di produzione ricevuto per la migrazione. |
| `Gestionale_AD_v0.7.1.zip` | Prototipo DPR con anagrafiche, preventivi, verifiche, ponte VerbalizzAI e importatore ingecert. |
| Valutazione e sequenza di sviluppo riportate dall’utente | Proposte esaminate criticamente; non costituiscono di per sé una conferma dello stack o del collaudo. |

Gli originali documentali S3 sono temporaneamente esclusi dalla fornitura, su indicazione dell’utente per motivi di spazio. Non bloccano l’attività corrente. La loro accessibilità e integrità dovranno essere trattate prima di chiudere la migrazione documentale, valutando allora anche un recupero diretto nell’ambiente di destinazione. Non viene richiesta una copia massiva nella conversazione. Restano da acquisire per le rispettive fasi: backup operativo completo di VerbalizzAI, procedure e casi d’uso non ricostruibili dal codice. I documenti 01–15 e il registro delle decisioni citati dalla 0.7.1 non sono nello ZIP.

## 4. Esiti delle analisi già svolte

### 4.1 Gestionali Garda e documenti

I tre sistemi condividono framework PHP `gi`, metadati JavaScript e MariaDB. DPR/DM gestiscono preventivi, verifiche, scadenze e fatturazione; I&C registra attività nei sottopunti dei preventivi, con collaboratori e ripartizioni.

I dump contengono complessivamente 3.500 record cliente. Le fatture elettroniche censite sono 473 DPR, 728 DM e 231 I&C: sono conteggi di fatture, non altrettanti XML originali già verificati.

Il PoC censisce 15.338 riferimenti documentali. **12.398 riferimenti classificati S3 non hanno l’originale locale nel backup fornito**, per circa 3,60 GB secondo le dimensioni registrate. Non è una prova di perdita: serve recuperare lo storage documentale. Per 1.398 riferimenti XML, i nomi sono stati trovati negli ZIP; restano da verificare contenuti e associazioni. Inoltre 34 fatture I&C non hanno il nome file valorizzato.

AD_dm e I&C condividono già dati mediante sincronizzazione. È stata verificata nel PHP la necessità di riportare manualmente alcune rettifiche successive alla sincronizzazione. I dati tecnici e commerciali non sono quindi soltanto duplicati: hanno anche relazioni operative da conservare.

### 4.2 VerbalizzAI e ponte minimo

È confermato il vantaggio di rinviare la sostituzione del backend durante il rilascio. `Archive` non contiene soltanto query: gestisce anche emissioni, revisioni, stato tecnico, utenti e importazioni. Cambiarlo richiede una regressione ampia.

Le verifiche e gli stati tecnici sono JSON strutturati; i documenti hanno hash SHA-256 e i backup verificano contenuti e riferimenti. Queste proprietà aiutano la migrazione, ma non la rendono automaticamente una sequenza di semplici inserimenti.

- **Da aggiungere:** riferimento facoltativo `ext_ingecert_impianto_id`, con controllo dei riferimenti compilati e gestione esplicita delle duplicazioni.
- **Già presente:** codice verbale completo in `header.number`; non serve un secondo campo equivalente.
- **Già presente:** nome e hash del Word importato in `source_meta`; un’ulteriore provenienza logica è facoltativa.
- **Da preservare nella migrazione:** nove tipi di oggetto, versioni, legami fra verifiche, profili tecnici, esportazioni, documenti, utenti, strumenti, firme, impostazioni ed eventi.

Un riferimento facoltativo non garantisce da solo il 100% degli abbinamenti: vanno misurati riferimenti mancanti, errati, duplicati e discordanti. Gli eventi esistenti non equivalgono a una copia completa di ogni precedente salvataggio.

Prove eseguite sul pacchetto autonomo: 255 test Python raccolti, 245 superati e 10 saltati per originali mancanti; quattro suite JavaScript superate; manifesto verificato; esperimento sintetico di conservazione del riferimento nel backup/ripristino. Non sono stati eseguiti una nuova accettazione Windows o nuovi PDF reali. Il ponte non è stato implementato né rilasciato.

### 4.3 Migrazione v0.2

La riesecuzione riproduce la quadratura ricevuta. Tutti i 3.500 JSON cliente sorgente sono conservati esattamente. Sono positivi 23 confronti aggregati e i controlli per record degli importi esaminati; integrità, FK dichiarate e sette riferimenti logici controllati non mostrano violazioni.

La revisione resta aperta per questi motivi:

- **Identità delle tarature:** 622 righe e 480 incarichi sono associati all’attrezzatura anziché alla valvola. Una correzione su copia diagnostica elimina le 244 tarature sul tipo di bene errato e ricostruisce 336 valvole con fonte I&C. Gli originali non sono stati modificati e la prova non è una release pronta.
- **Fusioni fiscali:** tre nuovi gruppi con CF comune e P.IVA differenti richiedono revisione. Il risultato effettivo è 2.472 clienti canonici, non 2.475.
- **Date discordanti:** la v0.2 applica già la prevalenza I&C a 41 date CND, pur lasciando aperti i conflitti. La prova corretta delle tarature fa emergere altre 17 discordanze. Le categorie possono sovrapporsi.
- **Rettifiche del recepimento:** 427 conflitti anagrafici e 508 segnalazioni nella quadratura ricevuta; 30 utenti primari più 10 alias non costituiscono una mappa completa delle origini dei 40 account.
- **Ancora necessari:** importi esatti nel modello operativo, identità stabili, import incrementale, storicizzazione dell’emittente, recupero dei documenti e validazione delle coperture/scadenze.

Questi sono problemi della migrazione sperimentale; non vanno attribuiti automaticamente a Garda.

### 4.4 Gestionale_AD v0.7.1

È lavoro recuperabile: contiene FastAPI, SQLAlchemy/Alembic, interfaccia HTML/JS, anagrafiche, tariffario, preventivi, verifiche, controlli documentali e ponte con VerbalizzAI. La copia incorporata è la 0.3.32.1, mentre il pacchetto autonomo analizzato è la 0.3.32.3.

La 0.7.1 contiene già un importatore ingecert. Il suo lettore è stato eseguito: i conteggi delle 13 tabelle selezionate coincidono con l’estrazione precedente. Non è stato eseguito l’importatore applicativo completo in questa revisione. Sono stati verificati sintatticamente 116 file Python, senza errori. I 107 test dichiarati dal progetto non sono stati rieseguiti.

Restano scelte DPR da adattare al nucleo delle tre attività e problemi di comportamento elencati più avanti. La presenza del prototipo non dimostra che l’integrazione sia già conclusa.

## 5. Avanzamento effettivo

| Attività | Stato al 8 ottobre 2026 | Esito o lavoro residuo |
|---|---|---|
| Reperimento e inventario dei backup | Completato per i materiali ricevuti | Sorgenti e dump disponibili; originali S3 rinviati su richiesta, non bloccanti per la fase concettuale. |
| Analisi iniziale delle tre attività | Completata come prima ricognizione | Regole e criticità individuate; non è un audit completo. |
| Revisione VerbalizzAI 0.3.32.3 | Completata sul pacchetto | Ponte minimo definito; archivio reale e modifica ancora da trattare. |
| Riesecuzione/revisione migrazione v0.2 | Eseguita, chiusura aperta | Prova diagnostica sulle tarature; correzioni definitive e nuova quadratura da fare. |
| Esame Gestionale_AD 0.7.1 | Completato come revisione mirata | Componenti candidati al riuso e comportamenti da riprogettare. |
| Catalogo concettuale delle inefficienze | Prima versione prodotta | Da validare con esempi d’uso, procedure e decisioni precedenti. |
| Processo scadenza–offerta–incarico | Prima specifica e mappa delle transizioni prodotte | Regole e casi nella sezione 15; confronto mirato Garda/0.7.1, controlli proposti e criteri di accettazione nella sezione 23. |
| Preparazione e finalizzazione del preventivo DPR | Requisiti documentali raccolti; sorgenti 0.7.1 confrontati | Ciclo anteprima–ritocco già recuperabile; firma, convenzione di nome e download automatico da completare. |
| Schema operativo definitivo e stack | Non consolidati | Non risulta una conferma esplicita dello stack nella conversazione disponibile. |
| Nuovo backend integrato, fatturazione e allegati | Non realizzati in questa sessione | Esistono PoC e prototipo ricevuti, non una nuova implementazione unificata conclusa. |
| Rilascio/cutover del gestionale integrato | Non avviato | Nessuna modifica ai gestionali in produzione. |

Le verifiche sono state svolte su copie dei materiali. Il codice del prototipo è stato ricevuto dall’utente; non viene presentato come sviluppo realizzato durante questa analisi.

## 6. Decisioni aperte

**Elenco operativo aggiornato:** la sezione 25 raccoglie i quattordici punti strutturali da chiudere prima dello sviluppo di partenza, distinguendoli dalle decisioni acquisite, dalle verifiche tecniche e dai dettagli rinviabili. La tabella seguente conserva il quadro sintetico.

| Decisione | Proposta o vincolo emerso | Stato |
|---|---|---|
| Stack | Python + FastAPI + SQLAlchemy/Alembic, HTML/JS; SQLite per sviluppo e possibile PostgreSQL in produzione. | Proposta riportata dall’utente; conferma non attestata. La 0.7.1 usa già parte di questo stack, ma non costituisce una scelta definitiva. |
| Stato tecnico e anagrafiche | Definire un proprietario del dato e regole di aggiornamento fra nucleo e VerbalizzAI. | Da decidere prima dell’integrazione definitiva. |
| Contratti DPR a scadenza e affidamenti pluriennali | Il nuovo contratto a ogni scadenza è il percorso ordinario; il pluriennale è un’eccezione esplicita. | Prassi chiarita dall’utente. Restano da definire prezzi, ambito e condizioni degli affidamenti pluriennali. |
| Riesame, consegna e fatturazione | Prassi attuale dichiarata: RV, poi consegna e fatturazione. Mappa nella sezione 23, proposta di percorso ordinario ed eccezione controllata nella sezione 24, con riscontro RG-01-04. | Primo esercizio con invio dopo riesame; rilascio immediato rinviato. Restano gestione delle correzioni da RV, dettagli della sospensione e rettifiche economiche. |
| Prevalenza delle scadenze discordanti | Non trattare una scelta implicita del migratore come decisione aziendale. | Politica da approvare sui casi reali. |
| Identità comuni | Revisione delle fusioni controverse e mappa completa delle origini. | Da completare prima dell’uso operativo. |
| Convivenza e passaggio | Un’autorità di scrittura dichiarata per ciascuna funzione; riallineamento e finestra di passaggio verificabili. | Piano da costruire; nessun cutover autorizzato o eseguito qui. |

Lo schema operativo proposto include importi in centesimi/decimal esatti, FK dichiarate e registro delle esportazioni Word/PDF. Sono requisiti di progettazione, non modifiche già applicate al PoC. La numerazione concorrente e il passaggio a PostgreSQL richiedono verifica concreta: il prototipo si appoggia anche a un blocco nel singolo processo.

## 7. Sequenza aggiornata e prossimo lavoro

La sequenza di sette passi riportata in conversazione — schema, backend, regole DPR, VerbalizzAI, fatturazione, allegati, cutover — è una base utile, ma la richiesta più recente inserisce **la progettazione dei processi prima di altro sviluppo**.

1. Descrivere i problemi quotidiani e validare i comportamenti desiderati, cominciando da scadenza, offerta e incarico.
2. Consolidare concetti comuni, regole specifiche, casi eccezionali e criteri di accettazione.
3. Scegliere componenti da recuperare dalla 0.7.1, confermare le scelte tecniche e correggere schema/migrazione con nuova quadratura.
4. Realizzare il minimo percorso DPR completo con VerbalizzAI e fatturazione; preparare in parallelo l’inventario degli allegati.
5. Collaudare sui casi reali, definire convivenza e cutover DPR; estendere DM e I&C dopo validazione nell’uso.

Prima attività concreta proposta: ricostruire un caso DPR normale e uno problematico dal momento in cui compare nello scadenzario fino alla consegna e fatturazione. In parallelo, usare un caso di taratura/CND I&C per verificare che il nucleo non sia troppo specifico del DPR.

Le sezioni successive costituiscono la prima proposta concettuale da discutere. Il documento verrà aggiornato sulla stessa base distinguendo ogni nuova decisione, evidenza e attività conclusa; non è un aggiornamento automatico in assenza di ulteriore lavoro.

## 8. Cosa recuperare dalla 0.7.1

| Parte | Valutazione | Uso proposto |
|---|---|---|
| Accesso, ruoli, permessi, griglie, registro e backup | Fondamenta già sviluppate, candidate al riuso | Valutarle sul sistema comune e sui permessi distinti per ambito e società. |
| Anagrafiche e ricerca | Buon punto di partenza per l’interfaccia | Conservare le funzioni utili; progettare identità condivisa e condizioni commerciali specifiche. |
| Tariffario, importi in centesimi, preventivi e revisioni documentali | Lavoro concreto da recuperare | Conservare prezzi storici e documenti emessi; distinguere offerta, accordo commerciale e lavoro operativo. |
| Verifiche, assegnazione, riesame e storico | Prototipo utile per discutere il DPR | Rivedere stati, prerequisiti e casi eccezionali prima di assumerli come modello comune. |
| Ponte con VerbalizzAI | Dimostra già il percorso incarico–bozza–emissione | Recuperare l’esperienza; rendere affidabili aggiornamenti, correzioni e proprietà dei dati. |
| Importatore Garda | Utile per leggere e mostrare i dati reali DPR | Trattarlo come importazione iniziale; progettare a parte la convivenza e il riallineamento. |

Una precisazione: sebbene il progetto sia nato senza il backup Garda, **la versione ricevuta contiene già un importatore del dump ingecert**. Legge anagrafiche, preventivi, verifiche e utenti. Non importa ancora fatture, pagamenti e contenuti dei PDF conservati in S3, e richiede un archivio senza clienti. Non è quindi già la migrazione incrementale del gestionale integrato.

La copia incorporata di VerbalizzAI è la 0.3.32.1; il sorgente autonomo ricevuto è la 0.3.32.3. Il riuso dovrà evitare che i due rami perdano le correzioni reciproche.

## 9. Primo catalogo dei problemi

La distinzione fra le origini è essenziale: un difetto del prototipo o della migrazione non dimostra un difetto di Garda. Viceversa, una regola utile di Garda non va eliminata solo perché il nuovo sistema è più semplice.

| Tema | Evidenza e origine | Comportamento da progettare |
|---|---|---|
| Aggiornamenti AD_dm/I&C | **Garda, accertato.** Due archivi e sincronizzazione delle attività. Il PHP avverte che date modificate dopo la sincronizzazione vanno riportate manualmente in AD_dm. | Registrare una sola attività sul bene corretto; tutte le viste interessate leggono lo stesso dato. Una rettifica aggiorna le conseguenze e lascia traccia. |
| Identità comuni | **Garda e migrazione.** Anagrafiche separate; nella migrazione esistono conflitti e abbinamenti da verificare. | Un’identità condivisa, con origini conservate. Condizioni, referenti, autorizzazioni e documenti possono restare diversi per attività o società. Nessuna fusione basata soltanto sul nome. |
| Significato della scadenza | **Prototipo, rischio verificato nel codice.** Il collegamento al preventivo usa impianto e data, senza distinguere la prestazione e lo stato del lavoro associato. | Distinguere bisogno tecnico, offerta, accettazione e programmazione. Una verifica straordinaria non deve apparire automaticamente come copertura di quella periodica. |
| Stato del lavoro e fatturazione | **Prototipo, accertato.** “Riesaminata” è etichettata “da fatturare”; per gli storici già fatturati l’informazione è nelle note. | Avanzamento operativo, riesame, consegna e fatturazione devono essere interrogabili separatamente. Una pratica già fatturata non entra nella lista delle nuove fatture. |
| Indipendenza del verificatore | **Regola utile di Garda.** La dichiarazione blocca programmazione/registrazione/esecuzione. Nella 0.7.1 il dato storico è nelle note e non è un controllo strutturato della verifica. | Conservare la dichiarazione come evidenza dell’incarico, con autore e data. Definire cosa succede se cambia il verificatore. |
| Componenti e campioni | **Prototipo, rischio accertato nel codice.** Gli elementi derivano dai campioni del verbale; quelli prima presenti ma non campionati vengono resi non attivi. | Distinguere “esistente”, “campionato”, “non campionato” e “dismesso”. La dismissione richiede un fatto esplicito, non l’assenza da un campione. |
| Dati tecnici e rettifiche | **Prototipo, accertato.** Un verbale più vecchio non cambia le date correnti, ma può comunque sovrascrivere caratteristiche ed elementi. | Il documento storico conserva ciò che attestava allora; lo stato corrente dipende da eventi validi e ordinati, con correzioni esplicite. |
| Emissione e aggiornamento gestionale | **Prototipo, accertato.** VerbalizzAI emette prima; se l’aggiornamento del gestionale fallisce, il codice invita a caricare il verbale manualmente. | Il completamento deve essere affidabile e recuperabile senza duplicare documenti, numeri o lavoro dell’operatore. Un’incompletezza deve comparire in una lista da risolvere. |
| Rinnovo dei contratti DPR | **Prassi chiarita dall’utente.** Nuovo contratto a scadenza in circa 99 casi su 100; affidamenti pluriennali solo in casi particolari. | Rendere rapido e controllato il nuovo contratto; gestire separatamente l’eccezione pluriennale senza rinunciare all’autorizzazione e alle condizioni della singola prestazione. |

Nel dump I&C ci sono 40 attività effettuate in attesa di sincronizzazione, di cui 26 CND e 14 tarature. È una misura concreta della coda da riconciliare, non la prova che tutte le 40 date AD_dm siano sbagliate.

Garda distingue già le righe VP da altre prestazioni nel collegamento fra preventivo e scadenza, e considera lo stato della verifica associata. Qui il prototipo va migliorato conservando una distinzione già presente nel sistema attuale.

Gli abbinamenti errati delle tarature alle attrezzature, individuati nella precedente revisione del PoC, sono invece **errori della migrazione**: non vanno attribuiti al gestionale Garda. Insegnano comunque che il modello futuro deve distinguere valvola, attrezzatura e relazione di installazione.

## 10. Il funzionamento comune da definire

Il nucleo dovrebbe esprimere sette concetti di lavoro, prima di diventare uno schema di database:

1. **Soggetto e sede:** chi è coinvolto e dove si svolge il lavoro. Identità condivisa, senza perdere condizioni e contatti pertinenti alla singola attività.
2. **Bene:** impianto, attrezzatura, valvola o altro oggetto identificabile, con storia delle relazioni. Le caratteristiche tecniche restano specifiche per tipologia.
3. **Prestazione o obbligo:** cosa occorre fare, su quale bene, con quale periodicità o motivo. Uno stesso bene può avere più scadenze indipendenti.
4. **Accordo commerciale:** quale prestazione è autorizzata, a quali condizioni e per quale società. Una variazione futura non cambia gli importi già concordati o fatturati.
5. **Incarico e intervento:** chi deve eseguire cosa, quando e con quali prerequisiti; cosa è stato effettivamente eseguito, anche se parziale, sospeso o a vuoto.
6. **Documento e riesame:** quale versione attesta il lavoro, quale controllo è stato eseguito e quale versione è stata consegnata. Il documento emesso conserva la propria storia.
7. **Fatturazione e incasso:** quali prestazioni sono fatturabili, già fatturate, parzialmente fatturate o incassate. Questi fatti non dipendono dal solo stato tecnico dell’incarico.

Questo non significa aggiungere sette maschere o far compilare più campi. **L’operatore registra il fatto una volta; il sistema deriva gli stati e presenta la prossima azione pertinente.** Le viste DPR, DM e I&C mostrano soltanto i dettagli utili al proprio lavoro.

AD S.r.l. e I&C S.r.l. rimangono soggetti distinti per emissione e contabilità. La condivisione dell’anagrafica non le rende una società unica, né va confusa con la precedente incorporazione di I&C snc.

## 11. Esempi con cui validare il progetto

Questi sono criteri di accettazione del comportamento, non test applicativi già eseguiti.

| Caso reale da simulare | Risultato atteso |
|---|---|
| Un cliente riceve una verifica DPR e una prestazione I&C | Identità comune; incarichi, condizioni, documenti e società emittente corretti per ciascuna prestazione. |
| I&C completa una taratura e successivamente rettifica la data | La taratura resta associata alla valvola corretta. Le viste DM e I&C concordano; la rettifica è tracciata e non richiede ricopiatura. |
| Un impianto ha una periodica in scadenza e un preventivo per una straordinaria | La periodica rimane visibile come lavoro da gestire, salvo una regola esplicita e approvata che stabilisca diversamente. |
| Una verifica campiona 8 componenti su 30 esistenti | Gli altri 22 restano nell’inventario; sono semplicemente non campionati in quella verifica. |
| Si importa un verbale storico successivamente a uno recente | Lo storico si aggiunge senza sostituire silenziosamente lo stato tecnico corrente. |
| Il riesame richiede una correzione del verbale | Si apre la revisione pertinente, restano disponibili documento ed evidenze precedenti, e si identifica la versione da consegnare. |
| L’aggiornamento del gestionale si interrompe dopo l’emissione | Il sistema recupera l’aggiornamento sullo stesso verbale; non genera un secondo numero o una seconda fattura. |
| Una verifica importata è già fatturata in Garda | È consultabile nello storico ed esclusa dalle prestazioni ancora da fatturare. |
| Un intervento viene annullato o eseguito parzialmente | Restano espliciti motivo, prestazioni realmente svolte, conseguenze sulle scadenze e trattamento economico concordato. |

## 12. Primo ambito di confronto con chi usa il gestionale

Partirei dal percorso **scadenza → contatto/offerta → incarico**, perché determina sia il lavoro della segreteria sia quello dei tecnici. Per ogni passaggio descriviamo: chi agisce, cosa deve conoscere, cosa ricopia oggi, quale controllo serve, quale risultato deve ottenere e quali eccezioni incontra.

Le prime decisioni da esplicitare sono:

| Decisione | Proposta iniziale da validare |
|---|---|
| Quando una scadenza è “gestita”? | Mostrare separatamente “da contattare”, “offerta preparata/inviata”, “accettata”, “incarico aperto” e “programmata”. Nessuna offerta nasconde da sola l’obbligo tecnico. |
| Serve un nuovo contratto per ogni scadenza DPR? | Chiarito: normalmente sì, circa 99 casi su 100. Gli affidamenti pluriennali sono un’eccezione da supportare, non il nuovo modello ordinario. |
| Quando si può consegnare un verbale e quando si può fatturare? | Definire condizioni distinte secondo le procedure aziendali, inclusi esiti negativi, sospensioni, interventi a vuoto e riesami non conformi. |
| Quali dati sono realmente condivisi? | Identità di soggetti e beni; condizioni economiche, destinatari e permessi specifici dove necessario. Stabilire anche chi può correggere il dato comune. |
| Come cambia una scadenza dopo una rettifica? | Conservare fonte e motivo della data; ricalcolare soltanto gli effetti pertinenti. Stabilire regole per straordinarie, annullamenti e beni spostati o dismessi. |

L’ordine di riesame, emissione e consegna deve essere definito con le procedure vigenti; questa analisi non certifica la conformità a ISO/IEC 17020. Garda e il prototipo sono fonti di comportamento, non sostituti della decisione organizzativa.

Per ogni miglioramento userei una scheda breve: **problema osservato; esempio; comportamento desiderato; regola da conservare; eccezioni; criterio di accettazione**. Solo dopo la validazione della scheda scegliamo cosa riusare, adattare o costruire.

## 13. Evidenze della revisione concettuale e riferimenti

Sono stati letti modelli, servizi, API, importazione, ponte VerbalizzAI e documentazione della 0.7.1, confrontandoli con i flussi PHP Garda. I 116 file Python esaminati non presentano errori di sintassi nella verifica statica.

È stato eseguito il solo lettore del dump della 0.7.1: i conteggi delle 13 tabelle selezionate coincidono con quelli dell’estrazione precedente, fra cui 1.910 clienti, 2.674 sedi, 2.694 impianti, 1.009 preventivi, 1.866 righe e 1.438 verifiche. Questo verifica la lettura quantitativa, non la trasformazione applicativa o la correttezza di ogni valore.

La documentazione dichiara 107 test automatici. Non sono stati rieseguiti in questa revisione; le dipendenze applicative non sono installate nell’ambiente corrente. Non è stato effettuato un collaudo operativo della 0.7.1 e non viene dichiarata pronta alla produzione.

Il LEGGIMI rinvia ai documenti 01–15 del progetto “Gestionale completo AD_dpr” e a un registro delle decisioni: non sono presenti nello ZIP. Le proposte qui indicate restano da confrontare con quei documenti e con i casi d’uso degli operatori.

Riferimenti principali ai sorgenti:

- Garda DPR: [controlli della verifica e ricalcolo scadenze](sandbox:/workspace/scratch/4e6614e59745/analysis/legacy/backup_gestionale/ingecert/codice/files/public_html/cust/_custom.php).
- Garda I&C: [attività e rettifiche dopo la sincronizzazione](sandbox:/workspace/scratch/4e6614e59745/analysis/legacy/backup_gestionale/iec/codice/files/public_html/cust/_custom.php).
- Prototipo: [stati e modello delle verifiche](sandbox:/workspace/scratch/4e6614e59745/analysis/gestionale_ad_v071/Gestionale_AD_v0.7.1/gestionale/moduli/verifiche/modelli.py), [aggiornamenti di impianto e componenti](sandbox:/workspace/scratch/4e6614e59745/analysis/gestionale_ad_v071/Gestionale_AD_v0.7.1/gestionale/moduli/verifiche/servizio.py).
- Prototipo: [legame scadenza–preventivo](sandbox:/workspace/scratch/4e6614e59745/analysis/gestionale_ad_v071/Gestionale_AD_v0.7.1/gestionale/moduli/preventivi/griglie.py), [importazione Garda](sandbox:/workspace/scratch/4e6614e59745/analysis/gestionale_ad_v071/Gestionale_AD_v0.7.1/gestionale/moduli/garda/importa.py), [emissione e aggiornamento del gestionale](sandbox:/workspace/scratch/4e6614e59745/analysis/gestionale_ad_v071/Gestionale_AD_v0.7.1/gestionale/moduli/verbali/api.py).

## 14. Analisi di dettaglio e storico del documento

- [Analisi iniziale dei tre gestionali](sandbox:/workspace/scratch/4e6614e59745/deliverables/01_Analisi_iniziale_gestionale_integrato_2026-10-08.md).
- [Valutazione VerbalizzAI e ponte minimo](sandbox:/workspace/scratch/4e6614e59745/deliverables/02_Valutazione_VerbalizzAI_ponte_integrazione_2026-10-08.md).
- [Revisione della migrazione v0.2](sandbox:/workspace/scratch/4e6614e59745/deliverables/03_Revisione_migrazione_v0.2_2026-10-08.md).

| Versione | Data | Aggiornamento |
|---|---|---|
| 1.0 | 8 ottobre 2026 | Prima sintesi unitaria di requisiti, materiali, analisi, avanzamento, decisioni aperte e catalogo concettuale; incorpora la revisione della 0.7.1. |
| 1.1 | 8 ottobre 2026 | Registrato il rinvio degli originali S3; sviluppato il processo scadenza–offerta–incarico con casi DPR e I&C, eccezioni e criteri di accettazione. |
| 1.2 | 8 ottobre 2026 | Raccolta la prassi DPR del contratto a ogni scadenza e dell’eccezione pluriennale; aggiornate le proposte precedenti e definito il primo comportamento di rinnovo. |
| 1.3 | 8 ottobre 2026 | Raccolte le basi tariffarie AD_dpr e la possibilità di sconto nelle gare PA; aperto il chiarimento sul calcolo delle ore per i luoghi con pericolo di esplosione. |
| 1.4 | 8 ottobre 2026 | Chiarito che ATEX segue l’importo preventivato senza consuntivo; verificato il percorso tariffa–preventivo–verifica–fattura nel codice; formalizzato il metodo di analisi prima delle domande. |
| 1.5 | 8 ottobre 2026 | Raccolto il requisito di anteprima PDF e correzione iterativa Word come in VerbalizzAI; verificato il riuso del flusso documentale 0.7.1; aggiunti firma/finalizzazione, nome file e download automatico con destinazioni da definire. |
| 1.6 | 8 ottobre 2026 | Recepito il termine “preventivo”; separati i dettagli rinviati dalle scelte strutturali; formulata la proposta di nucleo integrato con primo rilascio DPR autonomo e le cinque domande per delimitarlo. |
| 1.7 | 8 ottobre 2026 | Recepiti fatturazione/incassi completi, intestatario fattura distinto, programmazione separata e riesame obbligatorio dopo accettazione prima dell’affidamento; verificati i relativi riferimenti Garda e chiarita la domanda sulla connessione. |
| 1.8 | 8 ottobre 2026 | Scelto il primo rilascio solo online; chiusa Q4 e consolidata la scheda del primo AD_dpr, con proposta del nucleo concettuale e casi da verificare. |
| 1.9 | 8 ottobre 2026 | Ricostruito il ciclo DPR dai servizi e metadati; aggiunta la mappa di azioni, prerequisiti ed effetti, con controlli da rafforzare e casi di accettazione. Aperta la decisione sul riesame prima della consegna del verbale; fatturazione/incassi completi restano nel perimetro, con censimento dettagliato ancora da completare. |
| 1.10 | 8 ottobre 2026 | Raccolta la prassi RV–consegna–fattura; verificati RG-01-04 rev.03 §2.7 e rev.04 §2.5. Proposti percorso ordinario dopo RV ed eccezione controllata di rilascio immediato, soprattutto DPR, compatibili con l’uso online. Separata la decisione di attivazione dalla predisposizione del modello; recepito il vincolo esplicito di semplicità del flusso e dei controlli. |
| 1.11 | 8 ottobre 2026 | Consolidato l’elenco dei quattordici punti da decidere prima del codice iniziale, con proposte semplici e risultati attesi; distinti requisiti acquisiti, lavoro tecnico e decisioni che possono attendere il collaudo/cutover. |
| 1.12 | 8 ottobre 2026 | Chiarito D01 per il ciclo DPR: stesso datore di lavoro su impianto/preventivo/verbale, terzo soltanto in fattura. Ritirata la proposta di un diverso committente commerciale prima della fatturazione; recepito il vincolo di discussione preventiva delle modifiche alle logiche ed entità Garda. |
| 1.13 | 8 ottobre 2026 | Verificati anagrafica cliente, viste collegate e generazione preventivo Word Garda: dati correnti e assenza di una storia strutturata riscontrata. Acquisito il requisito di immutabilità di verbali/preventivi emessi; separati cambio dei dati della stessa azienda e subentro di altra azienda. Il trasferimento del bene è ancora da discutere. |
| 1.14 | 8 ottobre 2026 | Acquisita la scelta sul subentro DPR: nuovo cliente, stesso impianto e passaggio tracciato, con emessi precedenti preservati. Avviato il confronto D02 sul rapporto valvola–attrezzatura partendo dai metadati Garda, senza adottare nuove relazioni. |
| 1.15 | 8 ottobre 2026 | Acquisita la gestione semplice dell’abbinamento valvola–attrezzatura: dato corrente modificabile manualmente e storico tarature/documenti, senza storico dei montaggi aggiuntivo. Prosegue D03 sulla responsabilità delle correzioni anagrafiche. |
| 1.16 | 8 ottobre 2026 | Riclassificata la modifica anagrafica come configurazione di ruoli/permessi, non blocco del modello. Verificato il momento di aggiornamento delle scadenze DPR in Garda: ultima VP effettuata, senza richiedere RV conforme. La scelta futura su quel momento è ancora aperta. |
| 1.17 | 8 ottobre 2026 | Confermato aggiornamento scadenza DPR prima del RV, con adeguamento alle revisioni pertinenti. Riscontrata in Garda la riapertura/ricaricamento dopo RV negativo, senza revisione strutturata del verbale individuata; VerbalizzAI e ponte 0.7.1 contengono già revisioni. Prosegue D06 sull’evidenza di accettazione. |
| 1.18 | 8 ottobre 2026 | Acquisita l’evidenza scritta di accettazione DPR: preventivo controfirmato oppure email, senza accettazione telefonica. Il confronto D06 prosegue con l’aggiunta di prestazioni dopo l’accettazione; nessuna scelta automatica fra nuovo preventivo e revisione dell’accettato. |
| 1.19 | 8 ottobre 2026 | Preventivo accettato non modificabile: nuove prestazioni con nuovo preventivo integrativo, secondo il normale flusso di accettazione e RC. Acquisita la possibilità di fattura unica per prestazioni di preventivi diversi. Prossimo chiarimento: copertura degli interventi negli affidamenti pluriennali. |
| 1.20 | 8 ottobre 2026 | Corretto il confronto con Garda: fattura unica già disponibile tramite generazione da riga preventivo e associazione a fattura esistente, confermata nel sorgente della maschera. Raccolta la lacuna sui pluriennali (solo prossima scadenza) e la loro rarità. Raccomandato il rinvio di una gestione dedicata, preservando il flusso ordinario e gestendo manualmente le eccezioni. Nessuna nuova struttura contrattuale approvata. |
| 1.21 | 8 ottobre 2026 | Acquisito il significato degli stati DPR: programmazione facoltativa, registrazione durante l’esecuzione, eseguita solo con verbale finalizzato e caricato. Raccolta la proposta utente di stato sospesa quando la verifica non può essere eseguita. Da chiarire ripresa dello stesso incarico ed eventuale numero già assegnato. Aggiornata la mappa per evitare di chiamare eseguita la sola uscita fisica. |
| 1.22 | 8 ottobre 2026 | Confermata la continuità della verifica sospesa: ripresa sullo stesso incarico e conservazione dell’eventuale numero di verbale già assegnato. Nessuna creazione automatica di un nuovo incarico o duplicazione del numero per la sola sospensione. Prossimo chiarimento: eventuale addebito per uscita senza verifica conclusa. |
| 1.23 | 8 ottobre 2026 | Raccolta l’esigenza nuova di sopralluogo a vuoto addebitabile, oggi non gestita. Proposta una voce economica manuale distinta dalla verifica annullata, senza tariffa o addebito automatico. Avviato il chiarimento D11 sulla prassi DPR di acconti prima dell’esecuzione. Nessuna modifica applicativa. |
| 1.24 | 8 ottobre 2026 | Acquisita la prassi DPR sugli acconti: non ordinari ma possibili, quindi da supportare nel ciclo completo. Distinti acconto fatturato, incasso e collegamento al saldo. Prossimo chiarimento D11: modalità effettiva di trasmissione delle fatture elettroniche ed esiti. Nessuna modifica applicativa. |
| 1.25 | 8 ottobre 2026 | Acquisito il canale elettronico attuale: download XML da Garda e caricamento manuale su Fatturazione Elettronica Aruba. Conservazione del percorso nel primo DPR, con integrazione automatica rinviabile. Il ciclo completo di fatturazione/incassi resta richiesto. Prossimo chiarimento: dove vengono registrati gli incassi e controllati i crediti aperti. |
| 1.26 | 8 ottobre 2026 | Confermato Garda come riferimento operativo attuale per incassi e fatture ancora da pagare. Il primo AD_dpr conserva questa gestione; Aruba è il servizio di trasmissione delle fatture. Prossimo chiarimento D12: un unico bonifico a copertura di più fatture, rispetto al riferimento singolo per riga pagamento presente in Garda. |
| 1.27 | 8 ottobre 2026 | Confermato il caso occasionale di un bonifico per più fatture. Proposta una maschera unica di ripartizione con quote per fattura, conservando il collegamento singolo Garda. La modalità resta da validare prima di adottarla; nessuna modifica applicativa o nuova relazione finanziaria approvata. |
| 1.28 | 8 ottobre 2026 | Precisata la modalità minima di incasso: pagamento unico, normalmente associato a una fattura, eccezionalmente a più fatture. Superata la domanda su una maschera dedicata: basta estendere la normale associazione, conservando quote e totale. Prossimo chiarimento: dove vengono consultati o riportati gli esiti SdI. |
| 1.29 | 8 ottobre 2026 | Esiti oggi soltanto su Aruba, senza traccia in Garda: acquisito il requisito di importazione nel nuovo AD_dpr e di visibilità degli scarti da gestire. Conservazione degli esiti e dei tentativi sulla fattura; modalità tecnica da definire. Prossimo chiarimento: correzione della fattura scartata in Garda o direttamente in Aruba. |
| 1.30 | 8 ottobre 2026 | L’utente non ha una policy precisa sul luogo di correzione delle fatture scartate. Registrata la scelta aperta e proposta la correzione nel nuovo gestionale con rigenerazione XML, per allineare dati interni e contenuto trasmesso. Proposta da validare, non requisito approvato né implementazione. |
| 1.31 | 8 ottobre 2026 | Approvata la correzione delle fatture scartate nel nuovo gestionale, con rigenerazione XML e nuovo caricamento su Aruba, conservando tentativi ed esiti. Verificate le serie nei backup: DPR, DM, EX/ex in adsrl e serie annuale IEC. Prossimo chiarimento: attività cui corrisponde la serie EX, senza presumere una fusione delle numerazioni. |
| 1.32 | 8 ottobre 2026 | Chiarita dall’utente la serie EX di AD: CND GVR, efficienza delle valvole di sicurezza e verifiche ispettive volontarie SC/SP/GVR. Aggiornata l’interpretazione delle serie senza rinumerazioni. Prossimo chiarimento di nucleo comune: fatture separate o aggregate per prestazioni DM ed EX dello stesso cliente. |
| 1.33 | 8 ottobre 2026 | Confermate fatture separate per prestazioni DM ed EX dello stesso cliente, con serie distinte anche nei preventivi. Precisato il limite rispetto alla fattura unica da più preventivi già acquisita. Nessuna generalizzazione automatica agli altri abbinamenti. Prossima scelta sul primo DPR: attivazione del rilascio immediato del verbale, già previsto come opzione. |
| 1.34 | 8 ottobre 2026 | Confermato per ora l’invio dopo riesame nel primo DPR; opzione di rilascio immediato rinviata. Aggiornati i punti aperti precedenti. Riscontro Garda: RV negativo riporta la verifica a registrata. Prossimo confronto: mantenere quel ritorno o tenere distinta la sola correzione documentale nello stato RV. |
| 1.35 | 8 ottobre 2026 | Confermato il ritorno a registrata dopo RV negativo, con ripetizione dell’attività e/o correzione del verbale, ricaricamento ed eseguita prima del nuovo RV. Acquisiti nota RT visibile al verificatore e storico dei riesami per verbale/versione. Verificato il reset della nota corrente in Garda e gli eventi RV nel prototipo, da riutilizzare. Prossimo chiarimento D13: trasferimento o completamento in Garda degli incarichi DPR aperti al passaggio. |
| 1.36 | 8 ottobre 2026 | Acquisita la preferenza per importare gli incarichi DPR aperti, con decisione definitiva subordinata alla valutazione. Nel dump ingecert verificati 159 record negli stati assegnata/programmata/registrata e 3 effettuate senza RV fatto; la prova di import deve coprire questi casi. Prossimo chiarimento DPR: nuovo preventivo/incarico per ricontrollo straordinario dopo esito tecnico negativo. |
| 1.37 | 8 ottobre 2026 | Confermata la verifica straordinaria con preventivo distinto e verbale VS. Riscontrate in ingecert le tipologie VP/VS e la numerazione annuale comune. Ribadito il confronto obbligatorio con Garda per ogni requisito concordato: conservare l’esistente utile, documentare soltanto i miglioramenti necessari. Registrato un primo riscontro ANAC sugli sconti nelle procedure pubbliche, senza dichiarare conclusa la verifica delle condizioni applicabili. |
| 1.38 | 8 ottobre 2026 | Chiarita e confermata la numerazione DPR 462: progressivo unico annuale, prefissi VP/VS secondo il tipo. Il requisito conserva la logica ingecert esistente. Verificato inoltre che il ricalcolo Garda della scadenza periodica usa la VP effettuata e non la VS; prossimo chiarimento sulla prassi da mantenere. |
| 1.39 | 8 ottobre 2026 | Confermata la conservazione della regola Garda: VS senza ricalcolo automatico della scadenza periodica. Verificati flag dismessa, condizioni che impediscono nuove offerte da scadenza e generazione di verifiche per impianti dismessi; nel codice esaminato non risulta un annullamento automatico degli incarichi già aperti. Prossimo chiarimento sulla loro chiusura. |
| 1.40 | 8 ottobre 2026 | Confermata la chiusura manuale degli incarichi aperti su impianti dismessi, senza annullamento automatico. Riscontrata in ingecert l’accettazione per riga e il riepilogo accettato_parzialmente; prossimo chiarimento sulla sua rilevanza nella prassi DPR. |
| 1.41 | 8 ottobre 2026 | Confermata l’accettazione parziale sullo stesso preventivo, conservando una funzione già presente in ingecert. Riscontrato che il RC Garda è memorizzato sulla testata e letto dalle righe; il percorso esaminato non lo azzera alla successiva accettazione di un’altra riga. Prossimo chiarimento: portata del riesame nel caso di accettazioni successive. |
| 1.42 | 8 ottobre 2026 | Acquisita la semplificazione: RC sull’intera offerta invariata, senza ripeterlo per successive accettazioni di righe già incluse. Conservata la logica Garda con RC sulla testata. Esteso il riscontro sugli incassi: calcolo rate e residui presente nel codice; non individuato nel modulo personalizzato un import bancario dedicato. Prossimo chiarimento sul perimetro della registrazione incassi iniziale. |
| 1.43 | 8 ottobre 2026 | Confermati incassi manuali nel primo AD_dpr; import estratti conto richiesto come modulo necessario successivo. Riesaminato il registro D01–D14 per distinguere domande operative, verifiche tecniche e moduli futuri. Raccomandato di chiudere il DPR operativo e verificare ora soltanto la compatibilità strutturale del nucleo con DM/I&C, senza estendere il questionario ai loro flussi completi. |
| 1.44 | 8 ottobre 2026 | Confermato il perimetro: DPR operativo e compatibilità del nucleo con DM/I&C. Avviato il primo dei tre blocchi finali, dati tecnici: VerbalizzAI ha già la scelta di aggiornare/conservare la scheda all’emissione; il prototipo aggiorna caratteristiche al caricamento. Individuati controlli da correggere nel ponte, inclusa la scadenza automatica sulle VS. Nessuna modifica applicativa eseguita. |
| 1.45 | 8 ottobre 2026 | Chiarito che la scheda corrente deve seguire i cambiamenti dell’impianto, inclusi alimentazione e differenziali; verificato il riuso della gestione elementi in VerbalizzAI e il limite del campionamento. Aperta la conferma del comportamento predefinito alla finalizzazione. Consegnato separatamente l’approfondimento DM/I&C 05, versione 0.1, basato sul quadro 1.44. Nessuna modifica applicativa eseguita. |
| 1.46 | 8 ottobre 2026 | Confermata R61: fotografie storiche nei verbali emessi, nuova bozza dalla situazione tecnica dell’ultima verifica. Chiuso il criterio aziendale del primo blocco dati tecnici; restano mapping e collaudo. Avviato il riscontro sui prerequisiti dell’affidamento, senza riaprire la configurabilità di ruoli e permessi. Nessuna modifica applicativa eseguita. |
| 1.47 | 8 ottobre 2026 | Acquisita R62: con quattro tecnici abilitati non introdurre matrice o filtro delle qualifiche nel primo AD_dpr. Assegnazione manuale secondo i permessi; proseguire soltanto sul comportamento della dichiarazione d’indipendenza già presente in Garda. Nessuna modifica applicativa eseguita. |
| 1.48 | 8 ottobre 2026 | Acquisita R63: dichiarazione d’indipendenza preselezionata, escludibile; esclusione impedisce lo svolgimento da parte del tecnico, come in Garda. Chiusa la scelta del secondo blocco. Avviato il censimento delle note di credito già previste nel codice fiscale; prassi sulle rettifiche economiche ancora da chiedere. Nessuna modifica applicativa eseguita. |
| 1.49 | 8 ottobre 2026 | Acquisita R64: note di credito anche parziali nel primo AD_dpr. Verificato che Garda genera movimenti di uscita per TD04 e preserva i pagamenti saldati nel ricalcolo; rimane da chiarire la prassi su rimborso o compensazione delle somme già incassate. Nessuna modifica applicativa eseguita. |
| 1.50 | 8 ottobre 2026 | Acquisita R65: emissione diretta di fattura/nota di credito con righe libere, senza collegamento obbligatorio ai verbali. Verificati azioni di creazione, campi delle righe e riferimenti operativi non obbligatori nel codice Garda. Casi rari nello stesso ciclo economico, senza incarichi fittizi. Nessuna modifica applicativa eseguita. |
| 1.51 | 8 ottobre 2026 | Acquisita R66: nella prassi la nota di credito interviene prima dell’incasso. Caso ordinario basato sul residuo da riscuotere; nessuna procedura dedicata di rimborso richiesta ora. Riscontrati anche TD02/TD03 per acconti e flag di generazione XML in Garda; modalità del recupero esiti ancora da scegliere. Nessuna modifica applicativa eseguita. |
| 1.52 | 8 ottobre 2026 | Acquisita R67: importazione esiti Aruba necessaria, modalità da definire successivamente; nessuna scelta manuale o automatica approvata. Consolidata nella sezione 29 la sintesi funzionale del primo AD_dpr e del nucleo, distinguendo decisioni, modello proposto e verifiche tecniche prima del codice/produzione. Nessuna modifica applicativa eseguita. |

## 15. Prima specifica: scadenza, offerta e incarico

**Stato: proposta concettuale da validare nell’uso.** L’utente ha autorizzato a procedere; questo non equivale all’approvazione preventiva delle singole regole seguenti. Nessun codice applicativo modificato.

### 15.1 Unità di lavoro

La voce da seguire è **una prestazione su un bene per una determinata esigenza o ciclo**: ad esempio, la periodica DPR di un impianto riferita alla scadenza corrente. Non basta dire “questo impianto ha un preventivo”. Una straordinaria e una periodica sono esigenze diverse, anche sullo stesso impianto; un preventivo per un ciclo già completato non copre automaticamente il successivo.

La data tecnica deve conservare origine, regola o motivazione, attività di riferimento e eventuale discordanza. Una rettifica cambia il fatto pertinente, non cancella la storia. Un’attività senza scadenza periodica, come alcune consulenze, entra dal bisogno o dalla richiesta del cliente; non le si inventa una scadenza per adattarla al DPR.

### 15.2 Cosa dovrebbe mostrare la lista di lavoro

Una vista unica per la segreteria collega cliente, sede, bene, prestazione, società/ambito, data tecnica, incarico pertinente e prossima azione. La priorità tecnica e il progresso commerciale restano leggibili separatamente. Eventuali contatti e promemoria si aggiungono a quel contesto, senza copiare l’anagrafica.

| Situazione | Cosa resta visibile | Prossima azione proposta |
|---|---|---|
| Esigenza senza offerta o accordo applicabile | Data tecnica e lavoro da prendere in carico | Contattare il cliente o predisporre l’offerta. |
| Offerta preparata, non inviata | Esigenza ancora aperta e bozza pertinente | Completare e inviare la versione corretta. |
| Offerta inviata, risposta assente | Esigenza ancora aperta; invio e richiamo pianificato | Gestire il seguito commerciale. |
| Prestazione accettata, controlli contrattuali da completare | Accettazione acquisita e impedimento esplicito | Completare il riesame secondo il processo concordato. |
| Prestazione autorizzata, incarico da assegnare | Lavoro preso in carico ma non ancora programmato | Assegnare il tecnico idoneo. |
| Incarico programmato | Data tecnica e data pianificata, anche se diverse | Eseguire o riprogrammare, segnalando ritardi. |
| Cliente rifiuta o rimanda | Esigenza tecnica e motivo commerciale | Stabilire il seguito o l’esclusione motivata dalla propria lista operativa. |
| Lavoro svolto, documentazione incompleta | Attività eseguita e azione documentale residua | Completare verbalizzazione e controlli. |

“Non da ricontattare ora” non significa “obbligo tecnico assolto”. Il rifiuto del cliente non modifica da solo la data tecnica. L’uscita dalla lista commerciale, il rinvio del contatto e la dismissione del bene sono fatti distinti, con motivo e autore.

### 15.3 Passaggi e responsabilità proposte

| Passaggio | Responsabilità da attribuire | Dato acquisito una volta | Effetto atteso |
|---|---|---|---|
| Individuare l’esigenza | Segreteria/ruolo competente per l’ambito | Prestazione, bene, ciclo, fonte della data | Voce di lavoro identificata senza duplicazione. |
| Preparare l’offerta | Commerciale o segreteria autorizzata | Condizioni, righe, società emittente, versione | Anagrafica proposta dai dati comuni; prezzi storicizzati nell’offerta. |
| Acquisire l’accettazione | Segreteria autorizzata | Evidenza, data, riferimento e sole righe accettate | Le righe non accettate restano aperte nel proprio contesto. |
| Completare il riesame contrattuale | Ruolo competente da definire nelle procedure | Esito, autore, data, motivazioni ed evidenze disponibili | Autorizzazione operativa oppure impedimento esplicito. |
| Aprire l’incarico | Sistema, al soddisfacimento dei prerequisiti | Legame alla prestazione autorizzata | La stessa azione ripetuta non crea un secondo incarico. |
| Assegnare e programmare | Responsabile competente e tecnico secondo il flusso concordato | Incarico, verificatore, prerequisiti, data prevista | Il tecnico trova dati pertinenti e può aprire la bozza senza ricopiarli. |

Come base del primo caso DPR manteniamo il percorso già espresso dalla 0.7.1: riga accettata, riesame contrattuale conforme e incarico derivato. L’utente ha chiarito che il nuovo contratto a scadenza è la prassi ordinaria; gli affidamenti pluriennali sono un’eccezione, sviluppata nella sezione 16. Le attività I&C possono avere aggregazioni e articolazioni diverse dalle righe DPR; il concetto di prestazione autorizzata deve accoglierle senza imporre lo stesso formato commerciale.

L’accettazione non è un interruttore sull’intero cliente. Un’offerta può includere più sedi o prestazioni ed essere accettata parzialmente: si prendono in carico le parti autorizzate, evitando di dichiarare gestite anche le altre.

### 15.4 Eccezioni da conservare nel processo

- **Offerta rivista:** si conserva la versione inviata e si identifica quella corrente; l’accettazione resta collegata alle condizioni realmente accettate. Le modifiche successive non cambiano silenziosamente l’accordo.
- **Incarico già aperto:** la segreteria deve vederlo prima di creare un nuovo lavoro per la stessa esigenza. Una seconda prestazione legittima deve poter essere distinta, non bloccata solo perché riguarda lo stesso bene.
- **Tecnico sostituito:** va rivalutata la pertinenza delle dichiarazioni e dei prerequisiti personali; quelli del precedente verificatore non diventano automaticamente quelli del nuovo.
- **Annullamento:** si registra che cosa viene annullato — offerta, incarico o documento — e si decide se l’esigenza rimane da gestire. Il bene non viene dismesso automaticamente.
- **Riesame documentale negativo:** si apre la correzione della versione pertinente. Non si genera automaticamente una nuova visita o una nuova prestazione fatturabile; un ulteriore intervento reale è un fatto distinto.
- **Parziale, sospeso o a vuoto:** si registra ciò che è successo; completamento, prossima data e trattamento economico dipendono dalle regole specifiche concordate.

### 15.5 Casi concreti disponibili senza S3

I seguenti riscontri provengono dal dump del 7 ottobre 2026. Gli ID sono quelli dei gestionali sorgente, non quelli canonici del futuro sistema. Lo snapshot attesta i valori presenti, non tutta la sequenza storica delle azioni.

| Caso | Fatto verificato | Criterio di accettazione del futuro processo |
|---|---|---|
| DPR: verifica `1417`, impianto `2502` | Riga `2389` del preventivo `1045` accettata; riesame contratto conforme; dichiarazione del verificatore presente; verifica effettuata, con rilascio del verbale il 28/09/2026, riesame conforme e riferimento alla fattura `516`. | Lo storico mantiene tutti i collegamenti; il lavoro non torna da fatturare. La prossima esigenza usa la data registrata `27/09/2028`, senza riutilizzare il vecchio incarico. |
| DPR: impianto `1960` | Nei dati sono presenti verifiche sia VP sia VS. | Il collegamento commerciale distingue le due prestazioni e il ciclo pertinente; non usa soltanto l’identità dell’impianto. Questo dato da solo non prova una copertura errata in Garda. |
| I&C: attività/riga `3257` | Taratura effettuata il 22/09/2026, prossima data `21/09/2028`, valvola `627`, attrezzatura `7654`; flag di sincronizzazione ancora `T`. | Il nuovo nucleo collega la taratura alla valvola, conserva l’attrezzatura di contesto e aggiorna le viste DM/I&C dalla medesima attività. Il flag storico non va interpretato come prova che la copia DM sia già allineata. |
| I&C: attività/riga `2430` | Taratura della valvola `1823` con prossima data `20/08/2028`; nella precedente revisione è emersa una data DM diversa, `03/06/2028`. | Entrambe le origini sono conservate; la divergenza è visibile finché una regola o una decisione ne determina l’esito. Nessuna prevalenza implicita viene presentata come dato definitivo. |

### 15.6 Gestione degli allegati durante questa fase

Possiamo progettare relazioni documento–incarico–versione, permessi, revisioni, disponibilità e percorso di recupero usando i metadati. Per gli originali S3 non ricevuti lo stato corretto è **“riferimento presente; contenuto non verificato in questa analisi”**. Non diventano “mancanti in S3” o “persi”, e non si inventano hash verificati.

Restano rinviati: verifica di esistenza presso lo storage, lettura dei contenuti, confronto degli hash e deduplicazione dei file effettivi. Queste attività potranno essere svolte nell’ambiente che ospiterà i documenti, evitando di caricarli tutti qui. La decisione odierna riguarda lo spazio e la fase di lavoro, non la cancellazione della storia documentale.

### 15.7 Primo punto da chiarire con l’uso quotidiano

**Punto chiarito dall’utente:** circa 99 casi DPR su 100 comportano un nuovo contratto a scadenza. Solo casi particolari, come affidamenti pluriennali dei Comuni, seguono un accordo esteso nel tempo. Il confronto prosegue sul modo di preparare il rinnovo e sui prezzi da proporre.

## 16. Contratti DPR a scadenza: prassi e proposta di rinnovo

### 16.1 Requisito dichiarato

L’utente ha precisato: «99 su 100 prepariamo contratti a scadenza», con eccezioni per affidamenti pluriennali dei Comuni. La frequenza è un’indicazione della prassi aziendale, non una statistica calcolata dal dump.

**Conseguenza:** il nuovo sistema deve facilitare la preparazione di un nuovo contratto per il ciclo successivo. Non proponiamo di trasformare tutti i rapporti in accordi continuativi. Il contratto precedente resta storico e può aiutare a predisporre quello nuovo, senza costituire automaticamente l’autorizzazione del nuovo incarico.

### 16.2 Comportamento ordinario proposto

1. Dallo scadenzario si selezionano le prestazioni da rinnovare e si verifica se esiste già un’offerta o un incarico per quel ciclo.
2. Il sistema prepara una bozza con anagrafica corrente, beni e prestazioni pertinenti; mostra le precedenti condizioni come riferimento.
3. Si propone il prezzo secondo le basi tariffarie DPR chiarite nella sezione 17, segnalando differenze e deroghe. Non si confondono il prezzo storico, quello del tariffario e quello nuovamente concordato.
4. Si verificano destinatari, sedi, condizioni e righe; l’invio riguarda la versione identificata del nuovo documento.
5. Accettazione e riesame autorizzano le prestazioni pertinenti; la ripetizione dell’azione non genera incarichi duplicati.

Garda dispone già di generazione dei preventivi dallo scadenzario, con raggruppamento per cliente, possibilità di aggiunta a una bozza e riporto di alcune condizioni precedenti. Il miglioramento non può quindi essere descritto come semplice introduzione di una funzione assente: occorre capire quali correzioni o passaggi manuali restano nell’uso quotidiano. Evidenza: `ingecert/cust/lavori_batch_cli.php`, funzione `gi_scadenze_preventivi_crea`.

### 16.3 Eccezione pluriennale proposta — gestione dedicata rinviabile

**Aggiornamento di priorità:** l’utente conferma che Garda permette di preventivare soltanto la prossima scadenza e non gestisce le successive dell’affidamento pluriennale. Gli affidamenti sono rari e non devono complicare il flusso. Si raccomanda di non introdurre una gestione dedicata nel primo AD_dpr, conservando accordo e riferimenti per la gestione manuale del caso effettivo. Le indicazioni seguenti restano ipotesi per una futura estensione, non una struttura approvata o necessaria prima del codice iniziale.

Un affidamento pluriennale deve avere un riferimento esplicito, durata e prestazioni/bene coperti, condizioni e documentazione di autorizzazione. Il sistema verifica se il nuovo intervento ricade davvero in quell’ambito e mostra l’accordo pertinente. Non basta che il cliente abbia genericamente un contratto ancora valido.

Ogni intervento mantiene il proprio incarico, documenti, controlli e situazione economica. La necessità di un ordine specifico, di ulteriori autorizzazioni o di aggiornamenti del prezzo rimane da verificare sulle condizioni dell’affidamento; non si presume che il pluriennale elimini questi passaggi.

### 16.4 Criteri di accettazione e prossimo chiarimento

- Un impianto con contratto del ciclo precedente resta da rinnovare per il ciclo nuovo, salvo accordo pluriennale effettivamente applicabile.
- La preparazione ripetuta per la medesima esigenza segnala la bozza già esistente invece di crearne una seconda senza avviso.
- Un accordo pluriennale su alcuni impianti non copre automaticamente quelli esclusi o le prestazioni aggiuntive.
- Nuove condizioni e prezzi non modificano il contratto storico.

**Punto chiarito per AD_dpr:** terra e scariche atmosferiche seguono ISPESL 2005; i luoghi con pericolo di esplosione seguono una tariffa oraria. L’utente indica tariffe uguali alle precedenti e la possibilità di sconti, ad esempio nelle gare PA. Il dettaglio e il prossimo chiarimento sono nella sezione 17.

## 17. Prezzi AD_dpr: tariffe e sconti

### 17.1 Regole raccolte dall’utente

| Prestazione | Base di prezzo dichiarata | Implicazione per il rinnovo |
|---|---|---|
| Verifica di terra | Tariffario ISPESL 2005 | Normalmente la stessa base tariffaria del ciclo precedente. |
| Verifica delle scariche atmosferiche | Tariffario ISPESL 2005 | Normalmente la stessa base tariffaria del ciclo precedente. |
| Verifica in luoghi con pericolo di esplosione | Tariffa oraria come base del preventivo | L’importo concordato nel preventivo determina il prezzo della prestazione; nessuna variazione a consuntivo. Le ore eventualmente usate nel calcolo restano distinte da misure di tempo effettivo. |

L’utente segnala inoltre la possibilità, in teoria, di applicare sconti, citando le gare verso la PA. Queste informazioni riguardano AD_dpr; non vengono estese ad AD_dm o I&C.

### 17.2 Comportamento proposto

Il rinnovo propone la tariffa pertinente e permette di confrontarla con quella precedente. Se bene, parametri e condizioni restano gli stessi, il prezzo di base atteso è quello precedente. Eventuali differenze devono avere una spiegazione leggibile, ad esempio parametri tecnici cambiati, diverse ore o condizioni commerciali: non basta copiare indiscriminatamente il totale storico.

Il contratto conserva base tariffaria, parametri o quantità utilizzati, prezzo standard, eventuale sconto e prezzo concordato. Le condizioni pregresse restano nello storico anche quando il nuovo contratto cambia.

Per lo sconto proponiamo di conservare importo o percentuale, motivo e riferimento commerciale pertinente; chi può applicarlo e con quali condizioni è ancora da decidere. La possibilità citata non viene trasformata in uno sconto predefinito sui rinnovi.

### 17.3 Regola di fatturazione chiarita

L’utente precisa che nelle zone ATEX si fa riferimento al preventivo e non vengono applicate variazioni a consuntivo. Il prezzo concordato è quindi il riferimento della prestazione: l’eventuale rilevazione delle ore reali non ricalcola automaticamente l’importo fatturabile. Una modifica dell’oggetto commerciale richiederebbe un fatto esplicito distinto, non un aggiustamento silenzioso dopo l’esecuzione.

Il percorso di generazione fattura Garda esaminato usa già la `tariffa_applicata` della riga preventivo come prezzo unitario e totale netto della prestazione, con quantità di fattura pari a 1. La creazione della verifica copia lo stesso importo in `tariffa_effettiva`. L’osservazione dell’utente chiude pertanto una questione che poteva essere prima circoscritta meglio leggendo questo percorso.

## 18. Riscontro dei prezzi nel codice e metodo di analisi

### 18.1 Regole effettivamente riscontrate

| Percorso | Riscontro sul sorgente | Conseguenza per la progettazione |
|---|---|---|
| Calcolo standard Garda | `calcola_tariffa_standard` calcola la tariffa delle terre BT/AT dalla potenza e dagli scaglioni `tariffe_terre`. Per le altre tipologie restituisce `NULL`; il valore deve essere determinato nel preventivo. | Distinguere tariffario aziendale e automatismi effettivamente disponibili. La base tariffaria dichiarata per scariche e ATEX non implica che Garda ne esegua già il calcolo completo. |
| Sconto Garda | La riga conserva tariffa standard, sconto percentuale e tariffa applicata. La funzione di aggiornamento calcola l’importo scontato. | Recuperare la separazione fra prezzo standard e concordato, con regole di autorizzazione da valutare. |
| Preventivo → verifica Garda | La generazione copia `tariffa_standard` e `tariffa_applicata` della riga nei prezzi della verifica. Nell’interfaccia i prezzi della verifica sono di sola lettura. | Il prezzo commerciale proviene dal preventivo; non viene ricostruito dalle ore di esecuzione. |
| Preventivo → fattura elettronica Garda | La generazione usa `tariffa_applicata` della riga come prezzo unitario e totale netto, con quantità 1, conservando i riferimenti a preventivo e verifica. | Preservare l’importo concordato, coerentemente con la prassi ATEX precisata dall’utente. |
| Preventivo della 0.7.1 | La voce `ESPL-ORE` permette di calcolare il prezzo da tariffa unitaria e quantità; lo sconto è controllato per permesso e abilitazione del cliente. La fatturazione del prototipo non è ancora implementata. | Il calcolo a ore è preparazione del preventivo, non prova dell’esistenza di una fatturazione a consuntivo. Recuperare questi dettagli senza attribuirgli funzioni assenti. |

Riferimenti: `ingecert/cust/_custom.php`, funzioni `calcola_tariffa_standard` e `gi_preventivo_riga_tariffa_applicata_update`; `ingecert/cust/lavori_batch_cli.php`, generazione delle verifiche e delle fatture clienti; `ingecert/cust/meta/verifiche.js`, prezzi di sola lettura; nella 0.7.1, `moduli/tariffario/servizio.py` e `moduli/preventivi/servizio.py`.

### 18.2 Metodo per i prossimi processi

Prima si ricostruiscono dati, automatismi, vincoli e passaggi dai sorgenti. Si annota che cosa è provato dal codice e che cosa dipende dalla pratica aziendale. All’utente si sottopongono quindi inefficienze concrete, conflitti fra fonti o modifiche proposte, chiedendo chiarimenti soltanto dove incidono sul progetto.

Il codice può spiegare un comportamento implementato, ma non dimostra da solo quanto spesso venga usato, quali accordi esterni esistano o quali passaggi siano svolti fuori dal software. Queste sono le informazioni da raccogliere nell’intervista operativa.

## 19. Preventivo DPR: anteprima, correzione, firma e file finale

### 19.1 Comportamento richiesto

L’utente riferisce che il ciclo dei verbali di VerbalizzAI funziona bene: LibreOffice produce subito l’anteprima PDF; se corretta, si firma/finalizza e si invia; se presenta problemi, tipicamente di impaginazione, si scarica il Word, lo si corregge e ricarica, ottenendo automaticamente una nuova anteprima. Il ciclo si ripete finché il documento è corretto. È richiesto lo stesso comportamento per il preventivo DPR.

| Passaggio | Risultato desiderato | Riscontro nella 0.7.1 |
|---|---|---|
| Preparazione | Word compilato dai dati correnti e anteprima PDF via LibreOffice | Già presente nel percorso esaminato. |
| Controllo negativo | Scaricamento del Word e correzione esterna | Già presente; il prototipo ammette ritocchi di impaginazione e confronta il contenuto. |
| Ricaricamento | PDF rigenerato dal Word ricaricato e anteprima riaperta, anche più volte | Già presente. |
| Controllo positivo | Firma/finalizzazione della versione verificata | Presente l’approvazione del PDF; la funzione di firma richiesta va definita e completata. |
| Invio | Invio della versione finalizzata, senza rigenerazione silenziosa | Il prototipo usa il PDF approvato corrente e conserva quello inviato. |
| Download finale | File finale scaricato automaticamente con nome determinato | Presenti nomi automatici e download espliciti; nel percorso di approvazione esaminato non compare un download automatico. |

Queste sono evidenze di lettura del sorgente, non un nuovo collaudo con LibreOffice. La finalizzazione e la firma del mittente non equivalgono all’accettazione del cliente o al riesame del contratto: tali fatti conservano il proprio significato e le proprie evidenze.

### 19.2 Coerenza fra anteprima e documento ufficiale

Il documento finalizzato deve corrispondere alla versione controllata, includendo gli effetti della firma secondo il flusso che sarà scelto. Invio, archivio e download fanno riferimento a quella versione. Se cambiano i dati o viene ricaricato un Word diverso, occorre controllare la nuova anteprima; una precedente approvazione non vale implicitamente per il nuovo documento.

Il prototipo confronta il contenuto del Word ricaricato e ammette soltanto correzioni di impaginazione; per cambiare dati e importi richiede una modifica nel gestionale e una nuova generazione. Questa è una regola osservata nel codice, non un’ulteriore limitazione espressamente richiesta dall’utente. La gestione di eventuali modifiche sostanziali al Word va precisata preservando la coerenza fra documento e dati commerciali.

### 19.3 Nome del file e destinazioni

La 0.7.1 genera già un nome composto da codice del preventivo, revisione se presente e ragione sociale, ripulendo i caratteri incompatibili con i nomi file. Una convenzione proposta per il sistema integrato è:

`AD_DPR_Preventivo_P_001_26_rev00_RagioneSociale.pdf`

È un esempio nel registro dei dettagli rinviati, non una convenzione già approvata o da implementare ora. Il nome deve rendere distinguibili ambito, tipo di documento, numero, revisione e cliente, senza rinominare i file storici originali. L’identità archivistica della versione rimane indipendente dal nome di download.

Sono distinti: nome automatico, evento che avvia il download, archivio applicativo del documento e destinazione della copia scaricata. L’utente rinvia la scelta delle destinazioni; non viene presunta ora una cartella sul PC, sul server o sulla rete aziendale. Il PDF finale è il candidato principale al download; il Word corretto resta collegato come sorgente documentale.

### 19.4 Criteri di accettazione e riuso

- Si può ripetere il ciclo Word–PDF senza ricreare il contratto o il suo numero.
- Il PDF viene rigenerato dal Word ricaricato e mostrato prima della finalizzazione.
- I dati cambiati rendono necessario un nuovo controllo del documento pertinente.
- Firma, invio e download utilizzano la versione ufficiale identificata; l’invio non perde il ritocco di impaginazione.
- Numero e revisione rendono distinguibili i file finali; una nuova revisione conserva quella precedente.
- Il download automatico riguarda il file finalizzato, non una precedente anteprima.

Riferimenti verificati nella 0.7.1: `core/pdf.py`; `moduli/preventivi/api.py`, percorsi `anteprima`, `documenti/ritoccati`, `documenti/{id}/approva` e invio email; `moduli/preventivi/servizio.py`, funzioni `nome_file`, `prepara_ritocco`, `salva_ritocco`, `approva_documento` e selezione del PDF approvato; `static/js/preventivi.js`, ciclo `controlla` e `caricaRitocco`.

## 20. Struttura minima: nucleo comune e primo rilascio DPR

### 20.1 Proposta di architettura

**Progettare ora il nucleo integrato per le tre attività; realizzare e attivare per primo un AD_dpr autonomo nel proprio ciclo operativo, con VerbalizzAI come modulo.** È la proposta sottoposta all’utente, non la dichiarazione di un nuovo sistema già costruito o di tutte le scelte già approvate.

Il primo rilascio deve poter gestire il lavoro DPR senza affidarsi a Garda per i passaggi inclusi nel suo perimetro. Il nucleo comune evita che clienti, beni, autorizzazioni, documenti e dati economici debbano essere riprogettati quando arriveranno DM e I&C. Le regole e le maschere complete degli altri due ambiti saranno sviluppate dopo la validazione DPR.

| Livello | Da predisporre nel progetto comune | Da rendere operativo nel primo rilascio |
|---|---|---|
| Identità e anagrafiche | Soggetti, ruoli del soggetto, sedi, beni e origini; ambito distinto da società emittente | Anagrafiche e impianti DPR; storico e riferimenti verificati della migrazione. |
| Commerciale e operatività | Preventivi e versioni, accordi, prestazioni autorizzate, incarichi; eventuale coordinamento di più prestazioni | Preventivi DPR a scadenza, eccezioni pluriennali, accettazione, riesame, assegnazione e programmazione. |
| Tecnica | Regole per tipologia/prestazione, scadenze con fonti, esiti e correzioni | Regole DPR e VerbalizzAI, numerazione, emissione, revisioni e riesame. |
| Documenti e controllo | Versioni, esportazioni, disponibilità dei contenuti, utenti, permessi e registro | Ciclo documentale richiesto e controllo della versione inviata/scaricata. |
| Economico | Emittenti distinti, importi esatti, destinatario fiscale distinto dal cliente del preventivo, legami fra prestazioni, fatture e incassi | Modulo completo di fatturazione e incassi DPR, richiesto dall’utente. |

La compatibilità con ingecert riguarda dati, storia, numerazione e regole operative utili. Le semplificazioni concordate possono cambiare il modo di lavorare preservando queste informazioni. Il progetto tiene separati i campi tecnici specifici DPR dai concetti condivisi.

La migrazione degli originali S3 resta rinviata per questa fase. L’autonomia del nuovo ciclo operativo non equivale ad avere già recuperato tutto lo storico documentale: il piano di disponibilità dei vecchi originali rimane una verifica distinta prima della chiusura della migrazione.

### 20.2 Cinque domande che incidono sulla struttura

| Rif. | Domanda da sottoporre | Scelta suggerita o conseguenza |
|---|---|---|
| Q1 | Perimetro economico del primo DPR | Risposta acquisita: fatturazione e incassi completi. Le funzioni esistenti vanno censite e coperte nel perimetro operativo. |
| Q2 | Distinzione dei soggetti | DPR chiarito: datore di lavoro/committente e intestatari di preventivo e verbale coincidono nel processo indicato; intestatario terzo soltanto in fatturazione. Responsabilità sui dati comuni e altri ambiti da riscontrare. |
| Q3 | Programmazione comune delle attività | Risposta acquisita: per ora distinta; non realizziamo una pianificazione operativa unificata dei tre ambiti nel primo rilascio. |
| Q4 | Compilazione senza connessione | Decisione acquisita: primo rilascio solo online, senza bozze offline. |
| Q5 | Accettazione, riesame e affidamento | Flusso chiarito: risposta scritta del cliente (preventivo controfirmato o email), poi RC obbligatorio, poi incarico al tecnico. Conservazione pratica dell’evidenza e variazioni di ambito da consolidare. |

Le risposte descrivono l’operatività aziendale e il perimetro desiderato; non vengono inventate dal codice. Le regole già riscontrate, come prezzo ATEX preventivato e generazione degli importi dalla riga commerciale, restano la base acquisita.

Dopo le risposte si chiudono la scheda del primo rilascio, il modello concettuale comune, i controlli e un elenco breve di casi di accettazione. Si verifica quindi quali parti della 0.7.1 sono recuperabili e quali vanno adattate; lo sviluppo segue quel perimetro.

### 20.3 Registro dei dettagli rinviati

| Dettaglio | Stato e momento della decisione |
|---|---|
| Termine visibile “preventivo” | Indicazione dell’utente recepita; testi puntuali dell’interfaccia da uniformare più avanti. |
| Formato dei nomi file | Numero, revisione e identificazione del documento vanno conservati; prefissi, ordine, separatori e abbreviazioni si decidono alla fine. |
| Destinazioni delle copie scaricate | Da definire in seguito; distinte dall’archivio applicativo che conserva la versione ufficiale. |
| Aspetto, etichette dei pulsanti e impaginazione dei modelli | Da rifinire dopo i processi, riutilizzando il ciclo di anteprima e ritocco. |
| Dettagli pratici di firma e download | Da specificare nella progettazione del flusso documentale; il requisito di finalizzazione/versione coerente è già raccolto. |

Questo registro non rinvia requisiti strutturali come identità, ruoli, versioni, fonti delle scadenze o conservazione delle evidenze. Serve a evitare che scelte di presentazione rallentino la definizione del primo sistema praticabile.

## 21. Decisioni sul primo AD_dpr e vincoli del modello

### 21.1 Perimetro economico completo

L’utente richiede fatturazione e incassi completi nel primo rilascio AD_dpr. Non è quindi sufficiente una fase tecnica con fatture ancora gestite in ingecert, né la sola produzione di XML. L’inventario del modulo Garda deve coprire fatture e righe, intestazioni e dati fiscali storicizzati, documenti collegati, produzione XML e relativo percorso operativo, modalità e scadenze di pagamento, registrazione degli incassi e situazione residua, includendo i casi di documento e rettifica effettivamente gestiti.

Nei metadati Garda sono già presenti fatture clienti, righe, dati IVA, documenti collegati, generazione XML, pagamenti, tipi pagamento e scadenze; l’elenco dei tipi documento comprende anche acconti e note di credito. Questo censimento iniziale non equivale ancora alla verifica completa delle funzioni o delle casistiche fiscali.

### 21.2 Intestatario della fattura distinto

**Chiarimento successivo dell’utente:** per il DPR il committente è il datore di lavoro e a lui sono intestati preventivo e verbale. La fatturazione a terzi interviene soltanto in fase di fatturazione. È il comportamento Garda da mantenere, senza introdurre un ruolo di committente distinto prima di quel passaggio (sezione 26).

La proposta iniziale dell’intestatario fiscale proviene dall’intestatario del preventivo, ma può essere modificata per i casi indicati dall’utente. La modifica della fattura non deve riscrivere il preventivo, il bene o i documenti già emessi.

Nel codice Garda `meta/fatture_clienti.js` la scheda “Intestatario fattura” contiene propri campi `cli_rag_soc`, indirizzo, CF, P.IVA e codice destinatario/PEC; la vista `clienti_dec` propone gli stessi dati dall’anagrafica. Il generatore mantiene il collegamento al cliente commerciale del preventivo: tale riferimento non va confuso con i dati di intestazione della fattura.

Il nucleo futuro deve rappresentare questi ruoli e conservare i dati fiscali validi alla singola emissione. Per lo storico migrato si preservano i campi effettivamente presenti, senza assumere che il riferimento anagrafico e l’intestatario fiscale coincidano sempre. L’eventuale identità di proprietario e gestore dell’impianto resta un tema distinto da questo chiarimento.

### 21.3 Programmazione distinta

La programmazione resta distinta per attività nel primo rilascio. Il backend comune può condividere utenti, soggetti e componenti, ma non impone un’unica agenda o un’unica uscita per DPR/DM/I&C. Eventuali raggruppamenti futuri non sono parte del primo requisito operativo.

### 21.4 Accettazione, riesame e affidamento

Flusso richiesto: preventivo creato, inviato, accettato — oppure rifiutato/annullato —; a seguito dell’accettazione riesame obbligatorio; solo dopo un esito che autorizzi il lavoro si affida l’incarico al tecnico. L’utente collega questa regola alle proprie esigenze ISO 17020:2026; qui viene registrata come requisito esplicito del sistema.

Il riscontro Garda è concreto: l’azione “Genera verifiche” in `meta/preventivi_righe.js` richiede riga accettata, impianto non dismesso, tariffa disponibile e riesame del preventivo effettuato con esito conforme. La generazione della verifica assegna il tecnico. Nella 0.7.1 il riesame conforme genera le verifiche da assegnare; l’assegnazione è un passaggio successivo.

**Vincolo di progetto:** l’accettazione da sola non autorizza l’affidamento. Il controllo deve valere nel servizio applicativo, anche per azioni massive o richieste dirette, non soltanto nella visibilità di un pulsante. Si registrano autore, data, esito e riferimento al preventivo/condizioni riesaminati. Un riesame pendente o non conforme mantiene un impedimento esplicito all’affidamento.

L’approvazione dell’anteprima del PDF, la finalizzazione del preventivo, l’accettazione del cliente e il riesame contrattuale sono quattro fatti distinti. Il successivo chiarimento dell’utente richiede evidenza scritta di accettazione: preventivo controfirmato o almeno email di conferma (R38). Conservazione pratica dell’evidenza ed effetti delle revisioni sostanziali rimangono da consolidare.

### 21.5 Modalità online scelta

Dopo il confronto infrastrutturale, l’utente sceglie la soluzione più semplice: nessuna bozza offline al momento. Il browser accede al sistema centrale e i salvataggi applicativi arrivano al server. Anche conversione PDF con LibreOffice, gestione delle versioni, finalizzazione e invio rimangono nel sistema centrale.

Non sono inclusi nel primo rilascio un database operativo sul dispositivo, una coda di modifiche offline o la sincronizzazione dei client. L’eventuale futura funzione offline rimane un progetto separato: la scelta attuale non impone di realizzare ora una PWA o un’applicazione locale.

## 22. Scheda del primo AD_dpr e nucleo concettuale proposto

### 22.1 Perimetro raccolto

Il primo sistema comprende il ciclo DPR: anagrafiche e impianti, scadenze, preventivi e relativa preparazione documentale, accettazione, riesame contrattuale obbligatorio prima dell’affidamento, assegnazione e programmazione DPR, verbalizzazione con VerbalizzAI, revisioni e riesame, documenti/invii, fatturazione e incassi completi.

L’uso è online. La programmazione resta distinta dagli altri ambiti. Gli originali S3 non sono richiesti in questa fase. L’architettura proposta è un nucleo integrato con attivazione iniziale DPR: la scelta del perimetro operativo non equivale a un’approvazione puntuale di tutto il futuro schema tecnico.

### 22.2 Struttura dei concetti da verificare prima dello schema fisico

| Concetto | Responsabilità | Relazione essenziale |
|---|---|---|
| Soggetto e sede | Identità e contatti correnti, riferimenti sorgente verificati | L’intestatario del preventivo e quello fiscale della fattura possono essere diversi. |
| Bene e prestazione/ciclo | Identificare che cosa va controllato e quale esigenza è aperta | Uno stesso impianto può avere prestazioni o cicli diversi; la sola presenza di un’offerta sul bene non basta. |
| Preventivo e righe | Condizioni proposte, prezzi, versione ed esito commerciale | Le righe individuano le prestazioni; il documento finalizzato e l’accettazione restano fatti distinti. |
| Riesame del contratto | Autore, data, esito e condizioni riesaminate | L’accettazione precede il riesame; l’esito autorizzante precede l’affidamento al tecnico. |
| Incarico/verifica | Da assegnare, assegnata, programmata (facoltativa), registrata, eseguita, sospesa, annullata | Flusso chiarito dall’utente: registrata in occasione dell’esecuzione; eseguita solo con verbale finalizzato e caricato nel gestionale. Sospesa è l’aggiunta richiesta per impossibilità di eseguire la verifica; transizioni e ripresa da consolidare. |
| Verbale e stato tecnico | Snapshot della verifica, versioni, esito e correzioni | Lo storico emesso non viene riscritto da un aggiornamento dell’anagrafica; il campione non sostituisce l’inventario. |
| Riesame del verbale | Controllo della versione pertinente e eventuale richiesta di correzione | Revisione documentale ed eventuale nuovo intervento sono distinti. |
| Fattura, pagamenti e incassi | Intestazione fiscale storicizzata, importi, collegamenti e situazione economica | L’intestatario fiscale è modificabile nella fattura; la modifica non riscrive il preventivo. |
| Documenti, esportazioni ed eventi | Contenuti, versioni, disponibilità e traccia delle operazioni | Invio e download identificano il documento ufficiale pertinente. |

La tabella è il modello concettuale proposto, non l’elenco definitivo delle tabelle. Gli elementi comuni avranno riferimenti stabili; i dettagli tecnici di terra, scariche e ATEX restano nel modulo DPR, senza trasformarli in campi obbligatori per DM o I&C.

### 22.3 Risultato della fase e approfondimenti successivi

Il confronto mirato con i servizi Garda e il prototipo 0.7.1 ha prodotto la mappa di stati, azioni consentite, ruoli, prerequisiti ed effetti nella sezione 23. I casi prioritari sono: riga accettata senza riesame; riesame non conforme; tentativo di assegnazione anticipata; creazione ripetuta dello stesso incarico; intestatario fattura diverso; accettazione parziale; revisione del preventivo; riesame del verbale negativo; storici già fatturati e incassi parziali.

Rimangono da approfondire le evidenze concrete dell’accettazione, il ciclo completo fatture/pagamenti e le regole specifiche non ancora censite. Non si aprono nuove domande su naming, cartelle o impaginazione: sono nel registro dei dettagli rinviati. Il passo successivo resta concettuale e precede modifiche applicative.

## 23. Mappa operativa DPR: stati, controlli ed effetti

**Stato:** analisi mirata dei sorgenti e proposta concettuale. Non sono stati modificati i servizi applicativi né eseguiti nuovi test del prototipo. I casi descritti sotto sono criteri per il futuro collaudo, non prove già superate. I requisiti espliciti dell’utente restano distinti dalle scelte qui suggerite.

### 23.1 Stati distinti per evitare ambiguità

| Oggetto o fatto | Stati proposti | Significato |
|---|---|---|
| Preventivo commerciale | Creato, inviato, accettato parzialmente/totalmente, rifiutato, annullato, sostituito | Il riepilogo deriva anche dalle righe. L’accettazione riguarda condizioni e prestazioni identificabili. |
| Riesame del contratto (RC) | Da fare, conforme, non conforme; eventuale nuovo riesame necessario | Autorizza le prestazioni accettate coperte da quella valutazione. Non è l’accettazione del cliente. |
| Incarico/verifica | Da assegnare, assegnata, programmata, registrata, eseguita, annullata | Avanzamento del lavoro. La programmazione può restare facoltativa, come nella 0.7.1, senza saltare i prerequisiti dell’esecuzione. |
| Verbale e riesame del verbale (RV) | Documento in bozza/emesso/annullato; RV da fare/conforme/da correggere | Il riesame riguarda una precisa versione emessa. Una correzione documentale non cancella il fatto che l’intervento è avvenuto. |
| Consegna | Nessun invio, tentativo fallito, invio riuscito, eventuale nuova consegna | Eventi con destinatari, versione/hash e data; un invio riuscito non prova la lettura del cliente. |
| Fatturazione e incassi | Situazione economica distinta dal lavoro tecnico | Prestazione da fatturare/fatturata o rettificata; credito aperto/parzialmente incassato/saldato derivato dai movimenti pertinenti. Il ciclo fiscale dettagliato è ancora da censire. |

**Distinzione essenziale:** un esito tecnico negativo dell’impianto e un riesame non conforme del verbale sono cose diverse. Un documento corretto che descrive un impianto non conforme può avere RV conforme; non si blocca la fatturazione soltanto perché l’esito tecnico è negativo.

La 0.7.1 usa anche lo stato unico “riesaminata” e riporta a “registrata” dopo RV negativo. L’utente conferma il ritorno a registrata: il verificatore deve ripetere l’attività e/o correggere il verbale, ricaricarlo e riportare la verifica a eseguita prima del nuovo RV. **Eseguita richiede il verbale finalizzato e caricato**, non soltanto l’uscita fisica. Il fatto che l’intervento sia avvenuto, le note del RT, i documenti e tutti i riesami rimangono conservati nello storico. Non si mantiene eseguita una verifica con RV negativo.

### 23.2 Azioni e condizioni del primo ciclo operativo

I ruoli nella tabella sono una base ricavata dalla 0.7.1: segreteria per le azioni commerciali, RT per assegnazione/RV, tecnico assegnato per l’esecuzione; RC disponibile a RT e segreteria con il relativo permesso. La futura matrice delle deleghe aziendali resta configurabile per ambito. Ogni azione registra autore, data e oggetto/versione pertinenti.

| Azione | Operatore di riferimento | Prerequisiti proposti | Effetto |
|---|---|---|---|
| Creare/modificare preventivo | Segreteria autorizzata | Prestazioni identificate; condizioni e prezzi pertinenti; nessuna modifica silenziosa a condizioni già inviate/accettate | Bozza e righe, con versione. Prezzo ATEX concordato, senza conguaglio a consuntivo. |
| Preparare/finalizzare documento | Operatore documentale | Word e PDF coerenti con la versione; anteprima, eventuale ritocco e nuova conversione | Conservazione delle generazioni; finalizzazione e firma secondo il flusso richiesto, dettagli da completare. |
| Inviare o registrare consegna esterna | Segreteria autorizzata | Documento corrente finalizzato; destinatari e canale identificati | Evento di consegna sulla versione pertinente. Un errore di invio non equivale a preventivo inviato. |
| Registrare accettazione/rifiuto | Segreteria autorizzata | Preventivo effettivamente inviato/consegnato; righe e versione riconoscibili; riferimento/evidenza della risposta | Esito per riga e riepilogo commerciale; nessun affidamento automatico prima del RC. |
| Effettuare RC | Operatore autorizzato al RC | Accettazione delle prestazioni interessate; condizioni riesaminate; punti di controllo e motivazione se negativo | Esito conservato, con ambito coperto. Solo il conforme autorizza le prestazioni pertinenti. |
| Creare incarichi | Sistema a seguito di RC conforme | Riga accettata, RC conforme valido per l’offerta/versione invariata, comprensivo delle righe già offerte anche se accettate successivamente; bene attivo; nessun incarico attivo duplicato per lo stesso ciclo | Incarichi da assegnare. Ripetere l’azione non duplica il lavoro. |
| Assegnare/riassegnare | RT autorizzato | Autorizzazione commerciale ancora valida; tecnico attivo e idoneo alla prestazione; incarico non concluso | Assegnazione tracciata. Una dichiarazione personale del precedente tecnico non vale per il nuovo. |
| Dichiarazione d’indipendenza | Tecnico incaricato | Incarico e tecnico identificati | R63: casella preselezionata come in Garda, escludibile dal tecnico. Se esclusa, il tecnico non può procedere con la verifica. Tracciare le modifiche; il solo default non va registrato come una distinta conferma personale. |
| Programmare | Tecnico assegnato/RT autorizzato | Incarico autorizzato e prerequisiti personali soddisfatti | Data e assegnazione DPR; nessun obbligo di agenda condivisa con DM/I&C. |
| Registrare verifica e numero | Tecnico assegnato/RT autorizzato | Assegnazione valida, indipendenza, data; anche senza precedente programmazione | Numero completo riservato in modo atomico; numero annullato non riutilizzato. |
| Emettere verbale | Tecnico assegnato/operatore autorizzato | Incarico registrato, numero/modulo/dati coerenti; anteprima e finalizzazione secondo VerbalizzAI | Versione ufficiale e dati tecnici collegati; stato eseguita solo dopo finalizzazione e caricamento nel gestionale, come chiarito dall’utente; RV da fare. Stato della scadenza proposto nella sezione 23.5. |
| Effettuare RV | RT autorizzato | Versione ufficiale identificata; valutazione e motivazione se negativa | Conforme oppure negativo con ritorno a registrata. Nota RT visibile al verificatore; esito, autore, data/ora, nota e versione esaminata conservati nello storico. |
| Correggere/riemettere | Operatore autorizzato | Motivo, versione precedente e distinzione fra correzione documentale e nuovo intervento | Ripetizione dell’attività se richiesta e/o correzione documentale; verbale finalizzato e ricaricato, verifica a eseguita e nuovo RV da fare. Documenti e riesami precedenti conservati; il vecchio RV non approva il nuovo contenuto. |
| Consegnare verbale | Operatore autorizzato | PDF definitivo identificato e controllato; proposta ordinaria dopo RV/approvazione RT, oppure rilascio immediato autorizzato alle condizioni della sezione 24 | Invio/consegna tracciati della versione corretta; possibilità di reinvio senza nuova emissione; eccezione con RV successivo obbligatorio. |
| Generare fattura dalla prestazione | Operatore amministrativo | Prestazione pertinente e RV conforme, secondo la regola Garda riscontrata; controllo contro doppia fatturazione ordinaria | Fattura e collegamenti alle prestazioni; intestatario fiscale proposto dal preventivo ma modificabile, con dati storicizzati. |
| Registrare incasso/rettifica | Operatore amministrativo | Documento/credito identificato; importo, data e riferimento; permesso pertinente | Movimenti ed eventuali imputazioni, saldo derivato e storia conservata. Non basta sostituire il totale o spuntare “saldato”. |
| Annullare preventivo/incarico | Operatore autorizzato | Motivo e verifica degli effetti sui lavori/documenti già presenti | Blocco coerente dei passaggi successivi e storia preservata; lavori già eseguiti o fatturati richiedono una gestione esplicita, non una cancellazione a cascata. |

La riga “generare fattura dalla prestazione” descrive il ciclo ordinario delle verifiche. Acconti, note di credito e altri documenti economici già previsti da Garda richiedono le proprie regole: non si impone loro indiscriminatamente il completamento di una verifica.

### 23.3 Controlli da rafforzare rispetto ai sorgenti

| Riscontro concreto | Comportamento proposto |
|---|---|
| 0.7.1, `preventivi.servizio.stato_righe`: blocca annullati/sostituiti, ma non richiede lo stato inviato per accettare | Applicare il flusso richiesto: consegna prima dell’accettazione. È già disponibile `segna_inviato` per registrare una consegna esterna. |
| 0.7.1: RC conforme crea incarichi; un successivo RC negativo o l’annullamento del preventivo non aggiornano gli incarichi esistenti. `verifiche.servizio.assegna` non rilegge RC/stato del preventivo | Ricontrollare l’autorizzazione al momento dell’assegnazione e dei passaggi successivi. Registrare un blocco esplicito sugli incarichi ancora aperti, senza cancellarne la storia. |
| 0.7.1: accettare un’altra riga dopo il RC non crea il relativo incarico; `crea_da_preventivo` viene richiamato dal RC conforme | Requisito acquisito: il RC copre l’intera offerta invariata. Per la riga già offerta e accettata successivamente, consentire la generazione del relativo incarico usando il RC conforme valido, senza obbligare a ripeterlo; rispettare l’accettazione scritta e impedire duplicati. Non si introduce un riesame per riga. |
| 0.7.1: una verifica già presente sulla riga, anche annullata, impedisce la nuova creazione; il modello ha una riga univoca | Distinguere idempotenza da riapertura. Il recupero di un incarico annullato richiede un’azione motivata o una nuova autorizzazione/ciclo, mantenendo il vecchio riferimento. |
| Garda controlla `dichiaro_che` prima di programmare/registrare/effettuare; nei metadati il campo ha però default vero. Nel prototipo manca l’evidenza strutturata equivalente | Dichiarazione personale esplicita per incarico, conservata con autore/data; nessuna conferma automatica. |
| 0.7.1 sceglie i verificatori fra utenti attivi con permesso di eseguire verifiche | Distinguere permesso applicativo e idoneità alla prestazione. Qualifiche, ambiti e loro validità vanno modellati secondo le procedure effettive. |
| 0.7.1 blocca modulo/numero errati nel Word, ma data diversa, tipo VP/VS diverso ed esito non letto producono avvisi e la verifica diventa eseguita | Non finalizzare automaticamente dati essenziali discordanti o mancanti. Richiedere correzione o una risoluzione esplicita e tracciata da chi è autorizzato. |
| 0.7.1: RV negativo riporta a registrata; i dati dell’impianto erano già aggiornati al caricamento e `riesame` non li ricalcola | Conservare la decisione DPR di aggiornare la scadenza prima del RV, con fonte e versione identificabili; RV negativo riporta a registrata e la revisione emessa pertinente aggiorna il dato. Non introdurre un’attesa automatica del RV per ricalcolare la scadenza. Le caratteristiche tecniche correnti seguono la regola da chiarire in D03. |
| 0.7.1: il ponte permette l’invio VerbalizzAI con `verifiche.esegui`, e la funzione email non consulta il RV del gestionale | Applicare nel servizio centrale la politica di consegna: RV/approvazione per il percorso ordinario, autorizzazione specifica e condizioni per il rilascio immediato proposto nella sezione 24. |
| Garda contiene pagamenti con scadenza/importo e indicatore `saldato`; il codice fiscale genera rate e ricalcola le quote residue tenendo conto dei movimenti saldati; la fatturazione della 0.7.1 è ancora segnalata come funzione non attiva | Conservare e collaudare le funzioni esistenti di rate e residui, senza reinventarle. La presenza nel codice non dimostra una riconciliazione bancaria automatica; per importo effettivo, data e associazioni degli incassi resta necessaria una rappresentazione verificabile. |

Sono riscontri statici del flusso dei servizi esaminati. Le condizioni dei pulsanti Garda attestano le regole dichiarate nell’interfaccia; da sole non dimostrano che ogni percorso di scrittura le faccia rispettare.

### 23.4 Criteri di accettazione da trasformare in collaudo

| Caso | Risultato atteso della proposta |
|---|---|
| Preventivo creato ma non consegnato; tentativo di accettazione | Rifiuto dell’azione; resta possibile registrare prima una consegna esterna reale. |
| Riga accettata, RC pendente/negativo; assegnazione anche massiva | Nessun affidamento. Il controllo vale sul server e non soltanto sui pulsanti. |
| RC conforme, poi nuovo RC negativo oppure preventivo annullato | Gli incarichi aperti non proseguono usando la vecchia autorizzazione; blocco e motivazione visibili. |
| Due righe: prima accettata e riesaminata, seconda accettata più tardi | Prima coperta dal proprio RC; seconda non assegnabile finché non coperta. Ripetere la creazione non duplica gli incarichi. |
| Riassegnazione a un altro tecnico | La vecchia dichiarazione personale non viene attribuita al nuovo tecnico; registrazioni e motivi precedenti restano. |
| Due registrazioni concorrenti | Numeri distinti nello stesso ambito/anno; preservata la convenzione e la serie effettivamente adottata. |
| Verbale con numero/modulo errato oppure data/tipo/esito discordanti | Nessuna emissione automatica incoerente; errore o risoluzione autorizzata registrata secondo il campo interessato. |
| RV negativo, correzione e nuova emissione | Verifica a registrata; nota RT visibile. Dopo intervento/correzione, finalizzazione e ricaricamento: eseguita con nuovo RV da fare. Tutti i documenti e riesami precedenti consultabili, ciascuno riferito alla versione esaminata. |
| Impianto con esito tecnico negativo, verbale corretto e RV conforme | I due esiti restano distinti; il solo esito tecnico negativo non impedisce la fatturazione. |
| Intestatario fiscale diverso dal cliente del preventivo | Fattura correttamente intestata; preventivo, anagrafica tecnica e documenti precedenti non riscritti. |
| Storico già fatturato; nuova importazione degli stessi riferimenti | Nessuna nuova voce ordinaria da fatturare e nessuna duplicazione di fatture/incassi. |
| Fattura da 1.000 €, incassi da 300 € e 200 € | Residuo 500 €, movimenti distinti e tracciati; l’ultimo incasso non sostituisce il precedente. |
| Invio fallito, poi reinvio riuscito | Due eventi sul documento pertinente; il primo non segna consegna riuscita. |

### 23.5 Decisioni da affrontare in ordine

**Riesame e consegna: chiarimento successivo nella sezione 24.** L’utente conferma il percorso attuale RV–consegna–fattura e segnala l’eccezione del rilascio immediato. Il riscontro RG-01-04 porta alla proposta di due percorsi, con quello differito ordinario e quello immediato subordinato alle condizioni e all’autorizzazione specifica. L’utente conferma successivamente per ora l’invio dopo riesame nel primo DPR; l’opzione immediata viene rinviata (sezione 28.15). Il RC prima dell’affidamento rimane obbligatorio in entrambi.

**Scadenza DPR: momento di aggiornamento chiarito nella sezione 28.** L’utente conferma l’aggiornamento alla verifica effettuata/emissione, senza attendere RV conforme. Una revisione emessa con modifiche dei dati pertinenti aggiorna la scadenza; una correzione grafica non la cambia. La proposta precedente di attendere il RV è superata. Restano da consolidare gli effetti dei casi straordinari, degli annullamenti e dei conflitti tra fonti.

**Successivamente, ciclo economico completo.** Prima dello schema definitivo va censito il percorso effettivo di fatture ordinarie, acconti/rettifiche, XML e invio/esiti, rate, incassi parziali, residui e storni. La prima versione DPR deve coprirlo: questa mappa non chiude ancora la specifica fiscale e contabile. Naming, cartelle, etichette e impaginazione restano nel registro dei dettagli rinviati.

### 23.6 Riferimenti dei riscontri di questa fase

- Garda ingecert: `cust/meta/preventivi_righe.js` (condizioni per generare verifiche/fatture); `cust/meta/verifiche.js` e `cust/_custom.php` (dichiarazione, transizioni e RV negativo); `cust/meta/fatture_clienti.js` e `cust/meta/pagamenti.js` (intestazione fiscale, tipi documento, scadenze e indicatore saldato).
- Gestionale_AD 0.7.1: `gestionale/moduli/preventivi/servizio.py` (`stato_righe`, `segna_inviato`, `annulla`, `riesame`); `gestionale/moduli/verifiche/servizio.py` (`crea_da_preventivo`, `verificatori`, `assegna`, `registra`, `carica_verbale`, `riesame`); relative API per i permessi.
- Ponte documentale: `gestionale/moduli/verbali/archivio.py` (`PERMESSI`), `gestionale/moduli/verbali/api.py`, `gestionale/terzi/verbalizzai/app.py` (`mail_prepare`, `mail_send`); `gestionale/core/permessi.py` (ruoli proposti e funzioni economiche non attive).

## 24. Rilascio del verbale: percorso ordinario ed eccezione immediata

### 24.1 Prassi dichiarata e riscontro del regolamento

L’utente precisa il flusso attuale: verbalizzazione, riesame, invio del verbale, quindi fatturazione. La consegna presso il cliente potrebbe essere più frequente in AD_dpr; è rara in AD_dm e praticamente impossibile nella prassi I&C S.r.l. descritta. Queste sono indicazioni operative dell’utente, non misurazioni sui dump.

Sono stati consultati i testi ufficiali Accredia:
- [RG-01-04 rev.03, §2.7, pagina 17](https://www.accredia.it/wp-content/uploads/2025/06/RG-01-04_rev.03.pdf), in vigore dal 16 giugno 2025;
- [RG-01-04 rev.04, §2.5, pagina 17](https://accredia.it/wp-content/uploads/2026/05/RG-01-04rev.04.pdf), in vigore dal 1° novembre 2026.

Entrambe le revisioni prevedono l’indicazione dell’ispettore e del RT sui rapporti, con la possibilità della sola firma dell’ispettore quando il percorso ordinario non è concretamente praticabile, senza attività prolungata con più ispettori, e con ispettore qualificato ed esplicitamente autorizzato. Il rilascio presso il cliente subito dopo l’ispezione è un esempio riportato. La rev.04 esplicita inoltre il successivo riesame e l’approvazione del RT.

L’eccezione non coincide quindi con una generica email inviata rapidamente dopo la generazione del PDF. Occorre una modalità di rilascio pertinente, autorizzazione del personale ed evidenza delle condizioni applicabili. Le regole dell’OdI AD non vengono automaticamente estese a tutte le prestazioni di I&C S.r.l.

### 24.2 Proposta di progetto

**Predisporre entrambi i percorsi nel modello comune; usare il percorso dopo riesame come modalità ordinaria.** Per ora il primo AD_dpr mantiene l’invio dopo riesame, secondo la risposta successiva dell’utente (sezione 28.15). Il rilascio immediato rimane un’estensione futura da attivare e collaudare successivamente.

| Aspetto | Percorso ordinario | Rilascio immediato controllato |
|---|---|---|
| Sequenza | Preparazione/firma ispettore, RV e approvazione RT, consegna, fatturazione | Preparazione/firma ispettore e rilascio, RV e approvazione RT successivi, fatturazione |
| Autorizzazione alla consegna | Versione approvata dal RT | Ispettore qualificato e specificamente autorizzato; condizioni dell’eccezione soddisfatte |
| Evidenze | Versione approvata, approvatore e momento di approvazione, consegna | Versione effettivamente rilasciata, autore, momento/canale/destinatario, modalità e autorizzazione, RV ancora dovuto |
| RV negativo | Documento trattenuto e da correggere prima della consegna | Documento già consegnato; correzione gestita con comunicazione e nuova versione se necessarie |
| Economico | RV conforme abilita il normale ciclo fattura | Rilascio immediato da solo non abilita la fattura; si mantiene il controllo dopo RV |
| Utilizzo suggerito | Default DPR/DM; per I&C il controllo interno pertinente alle sue prestazioni | Opzione DPR, eventuale DM nei casi ammessi; nessuna attivazione I&C presunta |

Il progetto mantiene **un percorso ordinario e una sola opzione di rilascio immediato DPR**, utilizzabile dai tecnici specificamente autorizzati nei casi ammessi. La consegna registra la modalità adottata e i normali dati dell’evento. Il controllo usa ambito, autorizzazione e condizioni pertinenti; la prima versione non richiede un motore generale di workflow o una matrice di eccezioni configurabile. L’eventuale estensione DM si valuta quando quel modulo viene attivato.

RV e approvazione del RT devono riferirsi alla versione pertinente. Per il percorso ordinario va assicurata anche l’indicazione del RT sul rapporto secondo la procedura/modello adottati: il solo stato “riesaminato” in una griglia non sostituisce l’analisi di quel requisito documentale. La verifica dei modelli e dell’evidenza di approvazione è ancora da svolgere.

### 24.3 Compatibilità con la scelta online e uso del tablet

Il tablet può usare il browser collegato al sistema centrale: salvataggio, numerazione, conversione LibreOffice, anteprima, finalizzazione e invio rimangono sul server. Si conserva la scelta già acquisita di nessuna bozza offline.

La consegna immediata può avvenire per email mentre il tecnico è presso il cliente; una stampa sul posto non è un requisito acquisito. La ricevuta della trasmissione e l’eventuale evidenza di consegna al referente restano fatti distinguibili.

Prima dell’attivazione occorre provare in campo la compilazione, l’anteprima/firma e la consegna sul dispositivo effettivo, oltre alla disponibilità di connessione. Se manca la connessione o servono ritocchi Word non pratici sul tablet, si completa il ciclo centrale e si usa la consegna differita dopo RV. Non viene promessa ora la piena usabilità del pacchetto VerbalizzAI attuale su tablet.

### 24.4 Gestione della consegna prima del riesame

Proposta: ogni rilascio immediato alimenta una lista di documenti già consegnati e ancora da riesaminare, con responsabile, tempo trascorso e termine aziendale da stabilire. Il regolamento consultato non viene usato per inventare un numero di giorni. L’eccezione non deve far sparire il controllo dalla lista di lavoro.

Se il RV è negativo, si conserva il PDF consegnato e si distingue:
- correzione del documento con eventuale nuova versione e comunicazione al cliente;
- errore o insufficienza della verifica che richiede una decisione tecnica ed eventualmente un nuovo intervento.

Nessuna sostituzione silenziosa del documento già rilasciato. Anche un problema soltanto grafico richiede di identificare quale versione è stata effettivamente consegnata. Il processo per comunicazione, rettifica/sostituzione e gestione delle scadenze dovrà essere coerente con le procedure aziendali.

### 24.5 Fatturazione e risultato della fase

L’invio differito può rendere disponibili insieme verbale e attività di fatturazione dopo il RV. Si propone una funzione coordinata, senza rendere obbligatoria la simultaneità: consegna tecnica e fattura rimangono eventi distinti, utili anche quando una fattura raggruppa più prestazioni o segue condizioni commerciali particolari.

Il vincolo di fatturazione dopo RV per il ciclo ordinario deriva dal comportamento Garda riscontrato e dalla prassi aziendale dichiarata; non è attribuito come prescrizione fiscale a RG-01-04. Acconti e rettifiche mantengono il proprio percorso.

**Risultato:** la vecchia proposta di blocco universale prima della consegna è sostituita da un percorso ordinario e un’eccezione controllata nel modello. Sono ancora proposte, non implementazioni né attivazioni approvate. Il primo rilascio può usare soltanto il percorso ordinario senza perdere la futura possibilità del rilascio in campo. Il successivo vincolo di semplicità dell’utente è recepito nella sezione 24.6.

### 24.6 Vincolo esplicito di semplicità

L’utente chiede di non complicare enormemente il flusso e la logica del gestionale. Questo diventa un criterio di progettazione del primo rilascio, insieme ai requisiti funzionali già acquisiti.

**Esperienza operativa proposta:**
1. Il tecnico compila, controlla l’anteprima, firma ed emette.
2. Il RT trova il verbale da riesaminare e approva oppure chiede la correzione.
3. La segreteria consegna e avvia la fatturazione dalla stessa pratica.
4. Nel DPR, se abilitata e applicabile, l’opzione “Rilascia subito” anticipa la consegna; il verbale rimane nella normale lista del RT da riesaminare. La fatturazione ordinaria si abilita dopo il RV.

L’opzione immediata riusa gli stessi incarico, verbale, riesame e consegna; non crea un secondo processo da amministrare. Il criterio di autorizzazione specifica resta necessario, ma non impone una nuova approvazione manuale del RT per ogni rilascio se il tecnico è già autorizzato e il caso soddisfa le condizioni previste.

**Criteri per l’interfaccia e la logica:**
- Un contesto di pratica, con prossima azione disponibile e motivazione breve se è bloccata.
- Stati riepilogativi calcolati dai fatti registrati; l’operatore compie azioni, non aggiorna a mano più stati separati.
- Dati già presenti riutilizzati, numerazione/scadenze/saldi derivati; richieste ulteriori solo quando manca un’informazione necessaria.
- Liste operative del tecnico, RT e segreteria ottenute dagli stessi dati, senza registri paralleli da compilare.
- Distinzione fra firma/anteprima, RC, RV, consegna e fattura conservata internamente, con visibilità proporzionata al ruolo.
- Gli effetti ordinari sono automatici; ragioni e interventi manuali concentrati su rifiuti, annullamenti, correzioni e altre eccezioni reali.

La mappa dettagliata della sezione 23 descrive le regole da rispettare e i casi di verifica. Non corrisponde a un obbligo di presentare un pulsante, una schermata o un adempimento manuale per ogni riga. La semplicità del ciclo normale va provata insieme alla correttezza dei controlli.

## 25. Decisioni prima del codice iniziale

### 25.1 Perimetro già acquisito

Si lavora su un nucleo comune alle tre attività, con avvio operativo DPR e successiva attivazione DM/I&C dopo validazione. Il primo DPR comprende VerbalizzAI, fatturazione e incassi completi. Uso online, programmazione distinta per attività, soggetti emittenti AD e I&C S.r.l. distinti.

Sono acquisiti: preventivo normalmente nuovo per ogni ciclo; base ISPESL 2005 per terra/scariche e preventivazione oraria ATEX, senza conguaglio a consuntivo; destinatario fiscale della fattura modificabile rispetto al cliente del preventivo; accettazione prima del RC obbligatorio e affidamento soltanto dopo RC conforme; preparazione documentale con anteprima PDF e ritocco Word; percorso ordinario RV–consegna–fattura; semplicità e assenza di registri operativi duplicati. Il modello contempla l’eccezione di rilascio immediato descritta nella sezione 24, la cui attivazione iniziale resta da scegliere.

Questi punti non vengono sottoposti di nuovo come domande aperte.

### 25.2 Elenco unico dei punti strutturali da chiudere

Le proposte sono basi di discussione, non nuove decisioni dell’utente. Ogni punto deve produrre una regola breve, un caso normale e le eccezioni che incidono sul modello. Il censimento delle funzioni già esistenti rimane compito dell’analisi dei sorgenti.

| Rif. | Decisione effettiva | Proposta semplice da validare e risultato atteso |
|---|---|---|
| D01 | **Ruoli dei soggetti:** chiarito il ciclo DPR; acquisita la conservazione delle intestazioni nei documenti emessi; permessi di modifica configurabili; subentro DPR chiarito | DPR: datore di lavoro/committente, preventivo e verbale mantengono lo stesso intestatario; il terzo si sceglie soltanto in fattura. L’aggiornamento dell’anagrafica non riscrive emessi o loro ristampe. Subentro DPR chiarito: nuovo cliente, stesso impianto fisico e passaggio tracciato. Le responsabilità di modifica si configurano tramite ruoli e permessi. |
| D02 | **Identità e relazioni dei beni:** distinguere impianto DPR, attrezzatura DM, valvola tarata e oggetto CND; più prestazioni e scadenze sullo stesso bene | Conservare la distinzione Garda dei beni. Acquisiti: subentro DPR sullo stesso impianto con passaggio tracciato; abbinamento valvola–attrezzatura corrente modificabile manualmente, senza storico montaggi aggiuntivo. Storico tarature/documenti conservato. Restano gli altri casi condivisi da riscontrare. |
| D03 | **Proprietà dei dati fra nucleo e VerbalizzAI:** chi modifica anagrafiche, caratteristiche tecniche, inventario e profili; quando un verbale aggiorna il dato corrente | Anagrafiche nel nucleo; VerbalizzAI gestisce la compilazione tecnica. Un flusso esplicito aggiorna i dati correnti senza riscrivere gli emessi; campioni e inventario restano distinti. Definire il mapping con l’archivio reale e le versioni. |
| D04 | **Prerequisiti dell’incarico consolidati:** ruoli configurabili, filtro delle qualifiche escluso e dichiarazione d’indipendenza come in Garda | R62: con quattro tecnici abilitati niente matrice o filtro dedicato. R63: dichiarazione preselezionata ed escludibile dal tecnico; se esclusa impedisce lo svolgimento da parte di quel tecnico. Conservare il collegamento all’assegnazione e le modifiche senza inventare una conferma distinta per il solo default. Mapping, controlli sul server e riassegnazione sono lavoro tecnico da verificare. |
| D05 | **Scadenze e dato tecnico corrente:** momento di aggiornamento DPR chiarito; straordinaria con preventivo/incarico distinto chiarita; VS senza ricalcolo automatico della scadenza confermata; dismissione senza annullamento automatico degli incarichi chiarita; restano casi residui di annullamento e conflitti fra fonti | DPR: aggiornamento alla verifica effettuata/emissione, senza attendere RV conforme; revisione emessa con dati pertinenti modificati aggiorna la scadenza. Conservare fonte/motivo; nessuna prevalenza automatica cieca fra dump. Ritocco grafico senza effetto sulla data. VS senza nuovo ciclo periodico automatico: conservare la scadenza periodica esistente. |
| D06 | **Accettazione, modifiche e RC:** evidenza scritta, integrativi, accettazione parziale e RC su tutta l’offerta invariata acquisiti | Preventivo controfirmato oppure email di conferma; niente accettazione telefonica. Il contenuto commerciale accettato resta invariato: per l’aggiunta si crea un nuovo preventivo integrativo, con accettazione scritta e RC prima dell’affidamento. Conservare versione, prestazioni ed evidenze pertinenti. Accettazione parziale per righe confermata; il RC copre tutta l’offerta invariata, comprese le righe già offerte e accettate successivamente. Non occorre un nuovo RC per questa sola ulteriore accettazione. |
| D07 | **Affidamenti pluriennali:** lacuna Garda acquisita, caso raro; gestione dedicata raccomandata fuori dal primo MVP | Garda permette di preventivare la prossima scadenza, non quelle successive dell’affidamento (riscontro dell’utente). Evitare un nuovo modello e automatismi contrattuali ora; conservare accordo e riferimenti e trattare manualmente i rari casi. La copertura dell’accordo, eventuali ordini e RC saranno valutati sul caso effettivo. Non è una decisione bloccante per la struttura ordinaria. |
| D08 | **Deroghe di prezzo e sconti:** operatori autorizzati, casi ammessi, riferimento a gara/accordo e conseguenze sui rinnovi | Tariffa standard e prezzo concordato distinti; deroga motivata e controllata. Nessuno sconto implicito trasferito a tutti i cicli. Verificare le condizioni applicabili prima di attivare deroghe, senza dedurre dal solo codice la loro ammissibilità. |
| D09 | **Rilascio e RV del verbale:** primo DPR con invio dopo RV; RV negativo → registrata acquisito; nota RT visibile e storico RV richiesti | Il verificatore ripete l’attività e/o corregge il verbale, lo finalizza e ricarica, riporta la verifica a eseguita e sottopone il documento a nuovo RV. Conservare tutti i riesami con nota, autore, data/ora e versione esaminata. Invio e fatturazione ordinaria dopo nuovo RV conforme. Rilascio immediato futuro, nelle condizioni discusse. |
| D10 | **Interventi non ordinari:** stato sospesa e continuità alla ripresa acquisiti; sopralluogo a vuoto addebitabile richiesto; restano transizioni puntuali, parziali e condizioni economiche | Conservare il flusso assegnata → eventuale programmata → registrata durante l’esecuzione → eseguita solo con verbale finalizzato e caricato. Riprendere la sospesa sullo stesso incarico e mantenere l’eventuale numero già assegnato. Proposta minima: motivo e passaggio tracciati. Possibilità di addebitare il sopralluogo a vuoto come voce distinta: proposta manuale, con condizioni/importo da definire. Nessuna nuova verifica o variazione ATEX automatica. |
| D11 | **Fatturazione completa e canale elettronico:** fattura unica da più preventivi già presente in Garda e da conservare; acconti non ordinari ma possibili acquisiti; separazione DM/EX acquisita; restano altre eventuali aggregazioni, modalità degli acconti/saldo, rettifiche, riferimenti PA, serie e continuità dei numeri; download XML e caricamento manuale su Aruba acquisiti; importazione degli esiti e visibilità degli scarti richieste, modalità da definire | Conservare la generazione da riga preventivo con possibilità di associazione a fattura esistente, conservando il collegamento alle rispettive prestazioni. Supportare fatture di acconto come eccezione, con collegamento al saldo e distinzione dagli incassi; non imporle nel flusso ordinario. Censire le altre funzioni Garda e conservare il processo utile, con intestatario fiscale proprio. Mantenere download XML e caricamento manuale su Fatturazione Elettronica Aruba; l’invio automatico è rinviabile. Importare gli esiti sulla fattura e conservare scarti, correzioni e tentativi successivi; definire il recupero da Aruba. Approvata per il nuovo sistema la correzione nel gestionale con rigenerazione XML e conservazione del contenuto effettivo. Serie esistenti riscontrate nei backup; significato EX chiarito (CND GVR, efficienza valvole, ispezioni volontarie SC/SP/GVR). DM ed EX restano su fatture separate e hanno serie distinte anche nei preventivi, secondo la prassi confermata. Questo canale esterno non riduce il requisito di fatturazione e incassi completi nel gestionale. |
| D12 | **Incassi e residui:** gestione attuale in Garda acquisita; pagamento unico normalmente per una fattura, eccezionalmente per più fatture acquisito; registrazione manuale iniziale confermata; import estratti conto necessario e successivo; restano verifica dei dettagli economici e collaudo | Conservare la gestione operativa nel primo AD_dpr. Nella normale registrazione, consentire di associare lo stesso pagamento a più fatture, indicando quanto attribuito a ciascuna; non duplicare il totale ricevuto. Nessun flusso dedicato al caso raro. Saldo e residui coerenti; rappresentazione tecnica da consolidare. Registrazione manuale iniziale confermata. Import estratti conto richiesto in un modulo successivo necessario; modalità e abbinamento dei movimenti da progettare in quel modulo, senza presumere un collegamento bancario automatico. Distinguere il modulo incassi da un progetto aggiuntivo di contabilità generale. |
| D13 | **Migrazione e convivenza:** identità dubbie, autorità di scrittura per categoria, importazione dei lavori aperti preferita, da validare; storico già fatturato, riallineamenti | Predisporre l’importazione delle pratiche attive, con prova prima del perimetro definitivo di cutover. Identificativi e riferimenti sorgente stabili; fusioni dubbie da controllare, nessun abbinamento irreversibile solo fuzzy. Durante il collaudo Garda rimane autorità gestionale; VerbalizzAI conserva il proprio ruolo sui documenti prodotti. Al passaggio un’autorità dichiarata per funzione, con import incrementale che non sovrascrive il nuovo lavoro. |
| D14 | **Scelte tecniche iniziali:** stack, database, confine dell’adattatore VerbalizzAI, archivio nuovi documenti e riuso della 0.7.1; profilo di accesso al server centrale | Il candidato è Python/FastAPI, SQLAlchemy/Alembic, HTML/JS, già presenti nel prototipo. Valutare il database e il riuso sui requisiti consolidati. Un backend centrale online e un archivio ufficiale dei contenuti; specificare da subito cosa entra nel backup e come evitare aggiornamenti divergenti fra archivi. |

Per D11 e D12 il censimento dei percorsi attuali deve precedere le domande residue: non si chiede all’utente di riscrivere a memoria tutto il software. Analogamente D02/D03 vengono presentati con esempi reali e D05 con eventi e conflitti già riscontrati. Le funzioni assenti nella 0.7.1 non vengono scambiate per assenti in Garda.

Il carattere integrato del nucleo si valida adesso sui ruoli dei soggetti, sull’identità dei beni e su un caso condiviso DM/I&C. Non richiede di decidere adesso tutti i tariffari o i flussi applicativi dei futuri moduli DM/I&C.

### 25.3 Lavoro tecnico e verifiche che non sono ulteriori domande aziendali

Una volta chiuse le regole, la progettazione deve tradurle in:
- riferimenti canonici stabili e origine di ogni dato migrato;
- importi esatti e precisione pertinente di quantità/prezzi/aliquote;
- collegamenti e vincoli dichiarati, controllo dei duplicati;
- numerazione atomica, versioni e gestione della concorrenza;
- contenuti e generazioni documentali identificabili, registro eventi e riesami riferiti alle versioni;
- recupero coerente dopo errori, import incrementale, backup/ripristino completo;
- collaudo sui casi normali e sulle eccezioni concordate.

Sono responsabilità tecniche dell’implementazione. Il riuso del prototipo non autorizza a mantenerne i problemi osservati. Non occorre sottoporre ogni vincolo database all’utente come scelta separata.

### 25.4 Decisioni e dettagli che possono attendere

Non bloccano il codice iniziale: nomi file nei dettagli, cartelle di download, testi dei pulsanti, aspetto delle maschere, impaginazione fine, dispositivi/tablet specifici, termine operativo dei solleciti di RV e automazioni accessorie.

Sono necessari prima del corrispondente esercizio in produzione, ma non prima dell’ossatura: macchina/hosting effettivi, dominio e accesso esterno, frequenza/retention e tempi di ripristino del backup, eventuale ambiente esterno di recupero, disponibilità delle credenziali dei servizi, piano concreto per recuperare gli originali S3, verifiche finali sulle fusioni e sui documenti storici, data e finestra del cutover. Il requisito di accesso centrale e il perimetro dei dati da proteggere entrano invece in D14 adesso.

Le regole minute DM/I&C possono attendere i loro moduli, purché D01–D03 dimostrino ora che il nucleo non confonde soggetti, beni, società e prestazioni.

### 25.5 Ordine per chiudere la specifica

1. D01–D03: soggetti, beni e proprietà dei dati.
2. D04–D10: responsabilità e processo DPR, comprese le sole eccezioni strutturali.
3. D11–D12: ciclo economico completo.
4. D13–D14: migrazione/convivenza e soluzione tecnica coerente.

Il risultato prima del codice è una specifica breve dei casi e delle regole, accompagnata dal modello concettuale e dai criteri di accettazione. Non serve un motore generalizzato di processi. Nel confronto si affronta un punto alla volta, riutilizzando quanto già deciso; una proposta ancora aperta non diventa un requisito approvato soltanto perché compare in tabella.

## 26. Chiarimento DPR sui soggetti e metodo per le modifiche

### 26.1 Regola confermata, mantenendo Garda

L’utente chiarisce che Garda prevedeva opportunamente la fatturazione a terzi soltanto alla generazione della fattura:
- il committente è il datore di lavoro;
- impianto, preventivo e verbale hanno l’intestatario pertinente a quel datore di lavoro nel processo descritto;
- la fattura propone quel cliente come intestatario;
- nei casi particolari, l’intestatario della fattura può essere cambiato;
- tale modifica non cambia preventivo, verbale o anagrafica dell’impianto.

La proposta precedente di intestare il preventivo a un committente B mantenendo il verbale ad A è ritirata per questo flusso DPR: non corrisponde al processo chiarito e introdurrebbe una distinzione superflua. Non si aggiunge quindi un soggetto commerciale obbligatorio prima della fatturazione.

La scelta del terzo avviene nella fattura e ne conserva i dati fiscali propri. Non viene anticipata come requisito del preventivo o dell’incarico. Il termine datore di lavoro/intestatario non viene trasformato automaticamente in proprietario giuridico del bene.

### 26.2 Vincolo esplicito sul metodo

L’utente richiede di parlarne prima di modificare logiche, entità o relazioni Garda. Il metodo di confronto diventa:
1. mostrare il comportamento e i collegamenti attuali riscontrati nel sorgente;
2. indicare un’inefficienza, mancanza o esigenza concreta;
3. proporre la modifica minima e mostrarne l’effetto sul caso;
4. discutere la scelta prima di adottarla nel modello o nel codice.

Le proposte generali di nucleo comune nelle sezioni precedenti rimangono ipotesi di progettazione. L’obiettivo di integrazione non autorizza automaticamente una diversa articolazione dei soggetti, dei beni o dei flussi.

In questa fase sono stati aggiornati soltanto i documenti di analisi e decisione; non sono stati modificati i sorgenti o i database dei gestionali per implementare nuove logiche. La registrazione di una risposta dell’utente nel documento conserva il requisito; non equivale a un cambiamento dell’applicazione.

### 26.3 Stato del prossimo confronto

D01 è chiarito sul ruolo dei soggetti nel ciclo DPR. Le domande successive devono evitare di riaprire questa distinzione. Responsabilità di modifica dei dati comuni, casi di cambio intestatario del bene e differenze degli altri ambiti vanno affrontati soltanto dopo il riscontro del funzionamento Garda e con esempi pertinenti.

L’elenco D01–D14 della sezione 25 resta un elenco di temi da consolidare: non è un invito a ridisegnare tutti i concetti esistenti. Prima si conserva ciò che funziona; si cambia dove emerge un beneficio concreto e dopo il confronto richiesto.

## 27. Aggiornamento dei clienti e conservazione dei documenti emessi

### 27.1 Requisito esplicito dell’utente

L’utente segnala che, secondo il proprio ricordo, Garda non conserva la storia del cliente: cambiandone il nome cambiano le anagrafiche e le sedi collegate. Chiede di verificarlo e precisa il risultato necessario: **i dati non devono cambiare nei verbali e nei preventivi già emessi**.

Il requisito vale sia per il file ufficiale conservato sia per la consultazione del documento e per un’eventuale ristampa. Una correzione intenzionale di un emesso rimane un’azione distinta e tracciata; non è l’effetto implicito di una modifica dell’anagrafica.

### 27.2 Riscontro sul backup Garda ingecert

Verifica statica del dump e dei sorgenti:
- `clienti` contiene i dati correnti e i campi `last_update_user`, `last_update_ts`, `last_update_nr`; il dump non presenta una tabella di versioni storiche del cliente o di successione dei clienti sul bene.
- `clienti_dec` legge `rag_soc` direttamente da `clienti`; `impianti_read` ricava il cliente dalla sede operativa corrente. I collegamenti di visualizzazione non rappresentano da soli il cliente alla data della vecchia verifica.
- `gi_clienti_save_before` non contiene una conservazione delle precedenti intestazioni. I log tecnici e di elaborazione presenti non sono una storia strutturata dell’anagrafica riscontrata.
- `preventivi` conserva il riferimento al cliente, senza campi di copia dell’intestazione. Il report `_rp_preventivo_word` legge `clienti` tramite `p.cliente`; una nuova generazione usa quindi i dati correnti. Anche il nome file viene costruito dalla ragione sociale corrente.
- `verifiche_verbale` conserva riferimenti a file caricati; questo non equivale a conservare l’intestatario storico nelle viste anagrafiche.
- Le fatture clienti hanno invece propri campi `cli_rag_soc`, indirizzo, CF e P.IVA, distinti dal riferimento al cliente.

Il riscontro sostiene il ricordo dell’utente per i dati relazionali esaminati. Non dimostra che una modifica del cliente riscriva automaticamente file già archiviati: il rischio accertato è la lettura/generazione dai dati correnti. Gli originali S3 non sono stati consultati.

Riferimenti: dump `ingecert_2026-10-07.sql`; `cust/gi_views.php`; `cust/_custom.php` (`gi_clienti_save_before`, `gi_rpt_preventivi_base_file_name_get`); `cust/meta/_rp_preventivo_word.js`; `cust/meta/clienti.js` e `clienti_sedi_operative.js`.

### 27.3 Soluzione minima proposta

Separare il dato corrente dall’evidenza emessa:
- l’anagrafica può essere aggiornata;
- preventivo/verbale emesso conserva i dati utilizzati e il proprio file/versione ufficiale;
- il download/ristampa di un emesso usa quella versione o i suoi dati, senza sostituirli con l’anagrafica attuale;
- la preparazione di un nuovo documento usa invece il cliente corrente pertinente.

La conservazione dei dati dell’emissione non richiede, da sola, di introdurre una gestione completa delle versioni di ogni campo anagrafico o nuovi adempimenti manuali. Il meccanismo tecnico va consolidato prima del codice; il risultato richiesto dall’utente è acquisito. Le bozze e le eventuali revisioni commerciali mantengono il flusso già discusso.

### 27.4 Scelta acquisita: altra azienda sullo stesso impianto

Un aggiornamento della stessa azienda — ad esempio denominazione o recapito — e il subentro di un altro soggetto giuridico sono casi distinti. Per il secondo l’utente approva un nuovo record cliente, mantenendo il precedente per lo storico e per le pratiche che gli appartengono. Non si propone di trasformare l’identità della vecchia azienda semplicemente rinominandola.

Dopo il riscontro sui sorgenti e la precisazione sui documenti emessi, l’utente approva la proposta di **mantenere lo stesso impianto fisico**, collegarlo al nuovo cliente e **registrare il passaggio**. Non si crea una seconda identità del bene per il solo cambio di azienda. La scelta riguarda il caso DPR discusso; non è un trasferimento già eseguito.

I preventivi e i verbali emessi rimangono riferiti al soggetto e ai dati della loro emissione. Il sistema dovrà distinguere le nuove prestazioni dalle pratiche già appartenenti al precedente cliente: il subentro non trasferisce automaticamente i debiti o le condizioni commerciali della vecchia azienda.

### 27.5 Prossimo caso di confronto D02: valvole e attrezzature

Nei metadati Garda AD_dm la valvola di sicurezza è già un oggetto distinto (`valvole_sicurezza`), identificato anche da fabbricante, modello e matricola, con riferimenti di taratura. L’associazione alle attrezzature è in `attrezzature_vds`, con riferimenti separati a valvola e attrezzatura e unicità della coppia. Si conserva questa distinzione come base del confronto; non si propone di trasformare la valvola nell’attrezzatura.

L’utente riconosce la possibile utilità della storia dei montaggi, ma chiede di evitare la complicazione architetturale. La prassi e la scelta sono **mantenere l’abbinamento corrente, modificandolo manualmente quando necessario**, insieme allo storico delle tarature e ai documenti. Non si introduce nel primo perimetro una gestione separata dei montaggi con intervalli temporali. Il subentro DPR già concordato rimane un caso distinto.

Il collegamento corrente non deve alterare certificati e documenti già emessi. Le evidenze conservate rimangono consultabili, ma non viene promessa una ricostruzione strutturata dell’esatta installazione a qualsiasi data passata. Il modello comune va ancora validato sul riuso delle tarature fra DM e I&C.

Riferimenti: `adsrl/cust/meta/valvole_sicurezza.js` e `adsrl/cust/meta/attrezzature_vds.js`.

### 27.6 Esito D03: permessi di correzione configurabili

Riscontro nei ruoli predefiniti Garda ingecert (`gi_ddl_table_create_ruoli`): il ruolo Tecnico ha accesso alle proprie verifiche/impianti e non comprende i permessi di modifica clienti o sedi. Questo riscontro sui preset non certifica le assegnazioni e personalizzazioni di ogni account in produzione. Nel prototipo 0.7.1 i permessi anagrafici sono inizialmente assegnati a RT e segreteria.

L’utente chiarisce che l’eventuale correzione diretta delle anagrafiche è gestita con le impostazioni di ruoli e permessi. Non si introduce un percorso obbligatorio di segnalazione o approvazione per risolvere il caso; la distribuzione dei permessi non blocca il modello iniziale. I documenti già emessi restano comunque soggetti a R33.

Il catalogo D01–D14 è aggiornato di conseguenza: le domande successive devono riguardare effetti sostanziali sul lavoro o sui dati, non la sola assegnazione di un permesso già configurabile. Questo chiarimento non sceglie ancora quali dati tecnici del verbale aggiornino lo stato corrente e in quale momento.

## 28. Momento di aggiornamento delle scadenze DPR — scelta acquisita

Il riscontro Garda ingecert è preciso: `ricalcola_scadenze_impianto` legge l’ultima verifica **VP** in stato **effettuata**, ordinata per data di rilascio del verbale, e aggiorna ultima verifica e prossima scadenza dell’impianto. La selezione non richiede riesame conforme. `gi_verifiche_change_after` richiama quel ricalcolo; un nuovo RV negativo riporta la verifica a registrata e richiama il processo di aggiornamento. I casi di assenza di una VP utilizzabile e di rettifica meritano un controllo specifico, senza presumere che ogni ricalcolo cancelli o ripristini correttamente tutti i campi.

L’utente conferma il comportamento ordinario: **aggiornare la scadenza alla verifica effettuata/emissione, prima del RV**, salvo adeguarla quando il verbale viene modificato in revisione. La precedente proposta di consolidamento soltanto dopo RV conforme è superata.

La regola va applicata senza passaggi manuali aggiuntivi:
- una bozza di revisione non diventa il nuovo documento ufficiale;
- quando la revisione viene emessa, eventuali cambiamenti di data, periodicità o altra informazione determinante devono aggiornare coerentemente la scadenza pertinente;
- un cambiamento soltanto grafico non modifica quei dati;
- originali e revisioni rimangono conservati e identificabili.

Queste precisazioni traducono il requisito in criteri di implementazione; non sono modifiche già realizzate. La regola acquisita riguarda il ciclo periodico DPR. Effetti di annullamenti, esiti tecnici e straordinarie vanno ancora consolidati nei casi pertinenti.

Riferimenti: `ingecert/cust/_custom.php`, funzioni `ricalcola_scadenze_impianto` e `gi_verifiche_change_after`.

### 28.1 Riscontro sulle revisioni Garda e sul riuso di VerbalizzAI

Nel dump ingecert e nei servizi/metadati esaminati non è stata individuata una revisione strutturata del verbale con numero di revisione e relazione fra versioni. È invece presente il ciclo di correzione dopo RV negativo: verifica riportata a registrata, possibilità di ricaricare il PDF e rimetterla in effettuata, con reset del RV per il nuovo controllo. Il caricamento di un altro file non equivale, da solo, a una revisione formalmente collegata al precedente documento.

VerbalizzAI e il ponte 0.7.1 hanno già `create_revision`, `revision_of` e il percorso di nuova emissione collegata alla stessa verifica. Sono componenti da riutilizzare e adattare alla regola appena acquisita, non funzioni da ricostruire da zero. La lettura statica della 0.7.1 mostra inoltre che le differenze di data possono essere trattate come avvisi: il comportamento futuro deve assicurare coerenza fra i dati realmente corretti e la scadenza, senza limitarsi a sostituire il file.

Riferimenti: Garda `cust/_custom.php` e `meta/verifiche.js`; Gestionale_AD 0.7.1 `moduli/verbali/servizio.py` (`_revisione_dopo_riesame`, `dopo_emissione`) e `moduli/verifiche/servizio.py` (`carica_verbale`).

### 28.2 Esito D06: evidenza scritta dell’accettazione

Garda prevede il campo `rif_ord_cli` (“Rif. ordine cliente”), da riportare in fattura quando compilato. Il campo non chiarisce da solo quali risposte il cliente fornisca normalmente e quali evidenze l’azienda richieda per registrare l’accettazione.

L’utente chiarisce che una conferma telefonica non capita mai e che viene sempre richiesto il **preventivo controfirmato oppure almeno una email di conferma**. La conferma scritta deve essere riferibile alle condizioni/versione e alle prestazioni accettate. Un generico stato accettato non sostituisce tale evidenza.

Non è stato invece deciso che l’accettazione richieda sempre il caricamento manuale di un file nel gestionale: documento, email o loro riferimento devono poter essere conservati e recuperati secondo il processo da consolidare. Non si introducono una firma elettronica del cliente obbligatoria o un’ulteriore approvazione interna. L’accettazione scritta precede il RC nel flusso già acquisito.

### 28.3 Esito D06: nuova prestazione dopo il preventivo accettato

**Decisione acquisita:** il preventivo accettato non si può modificare. Se il cliente aggiunge una prestazione, si prepara un nuovo preventivo integrativo. Le prestazioni dell’originale e dell’integrativo possono poi essere riunite in un’unica fattura.

Il nuovo preventivo segue il flusso già concordato: invio, accettazione scritta, riesame del contratto e, solo dopo esito conforme, affidamento dell’incarico. L’offerta originaria, le condizioni accettate e la relativa evidenza restano conservate; i suoi incarichi non vengono riscritti per inserire la nuova prestazione. L’immutabilità riguarda il contenuto commerciale accettato e non impedisce di registrare il successivo avanzamento operativo.

**Funzione Garda da conservare:** l’utente conferma che dalla riga preventivo si può generare una fattura oppure associare la prestazione a una fattura esistente. Il sorgente della maschera conferma l’azione «Genera/integra fattura», il campo «Fattura da integrare» e l’invio del relativo identificativo. La fattura unica conserva la provenienza delle prestazioni dalle rispettive righe/preventivi e il controllo contro la doppia fatturazione. Non serve fondere o sostituire i preventivi per poterli fatturare insieme.

Riscontro aggiuntivo: Garda `cust/meta/_custom.js`, `gi_preventivi_righe_fattura_genera_click`; `cust/meta/preventivi_righe.js`, azione di generazione fattura. Non è stato eseguito un test dell’intero percorso di fatturazione.

Riscontro dei sorgenti: Garda gestisce righe del preventivo, stato per riga e controllo contro prestazioni duplicate; il percorso esaminato non rappresenta una revisione commerciale strutturata equivalente a quella del prototipo. La 0.7.1 consente invece `crea_revisione` soltanto da un preventivo inviato o rifiutato, non ancora accettato. Questa funzione non va estesa all’accettato per gestire l’aggiunta: il requisito acquisito richiede un nuovo preventivo integrativo.

Riferimenti: Garda `cust/_custom.php`, `gi_preventivi_righe_save_before`; 0.7.1 `moduli/preventivi/servizio.py`, `crea_revisione`.

### 28.4 D07: limite Garda e priorità dei pluriennali

**Chiarimento acquisito dall’utente:** Garda non prevede la gestione degli affidamenti pluriennali: consente di preventivare la prossima scadenza, non anche quelle successive. Questa è una lacuna del sistema attuale, distinta dalla fatturazione aggregata che invece esiste già.

L’utente precisa che i pluriennali sono rari e chiede di valutarne l’utilità senza rischiare di alterare la logica. **Raccomandazione:** non costruire ora un modulo o un nuovo ciclo di vita contrattuale; mantenere il flusso ordinario e trattare manualmente i rari affidamenti, conservando l’accordo accettato e i riferimenti alle prestazioni pertinenti. L’eventuale gestione automatica è un’estensione futura, non un prerequisito dell’MVP.

Questa raccomandazione non equivale ad approvare una nuova entità accordo, a imporre un nuovo preventivo o una nuova accettazione ogni anno, né a dare per autorizzata ogni prestazione futura. Quando si incontra il caso concreto, vanno verificate la copertura dell’accordo e la documentazione richiesta per il singolo intervento, insieme all’applicazione del RC già concordato.

### 28.5 Esito D10: stati ordinari e proposta di sospensione

**Flusso chiarito dall’utente:**
- dopo l’assegnazione, la verifica può essere programmata; lo stato programmata non è obbligatorio;
- passa a registrata in occasione dell’esecuzione;
- diventa eseguita soltanto quando il verbale è finalizzato e caricato nel gestionale;
- se la verifica non può essere eseguita, l’utente propone di aggiungere lo stato sospesa.

Si conserva quindi il flusso ordinario, aggiungendo uno stato di sospensione per un impedimento operativo. Una semplice uscita sul posto o l’avvio dell’attività non bastano a dichiarare eseguita la verifica. La sospensione non equivale all’esito tecnico negativo di una verifica conclusa e non è una correzione del verbale dopo RV.

**Continuità confermata dall’utente:** alla ripresa si continua sullo stesso incarico, mantenendo l’eventuale numero di verbale già assegnato. La sola sospensione non genera un nuovo incarico né una nuova numerazione. Attività e dati già registrati restano pertinenti alla stessa pratica.

**Proposta minima accessoria:** tracciare motivo, autore e momento della sospensione; conservare il passaggio e la ripresa nel registro eventi, senza introdurre un sottoprocesso separato.

Restano da definire gli stati dai quali si può sospendere e a quali si torna alla ripresa; l’eventuale rinuncia definitiva è distinta dalla sospensione. L’utente ha successivamente indicato come corretta la possibilità di addebitare il sopralluogo a vuoto (sezione 28.6); non è acquisita alcuna tariffa né un automatismo di fatturazione. I controlli RC e RV già concordati rimangono pertinenti; non si inventa un riesame aggiuntivo soltanto per il cambio di stato.

**Esito del chiarimento economico:** l’utente dichiara che oggi l’uscita a vuoto non è gestita e ritiene corretto addebitare il sopralluogo. È una nuova esigenza, non la descrizione di una procedura già in uso. La proposta di realizzazione e i limiti sono nella sezione 28.6.

### 28.6 Sopralluogo a vuoto: esigenza nuova e soluzione minima proposta

L’utente risponde al caso di verifica definitivamente annullata dopo l’uscita: oggi la situazione non è stata gestita, ma ritiene corretto addebitare un sopralluogo a vuoto. Si raccoglie la **possibilità di addebito**, non un obbligo in ogni caso.

**Proposta da discutere prima di implementare:** usare una voce economica manuale “sopralluogo a vuoto”, distinta dalla verifica non conclusa. Non portare la verifica a eseguita per fatturare l’uscita, non emettere un verbale di verifica inesistente e non aggiornare la scadenza periodica per il solo sopralluogo. L’operatore determina se la voce sia dovuta e il suo importo secondo le condizioni pertinenti: nessuna tariffa, clausola o autorizzazione commerciale viene inventata dal gestionale.

Il riscontro statico Garda mostra già righe fattura creabili/modificabili, con descrizione, quantità e prezzo; i riferimenti a preventivo e verifica non sono dichiarati obbligatori nei metadati esaminati. Questo suggerisce di conservare le normali funzioni economiche, senza introdurre un modulo separato per le uscite a vuoto. Non è stata eseguita una prova dell’intero percorso e non si dichiara già esistente una gestione specifica del sopralluogo.

Restano da concordare condizioni di addebito, importo e riferimento alla pratica. I dettagli tariffari possono essere definiti in seguito; non si estende automaticamente questa scelta alle verifiche sospese che saranno poi completate. Il controllo RV della fatturazione ordinaria delle verifiche rimane distinto dalla definizione di questa prestazione economica.

Riferimento: Garda ingecert `cust/meta/fatture_clienti_righe.js`.

### 28.7 Esito D11: acconti DPR occasionali

Garda offre nei metadati i tipi TD02 e TD03 per acconti/anticipi; la loro presenza non prova, da sola, una gestione completa dell’imputazione al saldo. L’utente chiarisce la prassi: **non sono ordinari nel DPR, ma possono capitare**. Vanno quindi supportati nel primo ciclo economico completo, mantenendo la fatturazione a lavoro concluso come percorso ordinario.

L’acconto fatturato deve essere riferibile al preventivo/prestazioni pertinenti e tenuto in conto nel saldo, evitando di fatturare nuovamente lo stesso importo. Il documento di acconto e il suo incasso sono fatti distinti: non si presume che una fattura sia pagata perché emessa. Questa precisazione conserva il significato dei dati, senza definire qui modalità fiscali di compilazione, calcolo o trasmissione.

L’acconto non rende eseguita una verifica e non sostituisce i controlli commerciali e tecnici concordati. Le regole ordinarie di RC, finalizzazione del verbale e RV rimangono pertinenti ai rispettivi passaggi; non si impone una verifica eseguita come condizione generale di creazione di una fattura di acconto.

Riferimento: Garda ingecert `cust/meta/fatture_clienti.js`.

### 28.8 Esito D11: download XML e caricamento su Aruba

**Prassi acquisita dall’utente:** l’XML viene scaricato dal gestionale e caricato manualmente nel servizio Fatturazione Elettronica Aruba. Il primo AD_dpr conserva questo percorso; l’invio automatico può essere un miglioramento successivo, senza condizionare l’avvio.

Il sorgente contiene il generatore XML e riferimenti ad Aruba nei metadati di configurazione e nei commenti del generatore. La risposta dell’utente chiarisce la prassi effettiva, che non era deducibile dai soli riferimenti statici.

Il ciclo completo di fatturazione e incassi rimane nel perimetro del gestionale, anche usando un servizio esterno per la trasmissione. L’utente ha successivamente chiarito che gli esiti sono consultati su Aruba e devono essere importati nel nuovo gestionale (sezione 28.11): la sola generazione o il download dell’XML non prova l’avvenuta trasmissione. Non sono acquisiti un sincronismo API né un’importazione automatica degli esiti.

Riferimenti: Garda ingecert `cust/meta/configurazioni.js`, `cust/fatture_clienti_genera_xml_cli.php`.

### 28.9 Esito D12: incassi e crediti gestiti in Garda

**Prassi confermata dall’utente:** gli incassi e le fatture ancora da pagare vengono gestiti in Garda. Questa funzione rimane nel primo AD_dpr, insieme alla fatturazione completa; Aruba conserva il ruolo dichiarato di servizio per il caricamento e la trasmissione degli XML.

Il sorgente Garda mostra pagamenti/scadenze, importo, riferimento del pagamento e indicatore saldato. Nei metadati esaminati ogni riga ha un riferimento obbligatorio a una singola fattura cliente. Questo non basta a dedurre come l’azienda gestisca effettivamente un bonifico che copre più fatture o un incasso parziale.

La registrazione di questa prassi non autorizza una nuova entità movimento o nuove relazioni finanziarie senza confronto. Prima si chiariscono i casi concreti da supportare, mantenendo la semplicità richiesta; non si presume un collegamento bancario automatico.

Riferimento: Garda ingecert `cust/meta/pagamenti.js`.

### 28.10 Esito D12: pagamento unico associabile a più fatture

**Chiarimento dell’utente:** il pagamento viene normalmente associato a una singola fattura. È raro che copra più fatture; in quel caso si tratta di associare lo stesso pagamento a due o più fatture.

Il risultato richiesto è quindi un pagamento unico, con una o più associazioni alle fatture. Non serve un flusso dedicato al caso raro: la normale gestione pagamenti permette di aggiungere la seconda fattura quando necessario. La precedente domanda sull’approvazione di una maschera separata è superata dal chiarimento.

Per ogni fattura deve risultare l’importo attribuito, così da calcolare il residuo senza duplicare quanto ricevuto. Esempio: 1.000 euro incassati, 400 attribuiti alla prima fattura e 600 alla seconda; l’incasso rimane 1.000 euro. Le quote sono una conseguenza tecnica del comportamento richiesto, non un ulteriore adempimento contabile.

**Riscontro Garda:** nei metadati esaminati la riga pagamento ha un riferimento obbligatorio a una singola fattura cliente, importo e riferimento del pagamento. Si conserva il significato del collegamento alla fattura; come rappresentare la possibilità di più associazioni va ancora definito tecnicamente. Non si dichiara che il vecchio riferimento singolo rappresenti già un pagamento unico su più fatture. Nessuna modifica a tabelle o applicazione è stata eseguita.

### 28.11 Esito D11: esiti su Aruba e importazione richiesta nel gestionale

**Prassi e mancanza confermate dall’utente:** gli esiti sono oggi consultati su Aruba e non lasciano traccia in Garda. L’utente chiede che vengano importati nel gestionale, segnalando che una fattura scartata deve essere ripresentata.

Il requisito riguarda il nuovo AD_dpr: mantenere sulla fattura gli esiti importati e rendere visibile lo scarto da gestire, conservando la storia delle correzioni e dei successivi tentativi. La generazione o il download dell’XML non equivalgono a trasmissione riuscita. Non basta memorizzare soltanto l’ultimo file eliminando il motivo dello scarto e l’esito precedente.

Il caricamento manuale dell’XML su Aruba può rimanere il percorso di invio. Il recupero degli esiti è un requisito distinto: la modalità concreta (automatica oppure importazione assistita) va verificata sulle capacità disponibili e definita prima dell’implementazione. Non è acquisita un’integrazione API già funzionante o autorizzato un accesso a credenziali.

I metadati Garda esaminati mostrano generazione XML e relativo log, coerentemente con il limite pratico segnalato dall’utente; non è stata eseguita una prova live del canale. Il requisito nuovo non autorizza modifiche immediate ai sorgenti Garda.

Riferimento: Garda ingecert `cust/meta/fatture_clienti.js`.

### 28.12 Esito D11: correzione nel nuovo gestionale approvata

L’utente inizialmente dichiara di non avere una policy precisa per la correzione delle fatture scartate. Dopo il confronto approva il criterio per il nuovo sistema: correzione nel gestionale, rigenerazione XML e nuovo caricamento su Aruba. È una scelta futura approvata, non una modifica già eseguita.

**Criterio approvato:** correggere il contenuto della fattura nel nuovo gestionale, rigenerare l’XML e caricare il file corretto su Aruba per il nuovo tentativo. Il gestionale conserva il contenuto utilizzato, gli XML dei tentativi e gli esiti importati. Aruba rimane il servizio di trasmissione; il recupero degli esiti resta un requisito separato.

Il vantaggio concreto è mantenere allineati importi, intestazione e righe conservati nel gestionale con il documento effettivamente ripresentato, senza dover riconciliare due contenuti modificati in luoghi diversi. Non serve un flusso documentale distinto per ogni servizio esterno.

Il criterio su dove correggere è approvato dall’utente; la sua realizzazione è ancora da progettare e collaudare. Individuare dove si corregge il contenuto non definisce da solo le regole fiscali di numerazione, date e rettifiche: tali regole dovranno essere verificate prima dell’implementazione pertinente. Non si assimila automaticamente lo scarto alla rettifica di una fattura già accettata e non si introduce una nuova prestazione da fatturare per il solo reinvio.

### 28.13 Esito D11: serie delle fatture e significato EX

Verifica sui database di staging derivati dai dump, aperti in sola lettura, e sui metadati Garda. Le serie recenti riscontrate sono:

| Archivio | Serie riscontrate | Significato acquisito |
|---|---|---|
| ingecert / AD_dpr | `/2026/DPR`, `/2025/DPR` | Serie DPR coerente con l’ambito. |
| adsrl / AD_dm | `/2026/DM`, `/2026/EX`, `/2026/ex`, `/2025/EX` tra le serie recenti | DM coerente con l’ambito; EX: CND GVR, efficienza valvole di sicurezza e verifiche ispettive volontarie SC/SP/GVR, secondo il chiarimento dell’utente. |
| iec / I&C | `/2026` | Serie annuale senza suffisso di attività nel campione riscontrato. |

Nei metadati fattura esistono numero e serie separati; il numero predefinito dipende dalla serie. Il generatore di serie adsrl esaminato propone `/anno/DM`, quindi il significato operativo EX è stato acquisito dall’utente. Non si deduce l’attività dal solo suffisso né si presume che EX ed ex vadano normalizzati o unificati.

**Significato EX acquisito dall’utente:**
- controlli non distruttivi delle attrezzature GVR;
- verifiche di efficienza delle valvole di sicurezza, come accessori GVR;
- verifiche ispettive volontarie SC, SP e GVR.

La classificazione conserva la società AD e il tipo specifico di prestazione oltre alla serie fiscale. Il termine “efficienza” indicato dall’utente resta quello della prestazione: non viene sostituito con “taratura” o assegnato automaticamente al modulo I&C. Questo chiarimento interessa i dati e il nucleo comune; i flussi dettagliati del futuro modulo DM possono attendere. Nessuna rinumerazione o fusione delle serie è approvata o eseguita.

Riferimenti: staging `ingecert.sqlite`, `adsrl.sqlite`, `iec.sqlite`, tabella `fatture_clienti`; `cust/meta/fatture_clienti.js`; adsrl `cust/_doc_fiscali_common.php`, `gi_serie_documento_get`.

### 28.14 Esito D11: DM ed EX su preventivi e fatture separati

**Risposta dell’utente:** si emettono due fatture separate, perché anche le serie dei preventivi DM ed EX sono separate. La separazione riguarda quindi il percorso commerciale e quello di fatturazione, pur per lo stesso cliente e la stessa società AD.

Il nucleo comune conserva questa prassi. La possibilità di riunire prestazioni di più preventivi in un’unica fattura, già acquisita nel confronto DPR, non autorizza a mescolare prestazioni DM ed EX. Non è necessario inventare una regola di scelta della serie per una fattura mista DM/EX: quel documento non fa parte della prassi da mantenere.

Questa risposta non decide automaticamente ogni altro abbinamento fra attività o serie. La separazione aziendale delle società emittenti rimane il requisito già acquisito.

Riscontro statico aggiuntivo: i metadati preventivo contengono serie e numero separati. Nel campione recente dello staging adsrl compaiono valori come `2026` e `2026/A`; da questi soli valori non è stata ricavata una mappatura delle serie commerciali DM/EX. Il significato della separazione è acquisito dall’utente; la corrispondenza puntuale nei materiali resta una verifica tecnica della migrazione, non una nuova regola da inventare.

Riferimenti: adsrl `cust/meta/preventivi.js`; staging `adsrl.sqlite`, tabella `preventivi`.

### 28.15 Esito D09: primo DPR con invio dopo riesame

Alla domanda sul perimetro del primo AD_dpr, l’utente conferma per ora **invio dopo riesame**, correggendo il termine inizialmente digitato. Il primo esercizio mantiene quindi il percorso ordinario; l’opzione di rilascio immediato viene rinviata.

Le valutazioni della sezione 24 rimangono riferimento per una futura estensione e per la compatibilità del modello. Non occorre implementare un secondo percorso operativo ora. Il RC prima dell’affidamento e il RV prima dell’invio mantengono i significati già concordati.

### 28.16 Esito D09: RV negativo → registrata, nota visibile e storico dei riesami

**Flusso confermato dall’utente:** quando il RT dà esito negativo al riesame, la verifica torna a registrata. Il verificatore deve ripetere l’attività e/o modificare il verbale, ricaricarlo e riportare la verifica a eseguita. Il documento viene quindi sottoposto a un nuovo RV; la fatturazione ordinaria e l’invio rimangono subordinati all’esito conforme.

**Requisiti aggiuntivi acquisiti:**
- il verificatore vede la nota scritta dal RT in caso di esito negativo;
- ogni verbale conserva lo storico di tutti i riesami, inclusi quelli negativi;
- ogni riesame resta riferito al documento/versione effettivamente esaminato, con esito, nota, autore e data/ora;
- il ricaricamento e il nuovo RV non eliminano né riscrivono le note e le evidenze precedenti.

La nota negativa rimane obbligatoria, come già previsto dai metadati Garda e dal servizio RV della 0.7.1. La visibilità richiesta serve al verificatore per conoscere cosa ripetere o correggere. Il riesame corrente può tornare da fare dopo il ricaricamento, mentre la cronologia continua a mostrare il precedente esito negativo e la sua nota.

**Riscontro Garda:** `gi_verifiche_change_after` riporta a registrata quando viene registrato un nuovo RV negativo. Al ritorno a effettuata resetta i campi correnti `riesame_fatto`, `riesame_esito` e `riesame_nota`. Il campo nota è già previsto nei metadati, visibile agli utenti che possono consultare le verifiche/proprie verifiche, con obbligo in caso di esito negativo. Quindi si conserva il flusso e si migliora la permanenza e la consultazione della cronologia. Il riscontro sui campi correnti non esclude eventuali log generici del framework, che da soli non sono la vista storica per verbale richiesta.

**Riuso del prototipo:** il servizio `riesame` registra esito, note, autore e momento e scrive un evento `verifica.riesame`; anche qui l’esito negativo porta a registrata. Il registro eventi è una base utile per lo storico, da rendere consultabile per verbale e collegare alla precisa versione esaminata. Non si dichiara già disponibile una cronologia completa conforme al nuovo requisito sulla sola presenza dell’evento.

**Criterio per il collaudo futuro:** RV negativo con nota, correzione e ricaricamento, nuovo RV conforme. La verifica torna prima a registrata e poi a eseguita; il verificatore vede la nota originale e la cronologia mostra entrambi i riesami con i rispettivi documenti. Nessun invio o fatturazione ordinaria usando il riesame precedente.

Riferimenti: ingecert `cust/_custom.php`, `gi_verifiche_change_after`; `cust/meta/verifiche.js`, `riesame_nota`; prototipo `gestionale/moduli/verifiche/servizio.py`, `riesame` e `_scrivi`.

### 28.17 D13: importazione degli incarichi aperti preferita, da valutare

L’utente indica che la scelta va valutata, ma **l’ideale è importare gli incarichi già aperti** nel nuovo AD_dpr. Si registra questa preferenza e si predispone il progetto per accogliere pratiche attive; non si presenta il trasferimento completo come una migrazione già collaudata o una decisione definitiva di cutover.

Durante il collaudo Garda rimane l’autorità gestionale, come già proposto. Prima del passaggio si prova l’importazione di incarichi nei diversi stati, con i collegamenti a cliente/sede/impianto, preventivo e righe, tecnico, numero di verbale eventualmente assegnato, documenti e riesame corrente disponibile. Le evidenze storiche vengono importate nella misura effettivamente disponibile, senza inventare riesami precedenti cancellati dai campi correnti.

**Riscontro sul dump ingecert del 7 ottobre 2026**, staging aperto in sola lettura:

| Stato della verifica nel dump | Numero di record |
|---|---:|
| assegnata | 81 |
| programmata | 71 |
| registrata | 7 |
| Totale nei tre stati sopra | 159 |
| effettuata, con riesame fatto = F | 3 |

Questi conteggi descrivono il backup, non una lettura del sistema live né un perimetro definitivo delle pratiche da trasferire. La prova deve comprendere anche i documenti già caricati e ancora da riesaminare, non soltanto i lavori da eseguire.

Il risultato della prova servirà a decidere il perimetro effettivo: continuità degli identificativi, degli stati e delle relazioni, disponibilità dei documenti necessari e ripresa del lavoro senza creare una seconda pratica. Al passaggio ogni incarico avrà un solo sistema operativo di riferimento. Non si fissa ancora una data e non si modificano dati in produzione.

Gli originali S3 rimangono differiti come richiesto dall’utente: i conteggi e i riferimenti documentali non attestano che i relativi file siano stati recuperati.

Riferimento: staging `ingecert.sqlite`, tabella `verifiche`, campi `stato_verifica`, `riesame_fatto`, `riesame_esito`.

### 28.18 Verifica straordinaria: preventivo distinto e verbale VS

**Decisione acquisita:** la verifica straordinaria viene preventivata a parte e produce un verbale VS anziché VP. Nel caso discusso, il ricontrollo dopo sistemazione dell’impianto costituisce quindi una nuova prestazione, con preventivo e incarico propri. Si conserva il normale percorso di accettazione scritta, riesame dell’offerta e affidamento. Il RV negativo rimane un caso diverso: ritorno a registrata sullo stesso incarico, correzione/ripetizione, nuova finalizzazione e nuovo RV.

**Riscontro nel codice ingecert:** `cust/meta/preventivi_righe.js` contiene già il tipo obbligatorio VP/VS. Le condizioni per generare una verifica richiedono riga accettata, tariffa applicata e riesame preventivo conforme; `cust/_custom.php`, `gi_verifiche_change_after`, costruisce il codice con il tipo della verifica come prefisso. La distinzione fra periodica e straordinaria non richiede quindi di inventare una nuova entità o un flusso separato. La richiesta aziendale di un preventivo distinto è ora confermata dall’utente; il solo enum nel codice non avrebbe dimostrato tale prassi.

**Da conservare:** tipo VP/VS, collegamento alla prestazione preventivata, normale ciclo di incarico e progressivo unico annuale. Il significato di «sezionale» è stato chiarito dall’utente: cambia soltanto il prefisso, come indicato sotto. È confermato anche che la VS non ricalcola automaticamente la scadenza periodica, mantenendo la logica Garda.

### 28.19 Numerazione VP/VS: logica Garda confermata

Il sorgente ingecert assegna il numero tramite `gi_next_number_get($conn, 'VPVS'.$anno)`: **un unico progressivo annuale condiviso fra VP e VS**, con codice `tipo/numero/anno`. Il prototipo AD 0.7.1 usa anch’esso un progressivo annuale comune. Si tratta di un riscontro sul comportamento implementato, non di una richiesta di modifica.

**Decisione acquisita:** l’utente conferma che la numerazione delle verifiche DPR 462 è unica su base annua; cambia soltanto il prefisso, VP per la verifica periodica e VS per la straordinaria. Si mantiene quindi il criterio già presente in ingecert, senza contatori distinti e senza una nuova logica di numerazione. Il chiarimento chiude l’ambiguità precedente.

Riferimenti: ingecert `cust/_custom.php`, `gi_verifiche_change_after`; prototipo `gestionale/moduli/verifiche/servizio.py`, `numero_successivo` e `codice_verbale`.

### 28.20 Metodo ribadito: confronto con Garda per ogni decisione

Per ciascun requisito concordato si documentano il riscontro in ingecert, adsrl o iec pertinente, la funzione da mantenere e la carenza concreta da migliorare. Se il riscontro non è disponibile o non è concluso lo si dichiara, senza presentare il requisito come una funzione nuova. Non si modificano logiche, entità o relazioni senza prima discuterne con l’utente, come già stabilito in R32.

L’esame del sorgente prova la presenza e le condizioni della funzione; il collaudo dimostra il suo funzionamento nel nuovo sistema. Non si attribuisce al codice una prassi aziendale o una validità normativa che richiedano una conferma distinta.

### 28.21 D08: primo riscontro documentale sugli sconti nelle procedure pubbliche

Il [comunicato del Presidente ANAC del 28 ottobre 2020](https://www.anticorruzione.it/documents/91439/121138/Comunicato%2Bdel%2BPresidentedel28_10_2020.pdf/cab40753-7516-c694-6e25-0a2ceb5eb84c?t=1608645132100), relativo all’articolo 7-bis del DPR 462/2001 e al tariffario ISPESL, interpreta le tariffe come riferimento per gli affidamenti pubblici e contempla ribassi in gara o sconti negli affidamenti diretti. Questo riscontro sostiene la prassi indicata dall’utente per le gare PA; non viene esteso automaticamente agli incarichi privati.

La verifica delle condizioni attualmente applicabili rimane aperta: non si dichiara concluso l’esame normativo e non si attiva alcun automatismo di deroga. È stato individuato anche un successivo parere ANAC del 15 novembre 2021, ma la pagina non è risultata consultabile; il suo contenuto non viene assunto come verificato.

### 28.22 Scadenza periodica dopo VS: regola Garda confermata

**Riscontro ingecert:** `cust/_custom.php`, `ricalcola_scadenze_impianto`, seleziona l’ultima verifica effettuata di tipo VP e ne usa `data_prox_verifica` per aggiornare la scadenza dell’impianto. La VS non è selezionata come fonte automatica del nuovo ciclo periodico. Questo descrive la logica del codice esaminato, non una prescrizione normativa né una conferma della prassi per ogni caso particolare.

**Decisione acquisita:** l’utente conferma che la straordinaria non determina automaticamente la periodicità e chiede di mantenere la regola esistente. La finalizzazione di una VS non avvia quindi un nuovo ciclo periodico e non sposta automaticamente la scadenza derivata dalla VP. Si conserva il comportamento Garda esaminato, senza introdurre un nuovo automatismo.

### 28.23 Dismissione con incarichi aperti: chiusura manuale confermata

**Riscontro ingecert:** `cust/meta/impianti.js` prevede già il flag booleano `dismessa`. In `cust/meta/scadenze.js` la creazione del preventivo da scadenza richiede `dismessa='F'`; in `cust/meta/preventivi_righe.js` la generazione della verifica richiede anch’essa impianto non dismesso. In `cust/_custom.php`, `gi_impianti_change_after` richiama il ricalcolo delle scadenze, senza una transizione esplicita di annullamento delle verifiche già aperte. Nel codice esaminato non risulta dunque una chiusura automatica degli incarichi aperti alla dismissione. Non si dichiara che il flag elimini tutte le righe di scadenza o impedisca ogni possibile azione del sistema.

**Decisione acquisita:** l’utente conferma che gli incarichi già aperti su un impianto segnato dismesso rimangono da chiudere manualmente. Non si introduce un annullamento automatico alla modifica del flag. Si mantengono distinti stato dell’impianto e stato dell’incarico; un eventuale sopralluogo a vuoto già svolto può essere valutato nel normale trattamento economico manuale concordato, senza addebiti automatici.

### 28.24 Accettazione parziale del preventivo: funzione Garda confermata

**Riscontro ingecert:** `cust/meta/preventivi_righe.js` prevede lo stato delle singole righe, inclusi accettata/rifiutata/da_accettare. In `cust/_custom.php`, `gi_preventivo_stato_update`, il riepilogo diventa `accettato_parzialmente` se alcune righe sono accettate e non tutte. La condizione per generare la verifica richiede la riga accettata e il riesame preventivo conforme. Quindi l’accettazione parziale è già prevista nel modello Garda; non richiede una nuova entità.

**Decisione acquisita:** l’utente conferma pienamente l’accettazione parziale. Si mantiene lo stesso preventivo, registrando quali righe sono accettate e procedendo soltanto su quelle dopo il riesame. Le altre righe non autorizzano l’affidamento. Restano ferme l’evidenza scritta di accettazione e l’immutabilità del contenuto commerciale accettato: accettare un’altra prestazione già offerta è distinto dall’aggiungere una prestazione nuova, che richiede un preventivo integrativo.

### 28.25 Portata del RC: intera offerta invariata

**Riscontro ingecert:** il riesame è memorizzato sulla testata del preventivo (`cust/meta/preventivi.js`). La vista delle righe (`cust/gi_views.php`) espone `p.riesame_fatto` e `p.riesame_esito` come dati del RC usati per generare la verifica. `gi_preventivi_righe_change_after` aggiorna importi, riepilogo e scadenze, senza un azzeramento esplicito del RC alla successiva accettazione di un’altra riga. Nel percorso esaminato, una riga già offerta e accettata in seguito può quindi usare il RC conforme ancora registrato sulla testata; non si assume da questo riscontro che tale comportamento coincida con l’ambito effettivamente valutato dal responsabile.

**Decisione acquisita:** l’utente precisa che il caso non è mai capitato e, per semplicità, sceglie che il riesame copra tutta l’offerta invariata. Nell’esempio, la successiva accettazione del terzo impianto già incluso nel preventivo non richiede di ripetere il RC. La riga non accettata non autorizza comunque l’affidamento; alla successiva accettazione scritta può essere utilizzato il RC conforme valido dell’offerta. La regola non copre l’aggiunta di una prestazione nuova o una modifica del contenuto commerciale accettato, per cui rimane il preventivo integrativo con relativo RC.

**Da conservare in Garda:** RC sulla testata e accettazione per riga. **Da migliorare nel prototipo:** consentire la generazione dell’incarico per una riga già offerta e accettata successivamente, senza richiedere un nuovo RC come espediente tecnico e senza duplicare incarichi. Nessun riesame separato per riga.

### 28.26 Incassi: manuali nel primo rilascio, import estratti conto necessario e successivo

**Riscontro ingecert:** `cust/meta/pagamenti.js` prevede gestione delle righe di pagamento, scadenza/importo, entrata/uscita, riferimento e saldato. `cust/_doc_fiscali_common.php`, `fw_doc_calcola_iva_totali`, legge i termini di pagamento e le rate, conserva i movimenti saldati e ricalcola le quote ancora dovute. La gestione di rate e residui è quindi già implementata nel percorso esaminato, benché non sia stato collaudato qui l’intero ciclo in esecuzione.

Nel codice personalizzato esaminato non è stato individuato un import dedicato degli estratti conto o un collegamento automatico alla banca. Il commento sulla riconciliazione nel generatore XML riguarda un campo FatturaPA, non dimostra una funzione di abbinamento bancario.

**Decisione acquisita:** l’utente conferma la registrazione manuale degli incassi nel primo AD_dpr, con associazione alle fatture e controllo dei residui. L’import degli estratti conto è rinviato a un modulo **necessario**, da sviluppare successivamente: non è eliminato dal progetto né classificato come funzione facoltativa. Non si decide in questa risposta se il futuro modulo userà file, collegamenti bancari o altre modalità, né se tutti gli abbinamenti saranno automatici. Restano già acquisiti il pagamento unico associabile a più fatture e il requisito di fatturazione e incassi completi nel primo rilascio.

### 28.27 Punto del questionario e perimetro di approfondimento proposto

L’utente chiede a che punto sia il totale delle domande e se approfondire tutte le questioni DM/I&C o soltanto il DPR. Il registro D01–D14 è un elenco di **aree decisionali**, non un questionario con un numero iniziale fisso di domande. Non si assegna quindi una percentuale numerica di completamento priva di una base di conteggio e non si confonde il consolidamento dei requisiti con l’avanzamento del codice.

**Già consolidato per il primo DPR:** soggetti e intestazioni, conservazione degli emessi, accettazione e integrativi, RC e accettazione parziale, stati dell’incarico, VP/VS e scadenze, dismissione, RV con nota e storico, invio dopo RV, fatturazione completa con intestatario terzo, canale XML/Aruba, esiti e scarti, incassi e pagamenti su più fatture. Alcuni dettagli e collaudi restano necessari: «consolidato» non significa modulo già implementato.

**Raccomandazione di lavoro:** chiudere il DPR operativo. Per DM/I&C verificare adesso soltanto le strutture comuni che incidono sul nucleo: società emittenti, clienti/sedi, identità e distinzione dei beni, prestazioni e scadenze, separazione di serie/ambiti, collegamenti a documenti e dati economici. Conservare le funzioni Garda esistenti; ogni modifica sostanziale resta da discutere prima. Tariffari, maschere e flussi dettagliati DM/I&C saranno approfonditi prima dei rispettivi moduli, dopo la validazione nell’uso del DPR.

**Tre blocchi residui da esaminare per chiudere la specifica iniziale**, senza trasformare ogni verifica tecnica in una domanda all’utente:

1. Confine dei dati tecnici fra nucleo e VerbalizzAI e aggiornamento del dato corrente, conservando gli emessi.
2. Prerequisiti sostanziali dell’affidamento, comprese qualifiche e indipendenza, partendo dai controlli già presenti nei sorgenti; non riaprire le scelte già affidate a ruoli e permessi.
3. Chiusura del censimento economico, soprattutto rettifiche/acconti e recupero degli esiti, chiedendo soltanto la prassi non desumibile dal codice.

Il mapping, i vincoli, la concorrenza, le prove di importazione e le scelte tecniche devono essere svolti dall’analisi e dall’implementazione, con proposte concrete quando incidono su una decisione dell’utente. Cutover, originali S3 e dettagli di esercizio restano necessari prima della produzione pertinente, ma non diventano un questionario completo su DM/I&C prima di iniziare l’ossatura DPR.

L’utente ha successivamente confermato questo perimetro di lavoro (R60): DPR operativo e verifica strutturale del nucleo per DM/I&C. Non equivale ad approvare puntualmente le proposte tecniche ancora aperte. Il risultato del giro finale sarà una sintesi breve delle decisioni, del modello concettuale e dei casi di accettazione da riesaminare prima del codice.

### 28.28 Primo dei tre blocchi finali: aggiornamento delle caratteristiche tecniche

**Riscontro ingecert:** la scheda verifica espone dati dell’impianto, fra cui potenza e numero di cabine, tramite campi di lettura `imp_*` (`cust/meta/verifiche.js`). Il ricalcolo esaminato in `cust/_custom.php`, `ricalcola_scadenze_impianto`, aggiorna sull’impianto i riferimenti e le date dell’ultima/prossima VP. Non è stato individuato in questo percorso un aggiornamento delle caratteristiche tecniche estratto dal contenuto del PDF del verbale. Questo riscontro è circoscritto al percorso esaminato, non dichiara assente ogni possibilità di modifica manuale dell’impianto.

**Riuso VerbalizzAI 0.3.32.3:** `plantstate.py` seleziona esplicitamente lo stato riutilizzabile, inclusi potenza, tensione, POD e cabine per M01; esclude misure ed esiti della singola verifica. La finalizzazione offre già «Aggiorna la scheda impianto» oppure «Conserva la scheda impianto» (`static/app.js`). `storage.py`, `Archive.issue`, applica l’aggiornamento scelto all’emissione, con controllo della versione e della data dello stato; il default prudente in `finalization.publish_default` non aggiorna automaticamente nelle revisioni o se lo stato corrente è più recente. Non occorre inventare un nuovo flusso di approvazione per questa scelta.

**Riscontro prototipo 0.7.1:** `gestionale/moduli/verbali/servizio.py`, `dopo_emissione`, usa i dati strutturati del verbale e richiama `verifiche.carica_verbale`; `aggiorna_impianto` registra caratteristiche tecniche ed elementi sulla scheda del gestionale. È una base riusabile, ma il ponte esaminato richiama l’aggiornamento senza subordinare le caratteristiche alla scelta VerbalizzAI di conservare lo stato: questa coerenza deve essere realizzata prima dell’integrazione. La prova non è già stata eseguita.

**Proposta iniziale superata dal chiarimento R61:** la scelta esistente «Aggiorna»/«Conserva» era stata proposta come comportamento da mantenere. L’utente chiarisce il criterio aziendale: la scheda corrente segue le modifiche rilevate e il nuovo verbale ripropone la situazione fotografata nell’ultimo. Vedere 28.29 e 28.30. Mapping e controlli di coerenza rimangono responsabilità tecnica; la scelta «Conserva» non deve lasciare ordinariamente una scheda superata dopo una nuova fotografia corrente dell’impianto.

**Correzione tecnica già necessaria in base a R55:** il prototipo `carica_verbale` calcola una prossima verifica dalla data e periodicità e richiama `aggiorna_impianto` senza un’esclusione esplicita delle VS nel percorso esaminato. Il ponte dovrà conservare la scadenza periodica quando finalizza una VS, invece di riusare questo automatismo. È l’applicazione di una regola già concordata, non un nuovo quesito all’utente.

### 28.29 La scheda corrente segue l’impianto rilevato

**Chiarimento acquisito R61:** l’utente richiede che, se cambia l’impianto, cambi anche la scheda tecnica corrente, citando potenza, sistema di alimentazione ed elenco dei differenziali. Non si conserva quindi una scheda precedente come rappresentazione corrente di un impianto effettivamente modificato. Rimane la regola già acquisita di conservare le fotografie dei verbali emessi.

**Riscontro VerbalizzAI:** `plantstate.py` include potenza e tensione, gruppi `systems` e `supply` e definizioni degli elementi `samples` tramite `asset_definition`. Per gli elementi conserva ID, tipo, quadro, nome, occorrenza e caratteristiche, escludendo i risultati della prova. `storage.py`, `_set_profile`, aggiorna gli elementi identificati e rimuove dal profilo quelli esplicitamente ritirati; conserva inoltre gli elementi già noti non presenti nel campione. La validazione ammette `rcd`, `overcurrent` e `continuity`. Questa è una base già esistente per aggiornare anche i differenziali senza mescolare il censimento con i risultati delle singole prove.

**Limite tecnico da mantenere:** un differenziale non incluso nel campione di prova non è automaticamente eliminato dal censimento. Sostituzioni e ritiri devono seguire le evidenze e la gestione esplicita degli elementi già presente, evitando di trattare ogni elenco campionato come inventario completo. La data dello stato e la revisione del profilo proteggono inoltre da aggiornamenti basati su informazioni più vecchie.

**Regola ora confermata con il successivo chiarimento:** scheda corrente coerente con l’ultima fotografia e nuova bozza che ripropone quella situazione. Alla finalizzazione il ponte deve allineare i dati riutilizzabili senza un’approvazione separata. Revisioni di vecchi verbali e import storici non devono riportare la scheda a uno stato superato; un aggiornamento concorrente più recente va preservato o risolto esplicitamente. Questi controlli attuano il criterio aziendale, senza aggiungere un nuovo stato operativo.

**Casi di collaudo futuri:** variazione di potenza/alimentazione con aggiornamento della scheda e verbale precedente invariato; differenziale sostituito con nuova definizione e ritiro esplicito del precedente, conservandone lo storico; differenziale non campionato ancora censito; revisione di un vecchio verbale senza regressione dello stato corrente. Aggiornare le caratteristiche durante una VS resta distinto dal ricalcolo della scadenza periodica, che non deve essere spostata automaticamente.

### 28.30 Primo blocco chiuso: fotografie storiche e riuso dell’ultima situazione

L’utente precisa che l’importante è preservare lo stato storico degli impianti nei verbali emessi, mentre il nuovo deve riproporre la situazione fotografata nell’ultimo. Si acquisisce il comportamento come R61, senza un ulteriore quesito sul medesimo criterio.

**Effetto sul flusso:** il verbale A conserva la propria fotografia; una successiva verifica B registra potenza, alimentazione ed elementi aggiornati senza riscrivere A; la bozza C riparte dalle caratteristiche riutilizzabili di B. Misure, risultati e conclusioni devono essere raccolti per C, come già previsto da `plantstate.py`. Il riuso è pertinente al modulo: il profilo M02 non sostituisce indiscriminatamente quello M01. «Ultimo» riguarda la situazione tecnica più recente, non il solo ordine di caricamento di un file storico. Non si costruisce una nuova tabella autonoma di storia dell’anagrafica per realizzare questa regola: si riusano fotografie dei verbali, profili ed eventi esistenti.

Il primo dei tre blocchi finali è chiuso sul criterio aziendale. Mapping, conservazione degli ID degli elementi, trattamento del campionamento e controlli su date/revisioni rimangono da implementare e collaudare. I casi tecnici già elencati non sono test eseguiti.

**Primo riscontro per il secondo blocco:** ingecert `cust/meta/verifiche.js` collega il tecnico agli utenti tramite alias `tecnici` e prevede un tecnico in affiancamento. La dichiarazione personale `dichiaro_che` è già richiesta per programmare, registrare o effettuare la verifica (`gi_verifiche_save_before`); il metadato la propone però con default T. Nei campi e nel percorso di assegnazione esaminati non è stata individuata una matrice strutturata delle qualifiche BT/MT/ATEX applicata all’incarico. Questa verifica mirata non esclude procedure esterne o altri controlli del framework. La successiva R62 esclude un filtro dedicato delle qualifiche nel primo rilascio; ruoli e permessi restano configurabili come già concordato.

### 28.31 Assegnazione semplice con quattro tecnici abilitati

**Decisione acquisita R62:** l’utente considera superfluo il filtro proposto, perché i tecnici abilitati sono soltanto quattro. Nel primo AD_dpr non si realizza una matrice delle abilitazioni né un filtro specifico per prestazione. L’operatore autorizzato sceglie il tecnico nell’incarico. Non si trasforma la gestione delle qualifiche in un nuovo modulo o prerequisito per iniziare il codice.

La decisione esclude l’automatismo applicativo, non dichiara che tutti i tecnici abbiano necessariamente le medesime qualifiche né modifica le procedure aziendali di affidamento. Restano RC conforme prima dell’incarico, ruoli e permessi configurabili e il tecnico in affiancamento già previsto in Garda.

**Proposta successivamente superata da R63:** era stata proposta una spunta non preselezionata con conferma personale. L’utente mantiene invece il default preselezionato, escludibile dal tecnico, e il blocco operativo quando escluso. Vedere 28.32. Nessun nuovo iter di approvazione dell’assegnazione.

### 28.32 Indipendenza: comportamento Garda confermato

**Decisione acquisita R63:** l’utente conferma la casella preselezionata ed escludibile. Se viene esclusa, la verifica non può essere svolta da quel tecnico. Si conserva il comportamento esistente, senza imporre una nuova spunta obbligatoria inizialmente vuota.

**Riscontro ingecert:** `cust/meta/verifiche.js`, campo `dichiaro_che`, imposta default T e descrive l’assenza di conflitti reali o potenziali. `cust/_custom.php`, `gi_verifiche_save_before`, impedisce il salvataggio negli stati programmata, registrata o effettuata quando il valore è F. Il futuro servizio deve conservare il vincolo anche per richieste dirette, non soltanto nella maschera. L’esclusione non è un ordine automatico di cancellare l’incarico o assegnarlo a un altro tecnico.

**Tracciabilità tecnica:** conservare il valore relativo all’incarico, il tecnico pertinente e autore/momento delle modifiche. Un default inserito dal sistema non si descrive come azione personale eseguita dal tecnico. In caso di riassegnazione, preservare la precedente esclusione nello storico e verificare la condizione del nuovo assegnatario secondo il normale flusso, senza riutilizzare la dichiarazione personale del precedente.

**Caso di collaudo futuro:** incarico assegnato con casella preselezionata; tecnico che la esclude; tentativo di avanzamento respinto senza perdere l’incarico e con modifica tracciata. Il criterio del secondo blocco è chiuso; implementazione e prova rimangono da eseguire.

### 28.33 Terzo blocco: primo riscontro sulle note di credito

Il codice ingecert `_doc_fiscali_common.php` contiene già il tipo TD04, percorsi documentali e di pagamento dedicati e il collegamento alla fattura originaria. `gi_fatture_clienti_save_after`, copiando una TD01 verso una TD04, aggiunge un riferimento `FattureCollegate` con numero e data della fattura e copia le righe. `fw_fattura_cliente_righe_change_after` segnala con un warning la mancanza di un riferimento per TD04: questo non è un vincolo bloccante nel percorso esaminato. Sono funzioni da preservare e collaudare, non un nuovo modulo da inventare.

La presenza di questi percorsi non chiarisce da sola la prassi aziendale. La successiva R64 conferma l’uso delle note di credito anche parziali; resta da consolidare il trattamento concreto dei documenti già incassati e dei residui. Le rettifiche non si confondono con la correzione di una fattura scartata e la rigenerazione XML già discusse.

### 28.34 Note di credito anche parziali

**Decisione acquisita R64:** l’utente conferma che vengono emesse anche note di credito parziali, non soltanto per l’intero importo della fattura. Il primo AD_dpr deve conservarne la gestione e il riferimento alla fattura originaria, con importi e righe pertinenti. Il documento originario e gli incassi effettivamente registrati non vengono riscritti come se la rettifica fosse già esistita.

**Riscontro economico Garda:** `_doc_fiscali_common.php`, `fw_doc_calcola_iva_totali`, attribuisce tipo_pagamento U alle rate di un documento TD04 ed E alle fatture ordinarie. Durante il ricalcolo cancella i pagamenti non saldati e rilegge quelli saldati. `cust/meta/pagamenti.js` conserva collegamento a fattura_cliente, entrata/uscita, scadenza, saldato e note. Questi riscontri provano percorsi di gestione distinti, non una compensazione automatica collaudata fra una fattura e la sua nota di credito.

**Chiarimento successivo R66:** l’utente indica che nella prassi la fattura non è ancora stata pagata. Rimborso o compensazione di una somma già incassata non costituiscono il caso ordinario da sviluppare come procedura dedicata ora. Il caso futuro di incasso precedente alla rettifica resta una verifica tecnica di coerenza economica, senza attribuire all’utente una policy di rimborso o un divieto di emissione.

**Casi di collaudo futuri:** fattura da 1.000 con nota di credito parziale da 200, senza incasso; storno totale. Verificare saldo economico, collegamenti, movimenti effettivi e importi dei documenti. R66 chiarisce il caso ordinario: credito netto residuo 800, senza inventare un incasso o rimborso. La stessa rettifica dopo un incasso rimane un caso di coerenza da provare, ma non richiede ora una procedura dedicata o una nuova domanda su una prassi non presente.

### 28.35 Emissione diretta con righe personalizzate

**Decisione acquisita R65:** fattura e nota di credito possono essere emesse anche «in bianco», compilando righe personalizzate, senza associazione obbligatoria a verbali esistenti. Il caso è raro, ma rientra nella fatturazione completa richiesta per il primo AD_dpr.

**Riscontro ingecert:** `cust/meta/fatture_clienti.js` prevede l’azione new autorizzata dal permesso `new_fatture_clienti`. `cust/meta/fatture_clienti_righe.js` prevede creazione e modifica delle righe e i tipi RG normale, TX nota libera e AC spesa accessoria. Descrizione, quantità, prezzo e codice IVA sono gestiti come campi della riga; i riferimenti preventivo e verifica sono readonly e non dichiarati required. `_doc_fiscali_common.php`, `gi_fatture_clienti_righe_save_before`, richiama il normale calcolo delle righe e dei totali, senza un requisito generale di verifica associata nel percorso esaminato. La funzione non deve quindi essere ricreata come una nuova procedura operativa.

**Implicazione del modello:** il documento fiscale e le sue righe devono poter esistere autonomamente; il collegamento alla prestazione o verifica è facoltativo per una riga libera e presente per una riga generata dall’attività. I riferimenti della nota di credito alla fattura rettificata sono distinti dai collegamenti a verbali e verifiche e rimangono nel normale percorso documentale. Anche il documento libero conserva emittente, intestatario fiscale, serie e numero, importi, file/XML, esiti e movimenti economici.

Non occorre creare un incarico fittizio né dichiarare una verifica eseguita per emettere una fattura libera. Per la fatturazione derivata da una verifica rimangono i prerequisiti già concordati. Le due modalità usano lo stesso ciclo economico e i normali permessi, senza un nuovo workflow o un modulo separato.

**Casi di collaudo futuri:** creazione di fattura con una riga economica personalizzata senza verifica, XML e gestione incasso; nota di credito parziale con descrizione libera e riferimenti fiscali pertinenti; riga TX testuale senza effetto sugli importi. Verificare che queste operazioni non creino o modifichino incarichi e scadenze tecniche.

### 28.36 Nota di credito prima del pagamento e chiusura dei casi economici

**Chiarimento acquisito R66:** alla domanda su rimborso o compensazione dopo il pagamento, l’utente risponde che in teoria non si pone il caso, perché la fattura non è stata pagata. Si registra la prassi e non si apre un workflow di rimborso soltanto per l’ipotesi discussa. Non si presume impossibile qualsiasi caso futuro di incasso precedente alla rettifica.

**Caso ordinario da ottenere:** fattura da 1.000 ancora non pagata, nota di credito da 200 collegata, credito netto da riscuotere 800. Conservare entrambi i documenti e le loro righe; non rappresentare la nota come un bonifico ricevuto o restituito. L’allocazione della rettifica alle partite economiche e i controlli sui residui sono lavoro tecnico. Si preserva anche la possibilità già acquisita di documento libero R65, distinguendo i riferimenti fiscali dai legami alle verifiche.

**Altri riscontri Garda del terzo blocco:** `cust/meta/fatture_clienti.js` enumera TD02 acconto/anticipo su fattura e TD03 acconto/anticipo su parcella. La presenza del tipo documento non dimostra da sola che un futuro saldo deduca correttamente tutti gli acconti: il collegamento e la quadratura rimangono da progettare e collaudare secondo R43, senza trasformare il raro acconto in un passaggio obbligatorio. Lo stesso metadato contiene `generata_fatt_elettronica`, usato anche nelle condizioni di modifica: è un flag di generazione, non la prova di trasmissione o accettazione SdI.

**Proposta non approvata, modalità rinviata con R67:** era stato proposto un caricamento manuale delle ricevute Aruba e un eventuale collegamento automatico successivo. L’utente non desidera approfondire ora, ma conferma che l’importazione degli esiti è una cosa da fare. Non si seleziona nessuna delle due modalità. Formati esportabili, strumenti disponibili, associazione alla fattura e al tentativo e gestione degli scarti sono da definire e implementare; il requisito rimane necessario e distinto dall’import degli estratti conto rinviato.

### 28.37 Aruba: requisito mantenuto e modalità da approfondire dopo

**Decisione acquisita R67:** non approfondire ora la modalità di recupero degli esiti. Il nuovo sistema dovrà importare gli esiti Aruba e conservarne la traccia. Non trasformare il rinvio della scelta tecnica in una rimozione della funzione o in approvazione del caricamento manuale.

Il confine da predisporre nel nucleo è già chiaro: fattura, contenuto/XML del singolo tentativo, esito e relativa evidenza, correzione e successivo tentativo. Il meccanismo di acquisizione può essere definito separatamente senza riscrivere questo collegamento. Il flag Garda di generazione XML non basta a rappresentare tale storico. Nessuna credenziale Aruba o capacità di integrazione è stata verificata in questa fase.

## 29. Sintesi funzionale per preparare il codice iniziale

Questa sintesi chiude il giro attuale delle domande operative. È sufficiente per preparare una proposta tecnica concreta sul primo AD_dpr; non equivale a uno schema fisico definitivo approvato né a software già realizzato. Prima di cambiare logiche o relazioni Garda, i cambiamenti vengono presentati all’utente, come richiesto.

### 29.1 Primo sistema operativo

Un nucleo comune per AD_dpr, AD_dm e I&C, con attivazione iniziale del DPR completo: clienti/sedi/impianti, scadenze, preventivi e accettazione, RC, incarichi, VerbalizzAI, revisioni/RV, documenti/invii, fatturazione e incassi. Uso online centrale; programmazione distinta per ambito. AD_dm e I&C vengono attivati successivamente dopo la validazione del DPR nell’uso, conservando ora la compatibilità delle strutture comuni. L’approfondimento parallelo 05 prepara i futuri moduli.

### 29.2 Regole del percorso ordinario DPR

| Passaggio | Regola acquisita |
|---|---|
| Intestazione | Datore di lavoro/committente su preventivo e verbale; eventuale intestatario terzo scelto soltanto in fattura. Gli aggiornamenti anagrafici non riscrivono gli emessi. |
| Preventivo | Documento con anteprima PDF, ritocco Word e nuova anteprima come VerbalizzAI. Accettazione scritta, anche per singole righe. Contenuto accettato invariato; prestazioni aggiuntive su preventivo integrativo. |
| RC e incarico | Dopo accettazione, RC obbligatorio e conforme prima dell’affidamento. Il RC copre l’intera offerta invariata. Tecnico scelto dall’operatore autorizzato, senza matrice delle qualifiche nel primo rilascio. |
| Indipendenza | Casella preselezionata come Garda, escludibile; se esclusa quel tecnico non può svolgere la verifica. |
| Esecuzione | Assegnata, eventuale programmata, registrata durante l’attività, eseguita soltanto con verbale finalizzato e caricato. Sospesa con ripresa sullo stesso incarico e conservazione del numero già assegnato. |
| Numerazione e scadenza | Progressivo annuale unico VP/VS. Straordinaria su preventivo/incarico distinto; una VS non sposta automaticamente la scadenza periodica. Dismissione senza annullamento automatico degli incarichi aperti. |
| Dato tecnico | Ogni verbale conserva la fotografia storica; la nuova bozza riparte dalle caratteristiche e dagli elementi dell’ultima situazione pertinente. Misure ed esiti sono propri della nuova verifica. |
| RV | Negativo: ritorno a registrata, nota RT visibile, correzione/ripetizione, nuova finalizzazione e nuovo RV. Conservare lo storico legato alle versioni esaminate. |
| Invio | Primo DPR con invio dopo RV conforme. Rilascio immediato rinviato. |

### 29.3 Ciclo economico del primo DPR

Conservare la fatturazione da riga preventivo, anche associando più prestazioni compatibili a una fattura esistente. Prevedere anche fatture e note di credito con righe personalizzate senza collegamento obbligatorio ai verbali. Note di credito totali e parziali; nella prassi ordinaria la rettifica riguarda una fattura non pagata e riduce il credito residuo. Acconti possibili ma non obbligatori, da collegare al saldo e distinguere dagli incassi.

Incassi manuali, quote attribuibili a una o più fatture, residui coerenti. L’import degli estratti conto è un modulo necessario successivo. FatturaPA generata nel nucleo, XML scaricato e caricato manualmente in Aruba; recupero degli esiti necessario ma modalità da definire secondo R67. Conservare le versioni effettive dei tentativi, gli scarti e le correzioni.

AD e I&C S.r.l. conservano società emittenti e documenti fiscali distinti. DM ed EX restano separati per preventivi e fatture. Le altre aggregazioni fra ambiti non sono automaticamente approvate. I tariffari e la validità delle deroghe devono essere verificati sulle fonti pertinenti; ATEX segue il prezzo preventivato, senza variazione a consuntivo.

### 29.4 Modello concettuale da tradurre in uno schema concreto

Si riusa la struttura di concetti della sezione 22.2; i nomi seguenti sono responsabilità logiche, non nuovi nomi di tabelle già approvati.

| Concetto | Relazione da preservare |
|---|---|
| Società, soggetto e sede | Identità, riferimenti sorgente e condizioni pertinenti; intestazioni storiche nei documenti. |
| Bene ed elementi | Impianto DPR, attrezzatura DM e valvola distinti; elementi tecnici censiti e collegamenti correnti, senza confondere inventario e campione. |
| Preventivo e righe | Versione commerciale e prestazioni accettate; compatibilità futura con punti/sottopunti e prezzi a corpo I&C. |
| Incarico/verifica | Prestazione autorizzata, bene, tecnico, stato e numero; flussi specifici per modulo. |
| Verbale e stato tecnico | Fotografia emessa, revisioni e caratteristiche correnti riutilizzabili per modulo. |
| Riesame | RC riferito all’offerta e RV riferito alla versione del verbale; autore, esito, nota e momento. |
| Documento fiscale e righe | Righe generate o libere; emittente, intestatario, serie, numeri, importi e riferimenti documentali. |
| Movimenti e attribuzioni | Incassi effettivi, quote su fatture e rettifiche; totali e residui senza doppio conteggio. |
| File, generazioni ed eventi | Word/PDF, documento ufficiale, invii, XML/tentativi/esiti, contenuti e tracciabilità. |

Prima della traduzione fisica verificare il caso condiviso GVR, CND I&C e valvola tarata già descritto nell’approfondimento 05. Una sola identità del bene non implica fatture comuni fra società. Il filtro delle qualifiche e lo storico autonomo dei montaggi non vanno reintrodotti nello schema per inerzia.

### 29.5 Lavoro tecnico successivo e prove minime

Preparare una proposta di schema e di riuso della 0.7.1 con confronto alle fonti Garda. Distinguere tabelle da conservare, adattamenti necessari, funzioni nuove richieste e dettagli rinviati. La proposta deve risolvere importi esatti, FK, ID canonici stabili, import incrementale, versioni documentali e confine dell’adattatore VerbalizzAI. Python/FastAPI, SQLAlchemy/Alembic e HTML/JS rimangono candidati discussi; database e confini del riuso vanno motivati prima di presentarli come scelta definitiva.

I casi minimi di accettazione includono: accettazione parziale e RC sull’offerta invariata; VP/VS concorrenti con progressivo unico e VS senza spostamento della periodicità; sospensione/ripresa; aggiornamento tecnico con verbali precedenti invariati; RV negativo e nuovo RV con storico; fattura a terzo, fattura libera e nota di credito parziale; pagamento ripartito e acconto/saldo senza doppio conteggio; nuova importazione che conserva ID e lavoro successivo; backup/ripristino coerente di dati e documenti. Sono prove da eseguire, non risultati già ottenuti.

Restano verifiche necessarie di esercizio e produzione: acquisizione esiti Aruba e relative evidenze, allegati richiesti dalle pratiche, disponibilità degli originali S3, prova d’importazione degli incarichi aperti, continuità delle serie/numeri, hosting e ripristino. La loro definizione può procedere nelle fasi pertinenti; non richiede ora un nuovo questionario completo su DM e I&C. I dettagli di nomi file, destinazioni di download e maschere restano nel registro dei dettagli rinviati.


## 30. Avvio del codice — candidatura Gestionale_AD 0.8.0

### 30.1 Nuove istruzioni e perimetro effettivo

L’utente richiede di implementare AD_dpr a partire da VerbalizzAI e dal tentativo Python Gestionale_AD, usando Garda come base logica e fonte dei dati, senza modificare/adattare il PHP (R68). Precisa che sviluppo e primi test si svolgeranno in locale Windows (R69). È stata quindi preparata una candidatura eseguibile 0.8.0, separata dagli originali, per iniziare il collaudo di quel perimetro. Non è stata messa in produzione e non è ancora il gestionale completo delle tre attività.

Stack usato concretamente: Python/FastAPI, SQLAlchemy/Alembic, SQLite, HTML/JavaScript e LibreOffice. Si mantiene il server locale con un solo processo. PostgreSQL, più processi e hosting pubblico non sono già disponibili o collaudati. Il nucleo economico distingue società emittente e ambito; i moduli DM/EX/I&C, il modello comune definitivo dei beni e i permessi per ambito rimangono lavoro successivo.

### 30.2 Componenti e regole implementati

| Componente | Stato della candidatura e rapporto ai requisiti |
|---|---|
| Fondamenta e anagrafiche | Riusate dal prototipo 0.7.1: accesso/ruoli/permessi, clienti/sedi/impianti, tariffario, griglie, registro, documenti, backup e import iniziale Garda. Non è una conversione del PHP. |
| VerbalizzAI | Modulo incorporato aggiornato alla 0.3.32.3; IDs e anagrafica del gestionale. Il suo archivio fisico resta distinto, come precisato sotto. |
| Preventivi | Fotografia del contenuto e dell’intestatario alla prima trasmissione dei nuovi documenti; conservazione Word/PDF, anteprima LibreOffice e correzione Word già presenti. Accettazione con riferimento scritto richiesto; ulteriore accettazione di righe nell’offerta invariata dopo RC conforme genera gli incarichi mancanti senza duplicarli. R33/R38/R57/R58. |
| Esecuzione | Sospensione e ripresa sullo stesso incarico/numero. Indipendenza preselezionata, modifiche tracciate e blocchi di registrazione/emissione per il tecnico che la esclude. R41/R63. Il default di migrazione non è prova di una dichiarazione personale storica. |
| Stato tecnico e VS | Caratteristiche riutilizzabili distinte dai risultati della nuova verifica; tutela del dato più recente e del censimento non interamente provato. La VS aggiorna la situazione tecnica pertinente ma non la scadenza periodica. R55/R61. |
| RV e invio | Storico con nota, autore, momento e riferimento al documento; RV negativo riporta a registrata. Il percorso di invio incorporato richiede RV conforme sullo stesso PDF esaminato. R50/R51/R52. |
| Nucleo economico | Società, fatture/righe/scadenze, XML/tentativi/esiti, incassi e attribuzioni; FK, importi in centesimi, decimali esatti e controllo della versione. TD01/TD02/TD04, righe personalizzate o da preventivo, più prestazioni sul documento e intestatario terzo scelto in fattura. R31/R43/R64/R65. |
| Rettifiche/incassi | Note totali/parziali riducono il credito non incassato; un pagamento ripartibile fra più fatture compatibili; revisione delle attribuzioni e storno tracciato. La procedura per rettificare somme già incassate non è ancora disponibile e non viene attribuita all’utente come divieto assoluto. R46/R66. |
| Scarti ed esiti | Tentativi XML immutabili, ricevuta identificata, scarto/correzione/nuovo tentativo con numero preservato. Disponibile il contratto interno di registrazione, non un’importazione reale da Aruba. R47/R67 resta da completare. |

La conservazione degli emessi vale per le nuove fotografie prodotte dalla candidatura. Per i documenti storici senza quella fotografia si conservano le evidenze effettive disponibili: non si ricostruisce un’identità passata prendendola dall’anagrafica odierna. Il riferimento testuale richiesto nell’accettazione non archivia da solo l’email o il preventivo controfirmato.

### 30.3 Confine fisico e migrazioni

VerbalizzAI conserva per ora il proprio archivio SQLite, accanto al database relazionale del gestionale. Non è stato realizzato l’adattatore `Archive` sulle future tabelle comuni di asset/verbali. Il percorso di acquisizione dell’emissione è idempotente per documento/impronta e l’API autorizzata di riallineamento recupera emissioni persistite nel modulo ma non ancora acquisite nel nucleo. Questa è una misura di recupero, non una transazione atomica fra i due archivi.

Migrazioni 0009 e 0010: tabelle economiche e storico RV, fotografie dell’offerta, sospensione/indipendenza e riferimento dell’accettazione. Avvio con backup pre-aggiornamento; ricostruzione delle tabelle SQLite in transazione e controllo FK prima del commit. La prova su archivio 0008 popolato ha rilevato e permesso di correggere un blocco della ricostruzione dovuto ai riferimenti dei documenti. Sono state poi provate conservazione dei collegamenti, recupero del RV corrente noto e annullamento completo su errore. Non vengono inventati riesami precedenti o evidenze scritte mancanti.

L’import iniziale Garda della 0.7.1 resta destinato ad archivio vuoto. **ID canonici per tutte le origini, riallineamento incrementale durante la convivenza e importazione economica non sono ancora implementati.** La 0.8.0 non completa lo schema operativo/migrazione incrementale proposti nel vecchio piano. L’adattamento definitivo al nucleo integrato resta necessario prima del cutover.

### 30.4 Verifiche osservate e dati economici

**121 test passati, zero fallimenti e zero test saltati**, in 101,55 secondi su Linux/Python 3.12; un avviso di deprecazione riguarda il client HTTP dei test. Verificati schema/modelli, backup/ripristino, migrazione popolata e rollback, flussi operativi/economici e conversione reale della copia di cortesia PDF con LibreOffice. Molti test isolano le regole con PDF sintetici: non si descrivono come conversioni reali. La suite indipendente completa di VerbalizzAI non è stata rieseguita integralmente o ricontata in questo giro.

Un test del DOM con backend HTTP ha eseguito apertura, creazione bozza/riga, emissione XML, attribuzione incasso e storno. Ha consentito di correggere la preselezione della fattura nella ripartizione e la chiusura della scheda dopo storno. Non equivale a una verifica grafica o a un avvio su Windows. Controlli statici Ruff sui nuovi componenti economici e sui file di supporto: nessun errore.

Audit in sola lettura dello staging ingecert: **473 fatture, 1.123 righe, nessuna riga orfana, una riga negativa**; totale documenti **€385.061,37**, dovuto **€375.480,58**, scadenze **€375.480,58**. Una differenza fra imponibile/IVA/bollo e totale richiede una spiegazione prima dell’import economico, non una correzione automatica del dato. La candidatura non supporta ancora la riga negativa storica. **Zero XML originali confrontati**: i record del dump non provano la regressione sui 473 XML citata nel piano precedente.

Il generatore XML è provato sullo schema locale storico **1.2.2**, reperito nei materiali ingecert; la validazione contro specifiche correnti e i controlli extra-XSD restano da eseguire. Nessuna accettazione SdI o conformità completa ISO/Accredia è attestata da questo collaudo.

### 30.5 Consegna e lavoro successivo

Pacchetto sorgente `Gestionale_AD_v0.8.0_collaudo_Windows_2026-10-09.zip`, con guida `INIZIA_QUI_WINDOWS.md`, avvio `AVVIA_COLLAUDO_WINDOWS.bat`, stato tecnico e risultati delle prove. Archivio di prova distinto, nessun dump privato o credenziale nel pacchetto. Nessuna email inviata, fattura trasmessa o base dati operativa modificata durante le prove.

Prossimo passo pratico: installazione/avvio Windows e giro completo su casi sintetici, poi validazione operativa con casi DPR reali. Restano necessari prima di sostituire ingecert: modello comune definitivo e migrazione incrementale, import contabile quadrato e numeri iniziali, pratiche aperte/documenti, import esiti Aruba, validazione fiscale corrente, firma/invio e ripristino completo nelle condizioni effettive. L’assenza degli originali S3 non blocca questo primo collaudo locale; gli allegati necessari all’esercizio dovranno comunque essere recuperati e verificati nella fase pertinente. DM e I&C saranno attivati dopo la validazione DPR, non sono riaperti come questionario preliminare.

Il requisito del primo AD_dpr completo di fatturazione e incassi non è ridotto: la candidatura rende concreto il lavoro sul percorso end-to-end, mantenendo esplicite le integrazioni non ancora concluse.
