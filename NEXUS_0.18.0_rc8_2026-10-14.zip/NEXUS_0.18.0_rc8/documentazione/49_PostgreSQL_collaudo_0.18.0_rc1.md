# PostgreSQL: preparazione e collaudo della 0.18.0 rc1

Questa è una consegna preliminare. Il server PostgreSQL nativo non è stato avviato nell'ambiente del revisore: UID/GID disponibili solo per root, mappatura verso l'utente del server non consentita. Le 35 prove native incluse restano da eseguire. La compilazione del SQL e le prove SQLite non attestano la riuscita del porting sul server.

## Configurazione

La connessione principale si fornisce tramite `GESTIONALE_DATABASE_URL`, per esempio con schema `postgresql+psycopg://`. Non salvarla in `config.json`, nel codice o nei documenti di consegna. `GESTIONALE_CARTELLA_DATI` continua a indicare documenti, backup e archivio VerbalizzAI; non sostituisce il nome del database PostgreSQL. Nessuna conversione automatica del file `database.sqlite`.

`GESTIONALE_PG_BIN` può indicare la cartella contenente `pg_dump` e `pg_restore`, quando non sono nel PATH. Le utility vanno abbinate alla versione principale del server. Il primo collaudo è predisposto per PostgreSQL 16; sviluppo, collaudo e produzione devono poi essere allineati sulla versione scelta.

SQLite resta disponibile per gli archivi di prova esistenti. I launcher Windows di prova/Garda azzerano la variabile della connessione e gli strumenti storici rifiutano il suo uso: una cartella TEST non deve finire involontariamente sul database principale. Quegli strumenti restano importatori di prova SQLite e non costituiscono l'importazione PostgreSQL completa.

## Schema: scelta implementativa esplicita

PostgreSQL nuovo parte dalla baseline congelata `gestionale/migrazioni/baseline_postgresql_0027.json`: 63 tabelle, 98 FK dichiarate e indici/vincoli derivati dal modello. Il bootstrap rifiuta tabelle già presenti in un database non versionato. Crea anche la protezione SQL da modifiche/cancellazioni del registro e registra Alembic 0027.

Le migrazioni storiche 0001–0027 restano byte per byte quelle ricevute, per SQLite. Non viene dichiarata una loro esecuzione completa su PostgreSQL: contengono trigger/ricostruzioni e aggiornamenti specifici di SQLite. Le future migrazioni, da 0028, seguiranno la baseline PostgreSQL e dovranno essere portabili e collaudate su entrambi i percorsi necessari.

**Non rigenerare la baseline 0027 con i modelli di una versione futura.** È congelata prima della prima apertura PostgreSQL. In questo modo un nuovo database non riceverà due volte le modifiche delle migrazioni successive.

Gli importi interi in centesimi usano BIGINT su PostgreSQL, preservando i 64 bit di SQLite INTEGER. La compilazione del DDL SQLite prima/dopo questa scelta è risultata identica: non serve modificare gli archivi di collaudo SQLite. Si tratta di ampiezza tecnica del tipo, senza nuove formule o regole economiche.

## Transazioni e archivio VerbalizzAI

Il porting conserva la politica del singolo scrittore. Su PostgreSQL la protegge un advisory lock del database, condiviso da processi differenti, in isolamento READ COMMITTED. Numerazioni, controllo versioni e catena del registro rimangono dentro la transazione. Questa scelta favorisce la coerenza; non promette scritture parallele né un nuovo benchmark.

I POST del ponte VerbalizzAI e le relative callback sono eseguiti nello stesso thread sotto il medesimo gate di manutenzione. Il backup non si inserisce fra operazione del generatore e callback del gestionale. Rimane il confine fra due archivi: se la callback fallisce dopo l'emissione, valgono ancora l'avviso e il recupero esplicito. Non è una transazione distribuita.

## Ambiente di collaudo

Usare un server isolato con un utente di test autorizzato a creare database. La suite crea ed elimina soltanto database nuovi chiamati `nexustest_<UUID>`; non riutilizza gli archivi operativi.

Installare le dipendenze del progetto:

```sh
python -m pip install -r requirements-sviluppo.txt
```

Impostare `NEXUS_TEST_POSTGRESQL_ADMIN_URL` nell'ambiente locale, senza riportare la password nella documentazione. Poi:

```sh
python -m pytest -q tests/postgresql --timeout=240
```

In PowerShell la variabile si imposta con `$env:NEXUS_TEST_POSTGRESQL_ADMIN_URL`; su Linux con `export NEXUS_TEST_POSTGRESQL_ADMIN_URL`. Il valore deve riferirsi al server di collaudo. `pg_dump` e `pg_restore` devono essere disponibili per la prova di backup.

Le 35 prove riusano i flussi funzionali pertinenti e aggiungono: bootstrap/FK/audit SQL, importi oltre INTEGER a 32 bit, numerazioni e versioni fra due processi, backup con documenti/VerbalizzAI e ripristino a fermo. Non sono il collaudo integrale su volumi Garda reali, né il collaudo Windows dell'ufficio.

## Backup e ripristino preliminare

Il backup PostgreSQL contiene `database.pgdump`, documenti, archivio VerbalizzAI e manifest con hash. La verifica controlla hash, percorsi, catalogo del dump e versione Alembic estratta dal dump. Il controllo ordinario PostgreSQL è logico (vincoli, riferimenti, registro e documenti), non un controllo fisico dei file equivalente a SQLite integrity_check.

Il ripristino dall'interfaccia PostgreSQL resta disabilitato in questa rc. La procedura amministrativa di collaudo richiede il servizio applicativo fermo:

```sh
python strumenti/ripristina_postgresql.py NOME_DEL_BACKUP.zip --applicazione-ferma
```

Lo schema del backup deve coincidere con quello corrente. Prima si conserva un backup di sicurezza; pg_restore opera in una transazione. Gli errori successivi sui file tentano il recupero dal backup precedente. Il marcatore `ripristino_postgresql_in_corso.json` impedisce l'avvio se il processo si interrompe o il recupero non riesce. Il test locale verifica anche esito del commit non noto e conservazione del marcatore quando fallisce il recupero; non sostituisce la prova nativa.

Se resta il marcatore, mantenere il servizio fermo. Conservare i dati presenti e il marcatore; identificare il backup di sicurezza indicato, estrarlo in un'altra cartella e verificarlo. Ripristinare insieme PostgreSQL, documenti e archivio VerbalizzAI da quella copia, quindi verificare schema, riferimenti, catena e documenti prima di rimuovere il marcatore. Questa procedura di recupero da interruzione va provata nell'ambiente nativo prima dell'uso operativo.

## Importazione finale Garda

La sorgente definitiva resta costituita dai **tre MariaDB Garda aggiornati al momento del lancio**, più gli allegati. Percorso: copia/staging fedele MariaDB, trasformazioni versionate, modello PostgreSQL Nexus. Nessun passaggio obbligatorio nel modello SQLite Nexus.

L'importatore completo, la riconciliazione economica, il trasferimento degli eventuali archivi di collaudo SQLite già popolati e la prova generale con copie recenti sono ancora da completare. Non usare un ripristino per simulare una migrazione fra motori e non usare l'importatore attuale come prova di completezza.

## Fonti tecniche

- https://www.postgresql.org/docs/16/server-start.html
- https://www.postgresql.org/docs/current/explicit-locking.html
- https://www.postgresql.org/docs/current/app-pgdump.html
- https://www.postgresql.org/docs/16/app-pgrestore.html
- https://docs.sqlalchemy.org/en/21/core/compiler.html
