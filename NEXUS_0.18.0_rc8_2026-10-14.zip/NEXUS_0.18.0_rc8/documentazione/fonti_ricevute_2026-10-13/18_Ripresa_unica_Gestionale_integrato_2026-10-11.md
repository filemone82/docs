# 18 · Ripresa unica del Gestionale integrato — riconciliazione dei rami

Data: 11/10/2026 · Redatto da Claude nel progetto «Gestionale completo AD_dpr» · Stato: **documento di riferimento unico** · Aggiornamento 1.17 (12/10/2026, sera): consegnata la **0.16.0** (schema 0027, R134–R143 realizzate, documento 36 C1–C16); ripresa nel **documento 37** · Aggiornamento 1.16 (12/10/2026, 18:30): **0.16 in sviluppo**, stato del codice e ripresa nel **documento 37** (`claude/37_Ripresa_NEXUS_0.16_in_corso_2026-10-12.md`); R143 ruoli multipli · Aggiornamento 1.15 (12/10/2026, 17:15): collaudo «da zero» di Federico, note nel documento 36, proposte **R137** (ambito solo sul cliente) e **R138** (accettazione/ordine con file e dati per la fattura elettronica) · Aggiornamento 1.14 (12/10/2026): consegnata la **0.15.0** (verbali DM come in VerbalizzAI) · Aggiornamento 1.13 (12/10/2026): consegnata la **0.14.0** (fatture DPR complete) · Aggiornamento 1.12 (12/10/2026): consegnata la **0.13.1** (NEXUS, R132–R133) · Aggiornamento 1.11 (12/10/2026): consegnata la **0.13.0** (VerbalizzAI_DM, prima parte) · Aggiornamento 1.10 (12/10/2026): consegnata la **0.12.10** (maschere AD_DM, documento 30) · Aggiornamento 1.9 (12/10/2026, mattina): consegnata la **0.12.9** (note del documento 28, R129–R131) · Aggiornamento 1.8 (11/10/2026, sera): consegnata la **0.12.8** (note di collaudo N1–N9, R124–R128, rilievi AD-REV-001…005) · Aggiornamento 1.7 (11/10/2026, 18:10): consegnata la **0.12.7** (R122) · Aggiornamento 1.6 (11/10/2026, 17:50): decise **R122** (scheda tecnica unica dell'impianto) e **R123** (verbali AD_dm con la logica di VerbalizzAI, proposta nel documento 24); nuovo ordine delle consegne (§ 7) · Aggiornamento 1.5 (11/10/2026, 16:20): consegnata la **0.12.6** (R119–R121, rilievi della revisione) · Aggiornamento 1.4 (11/10/2026, 14:20): consegnata la **0.12.5** (menu Garda R117, sedi doppie R116, R115, R118) · Aggiornamento 1.3 (11/10/2026, 11:30): consegnata la **0.12.4** (importazione adsrl, ambiti R114) · Aggiornamento 1.1 (11/10/2026, 07:35): consegnata la **0.12.2** (passo A completato), R112 deciso (§ 7), sviluppo affidato a Claude in questo progetto. Sostituisce, come punto di ripresa, il documento 26 (checkpoint C01), la ripresa 1.10/1.18 e lo «Stato verificato» dell'11/10. Quei documenti restano evidenze storiche.

**A cosa serve.** Lo sviluppo si era diviso in due conversazioni ChatGPT, con tre rami di codice e due registri di decisioni con numeri in collisione. Questo documento:
1. fissa **una sola base software**;
2. ricompone **un solo registro**;
3. elenca le **correzioni** da fare per primo;
4. propone l'**ordine dei lavori**;
5. contiene il **prompt** per la nuova chat di sviluppo (§ 10).

**Regola d'ora in poi:** una sola chat di sviluppo; il registro delle decisioni vive solo in questo progetto. La chat di sviluppo propone, il progetto registra (§ 8).

---

## 1. Certezze fissate dall'utente (11/10/2026)

- **VerbalizzAI 1.0.1 rc2 è in produzione da oggi e non si modifica.**
- **Verifica eseguita da Claude:** la copia incorporata nel gestionale (`gestionale/terzi/verbalizzai`, 0.12.1-wip1) è **identica** allo standalone `VerbalizzAI_AD_v1.0.1_rc2.zip`.
  - Le uniche differenze sono gli import resi relativi al pacchetto: 11 righe in `app.py`, `finalization.py`, `layout.py` e `storage.py`. Gli altri file Python e i file statici coincidono.
  - I modelli M01/M02/M03-PO01 rev. 02 coincidono byte per byte.
  - Conseguenza: la validazione ISO/IEC 17020 § 6.2.9 della versione in produzione vale anche per la copia incorporata, finché resta identica.
- **Il «ponte minimo» non si farà.** Non verranno aggiunti in VerbalizzAI il riferimento esterno all'impianto Garda né il codice completo del verbale. Gli impianti e i verbali creati da oggi andranno abbinati al gestionale **in migrazione**, per numero di verbale e indirizzo, con controllo manuale dei casi dubbi. Durante la convivenza con Garda (doc. 12, C1–C2):
  - il numero del verbale lo assegna Garda e in VerbalizzAI si riporta identico;
  - in Garda si scrive la data di prossima verifica stampata nel verbale.

  Questo rende l'abbinamento affidabile.

---

## 2. Base software unica: **0.12.2** (dall'11/10/2026, 07:35)

> **Aggiornamento 1.17 (12/10/2026, sera).** Base corrente: `NEXUS_0.16.0_2026-10-12.zip` (SHA-256 `9f715435fc3f27dcf37e5d11b534ba1b277b2046c81a0ff5595009d876e69639`, commit `b13b9de`), schema **0027** (migrazioni 0023–0027), **317 test**. Realizzate R134–R143 e le osservazioni C1, C2, C4–C16 del documento 36, più la registrazione multipla DM (documento 28 p. 13). Fuori per scelta di Federico: XML delle fatture (alla fine) e modello «impianto termico». Le rev. 03 di M14 e M11 sono in archivio «da approvare». Differenze: documento 43 nello ZIP; copia nel progetto `claude/38_Differenze_0.16.0_2026-10-12.md`. Stato del codice e ripresa: documento 37.
>
> **Aggiornamento 1.14 (12/10/2026).** Base precedente: `NEXUS_0.15.0_2026-10-12.zip` (SHA-256 `cbbcec3ec73cdaf02806f86e113f0d967e157a8510c3ced338f214e856f8577a`), schema **0022** invariato, **297 test** (LibreOffice reale nei test «pdf_vero»). Verbali DM come in VerbalizzAI: anteprima «BOZZA» con spazio firma riservato, riquadro firme intero e in fondo alla pagina, firma DM obbligatoria, «Firma ed emetti» con controllo delle pagine, «Aggiorna / Conserva». Modelli M14 e M11 di AD invariati; PDF di prova con dati inventati inviati per l'approvazione. Documento 42 nello ZIP; copia nel progetto: `claude/35_Differenze_0.15.0_2026-10-12.md`. **Risposte di Federico (17:02):** R134 revisione come DPR, R135 annullamento da verificatore o RT senza cambiare la numerazione, R136 modelli approvati con la grafica da allineare a M01–M03 di VerbalizzAI. **Codice fermo per ora** («non scrivere altro codice per il momento»). **Aggiornamento 17:50:** via alla 0.16 con «tutto quanto discusso» (XML esclusi, rimandati alla fine); stato nel documento 37. **Collaudo «da zero» (17:15) — prima cosa al via del codice: R142 (date alla registrazione delle attrezzature, scadenziario vuoto senza).** osservazioni raccolte nel documento 36 (`claude/36_Note_di_collaudo_NEXUS_2026-10-12.md`); C1 → R137; C2 → R138; C3 domanda sull'importazione; C4 → R139; C5 → R140; C6 errore all'emissione da archivio nuovo (difetto), XML rimandati alla fine per decisione di Federico (17:37); C7 nuova attrezzatura con la sede proposta dall'elenco filtrato; C8 collegamenti della sede distinti GVR / SC-SP; C9 → R141; C10 «Cerca sede» della nuova attrezzatura (difetto d'uso); C11 «Tipo attrezzatura verbale» solo GVR; C12 → R142; C13 PVP sulla scadenza più vicina (già così dalla 0.12.8; da estendere alle righe manuali e alle date uguali).
>
> **Aggiornamento 1.13 (12/10/2026).** Base corrente: `NEXUS_0.14.0_2026-10-12.zip` (SHA-256 `92f45b218e2a762bb725ec0a98c92f351c70374a5fdfef60492f3021df8ec2b0`), schema **0022**, **292 test**. Fatture DPR complete pari a Garda: cedente con REA e contatti, documenti collegati, modalità di pagamento con le regole di Garda, nome file SdI corretto, ricevute SdI da file, XML in blocco, scadenze di pagamento. Documento 41 nello ZIP; copia nel progetto: `claude/34_Differenze_0.14.0_2026-10-12.md`. **Da fare prima della produzione:** confronto con XML veri di Garda e prova su Aruba (documento 41 § 10). Prossimo: **0.15, verbali DM finiti**.
>
> **Aggiornamento 1.12 (12/10/2026).** Base corrente: `NEXUS_0.13.1_2026-10-12.zip` (SHA-256 `d6d5ae0640c4dbf7e6dd04a1746e0dde74cbb57e61529b720ab95dbc0b431930`), schema **0021**, **284 test**. Il gestionale si chiama **NEXUS** (R133); ruoli distinti per attività (R132); rilievi AD-REV-006…008. Documento 40 nello ZIP; copia nel progetto: `claude/33_Differenze_0.13.1_2026-10-12.md`. Prossimo: **0.14, fatture DPR complete**.
>
> **Aggiornamento 1.11 (12/10/2026).** Base corrente: `Gestionale_AD_0.13.0_2026-10-12.zip` (SHA-256 `43dabb5f838ad8acaf8f28c1a8c0a0e39dbf2fbb46762d507d77a7db43bdd071`), schema **0020** (nuova tabella `dm_schede_verbale`), **276 test**. Prima parte di VerbalizzAI_DM (R123; documento 28, punto 18):
> - dati del verbale come attributi dell'attrezzatura, con provenienza, correzione a mano e storico;
> - bozza del verbale dalla scheda, con risultato identico alla regola di Garda finché nessuno corregge;
> - Pes e Tes del funzionamento precedente come confronto;
> - firma DPR (VerbalizzAI) e firma DM distinte per ogni utente; i verbali DM usano solo la firma DM;
> - copia del PDF definitivo in `cartella_verbali_dm` / GVR o SC_SP / anno di emissione / sede, con nome INAIL e nome leggibile.
>
> Documento 39 nello ZIP; copia nel progetto: `claude/32_Differenze_0.13.0_2026-10-12.md`. **Da confermare:** formato del nome leggibile (numero senza zeri davanti e anno a 4 cifre, come nei file di Federico). Prossimo: **0.13.1** (modelli M-DM-GVR e M-DM-SCSP, anteprima, firma ed emissione).
>
> **Aggiornamento 1.10 (12/10/2026).** Base corrente: `Gestionale_AD_0.12.10_2026-10-12.zip` (SHA-256 `dd24e6f7d49a4744690453a5032ccae7c0e1dde88dab4cddbe94b52b91f6f4cc`), schema **0019** invariato, **272 test**. Contiene le maschere AD_DM dettate da Federico (documento 30):
> - viste di partenza per attività;
> - Attrezzature GVR e SC/SP raggruppate per sede;
> - Scadenze per sede;
> - Preventivi con fatturato e riesame;
> - Verifiche GVR e SC/SP;
> - Fatture sulla griglia, anche AD_DM.
>
> Documento 38 nello ZIP; copia nel progetto: `claude/31_Differenze_0.12.10_2026-10-12.md`. Prossimo: **VerbalizzAI_DM** (documento 28, punto 18; R123).
>
> **Aggiornamento 1.9 (12/10/2026, mattina).** Base corrente: `Gestionale_AD_0.12.9_2026-10-12.zip` (SHA-256 `62bb8e38ed76b92a52d80d71a3c4f0d80ccea55429cce8e5584f5f9ad9408f19`), schema **0019** invariato, **269 test**. Contiene, uniformato fra DPR e DM:
> - preventivo DM solo con le verifiche dell'allegato VII (R129), con il filtro «Attività EX»;
> - schede ridimensionabili (R130);
> - affidamento dalla scheda del preventivo con selezione multipla;
> - Verifiche AD_DM sulla griglia standard;
> - dati del tecnico nella scheda utente;
> - linguetta «Verbale» nell'incarico DM;
> - termini di esecuzione configurabili;
> - residui del revisore AD-REV-002 e AD-REV-005.
>
> Documento 37 nello ZIP; copia nel progetto: `claude/29_Differenze_0.12.9_2026-10-12.md`. Note di collaudo e punti aperti: `claude/28_Note_di_collaudo_2026-10-12.md`.
>
> **Aggiornamento 1.8 (11/10/2026, sera).** Base corrente: `Gestionale_AD_0.12.8_2026-10-11.zip` (SHA-256 `75ed6f56dceaf66df4dbede55438ac1b07d0f54c95d91cb6e06a568f37444f9f`), schema **0019**, **263 test**. Contiene:
> - le note di collaudo N1–N9 (documento 26): revoca motivata dell'accettazione (R124), «Accetta» ripetuto senza effetto, selezione distinta dallo stato, riesame non ripetibile;
> - fatture dalle righe dei preventivi come in Garda (R125), con la regola unica «da fatturare»;
> - preventivo DM dalle scadenze, una riga per scadenza (R128), prima periodica dalla scheda, blocco senza «soggetta a messa in servizio», colonna di tariffa visibile, sconto predefinito AD_DM del cliente (regola Garda AD-13, trovata nella rilettura del codice di Garda);
> - menu richiudibile, Gestione › Configurazione, «Tipi e tariffe» (R126); Utenti e permessi come in VerbalizzAI (R127);
> - correzione dei cinque rilievi della revisione della 0.12.6, AD-REV-001…005, tutti «risolto da verificare»; AD-DEC-001 decisa con R122. Registro aggiornato nello ZIP: `documentazione/Registro_rilievi_Gestionale_AD_0.12.8.txt`.
>
> Documento 36 nello ZIP; copia nel progetto: `claude/27_Differenze_0.12.8_2026-10-11.md`. Prossima: **0.13.0** (verbali AD_dm, R123, documento 24).
>
> **Aggiornamento 1.7 (11/10/2026, 18:10).** Base corrente: `Gestionale_AD_0.12.7_2026-10-11.zip` (SHA-256 `3d9c5955b2054783cef5f6e1e615645e1da375cc4eb430880ae33be9bc7401f8`), schema **0018** invariato, **251 test**. Contiene R122: scheda tecnica unica dell'impianto (quella di VerbalizzAI), copia del gestionale riallineata da sola, Word caricato a mano che entra nell'archivio dei verbali, linguetta «Scheda tecnica» con apertura della Scheda impianto di VerbalizzAI. Documento 35 nello ZIP; copia nel progetto: `claude/25_Differenze_0.12.7_2026-10-11.md`. Prossima: **0.13.0** (verbali AD_dm, R123, documento 24).
>
> **Aggiornamento 1.6 (11/10/2026, 17:50).** Decise R122 e R123; nuovo ordine delle consegne (§ 7).
>
> **Aggiornamento 1.5 (11/10/2026, 16:20).** Base corrente: `Gestionale_AD_0.12.6_2026-10-11.zip` (SHA-256 `4d4ed35b5860d4644416c3ed91a4ab5c374b513df067bb70e14887a881451688`), schema **0018**, 246 test. Contiene:
> - indipendenza dichiarata dal verificatore (R119);
> - affidamento dalle righe dei preventivi, DPR e DM, come in Garda;
> - verbale precedente caricato dalla verifica e data di emissione;
> - corrispondenze con Garda (R120) e fusione dei clienti solo se certa, con i possibili doppioni dei clienti;
> - schede Cliente e Sede e Scadenze nel contesto AD_DM;
> - correzione dei doppioni di sede;
> - ruoli di base (R121).
>
> Accoglie i quattro rilievi della revisione indipendente della 0.12.5. Documento 34 nello ZIP; copia nel progetto: `claude/23_Differenze_0.12.6_2026-10-11.md`.
>
> **Aggiornamento 1.4 (11/10/2026, 14:20).** Base corrente: `Gestionale_AD_0.12.5_2026-10-11.zip` (SHA-256 `1ec7ea30274b15b0b6b488eaa8c956b13870bdba75112a0afd00f97bdbe40e58`), schema **0017**, 237 test. Contiene:
> - il menu per attività come Garda (R117), con elenchi completi di attrezzature e valvole e i cataloghi;
> - le sedi doppie (R116);
> - i preventivi solo nel proprio ambito (R115);
> - la quadratura degli accoppiamenti (R118).
>
> Documento 33 nello ZIP; copia nel progetto: `claude/22_Differenze_0.12.5_2026-10-11.md`.
>
> **Aggiornamento 1.3 (11/10/2026, 11:30).** Base corrente: `Gestionale_AD_0.12.4_2026-10-11.zip` (SHA-256 `291a2f86fdb8243385f850615dcbff5fd7c1bd113023bb763619fe11c7982411`), schema **0016**, 231 test. Contiene:
> - l'**importazione di AD_dm** (`adsrl`) nell'archivio di prova creato da ingecert: clienti fusi, sedi, attrezzature, camere, accessori, date iniziali. Quadratura senza differenze sul dump reale del 07/10. È il primo pezzo della migrazione a secco del passo B;
> - gli **ambiti di lavoro** su clienti e sedi (R114);
> - i campi degli accessori nella scheda.
>
> Documento 32 nello ZIP; copia nel progetto: `claude/21_Differenze_0.12.4_2026-10-11.md`.
>
> **Aggiornamento 1.2 (11/10/2026, 08:15).** Base corrente: `Gestionale_AD_0.12.3_2026-10-11.zip` (SHA-256 `b2306ed76f702b80f2e441d411f86888cf568f08796229b3fb405945b8d92302`), 224 test: correzioni dopo la prima prova su Windows (ambiente di prova, codifica UTF-8, soglia del test di velocità). Documento 31 nello ZIP.
>
> **Aggiornamento 1.1.** La base era `Gestionale_AD_0.12.2_2026-10-11.zip` (SHA-256 `19b162b9c04433d25ed1759f30ed317ff36c3031b97c0b1464907db941dbea1a`), derivata dalla 0.12.1-wip1 con le correzioni del passo A (§ 4), schema 0015 invariato, **222 test passati**. Differenze: documento 30 dentro lo ZIP. I §§ 2.1–2.3 descrivono la situazione di partenza della 0.12.1-wip1 e restano validi, salvo quanto corretto dal passo A.

### Situazione di partenza: 0.12.1-wip1

### 2.1 Genealogia dei rami

| Ramo | Origine | Migrazione | Destino |
|---|---|---|---|
| 0.1.0 → 0.7.1 | Questo progetto (Claude), D1–D81 | fino a 0008 | Assorbito nella 0.8.0 |
| 0.8.0 → 0.11.0-dev | ChatGPT (tronco comune alle due chat) | 0009 → 0013 | Assorbito |
| **0.12.0-dev** | Chat «Progettare Gestionale Unico» | `0014_documenti_e_chiusura_tecnica_dm` | Assorbito nella 0.12.1-wip1 |
| **0.12.1-wip1** | Stessa chat, 11/10 | **0015** `fatturazione_dm_e_lotti_inail` | **BASE UNICA** |
| WIP da 0.11 | Chat «Analisi gestionale integrato» | `0014_verbali_riesami_dm` (**stessa etichetta 0014, schema diverso**) | **Non installare.** Se ne portano solo i pezzi utili (§ 2.3) |

Impronte SHA-256 dei pacchetti ricevuti (11/10/2026):
- `Gestionale_AD_0.12.1-wip1_checkpoint_2026-10-11.zip` — `66ceb0369db069e71136a33f33c70d7eb36debc7bf222d6c6211a444d6d6c686`
- `Gestionale_AD_0.12.0-dev_checkpoint_documenti_DM_2026-10-10.zip` — `7ac86109eb3dfd1a07338b30beb71d7069564bed06d8235d56dbb40aac431030`
- `VerbalizzAI_AD_v1.0.1_rc2.zip` — `2b1182136d424b06e07f50b987037e858cba0035e616c88fcef58157e1dc4cf4`
- `Gestionale_integrato_ripresa_verificata_e_WIP_2026-10-11.zip` — `a519815a3578c00186db9a2ad3c191ebf3aab38e9740c1f1b84c9592e8073ee5`
- `Gestionale_AD_delta_0.12.1-wip1_2026-10-11.docx` — `d1652aec90a46977400ae0a7b9b9f12a44eabdd3db82c940d519eb6b3e6a9dd9`
- `26_Ripresa_autonoma_LLM_Gestionale_integrato_2026-10-10.md` — `b1484fa626aeaac18c0baf941a4cfa32a23e1074af76bb9674a18d35362dcd72`
- Base del WIP, 0.11.0-dev — `dc4871323caaa2b6a6582c762d4afc073b034c8463785699f38a508a576d6f17` (dichiarata nel pacchetto di ripresa)
- Garda: `D:\backup_gestionale` sul PC dell'utente (adsrl, ingecert, iec, ciascuno con `codice`, `db`, `allegati`)

### 2.2 Cosa contiene davvero la 0.12.1-wip1

| Area | Presente | Stato |
|---|---|---|
| **DPR** | Anagrafica, tariffario, preventivi con documenti come i verbali, verifiche, VerbalizzAI incorporato, fatture/incassi (TD01/TD02/TD04, intestatario terzo, incassi ripartiti), import da ingecert | Fatture: XML non pari a Garda (FIN-04: mancano REA, contatti, documenti collegati, pagamenti NC); esiti Aruba e import economico/incrementale assenti |
| **Nucleo comune** | Beni, cataloghi Garda (31 tipi all.7, 72 ID specifiche, 162 compatibilità, 314 tariffe), camere L/DN, PSV, ingressi `/ad-dpr` `/ad-dm` `/iec` | Autorizzazioni per ambito da completare |
| **DM tecnico** | Preventivi, RC, assegnazione, programmazione, registrazione, Word/PDF GVR/SC/SP dai modelli Garda, ritocco controllato, PDF definitivo, chiusura, riesame, scadenze per componente, CND, email del definitivo | Riesame negativo → registrata implementato in parte (R108); **blocco di indipendenza rimosso (da ripristinare, § 4)** |
| **DM fatture e INAIL** | Backend: fatture per ambito DPR/DM/EX/IEC con controllo dell'emittente, archivio PDF fatture, lotti INAIL (62 colonne Garda, Excel + 3 ZIP + manifest) | **Bozza:** nessun test dedicato, nessuna schermata (le pagine fatture restano DPR), nessun confronto con Garda |
| **EX** | Solo apertura del servizio fatture all'ambito EX | Ciclo commerciale e tecnico assente |
| **I&C** | Ambito di navigazione | **Assente.** Il lavoro I&C descritto in chat il 10/10 pomeriggio **non esiste come codice** (confermato dal delta 0.12.1-wip1) |
| **Migrazione** | Import DPR iniziale (0.7.1) | Import dei tre dump e riallineamento incrementale assenti |
| **Test** | 215 passati (suite completa 0.12.1-wip1, Linux, Python 3.12, SQLite) | Coprono le parti esistenti, non fatture DM e INAIL. La 0015 è provata solo su archivio sintetico vuoto. Nessuna prova su Windows/Word, PostgreSQL o VPS |

### 2.3 Dal WIP nato dalla 0.11: cosa portare, cosa no

Controllato da Claude sul codice:
- **Da portare:** il controllo che la **visita interna** sia pertinente solo a **GV/INS GV** (rilievo DM-07). Nel WIP esiste in `dm/servizio.py`, nella 0.12.1-wip1 no.
- **Già coperto nella 0.12.1-wip1 (non portare):**
  - riesame negativo → registrata, già fatto come R108;
  - protezione delle bozze già salvate (DM-16), con precompilazione solo prima del primo salvataggio;
  - nuovo preventivo ammesso dopo incarico completato (DM-11);
  - ritorno alle date precedenti o iniziali all'annullamento.
- **Da non portare:**
  - la migrazione `0014_verbali_riesami_dm` (collisione di schema);
  - la scheda tecnica facoltativa: nella 0.12 resta **obbligatoria per V1**, come in Garda.
- **Test WIP fallito** (`test_migrazione_0012_popolata_preserva_foto_fk_e_default`, downgrade non atomico): riguarda solo la migrazione WIP, che non si porta. Va però controllato che la 0015 non abbia lo stesso difetto (§ 4, A6).

---

## 3. Registro unificato delle decisioni

### 3.1 Esito del confronto meccanico (eseguito da Claude, non a memoria)

- **R01–R100:** identici nei due documenti quadro (1.95 nella 0.12, 1.101 nel pacchetto di ripresa), testo e stato, **tranne R12**. Vale la formulazione del 1.101: documento autonomo di ripresa a ogni avanzamento, con dettagli integrali.
- **Documenti quadro:** tronco comune fino al § 76. Il 1.95 aggiunge i §§ 77–78 (trasferimento fedele, 0.12). Il 1.101 aggiunge i §§ 77–82 (audit Garda) e la sezione R101 sul riesame. Non ci sono altre divergenze nascoste: 25 righe proprie del 1.95, 80 del 1.101.
- **Collisione R101:** nel 1.95 indica «Garda funziona bene: conservare logiche e flussi». Nel 1.101 indica «riesame DM negativo → registrata». Il delta 0.12.1-wip1 ha rinumerato la seconda come **R108**. Qui si conferma quella numerazione.
- **Registro D (questo progetto):** D1–D81 nel documento 02. Le risposte Q8–Q16 del documento 17 (08/10/2026) **non risultano nel registro R** del ramo ChatGPT: vanno riportate (§ 3.3).

### 3.2 Numerazione valida da oggi

| Rif. | Decisione | Origine |
|---|---|---|
| D1–D81 | Registro di questo progetto (doc. 02) | Claude, 04–08/10 |
| R01–R100 | Registro comune dei due rami (R12 nel testo del 1.101) | ChatGPT |
| R101 | Garda funziona bene: conservare logiche e flussi, salvo modifiche concordate o necessarie all'unificazione | Quadro 1.95 |
| R102 | Nessuna semplificazione od omissione delle regole e funzioni Garda | Quadro 1.95 |
| R103 | Motivazione principale: indipendenza dal fornitore esterno | Quadro 1.95 |
| R104 | Meno click; offerte e verbali DM con ritocco ammesso, controllo, archiviazione definitiva e invio del PDF, come VerbalizzAI | Quadro 1.95 |
| R105 | Rifare le dashboard AD_dm | Quadro 1.95 |
| R106 | Un unico prodotto: tre frontend, backend comune, VerbalizzAI, tutte le funzioni Garda compatibili | Quadro 1.95 |
| R107 | Iterare fino a un prodotto «viable» (messaggio del 10/10, 08:46) | Delta 0.12.1-wip1 |
| R108 | Riesame DM negativo → la verifica torna a registrata (ex R101 del ramo audit; «Si» del 10/10, 21:58) | Delta 0.12.1-wip1 |
| **R109** | **Riesame negativo del verbale, in DM e in DPR:** la verifica torna al tecnico in stato «registrata» per la correzione, poi torna «eseguita» e va a nuovo riesame. **Nuovo rispetto a Garda: storico dei riesami del preventivo e del verbale**, con autore, data e note di ogni riesame; nessun riesame sovrascrive il precedente. Estende R51, R52 e R108 | Utente, 11/10/2026 |
| **R110** | **Dichiarazione di indipendenza, in DM e in DPR:** preimpostata su «Sì». Con «No» la verifica **non può essere programmata, registrata né eseguita**. Modifica R63, che bloccava solo l'esecuzione. Chiude AD-31 come deroga approvata ad adsrl. **Annulla la rimozione del blocco DM fatta nella 0.12.1-wip1** | Utente, 11/10/2026 |
| **R111** | VerbalizzAI 1.0.1 rc2 in produzione dall'11/10/2026, non si modifica. Il gestionale ne incorpora una copia identica, controllata a ogni aggiornamento. Niente ponte minimo: abbinamento in migrazione. Sostituisce D78 per la versione (0.3.32.1 → 1.0.1 rc2) | Utente, 11/10/2026 |
| **R112** | **Ordine dei lavori:** prima **AD_dpr «viable»**, completo in tutte le funzioni ma **non in produzione**; poi l'integrato DM + I&C (§ 7). Marzo 2027 non è vincolante | Utente, 11/10/2026 (scelta dell'opzione A e richiesta del codice) |
| **R113** | Una sola linea di sviluppo; registro unico nel progetto Claude; le due chat ChatGPT precedenti si archiviano. **Dall'11/10/2026 il codice lo scrive Claude in questo progetto**, su richiesta dell'utente; la verifica indipendente delle consegne è consigliata (istanza separata, con questo documento come riferimento) | Utente, 11/10/2026 |
| **R114** | **Anagrafica clienti unica con ambiti di lavoro.** Ci sono clienti solo AD_dpr (impianti), solo AD_dm o I&C (attrezzature) e clienti con entrambi. Un cliente e una sede portano gli indicatori AD_DPR, AD_DM, I&C. Gli elenchi di ogni attività mostrano solo i propri clienti e le proprie sedi; con un clic si vedono tutti. Gli indicatori si accendono da soli quando entra un impianto, un'attrezzatura o un preventivo dell'ambito, e si possono accendere a mano. Si spengono solo a mano, e solo se non servono più. Non sono un controllo di autorizzazione. Testo dell'utente: «un'anagrafica clienti unica è indispensabile, ma a livello di query sarebbe bene distinguere gli ambiti […] con un attributo legato a cliente che delimiti l'ambito AD_dm, AD_dpr e/o I&C». Realizzato nella 0.12.4 (migrazione 0016) | Utente, 11/10/2026, 10:58 |
| **R115** | **Preventivi solo nel proprio ambito.** Nel nuovo preventivo DM la ricerca mostra solo le sedi AD_DM; nel nuovo preventivo DPR solo i clienti AD_DPR. Il programma rifiuta il preventivo fuori ambito e indica dove cambiare l'ambito. Se serve, l'ambito si modifica dall'anagrafica (scheda del cliente o della sede). Una sede diventa comunque AD_DM da sola quando le si aggiunge un'attrezzatura (R114). Testo dell'utente: «quando creo un preventivo DM la ricerca delle sedi dovrebbe mostrare solo quelle associate a clienti AD_DM, non DPR. al limite se c'è l'esigenza si modifica dall'anagrafico l'attributo "ambito" (ora lo chiamo così, poi decidiamo come chiamarlo)». Il nome definitivo di «ambito» è da decidere | Utente, 11/10/2026, 11:56 |
| **R116** | **Sedi doppie: lo stesso stabilimento è una sola sede.** Nell'importazione da Garda la sede adsrl con lo stesso indirizzo e comune di una (e una sola) sede già presente dello stesso cliente si unisce a quella, con gli ambiti di entrambe. Le altre coppie probabili (stesso cliente e comune, ambiti diversi) si propongono all'utente: «Unisci» o «Sono sedi diverse». Per ora **un solo referente tecnico e una sola email per i verbali** per sede: i dati diversi vanno nelle note. Destinatari diversi per ambito sono possibili ma rari: da riprendere se servono. Testo dell'utente: «si va bene unire le sedi con stesso indirizzo […] i verbali potrebbero andare a persone diverse anche se è raro. però ora tieni un referente tecnico / mail sola» | Utente, 11/10/2026, 13:55 |
| **R117** | **Menu per attività con le sezioni dei gestionali di Garda**, nello stesso ordine: Clienti (clienti, sedi operative, tipi di pagamento, aliquote IVA), Attrezzature (attrezzature, valvole di sicurezza, tipi di attrezzature, tipi attrezzature GVR, ID specifiche, tipi attr./ID specifiche, tariffe SC/SP, tariffe GVR) per AD_dm o Impianti per AD_dpr, Scadenze, Preventivi, Verifiche, Fatture, Gestione (utenti, ruoli, configurazione, comuni). Sostituisce «Parco comune» e «Attrezzature e accessori». Testo dell'utente: «la vista di AD_DM non mi convince. "parco comune" "attrezzature e accessori" mi sembra poco coerente. i gestionali di garda sono divisi per: …» | Utente, 11/10/2026, 13:55 |
| **R118** | **L'importazione dal database di Garda deve avvenire senza errori, duplicazioni o accoppiamenti mancati.** Ogni importazione produce una quadratura, tabella per tabella, che controlla anche gli accoppiamenti: sedi attese e presenti, ogni bene nella sede giusta, ogni collegamento importato o scartato con il motivo. Vale per la migrazione vera dei tre gestionali (passo B). Testo dell'utente: «ricordiamoci poi che dovremo gestire l'importazione dal database di garda senza errori, duplicazioni o mancati accoppiamenti» | Utente, 11/10/2026, 13:55 |
| **R119** | **Indipendenza del verificatore.** La dichiara solo il verificatore a cui è affidata la verifica (DPR) o l'incarico (DM), anche quando è il responsabile tecnico; nessun altro può dichiararla per lui. Preimpostata su «Sì». Con «No» la verifica torna al responsabile tecnico da riassegnare, senza verificatore e senza data prevista, con la nota di chi l'ha esclusa e quando. Si dichiara fino alla registrazione; dopo, il RT riassegna e il numero del verbale resta. Completa R110. Testo dell'utente: «è il verificatore assegnatario (idem se responsabile tecnico assegnatario) che la deve dichiarare, di default lascio si, se no torna a rt per riassegnazione» | Utente, 11/10/2026, 15:54 |
| **R120** | **Corrispondenze strutturate con i gestionali di provenienza:** tabella `origini` (sistema, tabella, id originale → oggetto del gestionale integrato), riempita da ogni importazione, aggiornata dalle unioni, recuperata per gli archivi esistenti. Per attrezzature e accessori resta `asset_origini`. La fusione dei clienti avviene solo con corrispondenza certa; gli altri casi si confermano a mano. Base dei riallineamenti e della migrazione definitiva (R118) | Revisione indipendente della 0.12.5, accolta dall'utente («procediamo con il codice alle correzioni / integrazioni»), 11/10/2026 |
| **R121** | **Utenti e permessi personalizzabili, non fissi.** Ruoli di base: Amministratore (accesso completo), Responsabile tecnico (affida gli incarichi di verifica, esegue verifiche, riesamina i verbali), Verificatore (esegue le verifiche assegnate). L'amministratore crea ruoli e assegna i permessi uno per uno. Da completare: permessi per attività (AD_DPR, AD_DM, I&C) e visibilità del commerciale sui propri clienti | Utente, 11/10/2026, 15:54 |
| **R122** | **Una sola scheda tecnica per l'impianto (DPR).** Tutti i campi del verbale sono attributi dell'impianto, tranne esito positivo/negativo, durata della verifica, persona presente e resistenza di terra. Restano nel solo verbale anche i dati che cambiano a ogni verifica: numero, date, motivo, strumenti, note, non conformità, valori misurati sugli elementi. Il verbale precompilato di VerbalizzAI ripropone l'ultimo aggiornamento. Fa fede la scheda impianto di VerbalizzAI; il gestionale ne tiene solo una copia di lettura, riallineata dopo ogni emissione, adozione, correzione, annullamento, collegamento e Word caricato. Il Word caricato a mano su una verifica entra nell'archivio dei verbali e aggiorna la scheda come un'emissione, mai all'indietro. Chiude il punto 9(c) del § 5. Testo dell'utente: «una sola scheda tecnica per l'impianto. diciamo che tutti i campi del verbale (ad esclusione di "positivo" / "negativo", durata verifica, persona presente in occasione della verifica, resistenza di terra, sono attributi dell'impianto. il verbale precompilato di verbalizzAI ripropone l'ultimo aggiornamento.» | Utente, 11/10/2026, ~17:15 |
| **R123** | **Verbali AD_dm con la logica di VerbalizzAI** (proposta: documento 24).<br>**Scheda tecnica unica dell'attrezzatura**, divisa in gruppi per componente, secondo la regola di Garda `copia_dati_precedente_verifica`: accessori e dispositivi dai verbali con funzionamento; acqua e conduttore per a2 con funzionamento; stato delle tubazioni da integrità o interna; testi SC/SP. Ogni gruppo ricorda il verbale e la data di provenienza; la scheda si corregge a mano. Sono **attributi** (risposte dell'utente): i testi SC/SP «condizioni generali», «esame degli organi principali», «comportamento durante le prove», «configurazione e dati tecnici», e le **osservazioni** (GVR e SC/SP). Restano **solo nel verbale**: Pes e Tes (mostrati come valore del verbale precedente, da confrontare), le descrizioni dell'esame visivo e delle prove di stabilità del generatore, le prove eseguite, esito, regime, date.<br>**Documento**: anteprima PDF con lo spazio della firma riservato; ritocco di sola impaginazione; firma ed emissione solo se il numero di pagine non cambia; riquadro firme intero in fondo alla pagina; «Aggiorna/Conserva la scheda».<br>**Revisioni numerate** (stesso numero, rev. N, precedente «sostituito»). Una revisione di un verbale già esportato all'INAIL **resta solo in archivio e non si riesporta**. Annullamento con motivo; riesame non conforme corretto con una revisione.<br>**Modelli Word nuovi** M-DM-GVR e M-DM-SCSP, ridisegnati da Claude dai contenuti dei moduli Garda e approvati dall'utente in PDF.<br>**Precisazione del 12/10/2026 (documento 28, punti 16–17):**<br>• «ridisegnati» vale solo per impaginazione e firma: struttura, numerazione delle sezioni (1–4, con le varianti per funzionamento, integrità, interna) e contenuti restano quelli di Garda; per SC/SP il modello specifico;<br>• generazione come VerbalizzAI: anteprima PDF e ritocco Word;<br>• la scheda tecnica della PVP si prepara in Word e si carica in PDF;<br>• il PDF definitivo si salva due volte nella cartella locale `GVR` o `SC_SP` / anno di emissione / sede: con il nome INAIL e con il nome «potabile» `GVR_0012-26 …` (quattro cifre);<br>• la verifica resta registrata finché gli allegati non sono caricati.<br>VerbalizzAI non si modifica (R111): se ne chiamano le funzioni generiche. Testo dell'utente: «la stessa logica di verbalizzAI per dpr 462/01 deve essere ripetuta per AD_dm. n.b. in garda esisteva già il sistema di registrazione dei verbali dm (guarda bene le regole specifiche per gvr, funzionamento, interna, integrità, e per sc/sp), tuttavia è da migliorare alla luce di verbalizzAI (in particolare il sistema delle revisioni, il sistema di anteprima pdf, impaginazione migliorata con firma in basso senza sforare, etc.)». Risposte dell'utente alle domande del documento 24, § 7: attributi = «Testi SC/SP, Osservazioni»; revisione già esportata = «Solo archivio»; modelli = «Li ridisegni tu»; ordine = «R122, verbali DM, fatture» | Utente, 11/10/2026, 17:33 e risposte successive |
| **R124** | **Revoca dell'accettazione di una riga di preventivo** (DPR e DM): azione a sé, «Revoca accettazione…», con motivo obbligatorio; chi, quando e perché si registrano. La verifica o l'incarico nati dalla riga si annullano con lo stesso motivo se sono ancora «da assegnare»; se sono già affidati la revoca si blocca e prima si annulla la verifica. Il riesame resta valido per le altre righe; la riga riaccettata richiede un nuovo riesame (ISO/IEC 17020). Una riga accettata non cambia più stato senza revoca. Realizzata nella 0.12.8 (tabella `preventivi_righe_revoche`, migrazione 0019). Testo dell'utente: «se flaggo su accetta dopo che è stato accettao perde lo stato, va quindi anche riseaminato. in realtà per annullare l'accettazione andrebbe registrato (con motivaizone) l'annullamento»; alla proposta: «confermo» | Utente, 11/10/2026, 19:03 e 19:05 |
| **R125** | **Fatture dalle righe dei preventivi, come in Garda.** In Verifiche il filtro rapido «Da fatturare» (verbale emesso, riesaminato dal RT con esito conforme, non già fatturato) e il rimando alle righe; in Righe dei preventivi il filtro «Da fatturare» e «Fattura le selezionate…», che crea una bozza con tutte le righe scelte. Una nota di credito totale riporta la riga tra le «da fatturare»; un acconto non conta. Realizzata nella 0.12.8; XML pari a Garda e scadenze di pagamento automatiche nella 0.14. Testo dell'utente: «tra i filtri rapidi di verifiche metterei "da fatturare" (verbale emesso, riesaminato dal RT, non già fatturato)»; «in garda da preventivi righe (normalmente mettiamo filtro rapido "da fatturare" su verbali, e poi si rimanda a preventivi righe)»; «ok segnati questa modifica» | Utente, 11/10/2026, 19:13–19:15 |
| **R126** | **Menu richiudibile e Gestione riorganizzata.** I gruppi del menu si chiudono sulle voci principali: Clienti (clienti, sedi operative); Attrezzature (attrezzature, valvole di sicurezza, e i sei cataloghi Garda accorpati in una schermata «Tipi e tariffe»); Scadenze; Preventivi; Verifiche; Fatture; Gestione (utenti, ruoli, configurazione, comuni). In Configurazione: modelli dei verbali e dei preventivi, firme, strumenti di misura, e le impostazioni che prima erano voci del menu (tipi di pagamento, aliquote IVA, elenchi, commerciali, email, importazioni, registro, backup). Modifica R117. Realizzata nella 0.12.8. Testo dell'utente: «il menu a sinistra sempre "esploso" non va bene. deve poter collassare sulle voci principali. clienti -> clienti, sedi operative; gestione -> utenti, ruoli, configurazione (metterei quì templates verbali, preventivi, firme, strumenti di misura), comuni; attrezzature; attrezzature, valvole di sicurezza; scadenze; prevetivi; verifiche; fatture. Le voci ipi attrezzature, tipi attrezzature gvr, id specifiche, tipi attr. / id specifiche, tariffe sc/sp, tariffe gvr, li metterei in una schermata unica accorpate» | Utente, 11/10/2026, 19:23 |
| **R127** | **Utenti e permessi come in VerbalizzAI:** una pagina con l'elenco degli utenti e sotto la matrice «Permessi per ruolo» (una colonna per ruolo, una casella per operazione, «Salva permessi»); l'Amministratore ha sempre tutto. Completa R121. Realizzata nella 0.12.8. Testo dell'utente: «aggiungo che i permessi andrebbero gestiti come in verbalizzAI», con la schermata «Utenti e permessi» di VerbalizzAI | Utente, 11/10/2026, 19:24–19:25 |
| **R128** | **Preventivi DM dalle scadenze, una riga per attività.** In Scadenze AD_DM si selezionano le scadenze e si crea il preventivo, come in Garda («Crea preventivo da scadenze», `$merge=false`): una riga per scadenza, un preventivo per sede. La doppia verifica GVR non si fa di default: un'attrezzatura con funzionamento e integrità ha due righe distinte; la combinazione (funzionamento + integrità ecc.) si sceglie a mano modificando la singola riga. Prima verifica periodica o successiva proposta dalla scheda; per la prima periodica GVR la colonna di tariffa dipende da «soggetta a messa in servizio» (art. 4 D.M. 329/04) o no (art. 5), che va compilato. Realizzata nella 0.12.8. Testo dell'utente: «se cerco le verifiche scadute di un cliente non ho modo di selezionarle tutte o qualcuna (con un flag a sinistra)?»; «è da scadenza che in garda generiamo i preventivi (righe)»; «ricorda che la doppia verifica GVR NON la facciamo di default. se ho un'attrazzatura, ad es., con funzionamento e integrità, devi creare due righe distinte. quando edito la singola riga di preventivo posso modificare il tipo verifica mettendo funzionamento, integrità, funzionamento + integrità, etc.» | Utente, 11/10/2026, 19:16–19:19 |
| **R129** | **Il preventivo DM contiene solo le verifiche dell'allegato VII D.Lgs. 81/08**: GVR funzionamento, integrità e visita interna; verifiche SC/SP; prime periodiche e successive; solo attrezzature non esenti. CND, indagini supplementari, efficienza delle valvole e verifiche in regime volontario ISO 17020 sono **attività EX** (sezionale EX). Garda non le preventiva: si progetteranno sul modello di iec. In Scadenze, filtro «Attività EX» e comando «Prepara preventivo EX» (oggi solo informativo). Realizzata nella 0.12.9. Testo dell'utente: «il preventivo AD_dm che riguarda le verifiche allegato VII D.Lgs. 81/08 ha unicamente verifiche periodiche (e prime periodiche) di attrezzature di sollevamento, verifiche periodiche (e prime periodiche) di funzionamento, visita interna e integrità di attrezzature e insiemi GVR. Garda NON implementa attualmetne la preventivazione di attività "extra" […] Al momento mi interessa che il preventivo DM filtri SOLO le verifiche allegato VII D.Lgs. 81/08. Piuttosto metterei un filtro / comando "prepara preventivo EX", fermo restando che "prepara preventivo DM" può attingere solo da verifiche sc, sp, gvr, di attrezzature non esenti. E' un aspetto molto importante.» | Utente, 12/10/2026, 07:28 |
| **R130** | **Schede ridimensionabili:** maniglia sul bordo e «a tutto schermo»; larghezza predefinita in proporzione alla finestra; larghezza scelta ricordata. Vale per tutte le schede. Realizzata nella 0.12.9. Testo dell'utente: «scelto pannello a e b» (proposte (a) e (b) del documento 28, punto 8) | Utente, 12/10/2026, 07:51 |
| **R131** | **Licenza gestionale per sede del cliente**, senza rinnovo automatico, monitorata da un menu di Gestione. Avviso alla scadenza; proposta nel primo nuovo preventivo DM della sede. Da realizzare: mancano la data di inizio e i giorni di anticipo dell'avviso. Testo dell'utente: «licenza gestionale no rinnovo automatico (però devo porla monitorare da un menu apposito su "gestione"»; «la licenza è per sede cliente. quando scade non sarebbe male un altert e poi proporla nel primo nuovo preventivo dm» | Utente, 12/10/2026, 07:51–07:53 |
| **R132** | **Ruoli distinti per attività.** Amministratore e segreteria comuni (Federico: «segreteria comune»); RT DPR, RT DM, Verificatore DPR, Verificatore DM, Verificatore DM e DPR. I permessi tecnici (verifiche, verbali, strumenti, firme, INAIL, riesame del contratto) valgono solo nell'attività del ruolo; l'RT ha una sola attività. Testo dell'utente: «verificatori e RT vanno sdoppiati di _dm e _dpr, magari pensando a dm_e_dpr per chi ha entrambe le abilitazioni (verificatori, non RT)»; scelta fra ruolo + abilitazioni e ruoli distinti: «ruoli distinti direi» | Federico, 12/10/2026, 08:00 e 13:30 | realizzata nella 0.13.1 |
| **R133** | **Il gestionale integrato si chiama NEXUS** (Federico, 12/10/2026, 12:19). Logo scelto alle 12:48: proposta 1 «Incrocio» di Claude (due tratti intrecciati che formano la X; «x» verde nella scritta «nexus»), sottotitolo «INTEGRATED HUB», colori del programma (blu notte `#101f38`, verde `#2e807c` / `#56b7ad`). Versione chiara per la schermata di accesso, versione scura per il menu, icona sola per la scheda del browser. File in `gestionale/static/img/nexus/`. Si applica dalla 0.13.1: titoli, menu, accesso, nome di ZIP e cartella; nomi tecnici interni, `.bat`, cartelle dei dati e `config.json` invariati; VerbalizzAI mantiene il suo nome come modulo di NEXUS | Federico | deciso, dalla 0.13.1 |
| **R134** | **Revisione di un verbale DM emesso** come in AD_DPR (VerbalizzAI): stesso numero, dicitura «sostituisce il verbale n. … emesso il …», il precedente resta in archivio come sostituito. Testo dell'utente: «revisione ok come proposto e già praticato per dpr» | Federico, 12/10/2026, 17:02 | **realizzato nella 0.16.0** |
| **R135** | **Annullamento di un verbale DM emesso**: lo può fare il verificatore o l'RT, con motivo; la numerazione non cambia (il numero resta occupato, il verbale compare come annullato). Testo dell'utente: «annullamento, lo può fare verificatore o rt. la numerazione non cambia, resta così» | Federico, 12/10/2026, 17:02 | **realizzato nella 0.16.0** |
| **R136** | **Modelli dei verbali DM** (M14-PO01_dm GVR, M11-PO01_dm SC/SP): struttura approvata; la **grafica** (logo, caratteri, colori…) va allineata ai modelli M01, M02, M03 di VerbalizzAI. Comporta una nuova revisione dei modelli M14 e M11 del sistema di gestione. Testo dell'utente: «i modelli ok, però devi aggiornare la grafica (logo, font, colori etc.) ai modelli m01, m02, etc. di verbalizzAI» | Federico, 12/10/2026, 17:02 | **realizzato nella 0.16.0**: rev. 03 in archivio «da approvare», da mettere in uso dopo l'approvazione |
| **R137** | **Ambito AD_DPR / AD_DM / I&C solo sul cliente, ereditato dalle sedi operative.** La sede non ha più indicatori propri; ricerche, filtri e accensione automatica usano il cliente; le sedi doppie (R116) si riconoscono dal contenuto. Modifica in parte R114 e R115. Dettagli e domanda aperta nel documento 36, C1. Testo dell'utente: «il flag "ad_dpr", "ad_dm", "I&C" va bene, ma deve essere presente in cliente ed estendersi alle sedi operative del cliente, invece è presente sia in cliente che in sede operativa» | Federico, 12/10/2026, 17:15 | **realizzato nella 0.16.0** |
| **R138** | **Accettazione / ordine del cliente sul preventivo:** si caricano i file (preventivo firmato, ordine) e si registrano i dati per la fattura elettronica come nella linguetta «Fattura» di Garda (tipo doc.: ordine, contratto, convenzione, ricezione, fattura collegata, DDT, fattura principale; numero, data, CIG, CUP, commessa); passano da soli nella fattura. Dettagli e due domande aperte nel documento 36, C2. Testo dell'utente: «quando il cliente emette accettazione / ordine sarebbe l'ideale poter caricare il pdf del preventivo accettato / ordine emesso. n.b. bisogna poter registrare i dati necessari per il tracciato elettronico della fattura (elettronica)» | Federico, 12/10/2026, 17:19 | **realizzato nella 0.16.0** |
| **R139** | **Fattura anche dalle verifiche e dagli incarichi DM**: resta «Fattura le selezionate…» dalle righe dei preventivi (R125, come Garda); in più lo stesso comando negli elenchi Verifiche e Incarichi DM e il pulsante «Fattura questa verifica…» nella scheda riesaminata (al posto del testo «fase 6»). Stesse regole e stesse righe di fattura, che nascono sempre dalla riga del preventivo. Dettagli nel documento 36, C4. Testo dell'utente: «da dove si genera la fattura? in garda da righe preventivo, mi piacerebbe rimanesse ma anche da verbali» | Federico, 12/10/2026, 17:33 | **realizzato nella 0.16.0** |
| **R140** | **Copia di cortesia della fattura come quella di Garda**: intestazione AD con logo, tipo, numero e data (anche nella bozza, con «BOZZA»), riquadro cliente, righe con descrizioni come Garda, riepilogo IVA, totali, pagamento con banca, IBAN e scadenze, Tot. dovuto, pagine. Riferimenti a preventivo e ordine una sola volta in fondo se uguali per tutte le righe. Numero nel formato di Garda «390/2026/DPR» (da verificare sugli XML veri). Dettagli nel documento 36, C5. Testo dell'utente: «la bozza di fattura è bruttissima. tieni conto che deve sempre riportare in alto l'intestazione di AD, ovviamente il cliente, ovviamente le singole righe, nonché il riferimento al preventivo e all'ordine (se uguali per ogni riga unico in fondo …)»; «ma poi manca numero e data, manca proprio tutto» | Federico, 12/10/2026, 17:36 | **realizzato nella 0.16.0**; formato della nota di credito `…/DPR-NC` da verificare su XML veri |
| **R141** | **Gruppo della nuova attrezzatura e PSV a parte**: da Attrezzature GVR il nuovo è GVR fisso; da SC/SP si sceglie solo fra SC e SP; nessuna maschera attrezzatura propone PSV. PSV, dischi di rottura e valvole di intercettazione si gestiscono in una sezione «Accessori · PSV» propria, senza matricola INAIL, con taratura e collegamenti «protegge» alle attrezzature della sede. Riapre il sospeso «valvole di sicurezza» del documento 30. Dettagli nel documento 36, C9. Testo dell'utente: «se vado su nuova attrezzatura nella sezione gvr mi deve preimpostare gvr, se vado su sc/sp mi deve far scegliere, non mi deve dare tutte le opzioni. ti ricordo che le psv andrebbero gestite a parte (accessori - psv) perché non hanno matricola» | Federico, 12/10/2026, 17:43 | **realizzato nella 0.16.0** |
| **R142** | **Date alla registrazione di una nuova attrezzatura**: la maschera chiede, per ogni attività del gruppo (SC/SP: verifica periodica; GVR: funzionamento, integrità, visita interna), ultima data e riferimento facoltativi e **prossima data obbligatoria**, così l'attrezzatura entra subito nelle Scadenze. Sono date dichiarate; dopo il primo verbale NEXUS le date si calcolano come oggi. Nei GVR obbligatorie le prossime di funzionamento, integrità e visita interna se applicabile (Federico, 17:49). Dettagli nel documento 36, C12. Testo dell'utente: «quando registri un'attrezzatura (SC/SP o GVR) ti chiede il riferimento di ultima prossima verifica? n.b. dalla prima registrazione di un verbale è autocalcolato, ma quando la registro ex novo no! solo prossima verifica è obbligatorio (per poter filtrarlo in scadenze)» | Federico, 12/10/2026, 17:46 | **realizzato nella 0.16.0** |
| **R143** | **Più ruoli per utente, a caselle**: ogni permesso vale nell'attività del ruolo che lo dà (es. RT DPR + Verificatore DM: RT nel DPR, verificatore nel DM); il primo spuntato è il ruolo principale mostrato negli elenchi. Testo dell'utente: «l'utente in questione è RT (e verificatore) DPR ma anche verificatore DM, forse conviene cambiare il criterio di assegnazione del ruolo (flag su scelta multipla)?» | Federico, 12/10/2026, 17:58 | **realizzato nella 0.16.0** |

**Superate:**
- **D77**, per l'ordine di sviluppo: superata da R99/R106, e in attesa di R112;
- **D78**, per la versione di VerbalizzAI: superata da R111;
- **R63**, in parte: superata da R110;
- **AD-31** come «scostamento ereditato»: ora deroga approvata (R110);
- **R112 / § 7**, per l'ordine delle consegne 0.13–0.15: aggiornato dopo R123 (verbali DM prima delle fatture DPR);
- **R117**, per la forma del menu: modificata da R126 (gruppi richiudibili, cataloghi in una schermata, impostazioni in Configurazione).

### 3.3 Decisioni di questo progetto da riportare nel registro della chat di sviluppo

Dalle risposte del documento 17 (08/10/2026), assenti dal registro R:
- **Q8:** la modalità di pagamento dipende dal **cliente**, non dal settore.
- **Q9:** nel DM il preventivo è **per sede operativa**. Già in R come regola Garda.
- **Q10:** la licenza gestionale è **solo per i clienti DM**, **annuale**, con **monitoraggio della scadenza**. Il ramo ChatGPT la tratta solo come voce opzionale del preventivo DM.
- **Q11:** la separazione tra le società basta a livello di interfaccia.
- **Q12:** AD ha **tre sezionali: DPR, DM, EX**; I&C fattura separatamente.
- **Q13:** la verbalizzazione DM di Garda va migliorata (Word poco curati, niente PDF definitivi). Coperta da R104 e ora da R123.
- **Q14:** **EX = verifiche in regime volontario** ISO 17020, più CND ed efficienza delle valvole di sicurezza. Un'attrezzatura passa al DM solo dopo il cambio di stato, quando INAIL la mette in servizio. **Numerazione delle verifiche ISO 17020 autonoma.**
- **Q15:** per EX, **un contatore GVR e uno SC-SP**, come nel DM.
- **Q16:** le 47 verifiche numerate DM su attrezzature «ISO17020» sono **rinviate alla prova di migrazione**.
- **Sigla dei verbali EX:** da scegliere quando si realizza EX. Proposta: `VV/GVR/001/26`, `VV/SC/…`, `VV/SP/…`.
- **D79:** I&C condivide anagrafica clienti/sedi, attrezzature di AD_dm e motore di commesse e fatturazione; le sue attività non sono verifiche con verbale.
- **D80:** documenti dei preventivi con il metodo dei verbali.
- **D81:** importazione da ingecert in archivio separato.

**Errore da correggere nel documento 26, § 3:** la tabella attribuisce a I&C le «verifiche volontarie». Per R48 e Q14 appartengono alla **serie EX di AD**.

---

## 4. Passo A · Correzioni sulla 0.12.1-wip1 — ✔ completato nella 0.12.2

Tutte le voci A1–A7 sono realizzate e provate nella 0.12.2 (documento 30). A5 resta come indicato: fatture DM e INAIL invariati fino al passo D. Punti aperti emersi: `tipo_prox_verifica` del bene dopo la riapertura dell'unico lavoro chiuso (da confrontare con Garda); beni importati senza famiglia GVR non ammettono la visita interna (l'import del passo B deve portarla).

| N. | Correzione | Riscontro di Claude sul codice |
|---|---|---|
| **A1** | **Indipendenza (R110).** DM: ripristinare il blocco ed estenderlo alla programmazione. DPR: aggiungere il blocco alla programmazione. In entrambi: blocco su programmazione, registrazione ed esecuzione con «No», predefinito «Sì» | DPR `verifiche/servizio.py`: blocchi presenti solo in registrazione (riga 222) e in un secondo punto (riga 309), **assente in `programma`**. DM: blocco rimosso nella 0.12.1-wip1 (delta, § «Indipendenza») |
| **A2** | **Riesame (R108/R109).** Completare: nota visibile al tecnico assegnato senza accesso agli altri lavori; ciclo correzione → nuovo PDF → chiusura → nuovo riesame; ricalcolo CND al rientro; date con e senza precedenti e con date iniziali importate; nessuna riscrittura di fatture o lotti INAIL già emessi | Delta 0.12.1-wip1: implementato il rientro, mancano gli altri punti |
| **A3** | **Storico dei riesami** del preventivo (DPR e DM) e del verbale (DPR e DM): più righe per lo stesso oggetto, con autore, data, esito, note e versione esaminata | Esiste la tabella `preventivi_riesami`: da verificare che conservi più riesami e i campi richiesti |
| **A4** | Portare dal WIP il controllo della **visita interna** solo per GV/INS GV (DM-07), con casi di test pertinenti | § 2.3 |
| **A5** | **Fatture DM e INAIL** (bozza 0015): non estenderle ora. Restano nel codice, fuori dai menu, fino al passo D | Delta: nessun test dedicato |
| **A6** | **Migrazione 0015:** provarla con incarichi e righe fattura già presenti a 0014, e provare il blocco del downgrade con dati nuovi. Controllare che non abbia il difetto di atomicità visto nel WIP | Delta: provata solo su archivio sintetico vuoto |
| **A7** | **Test di contratto con VerbalizzAI:** a ogni consegna, confronto automatico della copia incorporata con lo standalone 1.0.1 rc2 (solo import relativi ammessi) | `test_ponte_contratto.py` e `strumenti/aggiorna_verbalizzai.py` già presenti |

Consegna attesa del passo A: **0.12.2** con migrazione **0016** (se serve), README, documento delle differenze, test dedicati per A1–A4 e A6.

---

## 5. Domande ancora aperte (le uniche)

1. **R112, ordine dei lavori:** conferma della proposta del § 7.
2. **IEC-03:** in Garda I&C si possono riaprire sottopunti di un preventivo accettato per nuove scadenze. Vale anche lì l'immutabilità con preventivo integrativo, oppure si conserva la riapertura? Va deciso prima del passo B, perché incide sul modello.
3. **Esiti Aruba:** con quale modalità importarli (R47, R67). Va deciso entro il passo C.
4. **R70:** il passaggio visivo tra gestionale e pagina Verbali non convince. Senza toccare VerbalizzAI si può agire solo sulla cornice del gestionale.
5. **COES-01 e IMP-01/02:** proprietà dei campi nel riallineamento e semantica del modello XLS. Da affrontare con casi concreti quando servono, non prima.
6. **Q16 e sigla EX:** al momento pertinente (§ 3.3).
7. **Fatture DM aggregate su più verifiche e lotto INAIL:** caso da verificare nel passo D.

---

9. **Dalla 0.12.4 (documento 32):**
   - (a) ~~scelta della sede nel nuovo preventivo DM~~: deciso con R115;
   - (c) ~~fonte unica dei dati tecnici dell'impianto~~: deciso con **R122** (fa fede la scheda di VerbalizzAI; realizzazione nella 0.12.7);
   - (d) **schermate «Verifiche» per ruolo** (amministrazione e RT da una parte, verificatore dall'altra, DPR e DM): da preparare prima come mockup;
   - (e) errore «Il server di VerbalizzAI non risponde» sull'anteprima PDF, sul PC dell'utente: servono `gestionale.log` e la finestra del programma;
   - (b) ~~sedi doppie~~: deciso con R116 (0.12.5: 71 unite nell'importazione, 83 coppie da confermare in «Possibili doppioni»); resta aperta la sola ipotesi di destinatari dei verbali diversi per ambito con lo stesso indirizzo di una sede DPR dello stesso cliente vanno unite nella migrazione vera, con conferma caso per caso?

10. **Dalla rilettura del codice di Garda (0.12.8):** Garda consente di cambiare il tipo di verifica GVR (funzionamento, integrità, combinazione) **sulla verifica**, dopo il preventivo. Nel gestionale si cambia solo sulla riga del preventivo. Da decidere con l'utente se serve anche sulla verifica (incarico DM).

8. **Interfaccia AD_dm (11/10/2026):** il canvas «Mockup AD_dm» v1 (elenco attrezzature, scheda attrezzatura, preventivo DM, incarico e verbale GVR, ricavati dagli screenshot di Garda) è accettato dall'utente **come prima approssimazione**, non come configurazione definitiva delle maschere. Restano da decidere: (a) esito della verifica in una sola scelta, che unisce l'esito di Garda e gli interruttori adeguato / non adeguato del verbale; (b) scheda attrezzatura su una pagina con indice al posto delle linguette; (c) date derivate da verbale correggibili solo dal verbale. Si riprendono quando si realizza AD_dm (passo D).

## 6. Rilievi di audit da conservare

**Registro dei rilievi della revisione della 0.12.6 (AD-REV-001…005, AD-DEC-001).** Ricevuto dall'utente l'11/10/2026. Nella 0.12.8 tutti e cinque sono corretti e riprodotti con prove nell'applicazione completa (`tests/test_rilievi_revisore.py`): esito «risolto da verificare». AD-DEC-001 è decisa con R122. La chiusura spetta al revisore. Registro aggiornato: `documentazione/Registro_rilievi_Gestionale_AD_0.12.8.txt` nello ZIP.


La matrice dei 66 rilievi (documento 26, § 14) e la matrice 26 della 0.12 (151 regole) restano l'elenco di comportamento e di test. Non vanno ricopiate qui. Si conservano integralmente nel pacchetto di ripresa verificata.

Priorità per la struttura (passo B):
- COM-01 (identità e mapping app/tabella/id);
- COM-04 (cancellazioni e riferimenti);
- COM-05 (concorrenza e numerazioni);
- MIG-01…07 (import, doppio storico fiscale, precisione degli importi, unicità);
- DPR-05: **il nuovo modello impianti ha perso il vincolo Garda di unicità sede + tipologia**. Da valutare con R73 prima della migrazione.

---

## 7. Ordine dei lavori — R112 (deciso l'11/10/2026: opzione A)

**Decisione:** AD_dpr «viable», completo ma non in produzione, poi l'integrato. Non andando in produzione, il modello resta modificabile senza rischi su dati veri. La migrazione a secco dei tre gestionali resta dentro il percorso come controllo del modello.

**Tempistica (Federico, 12/10/2026, 13:14):**
- VerbalizzAI in produzione da fine ottobre 2026;
- NEXUS per il D.P.R. 462/01 in sviluppo da ottobre, in produzione a marzo 2027 (stima), con collaudo dal vivo fino a maggio;
- settore D.M. 11.04.2011 sviluppato in parallelo;
- se il collaudo del D.P.R. va bene, tutto il sistema in produzione a giugno 2027.

Il D.P.R. detta il percorso critico.

**Consegne (aggiornamento 1.12, 12/10/2026):**
- 0.12.7–0.12.10 · ✔ consegnate:
  - R122;
  - note N1–N9;
  - documento 28;
  - maschere AD_DM;
- 0.13.0 · ✔ consegnata: VerbalizzAI_DM, prima parte;
- **0.13.1** · ✔ consegnata:
  - nome **NEXUS** e logo (R133);
  - **ruoli distinti per attività** (R132);
  - rilievi AD-REV-006…008;
- **0.14.0** · ✔ consegnata · **fatture DPR complete pari a Garda** (Federico, 12/10, 13:29), priorità per marzo 2027:
  - XML;
  - controlli;
  - note di credito;
  - incassi;
  - esiti di Aruba;
- **0.15.0** · ✔ consegnata (anteprima, firma ed emissione, Aggiorna/Conserva); **0.15.1** revisioni e annullamento dopo le risposte di Federico · **verbali DM finiti**:
  - modelli M-DM-GVR e M-DM-SCSP da approvare;
  - anteprima «BOZZA», firma ed emissione;
  - revisioni, annullamento e riesame;
  - storico di adsrl;
- poi:
  - funzioni DPR mancanti: esiti sospeso e a vuoto, affiancamento, CIG/CUP, contributo INAIL 5%, copia e dismissione degli impianti, unicità per sede e tipologia;
  - registrazione in blocco DM (documento 28, punto 13: deciso);
  - licenze gestionale (R131);
  - 49 regole ingecert e importazione completa con lo storico economico;
  - migrazione a secco ripetuta dei tre database;
  - installazione sul server Windows, validazione § 6.2.9 e formazione (febbraio 2027).

La tabella seguente è la proposta originaria, conservata come riferimento per le fasi successive (DM, I&C).

**Principio:** prima la **struttura** per tutti e tre i gestionali, poi le **funzioni** un modulo alla volta. Il rischio vero non è rimandare le funzioni di DM e I&C. È scoprire dopo la produzione DPR che il modello dati non regge attrezzature, PSV e scadenze condivise con I&C.

| Passo | Contenuto | Uscita |
|---|---|---|
| **A** | Correzioni del § 4 | 0.12.2 |
| **B · Nucleo provato sui tre** | **Migrazione a secco completa dei tre dump** (adsrl, ingecert, iec) nel database integrato, con quadrature: clienti comuni fusi, beni DM con camere/PSV/scadenze, attività I&C sugli stessi beni, storico fiscale dei tre sezionali AD e di I&C, documenti. Motore fatture multi-emittente e multi-sezionale. Decisione IEC-03. Vincolo DPR-05 | Rapporto di quadratura; schema stabile |
| **C · AD_dpr completo** | XML pari a Garda (FIN-04…06), esiti Aruba, import economico da ingecert, numerazioni di partenza (D76), collaudo Windows, VPS con HTTPS e backup, validazione § 6.2.9, prova in parallelo con Garda | Produzione AD_dpr **quando è pronto** |
| **D · AD_dm** | Fatture DM collegate (dalla bozza 0015), INAIL, EX, licenza gestionale, dashboard (R105), import XLS del parco (R96) | Collaudo DM |
| **E · I&C** | Punti e sottopunti, attività e report, provvigioni e fatture dei collaboratori con blocchi, scadenze condivise | Collaudo I&C |

**Regola di passaggio:** AD_dpr non va in produzione finché la migrazione a secco dei tre gestionali (passo B) non quadra. I passi D ed E possono procedere con AD_dpr già in esercizio, perché aggiungono funzioni senza cambiare la struttura.

---

## 8. Regole per la chat di sviluppo

1. **Una sola chat.** Non avviare istanze parallele.
2. **Ogni consegna** contiene:
   - ZIP con versione univoca e migrazione con revisione univoca: mai due migrazioni con la stessa etichetta;
   - README di installazione e aggiornamento;
   - documento delle sole differenze rispetto alla consegna precedente;
   - test effettivamente eseguiti, con comando e risultato;
   - ciò che non è stato verificato.
3. **Decisioni:** la chat di sviluppo non assegna numeri R. Riporta le nuove decisioni con il testo esatto della domanda e della risposta dell'utente; il numero si assegna nel registro di questo progetto. Ultimo numero assegnato: **R143**. Prossimo: **R144**.
4. **Garda è il riferimento funzionale** (R73, R101, R102). Ogni scostamento richiede regola Garda, differenza, effetto e consenso esplicito.
5. **VerbalizzAI non si modifica** (R111). Il gestionale si adatta a VerbalizzAI, non il contrario.
6. **Non trasformare** «analizzato» in «implementato», né «implementato» in «collaudato».

---

## 9. Materiali da allegare alla nuova chat (aggiornato al 12/10/2026, sera)

1. **Questo documento (18).** Prevale su tutti i documenti di ripresa precedenti.
2. **Base software:** `NEXUS_0.16.0_2026-10-12.zip` (SHA-256 `9f715435fc3f27dcf37e5d11b534ba1b277b2046c81a0ff5595009d876e69639`). Contiene il codice (senza la cartella .git), `documentazione/` (differenze fino al 43) e `report_collaudo/pytest_0.16.0.txt` (317 test). Stato del codice: documento 37.
3. **Lavoro da fare, nell'ordine:**
   - collaudo della 0.16.0 da parte di Federico: nuove osservazioni nel documento **36** da C17;
   - approvazione delle rev. 03 di M14 e M11 (R136);
   - § 7 di questo documento: importazione completa da Garda, XML delle fatture alla fine.
4. **Riferimenti di dominio:** documenti 16 e 17 (analisi e modello), 24 (verbali DM come VerbalizzAI), 30 (maschere AD_DM).
5. **Solo sul PC di Federico, mai nel progetto né in un artefatto pubblicato:**
   - dump di Garda (`ingecert`, `adsrl`, `iec`);
   - verbali DM di riferimento e PDF di cortesia delle fatture di Garda;
   - file delle credenziali.

   Si allegano alla chat solo quando servono, e i loro dati non vanno nel codice, nei test o nella documentazione.
6. **Solo per un confronto:** `VerbalizzAI_AD_v1.0.1_rc2.zip`, in produzione e da non modificare (R111).

---

## 10. Prompt per un'altra istanza (ripresa o verifica)

> **Aggiornamento 1.17 (12/10/2026, sera).** Serve se lo sviluppo prosegue altrove, oppure per far **verificare** una consegna da un'istanza indipendente.

> Riprendi lo sviluppo di **NEXUS**, il gestionale integrato di AD S.r.l. (AD_DPR D.P.R. 462/01, AD_DM D.M. 11.04.2011, poi I&C), che sostituisce i gestionali di Garda e incorpora VerbalizzAI. Lavori per Federico Amateis.
>
> 1. **Leggi prima** il documento 18 «Ripresa unica», che prevale su tutto, poi il documento 37 (stato del codice) e il documento 36 «Note di collaudo NEXUS».
> 2. **Base:** `NEXUS_0.16.0_2026-10-12.zip`. Controlla SHA-256 e test (`pytest`, 317 attesi; LibreOffice per i test «pdf_vero») **prima** di cambiare qualsiasi cosa.
> 3. **Il codice si scrive solo quando Federico dà il via.** Se chiede di annotare, annoti nel documento 36 (C1, C2…) e non tocchi il codice. Nel dubbio chiedi prima di fare.
> 4. **Registro:** D1–D81 e R01–R143 come nel § 3.
>    - Se lavori nel progetto di Claude, il prossimo numero è R144.
>    - Altrimenti non assegnare numeri: riporta la domanda e la risposta esatta di Federico.
>    - Rilievi del revisore: `documentazione/Registro_rilievi_Gestionale_AD_*.txt`, identificativi AD-REV-nnn invariati.
> 5. **Ogni consegna è completa:**
>    - ZIP con il nome `NEXUS_x.y.z_AAAA-MM-GG.zip` (git archive);
>    - documento «Differenze» in `documentazione/` e copia nel progetto;
>    - `report_collaudo/pytest_x.y.z.txt`;
>    - aggiornamento di questo documento (§ 2 e § 3).
>
>    Prove: suite completa e prova dell'interfaccia con un browser, senza errori JavaScript.
> 6. **Vincoli:**
>    - VerbalizzAI 1.0.1 rc2 non si modifica (R111);
>    - dati veri dei clienti mai in codice, test, documenti o artefatti pubblicati: i dati di prova sono inventati;
>    - credenziali: non si usano e non si inseriscono;
>    - gli XML delle fatture si rifiniscono alla fine, con XML veri di Garda e prova su Aruba (decisione del 12/10, 17:37).
> 7. **Stile:** italiano semplice e preciso, risposte brevi. Non dichiarare implementato o collaudato ciò che non lo è.
