# 36 · Note di collaudo di NEXUS «da zero» (dal 12/10/2026)

12/10/2026 · Redatto da Claude · Base provata: **NEXUS 0.15.0** (schema 0022).

Federico prova il sistema partendo da un archivio vuoto. Qui raccolgo le osservazioni in ordine di arrivo. Per ora **solo annotazione**: il codice è fermo («non scrivere altro codice per il momento», 17:02; «annota tutto e non scrivere codice», 17:15). Ogni punto si realizza quando Federico dà il via.

> **Stato al 12/10/2026, sera: consegnata la NEXUS 0.16.0** (schema 0027), che realizza C1, C2 e C4–C16. Esclusi per scelta di Federico: gli XML delle fatture (C6, «lo facciamo bene alla fine») e il modello «impianto termico» (C16, «lascia stare impianto termico»). C3 era una domanda: l'importazione completa da Garda resta da fare, documento 18 § 7. Dettagli: documento 43 nello ZIP, copia nel progetto `claude/38_Differenze_0.16.0_2026-10-12.md`. Le osservazioni nuove continuano da C17.

---

## C1 · Ambito AD_DPR / AD_DM / I&C solo sul cliente, esteso alle sue sedi (R137) — ✔ realizzato nella 0.16.0

**Osservazione (17:15).** «parto con la registrazione cliente. il flag "ad_dpr", "ad_dm", "I&C" va bene, ma deve essere presente in cliente ed estendersi alle sedi operative del cliente, invece è presente sia in cliente che in sede operativa.»

### Come funziona oggi (R114, 0.12.4, migrazione 0016)

**Indicatori:** cliente e sede hanno ciascuno i propri tre indicatori (`ambito_dpr`, `ambito_dm`, `ambito_iec`):
- la sede nuova senza indicazioni copia gli ambiti del cliente;
- gli indicatori si accendono da soli quando entra un oggetto: un impianto accende DPR sulla sede, un'attrezzatura o un accessorio accende DM sulla sede, un preventivo accende il suo ambito;
- la sede accesa accende anche il cliente;
- si spengono solo a mano. Il cliente non perde un ambito che una sua sede ha ancora. La sede non perde DPR se ha impianti, né DM se ha attrezzature.

**Dove si vedono:**
- nella scheda del cliente e in quella della sede;
- nelle griglie Clienti («Cliente AD_DPR…») e Sedi («Sede AD_DPR…»).

**Chi li usa:**
- la ricerca dei clienti nel nuovo preventivo DPR (R115) usa il cliente;
- la ricerca delle sedi nel nuovo preventivo DM (R115) usa la **sede**;
- la proposta di unione delle sedi doppie (R116, importazione AD_dpr + AD_dm) confronta gli ambiti delle due sedi;
- i filtri «Attività» degli elenchi usano l'una o l'altra a seconda dell'elenco.

### Cosa chiede Federico

L'ambito è un **dato del cliente**. Le sedi lo **ereditano** e non hanno un proprio indicatore da gestire. È già scritto nel testo originale di R114 («un attributo legato a cliente che delimiti l'ambito») e di R115 («le sedi associate a clienti AD_DM»). La 0.12.4 è andata oltre, mettendolo anche sulla sede.

### Proposta di realizzazione (da confermare al via del codice)

1. **Interfaccia:**
   - nella scheda della sede spariscono le caselle;
   - al loro posto una riga di sola lettura: «Ambito: dal cliente (AD_DPR, AD_DM)»;
   - nella griglia Sedi le colonne diventano «Cliente AD_DPR / AD_DM / I&C», cioè quelle del cliente, sempre filtrabili.
2. **Filtri:**
   - il nuovo preventivo DM mostra le sedi dei **clienti** AD_DM;
   - gli elenchi filtrati per «Attività» usano l'ambito del cliente.
3. **Accensione automatica:** un impianto, un'attrezzatura o un preventivo accendono l'ambito direttamente sul **cliente** della sede.
4. **Spegnimento:**
   - si fa sul cliente;
   - è rifiutato se una qualsiasi sua sede ha ancora impianti non dismessi (DPR) o attrezzature e accessori non dismessi (DM), oppure preventivi dell'ambito aperti;
   - il messaggio dice quali sedi lo impediscono.
5. **Sedi doppie (R116):** la proposta di unione non guarda più gli indicatori della sede ma il **contenuto**. Una sede con impianti e l'altra con attrezzature, stesso cliente e stesso comune: la proposta resta com'è oggi.
6. **Dati esistenti:**
   - le colonne della sede si possono lasciare nel database, inutilizzate, per non toccare la migrazione 0016 e permettere il ritorno indietro;
   - in alternativa si tolgono con una migrazione **0023** (scelta tecnica, senza effetti per l'utente);
   - prima di spegnerle si riportano sul cliente gli ambiti accesi solo sulla sede. Oggi non dovrebbe succedere, perché la sede accende già il cliente; la migrazione lo controlla comunque.
7. **Importazione da Garda:** invariata nella sostanza. Il cliente di adsrl diventa AD_DM, quello di ingecert AD_DPR, e se è in entrambi ha i due ambiti.

**Effetti collaterali da verificare:**
- test di R114, R115 e R116 (`test_ambiti*`, `test_doppioni*`, preventivi DM);
- maschere AD_DM del documento 30 (colonne predefinite delle sedi).

### Domanda aperta (una sola, da fare al via del codice)

Un cliente AD_DPR e AD_DM con più sedi può avere una sede solo DPR e una solo DM: per esempio, lo stabilimento con la cabina e il magazzino con i serbatoi. Con l'ambito solo sul cliente, il nuovo preventivo DM mostrerà **tutte** le sedi del cliente, anche quella che ha solo impianti. La mia proposta è accettarlo: si sceglie la sede giusta a mano, e dopo il primo preventivo la sede ha le sue attrezzature. In alternativa, nella ricerca del preventivo DM, le sedi che hanno già attrezzature DM compaiono per prime.

**Decisione:** **R137** (proposta, da confermare). Sostituisce in parte R114 (indicatori sulla sede) e aggiorna R115 (ricerca delle sedi DM).

---

## C2 · Accettazione / ordine del cliente: PDF allegato e dati per la fattura elettronica (R138) — ✔ realizzato nella 0.16.0

**Osservazione (17:19).** «quando il cliente emette accettazione / ordine sarebbe l'ideale poter caricare il pdf del preventivo accettato / ordine emesso. n.b. bisogna poter registrare i dati necessari per il tracciato elettronico della fattura (elettronica).» Con due schermate di Garda: scheda del preventivo, linguetta **FATTURA**.

### Garda oggi (schermate)

La scheda del preventivo ha le linguette Dati generali, Riesame, **Fattura** e Altro. Nella linguetta Fattura ci sono:
- **Tipo doc.**, a scelta fra:
  - Ordine d'acquisto;
  - Contratto;
  - Convenzione;
  - Ricezione;
  - Fattura collegata;
  - **Doc. di trasporto**;
  - **Fattura principale**;
- **N°** e **Data**, entrambi «obbligatorio se vuoi che esca in fattura»;
- **CIG**, **CUP**, **Commessa / Convenzione**.

### NEXUS 0.15.0 oggi

**Sul preventivo (DPR e DM)** ci sono:
- «riferimento ordine» (testo) e data dell'ordine;
- un'«evidenza dell'accettazione», solo testo.

Non si può **caricare un file**: i documenti del preventivo sono solo il Word e il PDF generati da NEXUS e i ritocchi Word.

**Sulla fattura** (0.14, documento 41 § 2) ci sono i «documenti collegati» completi: tipo, numero, data, CIG, CUP e commessa, nei blocchi FatturaPA giusti. Si inseriscono però **nella bozza della fattura**, e dal preventivo passano solo il numero e la data dell'ordine. Mancano:
- i tipi **DDT** (blocco DatiDDT);
- **Fattura principale** (blocco FatturaPrincipale, previsto per le fatture accessorie di trasporto: per AD quasi mai, ma va tenuto per parità con Garda).

### Proposta (da confermare al via del codice)

1. **Sezione «Accettazione / ordine del cliente»** nella scheda del preventivo DPR e DM, come la linguetta Fattura di Garda, con:
   - **file allegati**: il preventivo firmato per accettazione, l'ordine del cliente, eventuali email in PDF;
     - sono più di uno, in PDF, immagine o .eml/.msg;
     - si possono scaricare;
     - restano nell'archivio documenti con impronta, data e utente;
     - non si cancellano: si sostituiscono, come gli altri documenti;
   - **dati per la fattura elettronica**: una o più righe con
     - tipo (gli stessi sette di Garda);
     - numero e data, obbligatori perché la riga esca in fattura;
     - CIG, CUP, commessa/convenzione.
2. **Accettazione delle righe:** il file caricato vale come **evidenza dell'accettazione** (D17, ISO/IEC 17020 riesame del contratto). Il campo di testo attuale resta per le note.
3. **Passaggio in fattura:**
   - quando la fattura nasce dalle righe del preventivo, i documenti collegati del preventivo entrano **da soli** nella bozza, con tutti i dati, non solo numero e data come oggi;
   - con righe da più preventivi entrano quelli di ciascun preventivo, senza doppioni;
   - nella bozza restano modificabili, come oggi.
4. **Tipi mancanti** nell'XML e nell'elenco:
   - **DDT**: DatiDDT con numero e data;
   - **Fattura principale**: FatturaPrincipale con numero e data, nell'ordine dello schema FatturaPA 1.2.
5. **Pubblica amministrazione:** l'avviso della bozza («servono ordine o contratto con CIG») compare già nel preventivo, quando il cliente è una PA e mancano i dati.
6. **Importazione da Garda:** i dati della linguetta Fattura dei preventivi di ingecert (tipo, numero, data, CIG, CUP, commessa) si portano nei preventivi importati, con l'importazione completa (documento 18 § 7). Da verificare sul dump quali tabelle li contengono.

**Effetti:**
- serve una nuova tabella dei documenti collegati del preventivo e degli allegati di accettazione, quindi la migrazione **0023** (insieme a R137 se si fanno nella stessa versione);
- `rif_ordine` e `data_ordine` esistenti diventano la prima riga «Ordine d'acquisto».

### Domande aperte (al via del codice)

1. **Allegato obbligatorio?** Per accettare le righe del preventivo il file dell'accettazione/ordine deve essere obbligatorio, o resta facoltativo (con il testo come alternativa, per esempio «accettato per telefono il …»)? Proposta: **facoltativo, con un avviso** se manca.
2. **Riesame:** il riesame del contratto deve mostrare il file dell'accettazione, così l'RT lo vede prima di approvare? Proposta: **sì**, come collegamento nella scheda del riesame.

**Risposta di Federico (17:28):** «si segnati di implementare la nuova sezione del preventivo, evidenza dell'accettazione, il passaggio in fattura, avviso per la PA, importazione da garda». Confermati i punti 1, 2, 3, 5 e 6 della proposta, e implicitamente il punto 4 (tipi DDT e Fattura principale, parte della linguetta di Garda). Domande aperte: con il «sì» valgono le proposte, cioè allegato **facoltativo con avviso** e file visibile nel **riesame**.

**Decisione:** **R138**, confermata. Completa D36 (riferimento ordine) e FIN-04 (documenti collegati, 0.14). Da realizzare al via del codice.

---

## C3 · NEXUS vuoto: importare lo storico di Garda (domanda, 17:28) — risposta data; importazione completa ancora da fare

**Domanda.** «nexus è vuoto, c'è modo di importare lo storico di garda?»

**Risposta data:** sì, con `IMPORTA_DA_GARDA_WINDOWS.bat`, che usa i dump .sql di ingecert e, facoltativo, di adsrl. Crea un archivio separato (`GestionaleAD_dati_GARDA`), che si apre con `AVVIA_GARDA_WINDOWS.bat`. L'archivio vuoto del collaudo resta intatto.

**Cosa entra oggi:**
- **AD_dpr:** utenti (disattivati), modalità di pagamento, IVA, clienti, sedi, impianti con POD, preventivi con riesame, verifiche con numeri di verbale;
- **AD_dm:** clienti fusi, sedi, attrezzature, camere, accessori, date iniziali.

**Cosa non entra ancora:**
- fatture e incassi DPR;
- preventivi, verifiche e fatture DM;
- I&C;
- PDF dei verbali, che restano su S3 di Garda: si importa solo il nome del file.

Tutto questo è previsto nell'importazione completa (documento 18 § 7). Si aggiungono i dati della linguetta Fattura dei preventivi (R138).

---

## C4 · Da dove si genera la fattura: righe del preventivo e anche verbali (R139) — ✔ realizzato nella 0.16.0

**Domanda e richiesta (17:33)**, con la schermata della verifica VP/001/26, «Riesaminata (da fatturare)»: «da dove si genera la fattura? in garda da righe preventivo, mi piacerebbe rimanesse ma anche da verbali».

### NEXUS 0.15.0 oggi

- **Da righe del preventivo**, come Garda (N7 / R125, 0.12.8): menu Preventivi › **Righe dei preventivi**, filtro «Da fatturare», si spuntano le righe e si preme «**Fattura le selezionate…**». Nasce una bozza in Fatture, oppure le righe si aggiungono a una bozza esistente dello stesso cliente e attività. Una riga è «da fatturare» con:
  - riga accettata;
  - riesame del contratto conforme;
  - verifica DPR riesaminata e conforme, oppure incarico DM effettuato e riesaminato;
  - riga non già fatturata.

  Trasferta e voci a corpo diventano fatturabili insieme alla prima verifica fatturabile del loro preventivo.
- **Fattura a mano** da Fatture › Nuova.
- **Dalla verifica non si fattura:**
  - l'elenco Verifiche ha il filtro «Da fatturare» ma nessun pulsante;
  - la scheda della verifica riesaminata dice ancora «pronta per la fatturazione (fase 6)», un testo rimasto da prima della 0.7, quando le fatture non c'erano;
  - lo stesso vale per gli incarichi DM.

### Proposta (da confermare al via del codice)

1. **Restano le righe del preventivo**, come oggi e come in Garda.
2. **Dall'elenco Verifiche (DPR) e dall'elenco Incarichi DM:**
   - si spuntano le verifiche o gli incarichi «da fatturare» e si preme «**Fattura le selezionate…**», che si comporta come quello delle righe;
   - il programma risale alle righe del preventivo collegate e usa le stesse regole: stesso cliente e stessa attività, nessun doppione, bozza nuova o aggiunta a una bozza esistente;
   - trasferta e voci a corpo dello stesso preventivo si aggiungono da sole se non sono già fatturate, con un avviso nella bozza.
3. **Dalla scheda della verifica e dell'incarico DM riesaminati:** il testo «fase 6» sparisce e al suo posto c'è un pulsante «**Fattura questa verifica…**», con la scelta fra bozza nuova e bozza esistente del cliente. Dopo l'emissione la scheda mostra il numero della fattura con il collegamento.
4. **Permessi:** il pulsante si vede solo a chi può creare fatture (Segreteria, Amministratore), con l'attività del suo ruolo (R132).
5. **Righe della fattura:** sono identiche qualunque sia la strada, perché nascono sempre dalla riga del preventivo (stessa descrizione, stesso importo, stesso XML). Cambia solo il punto da cui si parte.

**Decisione:** **R139** (proposta, da confermare). Estende R125 (fattura da righe, 0.12.8).

---

## C5 · Copia di cortesia della fattura (PDF) come quella di Garda (R140) — ✔ realizzato nella 0.16.0

**Osservazione (17:36).** «la bozza di fattura è bruttissima. tieni conto che deve sempre riportare in alto l'intestazione di AD, ovviamente il cliente, ovviamente le singole righe, nonché il riferimento al preventivo e all'ordine (se uguali per ogni riga unico in fondo al preventivo). ti giro dei pdf di cortesia che garda genera» e «ma poi manca numero e data, manca proprio tutto».

Federico ha inviato due PDF di cortesia di Garda: una fattura DM e una DPR di settembre 2026. Contengono dati veri di clienti, quindi **restano solo nella chat** e non vanno nel progetto né nei test.

### NEXUS 0.15.0 oggi

`finanza/stampa.py` costruisce un Word minimo e lo converte con LibreOffice. Il risultato è testo semplice:
- nessun logo, nessun riquadro;
- una tabella con quattro colonne strette;
- totali e scadenze in righe di testo.

Nella **bozza** il numero non c'è ancora, perché si assegna all'emissione: compare la scritta «(bozza)», e la data appare solo come «Data: aaaa-mm-gg». Il risultato è davvero inutilizzabile.

### Impaginazione di Garda (dai due PDF), da riprodurre

Una pagina A4 verticale, carattere senza grazie, con riquadri grigio chiaro.

1. **Intestazione:**
   - a sinistra il logo «AD S.r.l. Inspections»;
   - a destra, in grande, «AD S.r.l.» e sotto indirizzo, telefono, email, C.F. e P.IVA, tutti presi dai Dati fiscali AD.
2. **Documento:** «TD01: fattura» e sotto «Fattura Nr. **512/2026/DM** del **24/09/2026**». Per la nota di credito: «TD04: nota di credito».
3. **Riquadro grigio «Cliente»:** ragione sociale, indirizzo, CAP, comune e provincia, poi C.F. e P.IVA.
4. **Tabella delle righe**, con le colonne Cod. articolo, Descrizione, Qtà, Prezzo, Importo e IVA:
   - **DPR:** «<cliente> <indirizzo della sede>: verifica periodica di <tipologia> - verbale VP/614/26 - rif. preventivo 471/2026 del 28/08/2026»;
   - **DM:** «Verifiche attrezzature di lavoro gruppo GVR, matr. …, n.f. …, verifica periodica successiva, verifica funzionamento, numero verbale 1840/26, preventivo 264/2026 del 04/05/2026, rif. ordine cliente …»;
   - in fondo alla tabella, righe di nota: «(Rif. Ordine d'acquisto n. … del …)» e «Copia della fattura elettronica disponibile nella Sua area riservata dell'Agenzia delle Entrate»;
   - righe vuote fino al fondo del riquadro.
5. **Riepilogo IVA:** aliquota o natura con descrizione (es. «22 - Imponibile 22%»), imponibile e imposta. Accanto, il riquadro dei totali: Tot. imponibile, Tot. IVA, **Tot. documento**.
6. **Pagamento:**
   - modalità (es. «Bonifico 60 gg F.M.»), banca e IBAN;
   - per ogni rata la data di scadenza e l'importo;
   - riquadro **Tot. dovuto**, diverso dal totale documento con lo split payment, la ritenuta o il bollo;
   - piè di pagina «Pag. 1/1».

### Richieste di Federico in più rispetto a Garda

- **Riferimenti al preventivo e all'ordine:**
  - se sono **uguali per tutte le righe**, compaiono **una volta sola in fondo**, e le descrizioni delle righe non li ripetono;
  - se sono diversi, restano riga per riga, come in Garda.
- **Sempre** l'intestazione di AD, il cliente, il numero e la data, **anche nella bozza**:
  - la bozza mostra «Fattura Nr. **BOZZA** – il numero si assegna all'emissione» e la data del documento in formato gg/mm/aaaa;
  - nella bozza c'è la scritta diagonale «BOZZA – non valida ai fini fiscali».

### Proposta di realizzazione (al via del codice)

1. **Nuovo modello di stampa:**
   - un modello Word «Fattura di cortesia» (come i modelli dei preventivi e dei verbali), compilato dalla fotografia fiscale e convertito con LibreOffice;
   - in alternativa, HTML convertito in PDF, come fa Garda con Chromium. La scelta è tecnica;
   - il modello si può sostituire da Sistema › Modelli, come gli altri.
2. **Logo:** quello di AD S.r.l. Inspections. Serve il file originale, possibilmente vettoriale. Se manca, lo ricavo dal PDF di Garda.
3. **Descrizioni delle righe:**
   - generate come in Garda (DPR e DM sopra);
   - preventivo e ordine tolti dalla riga quando sono comuni a tutte;
   - restano modificabili nella bozza come oggi.
4. **Ordine e documenti collegati (R138):** compaiono in fondo, ciascuno con tipo, numero, data, CIG e CUP.
5. **Stessi dati dell'XML:** la copia di cortesia si genera dalla stessa fotografia dell'XML emesso, quindi numeri, importi, scadenze e IVA coincidono sempre. Le fatture già emesse con il vecchio PDF lo conservano: il nuovo vale dalla prossima emissione, e si può rigenerare la sola copia di cortesia.
6. **Nome del file:** come Garda, `Fattura_<numero>-<anno>-<DPR|DM>_del_<gg-mm-aaaa>_<cliente>.pdf`.

### Da verificare: formato del numero

- **Garda:** «512/2026/DM», «390/2026/DPR».
- **NEXUS** (servizio.py): «DM/512/2026», «DPR/390/2026».

Va controllato sugli **XML veri di Garda** (campo Numero, documento 41 § 10) quale formato va allo SdI. Per la continuità della numerazione e per i clienti, NEXUS deve usare **lo stesso formato di Garda**. Proposta: «numero/anno/attività», come Garda.

**Decisione:** **R140** (proposta, da confermare). Riguarda la copia di cortesia, non l'XML: l'XML resta conforme alla FatturaPA 1.2.

---

## C6 · «Emetti e genera XML»: errore imprevisto (17:36), XML rimandati alla fine (17:37) — ✔ realizzato nella 0.16.0 (controllo di cosa manca); XML alla fine

**Osservazione.** Bozza n. 1 (cliente di prova, una riga «Messa a terra fino a 1.000 V · 150 kW», 600,00 € + IVA = 732,00 €, pagamento «Bonifico 30 gg F.M. (dal preventivo P_001_26)»). «Emetti e genera XML» dà: «Errore imprevisto del programma: riprova; se si ripete, avvisa l'amministratore (dettagli nel file di log)».

**Decisione di Federico (17:37):** «per gli xml aspettiamo lo facciamo bene alla fine». La parte XML si riprende alla fine, insieme al confronto con gli XML veri di Garda e alla prova su Aruba (documento 41 § 10). Restano annotati due punti.

1. **Errore imprevisto.** È un difetto: il programma non deve mai fermarsi con un errore generico. Se manca un dato, deve dire quale. L'ipotesi più probabile, su un archivio nato da zero, è un dato di configurazione assente o incompleto:
   - Dati fiscali AD (cedente, regime fiscale, REA…);
   - codice FatturaPA della modalità «Bonifico 30 gg F.M.», nata prima delle regole;
   - IBAN;
   - codice destinatario o PEC del cliente.

   La causa esatta è nel file di log della cartella dei dati: la riga «Traceback» dell'ora 17:36. Al via del codice:
   - si riproduce su un archivio vuoto con gli stessi passi del collaudo;
   - ogni dato mancante diventa un messaggio chiaro **prima** dell'emissione, con un elenco «Prima di emettere manca: …» nella bozza;
   - un test copre l'emissione da un archivio nuovo.
2. **Scheda della bozza:**
   - la data è in formato aaaa-mm-gg: va gg/mm/aaaa;
   - la scheda mostra solo l'imponibile della riga: mancano IVA, prezzo e totale per riga, come nella copia di cortesia (C5 / R140).

---

## C7 · Nuova attrezzatura dall'elenco filtrato per sede: la sede va proposta (17:41) — ✔ realizzato nella 0.16.0

**Osservazione.** «se in ad_dm apro da sedi operativa il collegamento a attrezzature, mi da elenco filtrato della sede (bene), però poi (male) se premo "Nuova attrezzatura" mi restituisce una maschera senza "sede", non ha senso cercarla poiché sono partito da lì».

**Oggi:**
- **Impianti DPR:** «Nuovo impianto» dall'elenco filtrato per sede propone già la sede, dalla 0.x, rilievo O5 (`impianti.js`: `nuovo(S.daFiltro("sede_id"))`).
- **Attrezzature DM (`beni.js`):** «Nuova attrezzatura» apre la maschera vuota. Inoltre la maschera ha due controlli per la stessa cosa: il campo «Cerca sede per cliente o nome» con il pulsante «Cerca sede», e la tendina «Sede» («Cerca e scegli una sede»). Il doppione confonde.

**Da fare (al via del codice), come per gli impianti:**
1. «Nuova attrezzatura» da un elenco filtrato per sede apre la maschera con la **sede già scelta**: cliente, denominazione e indirizzo visibili in sola lettura, con il link «cambia» per i rari casi in cui serve.
2. Lo stesso vale partendo:
   - dalla scheda della sede (linguetta o collegamento Attrezzature);
   - dalla scheda di un'attrezzatura, per aggiungere un accessorio collegato: si propongono la sede e il collegamento all'attrezzatura.
3. Senza filtro di sede resta la ricerca, ma con **un solo controllo**, cioè un campo di ricerca con suggerimenti (cliente, sede, comune), come nella maschera dell'impianto. Sparisce la coppia campo + tendina.
4. Le sedi proposte sono quelle dei clienti AD_DM (R137).
5. **Controllo generale:** la stessa regola («se parti da un elenco filtrato, il nuovo eredita il filtro») va verificata su tutte le maschere «Nuovo …» aperte da elenchi filtrati:
   - sedi del cliente;
   - preventivi del cliente o della sede;
   - incarichi DM della sede;
   - verifiche dell'impianto.

---

## C8 · Da «Sedi operative» le attrezzature vanno scelte fra GVR e SC/SP (17:42) — ✔ realizzato nella 0.16.0

**Osservazione.** «se da "sedi operative" vado su "attrezzature" va su attrezzature gvr, conviene avere la doppia scelta "gvr / sc_sp"».

**Oggi:**
- il menu dei collegamenti della sede (`sedi.js`) ha una sola voce, «Attrezzature ← Sede»;
- la voce apre l'elenco generico `/attrezzature` (gruppo «Tutti»);
- nel menu a sinistra l'elenco generico risulta sotto «Attrezzature GVR» (`MADRE` in `pagine.py`), quindi sembra l'elenco GVR, ma non lo è;
- dalla 0.12.10 (documento 30) gli elenchi dedicati sono due, `/attrezzature-gvr` e `/attrezzature-scsp`, con colonne diverse.

**Da fare (al via del codice):**
1. Nel menu dei collegamenti della sede, al posto di «Attrezzature ← Sede», due voci:
   - «**Attrezzature GVR ← Sede**» apre `/attrezzature-gvr` filtrato per la sede;
   - «**Attrezzature SC/SP ← Sede**» apre `/attrezzature-scsp` filtrato per la sede.
2. Accanto a ogni voce il numero di attrezzature (es. «GVR (3)», «SC/SP (0)»), così si vede subito dove andare.
3. Restano «Valvole di sicurezza ← Sede», «Scadenze ← Sede» e «Righe e verifiche ← Sede».
4. Con C7, «Nuova attrezzatura» dall'elenco filtrato propone **sede e gruppo**: GVR dall'elenco GVR, SC o SP dall'elenco SC/SP.
5. La stessa doppia scelta va data:
   - nei collegamenti della scheda del cliente e della scheda della sede;
   - nell'elenco generico `/attrezzature`, che non deve più apparire come «Attrezzature GVR» nel menu.

---

## C9 · Gruppo nella nuova attrezzatura e PSV gestite a parte (17:43) — ✔ realizzato nella 0.16.0

**Osservazione.** «se vado su nuova attrezzatura nella sezione gvr mi deve preimpostare gvr, se vado su sc/sp mi deve far scegliere, non mi deve dare tutte le opzioni. ti ricordo che le psv andrebbero gestite a parte (accessori - psv) perché non hanno matricola, guarda cosa ho scritto / allegato in precedenza nella conversazione!»

**Riferimenti precedenti:**
- documento 30: decisione del 12/10, 09:43, «il "Nuovo" di ciascuna voce propone il gruppo giusto»; in sospeso «teniamo in sospeso la questione valvole di sicurezza per il momento, appuntiamocelo»;
- documento 16, Q7: la valvola appartiene alla sede e può proteggere più attrezzature;
- documento 17: accessorio di sicurezza distinto dall'attrezzatura, con protezione molti a molti con data di inizio e fine.

**Oggi (`beni.js`):** la maschera «Nuova attrezzatura / accessorio» è una sola.
- **Tendina del gruppo:** propone **SC, SP, GVR e PSV** insieme. Il gruppo è preimpostato solo se la pagina lo passa: dall'elenco GVR sì, dall'elenco generico filtrato per sede (C8) no.
- **PSV nella stessa maschera:** il campo si chiama «Matricola informale / matricola PSV» e compaiono anche i campi della matricola INAIL (anno, attività, numero, provincia), che per una PSV non hanno senso.

**Da fare (al via del codice):**
1. **Nuova attrezzatura GVR** (elenco Attrezzature GVR, o collegamento «Attrezzature GVR ← Sede»): gruppo **GVR fisso**, senza tendina.
2. **Nuova attrezzatura SC/SP** (elenco Attrezzature SC/SP, o collegamento «Attrezzature SC/SP ← Sede»): scelta fra **SC e SP soltanto**.
3. **Nessuna maschera attrezzatura propone PSV.** La maschera delle attrezzature mostra solo i campi delle attrezzature: matricola INAIL in 4 parti, matricola informale, fabbrica, costruttore, modello, anno.
4. **Accessori · PSV gestiti a parte:**
   - voce di menu propria (oggi «Valvole di sicurezza»), con un elenco e una scheda propri;
   - «Nuovo accessorio» con **tipologia**: valvola di sicurezza, disco di rottura, valvola di intercettazione del combustibile;
   - campi propri: sede, costruttore, modello, numero di fabbrica / identificativo del costruttore, DN, diametro, area, **pressione di taratura**, taratura ultima e prossima;
   - **nessuna matricola INAIL**;
   - **protegge**: una o più attrezzature della stessa sede, con data di inizio e di fine (documento 17), modificabile dalla scheda della PSV e da quella dell'attrezzatura;
   - dalla scheda di un'attrezzatura, «Aggiungi accessorio» apre questa maschera con sede e collegamento già proposti (C7).
5. **Questione «valvole di sicurezza» del documento 30:** oggi è in sospeso. Con questa osservazione si **riapre**: la separazione delle PSV dalle attrezzature è decisa. Restano da definire con Federico le colonne dell'elenco PSV e i campi della scheda, partendo da Garda (`valvole_sicurezza`) e dagli allegati di Federico.
6. **Dati importati:** le PSV di adsrl sono già nella tabella dei beni con gruppo PSV e collegamenti `attrezzature_vds` (3.399). Restano dove sono e si mostrano solo nella nuova sezione, quindi non serve una migrazione dei dati. I campi della matricola INAIL eventualmente compilati per errore si segnalano.

**Decisione:** **R141** (proposta, da confermare). Nuova attrezzatura con il gruppo della sezione (GVR fisso; SC o SP); PSV e altri accessori di sicurezza in una sezione propria, senza matricola INAIL. Riapre il «sospeso valvole» del documento 30.

---

## C10 · «Cerca sede» nella nuova attrezzatura: deve essere un campo con completamento automatico (17:44) — ✔ realizzato nella 0.16.0

**Osservazione.** Nella maschera «Nuova attrezzatura», si scrive «bertot» nel campo «Cerca sede per cliente o nome», si preme «Cerca sede» e non succede nulla di visibile. Precisazione di Federico (17:44): «o meglio funziona ma dovrebbe essere un campo autocompletante (oltre che nel caso di specie già completato come scritto prima)». La ricerca quindi **funziona**: il problema è come la si usa.

**Analisi del codice** (`beni.js`, righe 125–133; `/api/sedi/cerca`):
- la ricerca **riempie la tendina «Sede»**, che sta nell'altra colonna della maschera, senza aprirla e senza segnalarlo;
- dopo la ricerca la tendina rimette il valore di prima (vuoto): anche con **un solo risultato** la sede **non viene scelta**;
- con zero risultati non compare alcun messaggio («nessuna sede trovata»);
- per chi usa la maschera sembra che non funzioni, anche se la ricerca in sé è corretta (confermato da Federico).

**Da fare (al via del codice), insieme a C7:**
1. Un **solo campo** «Sede», con ricerca mentre si scrive (cliente, nome della sede, comune) ed elenco dei suggerimenti sotto il campo, come nella maschera dell'impianto. Spariscono il pulsante «Cerca sede» e la tendina separata.
2. Con un solo risultato la sede si sceglie da sola; con nessuno compare «Nessuna sede trovata per "…"».
3. Sono proposte solo le sedi dei clienti AD_DM (R137) e le sedi attive, con la possibilità di vedere anche le altre.
4. Aperta da un elenco filtrato o dalla scheda della sede, la sede è già compilata (C7).
5. **Controllo generale:** cercare nel codice gli altri punti con la coppia «campo + pulsante Cerca + tendina» (preventivi DM, incarichi, valvole) e uniformarli.

---

## C11 · «Tipo attrezzatura verbale» solo per i GVR (17:45) — ✔ realizzato nella 0.16.0

**Osservazione.** «il tipo attrezzature verbale SOLO nel gvr». Nella schermata, una nuova attrezzatura SC (a3, apparecchi di sollevamento materiali; ID specifica 1, gru a struttura limitata fino a 500 kg) mostra nella linguetta «Class. INAIL» il campo «Tipo attrezzatura verbale (es. RG, RV, GV, INS, TUB)».

**Da fare (al via del codice):**
- il campo «Tipo attrezzatura verbale» (RG, RV, GV, INS, TUB) si vede e si salva **solo per il gruppo GVR**: maschera, scheda dell'attrezzatura, elenco SC/SP ed esportazioni;
- per SC e SP il campo sparisce. Se un'attrezzatura SC/SP importata lo ha compilato, il valore si conserva ma si segnala in «Da controllare»;
- **controllo generale:** in occasione di R141 vanno ripassati tutti i campi della maschera per gruppo (GVR / SC / SP / PSV), così ogni gruppo mostra solo i propri. Un altro esempio già deciso è PS e V solo nei GVR (documento 30).

---

## C12 · Date di ultima e prossima verifica alla registrazione di una nuova attrezzatura (17:46, R142) — ✔ realizzato nella 0.16.0

**Osservazione.** «quando registri un'attrezzatura (SC/SP o GVR) ti chiede il riferimento di ultima prossima verifica? n.b. dalla prima registrazione di un verbale è autocalcolato, ma quando la registro ex novo no! solo prossima verifica è obbligatorio (per poter filtrarlo in scadenze)».

**Oggi:** la maschera «Nuova attrezzatura» **non chiede le date**. Si possono aggiungere solo dopo, dalla scheda dell'attrezzatura, nella sezione «Date tecniche», con «date dichiarate» per attività: ultima, prossima, numero del report, nota sulla fonte. Senza date l'attrezzatura non compare nelle Scadenze. Dopo il primo verbale emesso in NEXUS le date si calcolano da sole: questo resta.

**Da fare (al via del codice):**
1. **Nuova sezione nella maschera di registrazione** «Ultima e prossima verifica», con le attività del gruppo:
   - **SC / SP:** una riga, «Verifica periodica SC/SP»;
   - **GVR:** una riga per attività: funzionamento, integrità, visita interna. CND e indagine supplementare restano nella scheda, dopo.
2. **Campi di ogni riga:**
   - data ultima verifica, facoltativa;
   - riferimento (numero del verbale o del report, e chi l'ha fatta: AD, altro organismo, INAIL), facoltativo;
   - **data prossima verifica, obbligatoria**, così l'attrezzatura entra subito nelle Scadenze.
3. Le date si registrano come oggi, come «**date dichiarate**» con la fonte «registrazione dell'attrezzatura», non come verbali. Restano modificabili dalla scheda finché un verbale NEXUS non le sostituisce.
4. **Controlli:** la prossima non può precedere l'ultima. Se la prossima è già passata, la data è accettata ma l'attrezzatura compare subito come «scaduta».
5. **Attrezzatura nuova mai verificata** (prima verifica periodica da fare): si scrive solo la prossima, cioè la data entro cui fare la prima periodica. L'ultima resta vuota.

**Risposta di Federico (17:49):** «la prossima verifica per GVR è obbligatoria sia per funzionamento, che per integrità, che per visita interna (se applicabile)». Nei GVR quindi sono **obbligatorie le prossime di funzionamento e integrità**, e quella della **visita interna** quando è prevista, cioè per i generatori di vapore e di acqua surriscaldata (GV / INS GV), con la stessa regola già usata nel preventivo.

**Decisione:** **R142**, confermata nella sostanza il 12/10 alle 17:49. Da realizzare al via del codice.

**Priorità alta (Federico, 17:49):** «la mancanza della registrazione della scadenza è grave, rende vuoto lo scadenziario!!». R142 va **per prima** al via del codice, prima delle altre note del collaudo. Insieme va un controllo: l'elenco «Attrezzature senza prossima verifica», cioè le attività obbligatorie senza data, si vede dalle Scadenze, così nessuna attrezzatura resta fuori dallo scadenziario. **Rimedio fino ad allora:** dalla scheda dell'attrezzatura, sezione «Date tecniche», si aggiunge a mano la data dichiarata per ogni attività.

---

## C13 · Prima verifica periodica (PVP) sulla scadenza più vicina, le altre successive (17:49) — ✔ realizzato nella 0.16.0

**Domanda.** «se la prossima è PVP, in automatico il sistema classifica prossima verifica periodica le altre? es., se scade una PVP, ma sono in scadenza funzionamento e integrità, solo la prima è PVP, l'altra periodica successiva».

**Oggi (0.12.8, rilievo AD-40, come Garda `ricalcola_scadenze_attrezzatura`): sì, già così.**
- L'attrezzatura ha l'attributo «Tipo prossima verifica»: prima periodica (V1) o successiva (V2).
- Nel **preventivo dalle Scadenze** (`dm/servizio.py`, `tipo_della_scadenza`) solo la scadenza **più vicina** prende quel tipo, quindi PVP se V1; tutte le altre dell'attrezzatura sono **successive** (V2).
- Quando si emette il verbale, il «Tipo prossima verifica» dell'attrezzatura passa a **successiva** (`dm/scadenze.py`).
- Con V1 la tariffa GVR usa le colonne V1/V2 di Garda (con o senza messa in servizio), che richiedono la scheda tecnica PDF. Il nome del file INAIL porta «PVP».

**Punti da sistemare (al via del codice):**
1. **Riga di preventivo aggiunta a mano** (non dalle Scadenze): oggi propone il «Tipo prossima verifica» dell'attrezzatura su **ogni** riga, quindi anche la seconda riga della stessa attrezzatura sarebbe proposta come PVP. Deve valere la stessa regola delle Scadenze: PVP solo per l'attività con la scadenza più vicina, le altre successive (sempre modificabili a mano, con un avviso).
2. **Stessa data per più attività** (risposta di Federico, 17:52: «la prima che viene filtrata in occasione della generazione del preventivo»; realizzato nella 0.16 wip1) (es. funzionamento e integrità alla stessa data): oggi la PVP va a quella creata per prima, cioè a caso. Proposta: con date uguali la PVP va al **funzionamento**, poi integrità, poi visita interna. Se le attività sono unite in una sola riga combinata, l'intera riga è PVP. **Da confermare con Federico.**
3. **Elenco Scadenze e scheda dell'attrezzatura:** una colonna o etichetta «**PVP**» sulla scadenza che sarà prima periodica, così si vede prima di preventivare.
4. **Registrazione di una nuova attrezzatura (R142):** nella sezione delle date si sceglie «la prossima è una prima verifica periodica: sì / no», e l'etichetta PVP va da sola sull'attività più vicina.

---

## C14 · «Tipi e tariffe» in Configurazione (18:05) — ✔ realizzato nella 0.16.0

**Osservazione.** «tipi e tariffe a mio avviso è più da "configurazione"».

**Realizzato nella 0.16 wip2:** la voce è tolta dal gruppo Attrezzature del menu AD_DM ed è ora in Gestione › Configurazione, riquadro «Cataloghi AD_DM».

**Da valutare:** spostare allo stesso modo anche il «Tariffario» DPR, oggi nel gruppo Impianti. Non l'ho spostato perché non era richiesto.

---

## C15 · Impostazioni email distinte per AD_DPR, AD_DM e I&C (18:29) — ✔ realizzato nella 0.16.0

**Osservazione.** «altra annotazione, impostazioni email vanno distinte per dm, dpr e iec».

**Oggi:** c'è un solo server di posta per tutto il programma, il file `posta.json` nella cartella dei dati (`core/posta.py`, `ImpostazioniPosta`). Lo usano:
- l'invio dei preventivi DPR e DM (`preventivi/api.py`);
- l'invio dei verbali DM (`dm/api.py`);
- i verbali DPR di VerbalizzAI (`verbali/archivio.py`, `PostaVerbali`);
- l'invio delle fatture.

**Da fare (0.16):**
1. **Tre configurazioni**, AD_DPR, AD_DM e I&C, ciascuna con:
   - server, porta, sicurezza, utente, password;
   - mittente e nome del mittente;
   - eventuale copia nascosta di archivio.
2. **Pagina Impostazioni email:** tre linguette, una per attività, ciascuna con «Prova invio». È anche possibile copiare le impostazioni da un'altra attività.
3. **Scelta automatica:** ogni invio usa le impostazioni dell'attività del documento:
   - preventivo DM e verbale DM → AD_DM;
   - preventivo DPR, verbale DPR di VerbalizzAI e fattura DPR → AD_DPR;
   - I&C quando esisterà il modulo.
4. **Archivi esistenti:** l'attuale `posta.json` diventa la configurazione di **tutte e tre** le attività, così nulla smette di funzionare. Poi si correggono quelle diverse.
5. **Password:**
   - restano nel file, mai nelle risposte dell'interfaccia;
   - la variabile d'ambiente `GESTIONALE_SMTP_PASSWORD` resta valida per tutte;
   - si aggiungono `GESTIONALE_SMTP_PASSWORD_DPR`, `GESTIONALE_SMTP_PASSWORD_DM` e `GESTIONALE_SMTP_PASSWORD_IEC`, che prevalgono.
6. **VerbalizzAI** (R111, da non modificare): il ponte `PostaVerbali` legge la configurazione AD_DPR. Non serve toccare VerbalizzAI.
7. **Permesso:** quello attuale («Impostazioni»). L'RT o la segreteria di un'attività non cambiano quella dell'altra solo se Federico lo chiede: **da chiedere al via**.

---

## C16 · Configurazione diversa per attività: modelli, firme, strumenti, commerciali (18:31) — ✔ realizzato nella 0.16.0, tranne «impianto termico»

**Osservazione** (con la schermata di Gestione › Configurazione): «quando lo apro in ad_dm, ad_dpr, IEC non deve mostrare la stessa interfaccia. m01, m02, m03, modello preventivo dpr -> solo in dpr; altrettanto per modello verbali gvr, modello sc/sp, modello impianti termici, modello preventivo, nel caso dm11. modello preventivo nel caso iec». Poi: «firme dei verificatori idem divise per ambito, idem strumenti di misura» e «idem commerciali».

**Oggi:** la pagina Configurazione è identica in tutte le attività. «Modelli Word di preventivi e verbali DM» elenca insieme i modelli DPR e DM. Firme dei verificatori e strumenti di misura sono quelli di VerbalizzAI, cioè DPR, ma compaiono anche in AD_DM. I commerciali sono un unico elenco.

**Da fare (0.16):** la pagina mostra solo ciò che riguarda l'attività scelta in alto.

| Riquadro | AD_DPR | AD_DM | I&C |
|---|---|---|---|
| Modelli | M01, M02, M03 (VerbalizzAI); modello del preventivo DPR | modello del verbale GVR (M14); modello del verbale SC/SP (M11); **modello impianti termici**; modello del preventivo DM | modello del preventivo I&C |
| Firme dei verificatori | firme DPR (VerbalizzAI) | firme DM (oggi nei dati tecnici dell'utente) | — (quando ci sarà il modulo) |
| Strumenti di misura | strumenti DPR (VerbalizzAI) | strumenti DM: **elenco nuovo**, non esiste ancora | strumenti I&C (con il modulo) |
| Commerciali | commerciali con ambito AD_DPR | commerciali con ambito AD_DM | commerciali con ambito I&C |
| Cataloghi | Tariffario DPR (da valutare se spostarlo qui, C14) | Tipi e tariffe (cataloghi di Garda) | — |
| Impostazioni email | configurazione AD_DPR (C15) | configurazione AD_DM (C15) | configurazione I&C (C15) |
| Comuni a tutte | tipi di pagamento, aliquote IVA, termini di esecuzione, elenchi di valori, importazioni, registro, backup | idem | idem |

Federico (18:31): «comuni invece tipi pagamento, aliquote iva, termini di esecuzione». Confermati comuni.

Federico (18:32): «backup e integrità unico, verbali di verbalizzai ad_dm e AD_dpr divisi» e «importazioni dati unico».
- **Comuni:** backup e integrità, importazione dati.
- **Divisi per attività:** «Verbali di VerbalizzAI», cioè l'importazione dell'archivio dei verbali e i collegamenti. In AD_DPR riguarda i verbali DPR e gli impianti; in AD_DM i verbali DM e le attrezzature.
- **Elenchi di valori e registro operazioni:** restano comuni come proposta di Claude, perché Federico non li ha citati.

**Note:**
1. La pagina «Modelli Word» filtra i modelli per attività. Un modello si carica solo nell'attività a cui appartiene.
2. **Commerciali:** come i clienti (R137), avranno l'indicatore AD_DPR / AD_DM / I&C, anche più di uno. Il cliente propone solo i commerciali della propria attività. I commerciali importati da ingecert diventano AD_DPR, quelli da adsrl AD_DM.
3. **Firme:** un verificatore con più ruoli (R143) può avere una firma DPR e una firma DM. Ciascuna si vede nella configurazione della sua attività.
4. **Strumenti di misura DM:** oggi NEXUS non li gestisce. Servono le colonne: le prendo dal registro strumenti di VerbalizzAI (denominazione, matricola, taratura, scadenza), salvo indicazioni diverse.

**Domanda aperta, da fare al via del lavoro sui modelli DM:** «modello impianti termici». In NEXUS i gruppi DM sono SC, SP e GVR, e i cataloghi di Garda (31 tipi) non hanno un gruppo per gli impianti termici, cioè i generatori di calore per riscaldamento oltre 116 kW (allegato VII D.Lgs. 81/08). Va chiarito:
- se AD fa queste verifiche;
- con quale modello di verbale;
- se in Garda le registra come GVR o fuori dal gestionale.

Fino alla risposta, nella configurazione DM il posto del modello è previsto ma vuoto.

---

## C17 · Filtri sopra le colonne come Garda; ordinamento e raggruppamento predefiniti di scadenze e attrezzature (13/10, 06:34)

**Solo annotato.** Base provata: NEXUS 0.16.0. Federico ha allegato tre schermate di Garda: la griglia Clienti, il filtro «Comune» e il filtro «Data scadenza verifica».

**Testo di Federico:** «garda (ingecert, adsrl, etc.) ha delle icone sopra ogni colonna: filtra, pulisci e nascondi colonna. filtra è importante! per i campi di testo ha una selezione tra contiene, inizia con, finisce con, uguale a, e un campo di testo editabile cui applicare la selezione. per le date (importantissimo!) una seleziona da - a, oltre a dei pulsanti con i casi d'uso più frequenti: anno corrente, mese prossimo, etc. inoltre ho notato che in tutte le schermate (AD_dpr, AD_dm, etc.) non c'è un ordinamento funzionale delle scadenze: in teoria la prossima verifica dovrebbe essere ordinata dalla più prossima alla più lontana. inoltre, ad es., in scadenze e attrezzature, occorre di default un raggruppamento per cliente (AD_dpr) e per sede operativa (AD_dm)»

**Garda, dalle schermate:**
- **Sopra ogni colonna** ci sono tre icone: **filtra**, **pulisci il filtro**, **nascondi la colonna**.
- **Filtro su un campo di testo** (finestra «Comune»): una scelta fra «Contiene», «Inizia con», «Finisce con» e «Uguale a», il campo «Valore», poi Annulla e OK.
- **Filtro su una data** (finestra «Data scadenza verifica»):
  - pulsanti rapidi: Ieri, Oggi, Domani; Mese scorso, Mese corrente, Mese prossimo; Anno scorso, Anno corrente, Anno prossimo; Ultimi 8 giorni, Prossimi 8 giorni;
  - campi «Da» e «A» (gg/mm/aaaa);
  - casella «Non valorizzato»;
  - Annulla e OK.

**Punti annotati:**
1. **Filtri sopra le colonne come in Garda**, con le icone filtra, pulisci e nascondi. Il filtro è importante; quello sulle date è «importantissimo».
2. **Ordinamento delle scadenze:** in tutte le schermate di AD_DPR, AD_DM e delle altre attività, la prossima verifica deve essere ordinata dalla più vicina alla più lontana.
3. **Raggruppamento predefinito** nelle schermate Scadenze e Attrezzature (Federico cita queste come esempio): per **cliente** in AD_DPR, per **sede operativa** in AD_DM.

---

## C18 · Raggruppamenti: cliente e sede operativa non si trovano (13/10, 06:36)

**Solo annotato.** Federico ha allegato la schermata dell'elenco «Raggruppa per» della griglia degli impianti, in AD_DPR.

**Testo di Federico:** «i possibili raggruppamenti non prevedono cliente e sede operativa?»

**Cosa si vede:** l'elenco è lunghissimo e parte dalle colonne dell'impianto: N. impianto, Codice gestionale attuale, Tipologia, Denominazione, Dismesso, Matricola INAIL…

**Risposta data, verificata sul codice (`static/js/griglia.js`):** si può già raggruppare per cliente e per sede, ma quelle voci non si vedono subito. L'elenco propone tutte le colonne della griglia nell'ordine delle colonne, e cliente e sede stanno in fondo, dopo le colonne dell'impianto.

**Punto annotato:**
- **Cliente** e **sede operativa** devono essere in cima alle scelte di raggruppamento.
- L'elenco va ridotto alle colonne che ha senso raggruppare.
- Si collega a C17, punto 3: il raggruppamento predefinito per cliente in AD_DPR e per sede in AD_DM.

---

## C19 · Scadenze: la prima colonna è il cliente (AD_DPR) o la sede operativa (AD_DM) (13/10, 06:37)

**Solo annotato.**

**Testo di Federico:** «in scadenze, forse ne avevamo parlato (vai a vedere), la prima colonna deve essere cliente (o sede operativa, a seconda che AD_dpr o AD_DM), non in fondo»

**Cosa c'era già nei documenti:**
- **Documento 05, inventario di Garda, Scadenze di AD_dpr:** le prime colonne sono cliente, sede operativa, impianto, poi dismessa, stato del preventivo, ecc.
- **Documento 30 § 5, Scadenze di AD_DM** (realizzato nella 0.12.10): raggruppate per sede operativa, con colonne reparto, rif. interno, descrizione, ecc. La sede è nell'intestazione del gruppo, «come in Garda», e la sua colonna è nascosta. Era una scelta di Claude fatta **in attesa di conferma** (documento 30, «Scelte fatte in attesa di conferma»).

**Punto annotato:**
- In Scadenze la **prima colonna** è il **cliente** in AD_DPR e la **sede operativa** in AD_DM. Oggi queste colonne sono in fondo.
- Il punto corregge la scelta del documento 30, che teneva nascosta la colonna della sede.
- Si collega a C17 (ordine per prossima verifica e raggruppamento predefinito) e a C18 (cliente e sede in cima ai raggruppamenti).

---

## C20 · Permessi Impianti AD_DPR e Attrezzature AD_DM distinti e riconoscibili (13/10, 10:53)

**Solo annotato e ragionato. Nessuna modifica al codice.** Base letta: NEXUS 0.16.0, schema 0027. Federico allega la schermata «Permessi per ruolo».

**Testo esatto di Federico:** «aggiungo degli elementi. quando nei permessi si parla di "Impianti" (creare e modificare, etc.) si parla di AD_dpr, giusto? e per le attrezzature (GVR, sc, sp)? non scrivere codice, annota e ragiona»

**Riscontro sui sorgenti, non prova applicativa:**
- «Creare e modificare impianti» è `anagrafica.impianti`; «Segnare un impianto come dismesso» è `anagrafica.dismetti`. Le API protette sono quelle degli impianti DPR, non delle attrezzature GVR/SC/SP.
- Per le attrezzature esiste già il gruppo **Attrezzature (AD_DM)**: `beni.vedere`, `beni.gestire`, `beni.scadenze`, `beni.dismetti`. La modifica comprende attrezzature, camere e associazioni con gli accessori; la dismissione riguarda attrezzature e accessori. I permessi sono comuni ai gruppi GVR, SC, SP e PSV: non esistono permessi distinti per ciascun gruppo.
- Clienti e sedi sono anagrafiche condivise. Gli impianti DPR e le attrezzature DM sono oggetti diversi, con permessi diversi.
- **Assegnazione da valutare:** nella schermata anche RT DM ha spuntato «Creare e modificare impianti» e «Segnare un impianto come dismesso». È coerente con l'inizializzazione attuale: i ruoli RT DPR e RT DM ereditano questi permessi. Le API degli impianti richiedono il relativo permesso ma non l'attività DPR; i permessi delle anagrafiche e `beni.*` non fanno parte dell'insieme `TECNICI` a cui si applica la separazione per attività. Non basta quindi rinominare una voce per circoscrivere chi può usarla.

**Proposta da valutare, non decisione acquisita:** rendere la matrice leggibile con gruppi **Anagrafiche comuni**, **Impianti AD_DPR**, **Attrezzature AD_DM**, **Accessori PSV** e operazioni con nomi pertinenti. Prima di modificare assegnazioni o controlli, chiarire se la gestione del parco è comune a entrambi gli RT o limitata all'attività del ruolo. Questa scelta è distinta dai permessi di esecuzione e riesame, già separati per attività. Nessuna richiesta di separare ulteriormente GVR da SC/SP viene dedotta dalla domanda.

**File letti:** `gestionale/core/permessi.py`, `gestionale/moduli/utenti/accesso.py`, `gestionale/web/dipendenze.py`, `gestionale/moduli/anagrafica/api.py`, `gestionale/moduli/beni/api.py`.

---

## C21 · Posizione e logica dei pulsanti nelle griglie (13/10, 10:54)

**Solo annotato e ragionato. Nessuna modifica al codice.** Federico allega la barra dell'elenco Verifiche AD_DPR.

**Testo esatto di Federico:** «la posizione dei pulsanti non mi convince molto, dobbiamo trovare un logica»

**Cosa si vede e riscontro sui sorgenti:** ricerca, raggruppamento, Colonne, Configurazioni, Azzera filtri, Esporta Excel, Aggiorna, filtri rapidi e azioni sulle verifiche sono nella stessa barra, che va a capo. «Fattura le selezionate…» precede «Affida le selezionate…», benché l'affidamento preceda la fatturazione nel flusso. `static/js/verifiche.js` passa filtri e azioni nella stessa lista `pulsanti`; `static/js/griglia.js` li aggiunge tutti a `griglia-barra`.

**Proposta di logica comune alle griglie, da valutare:**
1. **Filtri di lavoro:** una zona dedicata a Tutte, Da assegnare, Le mie, Da registrare, Programmate, Verbale da compilare, Da riesaminare, Da fatturare. Ordine pertinente al percorso di lavoro; stato attivo riconoscibile. «Le mie» è un criterio personale, non uno stato della verifica: va distinto visivamente.
2. **Comandi della griglia:** ricerca, raggruppamento, colonne e viste salvate nella zona della consultazione; Esporta e Aggiorna come comandi secondari. Restano separati dalle operazioni che cambiano i dati. Si coordina con C17–C19 per filtri, raggruppamenti e prime colonne.
3. **Azioni sulle righe selezionate:** barra separata vicina alla tabella, con il numero di righe selezionate. Le azioni mantengono una posizione stabile e sono ordinate secondo il flusso: nella schermata allegata Affida precede Fattura. Si mostrano solo le azioni consentite dal ruolo; si abilitano quando la selezione è compatibile, spiegando altrimenti il motivo. Non vengono introdotte operazioni multiple oggi assenti solo per riempire la barra.

La proposta va applicata in modo coerente a DPR e DM, preventivi, verifiche, attrezzature e scadenze, con le azioni pertinenti a ciascuna pagina. Le azioni della singola scheda restano nella scheda; la selezione di righe non equivale a cambiare lo stato o ad accettarle. Non è ancora un'impaginazione approvata e non cambia permessi o controlli del backend.

---

## C22 · Casella cumulativa per i requisiti del riesame del contratto con esclusioni individuali (13/10, 10:56)

**Solo annotato e ragionato. Nessuna modifica al codice.** Federico allega «Nuovo riesame del contratto», con quattro requisiti, esito, note e «Registra il riesame».

**Testo esatto di Federico:** «da aggiungere flag cumulativo, con possibilità di deflag parziale (in caso di esito non cofnorme)»

**Richiesta annotata:** aggiungere una casella generale **Seleziona tutti i requisiti**, che permette di spuntare insieme i quattro requisiti del riesame. Le singole caselle devono restare modificabili, così si possono deselezionare i requisiti non soddisfatti senza perdere quelli conformi. La richiesta riguarda i requisiti di un riesame, non il riesame in blocco di più preventivi.

**Proposta di comportamento:**
- tutte le caselle spuntate: casella generale spuntata;
- alcune spuntate e altre no: casella generale nello stato di selezione parziale;
- nessuna spuntata: casella generale non spuntata;
- il comando generale seleziona o deseleziona tutte; modificare una casella individuale aggiorna lo stato di quella generale;
- l'esito resta una scelta esplicita. Il flag generale non registra il riesame, non rende automaticamente conforme l'esito e non sostituisce «Registra il riesame»;
- restano i controlli esistenti: conforme solo con tutti i requisiti soddisfatti; per non conforme, note su motivo e azione decisa. Non viene dedotta una modifica dei requisiti o del loro valore nello storico.

**Riscontro sul codice:** `static/js/preventivi.js` costruisce quattro caselle distinte nel modulo del riesame; non c'è una casella generale per i requisiti. Da coordinare con il servizio del riesame e con lo storico già richiesto, per DPR e DM.

---

## C23 · Righe del preventivo nel contesto del singolo preventivo e colonne essenziali (13/10, 10:58)

**Solo annotato e ragionato. Nessuna modifica al codice.** Federico allega l'elenco «Righe dei preventivi» con righe di più preventivi.

**Testo esatto di Federico:** «righe dei preventivo "globale" non ha senso, deve essere sempre accessibvile dagli elementi collegati di preventivo e puntare alle righe del singolo preventivo. n.b. le colonne da visualizzare sono sede operativa, stato riga, tipo verifica, impianto tipologia tariffa applicata, stato verifica, verificatore, da fatturare»

**Richiesta annotata:**
1. La vista globale «Righe dei preventivi» non deve essere proposta come elenco autonomo. L'accesso parte dagli **elementi collegati del preventivo** e porta sempre alle righe di **quel solo preventivo**.
2. Il preventivo di contesto deve restare riconoscibile nel titolo e durante ricerca, filtri, raggruppamento, selezione ed esportazione. Il vincolo del preventivo deve rimanere anche usando Tutte o Azzera filtri, altrimenti si torna alla vista globale che Federico ha escluso.
3. La vista iniziale mostra, in quest'ordine, le colonne richieste. La sequenza «impianto tipologia tariffa applicata» è trascritta sopra esattamente; qui viene letta come tre colonne distinte:
   - Sede operativa;
   - Stato riga;
   - Tipo verifica;
   - Impianto;
   - Tipologia;
   - Tariffa applicata;
   - Stato verifica;
   - Verificatore;
   - Da fatturare.
4. Caselle di selezione e comandi di riga restano strumenti operativi, separati dalle colonne informative. Identificativi tecnici, tariffa standard e sconto non occupano la vista iniziale richiesta.

**Riscontro sui sorgenti:** oggi esistono le voci di menu globali `/righe-preventivi` e `/righe-preventivi-dm`. Nell'elenco preventivi esiste già il collegamento «Righe ← Preventivo», che passa il filtro `preventivo_id`. La modifica richiesta riguarda accesso e contesto dell'elenco: il semplice filtro eliminabile non basta a garantire il vincolo del singolo preventivo. File interessati dalla lettura: `web/pagine.py`, `static/js/preventivi.js`, `static/js/righe_preventivi.js`, `moduli/preventivi/griglie.py`, `static/js/griglia.js`.

**Effetti da coordinare, senza dedurre nuove decisioni:** la fatturazione e l'affidamento dalle righe continuano nel contesto del preventivo; il punto aggiorna la presentazione del percorso R125. La fatturazione dalla verifica prevista da R139 è un altro punto di accesso già esistente e non viene revocata da questa osservazione. Per il corrispondente elenco DM, valutare l'etichetta Attrezzatura al posto di Impianto e i campi GVR/SC/SP pertinenti, conservando lo stesso principio del singolo preventivo.

---

## C24 · Affidamento della verifica e utenti importati inattivi (13/10, 11:00)

**Solo analizzato e annotato. Nessuna modifica al codice o agli utenti.** Federico allega Utenti e permessi e la finestra «Affidare la verifica?».

**Testo esatto di Federico:** «qualcosa non va con i permessi, perché non riesco ad affidare l'incarico di verifica ad un verificatore?»

**Riscontro:** nella schermata i verificatori e RT importati mostrati sono **Attivo: No**; i due utenti selezionabili nella finestra sono amministratori attivi. `moduli/verifiche/servizio.py::verificatori` prende solo utenti attivi, con almeno un ruolo attivo pertinente all'attività e il permesso `verifiche.esegui`. Il ruolo Amministratore comprende quel permesso. L'importatore `moduli/garda/importa.py` crea intenzionalmente gli utenti importati con `attivo=False`, password generata e cambio password richiesto.

**Diagnosi del caso mostrato:** il verificatore atteso è escluso perché inattivo; le immagini non mostrano un errore di autorizzazione di chi affida. Serve aprire la scheda dell'utente destinato alle prove, verificare il ruolo DPR o DM pertinente e riattivarlo; quindi aggiornare l'elenco di affidamento. Per eventuale accesso dell'utente si gestisce la sua password provvisoria dal programma. Non sono state usate credenziali né modificati utenti.

**Miglioramento proposto per la prossima versione:** rendere evidente nell'importazione e nell'affidamento che gli utenti importati sono inattivi, con indicazione su dove riattivarli. Distinguere i due requisiti: chi affida deve poter assegnare nell'attività; chi riceve deve essere attivo e poter eseguire nell'attività. I controlli esistenti restano applicati; non viene dedotta una richiesta di attivazione automatica di tutti gli utenti importati.

---

## Valutazione congiunta C17–C26 prima della versione successiva (13/10, 11:01; aggiornata alle 11:09)

**Richiesta esatta di Federico:** «ora analizza tutti i punti emersi sinora, discutiamo eventuali problematiche o scelte dicrezionali poi scriviamo e testiamo il codice della versione successiva.»

**Fase attuale:** analisi per il confronto con Federico. Il codice NEXUS 0.16.0 è inalterato; i controlli seguenti sono lettura dei sorgenti e delle schermate, non nuovi test passati. La prossima versione proposta è **0.17.0**; versione e migrazione definitive si confermano sul cambiamento effettivo. La numerazione R resta nel registro unico del progetto; non vengono assegnati nuovi R qui.

### Problemi e vincoli di realizzazione

1. **C17, filtri.** I filtri testuali attuali del motore trattano il testo come «contiene». Per Inizia con, Finisce con e Uguale a servono anche operatori nel backend, oltre al controllo della colonna. I periodi di date esistono già con la sintassi testuale: la finestra Da/A e i pulsanti rapidi devono usare gli stessi limiti, includere tutto l'ultimo giorno e mantenere il corretto fuso nelle colonne data/ora. Ricerca, export e viste salvate devono usare lo stesso filtro. Le configurazioni già salvate vanno conservate e lette con il significato precedente.
2. **C17, ordine.** Scadenze DPR e DM hanno già la prossima data ascendente come ordine del backend. Il cambio di raggruppamento in `griglia.js`, però, sostituisce l'ordinamento con il solo campo del gruppo, perdendo la data. Le attrezzature sono invece ordinate per sede/reparto/matricola. Non basta cambiare le colonne: vanno composti raggruppamento e ordine per prossima data.
3. **C17–C19, gruppi e colonne.** Cliente e Sede operativa vanno proposti prima degli altri raggruppamenti sensati. Nelle Scadenze, la prima colonna informativa è Cliente nel DPR e Sede operativa nel DM. Le caselle di selezione e le azioni non contano come colonne informative. Oggi il raggruppamento è applicato alla singola pagina; ordinamento e paginazione devono essere coerenti e non presentare i conteggi della pagina come totali dell'intero gruppo.
4. **C20, permessi.** I nomi vanno resi espliciti, ma la questione delle assegnazioni è distinta: oggi anagrafiche e gestione dei beni sono comuni nei controlli, anche quando l'oggetto è DPR o DM. Serve la scelta operativa sotto indicata prima di cambiare i permessi di RT e verificatori. Clienti e sedi restano condivisi; l'ambito del cliente non è un'autorizzazione.
5. **C21, pulsanti.** Filtri di lavoro, controlli della vista e azioni sulle righe selezionate devono avere tre zone stabili. I comandi sulle righe sono ordinati secondo il flusso e dipendono da ruolo e selezione. La stessa regola vale nelle griglie DPR e DM, con le azioni già supportate da ciascuna pagina.
6. **C22, casella cumulativa.** Il flag generale agevola la compilazione dei quattro requisiti; non cambia la registrazione o l'esito. Nel servizio esistono già i blocchi per conforme con requisiti incompleti e non conforme senza nota: vanno mantenuti e provati anche dopo il nuovo controllo.
7. **C23, contesto delle righe.** Oggi il collegamento del preventivo imposta un normale filtro di colonna. `Tutte`, `Azzera filtri`, il pulsante Togli il filtro e l'applicazione di una vista salvata possono rimuoverlo. Per la nuova vista del singolo preventivo serve un contesto distinto dai filtri dell'utente, applicato a dati ed esportazione. La vista globale va tolta dagli accessi ordinari. Le nove colonne richieste diventano la vista iniziale DPR; in DM il riferimento è all'attrezzatura e alla sua attività. Affidamento e fatturazione restano collegati alle stesse righe commerciali.
8. **C24, affidamento.** Il caso mostrato dipende dagli utenti inattivi. Si propone un'indicazione chiara per l'operatore, conservando il filtro degli utenti attivi e i controlli per attività. La riattivazione effettiva degli utenti di Federico si fa sul suo archivio, non nel codice né automaticamente dall'import.
9. **C25, Salva e chiudi. Priorità alta.** La scheda Utente ha salvataggi separati che condividono la versione dell'utente ma non la aggiornano tutti nell'interfaccia. Il controllo di concorrenza può quindi scattare dopo un salvataggio effettuato dallo stesso operatore. Vanno coordinati i dati anagrafici/ruoli, il profilo tecnico e la firma, preservando i conflitti reali fra operatori. Proposta: Salva e Salva e chiudi seguono un solo percorso coerente per i dati della scheda; gli eventuali caricamenti immediati della firma riallineano la versione comune e non eliminano le modifiche in corso. Il caso va riprodotto, senza considerare l'analisi del sorgente una prova già passata.
10. **C26, caricamento Word. Priorità alta.** L'errore osservato viene dal controllo sul PDF allegato o ottenuto da LibreOffice, non dal limite del Word. Lo stesso messaggio copre formato PDF non riconoscibile e dimensione PDF oltre 25 MB. Serve riprodurre il caso, distinguere le cause e rendere chiaro il percorso Word precedente rispetto a definitivo della verifica corrente. Modulo e numero si verificano nel contenuto del Word; per il definitivo devono corrispondere alla verifica. La correzione appartiene all'integrazione NEXUS e non autorizza modifiche a VerbalizzAI.

### Due scelte da discutere

**Gestione del parco per ruolo.** Proposta: RT DPR gestisce gli impianti DPR; RT DM gestisce attrezzature e accessori DM; amministratore e segreteria restano comuni. Alternativa: mantenere la gestione anagrafica del parco comune a entrambi gli RT, con nomi e gruppi chiari nella matrice. La scelta riguarda la gestione del parco; non modifica la separazione di esecuzione e riesame già prevista da R132/R143.

**Ordine dei gruppi nelle Scadenze.** Proposta: clienti/sedi ordinati per la prima scadenza filtrata del gruppo, dalla più urgente; dentro ogni gruppo date crescenti e valori mancanti in fondo. Alternativa: gruppi alfabetici, sempre con date crescenti dentro il gruppo. Una lista piatta totalmente cronologica e una lista a gruppi rispondono a due criteri diversi: il programma può offrire entrambe le viste, ma serve definire la predefinita.

### Verifiche previste prima della consegna

- Filtri testuali nei quattro modi, caratteri speciali e risultati uguali fra elenco ed Excel; date singole e intervalli con limiti inclusivi, fine mese/anno e date/ora.
- Ordine delle scadenze dentro i gruppi e fra pagine, gruppi predefiniti, prime colonne e configurazioni salvate preesistenti.
- Permessi per ruoli singoli e multipli, controlli sulle API oltre ai pulsanti, utenti inattivi esclusi e ruoli dell'attività corretta nell'affidamento.
- Flag generale del riesame nei tre stati, esclusioni individuali e conferma dei controlli backend su esito e note.
- Scheda Utente: dati tecnici e firma seguiti da Salva/Salva e chiudi, sequenza inversa, clic ripetuti e conflitto reale fra due sessioni; nessuna perdita delle modifiche e una sola registrazione dell'operazione richiesta.
- Word DPR: caricamento senza PDF con conversione LibreOffice reale, PDF valido allegato, PDF non valido e oltre limite; DOCX di circa 1,2 MB; numerazione o modello errati; mancata conversione. Messaggi distinti e nessuna chiusura o archivio parziale in errore. Il DOCX effettivo e i log dell'ambiente di Federico non sono ancora disponibili.
- Due preventivi distinti: Tutte, Azzera, viste salvate, paginazione ed esportazione non fanno uscire dal preventivo di contesto; righe, affidamento e fatturazione pertinenti.
- Prova dell'interfaccia alle larghezze di uso, con barre stabili e nessun errore JavaScript, seguita dalla suite completa.

**Consegna prevista:** ZIP NEXUS della versione successiva, README, differenze rispetto alla 0.16.0, comandi e risultati delle prove effettive, note e ripresa aggiornate. Restano fuori da questo incremento XML/Aruba, nuove funzioni I&C/EX e modifiche a VerbalizzAI, salvo nuova istruzione di Federico.

---

## C25 · Salva e chiudi nella scheda Utente genera un conflitto di versione (13/10, 11:05)

**Solo analizzato e annotato. Nessuna modifica al codice.** Federico allega la scheda Utente, con dati tecnici e firma DM, e il messaggio di conflitto. I dati personali e l'immagine della firma non vengono riportati in questo documento.

**Testo esatto di Federico:** «se faccio salva e chiudi mi da questo errore»

**Messaggio osservato:** «Il dato è stato modificato da un altro utente mentre lo stavi modificando: ricarica la pagina e ripeti la modifica.»

**Riscontro sui sorgenti:**
- `static/js/utenti.js` conserva l'utente letto all'apertura e invia `u.versione` con il PUT dei dati anagrafici/ruoli.
- `static/js/schede.js::datiTecnico` conserva una propria variabile `versione`; i salvataggi del profilo tecnico e della firma DM aggiornano questa variabile, ma non quella della scheda Utente che contiene il pulsante principale.
- Il backend usa la stessa riga Utente e incrementa `Utente.versione` sia per anagrafica/ruoli sia per profilo tecnico e firma.
- `base.js::conChiudi` esegue la stessa azione del pulsante Salva e poi chiude la scheda: il conflitto non dimostra che un'altra persona abbia effettivamente modificato il dato.

**Percorso che può produrre il problema:** scheda aperta alla versione N → salvataggio di profilo tecnico o firma DM, versione N+1 → Salva e chiudi invia ancora N → conflitto. Il meccanismo è riscontrato nel codice; la sequenza esatta compiuta da Federico non è stata acquisita e non è ancora stata eseguita una prova di riproduzione. Anche i salvataggi anagrafici e tecnici nell'ordine inverso devono essere verificati.

**Correzione proposta per la prossima versione:** coordinare tutti i salvataggi della scheda e la versione corrente, non togliere il controllo di concorrenza. Salva e Salva e chiudi devono avere lo stesso significato sui dati della scheda; la differenza è la chiusura dopo il successo. In errore la scheda conserva i dati inseriti e resta aperta. Va impedita la doppia esecuzione durante una richiesta in corso. I caricamenti immediati della firma devono riallineare la versione senza cancellare le modifiche anagrafiche non ancora salvate.

**Rimedio temporaneo:** chiudere e riaprire la scheda, verificare quali dati sono già salvati e ripetere solo ciò che manca. La riattivazione dell'utente resta un'azione distinta (C24): nella schermata l'utente è ancora inattivo.

---

## C26 · Caricamento Word di circa 1,2 MB con errore riferito al PDF (13/10, 11:09)

**Solo analizzato e annotato. Nessuna modifica al codice.** Federico allega il caricamento del Word nella scheda di una verifica DPR. Il file Word non è allegato a questa analisi; sono disponibili la schermata e la dimensione dichiarata.

**Testo esatto di Federico:** «se carico un word che pesa circa 1,2 Mb mi da questo errore!»

**Messaggio osservato:** «Il PDF non è valido (massimo 25 MB).»

**Riscontro sui sorgenti:**
- `static/js/verifiche.js` invia il DOCX nel campo `word`; invia `pdf_file` solo se l'operatore ha selezionato un PDF.
- `moduli/verifiche/api.py` legge Word e PDF separatamente, fino a 25 MB più un byte; in assenza del PDF passa `None` al servizio.
- `moduli/verifiche/servizio.py::carica_verbale` genera il PDF con `core/pdf.py::da_word` se non è stato fornito. Poi produce il messaggio osservato se i byte non iniziano con `%PDF` **oppure** se il PDF supera 25 MB.
- `core/pdf.py` usa LibreOffice e restituisce il file generato; i messaggi per LibreOffice mancante, timeout o nessun PDF sono diversi da quello osservato.

**Conclusione verificabile:** l'errore arriva al controllo del PDF. Non dimostra che il Word di 1,2 MB sia troppo grande. Le due cause del messaggio attuale sono indistinguibili nella schermata. Non si può stabilire quale si sia verificata senza il PDF o i dettagli della conversione; non è stata eseguita una riproduzione del caso.

**Ulteriore verifica sul percorso usato:** il nome del Word nella schermata richiama un verbale precedente, con anno e numero diversi dalla verifica aperta. Il nome da solo non prova il contenuto. Per precompilare dalla verifica precedente il percorso è «Carica il verbale precedente»; per caricare il definitivo, il modulo e il numero letti **dentro il Word** devono corrispondere alla verifica registrata, come controlla già il servizio. L'errore sul PDF viene prima di questi controlli, quindi può nascondere il successivo errore di corrispondenza.

**Intervento proposto per la prossima versione:** separare dimensione e formato di Word e PDF nei messaggi, verificare il Word e i suoi riferimenti prima di una conversione inutile, verificare il risultato della conversione e conservare i dettagli tecnici nel log. Rendere più chiaro in interfaccia il caricamento del Word precedente rispetto a quello del definitivo. Mantenere i limiti e i controlli di corrispondenza; nessuna modifica a VerbalizzAI viene dedotta da questo caso. I test della conversione devono usare un DOCX sintetico, senza dati reali di clienti.

---

## C27 …

(altre osservazioni del collaudo della 0.16.0 a seguire)


## Approvazioni del 13/10/2026 — versione successiva

Testi esatti di Federico, successivi all’analisi C17–C26:

> per gruppi scadenze ok

> per gestione parco come hai indicato tu. proceci

> procedi pure

Scelte approvate: gruppi delle scadenze ordinati dalla prima scadenza più urgente, date crescenti dentro ciascun gruppo; gestione impianti AD_DPR riservata ai ruoli DPR e gestione attrezzature AD_DM (GVR, SC, SP, PSV) ai ruoli DM, mantenendo i ruoli comuni secondo i permessi assegnati. Autorizzata l’implementazione e il collaudo della versione successiva. Nessun numero R attribuito qui: registrazione definitiva nel registro canonico da R144.


## C27 — PostgreSQL e importazione completa Garda (13/10/2026)

Richiesta esatta:

> ora un tema "delicato", mi è stato sconsigliato di usare sqlite per lo sviluppo del gestionale integrato, ma usare postgre. tieni anche conto che quando andremo in produzione sarà ESSENZIALE riuscire a fare un'importazione completa e coerente del database (MariaDB) del gestionale garda informatica. come mi consigli di procedere per minimizzare gli errori?

Approvazione esatta:

> ok concordo procediamo prima con 0.17 con correzioni approvate e dopo passaggio a postgreSQL. nmi raccomando documenta tutto a latere così che io possa proseguire con un'altra istanza di LLM

Decisione: chiudere prima 0.17 su SQLite; subito dopo dedicare una versione al database principale PostgreSQL, usato anche in sviluppo e collaudo, prima di ulteriori funzioni. Nessun supporto PostgreSQL implementato o collaudato in 0.17. VerbalizzAI 1.0.1 rc2 preservato: archivio SQLite interno da valutare separatamente, non convertito automaticamente.

Analisi del codice: dipendenze SQLite nella connessione/PRAGMA, query date e group_concat, backup/ripristino; serializzazione delle scritture tramite RLock del singolo processo. Numerazioni, registro a catena e controllo delle versioni vanno verificati con transazioni e più processi PostgreSQL. SQLAlchemy/Alembic aiutano ma non rendono portabile automaticamente il prodotto.

Percorso raccomandato: inventario completo schema e allegati Garda; estrazione coerente MariaDB su copia fedele immutabile; trasformazioni versionate e mappa (archivio, tabella, ID originale) → ID NEXUS; importazione diretta nel modello PostgreSQL senza passaggio dal modello SQLite NEXUS. Ogni tabella/campo deve avere una destinazione o un'esclusione motivata approvata. Storico senza generare effetti operativi nuovi. Controlli automatici di collegamenti, duplicati, date, codifiche, stati, numerazioni, allegati/hash e riconciliazione economica; nessuno scarto silenzioso. Prove ripetibili, riesecuzione senza duplicati, prova generale su copia recente completa, backup e ripristino verificati. Al passaggio finale: sospensione scritture Garda, estrazione finale, importazione, riconciliazione e apertura NEXUS; ritorno a Garda prima della riapertura o procedura per recuperare eventuali nuove scritture NEXUS. Importatore attuale non completo.

Fonti primarie consultate: https://www.sqlite.org/whentouse.html ; https://www.postgresql.org/docs/current/ddl-constraints.html ; https://mariadb.com/docs/server/clients-and-utilities/backup-restore-and-import-clients/mariadb-dump . Snapshot --single-transaction coerente per tabelle transazionali, con attenzione alle modifiche DDL; non promessa per intero archivio senza inventario dei motori delle tabelle.

## C28 — Vietato riesaminare il proprio verbale (13/10/2026)

Richiesta esatta:

> aggiungo un elemnento: il verificatore (RT Federico nell'esempio) NON deve poter riesaminare il proprio vverbale!

Screenshot letto: esecutore e autore del riesame coincidono nell'esempio DPR. Non si riportano dati del cliente né si incorpora lo screenshot. Regola autorizzata: nessun verificatore, anche RT o amministratore, può riesaminare il proprio verbale; occorre un altro utente con permesso di riesame nell'attività. Protezione server, interfaccia e operazioni DM in blocco (tutto o niente). Non si alterano retroattivamente i riesami esistenti: individuazione e rimedio degli eventuali casi pregressi richiedono verifica separata dell'archivio operativo, qui non fornito.


## Chiusura implementazione 0.17.0 — 13/10/2026

C17–C26 e C28 implementati nel pacchetto 0.17.0; le sezioni «solo annotato» precedenti descrivono il momento dell'analisi e sono superate, sullo stato dell'implementazione, da questa chiusura e dal documento 44. Schema 0027 invariato. VerbalizzAI 1.0.1 rc2 invariato. Nessun dato operativo modificato.

Risultati effettivi: base 0.16 rieseguita, 317 test passati; suite completa 0.17, 346 test passati / 5 copie dell'avviso TestClient; 14 test mirati dopo l'ultima aggiunta all'audit export; 11 percorsi browser passati senza errori JS/500; aggiornamento sintetico da 0.16 con 63 tabelle preservate, escluso solo il catalogo delle etichette permessi. Log, comandi, iterazioni fallite e limiti nel documento 44 e nel pacchetto. Compilazione Python, sintassi di 37 JS e Ruff critico sui Python funzionali modificati passati.

C24: gli utenti importati disattivati restano esclusi correttamente; aggiunta spiegazione. Corretto anche l'affidamento DM che prima interrogava i valori DPR, verificato nel browser con RT DM senza ruolo DPR. C25: salvataggio atomico anagrafica+dati tecnici, firma/versione condivisa, bozza conservata e conflitti veri 409 mantenuti. C26: messaggi distinti e validazione Word/PDF; conversione reale di Word sintetico circa 1,2 MB passata; file reale dell'utente non fornito, caso specifico non riprodotto né dichiarato risolto. C28: autoriesame vietato anche per RT/amministratori e blocchi DM, senza modifiche retroattive ai riesami esistenti.

C27 resta pianificato e approvato: subito dopo la 0.17, database principale PostgreSQL e importazione completa/coerente MariaDB Garda; nessun supporto PostgreSQL implementato o collaudato qui. Documento 45 per ripresa LLM, 46 per percorso e criteri PostgreSQL/Garda, 47 per testi esatti delle richieste/approvazioni; nessun numero R inventato oltre R143. Ambiente provato Linux Python 3.12.3 / Chromium 134 / LibreOfficeDev 26.8 alpha: collaudo Windows operativo e file Word originale restano da verificare.
