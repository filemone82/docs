# 37 · Ripresa di NEXUS dopo la 0.16.0 (12/10/2026, sera)

Redatto da Claude per chi riprende lo sviluppo, anche su un'altra istanza o con un altro LLM. **Prevale sul documento 18 per lo stato del codice.** Il documento 18 resta il riferimento per:
- il registro completo delle decisioni (§ 3);
- le regole di lavoro (§ 8);
- il prompt di ripresa (§ 10).

Sostituisce la versione delle 18:30, «0.16 in corso», che indicava come base la wip2.

## 1. Dove siamo

| Voce | Stato |
|---|---|
| Ultima versione **consegnata** | `NEXUS_0.16.0_2026-10-12.zip`, SHA-256 `9f715435fc3f27dcf37e5d11b534ba1b277b2046c81a0ff5595009d876e69639`, commit `b13b9de`, schema Alembic **0027**, **317 test passati** (suite completa, LibreOffice reale nei test «pdf_vero») |
| Versione precedente | `NEXUS_0.15.0_2026-10-12.zip`, schema 0022, 297 test |
| Differenze | documento 43 nello ZIP (`documentazione/43_Differenze_0.16.0_2026-10-12.md`); copia nel progetto: `claude/38_Differenze_0.16.0_2026-10-12.md` |
| Lavoro non ancora nel commit | nessuno |
| Osservazioni di collaudo | documento 36: C1, C2 e C4–C16 realizzati. Le nuove osservazioni partono da C17 |

## 2. Decisioni realizzate nella 0.16.0

**Prossimo numero libero: R144.**

| N. | Decisione | Stato |
|---|---|---|
| R134 | Revisione di un verbale DM emesso | realizzata |
| R135 | Annullamento di un verbale DM da parte del verificatore assegnato o dell'RT | realizzata |
| R136 | Grafica di M14 e M11 come M01–M03 di VerbalizzAI, nella rev. 03 | realizzata. **I modelli sono «da approvare»**: Federico li approva dai PDF di prova, poi «Metti in uso» |
| R137 | Ambito del cliente, ereditato dalle sedi | realizzata (migrazione 0024, solo dati) |
| R138 | Accettazione e ordine sul preventivo: file e dati per la fattura elettronica | realizzata (migrazione 0026) |
| R139 | Fattura anche dalle verifiche DPR e dagli incarichi DM | realizzata |
| R140 | Copia di cortesia come Garda; numero `n/aaaa/DPR` | realizzata. Il formato della nota di credito, `n/aaaa/DPR-NC`, è da verificare su un XML vero |
| R141 | Gruppo fisso nella nuova attrezzatura; PSV a parte | realizzata |
| R142 | Prossima verifica obbligatoria alla registrazione | realizzata |
| R143 | Più ruoli per utente | realizzata (migrazione 0023) |
| — | Configurazione per attività: email, commerciali, strumenti, firme DM, modelli; «Tipi e tariffe» in Configurazione | realizzata (migrazione 0025) |
| — | Registrazione multipla degli incarichi DM (documento 28 p. 13) | realizzata |

## 3. Dove sta il codice nuovo

| Tema | File principali |
|---|---|
| Date alla registrazione, PSV | `moduli/beni/servizio.py` (`obbligatorie`, `date_iniziali`, `senza_prossima`), `static/js/beni.js` |
| Ambito dal cliente | `moduli/anagrafica/ambiti.py`, `doppioni.py`, `static/js/sedi.js` |
| Ruoli multipli | `moduli/utenti/modelli.py` (`UtenteRuolo`, `ruoli_di`), `core/accesso.py` (`per_attivita`), `static/js/utenti.js` |
| Email per attività | `core/posta.py` (`ImpostazioniPosta(cartella, attivita)`), `static/js/impostazioni_email.js` |
| Strumenti di misura DM e I&C | `moduli/strumenti/` (modelli, servizio, griglie, api) |
| Configurazione per attività | `web/pagine.py`, `templates/configurazione.html` |
| Accettazione e ordine | `moduli/preventivi/servizio.py` (`carica_allegato`, `salva_documenti_collegati`), `static/js/preventivi.js` |
| Fatture dalle verifiche | `moduli/finanza/servizio.py` (`righe_da_lavori`, `fattura_della_riga`), `static/js/schede.js` (`fatturaRighe`) |
| Copia di cortesia, cosa manca | `moduli/finanza/stampa.py`, `moduli/finanza/servizio.py` (`mancanti`) |
| Revisione verbali DM, registrazione multipla | `moduli/dm/tecnico.py` (`revisione`, `registra_in_blocco`, `prossima_calcolata`), `static/js/incarichi_dm.js` |
| Modelli rev. 03 | `strumenti/ristila_modelli_dm.py`, `gestionale/dati/modelli/*_rev03.docx`, `moduli/documenti/modelli_servizio.py` (`prepara_verbali_dm`, stato «da approvare») |
| Test | `tests/test_collaudo_016.py` (19 test) |

## 4. Rimasto fuori o da verificare

1. **XML delle fatture:** si rifiniscono alla fine, con XML veri di Garda e prova su Aruba (Federico, 17:37).
2. **Modello «impianto termico»:** lasciato da parte da Federico. In Configurazione AD_DM il posto non c'è.
3. **Approvazione delle rev. 03 di M14 e M11:** si fa sui PDF di prova inviati con la consegna.
4. **Bozza della fattura:** la scritta «BOZZA» è una fascia rossa in alto e non una scritta diagonale. Si cambia se Federico lo chiede.
5. **Nota di credito** `…/DPR-NC`: da confrontare con Garda.
6. **«Verbali di VerbalizzAI» per AD_DM:** manca l'importatore dei verbali DM da VerbalizzAI_DM, quindi la voce c'è solo in AD_DPR.
7. **Importazione completa da Garda** (documento 36, C3; documento 18 § 7): fatture e incassi DPR, preventivi, verifiche e fatture DM, I&C.

## 5. Test effettivamente eseguiti

| Prova | Esito |
|---|---|
| Suite completa sul commit `42813b2` | 316 passati, 1 fallito (`test_dati_e_backup::test_backup_verifica_e_ripristino`). Il test contava 5 documenti; con le due rev. 03 sono 7. Corretto nel commit `b13b9de` |
| **Suite completa sul commit consegnato `b13b9de`** | **317 passati**, in `report_collaudo/pytest_0.16.0.txt` |
| Prova a video con Chromium, archivio di prova portato all'avvio da 0022 a 0027 | configurazione per le tre attività, modelli, strumenti, firme DM, email, elenchi verifiche e incarichi, scheda dell'incarico con revisione, registrazione multipla, preventivo con «Accettazione e ordine». Dopo le correzioni del documento 43 § 8, **nessun errore JavaScript** |

## 6. Prossimo intervento

Nessun lavoro a metà. Le prossime cose, da concordare con Federico:
1. il suo collaudo della 0.16.0, con le osservazioni nel documento 36 da C17;
2. l'approvazione delle rev. 03 di M14 e M11;
3. l'ordine dei lavori del documento 18 § 7, con l'importazione completa da Garda e gli XML alla fine.

## 7. Vincoli da ricordare

- VerbalizzAI 1.0.1 rc2 non si modifica (R111).
- Niente dati veri dei clienti in codice, test, documenti o artefatti. I verbali DM di riferimento e i PDF delle fatture di Garda contengono dati veri e restano sul PC di Federico.
- Le credenziali non si usano.
- Il codice si scrive solo con il via di Federico. Se chiede di annotare, si annota nel documento 36 senza toccare il codice.
