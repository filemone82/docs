# Percorso verso il gestionale completo AD / I&C

10 ottobre 2026. Indicazioni di Federico delle 07:25–07:27, ora italiana. Questo documento precisa la direzione del progetto e prevale sulle precedenti proposte di semplificazione incompatibili con tali indicazioni.

## Risultato richiesto

Un solo prodotto, mantenibile ed estendibile senza dipendere dal fornitore attuale, con tre frontend separati — AD_dpr, AD_dm e I&C — e un backend comune nella base Python scelta per il progetto. VerbalizzAI aggiornato opera all'interno. Il risultato da portare al collaudo deve comprendere TUTTE le funzionalità Garda pertinenti, con dati, controlli, documenti e azioni equivalenti.

Il motivo del progetto è l'autonomia nelle implementazioni e modifiche, oggi molto costose. Garda funziona bene: non si parte dall'ipotesi di doverne ripensare il lavoro operativo.

## Metodo scelto

La strada raccomandata è trasferire le funzioni esistenti nel prodotto unico, conservando la base integrata dove è compatibile e riscrivendo le parti mancanti nel medesimo sistema. Il sorgente PHP/JS, i dump e i cataloghi sono il riferimento di comportamento. Non si avviano tre nuovi programmi né una riscrittura autonoma di VerbalizzAI.

Si condividono servizi realmente comuni: accesso, riferimenti a clienti/sedi/beni, documenti, modelli, posta, registro e backup; si conservano le regole proprie di ciascuna attività. Gli incassi e la fatturazione restano pertinenti all'emittente AD o I&C e ai relativi sezionali. L'ambiente scelto nel menu non cambia l'identità fiscale.

La struttura tecnica può cambiare quanto occorre all'unificazione. Gli effetti concreti vanno tracciati: ad esempio, la sincronizzazione adsrl↔iec cessa di essere un comando fra database distinti, perché i moduli leggono il medesimo bene e le attività scrivono i dati condivisi. Rimangono da preservare date, riferimenti, cronologia e controlli; la semplice eliminazione del vecchio comando non autorizza a perdere questi effetti.

## Cosa conserva il progetto e cosa può cambiare

| Aspetto | Criterio vincolante |
|---|---|
| Logiche, flussi e controlli Garda | Conservare; variazioni solo se decise con Federico o necessarie all'unificazione, con conseguenze esplicite. |
| Regole, campi, azioni multiple, filtri, export, stampe, import e modelli | Nessuna omissione o semplificazione tacita. Una voce assente è lavoro da completare. |
| Vecchie sincronizzazioni fra gestionali | Sostituire con riferimenti e scritture comuni, mantenendo gli effetti operativi pertinenti. |
| AD_dpr già sviluppato | Riutilizzare nelle parti compatibili; una precedente implementazione non prova automaticamente la parità con Garda. |
| VerbalizzAI | Incorporare la versione aggiornata, conservandone i comportamenti documentali e verificando il raccordo. |
| Molti click | Ridurre passaggi ripetitivi senza saltare controlli o cambiare il significato delle azioni. |
| Dashboard AD_dm | Ridisegno autorizzato; saranno presentate quando le funzioni sottostanti saranno verificate. |

Le anomalie e le raccomandazioni dei cataloghi non diventano automaticamente correzioni autorizzate. Ogni scostamento funzionale deve distinguere ciò che Garda fa, ciò che la nuova implementazione fa e l'eventuale decisione dell'utente. L'indicazione «da correggere» in un rapporto non è da sola un consenso.

## Sequenza di lavoro concreta

| Passaggio | Lavoro tecnico | Risultato verificabile |
|---|---|---|
| 1. Fissare la base e il perimetro | Riprendere checkpoint, sorgenti, dump, cataloghi e decisioni; censire anche le funzioni fuori dai cataloghi. | Elenco completo con fonte, corrispondenza nel nuovo prodotto, stato e prova. |
| 2. Raccordare VerbalizzAI aggiornato | Integrare 1.0.1 rc2; verificare emissione, ritocchi ammessi, PDF definitivo, permessi, riesame, invio, revisioni e backup. | Generatore attuale nel prodotto unico, senza secondo accesso o seconda anagrafica operativa. |
| 3. Completare AD_dm | Schede e scadenze per tipologia, tariffazione, preventivi, incarichi, precedenti, GVR/SC/SP, documenti, riesame, fatturazione, incassi e pacchetti INAIL. | Gli stessi casi operativi Garda completabili nel nuovo frontend, con risultati confrontati. |
| 4. Completare I&C e controllare DPR | Punti/sottopunti, prezzi a corpo/singoli, sconti, attività, date comuni, collaboratori/provvigioni, documenti, fatture e incassi; verificare copertura DPR. | Tutte e tre le attività operano sul medesimo backend; nessuna sincronizzazione manuale fra AD e I&C. |
| 5. Migrare e riconciliare una copia reale | Importare storici e relazioni con riferimenti stabili; verificare numeri, importi, date, stati e documenti disponibili; rendere ripetibile il caricamento. | Archivio di collaudo riconciliato, con eccezioni nominative e senza correzioni automatiche non concordate. |
| 6. Collaudare il prodotto completo | Percorsi reali amministrativi e tecnici, griglie/azioni multiple, documenti Word/PDF, INAIL, permessi, backup/ripristino e installazione prevista. | Una candidata completa da provare, con elenco esplicito delle sostituzioni dovute all'unificazione. |

Gli incrementi intermedi sono checkpoint di lavoro recuperabili. Non chiediamo a Federico di installare o validare ogni piccolo pezzo, e non presentiamo un checkpoint come il prodotto richiesto. Il primo collaudo complessivo deve riguardare il gestionale integrato, non soltanto un nucleo comune o un insieme di maschere vuote.

## Documenti definitivi e riduzione dei passaggi

Il problema concreto indicato da Federico riguarda la generazione Word di offerte e verbali AD_dm, i ritocchi manuali e l'impossibilità di inviare direttamente il PDF definitivo modificato. Il percorso richiesto è quello già apprezzato in VerbalizzAI: preparazione del documento, eventuale ritocco ammesso, controllo del PDF, emissione/approvazione pertinente, conservazione del definitivo e invio dello stesso file conservato. Il reinvio deve riprendere quel definitivo; una modifica successiva deve restare riconoscibile nello storico.

Le offerte DM già hanno nel checkpoint parte del percorso anteprima/ritocco/approvazione/invio: lo si verificherà ed estenderà alle parti mancanti. Questo non dimostra che il ciclo dei verbali DM sia completo. Il tipo di controllo, firma e riesame resta pertinente al documento; non si trasferisce automaticamente il riesame DPR a tutte le attività I&C.

## Responsabilità e tempi

L'assistente gestisce scelte di codice, struttura interna, compatibilità, prove e documentazione. Federico interviene sul funzionamento operativo e sui reali scostamenti da Garda, con esempi concreti e una questione alla volta. Non gli si chiede di definire tabelle, librerie o strategie di migrazione.

Per arrivare in tempi brevi si riusa il lavoro compatibile, si mantiene una sola base, si evitano cambi di tecnologia e si rinviano miglioramenti non necessari oltre ai due già indicati: percorso documentale e dashboard DM. Una data di consegna attendibile richiede la verifica delle parti mancanti; un numero di test superati non misura la completezza delle funzioni. Le verifiche di copertura servono a stimare e governare il lavoro, senza trasformarsi in un nuovo progetto soltanto documentale.

## Stato effettivo al termine del primo raccordo

Checkpoint interno 0.11.1-dev: VerbalizzAI 1.0.1 rc2 incorporato; corretto lo strumento di aggiornamento per import multipli e sostituzione verificata. Nessuna nuova migrazione oltre alla 0013; nessuna modifica in produzione. Inventario iniziale: 151 regole dei cataloghi e metadati interpretati dei tre sistemi, con dettagli nel rapporto 26. Non è ancora un inventario esaustivo di ogni percorso PHP/framework, né una matrice interamente collaudata.

I moduli DM e I&C, la migrazione completa e la dashboard restano da completare secondo il perimetro sopra. Il dettaglio dei controlli eseguiti su questo checkpoint è nel file STATO_IMPLEMENTAZIONE_0.11.1-dev.md.

## Avanzamento successivo — 0.12.0-dev

Il rapporto 27 documenta il ciclo DM ora realizzato: precedenti nativi, generazione GVR/SC/SP, modelli controllati, Word ritoccato/PDF, conferma del definitivo, chiusura, riesame, aggiornamento delle date e invio del file conservato. Schema 0014; VerbalizzAI 1.0.1 rc2 conservato. Prove e limiti nello stato 0.12 e nella matrice 26 aggiornata. La sequenza e il traguardo sopra rimangono validi: fatturazione DM collegata e INAIL, poi I&C e riconciliazione. Nessuna rinuncia alle funzioni aperte e nessuna installazione intermedia richiesta a Federico.
