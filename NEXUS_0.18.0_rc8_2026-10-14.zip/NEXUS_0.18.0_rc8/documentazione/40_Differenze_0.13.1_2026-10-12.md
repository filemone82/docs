# 40 · Differenze della 0.13.1 rispetto alla 0.13.0

12/10/2026 · Redatto da Claude · Schema Alembic **0021** (nuova migrazione, § 2).

Fonti:
- decisioni di Federico del 12/10/2026, dalle 12:19 alle 13:32: nome NEXUS e logo (R133), ruoli distinti per attività (R132), regole per i rilievi AD-REV-006 e 007;
- registro del revisore sulla 0.13.0: AD-REV-006, 007, 008 e l'osservazione sul documento 18.

## 1. NEXUS (R133)

Il gestionale integrato si chiama **NEXUS**.

Dove si vede:
- **schermata di accesso e primo avvio:** logo chiaro «nexus · INTEGRATED HUB»;
- **menu laterale:** logo scuro, con sotto l'attività attiva;
- **scheda del browser:** icona dell'incrocio;
- **titoli delle pagine:** «… · NEXUS»;
- **finestre dei `.bat`**, messaggi di avvio e di backup, email di prova;
- **nome dello ZIP e della cartella:** `NEXUS_0.13.1_…`.

Restano uguali, per aggiornare senza spostare nulla:
- nomi tecnici del codice (pacchetto `gestionale`);
- file `.bat`;
- cartelle dei dati;
- `config.json`.

VerbalizzAI mantiene il suo nome come modulo dei verbali.

I file del logo sono in `gestionale/static/img/nexus/`: logo chiaro e scuro, icona chiara e scura.

## 2. Ruoli distinti per attività (R132)

Federico, 12/10/2026: «ruoli distinti direi»; «segreteria comune».

| Ruolo | Attività | Note |
|---|---|---|
| Amministratore | tutte | invariato |
| **RT DPR** | AD_DPR | era «Responsabile tecnico» |
| **RT DM** | AD_DM | nuovo |
| **Verificatore DPR** | AD_DPR | era «Verificatore» |
| **Verificatore DM** | AD_DM | nuovo |
| **Verificatore DM e DPR** | entrambe | nuovo, solo per verificatori |
| Segreteria | comune | anagrafiche, preventivi, fatture di tutte le attività |

### Cosa vale per attività

I **permessi tecnici** valgono solo nell'attività del ruolo. Sono: vedere, affidare, eseguire, riesaminare, annullare e rivedere le verifiche; stato tecnico degli impianti; strumenti; firme; rendicontazione INAIL; riesame del contratto. In concreto:
- **affidamento:** l'elenco dei verificatori mostra solo gli abilitati a quell'attività, e il server rifiuta gli altri;
- **elenchi e schede delle verifiche:** un RT DPR non vede né tocca gli incarichi DM, e viceversa;
- **riesame del verbale e del contratto:** solo dall'RT di quell'attività (o dalla segreteria, per il contratto);
- **VerbalizzAI:** è il modulo dei verbali AD_DPR, quindi chi lavora solo nel DM non vi ha permessi tecnici;
- **menu e scelta dell'attività:** chi ha una sola attività vede solo quella. Le pagine dell'altra rispondono «permesso negato». Amministratore e segreteria vedono tutto.

### Regola dei ruoli

Un ruolo che affida o riesamina le verifiche è un ruolo da RT: deve avere **una sola attività**, perché Federico ha chiesto «DM_e_DPR … verificatori, non RT». Il controllo vale:
- quando si salva il ruolo;
- quando si salvano i suoi permessi;
- quando lo si crea copiandolo da un altro.

Un ruolo copiato eredita l'attività di quello di partenza. In Gestione › Utenti e permessi, la scheda del ruolo ha le caselle **AD_DPR / AD_DM**; nessuna spunta significa ruolo comune.

### Migrazione 0021

Aggiunge la colonna `ruoli.attivita`. Sugli archivi esistenti:
- «Responsabile tecnico» e «Verificatore» diventano i ruoli AD_DPR. Il nome cambia in «RT DPR» e «Verificatore DPR» solo se era ancora quello di partenza;
- nascono «RT DM», «Verificatore DM» e «Verificatore DM e DPR», con gli stessi permessi dei corrispondenti DPR;
- gli utenti restano sul loro ruolo: **l'amministratore assegna i ruoli DM** a chi lavora nel D.M.

Il ritorno alla 0020 è bloccato se qualche utente ha già un ruolo DM.

## 3. Rilievi del revisore sulla 0.13.0

| Rilievo | Decisione | Correzione |
|---|---|---|
| **AD-REV-006**, osservazioni nel verbale combinato | Federico (13:32): «nel verbale combinato le osservazioni dell'ultimo verbale di funzionamento» | **Con funzionamento:** si ripropongono le osservazioni del gruppo «funzionamento», compresa una sua correzione a mano. È una scelta diversa da Garda, che prendeva la più recente fra le componenti; il test di parità è aggiornato e lo dice.<br>**Senza funzionamento** (integrità + interna): vale la più recente. A parità di data la correzione a mano vince sul verbale; fra due correzioni vale l'ultima.<br>La provenienza della bozza indica il gruppo e l'identificativo della versione usata |
| **AD-REV-007**, nome INAIL uguale per due verbali | Federico (13:32): «nel caso di gvr il nome file deve avere anche funz., integr. o interna» | **Nome INAIL dei GVR:** finisce con l'attività: `verbale <matricola><data> funz.pdf`, `… integr.pdf`, `… interna.pdf`; nel combinato `… funz-integr.pdf`. Senza il punto, per evitare «funz..pdf». La stessa regola vale per scheda tecnica e fattura nel lotto INAIL.<br>**Copia nella cartella:** un PDF diverso non sostituisce mai in silenzio una copia esistente. Va in «… (2).pdf» con un avviso; la stessa copia ripetuta non crea file nuovi |
| **AD-REV-008**, limite della firma DM | proposta, nessuna obiezione | Resta il limite reale di 50 × 20 pixel, lo stesso della firma DPR di VerbalizzAI, così la stessa scansione vale per tutte e due. Messaggio e documento 39 ora dicono «minimo 50 × 20, consigliato 300 × 100».<br>VerbalizzAI 1.0.1 rc2 ha la stessa incongruenza nel messaggio: non si tocca (R111) e va segnalata alla sua chat |

## 4. Documento 18

Riallineati alla base corrente:
- § 7, ordine dei lavori, con la nuova tempistica di Federico: NEXUS D.P.R. in produzione a marzo 2027, tutto il sistema a giugno 2027;
- § 10, istruzioni di ripresa.

## 5. Prove

| Prova | Esito |
|---|---|
| `tests/test_ruoli_attivita.py` (nuovo, 4 test) | ruoli di partenza con attività e permessi uguali fra DPR e DM; RT con una sola attività, verificatore con due, copia che eredita; nessuna mescolanza (elenchi dei verificatori, affidamento rifiutato fuori attività, schede e griglie dell'altra attività negate, riesame del contratto, VerbalizzAI, scelta dell'attività e menu); migrazione 0020 → 0021 di un archivio esistente |
| `tests/test_scheda_verbale_dm.py` (4 test nuovi) | AD-REV-006 nel combinato; AD-REV-007 nome INAIL con l'attività e nessuna sovrascrittura; AD-REV-008 limiti 49/50 pixel |
| Test DM esistenti | verificatori di prova con ruolo «Verificatore DM»; test di parità delle osservazioni aggiornato alla decisione di Federico |
| Prova dell'interfaccia con Chromium (copia dell'ambiente di prova migrata 0020 → 0021) | accesso e menu con il logo NEXUS; Ruoli con la colonna «Attività» e le caselle AD_DPR / AD_DM; nessun errore JavaScript |
| Suite completa | **284 test passati** (Linux, Python 3.13), `report_collaudo/pytest_0.13.1.txt` |

## 6. Prossimi passi

1. **0.14 · Fatture DPR complete, pari a Garda:** XML, controlli, note di credito, incassi, esiti di Aruba. È la priorità per la produzione del D.P.R. a marzo 2027.
2. **0.15 · Verbali DM finiti:**
   - modelli M-DM-GVR e M-DM-SCSP da approvare;
   - anteprima «BOZZA», firma ed emissione;
   - revisioni, annullamento e riesame;
   - storico di adsrl.
