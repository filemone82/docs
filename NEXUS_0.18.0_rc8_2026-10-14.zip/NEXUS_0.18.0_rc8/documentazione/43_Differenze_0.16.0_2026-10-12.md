# 43 · Differenze della 0.16.0 rispetto alla 0.15.0

12/10/2026 · Redatto da Claude · Schema Alembic da **0022** a **0027**: cinque migrazioni, che partono da sole all'avvio dopo un backup automatico.

Richiesta di Federico (12/10/2026, 17:50): «ci sono già abbastanza elementi, facciamo una versione 16?», poi «tutto quanto discusso». Fuori da questa versione per sua scelta:
- **XML delle fatture**: «per gli xml aspettiamo lo facciamo bene alla fine»;
- **modello «impianto termico»**: «lascia stare impianto termico fai tutto il resto».

I punti C1–C16 sono quelli del documento 36 (note di collaudo «da zero»). Le decisioni nuove sono R137–R143.

## 1. Attrezzature DM (C7–C13, R142)

**Le date si chiedono alla registrazione (R142, C12).** Una nuova attrezzatura senza prossima verifica non compare nello scadenziario: per questo la data diventa obbligatoria.
- **SC/SP:** prossima verifica obbligatoria; l'ultima è facoltativa.
- **GVR:** prossima verifica obbligatoria per **funzionamento** e **integrità**, se il tipo di catalogo le prevede (cioè non sono «N.A.» né vuote). Per la **visita interna** è obbligatoria se l'attrezzatura la prevede.
- Le date entrano nella scheda come date iniziali, con la stessa origine di quelle importate da Garda. Dal primo verbale in poi si calcolano da sole, come prima.
- Le attrezzature già in archivio senza prossima verifica sono segnalate in un avviso sopra l'elenco, con il collegamento a ciascuna.

**Nuova attrezzatura dalla sede (C7, C10).** Se si parte dall'elenco filtrato di una sede, la sede è già compilata. Il campo «Sede» completa mentre si scrive e propone prima le sedi AD_DM, poi tutte le altre.

**Gruppo (C8, C9):**
- dall'elenco GVR il gruppo è fisso a GVR;
- dall'elenco SC/SP si sceglie fra SC e SP;
- nella sede, il collegamento «Attrezzature» si divide in **GVR**, **SC/SP** e **Accessori · PSV**, ciascuno con il proprio conteggio (anche nel cliente).

**PSV a parte (C9).** La voce di menu diventa «Accessori · PSV». Le PSV non hanno matricola INAIL, che viene rifiutata se la si scrive. Hanno invece il campo **«Protegge»**, cioè l'attrezzatura protetta. La data di taratura è facoltativa.

**«Tipo attrezzatura verbale» solo GVR (C11).** Il campo è nei dati del verbale solo per i GVR. Su SC/SP un valore già salvato resta in archivio ma non si vede e non si stampa.

**PVP sulla prima scadenza (C13).** Quando un preventivo DM nasce dalle scadenze, la «prima verifica periodica» va solo alla **prima** scadenza filtrata per ciascuna attrezzatura, contando anche le righe già presenti nel preventivo. Le altre diventano «periodica successiva». Lo stesso vale per una riga aggiunta a mano: se l'attrezzatura ha già una riga V1, la nuova propone V2.

## 2. Ambito del cliente esteso alle sedi (C1, R137)

L'ambito di lavoro (AD_DPR, AD_DM, I&C) è del **cliente**. Le sedi lo ereditano:
- nella scheda della sede l'ambito si vede ma non si cambia; un valore diverso da quello del cliente viene rifiutato e il messaggio dice di cambiarlo sul cliente;
- un ambito acceso sul cliente passa a tutte le sue sedi, anche a quelle nuove;
- un ambito si spegne sul cliente solo se nessuna sua sede ha ancora impianti o attrezzature di quell'ambito; il messaggio nomina la sede;
- un impianto, un'attrezzatura o un preventivo che accende l'ambito di una sede lo accende sul cliente, e quindi su tutte le sue sedi;
- nella ricerca delle sedi AD_DM vengono prima quelle che hanno attrezzature.

**Migrazione 0024** (solo dati): il cliente prende l'unione degli ambiti delle sue sedi, poi ogni sede prende quelli del cliente.

## 3. Utenti con più ruoli (R143)

Un utente può avere più ruoli, uno per attività: per esempio RT e verificatore in AD_DPR, verificatore in AD_DM.
- Nella scheda utente i ruoli sono caselle di spunta; nell'elenco la colonna diventa «Ruoli».
- I permessi tecnici si controllano sul ruolo dell'attività in cui si lavora.
- L'elenco dei verificatori di un'attività comprende chi ha quel ruolo in quella attività.

**Migrazione 0023:** tabella `utenti_ruoli`. Il ruolo che l'utente già aveva resta il principale.

## 4. Configurazione per attività (C14, C15, C16)

La pagina **Configurazione** mostra le voci dell'attività scelta in alto, poi quelle comuni.

| | AD_DPR | AD_DM | I&C |
|---|---|---|---|
| Modelli | M01–M03 di VerbalizzAI, preventivo DPR | verbali GVR e SC/SP, preventivo DM | preventivo I&C |
| Firme dei verificatori | firme DPR | firme DM (pagina nuova) | — |
| Strumenti di misura | quelli di VerbalizzAI | registro DM (nuovo) | registro I&C (nuovo) |
| Commerciali | quelli con AD_DPR | quelli con AD_DM | quelli con I&C |
| Impostazioni email | proprie | proprie | proprie |
| Cataloghi | Tariffario | Tipi e tariffe (spostato dal menu) | — |
| Verbali di VerbalizzAI | importazione e collegamenti | — | — |

**Comuni a tutte:** tipi di pagamento, aliquote IVA, termini di esecuzione, elenchi di valori, importazione dati, registro operazioni, backup e integrità.

Dettagli:
- **Email (C15):** ogni attività ha il proprio server e mittente. I preventivi usano quelli della loro attività; i verbali DM quelli di AD_DM; i verbali VerbalizzAI quelli di AD_DPR. Il file di impostazioni precedente, unico, vale per tutte e tre finché non le si separa. La password si può dare anche con la variabile `GESTIONALE_SMTP_PASSWORD_DPR` (o `_DM`, `_IEC`).
- **Commerciali:** hanno le caselle AD_DPR, AD_DM e I&C. Nella scheda cliente si propongono solo quelli della stessa attività. Un commerciale nuovo è AD_DPR finché non si cambia; quelli importati da ingecert sono AD_DPR.
- **Strumenti di misura DM e I&C:** registro nuovo con denominazione, costruttore, modello, matricola, certificato, data di taratura e scadenza, come il registro strumenti di VerbalizzAI.
- **Firme DM:** pagina propria con i dati del tecnico e la firma grafica DM di ciascun verificatore AD_DM.
- **Modelli Word:** la pagina mostra solo i modelli dell'attività. È nato il tipo «Preventivo I&C».

**Migrazione 0025:** caselle di attività dei commerciali e tabella `strumenti_misura`.

## 5. Accettazione, ordine e dati per la fattura elettronica (C2, R138)

Il preventivo ha una nuova linguetta **«Accettazione e ordine»**:
- **file del cliente:** preventivo controfirmato, ordine, email salvata in PDF. Restano in archivio con la loro impronta, valgono come evidenza dell'accettazione e si vedono anche nella linguetta Riesame. Si possono togliere: il file resta nel registro;
- **dati per la fattura elettronica**, come la linguetta «Fattura» di Garda: tipo di documento (ordine d'acquisto, contratto, convenzione, ricezione, fattura collegata, DDT, fattura principale), numero, data, CIG, CUP, commessa/convenzione. Passano da soli nella fattura che nasce dal preventivo; se sono uguali per tutte le righe compaiono una volta sola. Il primo ordine d'acquisto aggiorna il «Riferimento ordine» del preventivo.

All'accettazione, l'evidenza può essere il testo, come prima, oppure un file caricato. Se manca il file, un avviso consiglia di caricarlo.

L'importatore di Garda legge questi dati dalla linguetta «Fattura» dei preventivi.

**Migrazione 0026:** colonna `documenti_collegati` e tabella `preventivi_allegati`.

## 6. Fatture dalle verifiche e copia di cortesia (C4–C6, R139, R140)

**Fattura anche dalle verifiche (R139, C4).** Resta la generazione dalle righe del preventivo, come in Garda. In più:
- negli elenchi delle verifiche DPR e DM c'è **«Fattura le selezionate…»**;
- nella scheda di una verifica o di un incarico c'è **«Fattura questa verifica…»**.

Il programma risale alle righe del preventivo di quelle verifiche e prepara la bozza. Se una riga è già in una fattura, la scheda della verifica lo mostra.

**Numero (R140).** La fattura si numera `numero/anno/DPR`, per esempio `12/2026/DPR`; la nota di credito `numero/anno/DPR-NC`. Il formato della nota di credito va confrontato con un XML vero di Garda (§ 9).

**Copia di cortesia come Garda (R140, C5).** Il documento è stato rifatto sul modello dei PDF di Garda:
- intestazione AD con logo;
- riquadro del cliente;
- numero e data;
- tabella delle righe con quantità, prezzo, importo e IVA;
- in fondo, i riferimenti a preventivo e ordine quando sono uguali per tutte le righe; se cambiano, ciascuno sta nella sua riga;
- riepilogo IVA, totali, modalità di pagamento, scadenze, totale dovuto;
- «Pag. X di Y» nel piè di pagina;
- il nome del file segue Garda.

La bozza porta la fascia rossa «BOZZA – non valida ai fini fiscali».

**Cosa manca, prima di emettere (C6).** La bozza elenca cosa manca:
- dati fiscali di AD;
- indirizzo e codice fiscale/partita IVA del cliente;
- righe.

L'emissione si ferma con «Prima di emettere manca: …». Prima, da un archivio vuoto, finiva con un errore imprevisto. Gli XML restano come nella 0.15 e si rifanno alla fine, come chiesto.

## 7. Verbali DM: revisione, annullamento, registrazione multipla, modelli rev. 03

**Revisione di un verbale emesso (R134).** Nella scheda dell'incarico effettuato c'è **«Crea revisione (rev. N)»**, con il motivo obbligatorio. Possono farla l'RT o il verificatore assegnato. Cosa succede:
- l'incarico torna «registrato» con lo stesso numero di verbale e «rev. N» nel nome dei documenti e nel nome INAIL;
- il riesame si azzera e l'esportazione INAIL va rifatta;
- i CND del verbale precedente si annullano e si ricalcolano alla nuova emissione;
- le revisioni restano nell'elenco della scheda, con data, autore e motivo.

**Annullamento (R135).** Possono farlo l'RT o il verificatore assegnato, con il motivo.

**Registrazione multipla (documento 28 p. 13).** Nell'elenco degli incarichi DM c'è «**Registra le selezionate…**». Si scelgono:
- la data di rilascio;
- l'esito, se non è già nella scheda;
- le prossime date per attività (funzionamento, integrità, visita interna, SC/SP).

Una data lasciata vuota si prende dalla scheda; se manca anche lì, si calcola dalla periodicità del catalogo. La registrazione vale per tutti o per nessuno: si registrano solo gli incarichi affidati a chi registra, con l'indipendenza dichiarata. I numeri dei verbali si assegnano in ordine.

**Modelli M14-PO01_dm e M11-PO01_dm rev. 03 (R136).** Hanno la grafica dei modelli M01–M03 di VerbalizzAI:
- carattere Calibri;
- testo grigio ardesia;
- titoli delle sezioni in verde AD con la riga sotto;
- tabelle con bordi sottili e intestazioni su fondo chiaro;
- piè di pagina «rev. 03 del 12.10.2026».

Il contenuto (testi, segnaposto, sezioni) è quello della rev. 02 approvata. Entrano in archivio con lo stato **«da approvare»**: si mettono in uso da Configurazione › Modelli con «Metti in uso», dopo l'approvazione. I PDF di prova con dati inventati sono consegnati con questa versione.

Nella pagina dei modelli lo stato ora distingue:
- «in uso»;
- «superato», cioè un modello che è stato in uso;
- «da approvare», cioè un modello caricato e mai messo in uso.

**Migrazione 0027:** colonne `revisione` e `revisioni_json` degli incarichi DM.

## 8. Correzioni trovate nella prova a video

- Nella linguetta «Accettazione e ordine» compariva la scritta «null» sotto i dati per la fattura.
- I modelli rev. 03 «da approvare» comparivano come «superato».
- Due stili scritti dentro la pagina erano bloccati dalla politica di sicurezza (CSP): il titolo «Dati per la fattura elettronica» e l'anteprima della firma DM (questa dalla 0.13). Ora usano classi del foglio di stile.
- L'avviso «manca la firma DM» nella scheda dell'incarico porta a Configurazione › Firme dei verificatori, la nuova pagina.
- Nella finestra «Registra le selezionate» il singolare è «l'incarico».

## 9. Rimasto fuori o da verificare

- **XML delle fatture:** rimandati alla fine, per scelta di Federico.
- **Modello «impianto termico»:** lasciato da parte per scelta di Federico (documento 36, C16).
- **Approvazione delle rev. 03 di M14 e M11:** dai PDF di prova; poi «Metti in uso».
- **Bozza della fattura:** fascia rossa «BOZZA» in alto invece della scritta in diagonale; si cambia facilmente se Federico la preferisce in diagonale.
- **Numero della nota di credito** `…/DPR-NC`: da confrontare con un XML vero di Garda.
- **«Verbali di VerbalizzAI» per AD_DM:** la voce c'è solo in AD_DPR, perché l'importatore dei verbali DM da VerbalizzAI_DM non esiste ancora.
- **Importazione completa da Garda** (C3): fatture e incassi, preventivi, verifiche e fatture DM restano previsti (documento 18 § 7).

## 10. Prove

| Prova | Esito |
|---|---|
| `tests/test_collaudo_016.py` (nuovo, 19 test) | date obbligatorie alla registrazione (SC/SP, GVR per attività di catalogo, visita interna); elenco delle attrezzature senza prossima verifica; PSV senza matricola INAIL e con «Protegge»; tipo attrezzatura verbale solo GVR; conteggi GVR, SC/SP e PSV nella sede; PVP alla prima scadenza; posta per attività e file precedente; commerciali per attività; strumenti DM e configurazione per attività; file di accettazione e dati per la fattura; fattura dalle verifiche; emissione da archivio vuoto con l'elenco di cosa manca; copia di cortesia con LibreOffice reale; revisione e annullamento dei verbali DM; rev. 03 GVR e SC/SP con LibreOffice reale (stato «da approvare», poi in uso e precedente «superato»); registrazione multipla, anche con date dalla periodicità |
| Test aggiornati | ambiti dal cliente (R137); utenti con più ruoli; menu per attività; griglie («Ruoli»); fatture con DDT e fattura principale; testa delle migrazioni 0027; documenti controllati nel backup (7, con le due rev. 03) |
| Suite intera (`python -m pytest -q -p no:cacheprovider`, LibreOffice reale) | **317 passati**, in `report_collaudo/pytest_0.16.0.txt`. La prima esecuzione aveva un solo fallimento: il test del backup contava 5 documenti, che con le due rev. 03 sono 7. Il test è stato aggiornato |
| Prova a video con Chromium (archivio di prova portato da 0022 a 0027 all'avvio) | configurazione per AD_DPR, AD_DM e I&C; modelli DM con le rev. 03 «da approvare»; strumenti di misura; firme DM; impostazioni email; elenco incarichi DM con «Fattura / Registra le selezionate»; scheda dell'incarico effettuato con «Crea revisione (rev. 1)»; finestra della registrazione multipla; preventivo con la linguetta «Accettazione e ordine»; nessun errore JavaScript dopo le correzioni del § 8 |
