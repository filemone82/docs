# Gestionale integrato — documento quadro

**Versione del documento:** 1.95. **Aggiornamento:** 10 ottobre 2026, ora italiana. **Ambito:** sintesi della conversazione disponibile, dei materiali ricevuti, delle proposte e delle decisioni acquisite, con implementazione progressiva del gestionale integrato.

**Stato corrente del codice:** checkpoint interno 0.12.0-dev, migrazione 0014, VerbalizzAI incorporato 1.0.1 rc2. DM fino a generazione Word/PDF, conferma del definitivo, chiusura, riesame e date per componente. Fatturazione DM collegata, INAIL, I&C, dashboard e migrazione completa ancora aperti. R101–R106: trasferimento fedele di tutte le funzioni compatibili. Rapporti 25–27; nessuna istanza parallela avviata.

Questo è il riferimento unitario del progetto. Le analisi precedenti restano evidenze di dettaglio; questo documento ne riporta gli esiti attuali e le successive correzioni. “Verificato” indica un riscontro sui materiali o una prova eseguita; “proposto” non equivale ad approvato o implementato.

**Regola generale vincolante R73:** le regole presenti nei gestionali Garda sono il riferimento funzionale da conservare o modificare consapevolmente. Ogni omissione, comportamento difforme o deroga alle regole richiede valutazione espressa e consenso esplicito dell’utente. Le deroghe necessarie all’integrazione sono ammesse e considerate fisiologiche: database, collegamenti e interazioni fra i tre moduli saranno riprogettati per il nucleo comune. La verifica riguarda gli effetti sulle regole operative, sui controlli e sui risultati; non richiede una copia delle strutture tecniche Garda né un’approvazione per ogni dettaglio interno. Rimane confermata la riscrittura Python, senza adattare il PHP.

**Situazione attuale:** basi precedenti conservate, prosecuzione su copia 0.12.0-dev. Ciclo documentale e chiusura DM nel rapporto 27; nessuna dichiarazione di parità completa o nuova deroga. Le sezioni precedenti sono storiche; passaggio corrente nella sezione 78. Nessuna operazione sul VPS o sui gestionali di produzione.

**Ultima indicazione strutturale:** sezione 73 e rapporto 21: verificata la differenza preventivi DM/DPR; cliente e sede obbligatoria nella testata DM, solo cliente e impianti multisede nelle righe DPR (168 offerte multisede nel backup). Si conserva cliente→sedi→beni; testata comune con cliente e sede di contesto già prevista nel disegno v0.3. Nessun consenso automatico a nuove offerte DM multisede, nessuna ristrutturazione applicata qui. R99 richiede che il prossimo rilascio funzionale integri davvero DPR e DM; la manutenzione duplicati 0.8.1/0.9.1 già pronta non è quel rilascio. Importazione conservativa possibile, con discrepanze esplicite e senza dividere/unire gli emessi.

**Ultimo passaggio concreto:** precompilazione dai precedenti nativi, modelli Garda GVR/SC/SP, etichette, firma comune, documento corrente e conferma PDF, chiusura/riesame DM, scadenze pertinenti e CND. Tre ambienti della stessa applicazione. Prove e limiti nella sezione 78/rapporto 27.

**Stato attuale del progetto:** priorità R97/R99/R106 confermate: prodotto integrato completo; Excel alla fine. B2 avanzato fino al ciclo documentale DM, non chiuso. Finanza DM, B3–B5/INAIL/I&C da completare. Schema progettuale v0.3/E-R resta proposta, distinto dalle migrazioni applicative 0011–0014. Import completo/incrementale e COES-01 non risolti. Rapporto 27, stato 0.12 e scheda 00 danno la ripresa aggiornata.

**Lettura breve attuale:** la sezione 30 descrive il codice della candidatura 0.8.0, le prove osservate e i limiti; la sezione 29 conserva la sintesi funzionale precedente. La sezione 32 avvia l’approfondimento AD_DM su classificazione e INAIL; la sezione 33 fissa il criterio generale di conservazione delle regole Garda; la sezione 34 chiarisce acquisizione e manutenzione manuale della classificazione. La sezione 35 registra la cadenza trimestrale INAIL e il metodo di approfondimento progressivo. La sezione 36 approfondisce il generatore dei verbali DM e la provenienza dei dati GVR. La sezione 37 collega gli attributi delle attrezzature ai modelli Word ora forniti. La sezione 38 chiarisce volume delle camere e DN delle tubazioni. La sezione 39 conferma il legame preventivo–tariffa–verbale singolo/multiplo. La sezione 40 ribadisce il riferimento funzionale Garda per DM e I&C e la valutazione delle conseguenze del database unico. La sezione 41 ricostruisce le scadenze GVR per componente e la data sintetica del verbale/INAIL. La sezione 42 completa il percorso di esportazione INAIL; la sezione 43 chiude il dubbio sulla classificazione conservando la lettura dagli attributi attrezzatura. La sezione 44 ricostruisce il ponte DM–I&C e i preventivi a punti/sottopunti. La sezione 45 registra il software tecnico esterno in sviluppo e il riferimento al numero di report CND. La sezione 46 registra il report CND per singola attrezzatura come caso ordinario. La sezione 47 ricostruisce incassi e compensi dei collaboratori I&C e apre il chiarimento sul loro utilizzo. La sezione 48 conferma il mantenimento dei compensi dei collaboratori I&C; la sezione 49 ricostruisce la distinzione dall’esecutore tecnico; la sezione 50 acquisisce il chiarimento dell’utente e valuta le conseguenze sul database comune. La sezione 51 registra la prassi I&C di attendere il report pronto e distingue disponibilità, invio e incasso. La sezione 52 fissa il flusso commerciale I&C di invio via email, fatturazione e incasso successivo; la sezione 53 introduce il chiarimento sull’aggregazione DM/DPR, chiuso nella sezione 54 con la separazione di preventivi e fatture. La sezione 55 verifica il raccordo con il codice DPR attuale e il lavoro necessario prima di attivare DM. Il registro R01–R97 conserva le decisioni; le proposte precedenti vanno lette con i successivi chiarimenti e non diventano implementazioni per il solo fatto di essere documentate.

## 1. Obiettivo e perimetro

Ricostruire fedelmente tutte le funzionalità pertinenti dei tre gestionali Garda nel prodotto unico Python, con tre frontend separati e backend comune. **Garda è il riferimento operativo: nessuna semplificazione, omissione o riprogettazione tacita dei flussi.** Si riusano VerbalizzAI e AD_dpr già sviluppato nelle parti compatibili; cambiano gli aspetti necessari all’unificazione o concordati con Federico. L’obiettivo è autonomia dal fornitore nelle implementazioni future.

| Nome del gestionale attuale | Nome usato nella conversazione | Attività | Società |
|---|---|---|---|
| ingecert | AD_dpr | Verifiche DPR 462 | AD S.r.l. |
| adsrl | AD_dm | Verifiche su attrezzature a pressione e sollevamento | AD S.r.l. |
| iec | I&C | Consulenza, controlli e tarature | I&C S.r.l. |

Direzione di lavoro: un nucleo comune e interfacce dedicate alle tre attività. AD e I&C S.r.l. restano distinte per emissione e contabilità. La precedente incorporazione di I&C snc in AD nel 2025 non implica la disattivazione di I&C S.r.l.

La sequenza discussa è: rilascio autonomo di VerbalizzAI con il proprio collaudo; costruzione del gestionale integrato; avvio limitato ad AD_dpr; estensione ad AD_dm e I&C quando il funzionamento DPR è validato nell’uso. **DM e I&C entrano nel progetto del nucleo fin dall’inizio**, anche se saranno attivati dopo.

## 2. Requisiti e indirizzi raccolti

| Rif. | Requisito o indirizzo | Stato |
|---|---|---|
| R01 | Progettare inefficienze, mancanze e semplificazioni prima di scrivere altro codice applicativo. | Richiesta esplicita attuale. |
| R02 | Coprire le tre attività in un sistema integrato, con funzioni e viste pertinenti a ciascuna. | Obiettivo del progetto; dettaglio da definire. |
| R03 | Preservare dati storici, collegamenti, numeri, documenti e importi. | Necessità emersa dalla revisione; verifiche ancora da completare. |
| R04 | Tenere distinto il rilascio di VerbalizzAI dalla sostituzione del gestionale. | Percorso discusso e raccomandato; lo stato del rilascio reale non è attestato qui. |
| R05 | Attivare prima AD_dpr, poi AD_dm e I&C dopo validazione nell’uso. | Sequenza di riferimento discussa. |
| R06 | Riutilizzare Gestionale_AD v0.7.1 dove utile, senza assumere tutte le sue scelte come definitive. | Riuso avviato nella 0.8.0: nucleo Python, anagrafiche, preventivi, incarichi, permessi, backup e innesto VerbalizzAI. Nuovo modulo economico e correzioni dei flussi. Confine fisico degli archivi e integrazione futura ancora da completare. |
| R07 | Eliminare la ricopiatura e la sincronizzazione manuale dei dati condivisi AD_dm/I&C. | Miglioramento proposto su inefficienza verificata. |
| R08 | Distinguere avanzamento, riesame, documento consegnato e fatturazione; rendere affidabili scadenze e rettifiche. | Proposta concettuale da validare. |
| R09 | Conservare controlli utili già presenti, inclusa l’indipendenza del verificatore, con evidenze verificabili. | Regola Garda accertata; comportamento futuro da definire con le procedure. |
| R10 | Abbinare VerbalizzAI all’anagrafica tramite riferimenti stabili, preservando UUID, versioni e contenuti. | Ponte minimo proposto, non implementato nel sorgente autonomo esaminato. |
| R11 | Riallineare i dati durante la convivenza senza ricreare le identità canoniche. | Requisito tecnico proposto; import incrementale non ancora disponibile. |
| R12 | Mantenere aggiornati documento quadro e approfondimenti con requisiti, analisi, decisioni, progresso, dubbi e prossimo passo, per iterare anche da un’altra istanza. | Richiesta esplicita ribadita dall’utente. Documento quadro 1.88 e scheda di ripresa; aggiornare gli artefatti pertinenti a ogni passaggio significativo, distinguendo proposte, riscontri e implementazione. |
| R13 | Procedere senza fornire adesso gli originali S3, per motivi di spazio. | Vincolo esplicito dell’utente. Recupero e verifica dei contenuti rinviati; analisi dei processi e dei metadati prosegue. |
| R14 | Nel DPR predisporre normalmente un nuovo contratto a ogni scadenza; supportare come eccezione gli affidamenti pluriennali, ad esempio dei Comuni. | Prassi dichiarata dall’utente: circa 99 casi su 100 con contratto a scadenza. Requisito raccolto; dettagli dell’eccezione da definire. |
| R15 | Per AD_dpr usare ISPESL 2005 per terra e scariche atmosferiche; tariffa oraria per luoghi con pericolo di esplosione. | Regola operativa dichiarata dall’utente; tariffe normalmente uguali al ciclo precedente. Per ATEX vale l’importo del preventivo, come precisato in R17. |
| R16 | Prevedere la possibilità di sconti DPR, citata per gare verso la PA. | Possibilità dichiarata dall’utente; criteri, modalità e autorizzazioni da precisare. Non è attestata qui una prassi abituale di sconto. |
| R17 | Per ATEX assumere l’importo concordato nel preventivo senza variazioni a consuntivo. | Regola esplicita dell’utente; coerente con il percorso Garda preventivo–verifica–fattura esaminato. |
| R18 | Prima di registrare ogni elemento concordato, verificare se ingecert o gli altri gestionali Garda lo implementano già. Conservare le funzioni utili e migliorare le carenze, senza reinventare la logica. Chiedere chiarimenti sulla prassi non desumibile, sulle ambiguità e sulle modifiche desiderate. | Metodo esplicito ribadito dall’utente: ogni requisito deve riportare il riscontro nel sorgente, il comportamento da conservare e il miglioramento richiesto, oppure dichiarare che il riscontro non è ancora concluso. Presenza nel codice e funzionamento collaudato restano distinti. |
| R19 | Per i preventivi DPR adottare il flusso documentale apprezzato in VerbalizzAI: anteprima PDF via LibreOffice, eventuale correzione del Word, ricaricamento, nuova anteprima e iterazione fino alla versione corretta. | Richiesta esplicita; buona parte del ciclo è già presente nel prototipo 0.7.1. |
| R20 | Definire il nome automatico del file finalizzato e il download automatico, con destinazioni da stabilire. | Richiesta esplicita; nome già generato nella 0.7.1, convenzione finale e automatismo di download da progettare. |
| R21 | Prevedere firma e finalizzazione del documento prima dell’invio, secondo il flusso richiesto dall’utente. | Richiesta recepita; nel percorso preventivi della 0.7.1 è verificata l’approvazione, non una funzione equivalente di firma del mittente. Modalità da definire. |
| R22 | Usare “preventivo” come termine nell’interfaccia e raccogliere separatamente i dettagli che non incidono sull’architettura, decidendoli alla fine. | Richiesta esplicita. Resta corretto parlare di riesame del contratto e di accordi commerciali quando ci si riferisce a quei concetti. |
| R23 | Arrivare rapidamente a una struttura minima praticabile mediante domande mirate sulle decisioni strutturali. | Richiesta esplicita; proposta di architettura e cinque domande nella sezione 20. |
| R24 | Il primo AD_dpr deve includere il modulo completo di fatturazione e incassi. | Decisione esplicita dell’utente. Il perimetro non viene ridotto a sola esportazione XML o incassi essenziali. |
| R25 | L’intestatario fattura può differire dall’intestatario del preventivo, che costituisce la proposta normale. | Prassi e requisito espliciti; verificata la sezione Garda con dati fiscali di intestazione distinti. |
| R26 | Mantenere per ora distinta la programmazione delle attività. | Decisione dell’utente: nessuna agenda operativa unificata DPR/DM/I&C nel primo rilascio. |
| R27 | Preventivo creato → inviato → accettato, salvo rifiuto/annullamento; dopo l’accettazione riesame obbligatorio e solo successivamente affidamento al tecnico. | Flusso esplicito dell’utente, che richiama ISO 17020:2026. Riscontrato il vincolo di accettazione e riesame conforme nelle condizioni Garda per generare verifiche. |
| R28 | Il primo rilascio funziona online; non sono previste bozze offline. | Decisione esplicita dell’utente. Nessuna copia operativa locale, coda offline o sincronizzazione dei dispositivi nel perimetro iniziale. |
| R29 | Prassi attuale dichiarata: verbalizzazione, riesame del verbale, invio e poi fatturazione. Valutare rilascio immediato soprattutto DPR, raro DM e praticamente assente per I&C S.r.l. | Chiarimento dell’utente. Proposta di due percorsi nella sezione 24; attivazione dell’eccezione ancora da decidere. |
| R30 | Mantenere semplici il flusso e la logica del gestionale; evitare che la distinzione dei controlli aumenti il lavoro operativo. | Richiesta esplicita. Percorso ordinario unico, eccezione DPR circoscritta e stati derivati; criterio di progetto nella sezione 24.6. |
| R31 | Nel DPR datore di lavoro, committente, intestatario del preventivo e del verbale coincidono nel processo indicato. L’eventuale intestatario terzo si sceglie soltanto alla generazione della fattura, con default dal cliente. | Chiarimento esplicito: mantenere il funzionamento Garda, senza introdurre prima un committente distinto. |
| R32 | Discutere prima ogni cambiamento alle logiche, entità o relazioni Garda, partendo dal comportamento attuale e da un motivo concreto. | Vincolo esplicito. Le proposte del documento non autorizzano da sole una modifica del modello o dell’applicazione. |
| R33 | L’aggiornamento del cliente non deve modificare l’intestazione o i dati nei verbali e preventivi già emessi. | Requisito esplicito; conservarne file e dati validi all’emissione, anche per consultazione e ristampa. Il comportamento del subentro resta da decidere. |
| R34 | Nel subentro DPR di un’altra azienda mantenere lo stesso impianto fisico, con nuovo cliente e passaggio tracciato; emessi precedenti riferiti al vecchio soggetto e ai dati originali. | Proposta approvata dall’utente con “ok”; comportamento da specificare e implementare, non modifica già eseguita. |
| R35 | Valvola–attrezzatura: mantenere l’abbinamento corrente e modificarlo manualmente quando necessario, conservando tarature e documenti; non introdurre nel primo perimetro uno storico strutturato dei montaggi. | Scelta esplicita di semplicità, coerente con la prassi dichiarata. Non elimina le evidenze già conservate nei documenti. |
| R36 | Chi può modificare le anagrafiche si gestisce con la configurazione dei ruoli e permessi; non è una decisione architetturale da chiudere con una domanda separata. | Chiarimento esplicito dell’utente. Le regole di integrità e conservazione degli emessi valgono per ogni operatore autorizzato. |
| R37 | DPR: aggiornare la prossima scadenza alla verifica effettuata/emissione, senza attendere il RV conforme; tenerla coerente con eventuali modifiche del verbale in revisione. | Regola approvata dall’utente. La nuova revisione emessa aggiorna i dati pertinenti; un ritocco solo grafico non modifica la scadenza. |
| R38 | Accettazione DPR con preventivo controfirmato oppure almeno email di conferma; le conferme telefoniche non fanno parte della prassi ammessa descritta. | Requisito esplicito. Collegare la risposta scritta alla versione/prestazioni pertinenti; il modo pratico di conservarla non è ancora definito. |
| R39 | Il contenuto commerciale del preventivo accettato non si modifica. Le prestazioni aggiuntive richiedono un nuovo preventivo integrativo; prestazioni di preventivi diversi possono essere riunite in un’unica fattura nel flusso compatibile discusso. Le prestazioni DM ed EX restano su fatture separate (R49). | Requisito esplicito. L’aggregazione in fattura conserva una funzione già presente in Garda (generazione dalla riga preventivo con scelta della fattura da integrare), non introduce una nuova logica. Conservare offerta ed evidenza originarie e la provenienza delle prestazioni fatturate. |
| R40 | Garda permette di preventivare la prossima scadenza, non anche quelle successive di un affidamento pluriennale. Questi affidamenti sono rari: la loro gestione deve evitare di complicare o alterare la logica ordinaria. | Limite e priorità dichiarati dall’utente. Raccomandazione: rinviare una gestione dedicata e trattare manualmente i casi rari nel primo DPR, senza automatismi di copertura. Modalità concreta da verificare sul caso effettivo. |
| R41 | DPR: verifica assegnata, eventuale programmazione, registrazione in occasione dell’esecuzione; stato eseguita soltanto dopo finalizzazione e caricamento del verbale nel gestionale. Per una verifica che non può essere eseguita, introdurre lo stato sospesa. | Flusso e aggiunta richiesti dall’utente. Programmazione facoltativa. Confermata la ripresa sullo stesso incarico, mantenendo l’eventuale numero di verbale già assegnato. Transizioni puntuali e trattamento economico da consolidare; nessuna implementazione eseguita. |
| R42 | Prevedere la possibilità di addebitare un sopralluogo a vuoto quando, dopo l’uscita, la verifica non viene conclusa e viene definitivamente annullata. | Esigenza nuova: l’utente dichiara che oggi non è gestita e ritiene corretto l’addebito. Nessun importo, criterio di applicazione o automatismo approvato. Proposta minima: voce economica manuale distinta dalla verifica non eseguita. |
| R43 | Nel DPR la fattura di acconto prima dell’esecuzione non è la prassi ordinaria, ma può capitare e deve essere supportata. | Prassi esplicita dell’utente. Distinguere acconto fatturato e relativo incasso, collegare il documento alle prestazioni pertinenti e tenerne conto nel saldo. Non trasformare l’acconto in un passaggio obbligatorio delle verifiche. |
| R44 | Trasmissione elettronica DPR attuale: download dell’XML dal gestionale e caricamento manuale nel servizio Fatturazione Elettronica Aruba. | Prassi esplicita dell’utente. Conservare questo canale nel primo DPR, rinviando l’invio automatico. Generazione/download non equivalgono a trasmissione riuscita; esiti oggi consultati su Aruba, importazione nel nuovo gestionale richiesta (R47), modalità tecnica da definire. |
| R45 | Gli incassi e le fatture ancora da pagare vengono oggi registrati e controllati in Garda. | Prassi esplicita dell’utente. Conservare queste funzioni nel primo AD_dpr; il caricamento degli XML su Aruba non trasferisce al servizio esterno la gestione operativa dei crediti. Non equivale ad approvare nuove relazioni dei movimenti o una riconciliazione bancaria automatica. |
| R46 | Normalmente un pagamento viene associato a una fattura; nei rari casi deve essere possibile associare lo stesso pagamento a due o più fatture. | Comportamento chiarito dall’utente. Pagamento unico, con importo attribuito a ciascuna fattura e totale non duplicato. Estensione della normale associazione, senza flusso dedicato. Rappresentazione tecnica ancora da definire; nessuna implementazione eseguita. |
| R47 | Gli esiti delle fatture elettroniche vengono oggi consultati su Aruba e non lasciano traccia in Garda. Importarli nel nuovo AD_dpr, rendendo visibile una fattura scartata e la necessità di correggerla/ripresentarla. | Mancanza segnalata e requisito esplicito dell’utente. Collegare gli esiti alla fattura e conservare tentativi ed evidenze precedenti; modalità di recupero/importazione da definire. Approvato dall’utente il criterio futuro: correggere nel nuovo gestionale e rigenerare l’XML, conservando versioni ed esiti dei tentativi; nuovo caricamento su Aruba. Nessuna implementazione eseguita. |
| R48 | La serie EX di adsrl / AD comprende CND delle attrezzature GVR, verifiche di efficienza delle valvole di sicurezza (accessori GVR) e verifiche ispettive volontarie SC, SP e GVR. | Significato operativo esplicito dell’utente. Conservare le denominazioni delle prestazioni e la società emittente oltre alla serie; “efficienza delle valvole” non viene trasformata in “taratura”. Prestazioni DM ed EX fatturate separatamente, con serie distinte anche per i preventivi (R49). |
| R49 | Per uno stesso cliente le prestazioni DM ed EX generano due fatture separate, perché anche le serie dei relativi preventivi sono separate. | Regola e prassi esplicite dell’utente. Conservare la separazione commerciale e fiscale DM/EX. Non estendere automaticamente la fattura unica acquisita per più preventivi a questo abbinamento; gli altri eventuali abbinamenti non sono decisi da questa risposta. |
| R50 | Per ora il primo AD_dpr mantiene l’invio del verbale dopo riesame; il rilascio immediato resta una possibilità futura da attivare con una scelta successiva. | Risposta dell’utente al perimetro del primo DPR; precisato “invio” dopo riesame. Non introdurre l’opzione immediata nel primo esercizio previsto. La compatibilità futura non richiede un secondo flusso applicativo adesso. |
| R51 | Un RV negativo riporta la verifica a registrata. Il verificatore ripete l’attività e/o modifica il verbale, lo ricarica e riporta la verifica a eseguita per un nuovo RV. | Flusso esplicito dell’utente, conservando il comportamento Garda. Invio e fatturazione ordinaria restano subordinati al nuovo RV conforme. Ricaricare il documento non rende automaticamente conforme il riesame. |
| R52 | Il verificatore deve vedere la nota del RT in caso di RV negativo; ogni verbale deve avere lo storico dei riesami. | Requisito esplicito. Conservare esito, nota, autore, data/ora e versione esaminata per ogni RV, anche dopo ricaricamento e nuovo controllo. Nota negativa obbligatoria come già previsto in Garda; nessuna sovrascrittura dello storico con il solo esito corrente. |
| R53 | Al passaggio al nuovo AD_dpr l’utente preferisce importare anche gli incarichi già aperti, ma considera la scelta ancora da valutare. | Preferenza acquisita, non cutover definitivo approvato. Predisporre l’importazione delle pratiche attive e verificarla con una prova sugli stati, collegamenti e documenti; decidere il perimetro effettivo in base al risultato. |
| R54 | La verifica straordinaria DPR è preventivata a parte, con un proprio incarico e verbale VS anziché VP. Il ricontrollo dopo sistemazione dell’impianto è distinto dalla correzione del verbale conseguente a RV negativo sullo stesso incarico. | Prassi confermata dall’utente. Garda già distingue VP/VS nelle righe preventivo e nel codice verbale. Numerazione confermata dall’utente: un solo progressivo annuale per tutte le verifiche DPR 462, con prefisso VP per le periodiche e VS per le straordinarie. Si conserva il criterio già implementato da ingecert; nessun contatore separato. |
| R55 | La verifica straordinaria DPR non determina automaticamente la periodicità né ricalcola la scadenza della verifica periodica. | Regola confermata dall’utente: mantenere il comportamento ingecert, nel quale il ricalcolo usa l’ultima VP effettuata. Nessun nuovo ciclo periodico automatico alla finalizzazione di una VS. |
| R56 | Segnare un impianto dismesso non annulla automaticamente gli incarichi già aperti: la loro chiusura resta manuale. | Conferma esplicita dell’utente. Conservare il flag dismessa e i vincoli Garda sulle nuove generazioni; stato dell’impianto e stato dell’incarico restano distinti. La chiusura manuale consente di valutare un eventuale sopralluogo a vuoto già svolto, senza addebiti automatici. |
| R57 | Conservare l’accettazione parziale del preventivo DPR: con più impianti/prestazioni si può procedere soltanto sulle righe accettate, mantenendo lo stesso preventivo e dopo il riesame. | Conferma esplicita dell’utente. Funzione già presente in ingecert: stato per riga, riepilogo accettato_parzialmente e controllo della riga accettata per generare la verifica. Nessun nuovo preventivo obbligatorio per accettare una parte dell’offerta esistente. |
| R58 | Per semplicità, il riesame del preventivo DPR copre tutta l’offerta invariata, comprese le prestazioni già incluse che il cliente accetti successivamente. | Scelta esplicita dell’utente su un caso mai capitato. Coerente con RC sulla testata Garda: nessun nuovo riesame per la sola accettazione successiva di una riga già offerta. Restano necessarie accettazione scritta della prestazione e RC conforme valido prima dell’affidamento; le prestazioni nuove richiedono preventivo integrativo e relativo RC. |
| R59 | Nel primo AD_dpr gli incassi vengono registrati manualmente e associati alle fatture, con controllo dei residui. L’import degli estratti conto è un modulo necessario, da realizzare successivamente. | Decisione esplicita dell’utente: rinvio temporale, non esclusione definitiva né funzione facoltativa. Resta il requisito di fatturazione e incassi completi nel primo AD_dpr; restano già acquisiti uno stesso pagamento su più fatture e il recupero degli esiti SdI come questione distinta dall’import bancario. |
| R60 | Chiudere ora il DPR operativo, verificando la compatibilità strutturale del nucleo con DM e I&C. I flussi applicativi dettagliati DM/I&C saranno approfonditi prima dei rispettivi moduli, dopo la validazione del DPR nell’uso. | Perimetro confermato dall’utente. Nucleo integrato fin dall’inizio, primo AD_dpr completo di VerbalizzAI, fatturazione e incassi. Non si richiede un questionario completo su DM/I&C prima dell’ossatura DPR; restano da verificare le strutture comuni che sarebbe costoso modificare dopo. |
| R61 | Ogni verbale emesso conserva lo stato storico dell’impianto. La scheda corrente segue le modifiche rilevate e il nuovo verbale ripropone la situazione fotografata nell’ultimo, inclusi potenza, alimentazione ed elementi censiti. | Regola confermata dall’utente. La nuova bozza riparte dalle caratteristiche riutilizzabili dell’ultima situazione pertinente; misure ed esiti sono propri della nuova verifica. Revisioni/import di informazioni più vecchie non devono sovrascrivere uno stato più recente. Mapping e protezione dalla concorrenza sono lavoro tecnico, senza nuovo flusso di approvazione della scheda. |
| R62 | Nessuna matrice delle abilitazioni o filtro dedicato delle qualifiche nell’assegnazione del primo AD_dpr. | L’utente considera il controllo superfluo perché i tecnici abilitati sono soltanto quattro. L’assegnazione rimane una scelta dell’operatore autorizzato; non si aggiungono registri, scadenze o un workflow di qualificazione. Ruoli, permessi e dichiarazione personale d’indipendenza restano questioni distinte. |
| R63 | Dichiarazione d’indipendenza preselezionata come in Garda, escludibile dal tecnico; se esclusa, quel tecnico non può svolgere la verifica. | Scelta esplicita dell’utente, che conserva il default T già presente in ingecert e il blocco operativo quando il campo è F. Superata la proposta di spunta inizialmente vuota. Nessuna nuova approvazione; registrare le modifiche e il tecnico pertinente senza inventare una conferma personale distinta per il solo default. |
| R64 | Il primo AD_dpr deve supportare note di credito sia totali sia parziali. | L’utente conferma che emette anche note di credito parziali. Conservare i percorsi TD04 e il collegamento alla fattura originaria già presenti in Garda; trattamento dei residui, delle somme già incassate e delle eventuali compensazioni da consolidare e collaudare. |
| R65 | Fattura e nota di credito possono essere create anche «in bianco», con righe personalizzate, senza associazione obbligatoria a verbali o verifiche esistenti. | Funzione richiesta anche se rara, da includere nel primo AD_dpr. Già riscontrata nei metadati Garda la creazione diretta del documento e delle righe, con riferimenti operativi non obbligatori. Mantenere il normale ciclo fiscale, documentale ed economico, senza inventare un incarico per consentire l’emissione. |
| R66 | Nella prassi descritta la nota di credito riguarda una fattura non ancora pagata. | Chiarimento dell’utente: normalmente non si pone il rimborso/compensazione di somme già incassate. Caso ordinario: rettifica del credito ancora da riscuotere. Non è un divieto assoluto di emettere una nota su fattura pagata né l’approvazione di una procedura dedicata di rimborso. |
| R67 | Importare nel gestionale gli esiti della fatturazione elettronica da Aruba è una funzione da realizzare; la modalità non viene approfondita ora. | L’utente rinvia la scelta del meccanismo, mantenendo il requisito. Non è approvata l’importazione manuale proposta, né un collegamento automatico. Resta R47: esiti e scarti visibili, tentativi e correzioni conservati. Il rinvio dell’analisi non elimina la funzione dal progetto o la rende facoltativa. |
| R68 | Implementare il nuovo AD_dpr a partire da VerbalizzAI e dal prototipo Python, coerente con il futuro nucleo comune per DM e I&C. Il PHP Garda è riferimento logico e fonte dei dati, non codice da modificare/adattare. | Richiesta esplicita di procedere al codice. Candidatura 0.8.0 realizzata per collaudo; nessun sorgente PHP Garda modificato. Non implica che l’intero gestionale integrato sia già concluso. |
| R69 | I primi test e lo sviluppo si svolgono in locale su Windows. | Vincolo esplicito acquisito. Avvio dedicato con archivio separato, Python 3.12, SQLite e LibreOffice. Hosting rinviato; nessuna bozza offline introdotta. |

| R70 | Il passaggio al modulo VerbalizzAI distinto, con “Torna al gestionale” in basso, non convince l’utente. Registrare il tema per una valutazione successiva senza modificare ora l’interfaccia. | Prima osservazione durante il collaudo Windows. Nessuna soluzione alternativa, unificazione fisica o riscrittura autorizzata da questa osservazione. |
| R71 | Passare all’analisi AD_DM, leggendo codice e database Garda: categorizzazione SC/SP/GVR e rendicontazione INAIL essenziale. | Richiesta esplicita; riscontro in sola lettura documentato nella sezione 32. Nessuna implementazione DM o modifica di relazioni approvata con questa richiesta. |
| R72 | Preservare le regole di codifica dei nomi degli allegati fattura, scheda tecnica e verbale, senza perdere regole nel nuovo software. | Richiesta esplicita durante l’analisi. Catalogo iniziale N01–N14 nel rapporto AD_DM, con fonti ed eccezioni; distinzione stampa, archiviazione ed export INAIL. Copertura dell’intero software ancora da completare, nessuna modifica dei nomi introdotta. |
| R73 | Ogni regola presente nei gestionali Garda che non venga riproposta, venga disattesa o derogata richiede valutazione espressa e consenso esplicito dell’utente. Le deroghe necessarie a integrare i tre gestionali sono ammesse e fisiologiche. | Regola generale per DPR, DM, EX e I&C. Struttura DB e interazioni saranno riprogettate; gli scostamenti funzionali vanno esplicitati e approvati, senza chiedere conferma per ogni dettaglio tecnico interno. Non implica riuso del PHP o copia delle tabelle Garda. |
| R74 | Classificazione AD_DM: per le attrezzature importate acquisire quella presente in Garda; per le nuove compilazione manuale tramite maschere. Alcune classificazioni cambiano nel tempo, ad esempio la voce “Apparecchi all. 7” per SC oltre dieci anni. | Chiarimento esplicito: nessun problema operativo di classificazione da risolvere con automatismi. L’utente precisa di riferirsi ad “Apparecchi all. 7”, cioè tipo/categoria, non all’ID Specifica. Preservare scelta manuale e segnalazione Garda; distinguere i campi in base al riscontro del codice. La storia degli emessi resta tutelata dai requisiti già acquisiti. |
| R75 | Rendicontazione/esportazione INAIL AD_DM su base trimestrale. | Cadenza operativa confermata dall’utente, che richiama il D.M. 11.04.2011. La funzione Garda letta opera sulla selezione della griglia: calendario operativo e selezione tecnica vanno distinti. Prassi per le verifiche non ancora fatturate chiarita in R76; altre condizioni di esclusione/rettifica non ancora definite. |
| R76 | INAIL: le verifiche non ancora fatturate al momento della rendicontazione trimestrale vengono incluse nel trimestre successivo. | Prassi operativa esplicitamente confermata dall’utente, che chiede di mantenerla semplice. Restano da rendicontare fino all’esportazione; non si cambia la data reale della verifica. Nessun nuovo flusso di eccezione introdotto. |
| R77 | INAIL: Excel e ZIP prodotti dal gestionale vengono caricati manualmente sul portale denominato dall’utente “A.S.A.”. | Prassi confermata. Preservare produzione dei pacchetti e caricamento manuale; nessuna integrazione automatica con il portale richiesta. Il flag Garda di esportazione indica la generazione, non certifica l’acquisizione sul portale. |
| R78 | AD_DM usa il generatore Garda, fonte d’ispirazione di VerbalizzAI: legge dati dell’attrezzatura e propone alcuni dati dai precedenti. Analizzare attentamente il codice prima della spiegazione operativa GVR e dell’esempio che l’utente fornirà. | Conferma dell’uso attuale e indirizzo di analisi; non richiesta di adattare il PHP o cambiare ora il software. Riscontri nel rapporto 07: dati correnti, precedenti specifici F/I/N, aggiornamenti reciproci, stampa e limiti del materiale disponibile. |
| R79 | Approfondire il generatore DM a partire dagli attributi delle attrezzature GVR, SC e SP; ricevuti i due modelli Word del verbale. | Indicazione esplicita di metodo dell’utente. Distinguere scheda generale, classificazione, configurazione per camere/componenti, dati della verifica e dati da precedenti. Non autorizza modifiche automatiche degli attributi o del loro significato. |
| R80 | GVR: il volume generale è la somma dei volumi delle camere. Le tubazioni hanno DN (mm), non V (litri), e non contribuiscono al totale dei volumi. | Chiarimento esplicito dell’utente. Riletti i calcoli Garda: la capacità somma soltanto `gvr_vol`, mai `gvr_dn`. Nessuna nuova regola di conversione del DN, sincronizzazione automatica del campo generale o correzione dei dati storici introdotta. |
| R81 | GVR: verbali separati se le prestazioni sono preventivate separatamente; un verbale unico se è preventivata una verifica multipla. Tariffazione prime periodiche art.4/art.5 secondo soggezione a messa in servizio; successive funzionamento/interna rispetto a integrità/multipla. | Prassi e regola esplicitamente confermate dall’utente, già riscontrate nel codice Garda. Il tipo della riga è copiato alla verifica; preservare colonne tariffarie e agganci. Nessun accorpamento automatico dei verbali o somma dei prezzi dei singoli introdotto. |
| R82 | Per AD_DM e I&C il codice Garda è la fonte delle logiche fondamentali. La ristrutturazione di entità e relazioni per un database unico è prevista; devono essere spiegate le conseguenze concrete su dati, migrazione, interazioni e comportamento. | Criterio ribadito dall’utente. Accorpamenti tecnici nel perimetro autorizzato; cambiamenti funzionali soggetti alla valutazione e al consenso previsti da R73. Il criterio non attesta un audit già completo di tutti i moduli. |
| R83 | Procedere descrivendo ciascun passaggio, senza attendere conferma fra i passaggi; fermarsi per chiedere quando emergono dubbi. | Istruzione esplicita del 9 ottobre 2026. Prosegue il riscontro Garda; resta valido R73 per gli scostamenti funzionali. Non costituisce approvazione indistinta di cambiamenti alle regole. |
| R84 | INAIL: All. 7, ID Specifica e gli altri attributi di classificazione sono propri dell’attrezzatura e vengono letti dalla scheda, secondo Garda. Il cambio di categoria oltre dieci anni modifica gli attributi dell’attrezzatura; non si congela questa classificazione nel verbale per alimentare la rendicontazione. | Chiarimento esplicito dell’utente: quei codici non sono riportati nel verbale come ipotizzato nella proposta INAIL-01. Proposta ritirata e dubbio chiuso; date, prestazione ed esito rimangono propri della verifica. Nessun automatismo di riclassificazione introdotto. |
| R85 | I rapporti tecnici I&C sono oggi preparati fuori da Garda. Un ingegnere sta sviluppando un software autonomo da integrare nel gestionale completo. Per i CND registrare, oltre a data e prossimi CND, il riferimento al numero del report. | Chiarimento esplicito dell’utente; IEC-01 chiusa. Nuovo requisito rispetto ai campi data del percorso Garda letto. Non definisce ancora cardinalità dei rapporti, obbligatorietà del numero, formato, revisioni o interfaccia del software esterno. |
| R86 | Normalmente un report CND riguarda una singola attrezzatura. Collegare il riferimento al rapporto/attività e renderlo consultabile nello storico del bene. | Prassi confermata dall’utente; IEC-02 chiusa per il caso ordinario. “Normalmente” non stabilisce un vincolo assoluto né definisce la gestione di eventuali eccezioni. |
| R87 | Mantenere operativa nel nuovo I&C la gestione dei compensi percentuali dei collaboratori e delle loro fatture, con riferimento alle regole Garda ricostruite. | Conferma esplicita dell’utente: “sì assolutamente”; IEC-03 chiusa. Nessuna esclusione o rinvio della funzione. Non estende automaticamente il modulo ad AD_DPR e non approva implicitamente future variazioni alle singole regole. |
| R88 | In DM e DPR il tecnico è fondamentale per il flusso di lavoro e la rendicontazione; in I&C il collaboratore è una relazione di provvigioni commerciali. | Chiarimento esplicito dell’utente; IEC-04 chiusa sul significato del ruolo. Preservare relazioni distinte nel nucleo comune; non dedurre il tecnico dal beneficiario delle provvigioni. Non stabilisce un nuovo obbligo di assegnazione tecnica I&C. |
| R89 | Per le prestazioni I&C che producono report, normalmente si attende che il report sia pronto prima di procedere alla fatturazione. | Prassi esplicita dell’utente; IEC-05 chiusa per il caso ordinario. Non stabilisce un blocco assoluto, un nuovo stato o un obbligo di caricamento nel gestionale. Disponibilità del report, invio e incasso sono fatti distinti. |
| R90 | Flusso commerciale ordinario I&C: lavoro concluso/report pronto → trasmissione al cliente via email → fatturazione → incasso successivo. L’incasso non è una condizione per l’invio del report. | Chiarimento esplicito dell’utente; IEC-06 chiusa. L’incasso è mai o quasi mai contestuale secondo la prassi dichiarata. Non introduce invio automatico, nuove scadenze di pagamento o blocchi generali per eccezioni. |
| R91 | DM e DPR mantengono preventivi separati e fatture separate, con i rispettivi sezionali. Non consentire una fattura mista DM/DPR come effetto dell’integrazione. | Decisione esplicita dell’utente; UNIF-01 chiusa. Confermata anche R49 sulla separazione DM/EX. Il nucleo amministrativo comune non comporta fusione dei documenti o delle numerazioni. |
| R92 | Nei nuovi preventivi DM applicare esattamente la percentuale di sconto indicata e arrotondare soltanto l’importo monetario finale; mantenere integralmente gli importi storici. | Conferma esplicita dell’utente: “sì ok”; PREV-01 chiusa. Deroga approvata al rapporto anticipatamente arrotondato Garda, riscontrato su 14 righe DM. Nessun ricalcolo di preventivi importati, accettati o emessi; nessuna estensione automatica del consenso ad altri calcoli DPR/I&C. Decisione acquisita, implementazione ancora da eseguire. |
| R93 | Proseguire con lo schema operativo e mostrare uno schema grafico E-R di tutto il database integrato. | Richiesta esplicita dell’utente. Consegnato schema progettuale v0.3, E-R completo e viste per area con dizionario; non implica applicazione del DDL al prototipo o approvazione di nuove deroghe funzionali. |
| R94 | Le tubazioni non hanno visita interna; applicare le componenti GVR secondo la famiglia/classificazione del bene. | Chiarimento esplicito dell’utente, confermato dal catalogo Garda (visita interna N.A. per le quattro classificazioni tubazioni) e da zero verifiche contenenti interna sulle attrezzature attualmente classificate come tubazioni. Conservazione della logica esistente; nessuna deroga introdotta. |
| R95 | Con il database unico eliminare la sincronizzazione comandata manualmente fra I&C e AD_DM. | Chiarimento esplicito dell’utente. Attività e schede tecniche richiamano gli stessi beni/scadenze: aggiornamento condiviso, senza replica o secondo comando. Flag legacy F/T/S conservati come provenienza; non autorizza replay di attività storiche o sovrascrittura dei dati nativi dai dump. |
| R96 | Importazione massiva XLS/XLSX dell’intero parco SC/SP/GVR e accessori PSV, con classificazioni, dati tecnici, associazioni e date ultime/prossime verifiche, CND e tarature; senza ricostruzione dai verbali o inserimento uno per uno. | Richiesta esplicita dell’utente, riscontrata nelle procedure Excel Garda. Funzione operativa AD_DM anche per nuovi clienti/aggiornamenti; distinta dalla migrazione dei dump. Prassi precisata: l’utente popolava il modello XLS, il caricamento era gestito dalla software house; non conosce la semantica tecnica degli aggiornamenti. Questa risposta non approva una nuova policy. Importer non implementato. |
| R97 | Dare priorità a una versione integrata DPR/DM/I&C eseguibile in locale con le funzioni attuali; preparare il modello di importazione Excel alla fine. | Indirizzo esplicito dell’utente. R96 resta necessario prima dell’uso operativo DM; sviluppo/test iniziali sui dump disponibili. Matrice di completamento nel rapporto 16 (1.2); primo incremento B1a implementato nella candidatura 0.9.0 e rapporto 17. Sequenza di produzione DPR poi DM/I&C conservata; il gestionale completo resta da terminare. |
| R98 | Impedire un secondo preventivo sulla stessa prestazione periodica già preventivata, fino all’annullamento della prestazione/offerta precedente; il completamento della verifica consente il ciclo successivo. | Segnalazione esplicita dell’utente sulla 0.8.0; difetto riprodotto e corretto in 0.8.1/0.9.1 senza nuove migrazioni. Controllo anticipato anche alle bozze rispetto alla query Garda sulle righe accettate. Revisioni sostitutive, VS distinte e prestazioni integrative preservate. Rifiuto distinto dall’annullamento; nessuna bonifica automatica dei duplicati già presenti. Rapporto 18 e sezione 70. |
| R99 | Il prossimo rilascio funzionale deve essere già un gestionale integrato DPR e DM, non un nuovo incremento generico di soli beni. | Richiesta esplicita dell’utente, successiva alla preparazione della correzione duplicati. Schede/controlli e flussi DM da implementare secondo adsrl Garda, INAIL nel perimetro essenziale; I&C resta nell’architettura e nel seguito R97. 0.8.1/0.9.1 sono manutenzione/base, non il rilascio funzionale richiesto. Sezione 73 e rapporto 21; nessuna dichiarazione che quel codice sia già completo. |
| R100 | Un backend comune e ambienti pertinenti AD_DPR, AD_DM e I&C; selettore utile allo sviluppo/collaudo. Nel definitivo indirizzi distinti, almeno accesso AD_DPR/AD_DM e accesso I&C. | Richiesta e chiarimento espliciti dell’utente. Implementati selettore e ingressi locali, senza cambiare permessi o contabilità. Domini/proxy/autorizzazioni per ambito di produzione ancora da realizzare; numero finale due/tre ingressi non vincolato. Sezione 76. |

| R101 | Garda funziona bene: logiche e flussi da conservare, salvo modifiche decise assieme o necessarie all’unificazione. | Indicazione esplicita del 10 ottobre; rafforza R73/R82 e prevale sulle precedenti proposte di riprogettazione operativa non approvate. |
| R102 | Nessuna semplificazione o omissione delle regole/funzioni Garda. | Indicazione esplicita. Inventario e prove devono includere anche azioni, griglie, batch, import, stampe, modelli e permessi; cataloghi non esaustivi. |
| R103 | La motivazione principale è indipendenza dal fornitore esterno costoso per implementazioni e modifiche. | Indicazione esplicita: mantenibilità e possibilità di estensione del prodotto comune; nessun nuovo requisito contrattuale/licenza dedotto. |
| R104 | Ridurre click e portare offerte/verbali DM al percorso di ritocco ammesso, controllo, archiviazione definitiva e invio diretto del PDF, come VerbalizzAI aggiornato. | Miglioramento esplicitamente richiesto. Il tipo di firma/riesame resta pertinente al documento; applicazione DM da completare e verificare. |
| R105 | Rifare le dashboard AD_dm. | Autorizzazione esplicita al ridisegno; nessuna nuova dashboard realizzata o grafica già approvata in questo passaggio. |
| R106 | In tempi brevi arrivare a un unico prodotto con tre frontend, backend comune, VerbalizzAI e TUTTE le funzionalità Garda compatibili. Guidare l’utente come ingegnere gestionale. | Indicazione esplicita: scelte tecniche all’assistente, decisioni operative su casi concreti all’utente. Il primo traguardo di collaudo è la candidata completa; gli incrementi sono checkpoint interni e non soddisfano da soli il requisito. |

Non sono ancora specificati compiutamente: carichi di lavoro, utenti contemporanei, disponibilità richiesta, tempi di recupero, regole di conservazione, collegamenti esterni e tutti i casi economici. Vanno raccolti quando incidono sulle scelte, senza introdurre ora requisiti presunti.

## 3. Materiali disponibili

| Materiale | Contenuto e uso |
|---|---|
| `backup_gestionale.7z` | Sorgenti PHP/JS, dump dei tre database del 7 ottobre 2026 e allegati locali disponibili. Base delle verifiche Garda. |
| `gestionale_poc.zip` e schema/mapping/quadratura v0.1 | Prima prova di migrazione e modello unificato; analizzati come progetto sperimentale. |
| `gestionale_poc_v0.2.zip` e recepimento v0.2 | Migrazione rivista, rieseguita e controllata; presenta ancora punti aperti. |
| `verbale-gvr (1).docx`, `verbale-sc-sp (2).docx` | Modelli Word con segnaposto forniti il 9 ottobre. M14/M11-PO01_dm rev.02 del 16.07.2025; identici byte per byte ai modelli inclusi nel backup; non verbali compilati. |
| `VerbalizzAI_AD_v0.3.32.3.zip` | Sorgente autonomo verificato; nessun archivio operativo completo di produzione ricevuto per la migrazione. |
| `Gestionale_AD_v0.7.1.zip` | Prototipo DPR con anagrafiche, preventivi, verifiche, ponte VerbalizzAI e importatore ingecert. |
| Valutazione e sequenza di sviluppo riportate dall’utente | Proposte esaminate criticamente; non costituiscono di per sé una conferma dello stack o del collaudo. |

Gli originali documentali S3 sono temporaneamente esclusi dalla fornitura, su indicazione dell’utente per motivi di spazio. Non bloccano l’attività corrente. La loro accessibilità e integrità dovranno essere trattate prima di chiudere la migrazione documentale, valutando allora anche un recupero diretto nell’ambiente di destinazione. Non viene richiesta una copia massiva nella conversazione. Restano da acquisire per le rispettive fasi: backup operativo completo di VerbalizzAI, procedure e casi d’uso non ricostruibili dal codice. I documenti 01–15 e il registro delle decisioni citati dalla 0.7.1 non sono nello ZIP.

## 4. Esiti delle analisi già svolte

### 4.1 Gestionali Garda e documenti

I tre sistemi condividono framework PHP `gi`, metadati JavaScript e MariaDB. DPR/DM gestiscono preventivi, verifiche, scadenze e fatturazione; I&C registra attività nei sottopunti dei preventivi, con collaboratori e ripartizioni.

I dump contengono complessivamente 3.500 record cliente. Le fatture elettroniche censite sono 473 DPR, 728 DM e 231 I&C: sono conteggi di fatture, non altrettanti XML originali già verificati.

Il PoC censisce 15.338 riferimenti documentali. **12.398 riferimenti classificati S3 non hanno l’originale locale nel backup fornito**, per circa 3,60 GB secondo le dimensioni registrate. Non è una prova di perdita: serve recuperare lo storage documentale. Per 1.398 riferimenti XML, i nomi sono stati trovati negli ZIP; restano da verificare contenuti e associazioni. Inoltre 34 fatture I&C non hanno il nome file valorizzato.

AD_dm e I&C condividono già dati mediante sincronizzazione. È stata verificata nel PHP la necessità di riportare manualmente alcune rettifiche successive alla sincronizzazione. I dati tecnici e commerciali non sono quindi soltanto duplicati: hanno anche relazioni operative da conservare.

### 4.2 VerbalizzAI e ponte minimo

È confermato il vantaggio di rinviare la sostituzione del backend durante il rilascio. `Archive` non contiene soltanto query: gestisce anche emissioni, revisioni, stato tecnico, utenti e importazioni. Cambiarlo richiede una regressione ampia.

Le verifiche e gli stati tecnici sono JSON strutturati; i documenti hanno hash SHA-256 e i backup verificano contenuti e riferimenti. Queste proprietà aiutano la migrazione, ma non la rendono automaticamente una sequenza di semplici inserimenti.

- **Da aggiungere:** riferimento facoltativo `ext_ingecert_impianto_id`, con controllo dei riferimenti compilati e gestione esplicita delle duplicazioni.
- **Già presente:** codice verbale completo in `header.number`; non serve un secondo campo equivalente.
- **Già presente:** nome e hash del Word importato in `source_meta`; un’ulteriore provenienza logica è facoltativa.
- **Da preservare nella migrazione:** nove tipi di oggetto, versioni, legami fra verifiche, profili tecnici, esportazioni, documenti, utenti, strumenti, firme, impostazioni ed eventi.

Un riferimento facoltativo non garantisce da solo il 100% degli abbinamenti: vanno misurati riferimenti mancanti, errati, duplicati e discordanti. Gli eventi esistenti non equivalgono a una copia completa di ogni precedente salvataggio.

Prove eseguite sul pacchetto autonomo: 255 test Python raccolti, 245 superati e 10 saltati per originali mancanti; quattro suite JavaScript superate; manifesto verificato; esperimento sintetico di conservazione del riferimento nel backup/ripristino. Non sono stati eseguiti una nuova accettazione Windows o nuovi PDF reali. Il ponte non è stato implementato né rilasciato.

### 4.3 Migrazione v0.2

La riesecuzione riproduce la quadratura ricevuta. Tutti i 3.500 JSON cliente sorgente sono conservati esattamente. Sono positivi 23 confronti aggregati e i controlli per record degli importi esaminati; integrità, FK dichiarate e sette riferimenti logici controllati non mostrano violazioni.

La revisione resta aperta per questi motivi:

- **Identità delle tarature:** 622 righe e 480 incarichi sono associati all’attrezzatura anziché alla valvola. Una correzione su copia diagnostica elimina le 244 tarature sul tipo di bene errato e ricostruisce 336 valvole con fonte I&C. Gli originali non sono stati modificati e la prova non è una release pronta.
- **Fusioni fiscali:** tre nuovi gruppi con CF comune e P.IVA differenti richiedono revisione. Il risultato effettivo è 2.472 clienti canonici, non 2.475.
- **Date discordanti:** la v0.2 applica già la prevalenza I&C a 41 date CND, pur lasciando aperti i conflitti. La prova corretta delle tarature fa emergere altre 17 discordanze. Le categorie possono sovrapporsi.
- **Rettifiche del recepimento:** 427 conflitti anagrafici e 508 segnalazioni nella quadratura ricevuta; 30 utenti primari più 10 alias non costituiscono una mappa completa delle origini dei 40 account.
- **Ancora necessari:** importi esatti nel modello operativo, identità stabili, import incrementale, storicizzazione dell’emittente, recupero dei documenti e validazione delle coperture/scadenze.

Questi sono problemi della migrazione sperimentale; non vanno attribuiti automaticamente a Garda.

### 4.4 Gestionale_AD v0.7.1

È lavoro recuperabile: contiene FastAPI, SQLAlchemy/Alembic, interfaccia HTML/JS, anagrafiche, tariffario, preventivi, verifiche, controlli documentali e ponte con VerbalizzAI. La copia incorporata è la 0.3.32.1, mentre il pacchetto autonomo analizzato è la 0.3.32.3.

La 0.7.1 contiene già un importatore ingecert. Il suo lettore è stato eseguito: i conteggi delle 13 tabelle selezionate coincidono con l’estrazione precedente. Non è stato eseguito l’importatore applicativo completo in questa revisione. Sono stati verificati sintatticamente 116 file Python, senza errori. I 107 test dichiarati dal progetto non sono stati rieseguiti.

Restano scelte DPR da adattare al nucleo delle tre attività e problemi di comportamento elencati più avanti. La presenza del prototipo non dimostra che l’integrazione sia già conclusa.

## 5. Avanzamento effettivo

| Attività | Stato al 8 ottobre 2026 | Esito o lavoro residuo |
|---|---|---|
| Reperimento e inventario dei backup | Completato per i materiali ricevuti | Sorgenti e dump disponibili; originali S3 rinviati su richiesta, non bloccanti per la fase concettuale. |
| Analisi iniziale delle tre attività | Completata come prima ricognizione | Regole e criticità individuate; non è un audit completo. |
| Revisione VerbalizzAI 0.3.32.3 | Completata sul pacchetto | Ponte minimo definito; archivio reale e modifica ancora da trattare. |
| Riesecuzione/revisione migrazione v0.2 | Eseguita, chiusura aperta | Prova diagnostica sulle tarature; correzioni definitive e nuova quadratura da fare. |
| Esame Gestionale_AD 0.7.1 | Completato come revisione mirata | Componenti candidati al riuso e comportamenti da riprogettare. |
| Catalogo concettuale delle inefficienze | Prima versione prodotta | Da validare con esempi d’uso, procedure e decisioni precedenti. |
| Processo scadenza–offerta–incarico | Prima specifica e mappa delle transizioni prodotte | Regole e casi nella sezione 15; confronto mirato Garda/0.7.1, controlli proposti e criteri di accettazione nella sezione 23. |
| Preparazione e finalizzazione del preventivo DPR | Requisiti documentali raccolti; sorgenti 0.7.1 confrontati | Ciclo anteprima–ritocco già recuperabile; firma, convenzione di nome e download automatico da completare. |
| Schema operativo definitivo e stack | Non consolidati | Non risulta una conferma esplicita dello stack nella conversazione disponibile. |
| Nuovo backend integrato, fatturazione e allegati | Non realizzati in questa sessione | Esistono PoC e prototipo ricevuti, non una nuova implementazione unificata conclusa. |
| Rilascio/cutover del gestionale integrato | Non avviato | Nessuna modifica ai gestionali in produzione. |

Le verifiche sono state svolte su copie dei materiali. Il codice del prototipo è stato ricevuto dall’utente; non viene presentato come sviluppo realizzato durante questa analisi.

## 6. Decisioni aperte

**Elenco operativo aggiornato:** la sezione 25 raccoglie i quattordici punti strutturali da chiudere prima dello sviluppo di partenza, distinguendoli dalle decisioni acquisite, dalle verifiche tecniche e dai dettagli rinviabili. La tabella seguente conserva il quadro sintetico.

| Decisione | Proposta o vincolo emerso | Stato |
|---|---|---|
| Stack | Python + FastAPI + SQLAlchemy/Alembic, HTML/JS; SQLite per sviluppo e possibile PostgreSQL in produzione. | Proposta riportata dall’utente; conferma non attestata. La 0.7.1 usa già parte di questo stack, ma non costituisce una scelta definitiva. |
| Stato tecnico e anagrafiche | Definire un proprietario del dato e regole di aggiornamento fra nucleo e VerbalizzAI. | Da decidere prima dell’integrazione definitiva. |
| Contratti DPR a scadenza e affidamenti pluriennali | Il nuovo contratto a ogni scadenza è il percorso ordinario; il pluriennale è un’eccezione esplicita. | Prassi chiarita dall’utente. Restano da definire prezzi, ambito e condizioni degli affidamenti pluriennali. |
| Riesame, consegna e fatturazione | Prassi attuale dichiarata: RV, poi consegna e fatturazione. Mappa nella sezione 23, proposta di percorso ordinario ed eccezione controllata nella sezione 24, con riscontro RG-01-04. | Primo esercizio con invio dopo riesame; rilascio immediato rinviato. Restano gestione delle correzioni da RV, dettagli della sospensione e rettifiche economiche. |
| Prevalenza delle scadenze discordanti | Non trattare una scelta implicita del migratore come decisione aziendale. | Politica da approvare sui casi reali. |
| Identità comuni | Revisione delle fusioni controverse e mappa completa delle origini. | Da completare prima dell’uso operativo. |
| Convivenza e passaggio | Un’autorità di scrittura dichiarata per ciascuna funzione; riallineamento e finestra di passaggio verificabili. | Piano da costruire; nessun cutover autorizzato o eseguito qui. |

Lo schema operativo proposto include importi in centesimi/decimal esatti, FK dichiarate e registro delle esportazioni Word/PDF. Sono requisiti di progettazione, non modifiche già applicate al PoC. La numerazione concorrente e il passaggio a PostgreSQL richiedono verifica concreta: il prototipo si appoggia anche a un blocco nel singolo processo.

## 7. Sequenza aggiornata e prossimo lavoro

La sequenza di sette passi riportata in conversazione — schema, backend, regole DPR, VerbalizzAI, fatturazione, allegati, cutover — è una base utile, ma la richiesta più recente inserisce **la progettazione dei processi prima di altro sviluppo**.

1. Descrivere i problemi quotidiani e validare i comportamenti desiderati, cominciando da scadenza, offerta e incarico.
2. Consolidare concetti comuni, regole specifiche, casi eccezionali e criteri di accettazione.
3. Scegliere componenti da recuperare dalla 0.7.1, confermare le scelte tecniche e correggere schema/migrazione con nuova quadratura.
4. Realizzare il minimo percorso DPR completo con VerbalizzAI e fatturazione; preparare in parallelo l’inventario degli allegati.
5. Collaudare sui casi reali, definire convivenza e cutover DPR; estendere DM e I&C dopo validazione nell’uso.

Prima attività concreta proposta: ricostruire un caso DPR normale e uno problematico dal momento in cui compare nello scadenzario fino alla consegna e fatturazione. In parallelo, usare un caso di taratura/CND I&C per verificare che il nucleo non sia troppo specifico del DPR.

Le sezioni successive costituiscono la prima proposta concettuale da discutere. Il documento verrà aggiornato sulla stessa base distinguendo ogni nuova decisione, evidenza e attività conclusa; non è un aggiornamento automatico in assenza di ulteriore lavoro.

## 8. Cosa recuperare dalla 0.7.1

| Parte | Valutazione | Uso proposto |
|---|---|---|
| Accesso, ruoli, permessi, griglie, registro e backup | Fondamenta già sviluppate, candidate al riuso | Valutarle sul sistema comune e sui permessi distinti per ambito e società. |
| Anagrafiche e ricerca | Buon punto di partenza per l’interfaccia | Conservare le funzioni utili; progettare identità condivisa e condizioni commerciali specifiche. |
| Tariffario, importi in centesimi, preventivi e revisioni documentali | Lavoro concreto da recuperare | Conservare prezzi storici e documenti emessi; distinguere offerta, accordo commerciale e lavoro operativo. |
| Verifiche, assegnazione, riesame e storico | Prototipo utile per discutere il DPR | Rivedere stati, prerequisiti e casi eccezionali prima di assumerli come modello comune. |
| Ponte con VerbalizzAI | Dimostra già il percorso incarico–bozza–emissione | Recuperare l’esperienza; rendere affidabili aggiornamenti, correzioni e proprietà dei dati. |
| Importatore Garda | Utile per leggere e mostrare i dati reali DPR | Trattarlo come importazione iniziale; progettare a parte la convivenza e il riallineamento. |

Una precisazione: sebbene il progetto sia nato senza il backup Garda, **la versione ricevuta contiene già un importatore del dump ingecert**. Legge anagrafiche, preventivi, verifiche e utenti. Non importa ancora fatture, pagamenti e contenuti dei PDF conservati in S3, e richiede un archivio senza clienti. Non è quindi già la migrazione incrementale del gestionale integrato.

La copia incorporata di VerbalizzAI è la 0.3.32.1; il sorgente autonomo ricevuto è la 0.3.32.3. Il riuso dovrà evitare che i due rami perdano le correzioni reciproche.

## 9. Primo catalogo dei problemi

La distinzione fra le origini è essenziale: un difetto del prototipo o della migrazione non dimostra un difetto di Garda. Viceversa, una regola utile di Garda non va eliminata solo perché il nuovo sistema è più semplice.

| Tema | Evidenza e origine | Comportamento da progettare |
|---|---|---|
| Aggiornamenti AD_dm/I&C | **Garda, accertato.** Due archivi e sincronizzazione delle attività. Il PHP avverte che date modificate dopo la sincronizzazione vanno riportate manualmente in AD_dm. | Registrare una sola attività sul bene corretto; tutte le viste interessate leggono lo stesso dato. Una rettifica aggiorna le conseguenze e lascia traccia. |
| Identità comuni | **Garda e migrazione.** Anagrafiche separate; nella migrazione esistono conflitti e abbinamenti da verificare. | Un’identità condivisa, con origini conservate. Condizioni, referenti, autorizzazioni e documenti possono restare diversi per attività o società. Nessuna fusione basata soltanto sul nome. |
| Significato della scadenza | **Prototipo, rischio verificato nel codice.** Il collegamento al preventivo usa impianto e data, senza distinguere la prestazione e lo stato del lavoro associato. | Distinguere bisogno tecnico, offerta, accettazione e programmazione. Una verifica straordinaria non deve apparire automaticamente come copertura di quella periodica. |
| Stato del lavoro e fatturazione | **Prototipo, accertato.** “Riesaminata” è etichettata “da fatturare”; per gli storici già fatturati l’informazione è nelle note. | Avanzamento operativo, riesame, consegna e fatturazione devono essere interrogabili separatamente. Una pratica già fatturata non entra nella lista delle nuove fatture. |
| Indipendenza del verificatore | **Regola utile di Garda.** La dichiarazione blocca programmazione/registrazione/esecuzione. Nella 0.7.1 il dato storico è nelle note e non è un controllo strutturato della verifica. | Conservare la dichiarazione come evidenza dell’incarico, con autore e data. Definire cosa succede se cambia il verificatore. |
| Componenti e campioni | **Prototipo, rischio accertato nel codice.** Gli elementi derivano dai campioni del verbale; quelli prima presenti ma non campionati vengono resi non attivi. | Distinguere “esistente”, “campionato”, “non campionato” e “dismesso”. La dismissione richiede un fatto esplicito, non l’assenza da un campione. |
| Dati tecnici e rettifiche | **Prototipo, accertato.** Un verbale più vecchio non cambia le date correnti, ma può comunque sovrascrivere caratteristiche ed elementi. | Il documento storico conserva ciò che attestava allora; lo stato corrente dipende da eventi validi e ordinati, con correzioni esplicite. |
| Emissione e aggiornamento gestionale | **Prototipo, accertato.** VerbalizzAI emette prima; se l’aggiornamento del gestionale fallisce, il codice invita a caricare il verbale manualmente. | Il completamento deve essere affidabile e recuperabile senza duplicare documenti, numeri o lavoro dell’operatore. Un’incompletezza deve comparire in una lista da risolvere. |
| Rinnovo dei contratti DPR | **Prassi chiarita dall’utente.** Nuovo contratto a scadenza in circa 99 casi su 100; affidamenti pluriennali solo in casi particolari. | Rendere rapido e controllato il nuovo contratto; gestire separatamente l’eccezione pluriennale senza rinunciare all’autorizzazione e alle condizioni della singola prestazione. |

Nel dump I&C ci sono 40 attività effettuate in attesa di sincronizzazione, di cui 26 CND e 14 tarature. È una misura concreta della coda da riconciliare, non la prova che tutte le 40 date AD_dm siano sbagliate.

Garda distingue già le righe VP da altre prestazioni nel collegamento fra preventivo e scadenza, e considera lo stato della verifica associata. Qui il prototipo va migliorato conservando una distinzione già presente nel sistema attuale.

Gli abbinamenti errati delle tarature alle attrezzature, individuati nella precedente revisione del PoC, sono invece **errori della migrazione**: non vanno attribuiti al gestionale Garda. Insegnano comunque che il modello futuro deve distinguere valvola, attrezzatura e relazione di installazione.

## 10. Il funzionamento comune da definire

Il nucleo dovrebbe esprimere sette concetti di lavoro, prima di diventare uno schema di database:

1. **Soggetto e sede:** chi è coinvolto e dove si svolge il lavoro. Identità condivisa, senza perdere condizioni e contatti pertinenti alla singola attività.
2. **Bene:** impianto, attrezzatura, valvola o altro oggetto identificabile, con storia delle relazioni. Le caratteristiche tecniche restano specifiche per tipologia.
3. **Prestazione o obbligo:** cosa occorre fare, su quale bene, con quale periodicità o motivo. Uno stesso bene può avere più scadenze indipendenti.
4. **Accordo commerciale:** quale prestazione è autorizzata, a quali condizioni e per quale società. Una variazione futura non cambia gli importi già concordati o fatturati.
5. **Incarico e intervento:** chi deve eseguire cosa, quando e con quali prerequisiti; cosa è stato effettivamente eseguito, anche se parziale, sospeso o a vuoto.
6. **Documento e riesame:** quale versione attesta il lavoro, quale controllo è stato eseguito e quale versione è stata consegnata. Il documento emesso conserva la propria storia.
7. **Fatturazione e incasso:** quali prestazioni sono fatturabili, già fatturate, parzialmente fatturate o incassate. Questi fatti non dipendono dal solo stato tecnico dell’incarico.

Questo non significa aggiungere sette maschere o far compilare più campi. **L’operatore registra il fatto una volta; il sistema deriva gli stati e presenta la prossima azione pertinente.** Le viste DPR, DM e I&C mostrano soltanto i dettagli utili al proprio lavoro.

AD S.r.l. e I&C S.r.l. rimangono soggetti distinti per emissione e contabilità. La condivisione dell’anagrafica non le rende una società unica, né va confusa con la precedente incorporazione di I&C snc.

## 11. Esempi con cui validare il progetto

Questi sono criteri di accettazione del comportamento, non test applicativi già eseguiti.

| Caso reale da simulare | Risultato atteso |
|---|---|
| Un cliente riceve una verifica DPR e una prestazione I&C | Identità comune; incarichi, condizioni, documenti e società emittente corretti per ciascuna prestazione. |
| I&C completa una taratura e successivamente rettifica la data | La taratura resta associata alla valvola corretta. Le viste DM e I&C concordano; la rettifica è tracciata e non richiede ricopiatura. |
| Un impianto ha una periodica in scadenza e un preventivo per una straordinaria | La periodica rimane visibile come lavoro da gestire, salvo una regola esplicita e approvata che stabilisca diversamente. |
| Una verifica campiona 8 componenti su 30 esistenti | Gli altri 22 restano nell’inventario; sono semplicemente non campionati in quella verifica. |
| Si importa un verbale storico successivamente a uno recente | Lo storico si aggiunge senza sostituire silenziosamente lo stato tecnico corrente. |
| Il riesame richiede una correzione del verbale | Si apre la revisione pertinente, restano disponibili documento ed evidenze precedenti, e si identifica la versione da consegnare. |
| L’aggiornamento del gestionale si interrompe dopo l’emissione | Il sistema recupera l’aggiornamento sullo stesso verbale; non genera un secondo numero o una seconda fattura. |
| Una verifica importata è già fatturata in Garda | È consultabile nello storico ed esclusa dalle prestazioni ancora da fatturare. |
| Un intervento viene annullato o eseguito parzialmente | Restano espliciti motivo, prestazioni realmente svolte, conseguenze sulle scadenze e trattamento economico concordato. |

## 12. Primo ambito di confronto con chi usa il gestionale

Partirei dal percorso **scadenza → contatto/offerta → incarico**, perché determina sia il lavoro della segreteria sia quello dei tecnici. Per ogni passaggio descriviamo: chi agisce, cosa deve conoscere, cosa ricopia oggi, quale controllo serve, quale risultato deve ottenere e quali eccezioni incontra.

Le prime decisioni da esplicitare sono:

| Decisione | Proposta iniziale da validare |
|---|---|
| Quando una scadenza è “gestita”? | Mostrare separatamente “da contattare”, “offerta preparata/inviata”, “accettata”, “incarico aperto” e “programmata”. Nessuna offerta nasconde da sola l’obbligo tecnico. |
| Serve un nuovo contratto per ogni scadenza DPR? | Chiarito: normalmente sì, circa 99 casi su 100. Gli affidamenti pluriennali sono un’eccezione da supportare, non il nuovo modello ordinario. |
| Quando si può consegnare un verbale e quando si può fatturare? | Definire condizioni distinte secondo le procedure aziendali, inclusi esiti negativi, sospensioni, interventi a vuoto e riesami non conformi. |
| Quali dati sono realmente condivisi? | Identità di soggetti e beni; condizioni economiche, destinatari e permessi specifici dove necessario. Stabilire anche chi può correggere il dato comune. |
| Come cambia una scadenza dopo una rettifica? | Conservare fonte e motivo della data; ricalcolare soltanto gli effetti pertinenti. Stabilire regole per straordinarie, annullamenti e beni spostati o dismessi. |

L’ordine di riesame, emissione e consegna deve essere definito con le procedure vigenti; questa analisi non certifica la conformità a ISO/IEC 17020. Garda e il prototipo sono fonti di comportamento, non sostituti della decisione organizzativa.

Per ogni miglioramento userei una scheda breve: **problema osservato; esempio; comportamento desiderato; regola da conservare; eccezioni; criterio di accettazione**. Solo dopo la validazione della scheda scegliamo cosa riusare, adattare o costruire.

## 13. Evidenze della revisione concettuale e riferimenti

Sono stati letti modelli, servizi, API, importazione, ponte VerbalizzAI e documentazione della 0.7.1, confrontandoli con i flussi PHP Garda. I 116 file Python esaminati non presentano errori di sintassi nella verifica statica.

È stato eseguito il solo lettore del dump della 0.7.1: i conteggi delle 13 tabelle selezionate coincidono con quelli dell’estrazione precedente, fra cui 1.910 clienti, 2.674 sedi, 2.694 impianti, 1.009 preventivi, 1.866 righe e 1.438 verifiche. Questo verifica la lettura quantitativa, non la trasformazione applicativa o la correttezza di ogni valore.

La documentazione dichiara 107 test automatici. Non sono stati rieseguiti in questa revisione; le dipendenze applicative non sono installate nell’ambiente corrente. Non è stato effettuato un collaudo operativo della 0.7.1 e non viene dichiarata pronta alla produzione.

Il LEGGIMI rinvia ai documenti 01–15 del progetto “Gestionale completo AD_dpr” e a un registro delle decisioni: non sono presenti nello ZIP. Le proposte qui indicate restano da confrontare con quei documenti e con i casi d’uso degli operatori.

Riferimenti principali ai sorgenti:

- Garda DPR: [controlli della verifica e ricalcolo scadenze](sandbox:/workspace/scratch/4e6614e59745/analysis/legacy/backup_gestionale/ingecert/codice/files/public_html/cust/_custom.php).
- Garda I&C: [attività e rettifiche dopo la sincronizzazione](sandbox:/workspace/scratch/4e6614e59745/analysis/legacy/backup_gestionale/iec/codice/files/public_html/cust/_custom.php).
- Prototipo: [stati e modello delle verifiche](sandbox:/workspace/scratch/4e6614e59745/analysis/gestionale_ad_v071/Gestionale_AD_v0.7.1/gestionale/moduli/verifiche/modelli.py), [aggiornamenti di impianto e componenti](sandbox:/workspace/scratch/4e6614e59745/analysis/gestionale_ad_v071/Gestionale_AD_v0.7.1/gestionale/moduli/verifiche/servizio.py).
- Prototipo: [legame scadenza–preventivo](sandbox:/workspace/scratch/4e6614e59745/analysis/gestionale_ad_v071/Gestionale_AD_v0.7.1/gestionale/moduli/preventivi/griglie.py), [importazione Garda](sandbox:/workspace/scratch/4e6614e59745/analysis/gestionale_ad_v071/Gestionale_AD_v0.7.1/gestionale/moduli/garda/importa.py), [emissione e aggiornamento del gestionale](sandbox:/workspace/scratch/4e6614e59745/analysis/gestionale_ad_v071/Gestionale_AD_v0.7.1/gestionale/moduli/verbali/api.py).

## 14. Analisi di dettaglio e storico del documento

- [Analisi iniziale dei tre gestionali](sandbox:/workspace/scratch/4e6614e59745/deliverables/01_Analisi_iniziale_gestionale_integrato_2026-10-08.md).
- [Valutazione VerbalizzAI e ponte minimo](sandbox:/workspace/scratch/4e6614e59745/deliverables/02_Valutazione_VerbalizzAI_ponte_integrazione_2026-10-08.md).
- [Revisione della migrazione v0.2](sandbox:/workspace/scratch/4e6614e59745/deliverables/03_Revisione_migrazione_v0.2_2026-10-08.md).

| Versione | Data | Aggiornamento |
|---|---|---|
| 1.0 | 8 ottobre 2026 | Prima sintesi unitaria di requisiti, materiali, analisi, avanzamento, decisioni aperte e catalogo concettuale; incorpora la revisione della 0.7.1. |
| 1.1 | 8 ottobre 2026 | Registrato il rinvio degli originali S3; sviluppato il processo scadenza–offerta–incarico con casi DPR e I&C, eccezioni e criteri di accettazione. |
| 1.2 | 8 ottobre 2026 | Raccolta la prassi DPR del contratto a ogni scadenza e dell’eccezione pluriennale; aggiornate le proposte precedenti e definito il primo comportamento di rinnovo. |
| 1.3 | 8 ottobre 2026 | Raccolte le basi tariffarie AD_dpr e la possibilità di sconto nelle gare PA; aperto il chiarimento sul calcolo delle ore per i luoghi con pericolo di esplosione. |
| 1.4 | 8 ottobre 2026 | Chiarito che ATEX segue l’importo preventivato senza consuntivo; verificato il percorso tariffa–preventivo–verifica–fattura nel codice; formalizzato il metodo di analisi prima delle domande. |
| 1.5 | 8 ottobre 2026 | Raccolto il requisito di anteprima PDF e correzione iterativa Word come in VerbalizzAI; verificato il riuso del flusso documentale 0.7.1; aggiunti firma/finalizzazione, nome file e download automatico con destinazioni da definire. |
| 1.6 | 8 ottobre 2026 | Recepito il termine “preventivo”; separati i dettagli rinviati dalle scelte strutturali; formulata la proposta di nucleo integrato con primo rilascio DPR autonomo e le cinque domande per delimitarlo. |
| 1.7 | 8 ottobre 2026 | Recepiti fatturazione/incassi completi, intestatario fattura distinto, programmazione separata e riesame obbligatorio dopo accettazione prima dell’affidamento; verificati i relativi riferimenti Garda e chiarita la domanda sulla connessione. |
| 1.8 | 8 ottobre 2026 | Scelto il primo rilascio solo online; chiusa Q4 e consolidata la scheda del primo AD_dpr, con proposta del nucleo concettuale e casi da verificare. |
| 1.9 | 8 ottobre 2026 | Ricostruito il ciclo DPR dai servizi e metadati; aggiunta la mappa di azioni, prerequisiti ed effetti, con controlli da rafforzare e casi di accettazione. Aperta la decisione sul riesame prima della consegna del verbale; fatturazione/incassi completi restano nel perimetro, con censimento dettagliato ancora da completare. |
| 1.10 | 8 ottobre 2026 | Raccolta la prassi RV–consegna–fattura; verificati RG-01-04 rev.03 §2.7 e rev.04 §2.5. Proposti percorso ordinario dopo RV ed eccezione controllata di rilascio immediato, soprattutto DPR, compatibili con l’uso online. Separata la decisione di attivazione dalla predisposizione del modello; recepito il vincolo esplicito di semplicità del flusso e dei controlli. |
| 1.11 | 8 ottobre 2026 | Consolidato l’elenco dei quattordici punti da decidere prima del codice iniziale, con proposte semplici e risultati attesi; distinti requisiti acquisiti, lavoro tecnico e decisioni che possono attendere il collaudo/cutover. |
| 1.12 | 8 ottobre 2026 | Chiarito D01 per il ciclo DPR: stesso datore di lavoro su impianto/preventivo/verbale, terzo soltanto in fattura. Ritirata la proposta di un diverso committente commerciale prima della fatturazione; recepito il vincolo di discussione preventiva delle modifiche alle logiche ed entità Garda. |
| 1.13 | 8 ottobre 2026 | Verificati anagrafica cliente, viste collegate e generazione preventivo Word Garda: dati correnti e assenza di una storia strutturata riscontrata. Acquisito il requisito di immutabilità di verbali/preventivi emessi; separati cambio dei dati della stessa azienda e subentro di altra azienda. Il trasferimento del bene è ancora da discutere. |
| 1.14 | 8 ottobre 2026 | Acquisita la scelta sul subentro DPR: nuovo cliente, stesso impianto e passaggio tracciato, con emessi precedenti preservati. Avviato il confronto D02 sul rapporto valvola–attrezzatura partendo dai metadati Garda, senza adottare nuove relazioni. |
| 1.15 | 8 ottobre 2026 | Acquisita la gestione semplice dell’abbinamento valvola–attrezzatura: dato corrente modificabile manualmente e storico tarature/documenti, senza storico dei montaggi aggiuntivo. Prosegue D03 sulla responsabilità delle correzioni anagrafiche. |
| 1.16 | 8 ottobre 2026 | Riclassificata la modifica anagrafica come configurazione di ruoli/permessi, non blocco del modello. Verificato il momento di aggiornamento delle scadenze DPR in Garda: ultima VP effettuata, senza richiedere RV conforme. La scelta futura su quel momento è ancora aperta. |
| 1.17 | 8 ottobre 2026 | Confermato aggiornamento scadenza DPR prima del RV, con adeguamento alle revisioni pertinenti. Riscontrata in Garda la riapertura/ricaricamento dopo RV negativo, senza revisione strutturata del verbale individuata; VerbalizzAI e ponte 0.7.1 contengono già revisioni. Prosegue D06 sull’evidenza di accettazione. |
| 1.18 | 8 ottobre 2026 | Acquisita l’evidenza scritta di accettazione DPR: preventivo controfirmato oppure email, senza accettazione telefonica. Il confronto D06 prosegue con l’aggiunta di prestazioni dopo l’accettazione; nessuna scelta automatica fra nuovo preventivo e revisione dell’accettato. |
| 1.19 | 8 ottobre 2026 | Preventivo accettato non modificabile: nuove prestazioni con nuovo preventivo integrativo, secondo il normale flusso di accettazione e RC. Acquisita la possibilità di fattura unica per prestazioni di preventivi diversi. Prossimo chiarimento: copertura degli interventi negli affidamenti pluriennali. |
| 1.20 | 8 ottobre 2026 | Corretto il confronto con Garda: fattura unica già disponibile tramite generazione da riga preventivo e associazione a fattura esistente, confermata nel sorgente della maschera. Raccolta la lacuna sui pluriennali (solo prossima scadenza) e la loro rarità. Raccomandato il rinvio di una gestione dedicata, preservando il flusso ordinario e gestendo manualmente le eccezioni. Nessuna nuova struttura contrattuale approvata. |
| 1.21 | 8 ottobre 2026 | Acquisito il significato degli stati DPR: programmazione facoltativa, registrazione durante l’esecuzione, eseguita solo con verbale finalizzato e caricato. Raccolta la proposta utente di stato sospesa quando la verifica non può essere eseguita. Da chiarire ripresa dello stesso incarico ed eventuale numero già assegnato. Aggiornata la mappa per evitare di chiamare eseguita la sola uscita fisica. |
| 1.22 | 8 ottobre 2026 | Confermata la continuità della verifica sospesa: ripresa sullo stesso incarico e conservazione dell’eventuale numero di verbale già assegnato. Nessuna creazione automatica di un nuovo incarico o duplicazione del numero per la sola sospensione. Prossimo chiarimento: eventuale addebito per uscita senza verifica conclusa. |
| 1.23 | 8 ottobre 2026 | Raccolta l’esigenza nuova di sopralluogo a vuoto addebitabile, oggi non gestita. Proposta una voce economica manuale distinta dalla verifica annullata, senza tariffa o addebito automatico. Avviato il chiarimento D11 sulla prassi DPR di acconti prima dell’esecuzione. Nessuna modifica applicativa. |
| 1.24 | 8 ottobre 2026 | Acquisita la prassi DPR sugli acconti: non ordinari ma possibili, quindi da supportare nel ciclo completo. Distinti acconto fatturato, incasso e collegamento al saldo. Prossimo chiarimento D11: modalità effettiva di trasmissione delle fatture elettroniche ed esiti. Nessuna modifica applicativa. |
| 1.25 | 8 ottobre 2026 | Acquisito il canale elettronico attuale: download XML da Garda e caricamento manuale su Fatturazione Elettronica Aruba. Conservazione del percorso nel primo DPR, con integrazione automatica rinviabile. Il ciclo completo di fatturazione/incassi resta richiesto. Prossimo chiarimento: dove vengono registrati gli incassi e controllati i crediti aperti. |
| 1.26 | 8 ottobre 2026 | Confermato Garda come riferimento operativo attuale per incassi e fatture ancora da pagare. Il primo AD_dpr conserva questa gestione; Aruba è il servizio di trasmissione delle fatture. Prossimo chiarimento D12: un unico bonifico a copertura di più fatture, rispetto al riferimento singolo per riga pagamento presente in Garda. |
| 1.27 | 8 ottobre 2026 | Confermato il caso occasionale di un bonifico per più fatture. Proposta una maschera unica di ripartizione con quote per fattura, conservando il collegamento singolo Garda. La modalità resta da validare prima di adottarla; nessuna modifica applicativa o nuova relazione finanziaria approvata. |
| 1.28 | 8 ottobre 2026 | Precisata la modalità minima di incasso: pagamento unico, normalmente associato a una fattura, eccezionalmente a più fatture. Superata la domanda su una maschera dedicata: basta estendere la normale associazione, conservando quote e totale. Prossimo chiarimento: dove vengono consultati o riportati gli esiti SdI. |
| 1.29 | 8 ottobre 2026 | Esiti oggi soltanto su Aruba, senza traccia in Garda: acquisito il requisito di importazione nel nuovo AD_dpr e di visibilità degli scarti da gestire. Conservazione degli esiti e dei tentativi sulla fattura; modalità tecnica da definire. Prossimo chiarimento: correzione della fattura scartata in Garda o direttamente in Aruba. |
| 1.30 | 8 ottobre 2026 | L’utente non ha una policy precisa sul luogo di correzione delle fatture scartate. Registrata la scelta aperta e proposta la correzione nel nuovo gestionale con rigenerazione XML, per allineare dati interni e contenuto trasmesso. Proposta da validare, non requisito approvato né implementazione. |
| 1.31 | 8 ottobre 2026 | Approvata la correzione delle fatture scartate nel nuovo gestionale, con rigenerazione XML e nuovo caricamento su Aruba, conservando tentativi ed esiti. Verificate le serie nei backup: DPR, DM, EX/ex in adsrl e serie annuale IEC. Prossimo chiarimento: attività cui corrisponde la serie EX, senza presumere una fusione delle numerazioni. |
| 1.32 | 8 ottobre 2026 | Chiarita dall’utente la serie EX di AD: CND GVR, efficienza delle valvole di sicurezza e verifiche ispettive volontarie SC/SP/GVR. Aggiornata l’interpretazione delle serie senza rinumerazioni. Prossimo chiarimento di nucleo comune: fatture separate o aggregate per prestazioni DM ed EX dello stesso cliente. |
| 1.33 | 8 ottobre 2026 | Confermate fatture separate per prestazioni DM ed EX dello stesso cliente, con serie distinte anche nei preventivi. Precisato il limite rispetto alla fattura unica da più preventivi già acquisita. Nessuna generalizzazione automatica agli altri abbinamenti. Prossima scelta sul primo DPR: attivazione del rilascio immediato del verbale, già previsto come opzione. |
| 1.34 | 8 ottobre 2026 | Confermato per ora l’invio dopo riesame nel primo DPR; opzione di rilascio immediato rinviata. Aggiornati i punti aperti precedenti. Riscontro Garda: RV negativo riporta la verifica a registrata. Prossimo confronto: mantenere quel ritorno o tenere distinta la sola correzione documentale nello stato RV. |
| 1.35 | 8 ottobre 2026 | Confermato il ritorno a registrata dopo RV negativo, con ripetizione dell’attività e/o correzione del verbale, ricaricamento ed eseguita prima del nuovo RV. Acquisiti nota RT visibile al verificatore e storico dei riesami per verbale/versione. Verificato il reset della nota corrente in Garda e gli eventi RV nel prototipo, da riutilizzare. Prossimo chiarimento D13: trasferimento o completamento in Garda degli incarichi DPR aperti al passaggio. |
| 1.36 | 8 ottobre 2026 | Acquisita la preferenza per importare gli incarichi DPR aperti, con decisione definitiva subordinata alla valutazione. Nel dump ingecert verificati 159 record negli stati assegnata/programmata/registrata e 3 effettuate senza RV fatto; la prova di import deve coprire questi casi. Prossimo chiarimento DPR: nuovo preventivo/incarico per ricontrollo straordinario dopo esito tecnico negativo. |
| 1.37 | 8 ottobre 2026 | Confermata la verifica straordinaria con preventivo distinto e verbale VS. Riscontrate in ingecert le tipologie VP/VS e la numerazione annuale comune. Ribadito il confronto obbligatorio con Garda per ogni requisito concordato: conservare l’esistente utile, documentare soltanto i miglioramenti necessari. Registrato un primo riscontro ANAC sugli sconti nelle procedure pubbliche, senza dichiarare conclusa la verifica delle condizioni applicabili. |
| 1.38 | 8 ottobre 2026 | Chiarita e confermata la numerazione DPR 462: progressivo unico annuale, prefissi VP/VS secondo il tipo. Il requisito conserva la logica ingecert esistente. Verificato inoltre che il ricalcolo Garda della scadenza periodica usa la VP effettuata e non la VS; prossimo chiarimento sulla prassi da mantenere. |
| 1.39 | 8 ottobre 2026 | Confermata la conservazione della regola Garda: VS senza ricalcolo automatico della scadenza periodica. Verificati flag dismessa, condizioni che impediscono nuove offerte da scadenza e generazione di verifiche per impianti dismessi; nel codice esaminato non risulta un annullamento automatico degli incarichi già aperti. Prossimo chiarimento sulla loro chiusura. |
| 1.40 | 8 ottobre 2026 | Confermata la chiusura manuale degli incarichi aperti su impianti dismessi, senza annullamento automatico. Riscontrata in ingecert l’accettazione per riga e il riepilogo accettato_parzialmente; prossimo chiarimento sulla sua rilevanza nella prassi DPR. |
| 1.41 | 8 ottobre 2026 | Confermata l’accettazione parziale sullo stesso preventivo, conservando una funzione già presente in ingecert. Riscontrato che il RC Garda è memorizzato sulla testata e letto dalle righe; il percorso esaminato non lo azzera alla successiva accettazione di un’altra riga. Prossimo chiarimento: portata del riesame nel caso di accettazioni successive. |
| 1.42 | 8 ottobre 2026 | Acquisita la semplificazione: RC sull’intera offerta invariata, senza ripeterlo per successive accettazioni di righe già incluse. Conservata la logica Garda con RC sulla testata. Esteso il riscontro sugli incassi: calcolo rate e residui presente nel codice; non individuato nel modulo personalizzato un import bancario dedicato. Prossimo chiarimento sul perimetro della registrazione incassi iniziale. |
| 1.43 | 8 ottobre 2026 | Confermati incassi manuali nel primo AD_dpr; import estratti conto richiesto come modulo necessario successivo. Riesaminato il registro D01–D14 per distinguere domande operative, verifiche tecniche e moduli futuri. Raccomandato di chiudere il DPR operativo e verificare ora soltanto la compatibilità strutturale del nucleo con DM/I&C, senza estendere il questionario ai loro flussi completi. |
| 1.44 | 8 ottobre 2026 | Confermato il perimetro: DPR operativo e compatibilità del nucleo con DM/I&C. Avviato il primo dei tre blocchi finali, dati tecnici: VerbalizzAI ha già la scelta di aggiornare/conservare la scheda all’emissione; il prototipo aggiorna caratteristiche al caricamento. Individuati controlli da correggere nel ponte, inclusa la scadenza automatica sulle VS. Nessuna modifica applicativa eseguita. |
| 1.45 | 8 ottobre 2026 | Chiarito che la scheda corrente deve seguire i cambiamenti dell’impianto, inclusi alimentazione e differenziali; verificato il riuso della gestione elementi in VerbalizzAI e il limite del campionamento. Aperta la conferma del comportamento predefinito alla finalizzazione. Consegnato separatamente l’approfondimento DM/I&C 05, versione 0.1, basato sul quadro 1.44. Nessuna modifica applicativa eseguita. |
| 1.46 | 8 ottobre 2026 | Confermata R61: fotografie storiche nei verbali emessi, nuova bozza dalla situazione tecnica dell’ultima verifica. Chiuso il criterio aziendale del primo blocco dati tecnici; restano mapping e collaudo. Avviato il riscontro sui prerequisiti dell’affidamento, senza riaprire la configurabilità di ruoli e permessi. Nessuna modifica applicativa eseguita. |
| 1.47 | 8 ottobre 2026 | Acquisita R62: con quattro tecnici abilitati non introdurre matrice o filtro delle qualifiche nel primo AD_dpr. Assegnazione manuale secondo i permessi; proseguire soltanto sul comportamento della dichiarazione d’indipendenza già presente in Garda. Nessuna modifica applicativa eseguita. |
| 1.48 | 8 ottobre 2026 | Acquisita R63: dichiarazione d’indipendenza preselezionata, escludibile; esclusione impedisce lo svolgimento da parte del tecnico, come in Garda. Chiusa la scelta del secondo blocco. Avviato il censimento delle note di credito già previste nel codice fiscale; prassi sulle rettifiche economiche ancora da chiedere. Nessuna modifica applicativa eseguita. |
| 1.49 | 8 ottobre 2026 | Acquisita R64: note di credito anche parziali nel primo AD_dpr. Verificato che Garda genera movimenti di uscita per TD04 e preserva i pagamenti saldati nel ricalcolo; rimane da chiarire la prassi su rimborso o compensazione delle somme già incassate. Nessuna modifica applicativa eseguita. |
| 1.50 | 8 ottobre 2026 | Acquisita R65: emissione diretta di fattura/nota di credito con righe libere, senza collegamento obbligatorio ai verbali. Verificati azioni di creazione, campi delle righe e riferimenti operativi non obbligatori nel codice Garda. Casi rari nello stesso ciclo economico, senza incarichi fittizi. Nessuna modifica applicativa eseguita. |
| 1.51 | 8 ottobre 2026 | Acquisita R66: nella prassi la nota di credito interviene prima dell’incasso. Caso ordinario basato sul residuo da riscuotere; nessuna procedura dedicata di rimborso richiesta ora. Riscontrati anche TD02/TD03 per acconti e flag di generazione XML in Garda; modalità del recupero esiti ancora da scegliere. Nessuna modifica applicativa eseguita. |
| 1.52 | 8 ottobre 2026 | Acquisita R67: importazione esiti Aruba necessaria, modalità da definire successivamente; nessuna scelta manuale o automatica approvata. Consolidata nella sezione 29 la sintesi funzionale del primo AD_dpr e del nucleo, distinguendo decisioni, modello proposto e verifiche tecniche prima del codice/produzione. Nessuna modifica applicativa eseguita. |
| 1.91 | 9 ottobre 2026 | Autorizzata la prosecuzione del raccordo DPR–DM preservando DM per sede e DPR multisede. Richiesto consiglio per istanze parallele anche su altri LLM: protocollo 22 e kit di contesto, unico integratore e incarichi DM/QA/INAIL. Nessun agente avviato, nessuna modifica applicativa o nuova deroga funzionale. |
| 1.90 | 9 ottobre 2026 | R99: prossimo rilascio funzionale DPR/DM; verificata struttura delle offerte cliente/sede, 168 multisede DPR e discrepanze DM/DPR, proposta conservativa e importazione senza divisione/fusione degli emessi. Rapporto 21 e ripresa aggiornati. |
| 1.93 | 9 ottobre 2026 | Incarichi tecnici DM fino a registrazione, migrazione 0013 e aggiornamenti master/bozze; R100 per tre ambienti selezionabili e ingressi definitivi distinti almeno AD/I&C. Rapporto 24, stato/manuale e ripresa aggiornati; funzioni mancanti esplicite. |
| 1.89 | 9 ottobre 2026 | R98 e correzioni 0.8.1/0.9.1 con prove; ricevute e confrontate 15 schermate AD_DM, critica dell’interfaccia registrata e priorità sulle maschere Garda. Backend DM incompleto dichiarato; proposta cartelle Windows. Rapporti 18–20 e ripresa aggiornati. |

## 15. Prima specifica: scadenza, offerta e incarico

**Stato: proposta concettuale da validare nell’uso.** L’utente ha autorizzato a procedere; questo non equivale all’approvazione preventiva delle singole regole seguenti. Nessun codice applicativo modificato.

### 15.1 Unità di lavoro

La voce da seguire è **una prestazione su un bene per una determinata esigenza o ciclo**: ad esempio, la periodica DPR di un impianto riferita alla scadenza corrente. Non basta dire “questo impianto ha un preventivo”. Una straordinaria e una periodica sono esigenze diverse, anche sullo stesso impianto; un preventivo per un ciclo già completato non copre automaticamente il successivo.

La data tecnica deve conservare origine, regola o motivazione, attività di riferimento e eventuale discordanza. Una rettifica cambia il fatto pertinente, non cancella la storia. Un’attività senza scadenza periodica, come alcune consulenze, entra dal bisogno o dalla richiesta del cliente; non le si inventa una scadenza per adattarla al DPR.

### 15.2 Cosa dovrebbe mostrare la lista di lavoro

Una vista unica per la segreteria collega cliente, sede, bene, prestazione, società/ambito, data tecnica, incarico pertinente e prossima azione. La priorità tecnica e il progresso commerciale restano leggibili separatamente. Eventuali contatti e promemoria si aggiungono a quel contesto, senza copiare l’anagrafica.

| Situazione | Cosa resta visibile | Prossima azione proposta |
|---|---|---|
| Esigenza senza offerta o accordo applicabile | Data tecnica e lavoro da prendere in carico | Contattare il cliente o predisporre l’offerta. |
| Offerta preparata, non inviata | Esigenza ancora aperta e bozza pertinente | Completare e inviare la versione corretta. |
| Offerta inviata, risposta assente | Esigenza ancora aperta; invio e richiamo pianificato | Gestire il seguito commerciale. |
| Prestazione accettata, controlli contrattuali da completare | Accettazione acquisita e impedimento esplicito | Completare il riesame secondo il processo concordato. |
| Prestazione autorizzata, incarico da assegnare | Lavoro preso in carico ma non ancora programmato | Assegnare il tecnico idoneo. |
| Incarico programmato | Data tecnica e data pianificata, anche se diverse | Eseguire o riprogrammare, segnalando ritardi. |
| Cliente rifiuta o rimanda | Esigenza tecnica e motivo commerciale | Stabilire il seguito o l’esclusione motivata dalla propria lista operativa. |
| Lavoro svolto, documentazione incompleta | Attività eseguita e azione documentale residua | Completare verbalizzazione e controlli. |

“Non da ricontattare ora” non significa “obbligo tecnico assolto”. Il rifiuto del cliente non modifica da solo la data tecnica. L’uscita dalla lista commerciale, il rinvio del contatto e la dismissione del bene sono fatti distinti, con motivo e autore.

### 15.3 Passaggi e responsabilità proposte

| Passaggio | Responsabilità da attribuire | Dato acquisito una volta | Effetto atteso |
|---|---|---|---|
| Individuare l’esigenza | Segreteria/ruolo competente per l’ambito | Prestazione, bene, ciclo, fonte della data | Voce di lavoro identificata senza duplicazione. |
| Preparare l’offerta | Commerciale o segreteria autorizzata | Condizioni, righe, società emittente, versione | Anagrafica proposta dai dati comuni; prezzi storicizzati nell’offerta. |
| Acquisire l’accettazione | Segreteria autorizzata | Evidenza, data, riferimento e sole righe accettate | Le righe non accettate restano aperte nel proprio contesto. |
| Completare il riesame contrattuale | Ruolo competente da definire nelle procedure | Esito, autore, data, motivazioni ed evidenze disponibili | Autorizzazione operativa oppure impedimento esplicito. |
| Aprire l’incarico | Sistema, al soddisfacimento dei prerequisiti | Legame alla prestazione autorizzata | La stessa azione ripetuta non crea un secondo incarico. |
| Assegnare e programmare | Responsabile competente e tecnico secondo il flusso concordato | Incarico, verificatore, prerequisiti, data prevista | Il tecnico trova dati pertinenti e può aprire la bozza senza ricopiarli. |

Come base del primo caso DPR manteniamo il percorso già espresso dalla 0.7.1: riga accettata, riesame contrattuale conforme e incarico derivato. L’utente ha chiarito che il nuovo contratto a scadenza è la prassi ordinaria; gli affidamenti pluriennali sono un’eccezione, sviluppata nella sezione 16. Le attività I&C possono avere aggregazioni e articolazioni diverse dalle righe DPR; il concetto di prestazione autorizzata deve accoglierle senza imporre lo stesso formato commerciale.

L’accettazione non è un interruttore sull’intero cliente. Un’offerta può includere più sedi o prestazioni ed essere accettata parzialmente: si prendono in carico le parti autorizzate, evitando di dichiarare gestite anche le altre.

### 15.4 Eccezioni da conservare nel processo

- **Offerta rivista:** si conserva la versione inviata e si identifica quella corrente; l’accettazione resta collegata alle condizioni realmente accettate. Le modifiche successive non cambiano silenziosamente l’accordo.
- **Incarico già aperto:** la segreteria deve vederlo prima di creare un nuovo lavoro per la stessa esigenza. Una seconda prestazione legittima deve poter essere distinta, non bloccata solo perché riguarda lo stesso bene.
- **Tecnico sostituito:** va rivalutata la pertinenza delle dichiarazioni e dei prerequisiti personali; quelli del precedente verificatore non diventano automaticamente quelli del nuovo.
- **Annullamento:** si registra che cosa viene annullato — offerta, incarico o documento — e si decide se l’esigenza rimane da gestire. Il bene non viene dismesso automaticamente.
- **Riesame documentale negativo:** si apre la correzione della versione pertinente. Non si genera automaticamente una nuova visita o una nuova prestazione fatturabile; un ulteriore intervento reale è un fatto distinto.
- **Parziale, sospeso o a vuoto:** si registra ciò che è successo; completamento, prossima data e trattamento economico dipendono dalle regole specifiche concordate.

### 15.5 Casi concreti disponibili senza S3

I seguenti riscontri provengono dal dump del 7 ottobre 2026. Gli ID sono quelli dei gestionali sorgente, non quelli canonici del futuro sistema. Lo snapshot attesta i valori presenti, non tutta la sequenza storica delle azioni.

| Caso | Fatto verificato | Criterio di accettazione del futuro processo |
|---|---|---|
| DPR: verifica `1417`, impianto `2502` | Riga `2389` del preventivo `1045` accettata; riesame contratto conforme; dichiarazione del verificatore presente; verifica effettuata, con rilascio del verbale il 28/09/2026, riesame conforme e riferimento alla fattura `516`. | Lo storico mantiene tutti i collegamenti; il lavoro non torna da fatturare. La prossima esigenza usa la data registrata `27/09/2028`, senza riutilizzare il vecchio incarico. |
| DPR: impianto `1960` | Nei dati sono presenti verifiche sia VP sia VS. | Il collegamento commerciale distingue le due prestazioni e il ciclo pertinente; non usa soltanto l’identità dell’impianto. Questo dato da solo non prova una copertura errata in Garda. |
| I&C: attività/riga `3257` | Taratura effettuata il 22/09/2026, prossima data `21/09/2028`, valvola `627`, attrezzatura `7654`; flag di sincronizzazione ancora `T`. | Il nuovo nucleo collega la taratura alla valvola, conserva l’attrezzatura di contesto e aggiorna le viste DM/I&C dalla medesima attività. Il flag storico non va interpretato come prova che la copia DM sia già allineata. |
| I&C: attività/riga `2430` | Taratura della valvola `1823` con prossima data `20/08/2028`; nella precedente revisione è emersa una data DM diversa, `03/06/2028`. | Entrambe le origini sono conservate; la divergenza è visibile finché una regola o una decisione ne determina l’esito. Nessuna prevalenza implicita viene presentata come dato definitivo. |

### 15.6 Gestione degli allegati durante questa fase

Possiamo progettare relazioni documento–incarico–versione, permessi, revisioni, disponibilità e percorso di recupero usando i metadati. Per gli originali S3 non ricevuti lo stato corretto è **“riferimento presente; contenuto non verificato in questa analisi”**. Non diventano “mancanti in S3” o “persi”, e non si inventano hash verificati.

Restano rinviati: verifica di esistenza presso lo storage, lettura dei contenuti, confronto degli hash e deduplicazione dei file effettivi. Queste attività potranno essere svolte nell’ambiente che ospiterà i documenti, evitando di caricarli tutti qui. La decisione odierna riguarda lo spazio e la fase di lavoro, non la cancellazione della storia documentale.

### 15.7 Primo punto da chiarire con l’uso quotidiano

**Punto chiarito dall’utente:** circa 99 casi DPR su 100 comportano un nuovo contratto a scadenza. Solo casi particolari, come affidamenti pluriennali dei Comuni, seguono un accordo esteso nel tempo. Il confronto prosegue sul modo di preparare il rinnovo e sui prezzi da proporre.

## 16. Contratti DPR a scadenza: prassi e proposta di rinnovo

### 16.1 Requisito dichiarato

L’utente ha precisato: «99 su 100 prepariamo contratti a scadenza», con eccezioni per affidamenti pluriennali dei Comuni. La frequenza è un’indicazione della prassi aziendale, non una statistica calcolata dal dump.

**Conseguenza:** il nuovo sistema deve facilitare la preparazione di un nuovo contratto per il ciclo successivo. Non proponiamo di trasformare tutti i rapporti in accordi continuativi. Il contratto precedente resta storico e può aiutare a predisporre quello nuovo, senza costituire automaticamente l’autorizzazione del nuovo incarico.

### 16.2 Comportamento ordinario proposto

1. Dallo scadenzario si selezionano le prestazioni da rinnovare e si verifica se esiste già un’offerta o un incarico per quel ciclo.
2. Il sistema prepara una bozza con anagrafica corrente, beni e prestazioni pertinenti; mostra le precedenti condizioni come riferimento.
3. Si propone il prezzo secondo le basi tariffarie DPR chiarite nella sezione 17, segnalando differenze e deroghe. Non si confondono il prezzo storico, quello del tariffario e quello nuovamente concordato.
4. Si verificano destinatari, sedi, condizioni e righe; l’invio riguarda la versione identificata del nuovo documento.
5. Accettazione e riesame autorizzano le prestazioni pertinenti; la ripetizione dell’azione non genera incarichi duplicati.

Garda dispone già di generazione dei preventivi dallo scadenzario, con raggruppamento per cliente, possibilità di aggiunta a una bozza e riporto di alcune condizioni precedenti. Il miglioramento non può quindi essere descritto come semplice introduzione di una funzione assente: occorre capire quali correzioni o passaggi manuali restano nell’uso quotidiano. Evidenza: `ingecert/cust/lavori_batch_cli.php`, funzione `gi_scadenze_preventivi_crea`.

### 16.3 Eccezione pluriennale proposta — gestione dedicata rinviabile

**Aggiornamento di priorità:** l’utente conferma che Garda permette di preventivare soltanto la prossima scadenza e non gestisce le successive dell’affidamento pluriennale. Gli affidamenti sono rari e non devono complicare il flusso. Si raccomanda di non introdurre una gestione dedicata nel primo AD_dpr, conservando accordo e riferimenti per la gestione manuale del caso effettivo. Le indicazioni seguenti restano ipotesi per una futura estensione, non una struttura approvata o necessaria prima del codice iniziale.

Un affidamento pluriennale deve avere un riferimento esplicito, durata e prestazioni/bene coperti, condizioni e documentazione di autorizzazione. Il sistema verifica se il nuovo intervento ricade davvero in quell’ambito e mostra l’accordo pertinente. Non basta che il cliente abbia genericamente un contratto ancora valido.

Ogni intervento mantiene il proprio incarico, documenti, controlli e situazione economica. La necessità di un ordine specifico, di ulteriori autorizzazioni o di aggiornamenti del prezzo rimane da verificare sulle condizioni dell’affidamento; non si presume che il pluriennale elimini questi passaggi.

### 16.4 Criteri di accettazione e prossimo chiarimento

- Un impianto con contratto del ciclo precedente resta da rinnovare per il ciclo nuovo, salvo accordo pluriennale effettivamente applicabile.
- La preparazione ripetuta per la medesima esigenza segnala la bozza già esistente invece di crearne una seconda senza avviso.
- Un accordo pluriennale su alcuni impianti non copre automaticamente quelli esclusi o le prestazioni aggiuntive.
- Nuove condizioni e prezzi non modificano il contratto storico.

**Punto chiarito per AD_dpr:** terra e scariche atmosferiche seguono ISPESL 2005; i luoghi con pericolo di esplosione seguono una tariffa oraria. L’utente indica tariffe uguali alle precedenti e la possibilità di sconti, ad esempio nelle gare PA. Il dettaglio e il prossimo chiarimento sono nella sezione 17.

## 17. Prezzi AD_dpr: tariffe e sconti

### 17.1 Regole raccolte dall’utente

| Prestazione | Base di prezzo dichiarata | Implicazione per il rinnovo |
|---|---|---|
| Verifica di terra | Tariffario ISPESL 2005 | Normalmente la stessa base tariffaria del ciclo precedente. |
| Verifica delle scariche atmosferiche | Tariffario ISPESL 2005 | Normalmente la stessa base tariffaria del ciclo precedente. |
| Verifica in luoghi con pericolo di esplosione | Tariffa oraria come base del preventivo | L’importo concordato nel preventivo determina il prezzo della prestazione; nessuna variazione a consuntivo. Le ore eventualmente usate nel calcolo restano distinte da misure di tempo effettivo. |

L’utente segnala inoltre la possibilità, in teoria, di applicare sconti, citando le gare verso la PA. Queste informazioni riguardano AD_dpr; non vengono estese ad AD_dm o I&C.

### 17.2 Comportamento proposto

Il rinnovo propone la tariffa pertinente e permette di confrontarla con quella precedente. Se bene, parametri e condizioni restano gli stessi, il prezzo di base atteso è quello precedente. Eventuali differenze devono avere una spiegazione leggibile, ad esempio parametri tecnici cambiati, diverse ore o condizioni commerciali: non basta copiare indiscriminatamente il totale storico.

Il contratto conserva base tariffaria, parametri o quantità utilizzati, prezzo standard, eventuale sconto e prezzo concordato. Le condizioni pregresse restano nello storico anche quando il nuovo contratto cambia.

Per lo sconto proponiamo di conservare importo o percentuale, motivo e riferimento commerciale pertinente; chi può applicarlo e con quali condizioni è ancora da decidere. La possibilità citata non viene trasformata in uno sconto predefinito sui rinnovi.

### 17.3 Regola di fatturazione chiarita

L’utente precisa che nelle zone ATEX si fa riferimento al preventivo e non vengono applicate variazioni a consuntivo. Il prezzo concordato è quindi il riferimento della prestazione: l’eventuale rilevazione delle ore reali non ricalcola automaticamente l’importo fatturabile. Una modifica dell’oggetto commerciale richiederebbe un fatto esplicito distinto, non un aggiustamento silenzioso dopo l’esecuzione.

Il percorso di generazione fattura Garda esaminato usa già la `tariffa_applicata` della riga preventivo come prezzo unitario e totale netto della prestazione, con quantità di fattura pari a 1. La creazione della verifica copia lo stesso importo in `tariffa_effettiva`. L’osservazione dell’utente chiude pertanto una questione che poteva essere prima circoscritta meglio leggendo questo percorso.

## 18. Riscontro dei prezzi nel codice e metodo di analisi

### 18.1 Regole effettivamente riscontrate

| Percorso | Riscontro sul sorgente | Conseguenza per la progettazione |
|---|---|---|
| Calcolo standard Garda | `calcola_tariffa_standard` calcola la tariffa delle terre BT/AT dalla potenza e dagli scaglioni `tariffe_terre`. Per le altre tipologie restituisce `NULL`; il valore deve essere determinato nel preventivo. | Distinguere tariffario aziendale e automatismi effettivamente disponibili. La base tariffaria dichiarata per scariche e ATEX non implica che Garda ne esegua già il calcolo completo. |
| Sconto Garda | La riga conserva tariffa standard, sconto percentuale e tariffa applicata. La funzione di aggiornamento calcola l’importo scontato. | Recuperare la separazione fra prezzo standard e concordato, con regole di autorizzazione da valutare. |
| Preventivo → verifica Garda | La generazione copia `tariffa_standard` e `tariffa_applicata` della riga nei prezzi della verifica. Nell’interfaccia i prezzi della verifica sono di sola lettura. | Il prezzo commerciale proviene dal preventivo; non viene ricostruito dalle ore di esecuzione. |
| Preventivo → fattura elettronica Garda | La generazione usa `tariffa_applicata` della riga come prezzo unitario e totale netto, con quantità 1, conservando i riferimenti a preventivo e verifica. | Preservare l’importo concordato, coerentemente con la prassi ATEX precisata dall’utente. |
| Preventivo della 0.7.1 | La voce `ESPL-ORE` permette di calcolare il prezzo da tariffa unitaria e quantità; lo sconto è controllato per permesso e abilitazione del cliente. La fatturazione del prototipo non è ancora implementata. | Il calcolo a ore è preparazione del preventivo, non prova dell’esistenza di una fatturazione a consuntivo. Recuperare questi dettagli senza attribuirgli funzioni assenti. |

Riferimenti: `ingecert/cust/_custom.php`, funzioni `calcola_tariffa_standard` e `gi_preventivo_riga_tariffa_applicata_update`; `ingecert/cust/lavori_batch_cli.php`, generazione delle verifiche e delle fatture clienti; `ingecert/cust/meta/verifiche.js`, prezzi di sola lettura; nella 0.7.1, `moduli/tariffario/servizio.py` e `moduli/preventivi/servizio.py`.

### 18.2 Metodo per i prossimi processi

Prima si ricostruiscono dati, automatismi, vincoli e passaggi dai sorgenti. Si annota che cosa è provato dal codice e che cosa dipende dalla pratica aziendale. All’utente si sottopongono quindi inefficienze concrete, conflitti fra fonti o modifiche proposte, chiedendo chiarimenti soltanto dove incidono sul progetto.

Il codice può spiegare un comportamento implementato, ma non dimostra da solo quanto spesso venga usato, quali accordi esterni esistano o quali passaggi siano svolti fuori dal software. Queste sono le informazioni da raccogliere nell’intervista operativa.

## 19. Preventivo DPR: anteprima, correzione, firma e file finale

### 19.1 Comportamento richiesto

L’utente riferisce che il ciclo dei verbali di VerbalizzAI funziona bene: LibreOffice produce subito l’anteprima PDF; se corretta, si firma/finalizza e si invia; se presenta problemi, tipicamente di impaginazione, si scarica il Word, lo si corregge e ricarica, ottenendo automaticamente una nuova anteprima. Il ciclo si ripete finché il documento è corretto. È richiesto lo stesso comportamento per il preventivo DPR.

| Passaggio | Risultato desiderato | Riscontro nella 0.7.1 |
|---|---|---|
| Preparazione | Word compilato dai dati correnti e anteprima PDF via LibreOffice | Già presente nel percorso esaminato. |
| Controllo negativo | Scaricamento del Word e correzione esterna | Già presente; il prototipo ammette ritocchi di impaginazione e confronta il contenuto. |
| Ricaricamento | PDF rigenerato dal Word ricaricato e anteprima riaperta, anche più volte | Già presente. |
| Controllo positivo | Firma/finalizzazione della versione verificata | Presente l’approvazione del PDF; la funzione di firma richiesta va definita e completata. |
| Invio | Invio della versione finalizzata, senza rigenerazione silenziosa | Il prototipo usa il PDF approvato corrente e conserva quello inviato. |
| Download finale | File finale scaricato automaticamente con nome determinato | Presenti nomi automatici e download espliciti; nel percorso di approvazione esaminato non compare un download automatico. |

Queste sono evidenze di lettura del sorgente, non un nuovo collaudo con LibreOffice. La finalizzazione e la firma del mittente non equivalgono all’accettazione del cliente o al riesame del contratto: tali fatti conservano il proprio significato e le proprie evidenze.

### 19.2 Coerenza fra anteprima e documento ufficiale

Il documento finalizzato deve corrispondere alla versione controllata, includendo gli effetti della firma secondo il flusso che sarà scelto. Invio, archivio e download fanno riferimento a quella versione. Se cambiano i dati o viene ricaricato un Word diverso, occorre controllare la nuova anteprima; una precedente approvazione non vale implicitamente per il nuovo documento.

Il prototipo confronta il contenuto del Word ricaricato e ammette soltanto correzioni di impaginazione; per cambiare dati e importi richiede una modifica nel gestionale e una nuova generazione. Questa è una regola osservata nel codice, non un’ulteriore limitazione espressamente richiesta dall’utente. La gestione di eventuali modifiche sostanziali al Word va precisata preservando la coerenza fra documento e dati commerciali.

### 19.3 Nome del file e destinazioni

La 0.7.1 genera già un nome composto da codice del preventivo, revisione se presente e ragione sociale, ripulendo i caratteri incompatibili con i nomi file. Una convenzione proposta per il sistema integrato è:

`AD_DPR_Preventivo_P_001_26_rev00_RagioneSociale.pdf`

È un esempio nel registro dei dettagli rinviati, non una convenzione già approvata o da implementare ora. Il nome deve rendere distinguibili ambito, tipo di documento, numero, revisione e cliente, senza rinominare i file storici originali. L’identità archivistica della versione rimane indipendente dal nome di download.

Sono distinti: nome automatico, evento che avvia il download, archivio applicativo del documento e destinazione della copia scaricata. L’utente rinvia la scelta delle destinazioni; non viene presunta ora una cartella sul PC, sul server o sulla rete aziendale. Il PDF finale è il candidato principale al download; il Word corretto resta collegato come sorgente documentale.

### 19.4 Criteri di accettazione e riuso

- Si può ripetere il ciclo Word–PDF senza ricreare il contratto o il suo numero.
- Il PDF viene rigenerato dal Word ricaricato e mostrato prima della finalizzazione.
- I dati cambiati rendono necessario un nuovo controllo del documento pertinente.
- Firma, invio e download utilizzano la versione ufficiale identificata; l’invio non perde il ritocco di impaginazione.
- Numero e revisione rendono distinguibili i file finali; una nuova revisione conserva quella precedente.
- Il download automatico riguarda il file finalizzato, non una precedente anteprima.

Riferimenti verificati nella 0.7.1: `core/pdf.py`; `moduli/preventivi/api.py`, percorsi `anteprima`, `documenti/ritoccati`, `documenti/{id}/approva` e invio email; `moduli/preventivi/servizio.py`, funzioni `nome_file`, `prepara_ritocco`, `salva_ritocco`, `approva_documento` e selezione del PDF approvato; `static/js/preventivi.js`, ciclo `controlla` e `caricaRitocco`.

## 20. Struttura minima: nucleo comune e primo rilascio DPR

### 20.1 Proposta di architettura

**Progettare ora il nucleo integrato per le tre attività; realizzare e attivare per primo un AD_dpr autonomo nel proprio ciclo operativo, con VerbalizzAI come modulo.** È la proposta sottoposta all’utente, non la dichiarazione di un nuovo sistema già costruito o di tutte le scelte già approvate.

Il primo rilascio deve poter gestire il lavoro DPR senza affidarsi a Garda per i passaggi inclusi nel suo perimetro. Il nucleo comune evita che clienti, beni, autorizzazioni, documenti e dati economici debbano essere riprogettati quando arriveranno DM e I&C. Le regole e le maschere complete degli altri due ambiti saranno sviluppate dopo la validazione DPR.

| Livello | Da predisporre nel progetto comune | Da rendere operativo nel primo rilascio |
|---|---|---|
| Identità e anagrafiche | Soggetti, ruoli del soggetto, sedi, beni e origini; ambito distinto da società emittente | Anagrafiche e impianti DPR; storico e riferimenti verificati della migrazione. |
| Commerciale e operatività | Preventivi e versioni, accordi, prestazioni autorizzate, incarichi; eventuale coordinamento di più prestazioni | Preventivi DPR a scadenza, eccezioni pluriennali, accettazione, riesame, assegnazione e programmazione. |
| Tecnica | Regole per tipologia/prestazione, scadenze con fonti, esiti e correzioni | Regole DPR e VerbalizzAI, numerazione, emissione, revisioni e riesame. |
| Documenti e controllo | Versioni, esportazioni, disponibilità dei contenuti, utenti, permessi e registro | Ciclo documentale richiesto e controllo della versione inviata/scaricata. |
| Economico | Emittenti distinti, importi esatti, destinatario fiscale distinto dal cliente del preventivo, legami fra prestazioni, fatture e incassi | Modulo completo di fatturazione e incassi DPR, richiesto dall’utente. |

La compatibilità con ingecert riguarda dati, storia, numerazione e regole operative utili. Le semplificazioni concordate possono cambiare il modo di lavorare preservando queste informazioni. Il progetto tiene separati i campi tecnici specifici DPR dai concetti condivisi.

La migrazione degli originali S3 resta rinviata per questa fase. L’autonomia del nuovo ciclo operativo non equivale ad avere già recuperato tutto lo storico documentale: il piano di disponibilità dei vecchi originali rimane una verifica distinta prima della chiusura della migrazione.

### 20.2 Cinque domande che incidono sulla struttura

| Rif. | Domanda da sottoporre | Scelta suggerita o conseguenza |
|---|---|---|
| Q1 | Perimetro economico del primo DPR | Risposta acquisita: fatturazione e incassi completi. Le funzioni esistenti vanno censite e coperte nel perimetro operativo. |
| Q2 | Distinzione dei soggetti | DPR chiarito: datore di lavoro/committente e intestatari di preventivo e verbale coincidono nel processo indicato; intestatario terzo soltanto in fatturazione. Responsabilità sui dati comuni e altri ambiti da riscontrare. |
| Q3 | Programmazione comune delle attività | Risposta acquisita: per ora distinta; non realizziamo una pianificazione operativa unificata dei tre ambiti nel primo rilascio. |
| Q4 | Compilazione senza connessione | Decisione acquisita: primo rilascio solo online, senza bozze offline. |
| Q5 | Accettazione, riesame e affidamento | Flusso chiarito: risposta scritta del cliente (preventivo controfirmato o email), poi RC obbligatorio, poi incarico al tecnico. Conservazione pratica dell’evidenza e variazioni di ambito da consolidare. |

Le risposte descrivono l’operatività aziendale e il perimetro desiderato; non vengono inventate dal codice. Le regole già riscontrate, come prezzo ATEX preventivato e generazione degli importi dalla riga commerciale, restano la base acquisita.

Dopo le risposte si chiudono la scheda del primo rilascio, il modello concettuale comune, i controlli e un elenco breve di casi di accettazione. Si verifica quindi quali parti della 0.7.1 sono recuperabili e quali vanno adattate; lo sviluppo segue quel perimetro.

### 20.3 Registro dei dettagli rinviati

| Dettaglio | Stato e momento della decisione |
|---|---|
| Termine visibile “preventivo” | Indicazione dell’utente recepita; testi puntuali dell’interfaccia da uniformare più avanti. |
| Formato dei nomi file | Numero, revisione e identificazione del documento vanno conservati; prefissi, ordine, separatori e abbreviazioni si decidono alla fine. |
| Destinazioni delle copie scaricate | Da definire in seguito; distinte dall’archivio applicativo che conserva la versione ufficiale. |
| Aspetto, etichette dei pulsanti e impaginazione dei modelli | Da rifinire dopo i processi, riutilizzando il ciclo di anteprima e ritocco. |
| Dettagli pratici di firma e download | Da specificare nella progettazione del flusso documentale; il requisito di finalizzazione/versione coerente è già raccolto. |

Questo registro non rinvia requisiti strutturali come identità, ruoli, versioni, fonti delle scadenze o conservazione delle evidenze. Serve a evitare che scelte di presentazione rallentino la definizione del primo sistema praticabile.

## 21. Decisioni sul primo AD_dpr e vincoli del modello

### 21.1 Perimetro economico completo

L’utente richiede fatturazione e incassi completi nel primo rilascio AD_dpr. Non è quindi sufficiente una fase tecnica con fatture ancora gestite in ingecert, né la sola produzione di XML. L’inventario del modulo Garda deve coprire fatture e righe, intestazioni e dati fiscali storicizzati, documenti collegati, produzione XML e relativo percorso operativo, modalità e scadenze di pagamento, registrazione degli incassi e situazione residua, includendo i casi di documento e rettifica effettivamente gestiti.

Nei metadati Garda sono già presenti fatture clienti, righe, dati IVA, documenti collegati, generazione XML, pagamenti, tipi pagamento e scadenze; l’elenco dei tipi documento comprende anche acconti e note di credito. Questo censimento iniziale non equivale ancora alla verifica completa delle funzioni o delle casistiche fiscali.

### 21.2 Intestatario della fattura distinto

**Chiarimento successivo dell’utente:** per il DPR il committente è il datore di lavoro e a lui sono intestati preventivo e verbale. La fatturazione a terzi interviene soltanto in fase di fatturazione. È il comportamento Garda da mantenere, senza introdurre un ruolo di committente distinto prima di quel passaggio (sezione 26).

La proposta iniziale dell’intestatario fiscale proviene dall’intestatario del preventivo, ma può essere modificata per i casi indicati dall’utente. La modifica della fattura non deve riscrivere il preventivo, il bene o i documenti già emessi.

Nel codice Garda `meta/fatture_clienti.js` la scheda “Intestatario fattura” contiene propri campi `cli_rag_soc`, indirizzo, CF, P.IVA e codice destinatario/PEC; la vista `clienti_dec` propone gli stessi dati dall’anagrafica. Il generatore mantiene il collegamento al cliente commerciale del preventivo: tale riferimento non va confuso con i dati di intestazione della fattura.

Il nucleo futuro deve rappresentare questi ruoli e conservare i dati fiscali validi alla singola emissione. Per lo storico migrato si preservano i campi effettivamente presenti, senza assumere che il riferimento anagrafico e l’intestatario fiscale coincidano sempre. L’eventuale identità di proprietario e gestore dell’impianto resta un tema distinto da questo chiarimento.

### 21.3 Programmazione distinta

La programmazione resta distinta per attività nel primo rilascio. Il backend comune può condividere utenti, soggetti e componenti, ma non impone un’unica agenda o un’unica uscita per DPR/DM/I&C. Eventuali raggruppamenti futuri non sono parte del primo requisito operativo.

### 21.4 Accettazione, riesame e affidamento

Flusso richiesto: preventivo creato, inviato, accettato — oppure rifiutato/annullato —; a seguito dell’accettazione riesame obbligatorio; solo dopo un esito che autorizzi il lavoro si affida l’incarico al tecnico. L’utente collega questa regola alle proprie esigenze ISO 17020:2026; qui viene registrata come requisito esplicito del sistema.

Il riscontro Garda è concreto: l’azione “Genera verifiche” in `meta/preventivi_righe.js` richiede riga accettata, impianto non dismesso, tariffa disponibile e riesame del preventivo effettuato con esito conforme. La generazione della verifica assegna il tecnico. Nella 0.7.1 il riesame conforme genera le verifiche da assegnare; l’assegnazione è un passaggio successivo.

**Vincolo di progetto:** l’accettazione da sola non autorizza l’affidamento. Il controllo deve valere nel servizio applicativo, anche per azioni massive o richieste dirette, non soltanto nella visibilità di un pulsante. Si registrano autore, data, esito e riferimento al preventivo/condizioni riesaminati. Un riesame pendente o non conforme mantiene un impedimento esplicito all’affidamento.

L’approvazione dell’anteprima del PDF, la finalizzazione del preventivo, l’accettazione del cliente e il riesame contrattuale sono quattro fatti distinti. Il successivo chiarimento dell’utente richiede evidenza scritta di accettazione: preventivo controfirmato o almeno email di conferma (R38). Conservazione pratica dell’evidenza ed effetti delle revisioni sostanziali rimangono da consolidare.

### 21.5 Modalità online scelta

Dopo il confronto infrastrutturale, l’utente sceglie la soluzione più semplice: nessuna bozza offline al momento. Il browser accede al sistema centrale e i salvataggi applicativi arrivano al server. Anche conversione PDF con LibreOffice, gestione delle versioni, finalizzazione e invio rimangono nel sistema centrale.

Non sono inclusi nel primo rilascio un database operativo sul dispositivo, una coda di modifiche offline o la sincronizzazione dei client. L’eventuale futura funzione offline rimane un progetto separato: la scelta attuale non impone di realizzare ora una PWA o un’applicazione locale.

## 22. Scheda del primo AD_dpr e nucleo concettuale proposto

### 22.1 Perimetro raccolto

Il primo sistema comprende il ciclo DPR: anagrafiche e impianti, scadenze, preventivi e relativa preparazione documentale, accettazione, riesame contrattuale obbligatorio prima dell’affidamento, assegnazione e programmazione DPR, verbalizzazione con VerbalizzAI, revisioni e riesame, documenti/invii, fatturazione e incassi completi.

L’uso è online. La programmazione resta distinta dagli altri ambiti. Gli originali S3 non sono richiesti in questa fase. L’architettura proposta è un nucleo integrato con attivazione iniziale DPR: la scelta del perimetro operativo non equivale a un’approvazione puntuale di tutto il futuro schema tecnico.

### 22.2 Struttura dei concetti da verificare prima dello schema fisico

| Concetto | Responsabilità | Relazione essenziale |
|---|---|---|
| Soggetto e sede | Identità e contatti correnti, riferimenti sorgente verificati | L’intestatario del preventivo e quello fiscale della fattura possono essere diversi. |
| Bene e prestazione/ciclo | Identificare che cosa va controllato e quale esigenza è aperta | Uno stesso impianto può avere prestazioni o cicli diversi; la sola presenza di un’offerta sul bene non basta. |
| Preventivo e righe | Condizioni proposte, prezzi, versione ed esito commerciale | Le righe individuano le prestazioni; il documento finalizzato e l’accettazione restano fatti distinti. |
| Riesame del contratto | Autore, data, esito e condizioni riesaminate | L’accettazione precede il riesame; l’esito autorizzante precede l’affidamento al tecnico. |
| Incarico/verifica | Da assegnare, assegnata, programmata (facoltativa), registrata, eseguita, sospesa, annullata | Flusso chiarito dall’utente: registrata in occasione dell’esecuzione; eseguita solo con verbale finalizzato e caricato nel gestionale. Sospesa è l’aggiunta richiesta per impossibilità di eseguire la verifica; transizioni e ripresa da consolidare. |
| Verbale e stato tecnico | Snapshot della verifica, versioni, esito e correzioni | Lo storico emesso non viene riscritto da un aggiornamento dell’anagrafica; il campione non sostituisce l’inventario. |
| Riesame del verbale | Controllo della versione pertinente e eventuale richiesta di correzione | Revisione documentale ed eventuale nuovo intervento sono distinti. |
| Fattura, pagamenti e incassi | Intestazione fiscale storicizzata, importi, collegamenti e situazione economica | L’intestatario fiscale è modificabile nella fattura; la modifica non riscrive il preventivo. |
| Documenti, esportazioni ed eventi | Contenuti, versioni, disponibilità e traccia delle operazioni | Invio e download identificano il documento ufficiale pertinente. |

La tabella è il modello concettuale proposto, non l’elenco definitivo delle tabelle. Gli elementi comuni avranno riferimenti stabili; i dettagli tecnici di terra, scariche e ATEX restano nel modulo DPR, senza trasformarli in campi obbligatori per DM o I&C.

### 22.3 Risultato della fase e approfondimenti successivi

Il confronto mirato con i servizi Garda e il prototipo 0.7.1 ha prodotto la mappa di stati, azioni consentite, ruoli, prerequisiti ed effetti nella sezione 23. I casi prioritari sono: riga accettata senza riesame; riesame non conforme; tentativo di assegnazione anticipata; creazione ripetuta dello stesso incarico; intestatario fattura diverso; accettazione parziale; revisione del preventivo; riesame del verbale negativo; storici già fatturati e incassi parziali.

Rimangono da approfondire le evidenze concrete dell’accettazione, il ciclo completo fatture/pagamenti e le regole specifiche non ancora censite. Non si aprono nuove domande su naming, cartelle o impaginazione: sono nel registro dei dettagli rinviati. Il passo successivo resta concettuale e precede modifiche applicative.

## 23. Mappa operativa DPR: stati, controlli ed effetti

**Stato:** analisi mirata dei sorgenti e proposta concettuale. Non sono stati modificati i servizi applicativi né eseguiti nuovi test del prototipo. I casi descritti sotto sono criteri per il futuro collaudo, non prove già superate. I requisiti espliciti dell’utente restano distinti dalle scelte qui suggerite.

### 23.1 Stati distinti per evitare ambiguità

| Oggetto o fatto | Stati proposti | Significato |
|---|---|---|
| Preventivo commerciale | Creato, inviato, accettato parzialmente/totalmente, rifiutato, annullato, sostituito | Il riepilogo deriva anche dalle righe. L’accettazione riguarda condizioni e prestazioni identificabili. |
| Riesame del contratto (RC) | Da fare, conforme, non conforme; eventuale nuovo riesame necessario | Autorizza le prestazioni accettate coperte da quella valutazione. Non è l’accettazione del cliente. |
| Incarico/verifica | Da assegnare, assegnata, programmata, registrata, eseguita, annullata | Avanzamento del lavoro. La programmazione può restare facoltativa, come nella 0.7.1, senza saltare i prerequisiti dell’esecuzione. |
| Verbale e riesame del verbale (RV) | Documento in bozza/emesso/annullato; RV da fare/conforme/da correggere | Il riesame riguarda una precisa versione emessa. Una correzione documentale non cancella il fatto che l’intervento è avvenuto. |
| Consegna | Nessun invio, tentativo fallito, invio riuscito, eventuale nuova consegna | Eventi con destinatari, versione/hash e data; un invio riuscito non prova la lettura del cliente. |
| Fatturazione e incassi | Situazione economica distinta dal lavoro tecnico | Prestazione da fatturare/fatturata o rettificata; credito aperto/parzialmente incassato/saldato derivato dai movimenti pertinenti. Il ciclo fiscale dettagliato è ancora da censire. |

**Distinzione essenziale:** un esito tecnico negativo dell’impianto e un riesame non conforme del verbale sono cose diverse. Un documento corretto che descrive un impianto non conforme può avere RV conforme; non si blocca la fatturazione soltanto perché l’esito tecnico è negativo.

La 0.7.1 usa anche lo stato unico “riesaminata” e riporta a “registrata” dopo RV negativo. L’utente conferma il ritorno a registrata: il verificatore deve ripetere l’attività e/o correggere il verbale, ricaricarlo e riportare la verifica a eseguita prima del nuovo RV. **Eseguita richiede il verbale finalizzato e caricato**, non soltanto l’uscita fisica. Il fatto che l’intervento sia avvenuto, le note del RT, i documenti e tutti i riesami rimangono conservati nello storico. Non si mantiene eseguita una verifica con RV negativo.

### 23.2 Azioni e condizioni del primo ciclo operativo

I ruoli nella tabella sono una base ricavata dalla 0.7.1: segreteria per le azioni commerciali, RT per assegnazione/RV, tecnico assegnato per l’esecuzione; RC disponibile a RT e segreteria con il relativo permesso. La futura matrice delle deleghe aziendali resta configurabile per ambito. Ogni azione registra autore, data e oggetto/versione pertinenti.

| Azione | Operatore di riferimento | Prerequisiti proposti | Effetto |
|---|---|---|---|
| Creare/modificare preventivo | Segreteria autorizzata | Prestazioni identificate; condizioni e prezzi pertinenti; nessuna modifica silenziosa a condizioni già inviate/accettate | Bozza e righe, con versione. Prezzo ATEX concordato, senza conguaglio a consuntivo. |
| Preparare/finalizzare documento | Operatore documentale | Word e PDF coerenti con la versione; anteprima, eventuale ritocco e nuova conversione | Conservazione delle generazioni; finalizzazione e firma secondo il flusso richiesto, dettagli da completare. |
| Inviare o registrare consegna esterna | Segreteria autorizzata | Documento corrente finalizzato; destinatari e canale identificati | Evento di consegna sulla versione pertinente. Un errore di invio non equivale a preventivo inviato. |
| Registrare accettazione/rifiuto | Segreteria autorizzata | Preventivo effettivamente inviato/consegnato; righe e versione riconoscibili; riferimento/evidenza della risposta | Esito per riga e riepilogo commerciale; nessun affidamento automatico prima del RC. |
| Effettuare RC | Operatore autorizzato al RC | Accettazione delle prestazioni interessate; condizioni riesaminate; punti di controllo e motivazione se negativo | Esito conservato, con ambito coperto. Solo il conforme autorizza le prestazioni pertinenti. |
| Creare incarichi | Sistema a seguito di RC conforme | Riga accettata, RC conforme valido per l’offerta/versione invariata, comprensivo delle righe già offerte anche se accettate successivamente; bene attivo; nessun incarico attivo duplicato per lo stesso ciclo | Incarichi da assegnare. Ripetere l’azione non duplica il lavoro. |
| Assegnare/riassegnare | RT autorizzato | Autorizzazione commerciale ancora valida; tecnico attivo e idoneo alla prestazione; incarico non concluso | Assegnazione tracciata. Una dichiarazione personale del precedente tecnico non vale per il nuovo. |
| Dichiarazione d’indipendenza | Tecnico incaricato | Incarico e tecnico identificati | R63: casella preselezionata come in Garda, escludibile dal tecnico. Se esclusa, il tecnico non può procedere con la verifica. Tracciare le modifiche; il solo default non va registrato come una distinta conferma personale. |
| Programmare | Tecnico assegnato/RT autorizzato | Incarico autorizzato e prerequisiti personali soddisfatti | Data e assegnazione DPR; nessun obbligo di agenda condivisa con DM/I&C. |
| Registrare verifica e numero | Tecnico assegnato/RT autorizzato | Assegnazione valida, indipendenza, data; anche senza precedente programmazione | Numero completo riservato in modo atomico; numero annullato non riutilizzato. |
| Emettere verbale | Tecnico assegnato/operatore autorizzato | Incarico registrato, numero/modulo/dati coerenti; anteprima e finalizzazione secondo VerbalizzAI | Versione ufficiale e dati tecnici collegati; stato eseguita solo dopo finalizzazione e caricamento nel gestionale, come chiarito dall’utente; RV da fare. Stato della scadenza proposto nella sezione 23.5. |
| Effettuare RV | RT autorizzato | Versione ufficiale identificata; valutazione e motivazione se negativa | Conforme oppure negativo con ritorno a registrata. Nota RT visibile al verificatore; esito, autore, data/ora, nota e versione esaminata conservati nello storico. |
| Correggere/riemettere | Operatore autorizzato | Motivo, versione precedente e distinzione fra correzione documentale e nuovo intervento | Ripetizione dell’attività se richiesta e/o correzione documentale; verbale finalizzato e ricaricato, verifica a eseguita e nuovo RV da fare. Documenti e riesami precedenti conservati; il vecchio RV non approva il nuovo contenuto. |
| Consegnare verbale | Operatore autorizzato | PDF definitivo identificato e controllato; proposta ordinaria dopo RV/approvazione RT, oppure rilascio immediato autorizzato alle condizioni della sezione 24 | Invio/consegna tracciati della versione corretta; possibilità di reinvio senza nuova emissione; eccezione con RV successivo obbligatorio. |
| Generare fattura dalla prestazione | Operatore amministrativo | Prestazione pertinente e RV conforme, secondo la regola Garda riscontrata; controllo contro doppia fatturazione ordinaria | Fattura e collegamenti alle prestazioni; intestatario fiscale proposto dal preventivo ma modificabile, con dati storicizzati. |
| Registrare incasso/rettifica | Operatore amministrativo | Documento/credito identificato; importo, data e riferimento; permesso pertinente | Movimenti ed eventuali imputazioni, saldo derivato e storia conservata. Non basta sostituire il totale o spuntare “saldato”. |
| Annullare preventivo/incarico | Operatore autorizzato | Motivo e verifica degli effetti sui lavori/documenti già presenti | Blocco coerente dei passaggi successivi e storia preservata; lavori già eseguiti o fatturati richiedono una gestione esplicita, non una cancellazione a cascata. |

La riga “generare fattura dalla prestazione” descrive il ciclo ordinario delle verifiche. Acconti, note di credito e altri documenti economici già previsti da Garda richiedono le proprie regole: non si impone loro indiscriminatamente il completamento di una verifica.

### 23.3 Controlli da rafforzare rispetto ai sorgenti

| Riscontro concreto | Comportamento proposto |
|---|---|
| 0.7.1, `preventivi.servizio.stato_righe`: blocca annullati/sostituiti, ma non richiede lo stato inviato per accettare | Applicare il flusso richiesto: consegna prima dell’accettazione. È già disponibile `segna_inviato` per registrare una consegna esterna. |
| 0.7.1: RC conforme crea incarichi; un successivo RC negativo o l’annullamento del preventivo non aggiornano gli incarichi esistenti. `verifiche.servizio.assegna` non rilegge RC/stato del preventivo | Ricontrollare l’autorizzazione al momento dell’assegnazione e dei passaggi successivi. Registrare un blocco esplicito sugli incarichi ancora aperti, senza cancellarne la storia. |
| 0.7.1: accettare un’altra riga dopo il RC non crea il relativo incarico; `crea_da_preventivo` viene richiamato dal RC conforme | Requisito acquisito: il RC copre l’intera offerta invariata. Per la riga già offerta e accettata successivamente, consentire la generazione del relativo incarico usando il RC conforme valido, senza obbligare a ripeterlo; rispettare l’accettazione scritta e impedire duplicati. Non si introduce un riesame per riga. |
| 0.7.1: una verifica già presente sulla riga, anche annullata, impedisce la nuova creazione; il modello ha una riga univoca | Distinguere idempotenza da riapertura. Il recupero di un incarico annullato richiede un’azione motivata o una nuova autorizzazione/ciclo, mantenendo il vecchio riferimento. |
| Garda controlla `dichiaro_che` prima di programmare/registrare/effettuare; nei metadati il campo ha però default vero. Nel prototipo manca l’evidenza strutturata equivalente | Dichiarazione personale esplicita per incarico, conservata con autore/data; nessuna conferma automatica. |
| 0.7.1 sceglie i verificatori fra utenti attivi con permesso di eseguire verifiche | Distinguere permesso applicativo e idoneità alla prestazione. Qualifiche, ambiti e loro validità vanno modellati secondo le procedure effettive. |
| 0.7.1 blocca modulo/numero errati nel Word, ma data diversa, tipo VP/VS diverso ed esito non letto producono avvisi e la verifica diventa eseguita | Non finalizzare automaticamente dati essenziali discordanti o mancanti. Richiedere correzione o una risoluzione esplicita e tracciata da chi è autorizzato. |
| 0.7.1: RV negativo riporta a registrata; i dati dell’impianto erano già aggiornati al caricamento e `riesame` non li ricalcola | Conservare la decisione DPR di aggiornare la scadenza prima del RV, con fonte e versione identificabili; RV negativo riporta a registrata e la revisione emessa pertinente aggiorna il dato. Non introdurre un’attesa automatica del RV per ricalcolare la scadenza. Le caratteristiche tecniche correnti seguono la regola da chiarire in D03. |
| 0.7.1: il ponte permette l’invio VerbalizzAI con `verifiche.esegui`, e la funzione email non consulta il RV del gestionale | Applicare nel servizio centrale la politica di consegna: RV/approvazione per il percorso ordinario, autorizzazione specifica e condizioni per il rilascio immediato proposto nella sezione 24. |
| Garda contiene pagamenti con scadenza/importo e indicatore `saldato`; il codice fiscale genera rate e ricalcola le quote residue tenendo conto dei movimenti saldati; la fatturazione della 0.7.1 è ancora segnalata come funzione non attiva | Conservare e collaudare le funzioni esistenti di rate e residui, senza reinventarle. La presenza nel codice non dimostra una riconciliazione bancaria automatica; per importo effettivo, data e associazioni degli incassi resta necessaria una rappresentazione verificabile. |

Sono riscontri statici del flusso dei servizi esaminati. Le condizioni dei pulsanti Garda attestano le regole dichiarate nell’interfaccia; da sole non dimostrano che ogni percorso di scrittura le faccia rispettare.

### 23.4 Criteri di accettazione da trasformare in collaudo

| Caso | Risultato atteso della proposta |
|---|---|
| Preventivo creato ma non consegnato; tentativo di accettazione | Rifiuto dell’azione; resta possibile registrare prima una consegna esterna reale. |
| Riga accettata, RC pendente/negativo; assegnazione anche massiva | Nessun affidamento. Il controllo vale sul server e non soltanto sui pulsanti. |
| RC conforme, poi nuovo RC negativo oppure preventivo annullato | Gli incarichi aperti non proseguono usando la vecchia autorizzazione; blocco e motivazione visibili. |
| Due righe: prima accettata e riesaminata, seconda accettata più tardi | Prima coperta dal proprio RC; seconda non assegnabile finché non coperta. Ripetere la creazione non duplica gli incarichi. |
| Riassegnazione a un altro tecnico | La vecchia dichiarazione personale non viene attribuita al nuovo tecnico; registrazioni e motivi precedenti restano. |
| Due registrazioni concorrenti | Numeri distinti nello stesso ambito/anno; preservata la convenzione e la serie effettivamente adottata. |
| Verbale con numero/modulo errato oppure data/tipo/esito discordanti | Nessuna emissione automatica incoerente; errore o risoluzione autorizzata registrata secondo il campo interessato. |
| RV negativo, correzione e nuova emissione | Verifica a registrata; nota RT visibile. Dopo intervento/correzione, finalizzazione e ricaricamento: eseguita con nuovo RV da fare. Tutti i documenti e riesami precedenti consultabili, ciascuno riferito alla versione esaminata. |
| Impianto con esito tecnico negativo, verbale corretto e RV conforme | I due esiti restano distinti; il solo esito tecnico negativo non impedisce la fatturazione. |
| Intestatario fiscale diverso dal cliente del preventivo | Fattura correttamente intestata; preventivo, anagrafica tecnica e documenti precedenti non riscritti. |
| Storico già fatturato; nuova importazione degli stessi riferimenti | Nessuna nuova voce ordinaria da fatturare e nessuna duplicazione di fatture/incassi. |
| Fattura da 1.000 €, incassi da 300 € e 200 € | Residuo 500 €, movimenti distinti e tracciati; l’ultimo incasso non sostituisce il precedente. |
| Invio fallito, poi reinvio riuscito | Due eventi sul documento pertinente; il primo non segna consegna riuscita. |

### 23.5 Decisioni da affrontare in ordine

**Riesame e consegna: chiarimento successivo nella sezione 24.** L’utente conferma il percorso attuale RV–consegna–fattura e segnala l’eccezione del rilascio immediato. Il riscontro RG-01-04 porta alla proposta di due percorsi, con quello differito ordinario e quello immediato subordinato alle condizioni e all’autorizzazione specifica. L’utente conferma successivamente per ora l’invio dopo riesame nel primo DPR; l’opzione immediata viene rinviata (sezione 28.15). Il RC prima dell’affidamento rimane obbligatorio in entrambi.

**Scadenza DPR: momento di aggiornamento chiarito nella sezione 28.** L’utente conferma l’aggiornamento alla verifica effettuata/emissione, senza attendere RV conforme. Una revisione emessa con modifiche dei dati pertinenti aggiorna la scadenza; una correzione grafica non la cambia. La proposta precedente di attendere il RV è superata. Restano da consolidare gli effetti dei casi straordinari, degli annullamenti e dei conflitti tra fonti.

**Successivamente, ciclo economico completo.** Prima dello schema definitivo va censito il percorso effettivo di fatture ordinarie, acconti/rettifiche, XML e invio/esiti, rate, incassi parziali, residui e storni. La prima versione DPR deve coprirlo: questa mappa non chiude ancora la specifica fiscale e contabile. Naming, cartelle, etichette e impaginazione restano nel registro dei dettagli rinviati.

### 23.6 Riferimenti dei riscontri di questa fase

- Garda ingecert: `cust/meta/preventivi_righe.js` (condizioni per generare verifiche/fatture); `cust/meta/verifiche.js` e `cust/_custom.php` (dichiarazione, transizioni e RV negativo); `cust/meta/fatture_clienti.js` e `cust/meta/pagamenti.js` (intestazione fiscale, tipi documento, scadenze e indicatore saldato).
- Gestionale_AD 0.7.1: `gestionale/moduli/preventivi/servizio.py` (`stato_righe`, `segna_inviato`, `annulla`, `riesame`); `gestionale/moduli/verifiche/servizio.py` (`crea_da_preventivo`, `verificatori`, `assegna`, `registra`, `carica_verbale`, `riesame`); relative API per i permessi.
- Ponte documentale: `gestionale/moduli/verbali/archivio.py` (`PERMESSI`), `gestionale/moduli/verbali/api.py`, `gestionale/terzi/verbalizzai/app.py` (`mail_prepare`, `mail_send`); `gestionale/core/permessi.py` (ruoli proposti e funzioni economiche non attive).

## 24. Rilascio del verbale: percorso ordinario ed eccezione immediata

### 24.1 Prassi dichiarata e riscontro del regolamento

L’utente precisa il flusso attuale: verbalizzazione, riesame, invio del verbale, quindi fatturazione. La consegna presso il cliente potrebbe essere più frequente in AD_dpr; è rara in AD_dm e praticamente impossibile nella prassi I&C S.r.l. descritta. Queste sono indicazioni operative dell’utente, non misurazioni sui dump.

Sono stati consultati i testi ufficiali Accredia:
- [RG-01-04 rev.03, §2.7, pagina 17](https://www.accredia.it/wp-content/uploads/2025/06/RG-01-04_rev.03.pdf), in vigore dal 16 giugno 2025;
- [RG-01-04 rev.04, §2.5, pagina 17](https://accredia.it/wp-content/uploads/2026/05/RG-01-04rev.04.pdf), in vigore dal 1° novembre 2026.

Entrambe le revisioni prevedono l’indicazione dell’ispettore e del RT sui rapporti, con la possibilità della sola firma dell’ispettore quando il percorso ordinario non è concretamente praticabile, senza attività prolungata con più ispettori, e con ispettore qualificato ed esplicitamente autorizzato. Il rilascio presso il cliente subito dopo l’ispezione è un esempio riportato. La rev.04 esplicita inoltre il successivo riesame e l’approvazione del RT.

L’eccezione non coincide quindi con una generica email inviata rapidamente dopo la generazione del PDF. Occorre una modalità di rilascio pertinente, autorizzazione del personale ed evidenza delle condizioni applicabili. Le regole dell’OdI AD non vengono automaticamente estese a tutte le prestazioni di I&C S.r.l.

### 24.2 Proposta di progetto

**Predisporre entrambi i percorsi nel modello comune; usare il percorso dopo riesame come modalità ordinaria.** Per ora il primo AD_dpr mantiene l’invio dopo riesame, secondo la risposta successiva dell’utente (sezione 28.15). Il rilascio immediato rimane un’estensione futura da attivare e collaudare successivamente.

| Aspetto | Percorso ordinario | Rilascio immediato controllato |
|---|---|---|
| Sequenza | Preparazione/firma ispettore, RV e approvazione RT, consegna, fatturazione | Preparazione/firma ispettore e rilascio, RV e approvazione RT successivi, fatturazione |
| Autorizzazione alla consegna | Versione approvata dal RT | Ispettore qualificato e specificamente autorizzato; condizioni dell’eccezione soddisfatte |
| Evidenze | Versione approvata, approvatore e momento di approvazione, consegna | Versione effettivamente rilasciata, autore, momento/canale/destinatario, modalità e autorizzazione, RV ancora dovuto |
| RV negativo | Documento trattenuto e da correggere prima della consegna | Documento già consegnato; correzione gestita con comunicazione e nuova versione se necessarie |
| Economico | RV conforme abilita il normale ciclo fattura | Rilascio immediato da solo non abilita la fattura; si mantiene il controllo dopo RV |
| Utilizzo suggerito | Default DPR/DM; per I&C il controllo interno pertinente alle sue prestazioni | Opzione DPR, eventuale DM nei casi ammessi; nessuna attivazione I&C presunta |

Il progetto mantiene **un percorso ordinario e una sola opzione di rilascio immediato DPR**, utilizzabile dai tecnici specificamente autorizzati nei casi ammessi. La consegna registra la modalità adottata e i normali dati dell’evento. Il controllo usa ambito, autorizzazione e condizioni pertinenti; la prima versione non richiede un motore generale di workflow o una matrice di eccezioni configurabile. L’eventuale estensione DM si valuta quando quel modulo viene attivato.

RV e approvazione del RT devono riferirsi alla versione pertinente. Per il percorso ordinario va assicurata anche l’indicazione del RT sul rapporto secondo la procedura/modello adottati: il solo stato “riesaminato” in una griglia non sostituisce l’analisi di quel requisito documentale. La verifica dei modelli e dell’evidenza di approvazione è ancora da svolgere.

### 24.3 Compatibilità con la scelta online e uso del tablet

Il tablet può usare il browser collegato al sistema centrale: salvataggio, numerazione, conversione LibreOffice, anteprima, finalizzazione e invio rimangono sul server. Si conserva la scelta già acquisita di nessuna bozza offline.

La consegna immediata può avvenire per email mentre il tecnico è presso il cliente; una stampa sul posto non è un requisito acquisito. La ricevuta della trasmissione e l’eventuale evidenza di consegna al referente restano fatti distinguibili.

Prima dell’attivazione occorre provare in campo la compilazione, l’anteprima/firma e la consegna sul dispositivo effettivo, oltre alla disponibilità di connessione. Se manca la connessione o servono ritocchi Word non pratici sul tablet, si completa il ciclo centrale e si usa la consegna differita dopo RV. Non viene promessa ora la piena usabilità del pacchetto VerbalizzAI attuale su tablet.

### 24.4 Gestione della consegna prima del riesame

Proposta: ogni rilascio immediato alimenta una lista di documenti già consegnati e ancora da riesaminare, con responsabile, tempo trascorso e termine aziendale da stabilire. Il regolamento consultato non viene usato per inventare un numero di giorni. L’eccezione non deve far sparire il controllo dalla lista di lavoro.

Se il RV è negativo, si conserva il PDF consegnato e si distingue:
- correzione del documento con eventuale nuova versione e comunicazione al cliente;
- errore o insufficienza della verifica che richiede una decisione tecnica ed eventualmente un nuovo intervento.

Nessuna sostituzione silenziosa del documento già rilasciato. Anche un problema soltanto grafico richiede di identificare quale versione è stata effettivamente consegnata. Il processo per comunicazione, rettifica/sostituzione e gestione delle scadenze dovrà essere coerente con le procedure aziendali.

### 24.5 Fatturazione e risultato della fase

L’invio differito può rendere disponibili insieme verbale e attività di fatturazione dopo il RV. Si propone una funzione coordinata, senza rendere obbligatoria la simultaneità: consegna tecnica e fattura rimangono eventi distinti, utili anche quando una fattura raggruppa più prestazioni o segue condizioni commerciali particolari.

Il vincolo di fatturazione dopo RV per il ciclo ordinario deriva dal comportamento Garda riscontrato e dalla prassi aziendale dichiarata; non è attribuito come prescrizione fiscale a RG-01-04. Acconti e rettifiche mantengono il proprio percorso.

**Risultato:** la vecchia proposta di blocco universale prima della consegna è sostituita da un percorso ordinario e un’eccezione controllata nel modello. Sono ancora proposte, non implementazioni né attivazioni approvate. Il primo rilascio può usare soltanto il percorso ordinario senza perdere la futura possibilità del rilascio in campo. Il successivo vincolo di semplicità dell’utente è recepito nella sezione 24.6.

### 24.6 Vincolo esplicito di semplicità

L’utente chiede di non complicare enormemente il flusso e la logica del gestionale. Questo diventa un criterio di progettazione del primo rilascio, insieme ai requisiti funzionali già acquisiti.

**Esperienza operativa proposta:**
1. Il tecnico compila, controlla l’anteprima, firma ed emette.
2. Il RT trova il verbale da riesaminare e approva oppure chiede la correzione.
3. La segreteria consegna e avvia la fatturazione dalla stessa pratica.
4. Nel DPR, se abilitata e applicabile, l’opzione “Rilascia subito” anticipa la consegna; il verbale rimane nella normale lista del RT da riesaminare. La fatturazione ordinaria si abilita dopo il RV.

L’opzione immediata riusa gli stessi incarico, verbale, riesame e consegna; non crea un secondo processo da amministrare. Il criterio di autorizzazione specifica resta necessario, ma non impone una nuova approvazione manuale del RT per ogni rilascio se il tecnico è già autorizzato e il caso soddisfa le condizioni previste.

**Criteri per l’interfaccia e la logica:**
- Un contesto di pratica, con prossima azione disponibile e motivazione breve se è bloccata.
- Stati riepilogativi calcolati dai fatti registrati; l’operatore compie azioni, non aggiorna a mano più stati separati.
- Dati già presenti riutilizzati, numerazione/scadenze/saldi derivati; richieste ulteriori solo quando manca un’informazione necessaria.
- Liste operative del tecnico, RT e segreteria ottenute dagli stessi dati, senza registri paralleli da compilare.
- Distinzione fra firma/anteprima, RC, RV, consegna e fattura conservata internamente, con visibilità proporzionata al ruolo.
- Gli effetti ordinari sono automatici; ragioni e interventi manuali concentrati su rifiuti, annullamenti, correzioni e altre eccezioni reali.

La mappa dettagliata della sezione 23 descrive le regole da rispettare e i casi di verifica. Non corrisponde a un obbligo di presentare un pulsante, una schermata o un adempimento manuale per ogni riga. La semplicità del ciclo normale va provata insieme alla correttezza dei controlli.

## 25. Decisioni prima del codice iniziale

### 25.1 Perimetro già acquisito

Si lavora su un nucleo comune alle tre attività, con avvio operativo DPR e successiva attivazione DM/I&C dopo validazione. Il primo DPR comprende VerbalizzAI, fatturazione e incassi completi. Uso online, programmazione distinta per attività, soggetti emittenti AD e I&C S.r.l. distinti.

Sono acquisiti: preventivo normalmente nuovo per ogni ciclo; base ISPESL 2005 per terra/scariche e preventivazione oraria ATEX, senza conguaglio a consuntivo; destinatario fiscale della fattura modificabile rispetto al cliente del preventivo; accettazione prima del RC obbligatorio e affidamento soltanto dopo RC conforme; preparazione documentale con anteprima PDF e ritocco Word; percorso ordinario RV–consegna–fattura; semplicità e assenza di registri operativi duplicati. Il modello contempla l’eccezione di rilascio immediato descritta nella sezione 24, la cui attivazione iniziale resta da scegliere.

Questi punti non vengono sottoposti di nuovo come domande aperte.

### 25.2 Elenco unico dei punti strutturali da chiudere

Le proposte sono basi di discussione, non nuove decisioni dell’utente. Ogni punto deve produrre una regola breve, un caso normale e le eccezioni che incidono sul modello. Il censimento delle funzioni già esistenti rimane compito dell’analisi dei sorgenti.

| Rif. | Decisione effettiva | Proposta semplice da validare e risultato atteso |
|---|---|---|
| D01 | **Ruoli dei soggetti:** chiarito il ciclo DPR; acquisita la conservazione delle intestazioni nei documenti emessi; permessi di modifica configurabili; subentro DPR chiarito | DPR: datore di lavoro/committente, preventivo e verbale mantengono lo stesso intestatario; il terzo si sceglie soltanto in fattura. L’aggiornamento dell’anagrafica non riscrive emessi o loro ristampe. Subentro DPR chiarito: nuovo cliente, stesso impianto fisico e passaggio tracciato. Le responsabilità di modifica si configurano tramite ruoli e permessi. |
| D02 | **Identità e relazioni dei beni:** distinguere impianto DPR, attrezzatura DM, valvola tarata e oggetto CND; più prestazioni e scadenze sullo stesso bene | Conservare la distinzione Garda dei beni. Acquisiti: subentro DPR sullo stesso impianto con passaggio tracciato; abbinamento valvola–attrezzatura corrente modificabile manualmente, senza storico montaggi aggiuntivo. Storico tarature/documenti conservato. Restano gli altri casi condivisi da riscontrare. |
| D03 | **Proprietà dei dati fra nucleo e VerbalizzAI:** chi modifica anagrafiche, caratteristiche tecniche, inventario e profili; quando un verbale aggiorna il dato corrente | Anagrafiche nel nucleo; VerbalizzAI gestisce la compilazione tecnica. Un flusso esplicito aggiorna i dati correnti senza riscrivere gli emessi; campioni e inventario restano distinti. Definire il mapping con l’archivio reale e le versioni. |
| D04 | **Prerequisiti dell’incarico consolidati:** ruoli configurabili, filtro delle qualifiche escluso e dichiarazione d’indipendenza come in Garda | R62: con quattro tecnici abilitati niente matrice o filtro dedicato. R63: dichiarazione preselezionata ed escludibile dal tecnico; se esclusa impedisce lo svolgimento da parte di quel tecnico. Conservare il collegamento all’assegnazione e le modifiche senza inventare una conferma distinta per il solo default. Mapping, controlli sul server e riassegnazione sono lavoro tecnico da verificare. |
| D05 | **Scadenze e dato tecnico corrente:** momento di aggiornamento DPR chiarito; straordinaria con preventivo/incarico distinto chiarita; VS senza ricalcolo automatico della scadenza confermata; dismissione senza annullamento automatico degli incarichi chiarita; restano casi residui di annullamento e conflitti fra fonti | DPR: aggiornamento alla verifica effettuata/emissione, senza attendere RV conforme; revisione emessa con dati pertinenti modificati aggiorna la scadenza. Conservare fonte/motivo; nessuna prevalenza automatica cieca fra dump. Ritocco grafico senza effetto sulla data. VS senza nuovo ciclo periodico automatico: conservare la scadenza periodica esistente. |
| D06 | **Accettazione, modifiche e RC:** evidenza scritta, integrativi, accettazione parziale e RC su tutta l’offerta invariata acquisiti | Preventivo controfirmato oppure email di conferma; niente accettazione telefonica. Il contenuto commerciale accettato resta invariato: per l’aggiunta si crea un nuovo preventivo integrativo, con accettazione scritta e RC prima dell’affidamento. Conservare versione, prestazioni ed evidenze pertinenti. Accettazione parziale per righe confermata; il RC copre tutta l’offerta invariata, comprese le righe già offerte e accettate successivamente. Non occorre un nuovo RC per questa sola ulteriore accettazione. |
| D07 | **Affidamenti pluriennali:** lacuna Garda acquisita, caso raro; gestione dedicata raccomandata fuori dal primo MVP | Garda permette di preventivare la prossima scadenza, non quelle successive dell’affidamento (riscontro dell’utente). Evitare un nuovo modello e automatismi contrattuali ora; conservare accordo e riferimenti e trattare manualmente i rari casi. La copertura dell’accordo, eventuali ordini e RC saranno valutati sul caso effettivo. Non è una decisione bloccante per la struttura ordinaria. |
| D08 | **Deroghe di prezzo e sconti:** operatori autorizzati, casi ammessi, riferimento a gara/accordo e conseguenze sui rinnovi | Tariffa standard e prezzo concordato distinti; deroga motivata e controllata. Nessuno sconto implicito trasferito a tutti i cicli. Verificare le condizioni applicabili prima di attivare deroghe, senza dedurre dal solo codice la loro ammissibilità. |
| D09 | **Rilascio e RV del verbale:** primo DPR con invio dopo RV; RV negativo → registrata acquisito; nota RT visibile e storico RV richiesti | Il verificatore ripete l’attività e/o corregge il verbale, lo finalizza e ricarica, riporta la verifica a eseguita e sottopone il documento a nuovo RV. Conservare tutti i riesami con nota, autore, data/ora e versione esaminata. Invio e fatturazione ordinaria dopo nuovo RV conforme. Rilascio immediato futuro, nelle condizioni discusse. |
| D10 | **Interventi non ordinari:** stato sospesa e continuità alla ripresa acquisiti; sopralluogo a vuoto addebitabile richiesto; restano transizioni puntuali, parziali e condizioni economiche | Conservare il flusso assegnata → eventuale programmata → registrata durante l’esecuzione → eseguita solo con verbale finalizzato e caricato. Riprendere la sospesa sullo stesso incarico e mantenere l’eventuale numero già assegnato. Proposta minima: motivo e passaggio tracciati. Possibilità di addebitare il sopralluogo a vuoto come voce distinta: proposta manuale, con condizioni/importo da definire. Nessuna nuova verifica o variazione ATEX automatica. |
| D11 | **Fatturazione completa e canale elettronico:** fattura unica da più preventivi già presente in Garda e da conservare; acconti non ordinari ma possibili acquisiti; separazione DM/EX acquisita; restano altre eventuali aggregazioni, modalità degli acconti/saldo, rettifiche, riferimenti PA, serie e continuità dei numeri; download XML e caricamento manuale su Aruba acquisiti; importazione degli esiti e visibilità degli scarti richieste, modalità da definire | Conservare la generazione da riga preventivo con possibilità di associazione a fattura esistente, conservando il collegamento alle rispettive prestazioni. Supportare fatture di acconto come eccezione, con collegamento al saldo e distinzione dagli incassi; non imporle nel flusso ordinario. Censire le altre funzioni Garda e conservare il processo utile, con intestatario fiscale proprio. Mantenere download XML e caricamento manuale su Fatturazione Elettronica Aruba; l’invio automatico è rinviabile. Importare gli esiti sulla fattura e conservare scarti, correzioni e tentativi successivi; definire il recupero da Aruba. Approvata per il nuovo sistema la correzione nel gestionale con rigenerazione XML e conservazione del contenuto effettivo. Serie esistenti riscontrate nei backup; significato EX chiarito (CND GVR, efficienza valvole, ispezioni volontarie SC/SP/GVR). DM ed EX restano su fatture separate e hanno serie distinte anche nei preventivi, secondo la prassi confermata. Questo canale esterno non riduce il requisito di fatturazione e incassi completi nel gestionale. |
| D12 | **Incassi e residui:** gestione attuale in Garda acquisita; pagamento unico normalmente per una fattura, eccezionalmente per più fatture acquisito; registrazione manuale iniziale confermata; import estratti conto necessario e successivo; restano verifica dei dettagli economici e collaudo | Conservare la gestione operativa nel primo AD_dpr. Nella normale registrazione, consentire di associare lo stesso pagamento a più fatture, indicando quanto attribuito a ciascuna; non duplicare il totale ricevuto. Nessun flusso dedicato al caso raro. Saldo e residui coerenti; rappresentazione tecnica da consolidare. Registrazione manuale iniziale confermata. Import estratti conto richiesto in un modulo successivo necessario; modalità e abbinamento dei movimenti da progettare in quel modulo, senza presumere un collegamento bancario automatico. Distinguere il modulo incassi da un progetto aggiuntivo di contabilità generale. |
| D13 | **Migrazione e convivenza:** identità dubbie, autorità di scrittura per categoria, importazione dei lavori aperti preferita, da validare; storico già fatturato, riallineamenti | Predisporre l’importazione delle pratiche attive, con prova prima del perimetro definitivo di cutover. Identificativi e riferimenti sorgente stabili; fusioni dubbie da controllare, nessun abbinamento irreversibile solo fuzzy. Durante il collaudo Garda rimane autorità gestionale; VerbalizzAI conserva il proprio ruolo sui documenti prodotti. Al passaggio un’autorità dichiarata per funzione, con import incrementale che non sovrascrive il nuovo lavoro. |
| D14 | **Scelte tecniche iniziali:** stack, database, confine dell’adattatore VerbalizzAI, archivio nuovi documenti e riuso della 0.7.1; profilo di accesso al server centrale | Il candidato è Python/FastAPI, SQLAlchemy/Alembic, HTML/JS, già presenti nel prototipo. Valutare il database e il riuso sui requisiti consolidati. Un backend centrale online e un archivio ufficiale dei contenuti; specificare da subito cosa entra nel backup e come evitare aggiornamenti divergenti fra archivi. |

Per D11 e D12 il censimento dei percorsi attuali deve precedere le domande residue: non si chiede all’utente di riscrivere a memoria tutto il software. Analogamente D02/D03 vengono presentati con esempi reali e D05 con eventi e conflitti già riscontrati. Le funzioni assenti nella 0.7.1 non vengono scambiate per assenti in Garda.

Il carattere integrato del nucleo si valida adesso sui ruoli dei soggetti, sull’identità dei beni e su un caso condiviso DM/I&C. Non richiede di decidere adesso tutti i tariffari o i flussi applicativi dei futuri moduli DM/I&C.

### 25.3 Lavoro tecnico e verifiche che non sono ulteriori domande aziendali

Una volta chiuse le regole, la progettazione deve tradurle in:
- riferimenti canonici stabili e origine di ogni dato migrato;
- importi esatti e precisione pertinente di quantità/prezzi/aliquote;
- collegamenti e vincoli dichiarati, controllo dei duplicati;
- numerazione atomica, versioni e gestione della concorrenza;
- contenuti e generazioni documentali identificabili, registro eventi e riesami riferiti alle versioni;
- recupero coerente dopo errori, import incrementale, backup/ripristino completo;
- collaudo sui casi normali e sulle eccezioni concordate.

Sono responsabilità tecniche dell’implementazione. Il riuso del prototipo non autorizza a mantenerne i problemi osservati. Non occorre sottoporre ogni vincolo database all’utente come scelta separata.

### 25.4 Decisioni e dettagli che possono attendere

Non bloccano il codice iniziale: nomi file nei dettagli, cartelle di download, testi dei pulsanti, aspetto delle maschere, impaginazione fine, dispositivi/tablet specifici, termine operativo dei solleciti di RV e automazioni accessorie.

Sono necessari prima del corrispondente esercizio in produzione, ma non prima dell’ossatura: macchina/hosting effettivi, dominio e accesso esterno, frequenza/retention e tempi di ripristino del backup, eventuale ambiente esterno di recupero, disponibilità delle credenziali dei servizi, piano concreto per recuperare gli originali S3, verifiche finali sulle fusioni e sui documenti storici, data e finestra del cutover. Il requisito di accesso centrale e il perimetro dei dati da proteggere entrano invece in D14 adesso.

Le regole minute DM/I&C possono attendere i loro moduli, purché D01–D03 dimostrino ora che il nucleo non confonde soggetti, beni, società e prestazioni.

### 25.5 Ordine per chiudere la specifica

1. D01–D03: soggetti, beni e proprietà dei dati.
2. D04–D10: responsabilità e processo DPR, comprese le sole eccezioni strutturali.
3. D11–D12: ciclo economico completo.
4. D13–D14: migrazione/convivenza e soluzione tecnica coerente.

Il risultato prima del codice è una specifica breve dei casi e delle regole, accompagnata dal modello concettuale e dai criteri di accettazione. Non serve un motore generalizzato di processi. Nel confronto si affronta un punto alla volta, riutilizzando quanto già deciso; una proposta ancora aperta non diventa un requisito approvato soltanto perché compare in tabella.

## 26. Chiarimento DPR sui soggetti e metodo per le modifiche

### 26.1 Regola confermata, mantenendo Garda

L’utente chiarisce che Garda prevedeva opportunamente la fatturazione a terzi soltanto alla generazione della fattura:
- il committente è il datore di lavoro;
- impianto, preventivo e verbale hanno l’intestatario pertinente a quel datore di lavoro nel processo descritto;
- la fattura propone quel cliente come intestatario;
- nei casi particolari, l’intestatario della fattura può essere cambiato;
- tale modifica non cambia preventivo, verbale o anagrafica dell’impianto.

La proposta precedente di intestare il preventivo a un committente B mantenendo il verbale ad A è ritirata per questo flusso DPR: non corrisponde al processo chiarito e introdurrebbe una distinzione superflua. Non si aggiunge quindi un soggetto commerciale obbligatorio prima della fatturazione.

La scelta del terzo avviene nella fattura e ne conserva i dati fiscali propri. Non viene anticipata come requisito del preventivo o dell’incarico. Il termine datore di lavoro/intestatario non viene trasformato automaticamente in proprietario giuridico del bene.

### 26.2 Vincolo esplicito sul metodo

L’utente richiede di parlarne prima di modificare logiche, entità o relazioni Garda. Il metodo di confronto diventa:
1. mostrare il comportamento e i collegamenti attuali riscontrati nel sorgente;
2. indicare un’inefficienza, mancanza o esigenza concreta;
3. proporre la modifica minima e mostrarne l’effetto sul caso;
4. discutere la scelta prima di adottarla nel modello o nel codice.

Le proposte generali di nucleo comune nelle sezioni precedenti rimangono ipotesi di progettazione. L’obiettivo di integrazione non autorizza automaticamente una diversa articolazione dei soggetti, dei beni o dei flussi.

In questa fase sono stati aggiornati soltanto i documenti di analisi e decisione; non sono stati modificati i sorgenti o i database dei gestionali per implementare nuove logiche. La registrazione di una risposta dell’utente nel documento conserva il requisito; non equivale a un cambiamento dell’applicazione.

### 26.3 Stato del prossimo confronto

D01 è chiarito sul ruolo dei soggetti nel ciclo DPR. Le domande successive devono evitare di riaprire questa distinzione. Responsabilità di modifica dei dati comuni, casi di cambio intestatario del bene e differenze degli altri ambiti vanno affrontati soltanto dopo il riscontro del funzionamento Garda e con esempi pertinenti.

L’elenco D01–D14 della sezione 25 resta un elenco di temi da consolidare: non è un invito a ridisegnare tutti i concetti esistenti. Prima si conserva ciò che funziona; si cambia dove emerge un beneficio concreto e dopo il confronto richiesto.

## 27. Aggiornamento dei clienti e conservazione dei documenti emessi

### 27.1 Requisito esplicito dell’utente

L’utente segnala che, secondo il proprio ricordo, Garda non conserva la storia del cliente: cambiandone il nome cambiano le anagrafiche e le sedi collegate. Chiede di verificarlo e precisa il risultato necessario: **i dati non devono cambiare nei verbali e nei preventivi già emessi**.

Il requisito vale sia per il file ufficiale conservato sia per la consultazione del documento e per un’eventuale ristampa. Una correzione intenzionale di un emesso rimane un’azione distinta e tracciata; non è l’effetto implicito di una modifica dell’anagrafica.

### 27.2 Riscontro sul backup Garda ingecert

Verifica statica del dump e dei sorgenti:
- `clienti` contiene i dati correnti e i campi `last_update_user`, `last_update_ts`, `last_update_nr`; il dump non presenta una tabella di versioni storiche del cliente o di successione dei clienti sul bene.
- `clienti_dec` legge `rag_soc` direttamente da `clienti`; `impianti_read` ricava il cliente dalla sede operativa corrente. I collegamenti di visualizzazione non rappresentano da soli il cliente alla data della vecchia verifica.
- `gi_clienti_save_before` non contiene una conservazione delle precedenti intestazioni. I log tecnici e di elaborazione presenti non sono una storia strutturata dell’anagrafica riscontrata.
- `preventivi` conserva il riferimento al cliente, senza campi di copia dell’intestazione. Il report `_rp_preventivo_word` legge `clienti` tramite `p.cliente`; una nuova generazione usa quindi i dati correnti. Anche il nome file viene costruito dalla ragione sociale corrente.
- `verifiche_verbale` conserva riferimenti a file caricati; questo non equivale a conservare l’intestatario storico nelle viste anagrafiche.
- Le fatture clienti hanno invece propri campi `cli_rag_soc`, indirizzo, CF e P.IVA, distinti dal riferimento al cliente.

Il riscontro sostiene il ricordo dell’utente per i dati relazionali esaminati. Non dimostra che una modifica del cliente riscriva automaticamente file già archiviati: il rischio accertato è la lettura/generazione dai dati correnti. Gli originali S3 non sono stati consultati.

Riferimenti: dump `ingecert_2026-10-07.sql`; `cust/gi_views.php`; `cust/_custom.php` (`gi_clienti_save_before`, `gi_rpt_preventivi_base_file_name_get`); `cust/meta/_rp_preventivo_word.js`; `cust/meta/clienti.js` e `clienti_sedi_operative.js`.

### 27.3 Soluzione minima proposta

Separare il dato corrente dall’evidenza emessa:
- l’anagrafica può essere aggiornata;
- preventivo/verbale emesso conserva i dati utilizzati e il proprio file/versione ufficiale;
- il download/ristampa di un emesso usa quella versione o i suoi dati, senza sostituirli con l’anagrafica attuale;
- la preparazione di un nuovo documento usa invece il cliente corrente pertinente.

La conservazione dei dati dell’emissione non richiede, da sola, di introdurre una gestione completa delle versioni di ogni campo anagrafico o nuovi adempimenti manuali. Il meccanismo tecnico va consolidato prima del codice; il risultato richiesto dall’utente è acquisito. Le bozze e le eventuali revisioni commerciali mantengono il flusso già discusso.

### 27.4 Scelta acquisita: altra azienda sullo stesso impianto

Un aggiornamento della stessa azienda — ad esempio denominazione o recapito — e il subentro di un altro soggetto giuridico sono casi distinti. Per il secondo l’utente approva un nuovo record cliente, mantenendo il precedente per lo storico e per le pratiche che gli appartengono. Non si propone di trasformare l’identità della vecchia azienda semplicemente rinominandola.

Dopo il riscontro sui sorgenti e la precisazione sui documenti emessi, l’utente approva la proposta di **mantenere lo stesso impianto fisico**, collegarlo al nuovo cliente e **registrare il passaggio**. Non si crea una seconda identità del bene per il solo cambio di azienda. La scelta riguarda il caso DPR discusso; non è un trasferimento già eseguito.

I preventivi e i verbali emessi rimangono riferiti al soggetto e ai dati della loro emissione. Il sistema dovrà distinguere le nuove prestazioni dalle pratiche già appartenenti al precedente cliente: il subentro non trasferisce automaticamente i debiti o le condizioni commerciali della vecchia azienda.

### 27.5 Prossimo caso di confronto D02: valvole e attrezzature

Nei metadati Garda AD_dm la valvola di sicurezza è già un oggetto distinto (`valvole_sicurezza`), identificato anche da fabbricante, modello e matricola, con riferimenti di taratura. L’associazione alle attrezzature è in `attrezzature_vds`, con riferimenti separati a valvola e attrezzatura e unicità della coppia. Si conserva questa distinzione come base del confronto; non si propone di trasformare la valvola nell’attrezzatura.

L’utente riconosce la possibile utilità della storia dei montaggi, ma chiede di evitare la complicazione architetturale. La prassi e la scelta sono **mantenere l’abbinamento corrente, modificandolo manualmente quando necessario**, insieme allo storico delle tarature e ai documenti. Non si introduce nel primo perimetro una gestione separata dei montaggi con intervalli temporali. Il subentro DPR già concordato rimane un caso distinto.

Il collegamento corrente non deve alterare certificati e documenti già emessi. Le evidenze conservate rimangono consultabili, ma non viene promessa una ricostruzione strutturata dell’esatta installazione a qualsiasi data passata. Il modello comune va ancora validato sul riuso delle tarature fra DM e I&C.

Riferimenti: `adsrl/cust/meta/valvole_sicurezza.js` e `adsrl/cust/meta/attrezzature_vds.js`.

### 27.6 Esito D03: permessi di correzione configurabili

Riscontro nei ruoli predefiniti Garda ingecert (`gi_ddl_table_create_ruoli`): il ruolo Tecnico ha accesso alle proprie verifiche/impianti e non comprende i permessi di modifica clienti o sedi. Questo riscontro sui preset non certifica le assegnazioni e personalizzazioni di ogni account in produzione. Nel prototipo 0.7.1 i permessi anagrafici sono inizialmente assegnati a RT e segreteria.

L’utente chiarisce che l’eventuale correzione diretta delle anagrafiche è gestita con le impostazioni di ruoli e permessi. Non si introduce un percorso obbligatorio di segnalazione o approvazione per risolvere il caso; la distribuzione dei permessi non blocca il modello iniziale. I documenti già emessi restano comunque soggetti a R33.

Il catalogo D01–D14 è aggiornato di conseguenza: le domande successive devono riguardare effetti sostanziali sul lavoro o sui dati, non la sola assegnazione di un permesso già configurabile. Questo chiarimento non sceglie ancora quali dati tecnici del verbale aggiornino lo stato corrente e in quale momento.

## 28. Momento di aggiornamento delle scadenze DPR — scelta acquisita

Il riscontro Garda ingecert è preciso: `ricalcola_scadenze_impianto` legge l’ultima verifica **VP** in stato **effettuata**, ordinata per data di rilascio del verbale, e aggiorna ultima verifica e prossima scadenza dell’impianto. La selezione non richiede riesame conforme. `gi_verifiche_change_after` richiama quel ricalcolo; un nuovo RV negativo riporta la verifica a registrata e richiama il processo di aggiornamento. I casi di assenza di una VP utilizzabile e di rettifica meritano un controllo specifico, senza presumere che ogni ricalcolo cancelli o ripristini correttamente tutti i campi.

L’utente conferma il comportamento ordinario: **aggiornare la scadenza alla verifica effettuata/emissione, prima del RV**, salvo adeguarla quando il verbale viene modificato in revisione. La precedente proposta di consolidamento soltanto dopo RV conforme è superata.

La regola va applicata senza passaggi manuali aggiuntivi:
- una bozza di revisione non diventa il nuovo documento ufficiale;
- quando la revisione viene emessa, eventuali cambiamenti di data, periodicità o altra informazione determinante devono aggiornare coerentemente la scadenza pertinente;
- un cambiamento soltanto grafico non modifica quei dati;
- originali e revisioni rimangono conservati e identificabili.

Queste precisazioni traducono il requisito in criteri di implementazione; non sono modifiche già realizzate. La regola acquisita riguarda il ciclo periodico DPR. Effetti di annullamenti, esiti tecnici e straordinarie vanno ancora consolidati nei casi pertinenti.

Riferimenti: `ingecert/cust/_custom.php`, funzioni `ricalcola_scadenze_impianto` e `gi_verifiche_change_after`.

### 28.1 Riscontro sulle revisioni Garda e sul riuso di VerbalizzAI

Nel dump ingecert e nei servizi/metadati esaminati non è stata individuata una revisione strutturata del verbale con numero di revisione e relazione fra versioni. È invece presente il ciclo di correzione dopo RV negativo: verifica riportata a registrata, possibilità di ricaricare il PDF e rimetterla in effettuata, con reset del RV per il nuovo controllo. Il caricamento di un altro file non equivale, da solo, a una revisione formalmente collegata al precedente documento.

VerbalizzAI e il ponte 0.7.1 hanno già `create_revision`, `revision_of` e il percorso di nuova emissione collegata alla stessa verifica. Sono componenti da riutilizzare e adattare alla regola appena acquisita, non funzioni da ricostruire da zero. La lettura statica della 0.7.1 mostra inoltre che le differenze di data possono essere trattate come avvisi: il comportamento futuro deve assicurare coerenza fra i dati realmente corretti e la scadenza, senza limitarsi a sostituire il file.

Riferimenti: Garda `cust/_custom.php` e `meta/verifiche.js`; Gestionale_AD 0.7.1 `moduli/verbali/servizio.py` (`_revisione_dopo_riesame`, `dopo_emissione`) e `moduli/verifiche/servizio.py` (`carica_verbale`).

### 28.2 Esito D06: evidenza scritta dell’accettazione

Garda prevede il campo `rif_ord_cli` (“Rif. ordine cliente”), da riportare in fattura quando compilato. Il campo non chiarisce da solo quali risposte il cliente fornisca normalmente e quali evidenze l’azienda richieda per registrare l’accettazione.

L’utente chiarisce che una conferma telefonica non capita mai e che viene sempre richiesto il **preventivo controfirmato oppure almeno una email di conferma**. La conferma scritta deve essere riferibile alle condizioni/versione e alle prestazioni accettate. Un generico stato accettato non sostituisce tale evidenza.

Non è stato invece deciso che l’accettazione richieda sempre il caricamento manuale di un file nel gestionale: documento, email o loro riferimento devono poter essere conservati e recuperati secondo il processo da consolidare. Non si introducono una firma elettronica del cliente obbligatoria o un’ulteriore approvazione interna. L’accettazione scritta precede il RC nel flusso già acquisito.

### 28.3 Esito D06: nuova prestazione dopo il preventivo accettato

**Decisione acquisita:** il preventivo accettato non si può modificare. Se il cliente aggiunge una prestazione, si prepara un nuovo preventivo integrativo. Le prestazioni dell’originale e dell’integrativo possono poi essere riunite in un’unica fattura.

Il nuovo preventivo segue il flusso già concordato: invio, accettazione scritta, riesame del contratto e, solo dopo esito conforme, affidamento dell’incarico. L’offerta originaria, le condizioni accettate e la relativa evidenza restano conservate; i suoi incarichi non vengono riscritti per inserire la nuova prestazione. L’immutabilità riguarda il contenuto commerciale accettato e non impedisce di registrare il successivo avanzamento operativo.

**Funzione Garda da conservare:** l’utente conferma che dalla riga preventivo si può generare una fattura oppure associare la prestazione a una fattura esistente. Il sorgente della maschera conferma l’azione «Genera/integra fattura», il campo «Fattura da integrare» e l’invio del relativo identificativo. La fattura unica conserva la provenienza delle prestazioni dalle rispettive righe/preventivi e il controllo contro la doppia fatturazione. Non serve fondere o sostituire i preventivi per poterli fatturare insieme.

Riscontro aggiuntivo: Garda `cust/meta/_custom.js`, `gi_preventivi_righe_fattura_genera_click`; `cust/meta/preventivi_righe.js`, azione di generazione fattura. Non è stato eseguito un test dell’intero percorso di fatturazione.

Riscontro dei sorgenti: Garda gestisce righe del preventivo, stato per riga e controllo contro prestazioni duplicate; il percorso esaminato non rappresenta una revisione commerciale strutturata equivalente a quella del prototipo. La 0.7.1 consente invece `crea_revisione` soltanto da un preventivo inviato o rifiutato, non ancora accettato. Questa funzione non va estesa all’accettato per gestire l’aggiunta: il requisito acquisito richiede un nuovo preventivo integrativo.

Riferimenti: Garda `cust/_custom.php`, `gi_preventivi_righe_save_before`; 0.7.1 `moduli/preventivi/servizio.py`, `crea_revisione`.

### 28.4 D07: limite Garda e priorità dei pluriennali

**Chiarimento acquisito dall’utente:** Garda non prevede la gestione degli affidamenti pluriennali: consente di preventivare la prossima scadenza, non anche quelle successive. Questa è una lacuna del sistema attuale, distinta dalla fatturazione aggregata che invece esiste già.

L’utente precisa che i pluriennali sono rari e chiede di valutarne l’utilità senza rischiare di alterare la logica. **Raccomandazione:** non costruire ora un modulo o un nuovo ciclo di vita contrattuale; mantenere il flusso ordinario e trattare manualmente i rari affidamenti, conservando l’accordo accettato e i riferimenti alle prestazioni pertinenti. L’eventuale gestione automatica è un’estensione futura, non un prerequisito dell’MVP.

Questa raccomandazione non equivale ad approvare una nuova entità accordo, a imporre un nuovo preventivo o una nuova accettazione ogni anno, né a dare per autorizzata ogni prestazione futura. Quando si incontra il caso concreto, vanno verificate la copertura dell’accordo e la documentazione richiesta per il singolo intervento, insieme all’applicazione del RC già concordato.

### 28.5 Esito D10: stati ordinari e proposta di sospensione

**Flusso chiarito dall’utente:**
- dopo l’assegnazione, la verifica può essere programmata; lo stato programmata non è obbligatorio;
- passa a registrata in occasione dell’esecuzione;
- diventa eseguita soltanto quando il verbale è finalizzato e caricato nel gestionale;
- se la verifica non può essere eseguita, l’utente propone di aggiungere lo stato sospesa.

Si conserva quindi il flusso ordinario, aggiungendo uno stato di sospensione per un impedimento operativo. Una semplice uscita sul posto o l’avvio dell’attività non bastano a dichiarare eseguita la verifica. La sospensione non equivale all’esito tecnico negativo di una verifica conclusa e non è una correzione del verbale dopo RV.

**Continuità confermata dall’utente:** alla ripresa si continua sullo stesso incarico, mantenendo l’eventuale numero di verbale già assegnato. La sola sospensione non genera un nuovo incarico né una nuova numerazione. Attività e dati già registrati restano pertinenti alla stessa pratica.

**Proposta minima accessoria:** tracciare motivo, autore e momento della sospensione; conservare il passaggio e la ripresa nel registro eventi, senza introdurre un sottoprocesso separato.

Restano da definire gli stati dai quali si può sospendere e a quali si torna alla ripresa; l’eventuale rinuncia definitiva è distinta dalla sospensione. L’utente ha successivamente indicato come corretta la possibilità di addebitare il sopralluogo a vuoto (sezione 28.6); non è acquisita alcuna tariffa né un automatismo di fatturazione. I controlli RC e RV già concordati rimangono pertinenti; non si inventa un riesame aggiuntivo soltanto per il cambio di stato.

**Esito del chiarimento economico:** l’utente dichiara che oggi l’uscita a vuoto non è gestita e ritiene corretto addebitare il sopralluogo. È una nuova esigenza, non la descrizione di una procedura già in uso. La proposta di realizzazione e i limiti sono nella sezione 28.6.

### 28.6 Sopralluogo a vuoto: esigenza nuova e soluzione minima proposta

L’utente risponde al caso di verifica definitivamente annullata dopo l’uscita: oggi la situazione non è stata gestita, ma ritiene corretto addebitare un sopralluogo a vuoto. Si raccoglie la **possibilità di addebito**, non un obbligo in ogni caso.

**Proposta da discutere prima di implementare:** usare una voce economica manuale “sopralluogo a vuoto”, distinta dalla verifica non conclusa. Non portare la verifica a eseguita per fatturare l’uscita, non emettere un verbale di verifica inesistente e non aggiornare la scadenza periodica per il solo sopralluogo. L’operatore determina se la voce sia dovuta e il suo importo secondo le condizioni pertinenti: nessuna tariffa, clausola o autorizzazione commerciale viene inventata dal gestionale.

Il riscontro statico Garda mostra già righe fattura creabili/modificabili, con descrizione, quantità e prezzo; i riferimenti a preventivo e verifica non sono dichiarati obbligatori nei metadati esaminati. Questo suggerisce di conservare le normali funzioni economiche, senza introdurre un modulo separato per le uscite a vuoto. Non è stata eseguita una prova dell’intero percorso e non si dichiara già esistente una gestione specifica del sopralluogo.

Restano da concordare condizioni di addebito, importo e riferimento alla pratica. I dettagli tariffari possono essere definiti in seguito; non si estende automaticamente questa scelta alle verifiche sospese che saranno poi completate. Il controllo RV della fatturazione ordinaria delle verifiche rimane distinto dalla definizione di questa prestazione economica.

Riferimento: Garda ingecert `cust/meta/fatture_clienti_righe.js`.

### 28.7 Esito D11: acconti DPR occasionali

Garda offre nei metadati i tipi TD02 e TD03 per acconti/anticipi; la loro presenza non prova, da sola, una gestione completa dell’imputazione al saldo. L’utente chiarisce la prassi: **non sono ordinari nel DPR, ma possono capitare**. Vanno quindi supportati nel primo ciclo economico completo, mantenendo la fatturazione a lavoro concluso come percorso ordinario.

L’acconto fatturato deve essere riferibile al preventivo/prestazioni pertinenti e tenuto in conto nel saldo, evitando di fatturare nuovamente lo stesso importo. Il documento di acconto e il suo incasso sono fatti distinti: non si presume che una fattura sia pagata perché emessa. Questa precisazione conserva il significato dei dati, senza definire qui modalità fiscali di compilazione, calcolo o trasmissione.

L’acconto non rende eseguita una verifica e non sostituisce i controlli commerciali e tecnici concordati. Le regole ordinarie di RC, finalizzazione del verbale e RV rimangono pertinenti ai rispettivi passaggi; non si impone una verifica eseguita come condizione generale di creazione di una fattura di acconto.

Riferimento: Garda ingecert `cust/meta/fatture_clienti.js`.

### 28.8 Esito D11: download XML e caricamento su Aruba

**Prassi acquisita dall’utente:** l’XML viene scaricato dal gestionale e caricato manualmente nel servizio Fatturazione Elettronica Aruba. Il primo AD_dpr conserva questo percorso; l’invio automatico può essere un miglioramento successivo, senza condizionare l’avvio.

Il sorgente contiene il generatore XML e riferimenti ad Aruba nei metadati di configurazione e nei commenti del generatore. La risposta dell’utente chiarisce la prassi effettiva, che non era deducibile dai soli riferimenti statici.

Il ciclo completo di fatturazione e incassi rimane nel perimetro del gestionale, anche usando un servizio esterno per la trasmissione. L’utente ha successivamente chiarito che gli esiti sono consultati su Aruba e devono essere importati nel nuovo gestionale (sezione 28.11): la sola generazione o il download dell’XML non prova l’avvenuta trasmissione. Non sono acquisiti un sincronismo API né un’importazione automatica degli esiti.

Riferimenti: Garda ingecert `cust/meta/configurazioni.js`, `cust/fatture_clienti_genera_xml_cli.php`.

### 28.9 Esito D12: incassi e crediti gestiti in Garda

**Prassi confermata dall’utente:** gli incassi e le fatture ancora da pagare vengono gestiti in Garda. Questa funzione rimane nel primo AD_dpr, insieme alla fatturazione completa; Aruba conserva il ruolo dichiarato di servizio per il caricamento e la trasmissione degli XML.

Il sorgente Garda mostra pagamenti/scadenze, importo, riferimento del pagamento e indicatore saldato. Nei metadati esaminati ogni riga ha un riferimento obbligatorio a una singola fattura cliente. Questo non basta a dedurre come l’azienda gestisca effettivamente un bonifico che copre più fatture o un incasso parziale.

La registrazione di questa prassi non autorizza una nuova entità movimento o nuove relazioni finanziarie senza confronto. Prima si chiariscono i casi concreti da supportare, mantenendo la semplicità richiesta; non si presume un collegamento bancario automatico.

Riferimento: Garda ingecert `cust/meta/pagamenti.js`.

### 28.10 Esito D12: pagamento unico associabile a più fatture

**Chiarimento dell’utente:** il pagamento viene normalmente associato a una singola fattura. È raro che copra più fatture; in quel caso si tratta di associare lo stesso pagamento a due o più fatture.

Il risultato richiesto è quindi un pagamento unico, con una o più associazioni alle fatture. Non serve un flusso dedicato al caso raro: la normale gestione pagamenti permette di aggiungere la seconda fattura quando necessario. La precedente domanda sull’approvazione di una maschera separata è superata dal chiarimento.

Per ogni fattura deve risultare l’importo attribuito, così da calcolare il residuo senza duplicare quanto ricevuto. Esempio: 1.000 euro incassati, 400 attribuiti alla prima fattura e 600 alla seconda; l’incasso rimane 1.000 euro. Le quote sono una conseguenza tecnica del comportamento richiesto, non un ulteriore adempimento contabile.

**Riscontro Garda:** nei metadati esaminati la riga pagamento ha un riferimento obbligatorio a una singola fattura cliente, importo e riferimento del pagamento. Si conserva il significato del collegamento alla fattura; come rappresentare la possibilità di più associazioni va ancora definito tecnicamente. Non si dichiara che il vecchio riferimento singolo rappresenti già un pagamento unico su più fatture. Nessuna modifica a tabelle o applicazione è stata eseguita.

### 28.11 Esito D11: esiti su Aruba e importazione richiesta nel gestionale

**Prassi e mancanza confermate dall’utente:** gli esiti sono oggi consultati su Aruba e non lasciano traccia in Garda. L’utente chiede che vengano importati nel gestionale, segnalando che una fattura scartata deve essere ripresentata.

Il requisito riguarda il nuovo AD_dpr: mantenere sulla fattura gli esiti importati e rendere visibile lo scarto da gestire, conservando la storia delle correzioni e dei successivi tentativi. La generazione o il download dell’XML non equivalgono a trasmissione riuscita. Non basta memorizzare soltanto l’ultimo file eliminando il motivo dello scarto e l’esito precedente.

Il caricamento manuale dell’XML su Aruba può rimanere il percorso di invio. Il recupero degli esiti è un requisito distinto: la modalità concreta (automatica oppure importazione assistita) va verificata sulle capacità disponibili e definita prima dell’implementazione. Non è acquisita un’integrazione API già funzionante o autorizzato un accesso a credenziali.

I metadati Garda esaminati mostrano generazione XML e relativo log, coerentemente con il limite pratico segnalato dall’utente; non è stata eseguita una prova live del canale. Il requisito nuovo non autorizza modifiche immediate ai sorgenti Garda.

Riferimento: Garda ingecert `cust/meta/fatture_clienti.js`.

### 28.12 Esito D11: correzione nel nuovo gestionale approvata

L’utente inizialmente dichiara di non avere una policy precisa per la correzione delle fatture scartate. Dopo il confronto approva il criterio per il nuovo sistema: correzione nel gestionale, rigenerazione XML e nuovo caricamento su Aruba. È una scelta futura approvata, non una modifica già eseguita.

**Criterio approvato:** correggere il contenuto della fattura nel nuovo gestionale, rigenerare l’XML e caricare il file corretto su Aruba per il nuovo tentativo. Il gestionale conserva il contenuto utilizzato, gli XML dei tentativi e gli esiti importati. Aruba rimane il servizio di trasmissione; il recupero degli esiti resta un requisito separato.

Il vantaggio concreto è mantenere allineati importi, intestazione e righe conservati nel gestionale con il documento effettivamente ripresentato, senza dover riconciliare due contenuti modificati in luoghi diversi. Non serve un flusso documentale distinto per ogni servizio esterno.

Il criterio su dove correggere è approvato dall’utente; la sua realizzazione è ancora da progettare e collaudare. Individuare dove si corregge il contenuto non definisce da solo le regole fiscali di numerazione, date e rettifiche: tali regole dovranno essere verificate prima dell’implementazione pertinente. Non si assimila automaticamente lo scarto alla rettifica di una fattura già accettata e non si introduce una nuova prestazione da fatturare per il solo reinvio.

### 28.13 Esito D11: serie delle fatture e significato EX

Verifica sui database di staging derivati dai dump, aperti in sola lettura, e sui metadati Garda. Le serie recenti riscontrate sono:

| Archivio | Serie riscontrate | Significato acquisito |
|---|---|---|
| ingecert / AD_dpr | `/2026/DPR`, `/2025/DPR` | Serie DPR coerente con l’ambito. |
| adsrl / AD_dm | `/2026/DM`, `/2026/EX`, `/2026/ex`, `/2025/EX` tra le serie recenti | DM coerente con l’ambito; EX: CND GVR, efficienza valvole di sicurezza e verifiche ispettive volontarie SC/SP/GVR, secondo il chiarimento dell’utente. |
| iec / I&C | `/2026` | Serie annuale senza suffisso di attività nel campione riscontrato. |

Nei metadati fattura esistono numero e serie separati; il numero predefinito dipende dalla serie. Il generatore di serie adsrl esaminato propone `/anno/DM`, quindi il significato operativo EX è stato acquisito dall’utente. Non si deduce l’attività dal solo suffisso né si presume che EX ed ex vadano normalizzati o unificati.

**Significato EX acquisito dall’utente:**
- controlli non distruttivi delle attrezzature GVR;
- verifiche di efficienza delle valvole di sicurezza, come accessori GVR;
- verifiche ispettive volontarie SC, SP e GVR.

La classificazione conserva la società AD e il tipo specifico di prestazione oltre alla serie fiscale. Il termine “efficienza” indicato dall’utente resta quello della prestazione: non viene sostituito con “taratura” o assegnato automaticamente al modulo I&C. Questo chiarimento interessa i dati e il nucleo comune; i flussi dettagliati del futuro modulo DM possono attendere. Nessuna rinumerazione o fusione delle serie è approvata o eseguita.

Riferimenti: staging `ingecert.sqlite`, `adsrl.sqlite`, `iec.sqlite`, tabella `fatture_clienti`; `cust/meta/fatture_clienti.js`; adsrl `cust/_doc_fiscali_common.php`, `gi_serie_documento_get`.

### 28.14 Esito D11: DM ed EX su preventivi e fatture separati

**Risposta dell’utente:** si emettono due fatture separate, perché anche le serie dei preventivi DM ed EX sono separate. La separazione riguarda quindi il percorso commerciale e quello di fatturazione, pur per lo stesso cliente e la stessa società AD.

Il nucleo comune conserva questa prassi. La possibilità di riunire prestazioni di più preventivi in un’unica fattura, già acquisita nel confronto DPR, non autorizza a mescolare prestazioni DM ed EX. Non è necessario inventare una regola di scelta della serie per una fattura mista DM/EX: quel documento non fa parte della prassi da mantenere.

Questa risposta non decide automaticamente ogni altro abbinamento fra attività o serie. La separazione aziendale delle società emittenti rimane il requisito già acquisito.

Riscontro statico aggiuntivo: i metadati preventivo contengono serie e numero separati. Nel campione recente dello staging adsrl compaiono valori come `2026` e `2026/A`; da questi soli valori non è stata ricavata una mappatura delle serie commerciali DM/EX. Il significato della separazione è acquisito dall’utente; la corrispondenza puntuale nei materiali resta una verifica tecnica della migrazione, non una nuova regola da inventare.

Riferimenti: adsrl `cust/meta/preventivi.js`; staging `adsrl.sqlite`, tabella `preventivi`.

### 28.15 Esito D09: primo DPR con invio dopo riesame

Alla domanda sul perimetro del primo AD_dpr, l’utente conferma per ora **invio dopo riesame**, correggendo il termine inizialmente digitato. Il primo esercizio mantiene quindi il percorso ordinario; l’opzione di rilascio immediato viene rinviata.

Le valutazioni della sezione 24 rimangono riferimento per una futura estensione e per la compatibilità del modello. Non occorre implementare un secondo percorso operativo ora. Il RC prima dell’affidamento e il RV prima dell’invio mantengono i significati già concordati.

### 28.16 Esito D09: RV negativo → registrata, nota visibile e storico dei riesami

**Flusso confermato dall’utente:** quando il RT dà esito negativo al riesame, la verifica torna a registrata. Il verificatore deve ripetere l’attività e/o modificare il verbale, ricaricarlo e riportare la verifica a eseguita. Il documento viene quindi sottoposto a un nuovo RV; la fatturazione ordinaria e l’invio rimangono subordinati all’esito conforme.

**Requisiti aggiuntivi acquisiti:**
- il verificatore vede la nota scritta dal RT in caso di esito negativo;
- ogni verbale conserva lo storico di tutti i riesami, inclusi quelli negativi;
- ogni riesame resta riferito al documento/versione effettivamente esaminato, con esito, nota, autore e data/ora;
- il ricaricamento e il nuovo RV non eliminano né riscrivono le note e le evidenze precedenti.

La nota negativa rimane obbligatoria, come già previsto dai metadati Garda e dal servizio RV della 0.7.1. La visibilità richiesta serve al verificatore per conoscere cosa ripetere o correggere. Il riesame corrente può tornare da fare dopo il ricaricamento, mentre la cronologia continua a mostrare il precedente esito negativo e la sua nota.

**Riscontro Garda:** `gi_verifiche_change_after` riporta a registrata quando viene registrato un nuovo RV negativo. Al ritorno a effettuata resetta i campi correnti `riesame_fatto`, `riesame_esito` e `riesame_nota`. Il campo nota è già previsto nei metadati, visibile agli utenti che possono consultare le verifiche/proprie verifiche, con obbligo in caso di esito negativo. Quindi si conserva il flusso e si migliora la permanenza e la consultazione della cronologia. Il riscontro sui campi correnti non esclude eventuali log generici del framework, che da soli non sono la vista storica per verbale richiesta.

**Riuso del prototipo:** il servizio `riesame` registra esito, note, autore e momento e scrive un evento `verifica.riesame`; anche qui l’esito negativo porta a registrata. Il registro eventi è una base utile per lo storico, da rendere consultabile per verbale e collegare alla precisa versione esaminata. Non si dichiara già disponibile una cronologia completa conforme al nuovo requisito sulla sola presenza dell’evento.

**Criterio per il collaudo futuro:** RV negativo con nota, correzione e ricaricamento, nuovo RV conforme. La verifica torna prima a registrata e poi a eseguita; il verificatore vede la nota originale e la cronologia mostra entrambi i riesami con i rispettivi documenti. Nessun invio o fatturazione ordinaria usando il riesame precedente.

Riferimenti: ingecert `cust/_custom.php`, `gi_verifiche_change_after`; `cust/meta/verifiche.js`, `riesame_nota`; prototipo `gestionale/moduli/verifiche/servizio.py`, `riesame` e `_scrivi`.

### 28.17 D13: importazione degli incarichi aperti preferita, da valutare

L’utente indica che la scelta va valutata, ma **l’ideale è importare gli incarichi già aperti** nel nuovo AD_dpr. Si registra questa preferenza e si predispone il progetto per accogliere pratiche attive; non si presenta il trasferimento completo come una migrazione già collaudata o una decisione definitiva di cutover.

Durante il collaudo Garda rimane l’autorità gestionale, come già proposto. Prima del passaggio si prova l’importazione di incarichi nei diversi stati, con i collegamenti a cliente/sede/impianto, preventivo e righe, tecnico, numero di verbale eventualmente assegnato, documenti e riesame corrente disponibile. Le evidenze storiche vengono importate nella misura effettivamente disponibile, senza inventare riesami precedenti cancellati dai campi correnti.

**Riscontro sul dump ingecert del 7 ottobre 2026**, staging aperto in sola lettura:

| Stato della verifica nel dump | Numero di record |
|---|---:|
| assegnata | 81 |
| programmata | 71 |
| registrata | 7 |
| Totale nei tre stati sopra | 159 |
| effettuata, con riesame fatto = F | 3 |

Questi conteggi descrivono il backup, non una lettura del sistema live né un perimetro definitivo delle pratiche da trasferire. La prova deve comprendere anche i documenti già caricati e ancora da riesaminare, non soltanto i lavori da eseguire.

Il risultato della prova servirà a decidere il perimetro effettivo: continuità degli identificativi, degli stati e delle relazioni, disponibilità dei documenti necessari e ripresa del lavoro senza creare una seconda pratica. Al passaggio ogni incarico avrà un solo sistema operativo di riferimento. Non si fissa ancora una data e non si modificano dati in produzione.

Gli originali S3 rimangono differiti come richiesto dall’utente: i conteggi e i riferimenti documentali non attestano che i relativi file siano stati recuperati.

Riferimento: staging `ingecert.sqlite`, tabella `verifiche`, campi `stato_verifica`, `riesame_fatto`, `riesame_esito`.

### 28.18 Verifica straordinaria: preventivo distinto e verbale VS

**Decisione acquisita:** la verifica straordinaria viene preventivata a parte e produce un verbale VS anziché VP. Nel caso discusso, il ricontrollo dopo sistemazione dell’impianto costituisce quindi una nuova prestazione, con preventivo e incarico propri. Si conserva il normale percorso di accettazione scritta, riesame dell’offerta e affidamento. Il RV negativo rimane un caso diverso: ritorno a registrata sullo stesso incarico, correzione/ripetizione, nuova finalizzazione e nuovo RV.

**Riscontro nel codice ingecert:** `cust/meta/preventivi_righe.js` contiene già il tipo obbligatorio VP/VS. Le condizioni per generare una verifica richiedono riga accettata, tariffa applicata e riesame preventivo conforme; `cust/_custom.php`, `gi_verifiche_change_after`, costruisce il codice con il tipo della verifica come prefisso. La distinzione fra periodica e straordinaria non richiede quindi di inventare una nuova entità o un flusso separato. La richiesta aziendale di un preventivo distinto è ora confermata dall’utente; il solo enum nel codice non avrebbe dimostrato tale prassi.

**Da conservare:** tipo VP/VS, collegamento alla prestazione preventivata, normale ciclo di incarico e progressivo unico annuale. Il significato di «sezionale» è stato chiarito dall’utente: cambia soltanto il prefisso, come indicato sotto. È confermato anche che la VS non ricalcola automaticamente la scadenza periodica, mantenendo la logica Garda.

### 28.19 Numerazione VP/VS: logica Garda confermata

Il sorgente ingecert assegna il numero tramite `gi_next_number_get($conn, 'VPVS'.$anno)`: **un unico progressivo annuale condiviso fra VP e VS**, con codice `tipo/numero/anno`. Il prototipo AD 0.7.1 usa anch’esso un progressivo annuale comune. Si tratta di un riscontro sul comportamento implementato, non di una richiesta di modifica.

**Decisione acquisita:** l’utente conferma che la numerazione delle verifiche DPR 462 è unica su base annua; cambia soltanto il prefisso, VP per la verifica periodica e VS per la straordinaria. Si mantiene quindi il criterio già presente in ingecert, senza contatori distinti e senza una nuova logica di numerazione. Il chiarimento chiude l’ambiguità precedente.

Riferimenti: ingecert `cust/_custom.php`, `gi_verifiche_change_after`; prototipo `gestionale/moduli/verifiche/servizio.py`, `numero_successivo` e `codice_verbale`.

### 28.20 Metodo ribadito: confronto con Garda per ogni decisione

Per ciascun requisito concordato si documentano il riscontro in ingecert, adsrl o iec pertinente, la funzione da mantenere e la carenza concreta da migliorare. Se il riscontro non è disponibile o non è concluso lo si dichiara, senza presentare il requisito come una funzione nuova. Non si modificano logiche, entità o relazioni senza prima discuterne con l’utente, come già stabilito in R32.

L’esame del sorgente prova la presenza e le condizioni della funzione; il collaudo dimostra il suo funzionamento nel nuovo sistema. Non si attribuisce al codice una prassi aziendale o una validità normativa che richiedano una conferma distinta.

### 28.21 D08: primo riscontro documentale sugli sconti nelle procedure pubbliche

Il [comunicato del Presidente ANAC del 28 ottobre 2020](https://www.anticorruzione.it/documents/91439/121138/Comunicato%2Bdel%2BPresidentedel28_10_2020.pdf/cab40753-7516-c694-6e25-0a2ceb5eb84c?t=1608645132100), relativo all’articolo 7-bis del DPR 462/2001 e al tariffario ISPESL, interpreta le tariffe come riferimento per gli affidamenti pubblici e contempla ribassi in gara o sconti negli affidamenti diretti. Questo riscontro sostiene la prassi indicata dall’utente per le gare PA; non viene esteso automaticamente agli incarichi privati.

La verifica delle condizioni attualmente applicabili rimane aperta: non si dichiara concluso l’esame normativo e non si attiva alcun automatismo di deroga. È stato individuato anche un successivo parere ANAC del 15 novembre 2021, ma la pagina non è risultata consultabile; il suo contenuto non viene assunto come verificato.

### 28.22 Scadenza periodica dopo VS: regola Garda confermata

**Riscontro ingecert:** `cust/_custom.php`, `ricalcola_scadenze_impianto`, seleziona l’ultima verifica effettuata di tipo VP e ne usa `data_prox_verifica` per aggiornare la scadenza dell’impianto. La VS non è selezionata come fonte automatica del nuovo ciclo periodico. Questo descrive la logica del codice esaminato, non una prescrizione normativa né una conferma della prassi per ogni caso particolare.

**Decisione acquisita:** l’utente conferma che la straordinaria non determina automaticamente la periodicità e chiede di mantenere la regola esistente. La finalizzazione di una VS non avvia quindi un nuovo ciclo periodico e non sposta automaticamente la scadenza derivata dalla VP. Si conserva il comportamento Garda esaminato, senza introdurre un nuovo automatismo.

### 28.23 Dismissione con incarichi aperti: chiusura manuale confermata

**Riscontro ingecert:** `cust/meta/impianti.js` prevede già il flag booleano `dismessa`. In `cust/meta/scadenze.js` la creazione del preventivo da scadenza richiede `dismessa='F'`; in `cust/meta/preventivi_righe.js` la generazione della verifica richiede anch’essa impianto non dismesso. In `cust/_custom.php`, `gi_impianti_change_after` richiama il ricalcolo delle scadenze, senza una transizione esplicita di annullamento delle verifiche già aperte. Nel codice esaminato non risulta dunque una chiusura automatica degli incarichi aperti alla dismissione. Non si dichiara che il flag elimini tutte le righe di scadenza o impedisca ogni possibile azione del sistema.

**Decisione acquisita:** l’utente conferma che gli incarichi già aperti su un impianto segnato dismesso rimangono da chiudere manualmente. Non si introduce un annullamento automatico alla modifica del flag. Si mantengono distinti stato dell’impianto e stato dell’incarico; un eventuale sopralluogo a vuoto già svolto può essere valutato nel normale trattamento economico manuale concordato, senza addebiti automatici.

### 28.24 Accettazione parziale del preventivo: funzione Garda confermata

**Riscontro ingecert:** `cust/meta/preventivi_righe.js` prevede lo stato delle singole righe, inclusi accettata/rifiutata/da_accettare. In `cust/_custom.php`, `gi_preventivo_stato_update`, il riepilogo diventa `accettato_parzialmente` se alcune righe sono accettate e non tutte. La condizione per generare la verifica richiede la riga accettata e il riesame preventivo conforme. Quindi l’accettazione parziale è già prevista nel modello Garda; non richiede una nuova entità.

**Decisione acquisita:** l’utente conferma pienamente l’accettazione parziale. Si mantiene lo stesso preventivo, registrando quali righe sono accettate e procedendo soltanto su quelle dopo il riesame. Le altre righe non autorizzano l’affidamento. Restano ferme l’evidenza scritta di accettazione e l’immutabilità del contenuto commerciale accettato: accettare un’altra prestazione già offerta è distinto dall’aggiungere una prestazione nuova, che richiede un preventivo integrativo.

### 28.25 Portata del RC: intera offerta invariata

**Riscontro ingecert:** il riesame è memorizzato sulla testata del preventivo (`cust/meta/preventivi.js`). La vista delle righe (`cust/gi_views.php`) espone `p.riesame_fatto` e `p.riesame_esito` come dati del RC usati per generare la verifica. `gi_preventivi_righe_change_after` aggiorna importi, riepilogo e scadenze, senza un azzeramento esplicito del RC alla successiva accettazione di un’altra riga. Nel percorso esaminato, una riga già offerta e accettata in seguito può quindi usare il RC conforme ancora registrato sulla testata; non si assume da questo riscontro che tale comportamento coincida con l’ambito effettivamente valutato dal responsabile.

**Decisione acquisita:** l’utente precisa che il caso non è mai capitato e, per semplicità, sceglie che il riesame copra tutta l’offerta invariata. Nell’esempio, la successiva accettazione del terzo impianto già incluso nel preventivo non richiede di ripetere il RC. La riga non accettata non autorizza comunque l’affidamento; alla successiva accettazione scritta può essere utilizzato il RC conforme valido dell’offerta. La regola non copre l’aggiunta di una prestazione nuova o una modifica del contenuto commerciale accettato, per cui rimane il preventivo integrativo con relativo RC.

**Da conservare in Garda:** RC sulla testata e accettazione per riga. **Da migliorare nel prototipo:** consentire la generazione dell’incarico per una riga già offerta e accettata successivamente, senza richiedere un nuovo RC come espediente tecnico e senza duplicare incarichi. Nessun riesame separato per riga.

### 28.26 Incassi: manuali nel primo rilascio, import estratti conto necessario e successivo

**Riscontro ingecert:** `cust/meta/pagamenti.js` prevede gestione delle righe di pagamento, scadenza/importo, entrata/uscita, riferimento e saldato. `cust/_doc_fiscali_common.php`, `fw_doc_calcola_iva_totali`, legge i termini di pagamento e le rate, conserva i movimenti saldati e ricalcola le quote ancora dovute. La gestione di rate e residui è quindi già implementata nel percorso esaminato, benché non sia stato collaudato qui l’intero ciclo in esecuzione.

Nel codice personalizzato esaminato non è stato individuato un import dedicato degli estratti conto o un collegamento automatico alla banca. Il commento sulla riconciliazione nel generatore XML riguarda un campo FatturaPA, non dimostra una funzione di abbinamento bancario.

**Decisione acquisita:** l’utente conferma la registrazione manuale degli incassi nel primo AD_dpr, con associazione alle fatture e controllo dei residui. L’import degli estratti conto è rinviato a un modulo **necessario**, da sviluppare successivamente: non è eliminato dal progetto né classificato come funzione facoltativa. Non si decide in questa risposta se il futuro modulo userà file, collegamenti bancari o altre modalità, né se tutti gli abbinamenti saranno automatici. Restano già acquisiti il pagamento unico associabile a più fatture e il requisito di fatturazione e incassi completi nel primo rilascio.

### 28.27 Punto del questionario e perimetro di approfondimento proposto

L’utente chiede a che punto sia il totale delle domande e se approfondire tutte le questioni DM/I&C o soltanto il DPR. Il registro D01–D14 è un elenco di **aree decisionali**, non un questionario con un numero iniziale fisso di domande. Non si assegna quindi una percentuale numerica di completamento priva di una base di conteggio e non si confonde il consolidamento dei requisiti con l’avanzamento del codice.

**Già consolidato per il primo DPR:** soggetti e intestazioni, conservazione degli emessi, accettazione e integrativi, RC e accettazione parziale, stati dell’incarico, VP/VS e scadenze, dismissione, RV con nota e storico, invio dopo RV, fatturazione completa con intestatario terzo, canale XML/Aruba, esiti e scarti, incassi e pagamenti su più fatture. Alcuni dettagli e collaudi restano necessari: «consolidato» non significa modulo già implementato.

**Raccomandazione di lavoro:** chiudere il DPR operativo. Per DM/I&C verificare adesso soltanto le strutture comuni che incidono sul nucleo: società emittenti, clienti/sedi, identità e distinzione dei beni, prestazioni e scadenze, separazione di serie/ambiti, collegamenti a documenti e dati economici. Conservare le funzioni Garda esistenti; ogni modifica sostanziale resta da discutere prima. Tariffari, maschere e flussi dettagliati DM/I&C saranno approfonditi prima dei rispettivi moduli, dopo la validazione nell’uso del DPR.

**Tre blocchi residui da esaminare per chiudere la specifica iniziale**, senza trasformare ogni verifica tecnica in una domanda all’utente:

1. Confine dei dati tecnici fra nucleo e VerbalizzAI e aggiornamento del dato corrente, conservando gli emessi.
2. Prerequisiti sostanziali dell’affidamento, comprese qualifiche e indipendenza, partendo dai controlli già presenti nei sorgenti; non riaprire le scelte già affidate a ruoli e permessi.
3. Chiusura del censimento economico, soprattutto rettifiche/acconti e recupero degli esiti, chiedendo soltanto la prassi non desumibile dal codice.

Il mapping, i vincoli, la concorrenza, le prove di importazione e le scelte tecniche devono essere svolti dall’analisi e dall’implementazione, con proposte concrete quando incidono su una decisione dell’utente. Cutover, originali S3 e dettagli di esercizio restano necessari prima della produzione pertinente, ma non diventano un questionario completo su DM/I&C prima di iniziare l’ossatura DPR.

L’utente ha successivamente confermato questo perimetro di lavoro (R60): DPR operativo e verifica strutturale del nucleo per DM/I&C. Non equivale ad approvare puntualmente le proposte tecniche ancora aperte. Il risultato del giro finale sarà una sintesi breve delle decisioni, del modello concettuale e dei casi di accettazione da riesaminare prima del codice.

### 28.28 Primo dei tre blocchi finali: aggiornamento delle caratteristiche tecniche

**Riscontro ingecert:** la scheda verifica espone dati dell’impianto, fra cui potenza e numero di cabine, tramite campi di lettura `imp_*` (`cust/meta/verifiche.js`). Il ricalcolo esaminato in `cust/_custom.php`, `ricalcola_scadenze_impianto`, aggiorna sull’impianto i riferimenti e le date dell’ultima/prossima VP. Non è stato individuato in questo percorso un aggiornamento delle caratteristiche tecniche estratto dal contenuto del PDF del verbale. Questo riscontro è circoscritto al percorso esaminato, non dichiara assente ogni possibilità di modifica manuale dell’impianto.

**Riuso VerbalizzAI 0.3.32.3:** `plantstate.py` seleziona esplicitamente lo stato riutilizzabile, inclusi potenza, tensione, POD e cabine per M01; esclude misure ed esiti della singola verifica. La finalizzazione offre già «Aggiorna la scheda impianto» oppure «Conserva la scheda impianto» (`static/app.js`). `storage.py`, `Archive.issue`, applica l’aggiornamento scelto all’emissione, con controllo della versione e della data dello stato; il default prudente in `finalization.publish_default` non aggiorna automaticamente nelle revisioni o se lo stato corrente è più recente. Non occorre inventare un nuovo flusso di approvazione per questa scelta.

**Riscontro prototipo 0.7.1:** `gestionale/moduli/verbali/servizio.py`, `dopo_emissione`, usa i dati strutturati del verbale e richiama `verifiche.carica_verbale`; `aggiorna_impianto` registra caratteristiche tecniche ed elementi sulla scheda del gestionale. È una base riusabile, ma il ponte esaminato richiama l’aggiornamento senza subordinare le caratteristiche alla scelta VerbalizzAI di conservare lo stato: questa coerenza deve essere realizzata prima dell’integrazione. La prova non è già stata eseguita.

**Proposta iniziale superata dal chiarimento R61:** la scelta esistente «Aggiorna»/«Conserva» era stata proposta come comportamento da mantenere. L’utente chiarisce il criterio aziendale: la scheda corrente segue le modifiche rilevate e il nuovo verbale ripropone la situazione fotografata nell’ultimo. Vedere 28.29 e 28.30. Mapping e controlli di coerenza rimangono responsabilità tecnica; la scelta «Conserva» non deve lasciare ordinariamente una scheda superata dopo una nuova fotografia corrente dell’impianto.

**Correzione tecnica già necessaria in base a R55:** il prototipo `carica_verbale` calcola una prossima verifica dalla data e periodicità e richiama `aggiorna_impianto` senza un’esclusione esplicita delle VS nel percorso esaminato. Il ponte dovrà conservare la scadenza periodica quando finalizza una VS, invece di riusare questo automatismo. È l’applicazione di una regola già concordata, non un nuovo quesito all’utente.

### 28.29 La scheda corrente segue l’impianto rilevato

**Chiarimento acquisito R61:** l’utente richiede che, se cambia l’impianto, cambi anche la scheda tecnica corrente, citando potenza, sistema di alimentazione ed elenco dei differenziali. Non si conserva quindi una scheda precedente come rappresentazione corrente di un impianto effettivamente modificato. Rimane la regola già acquisita di conservare le fotografie dei verbali emessi.

**Riscontro VerbalizzAI:** `plantstate.py` include potenza e tensione, gruppi `systems` e `supply` e definizioni degli elementi `samples` tramite `asset_definition`. Per gli elementi conserva ID, tipo, quadro, nome, occorrenza e caratteristiche, escludendo i risultati della prova. `storage.py`, `_set_profile`, aggiorna gli elementi identificati e rimuove dal profilo quelli esplicitamente ritirati; conserva inoltre gli elementi già noti non presenti nel campione. La validazione ammette `rcd`, `overcurrent` e `continuity`. Questa è una base già esistente per aggiornare anche i differenziali senza mescolare il censimento con i risultati delle singole prove.

**Limite tecnico da mantenere:** un differenziale non incluso nel campione di prova non è automaticamente eliminato dal censimento. Sostituzioni e ritiri devono seguire le evidenze e la gestione esplicita degli elementi già presente, evitando di trattare ogni elenco campionato come inventario completo. La data dello stato e la revisione del profilo proteggono inoltre da aggiornamenti basati su informazioni più vecchie.

**Regola ora confermata con il successivo chiarimento:** scheda corrente coerente con l’ultima fotografia e nuova bozza che ripropone quella situazione. Alla finalizzazione il ponte deve allineare i dati riutilizzabili senza un’approvazione separata. Revisioni di vecchi verbali e import storici non devono riportare la scheda a uno stato superato; un aggiornamento concorrente più recente va preservato o risolto esplicitamente. Questi controlli attuano il criterio aziendale, senza aggiungere un nuovo stato operativo.

**Casi di collaudo futuri:** variazione di potenza/alimentazione con aggiornamento della scheda e verbale precedente invariato; differenziale sostituito con nuova definizione e ritiro esplicito del precedente, conservandone lo storico; differenziale non campionato ancora censito; revisione di un vecchio verbale senza regressione dello stato corrente. Aggiornare le caratteristiche durante una VS resta distinto dal ricalcolo della scadenza periodica, che non deve essere spostata automaticamente.

### 28.30 Primo blocco chiuso: fotografie storiche e riuso dell’ultima situazione

L’utente precisa che l’importante è preservare lo stato storico degli impianti nei verbali emessi, mentre il nuovo deve riproporre la situazione fotografata nell’ultimo. Si acquisisce il comportamento come R61, senza un ulteriore quesito sul medesimo criterio.

**Effetto sul flusso:** il verbale A conserva la propria fotografia; una successiva verifica B registra potenza, alimentazione ed elementi aggiornati senza riscrivere A; la bozza C riparte dalle caratteristiche riutilizzabili di B. Misure, risultati e conclusioni devono essere raccolti per C, come già previsto da `plantstate.py`. Il riuso è pertinente al modulo: il profilo M02 non sostituisce indiscriminatamente quello M01. «Ultimo» riguarda la situazione tecnica più recente, non il solo ordine di caricamento di un file storico. Non si costruisce una nuova tabella autonoma di storia dell’anagrafica per realizzare questa regola: si riusano fotografie dei verbali, profili ed eventi esistenti.

Il primo dei tre blocchi finali è chiuso sul criterio aziendale. Mapping, conservazione degli ID degli elementi, trattamento del campionamento e controlli su date/revisioni rimangono da implementare e collaudare. I casi tecnici già elencati non sono test eseguiti.

**Primo riscontro per il secondo blocco:** ingecert `cust/meta/verifiche.js` collega il tecnico agli utenti tramite alias `tecnici` e prevede un tecnico in affiancamento. La dichiarazione personale `dichiaro_che` è già richiesta per programmare, registrare o effettuare la verifica (`gi_verifiche_save_before`); il metadato la propone però con default T. Nei campi e nel percorso di assegnazione esaminati non è stata individuata una matrice strutturata delle qualifiche BT/MT/ATEX applicata all’incarico. Questa verifica mirata non esclude procedure esterne o altri controlli del framework. La successiva R62 esclude un filtro dedicato delle qualifiche nel primo rilascio; ruoli e permessi restano configurabili come già concordato.

### 28.31 Assegnazione semplice con quattro tecnici abilitati

**Decisione acquisita R62:** l’utente considera superfluo il filtro proposto, perché i tecnici abilitati sono soltanto quattro. Nel primo AD_dpr non si realizza una matrice delle abilitazioni né un filtro specifico per prestazione. L’operatore autorizzato sceglie il tecnico nell’incarico. Non si trasforma la gestione delle qualifiche in un nuovo modulo o prerequisito per iniziare il codice.

La decisione esclude l’automatismo applicativo, non dichiara che tutti i tecnici abbiano necessariamente le medesime qualifiche né modifica le procedure aziendali di affidamento. Restano RC conforme prima dell’incarico, ruoli e permessi configurabili e il tecnico in affiancamento già previsto in Garda.

**Proposta successivamente superata da R63:** era stata proposta una spunta non preselezionata con conferma personale. L’utente mantiene invece il default preselezionato, escludibile dal tecnico, e il blocco operativo quando escluso. Vedere 28.32. Nessun nuovo iter di approvazione dell’assegnazione.

### 28.32 Indipendenza: comportamento Garda confermato

**Decisione acquisita R63:** l’utente conferma la casella preselezionata ed escludibile. Se viene esclusa, la verifica non può essere svolta da quel tecnico. Si conserva il comportamento esistente, senza imporre una nuova spunta obbligatoria inizialmente vuota.

**Riscontro ingecert:** `cust/meta/verifiche.js`, campo `dichiaro_che`, imposta default T e descrive l’assenza di conflitti reali o potenziali. `cust/_custom.php`, `gi_verifiche_save_before`, impedisce il salvataggio negli stati programmata, registrata o effettuata quando il valore è F. Il futuro servizio deve conservare il vincolo anche per richieste dirette, non soltanto nella maschera. L’esclusione non è un ordine automatico di cancellare l’incarico o assegnarlo a un altro tecnico.

**Tracciabilità tecnica:** conservare il valore relativo all’incarico, il tecnico pertinente e autore/momento delle modifiche. Un default inserito dal sistema non si descrive come azione personale eseguita dal tecnico. In caso di riassegnazione, preservare la precedente esclusione nello storico e verificare la condizione del nuovo assegnatario secondo il normale flusso, senza riutilizzare la dichiarazione personale del precedente.

**Caso di collaudo futuro:** incarico assegnato con casella preselezionata; tecnico che la esclude; tentativo di avanzamento respinto senza perdere l’incarico e con modifica tracciata. Il criterio del secondo blocco è chiuso; implementazione e prova rimangono da eseguire.

### 28.33 Terzo blocco: primo riscontro sulle note di credito

Il codice ingecert `_doc_fiscali_common.php` contiene già il tipo TD04, percorsi documentali e di pagamento dedicati e il collegamento alla fattura originaria. `gi_fatture_clienti_save_after`, copiando una TD01 verso una TD04, aggiunge un riferimento `FattureCollegate` con numero e data della fattura e copia le righe. `fw_fattura_cliente_righe_change_after` segnala con un warning la mancanza di un riferimento per TD04: questo non è un vincolo bloccante nel percorso esaminato. Sono funzioni da preservare e collaudare, non un nuovo modulo da inventare.

La presenza di questi percorsi non chiarisce da sola la prassi aziendale. La successiva R64 conferma l’uso delle note di credito anche parziali; resta da consolidare il trattamento concreto dei documenti già incassati e dei residui. Le rettifiche non si confondono con la correzione di una fattura scartata e la rigenerazione XML già discusse.

### 28.34 Note di credito anche parziali

**Decisione acquisita R64:** l’utente conferma che vengono emesse anche note di credito parziali, non soltanto per l’intero importo della fattura. Il primo AD_dpr deve conservarne la gestione e il riferimento alla fattura originaria, con importi e righe pertinenti. Il documento originario e gli incassi effettivamente registrati non vengono riscritti come se la rettifica fosse già esistita.

**Riscontro economico Garda:** `_doc_fiscali_common.php`, `fw_doc_calcola_iva_totali`, attribuisce tipo_pagamento U alle rate di un documento TD04 ed E alle fatture ordinarie. Durante il ricalcolo cancella i pagamenti non saldati e rilegge quelli saldati. `cust/meta/pagamenti.js` conserva collegamento a fattura_cliente, entrata/uscita, scadenza, saldato e note. Questi riscontri provano percorsi di gestione distinti, non una compensazione automatica collaudata fra una fattura e la sua nota di credito.

**Chiarimento successivo R66:** l’utente indica che nella prassi la fattura non è ancora stata pagata. Rimborso o compensazione di una somma già incassata non costituiscono il caso ordinario da sviluppare come procedura dedicata ora. Il caso futuro di incasso precedente alla rettifica resta una verifica tecnica di coerenza economica, senza attribuire all’utente una policy di rimborso o un divieto di emissione.

**Casi di collaudo futuri:** fattura da 1.000 con nota di credito parziale da 200, senza incasso; storno totale. Verificare saldo economico, collegamenti, movimenti effettivi e importi dei documenti. R66 chiarisce il caso ordinario: credito netto residuo 800, senza inventare un incasso o rimborso. La stessa rettifica dopo un incasso rimane un caso di coerenza da provare, ma non richiede ora una procedura dedicata o una nuova domanda su una prassi non presente.

### 28.35 Emissione diretta con righe personalizzate

**Decisione acquisita R65:** fattura e nota di credito possono essere emesse anche «in bianco», compilando righe personalizzate, senza associazione obbligatoria a verbali esistenti. Il caso è raro, ma rientra nella fatturazione completa richiesta per il primo AD_dpr.

**Riscontro ingecert:** `cust/meta/fatture_clienti.js` prevede l’azione new autorizzata dal permesso `new_fatture_clienti`. `cust/meta/fatture_clienti_righe.js` prevede creazione e modifica delle righe e i tipi RG normale, TX nota libera e AC spesa accessoria. Descrizione, quantità, prezzo e codice IVA sono gestiti come campi della riga; i riferimenti preventivo e verifica sono readonly e non dichiarati required. `_doc_fiscali_common.php`, `gi_fatture_clienti_righe_save_before`, richiama il normale calcolo delle righe e dei totali, senza un requisito generale di verifica associata nel percorso esaminato. La funzione non deve quindi essere ricreata come una nuova procedura operativa.

**Implicazione del modello:** il documento fiscale e le sue righe devono poter esistere autonomamente; il collegamento alla prestazione o verifica è facoltativo per una riga libera e presente per una riga generata dall’attività. I riferimenti della nota di credito alla fattura rettificata sono distinti dai collegamenti a verbali e verifiche e rimangono nel normale percorso documentale. Anche il documento libero conserva emittente, intestatario fiscale, serie e numero, importi, file/XML, esiti e movimenti economici.

Non occorre creare un incarico fittizio né dichiarare una verifica eseguita per emettere una fattura libera. Per la fatturazione derivata da una verifica rimangono i prerequisiti già concordati. Le due modalità usano lo stesso ciclo economico e i normali permessi, senza un nuovo workflow o un modulo separato.

**Casi di collaudo futuri:** creazione di fattura con una riga economica personalizzata senza verifica, XML e gestione incasso; nota di credito parziale con descrizione libera e riferimenti fiscali pertinenti; riga TX testuale senza effetto sugli importi. Verificare che queste operazioni non creino o modifichino incarichi e scadenze tecniche.

### 28.36 Nota di credito prima del pagamento e chiusura dei casi economici

**Chiarimento acquisito R66:** alla domanda su rimborso o compensazione dopo il pagamento, l’utente risponde che in teoria non si pone il caso, perché la fattura non è stata pagata. Si registra la prassi e non si apre un workflow di rimborso soltanto per l’ipotesi discussa. Non si presume impossibile qualsiasi caso futuro di incasso precedente alla rettifica.

**Caso ordinario da ottenere:** fattura da 1.000 ancora non pagata, nota di credito da 200 collegata, credito netto da riscuotere 800. Conservare entrambi i documenti e le loro righe; non rappresentare la nota come un bonifico ricevuto o restituito. L’allocazione della rettifica alle partite economiche e i controlli sui residui sono lavoro tecnico. Si preserva anche la possibilità già acquisita di documento libero R65, distinguendo i riferimenti fiscali dai legami alle verifiche.

**Altri riscontri Garda del terzo blocco:** `cust/meta/fatture_clienti.js` enumera TD02 acconto/anticipo su fattura e TD03 acconto/anticipo su parcella. La presenza del tipo documento non dimostra da sola che un futuro saldo deduca correttamente tutti gli acconti: il collegamento e la quadratura rimangono da progettare e collaudare secondo R43, senza trasformare il raro acconto in un passaggio obbligatorio. Lo stesso metadato contiene `generata_fatt_elettronica`, usato anche nelle condizioni di modifica: è un flag di generazione, non la prova di trasmissione o accettazione SdI.

**Proposta non approvata, modalità rinviata con R67:** era stato proposto un caricamento manuale delle ricevute Aruba e un eventuale collegamento automatico successivo. L’utente non desidera approfondire ora, ma conferma che l’importazione degli esiti è una cosa da fare. Non si seleziona nessuna delle due modalità. Formati esportabili, strumenti disponibili, associazione alla fattura e al tentativo e gestione degli scarti sono da definire e implementare; il requisito rimane necessario e distinto dall’import degli estratti conto rinviato.

### 28.37 Aruba: requisito mantenuto e modalità da approfondire dopo

**Decisione acquisita R67:** non approfondire ora la modalità di recupero degli esiti. Il nuovo sistema dovrà importare gli esiti Aruba e conservarne la traccia. Non trasformare il rinvio della scelta tecnica in una rimozione della funzione o in approvazione del caricamento manuale.

Il confine da predisporre nel nucleo è già chiaro: fattura, contenuto/XML del singolo tentativo, esito e relativa evidenza, correzione e successivo tentativo. Il meccanismo di acquisizione può essere definito separatamente senza riscrivere questo collegamento. Il flag Garda di generazione XML non basta a rappresentare tale storico. Nessuna credenziale Aruba o capacità di integrazione è stata verificata in questa fase.

## 29. Sintesi funzionale per preparare il codice iniziale

Questa sintesi chiude il giro attuale delle domande operative. È sufficiente per preparare una proposta tecnica concreta sul primo AD_dpr; non equivale a uno schema fisico definitivo approvato né a software già realizzato. Prima di cambiare logiche o relazioni Garda, i cambiamenti vengono presentati all’utente, come richiesto.

### 29.1 Primo sistema operativo

Un nucleo comune per AD_dpr, AD_dm e I&C, con attivazione iniziale del DPR completo: clienti/sedi/impianti, scadenze, preventivi e accettazione, RC, incarichi, VerbalizzAI, revisioni/RV, documenti/invii, fatturazione e incassi. Uso online centrale; programmazione distinta per ambito. AD_dm e I&C vengono attivati successivamente dopo la validazione del DPR nell’uso, conservando ora la compatibilità delle strutture comuni. L’approfondimento parallelo 05 prepara i futuri moduli.

### 29.2 Regole del percorso ordinario DPR

| Passaggio | Regola acquisita |
|---|---|
| Intestazione | Datore di lavoro/committente su preventivo e verbale; eventuale intestatario terzo scelto soltanto in fattura. Gli aggiornamenti anagrafici non riscrivono gli emessi. |
| Preventivo | Documento con anteprima PDF, ritocco Word e nuova anteprima come VerbalizzAI. Accettazione scritta, anche per singole righe. Contenuto accettato invariato; prestazioni aggiuntive su preventivo integrativo. |
| RC e incarico | Dopo accettazione, RC obbligatorio e conforme prima dell’affidamento. Il RC copre l’intera offerta invariata. Tecnico scelto dall’operatore autorizzato, senza matrice delle qualifiche nel primo rilascio. |
| Indipendenza | Casella preselezionata come Garda, escludibile; se esclusa quel tecnico non può svolgere la verifica. |
| Esecuzione | Assegnata, eventuale programmata, registrata durante l’attività, eseguita soltanto con verbale finalizzato e caricato. Sospesa con ripresa sullo stesso incarico e conservazione del numero già assegnato. |
| Numerazione e scadenza | Progressivo annuale unico VP/VS. Straordinaria su preventivo/incarico distinto; una VS non sposta automaticamente la scadenza periodica. Dismissione senza annullamento automatico degli incarichi aperti. |
| Dato tecnico | Ogni verbale conserva la fotografia storica; la nuova bozza riparte dalle caratteristiche e dagli elementi dell’ultima situazione pertinente. Misure ed esiti sono propri della nuova verifica. |
| RV | Negativo: ritorno a registrata, nota RT visibile, correzione/ripetizione, nuova finalizzazione e nuovo RV. Conservare lo storico legato alle versioni esaminate. |
| Invio | Primo DPR con invio dopo RV conforme. Rilascio immediato rinviato. |

### 29.3 Ciclo economico del primo DPR

Conservare la fatturazione da riga preventivo, anche associando più prestazioni compatibili a una fattura esistente. Prevedere anche fatture e note di credito con righe personalizzate senza collegamento obbligatorio ai verbali. Note di credito totali e parziali; nella prassi ordinaria la rettifica riguarda una fattura non pagata e riduce il credito residuo. Acconti possibili ma non obbligatori, da collegare al saldo e distinguere dagli incassi.

Incassi manuali, quote attribuibili a una o più fatture, residui coerenti. L’import degli estratti conto è un modulo necessario successivo. FatturaPA generata nel nucleo, XML scaricato e caricato manualmente in Aruba; recupero degli esiti necessario ma modalità da definire secondo R67. Conservare le versioni effettive dei tentativi, gli scarti e le correzioni.

AD e I&C S.r.l. conservano società emittenti e documenti fiscali distinti. DM ed EX restano separati per preventivi e fatture. Le altre aggregazioni fra ambiti non sono automaticamente approvate. I tariffari e la validità delle deroghe devono essere verificati sulle fonti pertinenti; ATEX segue il prezzo preventivato, senza variazione a consuntivo.

### 29.4 Modello concettuale da tradurre in uno schema concreto

Si riusa la struttura di concetti della sezione 22.2; i nomi seguenti sono responsabilità logiche, non nuovi nomi di tabelle già approvati.

| Concetto | Relazione da preservare |
|---|---|
| Società, soggetto e sede | Identità, riferimenti sorgente e condizioni pertinenti; intestazioni storiche nei documenti. |
| Bene ed elementi | Impianto DPR, attrezzatura DM e valvola distinti; elementi tecnici censiti e collegamenti correnti, senza confondere inventario e campione. |
| Preventivo e righe | Versione commerciale e prestazioni accettate; compatibilità futura con punti/sottopunti e prezzi a corpo I&C. |
| Incarico/verifica | Prestazione autorizzata, bene, tecnico, stato e numero; flussi specifici per modulo. |
| Verbale e stato tecnico | Fotografia emessa, revisioni e caratteristiche correnti riutilizzabili per modulo. |
| Riesame | RC riferito all’offerta e RV riferito alla versione del verbale; autore, esito, nota e momento. |
| Documento fiscale e righe | Righe generate o libere; emittente, intestatario, serie, numeri, importi e riferimenti documentali. |
| Movimenti e attribuzioni | Incassi effettivi, quote su fatture e rettifiche; totali e residui senza doppio conteggio. |
| File, generazioni ed eventi | Word/PDF, documento ufficiale, invii, XML/tentativi/esiti, contenuti e tracciabilità. |

Prima della traduzione fisica verificare il caso condiviso GVR, CND I&C e valvola tarata già descritto nell’approfondimento 05. Una sola identità del bene non implica fatture comuni fra società. Il filtro delle qualifiche e lo storico autonomo dei montaggi non vanno reintrodotti nello schema per inerzia.

### 29.5 Lavoro tecnico successivo e prove minime

Preparare una proposta di schema e di riuso della 0.7.1 con confronto alle fonti Garda. Distinguere tabelle da conservare, adattamenti necessari, funzioni nuove richieste e dettagli rinviati. La proposta deve risolvere importi esatti, FK, ID canonici stabili, import incrementale, versioni documentali e confine dell’adattatore VerbalizzAI. Python/FastAPI, SQLAlchemy/Alembic e HTML/JS rimangono candidati discussi; database e confini del riuso vanno motivati prima di presentarli come scelta definitiva.

I casi minimi di accettazione includono: accettazione parziale e RC sull’offerta invariata; VP/VS concorrenti con progressivo unico e VS senza spostamento della periodicità; sospensione/ripresa; aggiornamento tecnico con verbali precedenti invariati; RV negativo e nuovo RV con storico; fattura a terzo, fattura libera e nota di credito parziale; pagamento ripartito e acconto/saldo senza doppio conteggio; nuova importazione che conserva ID e lavoro successivo; backup/ripristino coerente di dati e documenti. Sono prove da eseguire, non risultati già ottenuti.

Restano verifiche necessarie di esercizio e produzione: acquisizione esiti Aruba e relative evidenze, allegati richiesti dalle pratiche, disponibilità degli originali S3, prova d’importazione degli incarichi aperti, continuità delle serie/numeri, hosting e ripristino. La loro definizione può procedere nelle fasi pertinenti; non richiede ora un nuovo questionario completo su DM e I&C. I dettagli di nomi file, destinazioni di download e maschere restano nel registro dei dettagli rinviati.


## 30. Avvio del codice — candidatura Gestionale_AD 0.8.0

### 30.1 Nuove istruzioni e perimetro effettivo

L’utente richiede di implementare AD_dpr a partire da VerbalizzAI e dal tentativo Python Gestionale_AD, usando Garda come base logica e fonte dei dati, senza modificare/adattare il PHP (R68). Precisa che sviluppo e primi test si svolgeranno in locale Windows (R69). È stata quindi preparata una candidatura eseguibile 0.8.0, separata dagli originali, per iniziare il collaudo di quel perimetro. Non è stata messa in produzione e non è ancora il gestionale completo delle tre attività.

Stack usato concretamente: Python/FastAPI, SQLAlchemy/Alembic, SQLite, HTML/JavaScript e LibreOffice. Si mantiene il server locale con un solo processo. PostgreSQL, più processi e hosting pubblico non sono già disponibili o collaudati. Il nucleo economico distingue società emittente e ambito; i moduli DM/EX/I&C, il modello comune definitivo dei beni e i permessi per ambito rimangono lavoro successivo.

### 30.2 Componenti e regole implementati

| Componente | Stato della candidatura e rapporto ai requisiti |
|---|---|
| Fondamenta e anagrafiche | Riusate dal prototipo 0.7.1: accesso/ruoli/permessi, clienti/sedi/impianti, tariffario, griglie, registro, documenti, backup e import iniziale Garda. Non è una conversione del PHP. |
| VerbalizzAI | Modulo incorporato aggiornato alla 0.3.32.3; IDs e anagrafica del gestionale. Il suo archivio fisico resta distinto, come precisato sotto. |
| Preventivi | Fotografia del contenuto e dell’intestatario alla prima trasmissione dei nuovi documenti; conservazione Word/PDF, anteprima LibreOffice e correzione Word già presenti. Accettazione con riferimento scritto richiesto; ulteriore accettazione di righe nell’offerta invariata dopo RC conforme genera gli incarichi mancanti senza duplicarli. R33/R38/R57/R58. |
| Esecuzione | Sospensione e ripresa sullo stesso incarico/numero. Indipendenza preselezionata, modifiche tracciate e blocchi di registrazione/emissione per il tecnico che la esclude. R41/R63. Il default di migrazione non è prova di una dichiarazione personale storica. |
| Stato tecnico e VS | Caratteristiche riutilizzabili distinte dai risultati della nuova verifica; tutela del dato più recente e del censimento non interamente provato. La VS aggiorna la situazione tecnica pertinente ma non la scadenza periodica. R55/R61. |
| RV e invio | Storico con nota, autore, momento e riferimento al documento; RV negativo riporta a registrata. Il percorso di invio incorporato richiede RV conforme sullo stesso PDF esaminato. R50/R51/R52. |
| Nucleo economico | Società, fatture/righe/scadenze, XML/tentativi/esiti, incassi e attribuzioni; FK, importi in centesimi, decimali esatti e controllo della versione. TD01/TD02/TD04, righe personalizzate o da preventivo, più prestazioni sul documento e intestatario terzo scelto in fattura. R31/R43/R64/R65. |
| Rettifiche/incassi | Note totali/parziali riducono il credito non incassato; un pagamento ripartibile fra più fatture compatibili; revisione delle attribuzioni e storno tracciato. La procedura per rettificare somme già incassate non è ancora disponibile e non viene attribuita all’utente come divieto assoluto. R46/R66. |
| Scarti ed esiti | Tentativi XML immutabili, ricevuta identificata, scarto/correzione/nuovo tentativo con numero preservato. Disponibile il contratto interno di registrazione, non un’importazione reale da Aruba. R47/R67 resta da completare. |

La conservazione degli emessi vale per le nuove fotografie prodotte dalla candidatura. Per i documenti storici senza quella fotografia si conservano le evidenze effettive disponibili: non si ricostruisce un’identità passata prendendola dall’anagrafica odierna. Il riferimento testuale richiesto nell’accettazione non archivia da solo l’email o il preventivo controfirmato.

### 30.3 Confine fisico e migrazioni

VerbalizzAI conserva per ora il proprio archivio SQLite, accanto al database relazionale del gestionale. Non è stato realizzato l’adattatore `Archive` sulle future tabelle comuni di asset/verbali. Il percorso di acquisizione dell’emissione è idempotente per documento/impronta e l’API autorizzata di riallineamento recupera emissioni persistite nel modulo ma non ancora acquisite nel nucleo. Questa è una misura di recupero, non una transazione atomica fra i due archivi.

Migrazioni 0009 e 0010: tabelle economiche e storico RV, fotografie dell’offerta, sospensione/indipendenza e riferimento dell’accettazione. Avvio con backup pre-aggiornamento; ricostruzione delle tabelle SQLite in transazione e controllo FK prima del commit. La prova su archivio 0008 popolato ha rilevato e permesso di correggere un blocco della ricostruzione dovuto ai riferimenti dei documenti. Sono state poi provate conservazione dei collegamenti, recupero del RV corrente noto e annullamento completo su errore. Non vengono inventati riesami precedenti o evidenze scritte mancanti.

L’import iniziale Garda della 0.7.1 resta destinato ad archivio vuoto. **ID canonici per tutte le origini, riallineamento incrementale durante la convivenza e importazione economica non sono ancora implementati.** La 0.8.0 non completa lo schema operativo/migrazione incrementale proposti nel vecchio piano. L’adattamento definitivo al nucleo integrato resta necessario prima del cutover.

### 30.4 Verifiche osservate e dati economici

**121 test passati, zero fallimenti e zero test saltati**, in 101,55 secondi su Linux/Python 3.12; un avviso di deprecazione riguarda il client HTTP dei test. Verificati schema/modelli, backup/ripristino, migrazione popolata e rollback, flussi operativi/economici e conversione reale della copia di cortesia PDF con LibreOffice. Molti test isolano le regole con PDF sintetici: non si descrivono come conversioni reali. La suite indipendente completa di VerbalizzAI non è stata rieseguita integralmente o ricontata in questo giro.

Un test del DOM con backend HTTP ha eseguito apertura, creazione bozza/riga, emissione XML, attribuzione incasso e storno. Ha consentito di correggere la preselezione della fattura nella ripartizione e la chiusura della scheda dopo storno. Non equivale a una verifica grafica o a un avvio su Windows. Controlli statici Ruff sui nuovi componenti economici e sui file di supporto: nessun errore.

Audit in sola lettura dello staging ingecert: **473 fatture, 1.123 righe, nessuna riga orfana, una riga negativa**; totale documenti **€385.061,37**, dovuto **€375.480,58**, scadenze **€375.480,58**. Una differenza fra imponibile/IVA/bollo e totale richiede una spiegazione prima dell’import economico, non una correzione automatica del dato. La candidatura non supporta ancora la riga negativa storica. **Zero XML originali confrontati**: i record del dump non provano la regressione sui 473 XML citata nel piano precedente.

Il generatore XML è provato sullo schema locale storico **1.2.2**, reperito nei materiali ingecert; la validazione contro specifiche correnti e i controlli extra-XSD restano da eseguire. Nessuna accettazione SdI o conformità completa ISO/Accredia è attestata da questo collaudo.

### 30.5 Consegna e lavoro successivo

Pacchetto sorgente `Gestionale_AD_v0.8.0_collaudo_Windows_2026-10-09.zip`, con guida `INIZIA_QUI_WINDOWS.md`, avvio `AVVIA_COLLAUDO_WINDOWS.bat`, stato tecnico e risultati delle prove. Archivio di prova distinto, nessun dump privato o credenziale nel pacchetto. Nessuna email inviata, fattura trasmessa o base dati operativa modificata durante le prove.

Prossimo passo pratico: installazione/avvio Windows e giro completo su casi sintetici, poi validazione operativa con casi DPR reali. Restano necessari prima di sostituire ingecert: modello comune definitivo e migrazione incrementale, import contabile quadrato e numeri iniziali, pratiche aperte/documenti, import esiti Aruba, validazione fiscale corrente, firma/invio e ripristino completo nelle condizioni effettive. L’assenza degli originali S3 non blocca questo primo collaudo locale; gli allegati necessari all’esercizio dovranno comunque essere recuperati e verificati nella fase pertinente. DM e I&C saranno attivati dopo la validazione DPR, non sono riaperti come questionario preliminare.

Il requisito del primo AD_dpr completo di fatturazione e incassi non è ridotto: la candidatura rende concreto il lavoro sul percorso end-to-end, mantenendo esplicite le integrazioni non ancora concluse.

## 31. Prime osservazioni del collaudo Windows e import per le prove

9 ottobre 2026. L’utente comunica che sta avviando la candidatura sul PC Windows; il messaggio non attesta ancora il completamento dell’installazione o del giro funzionale. Chiede se si possono importare dati Garda per facilitare i test. Nel pacchetto consegnato sono già presenti `IMPORTA_DA_GARDA_WINDOWS.bat`, `AVVIA_GARDA_WINDOWS.bat` e lo script di importazione iniziale, verificati nel contenuto effettivo dello ZIP.

L’import usa il dump completo ingecert, crea un archivio distinto `GestionaleAD_dati_GARDA` accanto alla cartella del programma e richiede che non vi sia già un database in quella destinazione. Comprende clienti, sedi, impianti, scadenze, preventivi e verifiche; utenti Garda disattivati e nuovo amministratore con password provvisoria da cambiare. Conserva i numeri e segnala gli elementi da controllare nel rapporto. Fatture/incassi, originali Word/PDF S3 e riallineamento incrementale restano esclusi. Non è attestata una nuova importazione o una modifica del PC dell’utente in questo turno.

**Osservazione R70:** il “salto” a VerbalizzAI come modulo distinto, con il comando “Torna al gestionale” in basso, non convince l’utente. L’utente precisa di non chiedere una modifica adesso: il tema è registrato per un successivo esame dell’esperienza operativa. Non viene trasformato in approvazione di una nuova schermata, di un adattatore relazionale o di una riscrittura del modulo. Il codice e il pacchetto 0.8.0 restano invariati; la copia del documento contenuta in quello ZIP è la 1.53, mentre questo documento aggiornabile è ora la 1.54.

## 32. Avvio dell’approfondimento AD_DM — classificazione e INAIL

9 ottobre 2026. L’utente decide di passare alla parte AD_DM, indica come complessa la categorizzazione SC/SP/GVR e ribadisce che la rendicontazione INAIL è essenziale (R71). Durante l’analisi chiede esplicitamente di non perdere le regole dei nomi di fatture, schede tecniche e verbali (R72). Si procede sul sorgente e sui dati Garda; non sono stati modificati applicazione, database operativo o pacchetto 0.8.0.

Il dump adsrl del 7 ottobre è stato riparsato per nove tabelle principali e i conteggi coincidono con lo staging: 9.346 attrezzature (SC 1.359, SP 258, GVR 7.729), 8.700 verifiche, 31 tipi, 6 famiglie GVR, 72 specifiche, 162 associazioni ammesse e 314 prezzi SC/SP/GVR. Il controllo dei conteggi non è un confronto integrale campo per campo. Nessun collegamento tipo mancante, disallineamento gruppo–tipo o abbinamento incompatibile con il catalogo ricevuto.

Garda distingue gruppo, tipo/categoria, famiglia GVR, specifica e fascia tariffaria. La famiglia GVR è derivata dal tipo; PED e gruppo fluido sono ulteriori dati tecnici. I codici esterni non sono globalmente univoci: RG e RV sono due voci interne diverse con lo stesso codice b1/famiglia a1. Il catalogo effettivo contiene modifiche alle periodicità rispetto all’inizializzazione PHP; non va sostituito o accorpato automaticamente. Per SC è presente un avviso oltre dieci anni nelle categorie previste; per GVR ci sono date e componenti distinte di funzionamento, integrità, interna e CND. Esistono anche insiemi, pacchi bombola e collegamenti alle valvole. Il numero DPR VP/VS non va riutilizzato come regola DM: nel codice DM i contatori annuali sono GVR e SC–SP.

La funzione INAIL richiede verifica effettuata/non ancora esportata, riferimento alla fattura e PDF di fattura/verbale, più scheda per prima verifica. Produce XLSX a 62 colonne e ZIP distinti, poi aggiorna flag e riferimento del lavoro. Può produrre un pacchetto parziale con warning. L’export legge diversi dati dalle anagrafiche/cataloghi correnti; il datore di lavoro resta quello dell’attrezzatura, distinto dall’eventuale intestatario terzo della fattura. Non contiene prova di accettazione da INAIL. Fra 7.683 verifiche oggi effettuate, 6.638 risultano esportate e 1.045 no; di queste ultime 37 non hanno riferimento alla fattura. Sono indicatori da interpretare, non un arretrato certificato. 53 lavori INAIL nel dump: 15 successo, 32 warning, 6 errore.

Il nome INAIL è prefisso esatto (`fattura`, `verbale`, `scheda tecnica`) + spazio + concatenazione dei componenti matricola e data prossima verifica in ddmmyyyy. L’Excel usa il nome senza estensione, lo ZIP con `.pdf`. Una fattura condivisa viene inserita una volta per tabella/ID e tutte le righe usano il nome della prima verifica che la incontra. Il salvataggio in effettuata rinomina verbali/schede; l’archivio mantiene il prefisso hash e suffissi per allegati multipli. Il generatore INAIL prende il primo PDF esistente per ID crescente, criterio distinto da “ultima revisione”. Le funzioni di stampa ordinaria adottano altri nomi e sanitizzazioni. Queste distinzioni diventano regole tracciate, non dettagli estetici rinviabili.

Rapporto separato `06_Analisi_Garda_AD_DM_SC_SP_GVR_INAIL_2026-10-09.md`: fonti, catalogo effettivo dei tipi, famiglie/specifiche/associazioni, colonne INAIL, regole N01–N14, eccezioni e limiti. Restano da chiarire categorie RG/RV e variazioni, esperienza di classificazione desiderata, più allegati/revisioni, omonimie nei pacchetti, prova su originali e verifica delle specifiche ufficiali correnti. La lettura del backup non certifica conformità normativa attuale. Nessun originale S3 scaricato.

Direzione proposta, da discutere: più prestazioni/scadenze sullo stesso bene, codici/cataloghi preservati, fotografia storica coerente con i requisiti degli emessi, rendicontazione e nomi degli allegati inclusi nel perimetro necessario alla messa in esercizio AD_DM. Non è stato approvato un nuovo modello di relazioni o un automatismo di classificazione. La copia quadro inclusa nel pacchetto 0.8.0 rimane 1.53; il documento aggiornabile passa a 1.55.

## 33. Regola generale di conservazione delle regole Garda

9 ottobre 2026. L’utente stabilisce espressamente che ogni regola presente in Garda che non venga riproposta, venga disattesa o derogata richiede una valutazione espressa e il suo consenso esplicito (R73). La regola vale per tutti gli ambiti del progetto, non soltanto per la classificazione DM o per i nomi degli allegati INAIL.

Criterio operativo: per ciascuna regola individuata si registra la fonte Garda e il comportamento riscontrato, il comportamento previsto nel nuovo sistema e lo stato di recepimento. Qualsiasi scostamento deve riportare la modifica proposta, la motivazione, gli effetti su dati/storico, flussi e documenti o integrazioni interessate, e l’approvazione esplicita dell’utente riferita a quella modifica. Prima del consenso resta una proposta da valutare; non diventa un’omissione o deroga adottata nel codice. L’approvazione deve essere riportata nel registro delle decisioni con il proprio ambito.

Una richiesta generica di procedere, semplificare, migliorare o riscrivere il gestionale non costituisce consenso a cambiare una regola particolare. Neppure l’etichetta di presunto difetto, ridondanza o incoerenza autorizza una modifica funzionale automatica: il riscontro viene presentato e discusso. Il lavoro indipendente di lettura, documentazione e recepimento delle altre regole può proseguire.

Le decisioni già esplicitamente acquisite rimangono valide nel loro ambito; vanno collegate alle regole Garda eventualmente modificate, senza richiedere nuovamente il consenso già dato né estenderlo ad altri casi. Le differenze non ancora valutate o approvate, comprese quelle eventualmente emerse nel prototipo, devono essere segnalate e risolte prima di dichiarare completo il relativo recepimento. Questa istruzione non attesta che tutta la candidatura 0.8.0 sia già stata confrontata regola per regola con Garda.

Il criterio riguarda le regole e il comportamento, non impone lo stesso linguaggio, le stesse tabelle fisiche o l’adattamento del PHP: resta confermata la nuova implementazione Python richiesta dall’utente.

Chiarimento successivo dell’utente: le deroghe rispetto a Garda sono ammesse e fisiologiche quando si integrano tre gestionali, con conseguenze sulla struttura del database e sulle interazioni reciproche. L’obiettivo è quindi riprogettare il nucleo comune preservando o modificando consapevolmente le regole, non riprodurre tre sistemi separati. Accorpamenti tecnici, chiavi comuni e collegamenti fra moduli appartengono al lavoro autorizzato di integrazione; non si richiede una conferma per ciascuna colonna, FK o dettaglio interno. Se una scelta altera una regola di business, un controllo, una responsabilità, una numerazione, una fotografia storica, un documento o un tracciato esterno, ne vanno esplicitati gli effetti e acquisita l’approvazione nel relativo ambito. La disponibilità ad ammettere deroghe non equivale all’approvazione indistinta di scostamenti non presentati. Si distinguono inoltre le scelte proposte dalle implementazioni effettivamente verificate. La difficoltà della classificazione DM non è stata ancora qualificata dall’utente come problema operativo di censimento; la domanda di chiarimento rimane aperta, senza presumere una richiesta di automatizzazione.

Documento quadro aggiornato alla versione 1.56. Nessuna modifica al codice applicativo in questo passaggio.

## 34. Classificazione AD_DM: importazione, censimento e variazioni nel tempo

9 ottobre 2026. L’utente chiarisce che in Garda la classificazione era compilata manualmente per ciascuna attrezzatura tramite maschere dedicate e non individua un problema operativo da risolvere: per le attrezzature importate si acquisisce la classificazione esistente, per quelle nuove si registra a mano (R74). Non viene richiesta una classificazione automatica né un assistente di classificazione.

L’utente segnala che alcune classificazioni cambiano nel tempo, citando le attrezzature SC che superano dieci anni, e precisa che il campo interessato è “Apparecchi all. 7”, non l’ID Specifica. Nel modello Garda corrisponde al tipo/categoria dell’attrezzatura. Il riscontro del codice distingue i campi: la vista `attrezzature_read` verifica anno corrente meno anno di costruzione maggiore di dieci per i tipi SC a2, a4, b2 ed espone `alert_tipo_attr`; la maschera mostra il relativo avviso. Nei tipi sono presenti le controparti a1, a3, b3 per le condizioni oltre dieci anni. Nel catalogo ricevuto le specifiche ammesse delle coppie a2/a1, a4/a3 e b2/b3 coincidono: il passaggio di età interessa quindi il tipo/categoria e non implica, da solo, un cambio dell’ID Specifica. Il riscontro è coerente con il chiarimento dell’utente; non corregge automaticamente le attrezzature né stabilisce una regola normativa nuova.

Recepimento previsto: importare fedelmente la classificazione presente, consentire censimento e aggiornamento manuali, mantenere la segnalazione già prevista per l’età, e preservare la fotografia nei verbali/documenti emessi secondo i requisiti storici acquisiti. Non sono approvati riclassificazione automatica, ricalcolo retroattivo delle scadenze o modifica automatica dei documenti o dei pacchetti INAIL già prodotti. Qualsiasi comportamento diverso segue la valutazione e il consenso esplicito R73.

Il chiarimento chiude la domanda sull’eventuale difficoltà di censimento. Il successivo approfondimento riguarda la pratica operativa della rendicontazione INAIL, mantenendo le regole già riscontrate e distinguendo eventuali proposte nuove. Nessuna modifica del codice in questo passaggio; documento quadro 1.58.

## 35. Approfondimento progressivo per l’integrazione e cadenza INAIL

9 ottobre 2026. L’utente ribadisce di lavorare passo passo per integrare anche AD_DM e I&C. Si mantengono il nucleo comune come obiettivo e l’ordine di attivazione già concordato, con DPR validato nell’uso prima dell’attivazione dei moduli successivi. Ogni approfondimento parte dai riscontri Garda e dalle decisioni acquisite; le eventuali modifiche delle regole restano soggette a R73. Questa istruzione non autorizza una riscrittura delle regole o un’attivazione immediata degli altri moduli.

L’utente conferma che l’esportazione INAIL è trimestrale, richiamando il D.M. 11.04.2011 (R75). Si registra la cadenza come requisito operativo confermato. Il generatore Garda analizzato prende le verifiche selezionate in griglia e non impone da sé un trimestre fisso: ciò non contraddice l’organizzazione trimestrale del lavoro. Il criterio esatto di selezione del periodo, le condizioni di completamento e la gestione dei casi rimasti esclusi vanno ricostruiti senza introdurre deroghe implicite.

Riscontro utile per il prossimo punto: la funzione `gi_verifiche_esporta_inail` richiede riferimento alla fattura e disponibilità del relativo PDF; se il riferimento manca, interrompe l’elaborazione di quella verifica con errore, mentre il framework può continuare sulle altre. Questo vincolo è presente in Garda, non viene proposto come nuova regola. L’utente chiarisce che le verifiche non ancora fatturate vengono incluse nella rendicontazione del trimestre successivo e chiede di non appesantire la gestione (R76). Si conserva questa prassi semplice: rimangono da rendicontare, senza cambiare la data reale della verifica o marcarle come esportate prima della produzione del pacchetto. Nessun nuovo flusso di eccezione introdotto. Nessuna modifica applicativa; documento quadro aggiornato a 1.61.


### 35.1 Caricamento dei pacchetti INAIL

L’utente conferma che Excel e ZIP sono caricati manualmente sul portale INAIL denominato “A.S.A.” (R77). Il gestionale deve conservare la produzione dei pacchetti compatibili con questo lavoro manuale, comprese codifiche e nomi degli allegati già documentati. Non è richiesta un’automazione del caricamento. La denominazione del portale e la prassi sono confermate dall’utente; in questo passaggio non si è consultato o usato il portale. La generazione del pacchetto e la sua acquisizione da parte del portale sono eventi distinti; non viene introdotto uno stato aggiuntivo di approvazione né una nuova registrazione obbligatoria. Nessuna modifica applicativa; documento quadro 1.62.


## 36. Generatore Garda AD_DM — compilazione GVR, storico e stampa

L’utente conferma l’uso del generatore Garda e chiarisce che VerbalizzAI ne riprende l’impostazione. Per GVR il generatore legge dati dell’entità attrezzatura e propone alcuni dati dai precedenti; seguiranno una spiegazione operativa e un verbale reale. La richiesta attuale è una lettura attenta delle regole, svolta senza modificare codice applicativo o dati operativi (R78).

È stato seguito il percorso completo: permessi per generare dalla riga di preventivo accettata e riesaminata conforme; scelta tecnico; creazione assegnata; copia selettiva dei precedenti; copia della scheda tecnica; controlli e aggiornamenti al salvataggio; ricalcolo scadenze; selezione del modello e motore Word/PDF. Le condizioni sono distribuite fra metadati, gestori PHP e framework: la mancanza di un controllo nel solo corpo di una funzione non equivale alla sua assenza nel flusso.

Il punto centrale è la pluralità delle fonti. La configurazione GVR arriva dalla scheda corrente; i precedenti sono distinti per funzionamento, integrità e visita interna. Accessori e dispositivi provengono dal precedente funzionamento; lo stato delle tubazioni dal più recente integrità/interna; le osservazioni da un solo precedente pertinente, ordinato per data e ID. Acqua/conduttore hanno condizioni legate alla famiglia a2. Non viene copiata integralmente la vecchia configurazione del verbale, né risulta una proposta automatica dei suoi Pes/Tes nella nuova verifica: i dati di esercizio sono propri della verifica e possono essere conservati nel riallineamento della verifica già compilata se include funzionamento. Capacità come somma dei volumi a un decimale.

La chiave di abbinamento delle righe tecniche è descrizione/n.f. normalizzati. Alcune modifiche a configurazione, breve descrizione e descrizione del tipo aggiornano la scheda già negli stati aperti o nel passaggio a effettuata, poi riallineano i lavori aperti. Le proposte dallo storico vengono aggiornate soltanto se non ancora salvate secondo `last_update_nr=0`, mentre i dati tecnici della scheda possono aggiornare tutte le verifiche aperte. Questo comportamento non equivale a un aggiornamento esclusivamente dopo la finalizzazione. Importante omonimia: `attrezzature.tipo_attr` è la categoria “Apparecchi all. 7”, `verifiche.tipo_attr` è la descrizione testuale del verbale.

Stampa: modello scelto dagli allegati in configurazione, non necessariamente dai DOCX inclusi nel sorgente; trasformazioni specifiche con `///` per i testi non applicabili, campi acqua/conduttore e superficie/producibilità condizionati; sezioni JSON ripetute e conversione LibreOffice. Il report combina dati salvati della verifica e anagrafiche correnti. Non costituisce una fotografia integrale sufficiente a garantire da sola il requisito degli emessi immutabili. Il codice di aggancio automatico del PDF generato alla verifica è commentato: il percorso reale di caricamento/finalizzazione va confrontato con l’esempio dell’utente.

Riesame e indipendenza: nel gestore DM letto il riesame negativo richiede nota, ma non si è riscontrato il ritorno automatico a registrata né uno storico dedicato completo; traccia ultimo utente/data su cambio di flag/esito. Questi riscontri vanno confrontati con i requisiti comuni già acquisiti, senza dichiarare che siano già Garda DM o cambiare implicitamente le regole. La dichiarazione di indipendenza ha default T anche nello schema SQL; non è stato individuato nei gestori personalizzati letti un blocco effettivo sulla sua esclusione. Serve una prova mirata del percorso, non una conclusione sulla policy dal solo dato storico.

Riscontri diagnostici: 7.729 attrezzature GVR, 4.203 con configurazione JSON non vuota; 6.711 verifiche GVR, 3.516 con configurazione non vuota. Nessun JSON invalido nei campi analizzati; chiavi tecniche duplicate in 60 attrezzature e una verifica; Pes/Tes presenti anche in sette schede. Nessuna discordanza nel confronto della capacità calcolabile delle verifiche, con la metodologia dichiarata nel rapporto. Nessuna correzione automatica. Duplicazioni, campi vuoti e dati storici non autorizzano scarti in migrazione o nuove regole funzionali.

Rapporto separato `07_Regole_Garda_generatore_verbali_AD_DM_GVR_SC_SP_2026-10-09.md`: fonti, 43 regole G01–G43, matrice delle sette combinazioni GVR, campo per campo dei precedenti, trasformazioni di stampa, aggiornamenti della scheda, numerazione/riesame/allegati, inventario dei campi e punti per il confronto operativo. Le regole N01–N14 dei nomi documentali restano nel rapporto 06. L’analisi è statica, con riscontri sul backup in sola lettura; nessuna esecuzione del PHP, conversione reale o lettura degli originali S3. I modelli attivi risultano configurati ma i loro originali non sono disponibili localmente. Nessuna nuova decisione di architettura o deroga funzionale adottata; documento quadro 1.63.


## 37. Attributi GVR, SC e SP e modelli Word ricevuti

9 ottobre 2026. L’utente fornisce i modelli Word GVR e SC/SP e precisa che per capire il generatore bisogna guardare gli attributi delle attrezzature (R79). Sono stati letti i campi della scheda, le viste, la selezione della classificazione e le regole di salvataggio, e confrontati con tutti i segnaposto dei modelli. I Word contengono segnaposto, non i dati di una verifica già emessa. Il confronto dei file conferma identità byte per byte con i modelli inclusi nel backup e dimensioni coincidenti con gli allegati configurati. Renderizzazione e ispezione visiva: GVR non compilato due pagine, SC/SP una. Non è una prova di generazione PHP o di impaginazione con dati reali; nessun originale S3 scaricato.

La base comune comprende identità, sede/cliente, matricole, costruttore, modello, anno, descrizione, riferimenti, CE e stati dell’attrezzatura. La classificazione distingue tipo All. VII, specifica compatibile, famiglia GVR derivata e descrizione libera del tipo per il verbale. I codici guidano anche caselle del report, tariffari, scadenze e INAIL; l’insieme degli attributi necessari non coincide quindi con i soli campi stampati nel Word.

GVR ha due livelli tecnici: caratteristiche generali (PS, volume, TS, superficie/producibilità, gruppo fluido, PED, soggezione messa in servizio, insieme/pacco bombola) e JSON con camere/componenti. La configurazione della scheda contiene nove attributi statici per riga; la verifica ne aggiunge due, Pes/Tes, e il modello ripete undici valori. La capacità del verbale deriva dai volumi delle righe; non viene copiata dal volume generale. Nel percorso letto non c’è sincronizzazione automatica PS/volume/TS generali↔valori delle camere: il significato dei due livelli va chiarito prima di proporre uguaglianze o derivazioni. Sono presenti schede con dati generali ma senza camere e non si inventano configurazioni in importazione.

SC e SP condividono la struttura tecnica della scheda (portata, numero panieri per i casi pertinenti), il modello e i cinque testi della verifica; le caselle di categoria sono calcolate da gruppo/tipo e in alcuni casi specifica. La portata stampata arriva dalla scheda. I testi tecnici del verbale sono dati della verifica e alcuni vengono riproposti dal precedente, secondo il rapporto 07. Non si è deciso di sostituirli con una nuova struttura di componenti.

La tabella fisica attrezzature ha 73 colonne, incluse colonne storiche con nomi precedenti; i campi letti da vista e quelli annidati nel JSON non sono altrettante colonne. Si è documentato l’inventario della maschera e mantenuta la distinzione. Nessun campo storico viene eliminato o ridenominato automaticamente. Maschera e gestore proteggono date/tipo prossimo quando esiste lo storico collegato e trattano esplicitamente i campi del diverso gruppo.

Tariffe: il gestore GVR sceglie specifica e colonna V1–V4, distinguendo la soggezione messa in servizio nelle prime periodiche e componente F/interna rispetto a integrità/multipla nelle successive. SC/SP usa associazione tipo/specifica e V1/V2. Non è stato trovato un ricalcolo diretto del prezzo da PS×volume o portata nel gestore. La classificazione rimane manuale come già confermato. INAIL utilizza anche attributi non stampati, fra cui soggezione messa in servizio e panieri nei casi previsti.

Rapporto 07 aggiornato a 1.1 con sezione 12, regole degli attributi A01–A10, matrice delle caselle SC/SP, identificazione dei due modelli e inventario completo della maschera in appendice C. Il primo punto sul significato del volume generale GVR è stato successivamente chiarito in R80 e nella sezione 38. Nessuna nuova regola di uguaglianza o aggiornamento adottata, nessuna modifica applicativa; documento quadro 1.64. La sezione 36 resta il resoconto della prima analisi, con i limiti successivamente aggiornati dai modelli ora ricevuti.


## 38. Volume GVR e DN delle tubazioni

9 ottobre 2026. L’utente conferma che il volume generale corrisponde alla somma dei volumi delle camere e precisa che una tubazione non ha V in litri, ma DN in mm; in tal caso non contribuisce al totale. Invita a verificare il codice Garda che già implementa questi aspetti (R80). La domanda sul significato del volume è chiusa e non resta aperta una diversa interpretazione del campo.

Riletti i due percorsi del calcolo nel sorgente adsrl: `gi_verifiche_save_before` somma il solo `gvr_vol` delle righe mediante `bcadd` a un decimale; `copia_dati_attrezzatura_su_verifica` somma il medesimo campo nella configurazione indicizzata. Il DN non viene sommato né convertito in litri. Il modello e i metadati mantengono Volume e DN separati. Nei due cicli non compare un filtro esplicito sulla categoria tubazione: il comportamento deriva dalla selezione del campo volume e dalla rappresentazione delle righe con DN distinto. Restano valide le regole già documentate di indicizzazione delle camere, precisione e riporto dei dati tecnici.

Si distingue il significato tecnico confermato dall’utente dall’esistenza di un ulteriore automatismo: nei percorsi letti il totale è scritto in `verifiche.gvr_capacita`, non si è individuata una sincronizzazione automatica aggiuntiva di `attrezzature.volume_attr_gvr`. Il chiarimento non autorizza nuovi blocchi, normalizzazioni o ricalcoli dei dati importati, né modifica i documenti emessi. Rapporto 07 aggiornato a 1.2 con A11 e chiusura del chiarimento. Nessuna modifica applicativa; documento quadro 1.65.


## 39. GVR — il preventivo determina tariffa e composizione del verbale

9 ottobre 2026. L’utente chiarisce che numero e composizione dei verbali dipendono dalla prestazione preventivata: separate producono due verbali, una multipla produce un verbale unico. Richiama le quattro distinzioni del tariffario ministeriale GVR e chiede di leggere attentamente la logica Garda già esistente (R81). La domanda su uno o due verbali è chiusa; non serve ridefinire una scelta che appartiene al preventivo.

Riletto il percorso completo tariffario→salvataggio riga→creazione verifica→stampa: la maschera delle righe prevede i sette tipi GVR, incluse le combinazioni. Il generatore trasferisce il tipo e le tariffe standard/applicata alla verifica, mantiene `preventivo_riga` e aggiorna il collegamento inverso. Una riga multipla genera una verifica unica con quelle componenti; due righe separate restano due lavori e due verbali. La stessa testata di preventivo, il giorno della verifica, il sito o la fattura non sono criteri autonomi di fusione.

Le etichette delle quattro colonne sono confermate direttamente in `tariffe_gvr.js`: V1 prima periodica art.4, V2 prima periodica art.5, V3 successiva funzionamento/visita interna, V4 successiva integrità/multipla. `calcola_tariffa_standard` sceglie V1 con soggezione messa in servizio T per una prima periodica, altrimenti V2; per successiva sceglie V3 soltanto con tipo esattamente funzionamento o interna, altrimenti V4 per i tipi supportati. Prezzo cercato per specifica e colonna, non somma dei singoli prezzi. Attenzione: V1/V2 del tipo verifica significano prima/successiva, mentre V1–V4 del tariffario sono colonne con significato diverso. Questi codici non devono essere accorpati per sola omonimia nel nucleo comune. Il richiamo normativo è registrato come etichetta applicativa e chiarimento dell’utente, senza verifica degli importi o delle norme correnti.

Il batch dei preventivi da scadenze usa `$merge=false`, distinto dalla possibilità di scegliere una prestazione multipla nella riga: il batch non fonde automaticamente le nuove righe né i verbali durante l’assegnazione. Sono stati riletti controlli sul tipo GVR, standard positivo, flag di ricalcolo, agganci e ripreventivazione accettata aperta, con limiti dei confronti annotati nel rapporto. Catalogo ricevuto: 33 tariffe per ciascuna colonna, 132 totali. Il dump contiene righe GVR singole; ciò non autorizza a eliminare le combinazioni supportate dal codice e confermate dall’utente.

Rapporto 07 aggiornato a 1.3: regole G44–G48 e sezione 13 con matrice delle quattro colonne, esempi di righe e verbali, controlli e limiti. Il recepimento conserva la logica del preventivo, tariffazione, scadenze e dati INAIL, secondo R73. Nessuna implementazione o deroga funzionale introdotta; documento quadro 1.66.

## 40. Logiche Garda DM e I&C e conseguenze del database unico

9 ottobre 2026. L’utente ribadisce che, in particolare per AD_DM e I&C, il codice Garda contiene tutte le logiche fondamentali. È il riferimento funzionale da ricostruire prima di implementare i corrispondenti moduli del nuovo sistema (R82). Non si richiede una riscrittura del PHP né una replica delle tre strutture fisiche: restano confermati la nuova applicazione Python e il nucleo comune. Questa indicazione è un criterio di lavoro e non una dichiarazione di verifica già conclusa di tutte le logiche DM e I&C.

Per ogni funzione si parte dalle fonti Garda pertinenti: maschere e metadati, controlli, hook, batch, viste, cataloghi, database e generazione dei documenti. Si documentano fonte, comportamento osservato, recepimento previsto e verifica effettuata. Una regola non individuata nel percorso letto non viene automaticamente dichiarata assente dal sistema; l’analisi deve seguire i collegamenti necessari. Si chiedono chiarimenti all’utente quando le fonti non risolvono il punto o quando si propone un cambiamento funzionale, evitando di fargli ridefinire regole già codificate.

La ristrutturazione di entità e relazioni per il database unico rientra nel lavoro autorizzato di integrazione. Per le scelte significative si esplicitano il modello precedente e quello proposto, la motivazione, le conseguenze sulla migrazione e sull’uso, le regole conservate e gli eventuali scostamenti da sottoporre a valutazione. Non serve una nuova decisione per ogni colonna o chiave interna. La distinzione non dipende dalla dimensione tecnica della modifica: anche una piccola modifica che cambi una regola operativa va trattata secondo R73, mentre una riorganizzazione ampia che conservi il comportamento può essere tecnica.

| Area di integrazione | Conseguenze da rendere esplicite |
|---|---|
| Clienti e sedi comuni | Identificativi canonici e corrispondenze con sistema e ID originali; criteri di riconciliazione dei duplicati, senza fusioni basate soltanto sul nome. Le modifiche dell’anagrafica corrente devono preservare le fotografie nei documenti emessi secondo le decisioni già acquisite. |
| Attrezzature e impianti | Quali dati identificativi e tecnici sono condivisi e quali restano propri del modulo. Classificazioni, camere GVR, DN, periodicità, prestazioni e dati INAIL devono mantenere il significato previsto dalle regole Garda e dalle decisioni approvate. |
| Preventivi, incarichi, verbali e documenti | Nuove relazioni fra entità comuni e specifiche, preservando composizione delle prestazioni, riesami, numerazioni, regole di emissione e nomi degli allegati. Un collegamento comune non implica accorpamento automatico di attività o documenti. |
| Ambiti, soggetti emittenti e permessi | Separazione delle competenze operative, delle serie e degli accessi dove richiesta. Non si assume che i tre database corrispondano automaticamente a tre soggetti giuridici né che una sola anagrafica renda indistintamente visibili tutti i dati. |
| Migrazione e convivenza | Origine dei record, collegamento degli ID preesistenti, stabilità delle chiavi fra reimportazioni, trattamento dei conflitti e quadrature. Le conseguenze vanno valutate anche per dati storici e collegamenti ai documenti, senza richiedere ora gli originali S3. |

Ogni cambiamento effettivo di flussi, controlli, tariffe, responsabilità, serie, documenti o rendicontazione deve essere presentato con le sue conseguenze e ricevere il consenso esplicito previsto da R73, salvo decisioni già acquisite nel relativo ambito. Le alternative strutturali ancora da definire restano proposte: questa sezione non adotta un nuovo schema né dichiara completata l’integrazione.

Documento quadro aggiornato alla versione 1.67. Nessuna modifica al codice applicativo o ai database in questo passaggio.

## 41. Primo passaggio operativo DM — scadenze GVR per componente

9 ottobre 2026. Si prosegue un punto alla volta, seguendo il codice Garda prima di chiedere decisioni. Questo passaggio consolida la lettura statica del collegamento fra prestazione della riga di preventivo, verifica, scadenze dell’attrezzatura e data della rendicontazione. Sono riscontri del sorgente, non nuove decisioni dell’utente e non nuove implementazioni.

### 41.1 Distinzioni funzionali da mantenere

| Concetto | Regola osservata in Garda | Fonte |
|---|---|---|
| Prestazioni del verbale GVR | Il tipo, già copiato dalla riga di preventivo, può includere funzionamento, integrità e interna nelle sette combinazioni supportate. Una verifica multipla resta un solo record/verbale con più componenti. | `cust/lavori_batch_cli.php`, `gi_preventivi_righe_verifiche_genera`; R81 e sezione 39 |
| Date delle componenti svolte | I campi della verifica `data_prox_funz`, `data_prox_integrita`, `data_prox_interna` sono modificabili secondo permessi; vengono mostrati quelli pertinenti alla prestazione e sono obbligatori quando la verifica è registrata o effettuata. Nei percorsi letti non è introdotto un calcolo normativo automatico delle periodicità. | `cust/meta/verifiche.js:672–795`; `cust/meta/_custom.js:454–521`; `cust/_custom.php:1440–1586` |
| Data sintetica della verifica | `data_pvp` è calcolata come minimo delle prossime date delle sole componenti incluse nella prestazione corrente. Non è il minimo di tutte le scadenze dell’attrezzatura e non coincide necessariamente con quella di funzionamento. | `gi_verifiche_save_before`, righe 1564–1586 |
| Ultimo verbale per componente | La scheda recupera separatamente l’ultima verifica effettuata che comprende funzionamento, integrità o interna, ordinata per data rilascio decrescente. Le verifiche multiple partecipano a ciascuna delle componenti che includono. | `ricalcola_scadenze_attrezzatura`, righe 2617–2646 |
| Scadenzario dell’attrezzatura | Conserva righe distinte per funzionamento, integrità e interna quando la relativa prossima data è presente; comprende inoltre le scadenze CND e delle valvole nei rispettivi percorsi. Il riferimento V1/V2 delle scadenze periodiche dipende anche dalla prima data e dal tipo prossimo dell’attrezzatura. | Stessa funzione, righe 2679–2858 |
| Date delle componenti non svolte | Le verifiche GVR aperte, assegnate/programmate/registrate, ricevono dalla scheda le date delle componenti non modificabili perché esterne alla prestazione. La presenza fisica di tali date nel record non significa che quelle attività siano state eseguite nel verbale corrente. Il salvataggio azzera prima le date non pertinenti; il successivo aggiornamento delle verifiche aperte può riproporle. | `aggiorna_date_gvr_verifiche_non_effettuate:1642–1684`; `gi_verifiche_change_after:2289–2295` |
| Collegamento alla riga di preventivo | Lo scadenzario mantiene o ricerca una riga compatibile con attrezzatura, V1/V2 e componente, con verifica ancora aperta oppure assente e riga non rifiutata. Una riga multipla può essere compatibile con più componenti senza fondere le righe di scadenza. | `ricalcola_scadenze_attrezzatura:2815–2856` |
| Data nell’Excel INAIL | L’export usa il `data_pvp` della verifica, formattato giorno/mese/anno. Non lo ricalcola come minimo dello scadenzario corrente dell’attrezzatura. Richiede verifica effettuata, non già esportata, e fattura collegata; le altre regole di documenti, nomenclatura e tracciato restano quelle del rapporto 06. | `gi_verifiche_esporta_inail`, `cust/lavori_batch_cli.php:735–775,793–794` |

Il ricalcolo dello scadenzario viene richiamato dopo le modifiche della verifica, ma i riferimenti all’ultima verifica periodica si basano su quelle in stato effettuata. La data sintetica del record viene invece già calcolata per lo stato registrata: non si confondono questi due momenti.

### 41.2 Esempio illustrativo, senza fissare nuove periodicità

Supponiamo che una prestazione comprenda funzionamento e integrità. Il tecnico indica, per quelle componenti, prossima funzionamento 09/10/2028 e prossima integrità 09/10/2036. Una visita interna non inclusa nella prestazione conserva sulla scheda una scadenza precedente, 09/10/2027.

Il risultato atteso dal percorso Garda letto è:

- un solo verbale di funzionamento + integrità, secondo la prestazione preventivata;
- data sintetica di quel verbale e dell’Excel INAIL 09/10/2028, perché il minimo riguarda soltanto funzionamento e integrità;
- scadenzario dell’attrezzatura con interna 09/10/2027, funzionamento 09/10/2028 e integrità 09/10/2036;
- la visita interna non risulta eseguita per la sola presenza della sua data sulla scheda o su una verifica aperta.

Le date sono inventate per mostrare la distinzione, non sono una proposta di periodicità normativa o un esempio verificato eseguendo il PHP.

### 41.3 Conseguenza per il modello unificato

La futura struttura deve poter rappresentare una verifica con più componenti e le scadenze distinte delle componenti dell’attrezzatura. La data sintetica del verbale va conservata con il suo significato storico, evitando di sostituirla con la prima scadenza corrente dell’intero bene. È un vincolo funzionale ricavato dal codice; questa lettura non decide ancora fra colonne dedicate e relazioni figlie nel database comune. Anche se le scadenze vengono rappresentate con una struttura comune DPR/DM/I&C, tipo della prestazione, contenuto dei documenti e regole INAIL rimangono distinti secondo il relativo ambito.

Punti già annotati nel rapporto 07 restano da valutare espressamente prima di eventuali correzioni: ordinamento delle ultime verifiche per sola data senza spareggio ID; mancata cancellazione esplicita dei riferimenti della stessa componente quando non rimane alcuna verifica effettuata. Il sorgente non prova, da solo, un malfunzionamento operativo in ogni caso. Non sono stati corretti né derogati in questo passaggio.

Rilette anche le etichette del tipo GVR esportato: le singole componenti derivano dal catalogo attrezzature; per le multiple esistono testi dedicati. Funzionamento + integrità sceglie biennale/triennale/quadriennale/quinquennale dal testo catalogo; funzionamento + interna e la tripla usano testi biennali fissi nel sorgente. Queste particolarità vanno conservate nel catalogo di recepimento ed eventualmente valutate, senza sostituirle ora con un generatore di descrizioni diverso. Fonte: `cust/lavori_batch_cli.php:808–840`. Non si esprime qui un giudizio di conformità del tracciato alle specifiche INAIL attuali.

Documento quadro 1.68; registro delle decisioni invariato R01–R82. Nessuna modifica al software o ai database. Il passaggio successivo resta circoscritto: completare il riscontro della selezione per la rendicontazione trimestrale e delle regole dei pacchetti Excel/ZIP, distinguendo quelle già documentate da eventuali punti realmente da decidere.

## 42. Rendicontazione INAIL — selezione, pacchetti e primo dubbio da decidere

9 ottobre 2026. L’utente autorizza a proseguire descrivendo ogni passaggio e a fermarsi soltanto per chiedere in caso di dubbi (R83). È stata completata la rilettura statica del percorso di esportazione nel sorgente adsrl; non sono stati avviati lavori sul vecchio gestionale né recuperati file S3. Il rapporto 06 rimane il catalogo dettagliato del tracciato e delle regole N01–N14 sui nomi, da conservare.

### 42.1 Selezione e prerequisiti

L’azione nella griglia avvia un lavoro batch sulle verifiche selezionate o sull’insieme indicato dall’azione generica, con controllo dei permessi. Nella funzione personalizzata non è imposto un trimestre di calendario: il periodo viene gestito mediante la selezione operativa. Fonte: `cust/meta/_custom.js:427–451`, `cust/meta/verifiche.js:79–81,117–128` e `std/fw/gi_batch.php:23–118`.

Il singolo record deve risultare effettuato, avere flag esportazione F ed essere collegato a una fattura. Si supportano fatture storiche e fatture clienti elettroniche, con i rispettivi campi PDF. Sono richiesti PDF verbale e fattura; per V1 anche scheda tecnica. Un record/file collegato nel dump non prova la disponibilità dell’originale. Sono controllati campi obbligatori e lunghezze del tracciato, con condizioni GVR, esito Sospeso, V1 e numero panieri per le voci SC pertinenti. Fonti: `cust/lavori_batch_cli.php:735–775,884–933,980–1033`.

Il riesame conforme non compare come controllo dedicato nella funzione export letta: non se ne introduce ora uno nuovo né si conclude che il controllo manchi in ogni percorso applicativo. Il requisito funzionale del nuovo sistema e i blocchi del ciclo ordinario vanno confrontati con le regole e le decisioni già acquisite prima di adottare ulteriori condizioni.

Resta confermata la scelta operativa dell’utente R75–R77: rendicontazione trimestrale; verifiche non fatturate riprese nel trimestre successivo senza alterarne le date; Excel e ZIP caricati manualmente su ASA. Non si richiede una nuova scelta su questi punti. Il codice letto richiede la fattura ma non un controllo dedicato dell’incasso: fatturazione e pagamento non vengono equiparati.

### 42.2 Produzione dei file e nomenclatura

Il lavoro genera XLSX con 62 colonne nel sorgente ricevuto, intestazioni alla riga 2 e dati dalla riga 3. Produce ZIP verbali e fatture, e ZIP schede tecniche quando ne sono state aggiunte. L’ordine, i tipi delle celle, i campi e i nomi sono quelli ricostruiti nel rapporto 06; questa rilettura non certifica l’allineamento del vecchio generatore alle specifiche INAIL attuali.

Per i PDF la funzione `gi_inail_filename_gen` concatena i componenti della matricola memorizzati con giorno, mese e anno della prossima verifica sintetica `data_pvp`. I prefissi sono `verbale `, `fattura ` e `scheda tecnica `; l’Excel riporta il nome senza estensione e lo ZIP aggiunge `.pdf`. Gli zeri presenti nella matricola sono conservati e non si cambia la data di riferimento con quella di esecuzione o di fattura. Le fatture sono deduplicate per tabella di origine e ID all’interno del lavoro, utilizzando il nome assegnato al primo incontro. Nomi ordinari di download/stampa e nomi dei pacchetti INAIL sono distinti. Fonti: `cust/_custom.php:2299–2311`; `cust/lavori_batch_cli.php:884–933,1053–1062,1085–1103`; regole N01–N14 del rapporto 06.

### 42.3 Esiti e storia dell’esportazione

Il framework gestisce gli errori sui singoli record e può completare il lavoro con un pacchetto parziale e segnalazioni. La lista degli ID esportati viene aggiunta dopo l’elaborazione riuscita del record. Al termine vengono salvati i file e poi aggiornati, per quegli ID, flag esportazione T e riferimento al lavoro. Non si attribuisce a questo percorso una transazione atomica unica né un rollback complessivo non dimostrato dalla lettura. Fonti: `std/fw/gi_batch.php:95–206`; `cust/lavori_batch_cli.php:1065–1116`.

Il significato del flag è pacchetto generato, non caricamento né accettazione su ASA. Per riesportare Garda richiede di rimettere manualmente il flag a No; la maschera lo rende modificabile con `edit_verifiche`. Il riferimento al lavoro è in sola lettura. Gli output dei lavori precedenti non vengono descritti come nuovi esiti del portale. Questo passaggio non aggiunge nuovi stati o una procedura di caricamento automatica. Fonti: `cust/meta/verifiche.js:945–975`; `cust/lavori_batch_cli.php:744–747,1107–1109`.

### 42.4 Proposta INAIL-01 — ritirata dopo il chiarimento R84

**Stato aggiornato:** la proposta seguente è conservata soltanto come traccia del confronto. È ritirata: la sezione 43 e R84 chiariscono che i codici sono attributi dell’attrezzatura, non una classificazione contenuta nel verbale.

L’export rilegge l’attrezzatura da `attrezzature_read`; la vista risolve codice tipo, famiglia GVR e ID Specifica dai cataloghi e dagli agganci correnti. Poi copia i codici nel tracciato. Fonte: `cust/gi_views.php:83–96`; `cust/lavori_batch_cli.php:749–753,777,804–805,852`. L’alert sull’età SC non riclassifica automaticamente: la classificazione è mantenuta manualmente, come R74. Questo dubbio riguarda un cambio manuale intervenuto tra verifica ed esportazione, non un automatismo da introdurre.

Esempio: dopo una verifica SC si aggiorna la voce Apparecchi all. 7 della scheda perché l’attrezzatura è passata alla categoria pertinente oltre dieci anni. Se la verifica precedente viene esportata in seguito, il percorso Garda letto usa il codice della scheda aggiornata. Il requisito già acquisito tutela i verbali emessi e i pacchetti già prodotti, ma non risolve espressamente quale classificazione usare per un primo export successivo al cambio della scheda.

| Aspetto | Garda nel percorso letto | Proposta da valutare, non approvata |
|---|---|---|
| Classificazione della verifica da rendicontare | Codici ottenuti dalla scheda e dai cataloghi correnti al momento dell’export. | Conservare nella fotografia della verifica i codici della classificazione utilizzata nel verbale; usare questi codici per rendicontare quella verifica. |
| Scheda corrente | Rimane aggiornabile manualmente secondo la classificazione attuale. | Rimane aggiornata e governa le nuove attività; il suo aggiornamento non sostituisce i codici delle verifiche già emesse. |
| Effetto per gli operatori | Una modifica di classificazione prima dell’export può cambiare il contenuto della riga da rendicontare. | Per le nuove verifiche non serve una seconda classificazione manuale: il congelamento usa quella del verbale emesso. La regola evita cambi retroattivi nel tracciato per sole modifiche della scheda. |
| Storici importati | Il vecchio record non contiene necessariamente una fotografia completa dei codici storici. | Non ricostruire valori storici per supposizione: conservare le evidenze disponibili e definire separatamente come trattare quelli privi di fotografia. Non servono ora nuovi originali S3 per decidere la regola futura. |

La proposta modifica il comportamento di lettura del generatore Garda; richiede valutazione e consenso esplicito R73. L’estensione agli altri dati dell’export, alle correzioni di errori e alle eventuali riesportazioni non è implicitamente decisa dalla scelta sulla classificazione. Il punto viene presentato all’utente prima di qualsiasi implementazione. Non è una conclusione normativa su quale codifica imponga oggi il portale.

**INAIL-01 chiusa, proposta ritirata:** mantenere la classificazione letta dagli attributi correnti dell’attrezzatura, secondo il chiarimento R84 e la sezione 43. La precedente ipotesi di una classificazione da riprendere dal verbale non corrisponde al funzionamento descritto dall’utente.

Documento quadro 1.69; R83 registra soltanto il metodo di prosecuzione richiesto. Nessuna modifica applicativa, ai database, agli archivi originali o alle regole INAIL adottata. Il lavoro si ferma sul dubbio INAIL-01, con una proposta concreta e i suoi effetti descritti.

## 43. INAIL — classificazione dell’attrezzatura, chiarimento definitivo

9 ottobre 2026. L’utente chiarisce che il passaggio oltre dieci anni modifica correttamente la categoria Apparecchi all. 7 negli attributi dell’attrezzatura. Fornisce l’esempio della gru a ponte in ambiente ordinario sotto dieci anni con periodicità triennale. Si registra l’esempio come spiegazione operativa dell’utente, senza effettuare in questo passaggio una verifica normativa delle periodicità.

All. 7, ID Specifica e gli altri attributi di classificazione utilizzati nell’export INAIL appartengono all’attrezzatura. Il verbale non riporta quei codici come ipotizzato nella proposta INAIL-01. Il chiarimento esclude espressamente da questo ragionamento le date e gli altri dati della verifica.

Si conserva quindi la provenienza già presente in Garda:

| Dati di rendicontazione | Provenienza da conservare |
|---|---|
| All. 7, ID Specifica, famiglia e attributi di classificazione | Scheda attrezzatura e relativi cataloghi, secondo il percorso Garda. |
| Prestazione eseguita, date, esito e prossima verifica sintetica | Record della verifica e calcoli già ricostruiti. |
| Fattura e PDF allegati | Documenti collegati con le regole di selezione e nomenclatura già documentate. |

La proposta di congelare i codici per rendicontare la categoria ipoteticamente contenuta nel verbale viene ritirata. Non si costruisce una nuova storicizzazione della classificazione per questo scopo e non si riapre la scelta manuale di classificazione acquisita con R74. Restano tutelati i verbali emessi e i file dei pacchetti già generati: questo chiarimento riguarda l’origine dei dati quando si prepara l’export, non una modifica dei documenti già prodotti. Il riscontro del codice corrente rimane valido; era superflua la modifica progettuale proposta dall’assistente.

R84 registra il chiarimento; INAIL-01 è chiusa. Nessuna modifica applicativa effettuata.

## 44. Ponte Garda AD_DM–I&C e struttura dei preventivi I&C

9 ottobre 2026. Prosegue l’analisi in sola lettura del codice e della copia SQLite IEC. Questo è il primo riscontro approfondito dei percorsi qui elencati, non un audit completo di tutte le logiche I&C. I dati aggregati si riferiscono al backup ricevuto e non sono prova dello stato degli originali allegati.

### 44.1 Il collegamento esiste già e va migrato

Garda contiene un flusso bidirezionale: AD_DM fornisce a I&C le scadenze CND, indagini supplementari e tarature; I&C restituisce le date di esecuzione e prossima scadenza delle attività completate da sincronizzare. L’endpoint DM aggiorna i campi CND/supplementare dell’attrezzatura o le date della valvola e richiama gli aggiornamenti delle scadenze. Poi restituisce le scadenze correnti dei tre tipi, con i clienti e le sedi pertinenti. Non invia in questo percorso le verifiche periodiche GVR o SC/SP come attività I&C.

Fonti: `analysis/legacy/backup_gestionale/iec/codice/files/public_html/cust/lavori_batch_cli.php:59–120`; `analysis/legacy/backup_gestionale/adsrl/codice/files/public_html/cust/iec_sincronizza_scadenze.php`, funzione `gi_iec_sincronizza_scadenze`, rami CND/suppl/taratura e query di ritorno.

I riferimenti attrezzatura e valvola sulle righe I&C sono interi esterni del database AD_DM. Le scadenze I&C contengono dati descrittivi importati e sono sincronizzate per attrezzatura, tipo scadenza e valvola. Clienti e sedi vengono abbinati dapprima per ragione sociale/nome e poi, nei rami di recupero, con gli ID originali AD_DM; il flusso mantiene `id_cliente_adsrl` e `id_sede_adsrl`. Gli aggiornamenti dei record già esistenti non copiano indistintamente tutti i campi: per esempio i rami per cambio nome aggiornano il nome e quelli sugli stati sede divergenti segnalano un warning. Non si interpreta questa vecchia replica come una regola di fusione automatica di anagrafiche omonime.

Riscontri sulla copia del database in sola lettura, interrogando anche la copia AD_DM:

| Sottopunti di preventivo I&C | Conteggio | Riferimenti attrezzatura assenti in AD_DM | Riferimenti valvola valorizzati ma assenti in AD_DM |
|---|---:|---:|---:|
| CND | 408 | 0 | 0 |
| Indagini supplementari | 46 | 0 | 0 |
| Tarature | 622 | 0 | 0 |
| Altro | 1.150 | Non applicabile: tutti senza riferimento attrezzatura | Non utilizzato nel controllo del ponte |

Lo scadenzario I&C contiene 5.163 righe CND, 713 supplementari e 3.320 tarature. Sono scadenze importate, non conteggi di attività effettuate. Le corrispondenze esistenti devono alimentare la migrazione; non serve ricostruire i 1.076 agganci tecnici dei sottopunti mediante confronto di nomi.

### 44.2 Attività I&C e date

La maschera `attivita` scrive nella tabella `preventivi_righe`: l’attività è la stessa riga di sottopunto vista con i suoi campi operativi. L’accettazione del sottopunto crea lo stato da programmare quando assente. Gli stati dichiarati sono da programmare, programmata, effettuata e annullata; non coincidono automaticamente con tutti gli stati DPR/DM.

La programmazione richiede la data; l’attività effettuata richiede data esecuzione e, per i tipi tecnici del percorso, prossima scadenza. Il tipo Altro non richiede prossima scadenza e il salvataggio la azzera. Nel salvataggio non annullato, la compilazione della data programmazione può impostare programmata e quella di esecuzione, con i requisiti previsti, effettuata. Non si aggiungono blocchi di emissione/riesame non dimostrati dal percorso letto.

Il vecchio ponte distingue F non da sincronizzare, T da sincronizzare e S sincronizzato. Dopo l’aggiornamento riuscito il batch porta la riga a S; quelle indicate come fallite rimangono T. Se le date di una riga già sincronizzata vengono modificate, Garda avvisa di correggere manualmente AD_DM. Questa è una conseguenza operativa della separazione dei database da considerare nel nuovo nucleo; non è stata implementata una nuova gestione delle correzioni.

Fonti: `cust/meta/attivita.js:6–7,118–144,239–260,285–304`; `cust/_custom.php:1318–1459` nel sorgente IEC. Permessi della maschera condizionano la modifica quando attività effettuata e fatturata; non si attribuisce a questi controlli una immutabilità tecnica assoluta di ogni percorso.

### 44.3 Punti, sottopunti e prezzo a corpo/singolo

Il preventivo I&C ha punti P e sottopunti S, con legame al punto e numerazioni distinte. Si rilevano 616 punti, di cui 45 a corpo C e 571 a prezzi singoli S; 2.226 sottopunti, di cui 70 a corpo e 2.156 singoli. Non si confonde S sottopunto con S modalità prezzo singolo.

| Modalità | Importo commerciale | Attività e collegamenti |
|---|---|---|
| Prezzo singolo | Importo sul singolo sottopunto; il punto raggruppa descrittivamente. | Le attività sono i sottopunti con accettazione, date, bene/valvola ove pertinenti e fattura. |
| Prezzo a corpo | Importo sul punto; i sottopunti non hanno ciascuno un importo autonomo. | I sottopunti rimangono attività distinte. Gli stati commerciali sono coordinati fra i sottopunti del punto a corpo. |

La generazione fattura parte da un sottopunto accettato, effettuato e fatturabile secondo i permessi. Per prezzo singolo usa l’importo del sottopunto; per prezzo a corpo recupera l’importo del punto, crea una descrizione con titolo e descrizioni dei sottopunti e collega la fattura anche al punto e a tutti i sottopunti. Il batch evita la ripetizione dello stesso punto a corpo nel medesimo lavoro. Nel ramo letto non è richiesto esplicitamente che tutti i fratelli siano effettuati prima di fatturare il corpo: non si introduce ora tale requisito come presunta regola Garda.

I controlli comprendono prezzo prima dell’accettazione, unicità delle numerazioni nel preventivo, condizioni sulla modifica dei sottopunti, sconti percentuali o assoluti entro i limiti previsti. Il calcolo economico usa precisione intermedia otto decimali, ripartisce lo sconto assoluto di testata in proporzione e arrotonda gli importi finali delle righe a due decimali con il relativo helper. Il progetto di importi monetari finali in centesimi deve conservare questa semantica di calcolo; non significa arrotondare tutte le operazioni intermedie al centesimo.

Fonti: IEC `cust/_custom.php:554–685,809–1104,1360–1404`; `cust/meta/preventivi_righe.js`; `cust/lavori_batch_cli.php:305–510`. Questa lettura non conclude il confronto completo di fatturazione, collaboratori, pagamenti e documenti I&C.

### 44.4 Conseguenze concrete per il database unico

- Le corrispondenze sorgente DM di attrezzature/valvole I&C devono diventare relazioni agli stessi beni canonici, mantenendo provenienza e ID vecchi per quadratura e reimportazioni.
- Clienti e sedi comuni possono eliminare la replica usata dal ponte; dati commerciali specifici, collaboratori e stati operativi devono mantenere il proprio significato e non essere sovrascritti per sola omonimia.
- CND, supplementare e taratura sono attività che aggiornano le rispettive scadenze. Non si trasformano in verifiche periodiche DM, né si aggiungono alla rendicontazione INAIL per la sola condivisione del bene.
- I preventivi comuni devono poter collegare un importo commerciale a più attività senza duplicare il prezzo a corpo; appiattire ogni sottopunto in una riga con l’intero importo perderebbe le regole I&C.
- Altro, presente in 1.150 sottopunti, dimostra che il modello deve supportare prestazioni senza un’attrezzatura DM collegata. Non si impone di creare un’attrezzatura DM per ogni servizio commerciale.

Sono requisiti strutturali ricavati dal comportamento Garda. Non è adottato qui uno schema fisico definitivo né un cambiamento delle regole operative.

### 44.5 Primo dubbio I&C da chiarire: produzione dei rapporti tecnici

Nei file di maschera `attivita` e `preventivi_righe` letti non compaiono campi di allegato rapporto/certificato o un’azione di generazione tecnica. I report personalizzati reperiti in `cust/meta` sono preventivi Word e fatture clienti; in `cust/modelli` è presente il modello preventivo. Il vecchio campo di configurazione modello verbale GVR è commentato come ex adsrl e non prova un generatore I&C attivo. La tabella `gi_reports` del dump riporta 414 lavori preventivi e 210 fatture clienti, nessun altro meta sorgente.

Queste evidenze non provano che l’attività documentale non esista fuori dal backup. Non si inventa una funzione né si tratta una maschera assente dai percorsi verificati come una decisione di sopprimerla.

**IEC-01 chiusa:** l’utente conferma la produzione dei rapporti fuori da Garda e un software autonomo in sviluppo da integrare in seguito. Il riferimento al numero del report CND è richiesto con R85; dettagli nella sezione 45.

Documento quadro 1.70; R84 chiude la classificazione INAIL secondo Garda. Il nuovo dubbio aperto è IEC-01. Nessuna modifica a codice applicativo, database, archivi o documenti emessi.

## 45. Rapporti tecnici I&C — software autonomo e numero del report CND

9 ottobre 2026. L’utente conferma che i rapporti sono preparati fuori da Garda e che il suo ingegnere sta implementando un software autonomo per produrli. Quando sarà disponibile il gestionale completo, quel software sarà integrato. Il relativo codice e le capacità effettive non sono stati analizzati in questo passaggio: non si presume un formato di scambio o una funzione già completata.

L’utente richiede di registrare per i CND non soltanto la data e la prossima scadenza, ma anche il riferimento al numero del report. R85 registra il requisito; IEC-01 sulla provenienza dei documenti è chiusa. Non occorre ricostruire adesso un generatore CND dentro il gestionale né duplicare il lavoro già in corso presso l’ingegnere.

### 45.1 Riscontro Garda e aggiunta richiesta

Nel percorso attuale I&C, i sottopunti/attività contengono data esecuzione e prossima scadenza; il ponte verso DM trasmette quelle date con i riferimenti attrezzatura, valvola e tipo attività. Nei campi delle attività e nelle maschere attrezzature/valvole lette non è stato trovato un riferimento strutturato al numero del report. Le vecchie colonne `attrezzature.ultimi_cnd` e `prossimi_cnd` sono di tipo DATE nel dump originale; non sono numeri di rapporto. Le date correnti sono `data_ult_cnd` e `data_prox_cnd`; le valvole hanno `ultima_tar` e `prossima_tar`. Eventuali riferimenti scritti in note o documenti esterni non sono esclusi da questo riscontro.

Fonti: IEC `cust/meta/attivita.js`, `cust/meta/preventivi_righe.js`, `cust/lavori_batch_cli.php:66–77`; DM `cust/meta/attrezzature.js:912–928`, `cust/meta/valvole_sicurezza.js:243–259`; definizioni di `attrezzature` e `verifiche` nel dump originale adsrl.

L’aggiunta del riferimento al report è quindi un requisito esplicitamente richiesto, non una funzione Garda già verificata né una deroga inferita. Le regole esistenti sui collegamenti alle attività, scadenze, preventivi e fatture devono continuare a essere recepite.

### 45.2 Collegamenti concettuali minimi

| Elemento | Funzione nel gestionale integrato |
|---|---|
| Attrezzatura o valvola canonica | Identifica il bene già condiviso fra DM e I&C. |
| Attività tecnica | Conserva il lavoro svolto, la data e la prossima scadenza secondo il relativo percorso. |
| Riferimento al report | Consente di risalire al documento tecnico attraverso il suo numero, mantenendo il formato originale. |
| Software tecnico esterno | Produce i rapporti; l’integrazione futura dovrà collegare i suoi identificativi ai record del gestionale. |
| Documento finale | Potrà essere collegato tramite la gestione documentale comune; dettagli di file, revisioni e modalità di acquisizione da verificare con il software tecnico. |

Il numero del report non va confuso con il numero della verifica periodica DM, il numero del preventivo, l’ID della riga o quello della fattura. Nel nucleo comune il riferimento deve appartenere all’attività/rapporto che documenta: memorizzarlo soltanto in una casella sovrascritta sulla scheda attrezzatura perderebbe i collegamenti alle attività precedenti. La scheda può mostrarne il riferimento pertinente attraverso questi collegamenti senza una seconda compilazione manuale. È un indirizzo progettuale per soddisfare R85, non uno schema fisico già adottato.

Non si stabiliscono ora numero obbligatorio per chiudere l’attività, numerazione centralizzata, unicità globale fra software o emittenti, blocchi di fatturazione, regole di revisione o automatismi di firma. Non sono stati richiesti e il nuovo software non è ancora disponibile per il confronto. I record storici privi del numero non devono ricevere valori ricostruiti per supposizione.

### 45.3 Un solo chiarimento sulla cardinalità

**IEC-02 chiusa con il chiarimento della sezione 46:** normalmente un report CND riguarda una singola attrezzatura. La domanda originaria era se un rapporto potesse coprire più attrezzature oppure fosse sempre individuale. La risposta non è contenuta nel generatore Garda perché i rapporti sono prodotti all’esterno. Serve a definire il collegamento fra rapporto e beni/attività, conservando un numero unico del documento quando copre più beni anziché inventare numeri o duplicare documenti. Il numero di rapporti non viene dedotto dal prezzo a corpo o dai punti del preventivo.

Il chiarimento successivo fissa il collegamento individuale come caso ordinario, senza stabilire esclusività assoluta. Le date e le regole di rendicontazione INAIL già concordate non vengono modificate dalla futura integrazione dei rapporti CND.

Documento quadro 1.71. Requisito R85 acquisito; IEC-01 chiusa, IEC-02 aperta. Nessuna modifica applicativa né richiesta del nuovo software o di originali S3 in questo passaggio.

---

## 46. Report CND normalmente relativo a una singola attrezzatura

L’utente chiarisce: «normalmente un report riguarda la singola attrezzatura». R86 recepisce questa prassi e chiude IEC-02 per il percorso ordinario. Il rapporto si collega all’attività CND dell’attrezzatura; il riferimento al suo numero deve essere consultabile nello storico insieme alla data e alla prossima scadenza, secondo R85.

La parola “normalmente” non autorizza a introdurre un vincolo assoluto che impedisca eventuali rapporti diversi. Non sono stati definiti casi eccezionali, obbligatorietà o formato del numero, unicità globale, revisioni del documento o API del software esterno. Non occorre approfondirli ora per acquisire il caso ordinario. Il prezzo a corpo del preventivo non determina quanti rapporti tecnici debbano essere prodotti.

Nessuna modifica applicativa o al database in questo passaggio. La rendicontazione INAIL e la sincronizzazione delle date DM–I&C restano soggette alle regole già ricostruite e concordate.

## 47. I&C: incassi, percentuali e fatture dei collaboratori

### 47.1 Perimetro della lettura

Letti i percorsi pertinenti del sorgente I&C: `cust/gi_views.php` (viste dei preventivi e dei compensi), `cust/_custom.php` (calcolo delle percentuali, associazione a fatture e aggiornamento del saldo), `cust/meta/pagamenti.js`, `cust/meta/importi_collaboratori.js` e `cust/meta/fatture_collaboratori.js`. Effettuate sole interrogazioni aggregate in lettura sul database di staging `iec.sqlite`. Nessun collegamento ai servizi esterni e nessuna esecuzione dei lavori batch.

Questa ricostruzione riguarda il percorso letto; non costituisce una verifica completa di ogni funzione amministrativa I&C né prova dell’utilizzo attuale delle maschere.

### 47.2 Regole presenti nel codice Garda

| Tema | Comportamento rilevato | Riferimento nel sorgente I&C |
|---|---|---|
| Percentuale proposta | Percentuale per articolo/servizio del collaboratore associato al cliente. La proposta dipende dal catalogo delle percentuali; il sottopunto non riceve autonomamente il default. Il catalogo valida valori da 0 a 100. | `_custom.php`, `gi_preventivi_righe_perc_collab_default_calc`, da riga 1293; validazione da riga 1519. |
| Base del compenso | Percentuale applicata all’importo commerciale finale della riga, con arrotondamento del compenso a due decimali. La base è `imp_finale`, non il totale comprensivo di IVA. | `gi_views.php`, `importi_collaboratori_read`, da riga 260. |
| Preventivo a corpo o a singoli prezzi | Per prezzi singoli il compenso deriva dai sottopunti; per prezzo a corpo deriva dal punto. La vista evita di contare nuovamente ogni sottopunto del punto a corpo. Sono considerate le righe associate a una fattura cliente e con percentuale positiva. | `gi_views.php`, `importi_collaboratori_read`. |
| Stato del compenso | Se associato a fattura del collaboratore: `fatturato`. Altrimenti, se la fattura cliente è saldata: `fatturabile`; negli altri casi: `assegnato`. È uno stato calcolato dalla vista. | `gi_views.php`, `preventivi_righe_read`, righe 151–173. |
| Fattura cliente saldata | Il ricalcolo imposta il saldo se esiste almeno una riga di pagamento e non ne rimane alcuna marcata non saldata. Non confronta aritmeticamente la somma degli importi ricevuti con il totale fattura. | `_custom.php`, `gi_fatture_clienti_fattura_saldata_recalc`, da riga 1625. |
| Righe di pagamento | Fattura cliente, scadenza, entrata/uscita, importo e indicatore di saldo; quest’ultimo proposto falso. La fattura associata non è modificabile dalla maschera dopo la creazione. | `meta/pagamenti.js`, righe 1–90 e 120–182. |
| Associazione alla fattura del collaboratore | Il collaboratore del compenso deve coincidere con quello della fattura del collaboratore, anche nell’associazione multipla. La fattura ha unicità su numero, data e collaboratore. | `_custom.php`, controllo da riga 1536; `meta/fatture_collaboratori.js`, righe 24–54. |
| Quadratura della fattura del collaboratore | Differenza fra imponibile della fattura e somma dei compensi associati. Una differenza negativa genera un avviso, non un blocco di salvataggio nel percorso letto. | `_custom.php`, ricalcolo da riga 1577 e relativo controllo successivo. |
| Pagamenti dopo fatturazione del compenso | Le condizioni delle maschere impediscono modifica/eliminazione dei pagamenti quando la fattura cliente ha compensi già associati a fattura del collaboratore. Il controllo prima del salvataggio impedisce di aggiungere un pagamento in quel caso. | `meta/pagamenti.js`, permessi; `_custom.php`, `gi_pagamenti_save_before`, da riga 1611. |

Non va confuso l’indicatore Garda di saldo delle righe con un futuro registro degli incassi effettivi e delle loro allocazioni. I requisiti già acquisiti per pagamenti parziali e associazione a più fatture restano validi: l’eventuale diverso calcolo del saldo e le sue conseguenze sui compensi vanno valutati espressamente prima di modificare questa regola, secondo R73. In questa analisi non sono stati adottati algoritmi sostitutivi né nuove politiche di pagamento.

### 47.3 Evidenza del backup e limite interpretativo

Nel database I&C letto risultano 231 fatture clienti, 231 righe di pagamento, 132 voci del catalogo delle percentuali dei collaboratori e 3 fatture di collaboratori. Le righe di preventivo associate a una fattura del collaboratore sono zero. Le fatture clienti riportano 141 indicatori di saldo veri e 90 falsi.

Sono conteggi del backup disponibile, non una fotografia garantita dell’uso corrente. Le tre fatture presenti e l’assenza di associazioni non consentono di concludere che la gestione dei compensi sia usata regolarmente, abbandonata o sostituita da un processo esterno. Non si autorizza quindi la sua eliminazione o il suo rinvio soltanto sulla base dei conteggi.

### 47.4 Chiarimento operativo successivo

**IEC-03 chiusa nella sezione 48:** l’utente conferma il mantenimento operativo della gestione dei compensi percentuali e delle fatture dei collaboratori nel nuovo I&C.

Il codice dimostra che la funzione esiste e ne permette la ricostruzione; la successiva conferma dell’utente ne stabilisce il mantenimento operativo (R87). Le regole restano nel riferimento funzionale Garda e gli eventuali scostamenti sono soggetti a R73. Non si modifica in questa fase il modulo amministrativo comune né si introduce automaticamente questa funzione in AD_DPR.

Documento quadro 1.72. R86 acquisito; IEC-01 e IEC-02 chiuse, IEC-03 aperta. Nessuna modifica applicativa o al database; nessuna richiesta di originali S3.

---

## 48. Conferma del mantenimento dei compensi e delle fatture dei collaboratori I&C

Alla domanda se questa gestione debba restare operativa nel nuovo I&C, l’utente risponde «sì assolutamente». R87 acquisisce la conferma e chiude IEC-03. Il numero ridotto di fatture di collaboratori e l’assenza di associazioni nel backup non sono motivo per omettere la funzione o differirla dal perimetro I&C.

Sono da recepire percentuali per servizio, distinzione punto a corpo/sottopunto a prezzo singolo, base commerciale del compenso, stato collegato al saldo cliente, associazione e quadratura con la fattura del collaboratore, visibilità e controlli pertinenti. Le regole puntuali lette rimangono descritte nella sezione 47; questa conferma non autorizza a cambiarle silenziosamente. Il futuro rapporto con il registro comune degli incassi richiede di conservare la loro semantica oppure esplicitare lo scostamento secondo R73.

La gestione riguarda I&C. Il nucleo comune può offrire identità, documenti e movimenti economici condivisi, conservando il contesto dell’attività; non si aggiungono per questo compensi dei collaboratori ai flussi DPR o DM. Nessuna modifica applicativa o al database effettuata.

## 49. I&C: collaboratore del cliente/preventivo ed esecutore dell’attività

### 49.1 Evidenza del sorgente e del database

| Relazione | Garda I&C | Conseguenza per l’analisi del nucleo comune |
|---|---|---|
| Cliente → collaboratore | `clienti.collaboratore` punta a un utente. La visibilità dei clienti del collaboratore usa questo collegamento. | Preservare il significato e la visibilità del dato importato; non convertirlo automaticamente in un assegnatario tecnico. |
| Preventivo → collaboratore | La maschera propone il collaboratore dal cliente con `values_dragging`; il preventivo conserva un proprio campo, mostrato in sola lettura. | Il collaboratore del preventivo e quello corrente del cliente sono collegamenti distinti, non un unico valore da ricalcolare durante la migrazione. |
| Attività/compenso → collaboratore | `preventivi_righe_read` legge `p.collaboratore` dal preventivo; `attivita_read` e `importi_collaboratori_read` derivano da questa vista. La maschera attività espone quel valore come campo di lettura. | L’etichetta nella griglia attività non dimostra che il soggetto sia il tecnico esecutore. |
| Scadenze → collaboratore | La vista passa dal cliente della sede operativa; i permessi possono limitarne la visibilità al collaboratore. | La titolarità commerciale corrente della scadenza può avere una provenienza diversa dal collaboratore conservato nel preventivo. |
| Verifiche DM/DPR → tecnico | Entrambi i gestionali prevedono il campo `tecnico` della verifica, obbligatorio nella maschera, e un distinto `tecnico_aff` facoltativo. | La relazione tecnica è esplicita; non coincide per struttura con il collaboratore I&C. |

Riferimenti letti: I&C `cust/meta/clienti.js`, campo collaboratore e permessi; `cust/meta/preventivi.js`, righe 252–303; `cust/gi_views.php`, viste `preventivi_righe_read`, `scadenze_read`, `attivita_read`, `importi_collaboratori_read`; `cust/meta/attivita.js`, campi e permessi; `cust/meta/importi_collaboratori.js` e `cust/meta/scadenze.js`. Confronto con `cust/meta/verifiche.js` di ingecert (righe 399–433) e adsrl (righe 479–514).

Nel database I&C, `preventivi` e `clienti` hanno il campo collaboratore; nelle righe di preventivo lette non emerge un campo tecnico/esecutore distinto. Su 349 preventivi, 106 hanno collaboratore valorizzato, riferito a 3 utenti distinti; su 814 clienti, 311 hanno collaboratore valorizzato, riferito a 4 utenti distinti. Sono conteggi del backup, non prova di chi abbia svolto le prestazioni.

La ricerca nei metadati e nel PHP personalizzato I&C non ha individuato un percorso distinto di assegnazione del tecnico per le attività lette. La griglia delle righe fattura contiene la stringa `tecnico`; la tabella di staging conserva effettivamente i campi `tecnico` e `tecnico_aff`, ma entrambi risultano nulli su tutte le 1.171 righe fattura I&C e nei campi del metadato letto non è stata individuata una loro definizione operativa. Né la stringa né le sole colonne dimostrano quindi un flusso utilizzato di assegnazione tecnica. Non si conclude che il software esterno in sviluppo o tutte le prassi operative siano privi del dato.

### 49.2 Chiarimento sul significato operativo

**IEC-04 chiusa sul significato operativo nella sezione 50:** l’utente chiarisce che in I&C il collaboratore è una questione di provvigioni commerciali, mentre in DM/DPR il tecnico è fondamentale per flusso e rendicontazione.

Il chiarimento stabilisce la semantica necessaria al nucleo comune: una relazione commerciale non è un’attribuzione tecnica. La stessa persona può essere referenziata dall’anagrafica comune per ruoli distinti, senza dedurre il tecnico dal collaboratore I&C. La risposta non introduce un nuovo obbligo di assegnazione tecnica I&C né decide i campi del software esterno. I dati importati non vanno arricchiti con un esecutore storico dedotto dal solo collaboratore.

Restano preservati i flussi specifici: I&C oggi usa attività da programmare/programmata/effettuata/annullata e date, mentre DM/DPR hanno verifiche con assegnazione al tecnico e ulteriori passaggi. La struttura comune non autorizza a uniformarli automaticamente né a trasferire a I&C tutti i controlli DPR.

Documento quadro 1.73. R87 acquisito; IEC-01, IEC-02 e IEC-03 chiuse, IEC-04 aperta. Nessuna modifica applicativa o al database; nessuna richiesta degli originali S3.

---

## 50. Ruoli tecnici DM/DPR e provvigioni commerciali I&C nel database comune

### 50.1 Decisione acquisita

L’utente precisa che in DM e DPR il tecnico è fondamentale perché ricorre sia nella rendicontazione sia nel flusso di lavoro; in I&C il collaboratore è una questione di provvigioni commerciali. R88 recepisce la distinzione. IEC-04 è chiusa sul significato del ruolo: non occorre imporre per I&C lo stesso modello di assegnazione del verificatore previsto in DM/DPR.

Una persona eventualmente presente in più attività può avere un’identità comune e relazioni distinte: tecnico della verifica, referente commerciale del cliente, collaboratore commerciale del preventivo I&C. Questa separazione conserva i significati Garda e non richiede maschere o passaggi aggiuntivi per il solo fatto di adottare un database unico. L’identificazione di persone fra i tre archivi resta da verificare in migrazione, senza unire utenti sulla sola uguaglianza degli ID numerici locali.

### 50.2 Ulteriore riscontro Garda sui riferimenti commerciali

DM e DPR contengono anche `clienti.referente_commerciale`, distinto dal tecnico della verifica. La relativa maschera e il permesso di visualizzazione dei clienti propri usano tale riferimento (`cust/meta/clienti.js`, campo da riga 200 e condizione da riga 26 in entrambi i gestionali). Non va omesso durante l’unificazione né scambiato per il verificatore.

Il ponte I&C importa il referente commerciale DM tramite una mappa verso gli utenti collaboratori I&C quando crea un nuovo cliente. Se manca l’associazione, produce un avviso per la compilazione manuale; non sceglie un collaboratore sulla sola coincidenza degli ID. Il ramo relativo al cliente già trovato non esegue la medesima assegnazione automatica del collaboratore. Riferimento: I&C `cust/lavori_batch_cli.php`, `gi_import_clienti_da_adsrl`, righe 163–219. Non sono state lette o esposte le credenziali delle connessioni.

Per i preventivi I&C, inoltre, il beneficiario esposto nelle viste proviene dal collaboratore conservato sulla testata del preventivo, mentre il default della percentuale per articolo consulta il collaboratore corrente del cliente. Sono due percorsi distinti rilevati nel sorgente (`cust/gi_views.php`, `preventivi_righe_read`; `cust/_custom.php`, `gi_preventivi_righe_perc_collab_default_calc`). L’analisi non autorizza a uniformarli o a ricalcolare retroattivamente i compensi; se si intenderà correggere la possibile divergenza, occorrerà descrivere il caso concreto e ottenere la decisione prevista da R73.

### 50.3 Effetti tecnici della ristrutturazione

| Dato di origine | Recepimento da conservare | Comportamento da evitare |
|---|---|---|
| Tecnico e affiancamento della verifica DM/DPR | Riferimenti alle persone pertinenti alla singola verifica e al relativo ambito; conservazione degli incarichi e delle attribuzioni storiche. | Assegnare automaticamente il collaboratore commerciale come verificatore. |
| Referente commerciale del cliente DM/DPR e collaboratore del cliente I&C | Conservazione delle relazioni di origine e dei permessi nel contesto pertinente. Anagrafica cliente comune senza sovrascrivere le assegnazioni fra attività. | Un unico campo globale che scelga silenziosamente uno dei tre valori quando le anagrafiche sono unite. |
| Collaboratore conservato nel preventivo I&C | Collegamento proprio del preventivo, mantenuto nei dati migrati e nel calcolo/associazione dei compensi. | Sostituirlo automaticamente con il referente corrente del cliente durante una reimportazione o un aggiornamento anagrafico. |
| Percentuale della prestazione e compenso | Preservare i valori delle righe, l’importo finale e i criteri punto/sottopunto della sezione 47. | Ricalcolare le righe storiche applicando il catalogo percentuali corrente. |
| Fattura e saldo | Collegamenti al ciclo economico I&C e relativo stato del compenso. | Dedurre l’esecuzione tecnica o la consegna del report dal pagamento cliente. |

È un indirizzo di mapping che conserva le relazioni, non uno schema fisico già implementato né una nuova policy di assegnazione commerciale. Non vengono introdotti nuovi controlli di accreditamento per I&C sulla sola base delle regole DM/DPR.

### 50.4 Prossimo chiarimento: attività effettuata e disponibilità del report I&C

**IEC-05 chiusa per il caso ordinario nella sezione 51:** l’utente precisa che normalmente si aspetta che il report sia pronto. La domanda riguardava il rapporto fra completamento tecnico e fatturazione.

Il codice Garda letto usa stato effettuata e date nel percorso attività e fatturazione; il generatore tecnico è esterno, come confermato dall’utente. In quel percorso non è stato trovato un requisito di disponibilità del report analogo al verbale finale DM/DPR. Il sorgente pertanto ricostruisce il comportamento applicativo attuale, ma non dimostra se la prassi operativa attenda comunque il rapporto. Il successivo chiarimento dell’utente registra la prassi di attendere il report pronto (R89). Non si aggiunge automaticamente un blocco documentale o un nuovo stato; l’integrazione futura dovrà rappresentare questa prassi senza attribuire al vecchio codice un controllo documentale che non è stato riscontrato. Il requisito riguarda solo le prestazioni che producono report; le righe di tipo Altro non diventano soggette a un rapporto tecnico per questo motivo.

Documento quadro 1.73. R87 e R88 acquisiti; IEC-01, IEC-02, IEC-03 e IEC-04 chiuse sul perimetro descritto, IEC-05 aperta. Nessuna modifica applicativa o al database; nessuna richiesta degli originali S3.

---

## 51. I&C: normalmente report pronto prima della fatturazione

### 51.1 Prassi acquisita e perimetro

Alla domanda sul completamento della prestazione e sulla fatturabilità quando il report è ancora da completare, l’utente risponde: «normalmente aspettiamo il report sia pronto». R89 registra il percorso ordinario delle prestazioni I&C che producono report. IEC-05 è chiusa per questo percorso.

Il chiarimento orienta il completamento operativo e la fatturazione, ma non equivale all’approvazione di un nuovo vincolo informatico assoluto. Non è stato definito che ogni data di esecuzione debba attendere il report, né un nuovo stato tecnico, un obbligo di caricamento del PDF, un riesame analogo a DM/DPR o un blocco delle eccezioni. La data effettiva dell’intervento va preservata anche se il report viene preparato successivamente. Le attività che non producono un rapporto non acquisiscono un documento obbligatorio per effetto di questa decisione.

### 51.2 Raccordo con il comportamento Garda

Il sorgente I&C permette di generare una fattura dalla riga di attività effettuata, non già fatturata. La condizione della maschera è `tip_riga = S`, attività presente, stato `effettuata`, fattura assente (`cust/meta/preventivi_righe.js`, azione `custom_preventivi_righe_fattura_cliente_genera`, righe 51–53). Il lavoro batch verifica anche che la riga sia accettata e lo stato attività effettuata (`cust/lavori_batch_cli.php`, `gi_preventivi_righe_fattura_cliente_genera`, ramo process da riga 390).

Nel percorso letto non è richiesto un report finale collegato come condizione di fatturazione. Il rapporto oggi è prodotto esternamente (R85), e l’utente chiarisce che nella prassi si attende che sia pronto. Sono evidenze diverse: la condizione applicativa Garda usa lo stato della riga; la prassi dell’ufficio comprende la disponibilità del report. Il gestionale nuovo dovrà poter rendere riconoscibile questa disponibilità quando sarà integrato il software tecnico, con la semplicità richiesta dall’utente. Il dettaglio dei campi e dell’interfaccia non è ancora adottato.

Restano valide le regole specifiche di fatturazione I&C a prezzo singolo/a corpo, compresa la selezione e il raggruppamento ricostruiti nella sezione 44. Il chiarimento non autorizza a cambiare il trattamento di tutti i sottopunti di un prezzo a corpo, la base delle provvigioni o gli stati dipendenti dal saldo cliente.

### 51.3 Distinguere disponibilità, consegna e pagamento

| Fatto | Significato | Stato della decisione |
|---|---|---|
| Intervento eseguito | Attività svolta nella sua data reale; date tecniche e prossime scadenze. | Conservare le date e le regole Garda già ricostruite. |
| Report pronto | Documento completato dal software tecnico esterno; normalmente atteso prima di procedere alla fatturazione. | Prassi acquisita con R89; automatismo e blocco assoluto non approvati. |
| Report inviato al cliente | Consegna del documento, successiva alla sua disponibilità. | Chiarito con R90: normalmente via email prima della fatturazione, senza attendere l’incasso. Report pronto non significa già inviato. |
| Fattura cliente saldata | Situazione economica che governa anche lo stato fatturabile dei compensi commerciali. | Conservare il significato della sezione 47; non dedurre il saldo dall’invio del report. |

### 51.4 Prossimo chiarimento operativo

**IEC-06 chiusa nella sezione 52:** l’utente conferma invio del lavoro concluso al cliente via email, poi fatturazione e incasso normalmente successivo.

La successiva risposta chiarisce che l’incasso non è una condizione ordinaria per la consegna (R90). Nella ricerca del sorgente personalizzato letto non è stato individuato un flusso di consegna dei report subordinato al pagamento; l’assenza di tale controllo nel software non dimostra la prassi operativa svolta fuori da Garda. La risposta serve a definire il rapporto fra modulo documentale e amministrativo nel futuro I&C. Non si presume un obbligo di incasso anticipato né si trasferisce automaticamente la regola DPR.

Documento quadro 1.74. R89 acquisito; IEC-05 chiusa per il caso ordinario, IEC-06 aperta. Nessuna modifica applicativa o al database; nessuna richiesta di originali S3 o del software tecnico esterno.

---

## 52. I&C: invio via email, poi fatturazione e incasso successivo

L’utente precisa: «la prassi commerciale è, finito il lavoro, trasmetterlo al cliente a mezzo mail, poi fatturarlo, l’incasso non è mai o quasi contestuale». R90 fissa il flusso ordinario e chiude IEC-06. Il rapporto pronto viene inviato al cliente via email; segue la fatturazione, e il pagamento è normalmente successivo. Non si prevede una condizione di incasso prima dell’invio del report.

Questa regola integra R89 e distingue il completamento del lavoro dalla situazione economica. Non modifica le date reali di esecuzione e le scadenze tecniche né le regole di fatturazione a corpo. Il pagamento resta pertinente allo stato dei compensi commerciali della sezione 47: l’invio del rapporto non rende la fattura saldata e non rende automaticamente fatturabile la provvigione.

La risposta stabilisce canale e ordine operativo, non l’automazione della trasmissione. Modalità manuale/automatica dell’email, destinatari, nomi dei file, prova di invio e integrazione del software tecnico rimangono dettagli da definire senza aggiungere ora stati o maschere. Nessuna email inviata in questa analisi.

Per il nucleo comune devono restare riconoscibili prestazione e report pertinente, consegna e collegamento fiscale. Si conservano relazioni distinte per evitare che report inviato, prestazione fatturata e credito incassato siano trattati come un solo stato. Non occorre per questo aggiungere un nuovo flusso ispettivo DM/DPR alle attività I&C.

## 53. Fattura unica tra ambiti: limite da chiarire per DM e DPR

### 53.1 Decisioni già acquisite e riscontro Garda

È già confermata la fattura unica da più prestazioni/preventivi compatibili e la possibilità di associare a una fattura esistente. È anche esplicitamente deciso che le prestazioni DM ed EX siano fatturate separatamente, con serie distinte per i preventivi (R48–R49). Quest’ultimo caso non può essere unificato come effetto automatico del nuovo backend.

DM e DPR Garda usano procedure di generazione riferite alle proprie righe e verifiche nella rispettiva connessione. I riferimenti letti sono `cust/lavori_batch_cli.php`, `gi_preventivi_righe_fattura_cliente_genera`, da riga 1782 in adsrl e da riga 751 in ingecert. Entrambi i metadati delle fatture definiscono numero e serie, con indice univoco su serie, tipo e numero (`cust/meta/fatture_clienti.js`, da riga 127). Questa lettura ricostruisce le strutture separate disponibili e non prova una regola commerciale assoluta contraria a una futura aggregazione tra ambiti.

La rendicontazione INAIL DM collega ogni verifica alla sua fattura e al relativo allegato; il percorso letto deduplica l’allegato per chiave tabella/ID fattura e riutilizza il nome già generato (`adsrl/cust/lavori_batch_cli.php`, righe 882–903). Un’eventuale fattura contenente prestazioni di più ambiti deve dunque conservare i legami delle righe alle verifiche DM e i riferimenti documentali richiesti dall’esportazione, oltre alle regole di codifica già censite. Non si decide qui di cambiare questi nomi o di suddividere la fattura per l’export.

### 53.2 Chiarimento per il nucleo integrato

**UNIF-01 chiusa nella sezione 54:** l’utente conferma fatture e preventivi separati DM/DPR, con i rispettivi sezionali (R91).

La scelta riguarda soltanto l’aggregazione commerciale DM/DPR della stessa società emittente; non unisce fatture fra società diverse, non altera la separazione DM/EX già decisa e non presume una fusione delle numerazioni fiscali. Nel nucleo economico vanno in ogni caso conservati emittente, ambito delle righe, prestazioni di origine e serie pertinenti. Nessuna aggregazione fra ambiti è introdotta in assenza della decisione.

La fattura mista DM/DPR è esclusa dalla successiva decisione R91. Le considerazioni precedenti sui riferimenti INAIL non costituiscono autorizzazione a introdurla. Identità comune del cliente e modulo amministrativo condiviso rimangono compatibili con fatture e preventivi separati; non si cambia ora il primo DPR in collaudo. Il dettaglio tecnico delle chiavi non richiede una nuova decisione commerciale per ogni colonna.

Documento quadro 1.75. R90 acquisito; IEC-06 chiusa, UNIF-01 aperta. Nessuna modifica applicativa o al database; nessuna trasmissione al cliente o richiesta di originali S3.

---

## 54. DM e DPR: sezionali, preventivi e fatture separati

Alla domanda sulla fattura unica DM/DPR, l’utente risponde: «no perché sono comunque sezionali separati (dpr e dm) e pure preventivi separati». R91 acquisisce la regola e chiude UNIF-01. La separazione DM/EX già concordata con R49 rimane valida.

Nel gestionale completo il cliente può avere un’anagrafica comune e l’ufficio può usare lo stesso modulo amministrativo, mantenendo però preventivi, fatture e numerazioni DM/DPR distinti. La funzione che raggruppa più prestazioni nella stessa fattura deve rispettare questo confine: uno stesso cliente e una stessa società emittente non bastano a rendere compatibili due righe DM e DPR. Le numerazioni importate vanno conservate nel loro contesto, senza rinumerare gli originali o unire progressivi uguali di sezionali diversi.

La decisione riguarda documenti commerciali e fiscali. Non revoca i requisiti già acquisiti di pagamento parziale e ripartizione di un incasso fra più fatture; una ripartizione economica non trasforma le fatture originarie in un documento unico. Non viene qui introdotta una nuova policy di incasso fra società o intestatari diversi.

## 55. Compatibilità con il codice DPR attuale: verifica circoscritta e lavoro per DM

### 55.1 Riscontro nei sorgenti Garda e nel nuovo gestionale

In Garda, i preventivi di ciascun archivio definiscono la serie e il progressivo dipendente dalla serie, con unicità serie/numero. Riferimenti: `cust/meta/preventivi.js`, da riga 76 e campi da riga 193 in adsrl; da riga 80 e campi da riga 206 in ingecert. Nel database comune non è sufficiente usare il testo della serie, che può essere lo stesso anno nei due archivi: occorre conservare anche il contesto di origine/ambito.

La lettura del codice `work/Gestionale_AD_v0.8.0` ha rilevato:

| Parte | Stato attuale rilevato | Lavoro da svolgere prima di attivare DM |
|---|---|---|
| Modello fatture | `Fattura` contiene società e ambito; unicità su società, ambito, tipo, anno e numero. | Conservare il confine di ambito e collegare i sezionali corretti; non dichiarare già implementate tutte le serie storiche Garda. |
| Creazione fatture | Il servizio abilita soltanto ambito DPR e società AD. | Abilitare DM solo insieme alle relative prestazioni, controlli e riferimenti; non basta sbloccare una stringa. |
| Numerazione fatture | Il servizio filtra il progressivo per società, ambito, gruppo fattura/nota di credito e anno. | Verificare i codici e le serie definitive sul mapping Garda prima del cutover; non fondere i progressivi DM/DPR. |
| Modello preventivi | Unicità attuale su anno, numero e revisione; non è presente un contesto di società/ambito/sezionale nella chiave letta. È il modello operativo DPR corrente. | Estendere identità, progressivo e importazione dei preventivi prima di collocare nello stesso nucleo quelli DM/EX/I&C. Non riusare un’identità DPR per un preventivo DM con lo stesso numero. |
| Raggruppamento fiscale | La versione corrente opera sul solo DPR. | Esplicitare e verificare l’incompatibilità DM/DPR delle righe in generazione, integrazione della fattura esistente ed emissione. |
| Ripartizione incassi | Il servizio verifica società e intestatario uguali alle fatture associate, importo positivo e residuo disponibile; non usa l’ambito come condizione nella funzione letta. | Conservare la distinzione fra pagamento ripartito e fattura unica. Eventuali prove su più ambiti saranno possibili solo dopo la loro implementazione. |

Riferimenti nel nuovo sorgente: `gestionale/moduli/finanza/modelli.py`, classe `Fattura`; `gestionale/moduli/finanza/servizio.py`, funzioni `crea`, `emetti` e `ripartisci`; `gestionale/moduli/preventivi/modelli.py`, classe `Preventivo`. È una lettura circoscritta del codice, non un collaudo end-to-end né una verifica esaustiva del nucleo.

### 55.2 Conseguenza architetturale acquisita

La separazione commerciale richiede contesti distinti all’interno del nucleo comune, non tre database indipendenti. Tabelle, servizi e maschere amministrative possono essere condivisi se mantengono il contesto dei documenti e i controlli sulle loro relazioni. La ristrutturazione tecnica necessaria per conservare queste regole rientra nell’integrazione autorizzata; un eventuale cambiamento del comportamento operativo resta soggetto a R73.

Per il DPR in collaudo non sono state eseguite modifiche applicative. Le estensioni DM/I&C rimangono lavoro successivo: la presenza del campo ambito nelle fatture non dimostra che preventivi, beni, attività tecniche, permessi e rendicontazione siano già integrati. Sono ora fissati i confini essenziali: ruoli tecnici e commerciali distinti (R88), consegna I&C prima di fatturazione/incasso (R90), preventivi e fatture DM/DPR separati (R91), conservazione delle regole INAIL DM già analizzate.

Documento quadro 1.76. R91 acquisito; UNIF-01 chiusa. Nessuna nuova domanda necessaria per recepire questo confine. Nessuna modifica applicativa o al database, nessun nuovo test dichiarato eseguito e nessuna richiesta degli originali S3.

---

## 56. Stato del progetto al 9 ottobre 2026: analisi, codice e lavoro residuo

L’utente chiede di proseguire e di chiarire a che punto siamo. Il progetto ha una candidatura DPR eseguibile, un approfondimento sostanziale dei percorsi Garda DM e I&C e i confini principali dell’integrazione documentati. Non è ancora un gestionale completo delle tre attività. Il registro arriva a R91: contiene requisiti, decisioni e proposte con il rispettivo stato, non 91 funzioni tutte implementate o collaudate.

| Area | Risultato raggiunto | Cosa resta |
|---|---|---|
| AD_DPR | Candidatura 0.8.0 per il collaudo locale Windows con preventivi, incarichi, innesto VerbalizzAI e nucleo fatturazione/incassi; verifiche tecniche descritte nella sezione 30. | Validazione nell’uso da parte dell’utente e completamento dei punti per il cutover. L’avvio Windows completo non è stato attestato in questa conversazione. |
| AD_DM | Ricostruiti percorsi di classificazione SC/SP/GVR, camere/volumi/DN, tariffazione delle prestazioni GVR, generatore verbali e scadenze per componente. | Tradurre il mapping nello schema comune e implementare il modulo, preservando cataloghi e comportamenti. La lettura non è un audit esaustivo di ogni funzione DM. |
| INAIL DM | Analizzati tracciato Excel, prerequisiti, pacchetti ZIP e codifica degli allegati; acquisita la prassi trimestrale con caricamento manuale A.S.A. | Implementazione, confronto con dati reali e verifica dei pacchetti. Non è stata provata una rendicontazione prodotta dal nuovo software. |
| I&C | Ricostruiti ponte con DM, attività, preventivi a punti/sottopunti, prezzi a corpo/singoli e compensi commerciali. Acquisiti produzione esterna dei report, numero CND, report normalmente individuale e invio prima di fatturazione/incasso. | Implementare modulo e raccordo documentale; integrare il software tecnico dell’ingegnere quando disponibile. Non serve duplicarne ora il generatore. |
| Confini comuni | Tecnico DM/DPR distinto dal collaboratore commerciale; preventivi e fatture DM/DPR separati; separazione DM/EX conservata. Identità comuni non comportano uniformazione dei flussi. | Schema fisico definitivo, permessi per ambito, adattamenti dei preventivi e collegamenti dei beni. |
| Migrazione | Dump e staging disponibili; analisi e controlli circoscritti già documentati; import iniziale DPR per le prove. | Identità canoniche per tutte le origini, import incrementale e import economico quadrato. Non sono funzioni già presenti nel pacchetto DPR. |
| Documenti e produzione | Censite le regole di conservazione degli emessi, nomenclatura, esiti fiscali e backup. | Recupero/verifica degli allegati nella fase pertinente, integrazione esiti Aruba, prove di ripristino e cutover. L’assenza degli originali S3 non impedisce di proseguire ora. |

I chiarimenti IEC-01–IEC-06 e UNIF-01 sono chiusi per il perimetro acquisito; le prassi introdotte con “normalmente” non diventano vincoli assoluti. Non occorre riaprire queste domande. Restano lavori tecnici e alcune decisioni circoscritte da presentare solo quando un caso concreto comporti uno scostamento funzionale da Garda.

Le 121 prove riportate nella sezione 30 sono i risultati precedenti sulla candidatura DPR in ambiente Linux/Python 3.12, non nuove prove Windows o test dei futuri moduli DM/I&C. In questo passaggio sono state eseguite letture del codice e dei documenti; nessuna nuova suite o modifica applicativa.

### 56.1 Sequenza operativa confermata

Il lavoro concettuale procede ora con una matrice Garda → responsabilità del nucleo comune → lavoro necessario, iniziata nella sezione 57. La traduzione in schema e migrazioni deve conservare gli ID e le relazioni di origine, mentre ogni variazione di comportamento viene esplicitata secondo R73. Il DPR continua il proprio collaudo; l’attivazione in esercizio di DM e I&C segue la validazione DPR. L’integrazione del software tecnico esterno e i dettagli di email/file non devono bloccare il mapping delle strutture fondamentali.

## 57. Prima matrice delle strutture comuni e delle logiche specifiche

Questa matrice consolida le analisi già svolte e la lettura recente dei modelli della candidatura DPR. I concetti indicati sono responsabilità del modello, non nomi definitivi di nuove tabelle. Non vengono introdotte deroghe Garda o modifiche al software.

| Area | Responsabilità comune e dati da conservare | Logica che rimane specifica / lavoro necessario |
|---|---|---|
| Identità di origine | Collegare ogni record migrato alla sua origine e al proprio ID canonico; distinguere archivio, entità e ID locale. | Numeri uguali dei tre archivi non identificano lo stesso record. Il riallineamento incrementale resta da implementare. |
| Società, clienti e sedi | Identità comuni dove accertate, documenti intestati alla società pertinente e fotografie degli emessi. | Relazioni commerciali e permessi conservano il contesto dell’attività. Niente fusione automatica dei referenti o delle società emittenti. |
| Persone e ruoli | Identità della persona separata dalle sue relazioni alle attività e ai documenti. | Tecnico e affiancamento DM/DPR; referente commerciale; collaboratore del preventivo I&C e provvigioni sono ruoli distinti (R88). |
| Beni | Identificare e collegare lo stesso bene quando effettivamente condiviso fra DM e attività I&C. | Non rappresentare un’attrezzatura GVR come impianto elettrico DPR solo per riusare il modello esistente. Attributi e cataloghi SC/SP/GVR, camere e valvole devono essere recepiti. |
| Classificazione | Conservare cataloghi, relazioni ammesse e classificazione dell’attrezzatura acquisita dai dump o compilata manualmente. | Passaggio SC oltre dieci anni sugli attributi; INAIL legge la classificazione corrente dell’attrezzatura secondo R84. Nessun automatismo nuovo adottato. |
| Stato tecnico e documenti emessi | Distinguere caratteristiche correnti riutilizzabili dai documenti storici immutabili. | Camere, DN e misure, profili DPR e composizione GVR non sono intercambiabili. Conservare quanto le fonti documentano senza inventare fotografie storiche mancanti. |
| Prestazioni e scadenze | Collegare bisogno tecnico, prestazione, offerta e attività, conservando date reali e riferimenti pertinenti. | VP/VS DPR e regola della straordinaria; componenti F/I/N e prima/successiva DM; CND/supplementari/valvole I&C. Una scadenza comune non cancella queste differenze. |
| Preventivi e numerazioni | Conservare documento, righe, accettazione, prezzi e numerazione nel rispettivo sezionale. | Il modello DPR corrente va esteso: numerazione per contesto, attrezzature DM e punti/sottopunti I&C. R91 esclude offerte e fatture miste DM/DPR. |
| Tariffe e composizione | Importi finali esatti e collegamento alla prestazione preventivata; preservare i valori storici e i passaggi di precisione ricostruiti. | Tariffario DPR e prezzo ATEX preventivato; colonne tariffarie GVR e prestazioni multiple; prezzo a corpo/singolo I&C. Non appiattire tutti i calcoli a due decimali intermedi. |
| Attività e riesami | Riferimenti comuni a prestazione, bene, persona e documenti, con tracciabilità. | Macchine a stati e condizioni DM/DPR/I&C restano specifiche. Non imporre il ciclo ispettivo DPR alle attività commerciali I&C. |
| Report, Word/PDF e invii | Collegare generazioni, documento pertinente, versioni ed evidenza di consegna. | VerbalizzAI conserva ancora l’archivio distinto nella candidatura; il suo adattatore al modello comune non è realizzato. I report I&C sono prodotti esternamente e normalmente precedono invio e fatturazione. |
| Fatture e incassi | Nucleo comune con società, intestatario, sezionale, riferimenti alle prestazioni e attribuzioni economiche. | Separazione DM/DPR e DM/EX; fattura al terzo scelta in fatturazione. I compensi I&C dipendono dal proprio percorso commerciale e dal saldo pertinente. |
| Rendicontazione INAIL | Collegamenti verifiche–fatture–documenti e tracciabilità del pacchetto generato. | Tracciato, selezione, nomi Excel/ZIP/PDF e regole DM preservati. Generazione del pacchetto non equivale a invio o accettazione A.S.A. |

### 57.1 Caso concreto di integrazione da usare nella verifica futura

Una stessa attrezzatura GVR può avere una verifica DM e un’attività CND I&C. La matrice deve permettere di consultarle dalla stessa identità del bene conservando prestazioni, report, operatori/ruoli, scadenze e documenti economici propri. Il riferimento al numero del report CND appartiene all’attività/rapporto e rimane consultabile nello storico (R85–R86). Il collaboratore commerciale non diventa il tecnico della verifica. La fattura DM e quella I&C rimangono della società e del percorso pertinenti; non vengono aggregate per la sola presenza dello stesso bene.

La componente di integrità o funzionamento DM non diventa effettuata per la sola registrazione dei CND; una prossima data CND non sostituisce le scadenze F/I/N. Nel database comune si elimina la necessità tecnica di copiare lo stesso bene tra archivi, ma non si eliminano le differenze operative ricostruite nel ponte Garda. La modalità fisica di collegamento e la migrazione devono ancora essere progettate e provate.

### 57.2 Primo lavoro tecnico da sviluppare

Approfondire il mapping delle identità dei beni e delle prestazioni, seguito da quello dei preventivi con sezionali e gerarchia punto/sottopunto. Da questi mapping derivano schema e migrazioni; non si forza il dato DM/I&C nelle sole colonne DPR attuali. Per ogni elemento indicare origine, destinazione, dati conservati, impatto sulle regole e prova pertinente. Le decisioni funzionali già acquisite non richiedono un nuovo questionario.

Documento quadro 1.77. Registro R01–R91 invariato. Aggiunti stato sintetico e prima matrice di integrazione; nessuna modifica applicativa, nessun nuovo collaudo dichiarato e nessuna richiesta di originali S3.

---

## 58. Mapping dettagliato beni DM, camere GVR, valvole e attività I&C

### 58.1 Passaggio svolto e fonti

L’utente autorizza a proseguire. È stato approfondito il mapping delle relazioni dei beni, in sola lettura sul sorgente e sui database di staging adsrl/iec. Riferimenti: adsrl `cust/meta/attrezzature.js`, `cust/meta/attrezzature_vds.js`, `cust/meta/valvole_sicurezza.js`, `cust/gi_views.php`; `cust/_custom.php`, funzioni `gi_valvole_sicurezza_change_after`, `gi_attrezzature_vds_change_after`, `gvr_conf_dati_tecnici_k`, `copia_dati_attrezzatura_su_verifica` e ramo valvole di `ricalcola_scadenze_attrezzatura`; `cust/iec_sincronizza_scadenze.php`. Per I&C rimangono pertinenti attività e ponte già ricostruiti nelle sezioni 44–50.

Nessuna modifica ai gestionali, nessuna esecuzione di endpoint o lavori batch, nessun recupero S3. I conteggi sono controlli circoscritti sul backup e non certificano la qualità di ogni dato o l’attuale situazione operativa.

### 58.2 Le quattro identità da non confondere

| Elemento | Struttura Garda rilevata | Recepimento nel nucleo comune |
|---|---|---|
| Attrezzatura DM | Record autonomo `attrezzature`, collegato alla sede; gruppo, tipo, specifica, matricole, caratteristiche e date. | Identità canonica della stessa attrezzatura consultata da DM e I&C, con dettaglio tecnico DM conservato. Non crearne una copia I&C. Non trasformarla in impianto elettrico DPR. |
| Camera/elemento GVR | Riga dell’array JSON `gvr_conf_dati_tecnici` dell’attrezzatura o della verifica; non è un record autonomo con PK nel percorso letto. | Conservare elenco, ordine, chiavi e contenuto nel dato tecnico pertinente. Non è necessario creare una nuova anagrafica bene per ogni camera. |
| Valvola/accessorio | Record autonomo `valvole_sicurezza`, con propria sede, matricola, tipo accessorio, caratteristiche e date. | Identità distinta dall’attrezzatura, utilizzabile dalle attività I&C e associabile alle attrezzature. Conservare anche i tipi di accessorio presenti nel catalogo, non soltanto l’etichetta della tabella. |
| Associazione attrezzatura–valvola | Tabella `attrezzature_vds`, unicità della coppia; non unicità della valvola o dell’attrezzatura prese singolarmente. | Relazione corrente molti-a-molti, conservata senza introdurre uno storico strutturato dei montaggi (R35). Attività/documenti storici mantengono i propri riferimenti. |

Nella proposta di mapping, l’elenco delle camere può rimanere strutturato nel dato tecnico dell’attrezzatura e della verifica. L’eventuale proiezione relazionale per ricerca o calcoli non deve diventare un secondo dato da compilare. Non si adotta qui uno schema fisico definitivo né si implementa il contenitore JSON comune: si esplicita che la migrazione può preservare l’array senza imporre una nuova entità operativa per camera.

### 58.3 Campi e gruppi di dati da conservare

| Origine adsrl | Destinazione logica | Vincolo di conservazione |
|---|---|---|
| `attrezzature.id`, `sede_operativa` | Identità del bene e sede corrente con mappa dei riferimenti sorgente. | ID sorgente distinto dall’ID canonico; riuso nelle attività I&C tramite la mappa dell’attrezzatura DM originale. |
| Parti della matricola, `matr_informale`, numero di fabbrica, costruttore, modello, anno, reparto, riferimento interno | Identificazione e presentazione dell’attrezzatura. | Conservare i campi distinti e il valore informale: non deduplicare automaticamente sul solo testo della matricola. |
| `gruppo_attr`, `tipo_attr`, `id_spec`, `tipo_attr_verbale`, cataloghi collegati | Classificazione e descrizione per il documento. | Non appiattire gruppo/tipo/specifica in una singola etichetta. Importare i cataloghi effettivi; non ricrearli dai soli default PHP. |
| PS, TS, volume generale, superficie riscaldata, produttività, portata SC/SP, numero panieri, marcatura CE, PED e gruppo fluido | Attributi specifici del dettaglio DM. | Campi e unità distinti; dati non pertinenti non vengono trasformati in attributi obbligatori universali. |
| `sogg_messa_servizio_gvr` | Attributo pertinente alla selezione tariffaria GVR. | Conservare il valore e i criteri art. 4/art. 5 ricostruiti, senza confondere le colonne tariffarie V1–V4 con prima/successiva verifica V1/V2. |
| `gvr_conf_dati_tecnici` e breve descrizione del processo | Elenco tecnico corrente dell’attrezzatura. | Conservare tutte le chiavi, anche quelle meno frequenti; non eliminare dati perché non compaiono nelle sole maschere standard. |
| `matr_insieme`, `id_pacco_bombola` | Riferimenti testuali dell’attrezzatura. | Nel metadato letto sono stringhe, non FK a un’altra attrezzatura. Non convertirli in una parentela canonica dedotta dal testo; conservare formato e significato. |
| `dismessa`, `esente_verifiche` | Condizioni del bene nel contesto DM. | Non equiparare dismissione, esenzione e inattività della sede; preservare i relativi filtri nei percorsi pertinenti. |
| Date ultime/prossime e riferimenti alle verifiche | Stato tecnico corrente e scadenze distinte per prestazione. | Non fonderle nella sola “prossima verifica”; F/I/N, SC/SP, CND e supplementari mantengono il loro significato. |
| `valvole_sicurezza.id`, sede, tipo accessorio, fabbricante, modello, matricola, DN, diametro, area, pressione di taratura, date | Identità, dettaglio tecnico e scadenza dell’accessorio. | Matricola unica per sede secondo il metadato Garda, non globale; DN, diametro e area non sono intercambiabili. |
| `attrezzature_vds.attrezzatura`, `valvola_sicurezza` | Associazione corrente fra le due identità. | Coppia unica e cardinalità multipla; non cambiare gli abbinamenti durante la migrazione sulla base di descrizioni simili. |
| Campi `valv_sicurezza`, `ult_taratura`, `pross_taratura` sull’attrezzatura | Presentazione/aggregati derivati dalle valvole associate. | Non trattarli come ulteriori valvole autonome o come unica fonte delle date di ciascuna valvola. Conservare i valori storici disponibili e ricalcolare con la regola pertinente soltanto nel percorso previsto. |

Le verifiche DM conservano la propria configurazione GVR e i risultati misurati; l’array corrente del bene non sostituisce il contenuto delle verifiche o i file emessi. La migrazione non rende retroattivamente immutabili tutti i vecchi record né ricostruisce fotografie mancanti dagli attributi correnti. I nuovi documenti dovranno rispettare i requisiti di conservazione storica acquisiti.

### 58.4 Camere: forma effettiva del JSON e cautela nella conversione

Interrogate le due colonne JSON in tutte le righe disponibili. Su 9.346 attrezzature, 3.511 valori sono assenti/vuoti e 5.835 sono array JSON validi; fra questi ultimi 1.632 sono array vuoti. I 4.203 array non vuoti contengono complessivamente 5.460 righe. Su 8.700 verifiche, 4.655 valori sono assenti/vuoti e 4.045 sono array JSON validi, di cui 529 vuoti; gli array non vuoti contengono 4.516 righe. Questi conteggi riguardano le tabelle intere, non soltanto i record classificati GVR.

Le chiavi comuni sono `gvr_att`, `gvr_nf`, `gvr_ps`, `gvr_ts`, `gvr_nat`, `gvr_stt`, `gvr_grp`, `gvr_vol`, `gvr_dn`. Nelle verifiche compaiono anche `gvr_pes` e `gvr_tes`; queste ultime sono presenti pure in 56 righe del JSON delle attrezzature. La chiave aggiuntiva `gvr_breve_desc` compare in 27 righe tecniche di attrezzature e 96 di verifiche. Il mapping non scarta queste chiavi né ripulisce automaticamente i valori importati in nome della distinzione teorica fra dati di targa e misure.

Nel codice la chiave interna di abbinamento della riga è descrizione e numero di fabbrica, entrambi normalizzati in minuscolo e senza spazi esterni (`gvr_conf_dati_tecnici_k`). Il riporto dei dati usa tale chiave e tratta selettivamente PES/TES per le prestazioni di funzionamento; il volume è somma del campo `gvr_vol` con un decimale, secondo R80 e l’analisi precedente. Non si converte il DN in litri. La presenza di entrambe le chiavi in un oggetto, talvolta con zero o valori convenzionali, non prova un contributo volumetrico di una tubazione.

La migrazione deve conservare l’array originale e il contesto della riga. Non si eleva descrizione/numero di fabbrica a identificatore globale di una camera e non si esegue il ricalcolo del generatore come “pulizia” dell’import. Le eventuali differenze del riporto, della somma o dell’indicizzazione vanno valutate secondo R73, non corrette implicitamente durante la normalizzazione.

### 58.5 Valvole: cardinalità, scadenze e dati anomali da preservare

Il backup contiene 3.311 valvole/accessori e 3.399 associazioni. Nel controllo eseguito: nessuna associazione orfana e nessuna coppia duplicata; 98 valvole sono associate a più attrezzature (massimo 23), e 552 attrezzature hanno più valvole (massimo 10). Sono presenti 159 valvole senza associazione corrente. L’unicità sede/matricola non presenta duplicati; le matricole ripetute globalmente formano invece 76 gruppi. Perciò una nuova unicità globale della matricola cambierebbe il comportamento e potrebbe impedire l’import.

Nel ricalcolo, Garda seleziona le valvole associate non dismesse e appartenenti a sedi non inattive. Produce una scadenza di tipo `taratura` per ogni coppia attrezzatura–valvola; sulle date sintetiche dell’attrezzatura usa massimo dell’ultima taratura e minimo della prossima taratura. Queste date non identificano una singola valvola e non sono la prova di una taratura di tutte le valvole nello stesso giorno. Modifiche alle valvole e alle associazioni richiamano il ricalcolo degli apparecchi pertinenti.

Sono state riscontrate 9 associazioni fra attrezzatura e valvola con sedi diverse; entrambe le entità risultano non dismesse. Il metadato prevede dipendenze della selezione dalla sede ma il solo percorso letto non dimostra un vincolo universale che elimini questi casi. I dati vengono segnalati e conservati, non corretti automaticamente, né si aggiunge un vincolo di uguaglianza delle sedi alle FK. Non si attribuisce la differenza a errore, trasferimento o impianto condiviso senza ulteriore evidenza.

L’assenza di uno storico strutturato dei montaggi è già una scelta dell’utente (R35). Non si riapre la domanda per la presenza di questi casi: attività e documenti mantengono le evidenze che possiedono; la coppia corrente continua a essere modificabile manualmente nel percorso autorizzato.

### 58.6 Collegamento delle attività I&C agli stessi beni

| Tipo I&C nel database | Sottopunti del preventivo | Riferimento effettivo al bene | Recepimento |
|---|---:|---|---|
| `cnd` | 408 | Attrezzatura DM, nessuna valvola. | Collegamento allo stesso bene canonico; rapporto CND e relative date specifiche. |
| `suppl` | 46 | Attrezzatura DM, nessuna valvola. | Collegamento allo stesso bene; indagine supplementare distinta dalla verifica periodica. |
| `taratura` | 622 | Attrezzatura e valvola DM. | Conservare entrambi i riferimenti nell’attività; date della valvola e aggiornamento degli apparecchi associati nel percorso pertinente. |
| `altro` | 1.150 | Nessun riferimento effettivo al bene; nel dump `attrezzatura` è 0. | Attività/riga libera senza inventare una nuova attrezzatura per rendere valido il collegamento. |

Nei riferimenti effettivi delle righe e delle scadenze I&C letti non sono stati trovati ID mancanti nelle anagrafiche DM. Il conteggio ignora 0 come riferimento assente, coerentemente con i controlli PHP `empty`: trasformarlo in `NULL` nella nuova FK preserva l’assenza, mentre il valore sorgente va mantenuto nella traccia di importazione. Non è una correzione di una reale attrezzatura mancante. Lo scadenzario I&C contiene 5.163 righe CND, 713 supplementari e 3.320 di taratura; non rappresentano altrettante attività già eseguite.

Sei sottopunti di taratura I&C e cinque righe del relativo scadenzario si riferiscono a coppie attrezzatura–valvola non presenti nella tabella delle associazioni correnti. Le due entità esistono: non sono riferimenti orfani. Non si deduce la causa né si elimina il riferimento. In particolare, una FK dell’attività verso la coppia corrente imporrebbe una regola nuova e potrebbe rendere non importabili quelle attività. Nel mapping si conservano quindi riferimenti distinti alle due identità e il contesto storico dell’attività; l’associazione corrente rimane una relazione diversa.

La scelta strutturale consente di preservare il comportamento senza uno storico aggiuntivo dei montaggi. Il controllo di selezione nelle nuove attività dovrà seguire le maschere e le regole Garda pertinenti, senza sostituire il contesto degli storici con l’abbinamento attuale.

Il ponte Garda aggiorna per CND/supplementari le date dell’attrezzatura e per taratura quelle della valvola, poi invoca i ricalcoli relativi. Il nucleo comune deve conservare gli stessi effetti senza una copia separata dell’anagrafica in I&C. Questo non autorizza nuovi automatismi di completamento delle verifiche DM, modifiche alla classificazione o ricalcoli delle componenti F/I/N dalla sola esecuzione dei CND.

### 58.7 Quadrature da eseguire sulla futura migrazione

Le interrogazioni del backup svolte qui non sono una migrazione. La futura prova deve verificare: conservazione dei record e delle associazioni; riferimenti I&C risolti agli stessi beni; nessuna perdita delle chiavi/righe JSON; conservazione delle valvole senza associazione; mantenimento dei riferimenti storici delle coppie non più correnti; trattamento dello zero come assenza; rispetto dell’unicità per sede e della cardinalità multipla; medesimi esiti pertinenti delle scadenze senza deduzioni dalle sole date sintetiche. Le differenze di sede vengono elencate per esame, non sanate silenziosamente.

Il passaggio successivo è il mapping dettagliato dei preventivi: contesto/sezionale, righe DM collegate a prestazioni e gerarchia punto/sottopunto I&C. Non è necessario un nuovo chiarimento per conservare le relazioni appena ricostruite. Uno scostamento operativo concreto, se richiesto, sarà presentato prima dell’implementazione secondo R73.

Documento quadro 1.78. Registro R01–R91 invariato; aggiunto mapping dettagliato e controlli circoscritti dei beni. Nessuna modifica applicativa o al database, nessuna migrazione eseguita e nessuna richiesta di originali S3.

---

## 59. Mapping preventivi: contesti, serie, prestazioni DM e punti/sottopunti I&C

### 59.1 Passaggio svolto e limiti

Su indicazione dell’utente prosegue il mapping, in sola lettura. Confrontati i metadati `cust/meta/preventivi.js` dei tre archivi, `cust/meta/preventivi_righe.js` DM/I&C, gli hook commerciali dei rispettivi `cust/_custom.php`, le viste I&C in `cust/gi_views.php`, i rami di generazione verifiche DM e fatture I&C in `cust/lavori_batch_cli.php`. Per il confronto con il nuovo codice: candidatura 0.8.0, `gestionale/moduli/preventivi/modelli.py` e calcolo della tariffa applicata in `servizio.py`.

Interrogati i tre staging SQLite in modalità di sola lettura. Nessuna esecuzione di endpoint, lavori batch o sorgente PHP; nessun recupero S3 e nessuna modifica dei programmi o dei database. I controlli riguardano i percorsi e il backup ricevuti, non tutte le funzionalità di preventivazione, stampa e fatturazione né lo stato dei gestionali in esercizio. Le strutture di destinazione qui descritte sono un mapping concettuale, non uno schema già implementato.

### 59.2 Identità del preventivo: la serie non coincide necessariamente con l’anno

Nei tre Garda la coppia `serie_preventivo, numero_preventivo` è dichiarata unica. La serie è una stringa, proposta dall’anno della data; il progressivo è proposto da `gi_nextcode_get` nel contesto della serie. Questo non rende obbligatorio che ogni serie contenga soltanto quattro cifre.

| Archivio | Preventivi | Righe | Preventivi con serie diversa da quattro cifre | Serie distinte di questo tipo |
|---|---:|---:|---:|---:|
| adsrl | 1.849 | 9.878 | 231 | 72 |
| ingecert | 1.009 | 1.866 | 1 | 1 |
| iec | 349 | 2.842 | 8 | 5 |

Esempi effettivi di serie adsrl: `2023 /1`, `2024 bis`, `2025/A`, `2025-2bis`, `2026 rev.01`, `2026/AS`, `2026_bis`. In ingecert è presente `2025_annullato`; in iec sono presenti serie `2026/1` fino a `2026/4`. Non si deduce dal suffisso, da solo, una revisione formale, un rapporto padre/figlio, una prestazione EX, un annullamento da applicare o una variante da fondere. Lo stato resta quello del suo campo; il testo della serie e il numero restano quelli originari.

Nel backup non risultano duplicati della coppia all’interno di ciascun archivio. Tra archivi diversi la stessa coppia ricorre spesso: 929 corrispondenze adsrl/ingecert, 321 adsrl/iec e 326 ingecert/iec. Sono collisioni del codice commerciale nel futuro spazio comune, non duplicati da eliminare. I conteggi sono confronti a coppie, non un numero complessivo di preventivi unici.

La destinazione deve quindi distinguere società emittente, ambito/sezionale e serie commerciale. La chiave di provenienza `(archivio, tabella, id origine)` determina l’identità stabile importata; la numerazione resta un attributo del documento nel proprio contesto. Conservare serie letterale, numero e codice visualizzato originario; non trasformare tutte le serie in un anno intero né assegnare nuove numerazioni agli storici.

La revisione strutturata del nuovo DPR è un concetto distinto dai suffissi liberi Garda. La futura chiave del documento dovrà includere il contesto della numerazione e, dove pertinente, la revisione strutturata. Non si impostano nuove revisioni storiche deducendole da `/1`, `bis` o lettere. Il formato definitivo dei nuovi nomi/codici resta un dettaglio da decidere nella sede già prevista; la conservazione delle identità non dipende da quella scelta.

R49 e R91 conservano offerte/fatture DM/EX e DM/DPR separate. Il dump adsrl delle sole tabelle preventivi qui letto non espone un campo ambito EX né prova una regola automatica di classificazione delle sue serie come EX: il contesto operativo dichiarato dall’utente va mantenuto senza inventare una classificazione tramite suffissi. Un’eventuale disambiguazione dei record EX si affronterà con evidenze pertinenti al momento della loro importazione.

### 59.3 Mappa commerciale e operativa

| Origine | Dato o relazione | Recepimento nel nucleo comune | Vincolo da conservare |
|---|---|---|---|
| Tre testate | Cliente, data, serie, numero, ordine, termini di pagamento/esecuzione, note | Testata comune con contesto e provenienza; dettagli specifici del modulo | Stesso cliente non significa stessa offerta o stesso sezionale. L’intestatario fattura distinto si sceglie nella fase già concordata, senza riscrivere il committente del preventivo. |
| Testate DM/I&C | Sede operativa di testata | Riferimento e fotografia pertinenti, conservati secondo il modulo | Non eliminare il contesto della sede per uniformarsi alla sola testata DPR. Non imporre quella stessa sede a ogni storico senza confronto con i dati. |
| Tre testate | Tipo/numero/data documento, CIG, CUP, commessa/convenzione | Riferimenti amministrativi preservati | Il nuovo modello DPR letto non ha colonne dedicate a tutti questi campi; vanno mappati prima dell’import completo. Non ridurli al solo riferimento ordine. |
| Riga DM | `n_riga`, `attrezzatura`, `tipo_verifica` | Riga ordinaria collegata al bene canonico; prima/successiva DM come significato specifico | DM `V1/V2` non sono DPR `VP/VS`: i codici non condividono una sola enumerazione funzionale. |
| Riga GVR | `tipo_verifica_gvr` | Composizione tecnica collegata alla riga e alla verifica | Conservare le sette combinazioni; una multipla resta una prestazione e un verbale con più componenti. |
| Riga DM | Standard, sconto, applicata, comando di ricalcolo | Valori economici della riga e regola di calcolo DM | Gli storici si importano senza rivalutazione dal tariffario corrente. Il flag di ricalcolo è un comando operativo, non una licenza a ricalcolare tutto durante la migrazione. |
| Riga DM | `verifica`; verifica `preventivo_riga` | Collegamento commerciale–incarico/verifica, con provenienza di entrambi | Preservare l’aggancio reciproco esistente; non creare una nuova verifica solo perché cambia l’ID fisico della riga. |
| Riga DPR | Impianto, periodica/straordinaria, tariffa | Riga ordinaria pertinente a DPR | Conservare gli specifici flussi già concordati e il confine di ambito. |
| Punto I&C | Titolo, descrizione, nota finale, tipo prezzo, posizione | Nodo commerciale di primo livello | Il punto organizza i sottopunti; non è automaticamente un’attività tecnica. |
| Sottopunto I&C | Parent `punto`, numero sottopunto, tipo servizio, attrezzatura/valvola | Nodo figlio e attività correlata in modo stabile | Il sottopunto costituisce l’attività Garda, non due lavori indipendenti. Il legame fra rappresentazione commerciale e operativa deve restare uno-a-uno. |
| Prezzo I&C singolo | Importo e sconto sul sottopunto | Valore economico sul figlio | Il punto aggrega e presenta; non ha un secondo prezzo da sommare. |
| Prezzo I&C a corpo | Importo e sconto sul punto | Valore economico sul padre, condiviso dalle attività figlie | I sottopunti non duplicano il prezzo. La fattura del corpo addebita il padre una volta e conserva tutti i riferimenti pertinenti. |
| Testata/righe I&C | Sconti assoluti/percentuali e importi intermedi/finali | Strategia economica I&C e valori finali in centesimi | Preservare precisione e ordine delle operazioni, non riusare automaticamente il solo sconto percentuale della riga DPR. |
| I&C | Collaboratore di testata, percentuale della riga economica, fattura collaboratore | Relazioni commerciali e base compenso | Rimangono distinte dall’esecutore tecnico; un corpo non produce un compenso duplicato per ciascun figlio. |

Una rappresentazione minima praticabile è una testata comune con righe ordinarie e, solo per I&C, righe punto/sottopunto con parent. Lo stato operativo e i dati specifici devono poter essere collegati alla riga senza obbligare ogni punto, riga libera o riga DPR ad avere gli stessi campi. Non serve introdurre gerarchie arbitrarie: Garda I&C qui ricostruito usa due livelli, punto e sottopunto. Questa è una proposta tecnica per conservare le logiche, non un nuovo flusso per l’utente o l’adozione già avvenuta di una tabella fisica definitiva.

### 59.4 DM: prezzi, incarichi, totali e controlli

Ogni riga DM richiede l’attrezzatura; il tipo GVR è obbligatorio per GVR e viene azzerato per gli altri gruppi. La tariffa standard deve essere positiva. `calcola_tariffa_standard` distingue prima/successiva, soggezione a messa in servizio e componenti GVR secondo R81; per SC/SP risolve gruppo/tipo/ID specifica e tariffa prima/successiva. I codici tariffari GVR `V1–V4` non vanno confusi con il tipo verifica DM `V1/V2`.

Le maschere consentono la generazione della verifica da riga accettata con riesame preventivo fatto/conforme, attrezzatura non dismessa e verifica ancora assente. Il batch copia attrezzatura, tecnico, tipo, componenti e tariffe, propone esito positivo e, per successive, regime `A2`; collega la verifica alla riga e la riga alla verifica. La prevenzione della ripreventivazione accettata aperta presente nell’hook, con i suoi confronti esatti descritti nel rapporto 07, resta una regola da riprodurre senza attribuirle una copertura più ampia di quella letta. Il batch da scadenze usa ancora `$merge=false`: nessuna fusione automatica delle componenti in un’offerta multipla.

La fatturazione da riga DM è condizionata nella maschera a verifica effettuata, riesame verifica fatto/conforme e assenza di fattura sui due riferimenti legacy. I percorsi I&C non richiedono per questo lo stesso riesame ispettivo: una tabella comune non rende comuni tutti i controlli di abilitazione delle azioni.

`gi_preventivo_totali_update` DM somma le tariffe standard/applicate di tutte le righe del preventivo nella query letta, senza filtrare lo stato della riga, e calcola subtotali SC/SP e GVR, prime e successive. Quando `lic_gest='T'`, aggiunge `prz_lic_gest` al totale standard e scontato. Il backup contiene 12 preventivi con questo flag, per 4.020 euro complessivi: la voce non può scomparire migrando soltanto le righe delle verifiche. Si preservano i dati e la distinzione già usata nella stampa; il riscontro non dimostra da solo ogni successivo trattamento fiscale della voce.

Il badge di fatturazione DM diventa totale contando tutte le righe; il calcolo I&C invece esclude dal denominatore i sottopunti rifiutati. La candidatura DPR, a sua volta, somma le righe considerate attive nella propria funzione. Queste differenze vietano di applicare indiscriminatamente un solo aggregatore del prototipo a tutti gli archivi. Totale dell’offerta emessa, quota accettata e quota fatturata restano concetti distinti; non si riscrivono i totali originari per farli coincidere con una nuova convenzione.

Fonti DM: `_custom.php:1101–1349,1406–1443,2422–2427,2926–2993`; `meta/preventivi_righe.js`, permessi da riga 27 e campi da riga 287; `lavori_batch_cli.php:296–368,387–463`. La protezione del contenuto commerciale accettato e le offerte integrative già richieste in R39 restano requisiti del nuovo sistema; non si interpreta la lettura di singoli permessi Garda come prova di una protezione storica completa.

### 59.5 I&C: gerarchia, prezzi e fatturazione del corpo

Il backup contiene 616 punti e 2.226 sottopunti. Distribuzione:

| Ruolo | Prezzo a corpo | Prezzo singolo |
|---|---:|---:|
| Punto | 45 | 571 |
| Sottopunto | 70 | 2.156 |

Non risultano sottopunti senza parent, parent di ruolo errato, parent di un altro preventivo, numerazione di punto incoerente o tipo prezzo diverso dal proprio parent. Non risultano duplicati del numero punto o della coppia numero punto/numero sottopunto. Non risultano importi netti sui nodi che non devono ospitare il prezzo. I sottopunti a corpo non hanno stati commerciali discordanti nel medesimo punto, coerentemente con la propagazione prevista dall’hook.

Ci sono anche 13 punti senza sottopunti (10 a corpo, 3 singoli), e un punto può avere fino a 40 figli nel backup. I punti vuoti vanno conservati nell’import, senza cancellarli o creare attività fittizie. La cardinalità non va ridotta a un unico figlio perché normalmente il report riguarda una singola attrezzatura: report individuale e organizzazione dell’offerta sono concetti diversi.

Gli hook validano l’esistenza del punto, la numerazione, il prezzo prima dell’accettazione e gli sconti; azzerano prezzo/stato operativo sui nodi pertinenti. Per il corpo, il cambiamento dello stato commerciale di un figlio si propaga ai fratelli. I permessi e gli indicatori `almeno_un_sottopunto_*` vincolano modifiche, inserimenti e cancellazioni; non si rendono i fratelli attività eseguite per la sola accettazione commerciale comune.

Nel batch fattura viene selezionato un sottopunto accettato/effettuato, non il punto. Per il prezzo singolo si usa il suo `imp_finale`. Per il corpo si usa il valore del punto, si elencano le descrizioni di tutti i sottopunti, si evita il doppio addebito del punto nello stesso batch e si associa la fattura al punto e ai figli. Il ramo letto non introduce un controllo che tutti i fratelli siano effettuati: non va aggiunto come presunta regola Garda. La prassi dell’utente di attendere normalmente il report pronto resta distinta da un nuovo blocco universale, già escluso dalla sezione 51.

Il calcolo usa sconti di nodo e testata, percentuali o assoluti. Lo sconto assoluto di testata è ripartito proporzionalmente con precisione intermedia otto decimali, quindi gli importi di riga sono arrotondati tramite l’helper a due decimali. Nel backup vi sono 12 preventivi con sconto assoluto di testata e 6 percentuale; sulle righe con sconto valorizzato risultano entrambe le modalità, sia per punti a corpo sia per sottopunti singoli. Non sono funzioni solo teoriche. Il passaggio a importi finali in centesimi non autorizza arrotondamenti intermedi anticipati o redistribuzioni silenziose di differenze di un centesimo.

Fonti I&C: `_custom.php:497–685,809–1104,1360–1404`; `meta/preventivi_righe.js`, permessi e struttura dei campi; `gi_views.php:151–183`; `lavori_batch_cli.php:305–510`. La prassi di invio report prima di fatturazione/incasso (R90) e la gestione dei compensi già ricostruita nelle sezioni 47–50 restano applicabili.

### 59.6 Documenti, nomi e conservazione della fotografia commerciale

Gli hook DM e I&C `gi_rpt_preventivi_base_file_name_get` producono, per il singolo documento, la base `Preventivo {numero/serie} del {data} {ragione sociale}`, sostituendo `/` con `-` nei segmenti numero/data; il risultato sostituisce i caratteri esterni all’insieme consentito dalla regex con spazi, viene rifilato e troncato a 80 caratteri. Per la stampa complessiva usano `Preventivi stampati il {data e ora}` con formato `Y-m-d_H-i-s`. È la base del nome, non una prova dell’estensione o del nome effettivo di ogni allegato conservato.

Gli hook propongono inoltre destinatario dalla sede, oggetto dalla decodifica e testo email. Le proposte non sono autorizzazioni all’invio automatico. Fonti: DM `_custom.php:2544–2580`; I&C `_custom.php:686–724`.

Importare nomi e riferimenti documentali effettivi quando disponibili; nessuna rinomina degli originali per uniformare i tre ambiti. Per i nuovi emessi conservare fotografia commerciale, modello, Word/PDF, versioni e invii secondo i requisiti già acquisiti e il ciclo di anteprima/correzione. Dove Garda stampa dati anagrafici correnti, una rigenerazione dal solo database non prova il contenuto di un vecchio documento emesso: senza gli originali si conserva il limite dell’evidenza, anziché presentare una ricostruzione come originale. Nessuna richiesta di recupero S3 in questo passaggio. Le convenzioni fatture/schede/verbali INAIL già catalogate nei rapporti 06/07 restano separate e vincolanti.

### 59.7 Sconti frazionari DM (PREV-01, chiusa con R92)

La formula DM letta è `gi_bcmul(tariffa_standard, bcsub('1', gi_bcdiv(sconto, '100', 2), 2))`. L’helper `gi_bcdiv` arrotonda il rapporto a due decimali prima della moltiplicazione; `gi_bcmul` arrotonda poi l’importo alla scala monetaria (default due). Non è il calcolo della percentuale esatta seguito dal solo arrotondamento monetario finale.

Nel backup ci sono 14 righe DM con sconto frazionario: 11 al 4,5% e 3 all’8,5%. Un confronto numerico in Python/Decimal, circoscritto a queste righe e alle formule lette, riproduce tutti i 14 importi memorizzati con il rapporto anticipatamente arrotondato; tutti e 14 differiscono dal risultato della percentuale esatta. Non è un’esecuzione PHP, un collaudo del nuovo modulo o una prova di migrazione.

| Tariffa standard | Sconto indicato | Rapporto usato da Garda | Applicata memorizzata | Con percentuale esatta e arrotondamento finale |
|---|---:|---:|---:|---:|
| 299,06 € | 4,5% | 0,05, equivalente al 5% | 284,11 € | 285,60 € |
| 260,31 € | 8,5% | 0,09, equivalente al 9% | 236,88 € | 238,18 € |

Fonti: DM `_custom.php:2422–2427`; framework `std/fw/gi_common.php`, `gi_get_bcscale` da riga 1578 e helper `gi_bcdiv`, `gi_bcmul`, `gi_bcround` da righe 1663–1690. La nuova candidatura DPR usa un’altra formula (`round` su centesimi e sconto in centesimi di punto): non è quindi un motore economico DM/I&C già equivalente; questa lettura non estende automaticamente a DPR o I&C la decisione sul calcolo DM.

**PREV-01 — chiusa con R92:** alla proposta di applicare la percentuale esatta sui nuovi preventivi DM, mantenendo integralmente gli importi storici, l’utente conferma “sì ok”. È quindi approvata la modifica funzionale ai sensi di R73: nessun arrotondamento anticipato del rapporto percentuale, arrotondamento del solo importo monetario finale. Preventivi importati, accettati ed emessi conservano valori e sconti originali, senza ricalcolo. La regola è acquisita per l’implementazione successiva; nessuna modifica del software è stata eseguita per il solo fatto di registrare il consenso. I dettagli tecnici e il perimetro sono consolidati nella sezione 60.

### 59.8 Estensioni del prototipo e verifiche successive

Il modello preventivi DPR 0.8.0 ha chiave anno/numero/revisione, righe piatte con impianto facoltativo e tipo periodica/straordinaria, sconto percentuale, fotografie e documenti/invii. È una base utile, ma prima di accogliere DM/I&C servono contesto della numerazione e serie letterali importate, riferimenti ai beni DM, tipologie specifiche, gerarchia I&C a due livelli e calcoli economici distinti. Lo storico dei documenti accettati deve rimanere protetto mentre avanzano gli stati operativi delle attività.

Le query del backup non hanno trovato righe senza preventivo nei tre archivi, né riferimenti DM/DPR a beni o verifiche inesistenti nei controlli svolti; il collegamento reciproco riga DM–verifica risulta coerente per le righe collegate. Questo dà una base concreta al mapping, non attesta una migrazione eseguita. Saranno necessarie quadrature su record, serie/codici, prezzi, sconti, totali, licenza DM, gerarchie, stati specifici, collegamenti alle fatture e compensi; gli importi importati resteranno quelli originali anche quando un ricalcolo evidenzia differenze.

PREV-01 è ora chiusa con R92. La sezione 60 consolida il disegno minimo del nucleo e le condizioni della migrazione delle strutture appena mappate. Le altre regole fondamentali individuate vengono mantenute; eventuali altri scostamenti emersi dal confronto vanno valutati ai sensi di R73 prima della loro applicazione.

Documento quadro 1.79. Registro R01–R91 invariato; aggiunto mapping preventivi e aperto PREV-01 con evidenza numerica. Nessuna modifica applicativa o al database, nessuna migrazione eseguita e nessuna nuova regola economica approvata.

---

## 60. Sconti DM approvati e consolidamento del nucleo minimo

### 60.1 Consenso e confine della modifica economica

9 ottobre 2026. L’utente risponde “sì ok” alla correzione proposta in PREV-01. Acquisita R92: percentuale esatta nei nuovi preventivi DM, con arrotondamento soltanto dell’importo monetario finale; importi storici integralmente conservati. La precedente descrizione di PREV-01 come domanda aperta è superata.

Specifica per il futuro calcolo DM: tariffa standard × (1 − sconto / 100), eseguita con aritmetica decimale esatta; il rapporto percentuale non viene quantizzato a due decimali. L’importo finale viene arrotondato ai centesimi con criterio metà verso l’esterno, coerente con l’helper monetario Garda per importi positivi. I valori monetari finali possono essere salvati come centesimi interi. Non usare i float binari né il `round` Python come sostituto implicito dell’intero percorso decimale. Questo precisa l’implementazione della correzione approvata, senza aggiungere un nuovo sconto, cambiare il tariffario o spostare il punto in cui si forma l’accordo commerciale.

Gli esempi della sezione 59 restano evidenza del comportamento precedente: la riga storica 299,06 € / 4,5% conserva 284,11 €; una nuova riga DM con gli stessi input produce 285,60 €. Analogamente 260,31 € / 8,5% conserva 236,88 € sullo storico e produce 238,18 € sulla nuova riga. L’importazione non invoca il nuovo calcolo sui vecchi valori. La nuova offerta integrativa segue la regola nuova senza modificare l’offerta accettata cui si aggiunge.

La decisione non autorizza una correzione degli importi delle fatture, una revisione retroattiva degli emessi o una semplificazione dei calcoli I&C. Per I&C resta il percorso di sconti assoluti/percentuali e ripartizione con precisione intermedia descritto nella sezione 59.5. Il calcolo DPR sarà confrontato con le proprie regole nel percorso di implementazione pertinente; R92 non cambia autonomamente il prototipo DPR in collaudo.

### 60.2 Nucleo minimo risultante dai mapping

La struttura comune deve conservare le relazioni fondamentali senza estendere a tutti i moduli i vincoli del solo DPR. Il seguente consolidamento è progettuale: nessuna tabella è stata creata o modificata in questo passaggio.

| Componente | Identità e relazioni minime | Comportamento da preservare |
|---|---|---|
| Contesto | Società emittente, ambito, sezionale e serie di numerazione pertinenti | Cliente condiviso e servizio amministrativo comune; documenti DM/DPR e DM/EX separati. I&C S.r.l. non viene disattivata per effetto di una vecchia assunzione della prova di migrazione. |
| Anagrafiche | Clienti, sedi, persone e riferimenti di provenienza | Corrispondenze note riutilizzate; dati commerciali per ambito preservati. Nessuna fusione per sola omonimia o perdita della fotografia negli emessi. |
| Beni | Identità comune per impianti DPR, attrezzature SC/SP/GVR e accessori; stato tecnico pertinente | I&C richiama gli stessi beni DM. Camere GVR nei dati tecnici, con ordine/chiavi preservati; valvole autonome e collegamenti multipli correnti. |
| Preventivi | Testata con contesto, serie letterale, numero e versione pertinente; righe ordinarie o punto/sottopunto | Righe DPR/DM piatte; gerarchia I&C a due livelli. Prezzo a corpo sul padre, singolo sul figlio; contenuto commerciale accettato conservato. |
| Lavoro tecnico | Incarico/verifica DPR/DM e attività I&C collegati alle rispettive righe | Collegamento commerciale stabile; stati e controlli specifici del modulo. Il sottopunto I&C non diventa due attività; il punto commerciale non diventa un incarico tecnico. |
| Rapporti e documenti | Documento, collegamento al lavoro/bene, versione, file effettivo e riferimento del report esterno | Fotografia dei verbali emessi, revisioni e storico riesami; numero report CND richiesto. Integrazione futura del produttore tecnico esterno senza duplicarne ora il generatore. |
| Scadenze | Tipo/componente, bene, eventuale valvola correlata, fonte e lavoro pertinente | Componenti GVR distinte e tarature per coppia attrezzatura/valvola. Data sintetica dell’attrezzatura come riepilogo, non sostituzione delle scadenze elementari. |
| Amministrazione | Fattura/nota di credito, righe con provenienza economica, XML/esiti e movimenti con attribuzioni | Nucleo condiviso con confini di ambito; prezzo a corpo fatturato una volta; un pagamento può coprire più fatture compatibili. Compensi e fatture collaboratori I&C preservati. |
| Tracciabilità | Mappa origini, dati sorgente, eventi, importazioni e quadrature | ID canonici stabili; codici commerciali e file originali conservati; nessuna perdita di record o cambiamento funzionale nascosto da una deduplicazione tecnica. |

Ruolo tecnico e collaboratore commerciale rimangono relazioni diverse anche quando richiamano la stessa persona. La scheda impianto/attrezzatura corrente può evolvere; il contenuto degli emessi rimane quello pertinente alla loro versione. Rendicontazione INAIL e invio report I&C rimangono percorsi specifici: un report CND associato al bene non diventa per questo una verifica periodica da rendicontare.

### 60.3 Confronto circoscritto con lo schema della prova e il prototipo

Letta la copia locale della prova di migrazione: `analysis/poc/gestionale/schema/schema.sql`, intestata v0.1, e `tools/migrate.py`. Il confronto riguarda quella copia, non certifica tutte le eventuali revisioni degli altri materiali ricevuti. Non è stato eseguito lo script di migrazione.

La prova già rappresenta clienti/sedi/asset, origini, stato tecnico JSON, parent delle righe I&C, incarichi e scadenze. Sono elementi riutilizzabili del disegno, da raccordare al nuovo sorgente Python e ai requisiti successivi; la copia non costituisce uno schema operativo definitivo. In particolare:

- `preventivi_righe.stato_riga` nella copia SQL è obbligatorio con un default commerciale; Garda I&C invece mantiene il punto privo di stato commerciale/operativo proprio. Il modello operativo deve poter rappresentare questo significato senza inventare un’accettazione del punto. Le attività dei figli restano distinte dalla loro eventuale accettazione comune a corpo.
- `scadenze` nella copia ha unicità bene/tipo e non espone la valvola correlata. Per le tarature di attrezzature con più valvole quella chiave da sola non rappresenta tutte le scadenze per coppia rilevate in Garda. La destinazione deve mantenere l’identità pertinente alla coppia e può derivare il riepilogo dell’attrezzatura senza collassare i record.
- Alcuni collegamenti alle righe/attività/fatture sono annotati come FK logiche; lo schema operativo deve dichiarare i vincoli realmente pertinenti e verificare la coerenza in fase di caricamento. Questo non autorizza a imporre allo storico I&C un collegamento alla sola associazione attrezzatura–valvola attualmente presente, già escluso nella sezione 58.
- La copia usa `REAL` per importi. La struttura operativa deve conservare gli importi finali esatti e i percorsi di calcolo specifici, comprese R92 e la precisione intermedia I&C; cambiare il tipo di colonna non rende equivalenti gli algoritmi.
- `tools/migrate.py` elimina e ricrea il database di destinazione. È un comportamento da prova a secco, incompatibile con il riallineamento incrementale richiesto: va sostituito prima di importare su una destinazione con dati nativi o ID da preservare.

Il prototipo DPR 0.8.0, distinto da questa prova SQL, ha già fatture con contesto società/ambito e allocazioni degli incassi, ma preventivi con chiave anno/numero/revisione e verifiche centrate sull’impianto DPR. Non basta aggiungere una selezione “DM” alla maschera: prima servono i riferimenti e i significati descritti nelle sezioni 58–59. Le estensioni verranno introdotte per moduli, preservando il percorso DPR collaudato e senza dichiarare implementate DM/I&C sulla base di sole colonne comuni.

### 60.4 Contratto minimo della futura migrazione

Per ogni famiglia di record il mapping deve esplicitare: archivio e tabella sorgente, ID origine, ID canonico, trasformazioni puramente rappresentative, campi specifici conservati, relazioni da risolvere, dati storici non ricalcolabili, anomalie da elencare e quadratura attesa. La tabella delle origini è un indice persistente: una seconda importazione della stessa identità ritrova lo stesso record, anziché ricrearlo o identificarlo con ragione sociale, matricola o codice preventivo.

Prima passano le identità, poi i collegamenti: anagrafiche e cataloghi; beni e associazioni; preventivi/punti/sottopunti; lavori tecnici, rapporti e scadenze; documenti e relazioni amministrative pertinenti. L’ordine descrive dipendenze, non una nuova prassi di lavoro o l’esecuzione già avvenuta di una migrazione. Un corpo I&C conserva un solo importo economico e tutti i figli, anche nel riallineamento; una verifica DM già agganciata non viene rigenerata; una scadenza per valvola resta distinta dalle altre dello stesso bene.

Le righe sorgente e le corrispondenze devono restare consultabili per confrontare quantità, importi e riferimenti. Gli storici monetari non vengono ricalcolati; le serie non vengono reinterpretate come revisioni; gli originali documentali assenti restano metadati di contenuti da recuperare, senza sha256 di contenuto inventati o nomi cambiati. Le quadrature includono il mantenimento delle 14 righe con il vecchio calcolo sconto e l’esito diverso, approvato, dei nuovi esempi DM.

Il futuro riallineamento durante la convivenza dovrà definire l’autorità dei dati nei rispettivi ambiti e proteggere documenti/attività nativi da una sovrascrittura indiscriminata del dump. Questo è lavoro necessario prima dell’uso operativo dell’import incrementale, non un’autorizzazione generica a scegliere silenziosamente quale modifica prevalga in caso di conflitto. In questa fase nessun dato è stato aggiornato e non è stata introdotta una politica di cancellazione degli assenti.

### 60.5 Stato del passaggio e seguito

PREV-01 è chiusa; R92 è acquisita, non ancora implementata. Consolidati beni, struttura commerciale, lavoro tecnico, amministrazione e condizioni di conservazione nel nucleo comune. Resta da trasformare questo disegno in schema operativo e migrazioni, con prove sulle cardinalità, sui calcoli specifici e sulla stabilità delle identità; quindi estendere progressivamente il codice. La correzione sconti approvata non comporta un rilascio del software in questo turno.

Documento quadro 1.80. Registro esteso a R01–R92, con consenso economico DM e PREV-01 chiusa. Aggiunto consolidamento progettuale con riscontri sul materiale della prova e sul prototipo; nessuna modifica applicativa o al database, nessuna migrazione o nuova suite di collaudo eseguita.

---

## 61. Schema operativo di progetto v0.3 e diagramma E-R completo

### 61.1 Richiesta e risultato

L’utente autorizza il passaggio allo schema operativo e richiede anche un E-R di tutto il database integrato. R93 acquisisce la richiesta. Creati nuovi artefatti separati dal prototipo DPR e dalle prove precedenti: DDL di destinazione v0.3, diagramma HTML autonomo/offline, SVG generale, sorgente Mermaid completo, dizionario dei campi, copertura tabelle sorgente e rapporto di verifica. Nessun database aziendale o applicativo è stato modificato e nessuno script di importazione dei dump è stato avviato.

Lo schema comprende **85 tabelle, 925 campi e 230 FK dichiarate**. Sono incluse anagrafiche, utenti/permessi, beni e classificazioni, tariffe/preventivi, incarichi/verbali, rapporti I&C, documenti/modelli/firme/strumenti/esportazioni, fatturazione/XML/esiti/incassi/compensi, scadenze/INAIL e tracciabilità di migrazione. È l’intero schema di destinazione proposto, non una dichiarazione che tutte le regole dei tre Garda siano già implementate o esaustivamente auditate.

### 61.2 Diagramma e dizionario

`09_Diagramma_ER_integrato_v0.3.html` contiene una vista generale di tutte le tabelle e otto viste per area. Zoom, trascinamento, ricerca per tabella/campo, selezione e scheda laterale permettono di leggere i campi e le FK. La vista generale e quelle per area usano forme compatte; tutti i campi sono presenti nelle schede e nel dizionario. I colori distinguono le famiglie. Le viste di dettaglio includono anche parent esterni all’area per conservare il contesto dei collegamenti.

Le frecce rappresentano FK SQL reali. I registri generici di audit/migrazione/mail hanno anche puntatori logici entità/ID: sono descritti nelle note, senza inventare una FK fisica verso una sola tabella. Il diagramma è generato dai metadati dello stesso DDL; non è un disegno indipendente da mantenere manualmente. Il pacchetto include SVG e Mermaid modificabile, oltre al dizionario completo.

### 61.3 Principali adattamenti recepiti

- Documenti con ID interno e SHA-256 nullable per contenuti non recuperati; associazioni documentali tipizzate. Nessun hash inventato per gli originali S3 assenti, nessuna richiesta dei contenuti in questo turno.
- Chiavi dei preventivi contestuali con serie letterale e versione; punti I&C privi di stato proprio, parent nello stesso preventivo e prezzo collocato sul nodo pertinente. Compensi I&C conservati come relazioni commerciali distinte dal tecnico.
- Asset condivisi, accessori autonomi, associazioni correnti multiple e attività con FK indipendenti ad attrezzatura/valvola; matricola accessorio unica per sede. Nessuno storico dei montaggi introdotto.
- Scadenze distinte per bene/tipo e, quando pertinente, valvola; componenti GVR e dati legacy conservabili. La classificazione letta all’export INAIL rimane quella corrente del bene; il tracciato effettivamente generato viene registrato nel pacchetto.
- Importi monetari finali in centesimi interi; percentuali, quantità e prezzi unitari intermedi decimali in testo. Nessuna colonna `REAL`. Gli algoritmi specifici e R92 sono descritti nel documento tecnico; nessun importo storico ricalcolato.
- Generazioni Word/PDF ed esiti XML registrabili per versione; rapporti CND esterni con numero; riesami storici con esito e nota. Fatture, scadenze economiche, incassi/attribuzioni e ciclo collaboratori rappresentati.
- Progressivo annuale DPR condiviso VP/VS; contesti DM e fiscali distinti. Registro identità e record di importazione per preparare la convivenza incrementale.

Le strutture non autorizzano l’uniformazione dei flussi, fatture miste DM/DPR o DM/EX, obblighi di report non concordati o nuovi automatismi di invio. Le transizioni, le autorizzazioni, i blocchi sugli emessi, i calcoli fiscali, i limiti sugli incassi e le condizioni INAIL richiedono anche servizi applicativi specifici. Il DDL è una base progettuale eseguibile, non la sostituzione delle logiche applicative analizzate.

### 61.4 Verifiche e limiti

Eseguita la creazione completa su SQLite in memoria con FK attive, analisi dei riferimenti, `integrity_check` e `foreign_key_check`: nessuna FK irrisolta nel DDL e nessun errore nei controlli sulle fixture. Superate **18 prove**, fra cui contesti di numerazione distinti, parent I&C improprio, prezzo duplicato sul figlio a corpo, associazioni multiple e storiche valvole, scadenze elementari, matricola per sede, allegati con contenuto assente, riferimenti documentali, pagamento unico attribuito a più fatture, VP/VS e R92.

Verificata la presenza di tutte le 85 tabelle e 230 FK nella tavola SVG generale e la copertura delle nove viste; controllata la sintassi JavaScript e renderizzate tavole SVG per ispezione visiva. Il file HTML non usa script remoti. Non è stato eseguito un collaudo interattivo nel browser Windows dell’utente.

Il CSV di copertura censisce **165 tabelle e 2.134 definizioni di campo** nei tre staging, inclusi elementi del framework ed esclusi i metadati locali della conversione. Indica destinazioni strutturate e conservazione raw: non dimostra che l’importer o l’audit funzionale di ogni tabella sia completato. Nessuna migrazione dei dump, regressione XML storici, prova applicativa end-to-end o verifica PostgreSQL/Alembic eseguita in questo passaggio. Il nuovo schema non va applicato direttamente al database della candidatura DPR 0.8.0.

### 61.5 Artefatti e seguito

Nel pacchetto `Gestionale_AD_schema_ER_v0.3_2026-10-09.zip` sono presenti DDL, HTML, SVG, Mermaid, metadati, dizionario, copertura CSV, verifica JSON, script ripetibile di verifica e istruzioni. Non sono inclusi dump aziendali, credenziali o originali S3. Disponibili anche SQL, HTML e note come file singoli.

Il seguito riguarda modelli SQLAlchemy/Alembic e migrazioni separate: adattamento del DPR esistente, mantenimento degli ID canonici nelle reimportazioni e policy dei conflitti prima dell’uso operativo. Il registro e i vincoli preparano queste attività ma non costituiscono un importer incrementale già disponibile. L’adattatore VerbalizzAI dovrà essere collaudato sulla versione consolidata pertinente; non si cambia il software ora in esercizio sul VPS per effetto di questa consegna.

Documento quadro 1.81. Registro esteso a R01–R93; creato e verificato lo schema progettuale v0.3 con E-R completo. Codice applicativo DPR/VerbalizzAI e database esistenti invariati; nessun cutover eseguito.

---

## 62. Primo percorso GVR completo e applicabilità delle componenti

### 62.1 Lavoro e caso reale

Dopo la consegna E-R l'utente conferma il percorso proposto con “ok”. Eseguito il primo riscontro documentale dalla scheda GVR a preventivo, incarico, verbale, riesame, fattura/incasso, scadenze e INAIL. Creato `11_Percorso_GVR_e_riscontro_schema_integrato_2026-10-09.md`. È un confronto funzionale e sui dati, non un collaudo applicativo o una migrazione.

Copia staging adsrl aperta in sola lettura. Catena anonima: attrezzatura 5762, preventivo 2080, riga 12332, verifica 8490 `V/GVR/1678/26`, fatture_clienti 686. Riga accettata, RC T/C, successiva F, standard 184,04 €, sconto 15%, applicata 156,43 €, A2 e contributo 9,20 € sulla tariffa standard. Rilascio 03/09/2026, prossima F/data_pvp 02/09/2029, effettuata, RV T/C, esp_inail F. Legame riga–verifica reciproco. Il riferimento fattura non prova disponibilità PDF o pagamento; nessun originale S3 recuperato.

### 62.2 Mapping e regole conservate

Il caso è rappresentabile con asset, dati tecnici, righe, incarichi, contenuti/versioni verbali, riesami, documenti, incassi, scadenze e pacchetti INAIL del v0.3. Servizi, tariffazione, numeratori, aggiornamenti, export e blocchi devono ancora essere realizzati. Nessuna modifica al DDL o codice applicativo.

Confermata R81: una riga multipla F+I produce un incarico/verbale e due scadenze; due righe F/I producono due incarichi/verbali. La multipla successiva usa V4, senza somma automatica delle componenti; batch dalle scadenze merge=false conservato. La combinazione è uno scenario supportato dal codice/requisito, non un record multiplo trovato nella tabella verifiche del dump.

Classificazione INAIL dagli attributi correnti R84; data_pvp dalle componenti del singolo lavoro; nomi N01–N14 e deduplicazione fattura condivisa conservati. Export effettuata/fattura/documenti/non già esportata; generazione distinta da caricamento manuale A.S.A. Precedenti F/I/N separati e scadenze elementari preservati. Le eccezioni già catalogate non sono implicitamente eliminate; i flussi DPR non vengono estesi a DM come se fossero già regole Garda.

### 62.3 Chiarimento dell'utente e ricontrollo del confronto date

L'utente precisa: “le tubazioni non hanno visita interna”. R94 acquisisce il chiarimento. Il catalogo conferma `tipo_ver_gvr_3=N.A.` per tutte le quattro classificazioni con famiglia tubazioni; zero verifiche contenenti interna sulle attrezzature attualmente classificate come tubazioni. La famiglia FK 4/codice a4 è distinta dal codice all.7 a4. La matrice generale GVR non impone ogni componente a ogni famiglia. Non si creano date o obblighi di visita interna per tubazioni.

La precedente segnalazione intermedia di selezione del più vecchio per `gvr_tub_stato` era errata: nel codice `strcmp(data_integrita,data_interna)<0` seleziona interna se successiva, quindi il più recente; a parità resta integrità. G07 nel rapporto originario era corretto ed è confermato. Nessun quesito GVR-01 resta aperto e nessuno scostamento software è proposto su quella base.

Il campo ha etichetta “Stato di conservazione” e visibilità generale GVR non puro F, anche se collocato nel gruppo tubazioni. I 103 beni con entrambi i riferimenti integrità/interna sono 85 generatori vapore, 15 acqua surriscaldata e 3 recipienti secondo classificazione attuale; zero tubazioni. I conteggi intermedi di date/testi diversi non provano un'anomalia. L'applicabilità storica non si deduce dai soli riferimenti e non si riscrive. Rapporto 07 aggiornato a 1.4 per precisare questi limiti.

### 62.4 Stato e seguito

Completato il primo percorso documentale GVR ordinario e la variante multipla distinta. Nessuna nuova scelta bloccante emersa, nessuna migrazione o prova applicativa end-to-end eseguita. Segue il caso I&C sullo stesso bene, poi policy di convivenza/import incrementale prima di implementazione e collaudo.

Documento quadro 1.82; registro R01–R94. Rapporto 07 chiarito a 1.4, nuovo rapporto 11. Database, DDL v0.3, DPR e VerbalizzAI invariati.

---

## 63. Percorso I&C–AD_DM e aggiornamento condiviso delle scadenze

### 63.1 Richiesta e decisione R95

L'utente autorizza il seguito e precisa che la sincronizzazione ora comandata manualmente non sarà più tale avendo un database unico. R95 elimina comando e replica tecnica fra i moduli. L'attività I&C richiama il bene comune; completamento e aggiornamento delle date/scadenze condivise avvengono attraverso un unico servizio/transazione. Le due viste leggono lo stesso dato. F/T/S rimangono evidenza degli importati, non stati o pulsanti operativi del nuovo sistema.

Non si aggiunge una richiesta di conferma per una scelta già espressa. Le rettifiche autorizzate dei dati correnti non richiedono seconda compilazione su DM; la policy delle fonti e dei conflitti storici sarà esplicitata prima dell'import operativo, senza sovrascrittura per solo ordine delle scritture.

### 63.2 Riscontro del ponte e casi reali

Riletti endpoint DM, batch IEC, salvataggio attività, permessi, viste e calcoli pertinenti. Il vecchio ponte restituisce CND/supplementari/tarature e accetta date dell'attrezzatura o della valvola; l'hook valvola ricalcola tutte le associazioni correnti. Le attività sono i sottopunti della stessa tabella commerciale, con stati specifici; Altro non aggiorna scadenze tecniche. Il batch F/T/S e l'avviso di correggere manualmente DM dopo una rettifica di riga S sono conseguenze dei due database, superate da R95.

Due catene anonime verificate: CND riga 3649/punto 3648/prev 398→attrezzatura DM 5207, esecuzione 30/09/2026/prossima 29/09/2036, S, fattura IEC 259; date coincidenti in scheda e scadenzario DM. Taratura riga 3622/punto 3607/prev 394→attrezzatura 9430/valvola 2091, esecuzione 28/09/2026/prossima 27/09/2028, S, fattura IEC 257; date coincidenti su valvola e scadenza della coppia. Entrambi singoli, accettati ed effettuati. Nessun numero report ricostruito e nessuna prova di pagamento/invio dai soli riferimenti fattura. Il bene 5762 del precedente esempio GVR non ha attività IEC nel dump: non è stato costruito un falso collegamento.

### 63.3 Copertura e migrazione

Confermati 408 sottopunti CND, 46 supplementari, 622 tarature con riferimenti attrezzatura validi; valvole valide nelle tarature. Sono 1.076 agganci tecnici, distinti dai 1.150 Altro. Fra tecniche effettuate: 579 S (233 CND, 21 supplementari, 325 tarature), 40 T (26 CND, 14 tarature); nessuna duplicazione della chiave bene/valvola/tipo nel controllo delle T. Conteggi del backup, non stato corrente.

I 40 flag T non vengono eseguiti durante l'import: conservare e confrontare date effettive dei due archivi, senza riprodurre retroattivamente gli hook. L'endpoint legacy aggiorna direttamente le date ricevute; non si è trovato nel ramo letto il medesimo filtro cronologico dell'aggiornamento CND da verifica DM. La cancellazione legacy delle scadenze assenti riguarda una replica IEC: non viene trasferita come cancellazione indiscriminata del nucleo condiviso.

### 63.4 Schema, report e amministrazione

I casi sono rappresentabili in asset/relazioni, righe con parent, incarichi IEC con FK bene/valvola indipendenti, rapporti_tecnici con numero, documenti/esportazioni, scadenze condivise e relazioni finanziarie del v0.3. La vista I&C usa i tipi tecnici pertinenti, senza doppia scadenza equivalente per replicare il vecchio ponte. Nessun DDL modificato.

R85–R90 preservate: report esterno, numero richiesto, normalmente singola attrezzatura; normale report pronto→invio email→fattura→incasso. Nessun blocco assoluto PDF/riesame ispettivo I&C aggiunto. Collaboratore commerciale distinto dal tecnico; corpo addebitato una volta, percentuali/base e saldo legacy conservati. Un'attività I&C non entra nella rendicontazione INAIL per sola condivisione del bene.

### 63.5 Artefatto e seguito

Creato `12_Percorso_IEC_DM_report_scadenze_database_unico_2026-10-09.md` con regole, casi, mapping e limiti. Completo il secondo riscontro ordinario dopo GVR. Segue la policy di autorità dei dati e conflitti durante convivenza/import incrementale, considerando che anche DM può aggiornare date CND.

Documento quadro 1.83; registro R01–R95. Nessun collegamento agli endpoint, batch o migrazione avviati; nessun test applicativo end-to-end/Windows o analisi del software CND esterno eseguiti. DPR, VerbalizzAI, DDL v0.3 e database esistenti invariati.

---

## 64. Proposta di riallineamento incrementale e convivenza

### 64.1 Riscontro e artefatto

L'utente autorizza di proseguire. Riletti importatore della prova unificata e importatore del prototipo DPR: il primo elimina/ricrea la destinazione, il secondo rifiuta archivio con clienti esistenti. Sono due strumenti iniziali distinti e non costituiscono un importer incrementale. Nessuno è stato eseguito. Creato `13_Proposta_riallineamento_incrementale_e_convivenza_Garda_2026-10-09.md` con regole, esempi, autorità per fase, procedura e limiti.

### 64.2 Proposta tecnica concreta

Identità persistente per archivio/tabella/ID origine; nessun ricalcolo globale dei merge a ogni import. Confronto tra base applicata, dump nuovo e valore locale per campo/gruppo coerente. Invariati senza modifiche; aggiornamento sorgente solo dove la fonte ha autorità e il locale non è conflittuale; lavoro nativo conservato; differenze concorrenti da controllare. Assenza dal dump non cancella record; dump parziale non prova assenza effettiva. Documenti/accettati, importi storici, codici e numerazioni restano protetti secondo i requisiti acquisiti.

Piano in staging prima di scrittura, dipendenze risolte, quadrature, revisione verificata al commit e applicazione transazionale. Import non esegue gli hook operativi storici: nessuna generazione/riesame/invio/ponte I&C ripetuti. I 40 T del backup conservano la propria evidenza. Nessun secondo snapshot ricevuto/confrontato in questo passaggio.

Schema v0.3 dispone dei registri; serve rendere persistente la base effettivamente applicata per fonte/campi e distinguerla dall'ultimo record soltanto visto. Un hash grezzo non basta se alcuni campi restano in conflitto. Estensione tecnica da prevedere con i modelli/Alembic; nessun DDL modificato o nuovo motore dichiarato disponibile.

### 64.3 Autorità e COES-01

Durante il collaudo resta D13: Garda autorità gestionale, VerbalizzAI autorità dei propri oggetti/documenti. Dopo passaggio DPR, i nuovi flussi DPR appartengono al nuovo sistema; DM/I&C rimangono sui loro Garda fino ai rispettivi passaggi. R53 conserva la preferenza da validare per import delle pratiche aperte; nessun cutover ora.

**COES-01 aperta:** nella fase nuovo DPR in produzione e DM/I&C ancora Garda, scegliere dove aggiornare clienti/sedi comuni. Opzione nuovo riferimento: modifiche comuni nel nuovo sistema, dump legacy non prevalenti, copie eventualmente necessarie nei vecchi Garda da mantenere coerenti nella fase temporanea, senza promessa di una scrittura di ritorno. Opzione Garda riferimento: modifiche nel riferimento sorgente dichiarato, nuovo DPR riallineato dai dump; fonte fra archivi discordanti da esplicitare, senza scelta per sola completezza.

Le regole dei conflitti e la matrice nel rapporto sono proposte concrete, non nuove decisioni tacitamente approvate. La prosecuzione autorizza preparazione e analisi; la scelta dell'autorità operativa resta dell'utente. La policy resta proposta. Il successivo chiarimento acquisisce R96 sull’importazione operativa Excel, approfondita nella sezione 65; la scelta COES-01 resta aperta.

### 64.4 Seguito e stato

COES-01 resta il chiarimento aperto sulla convivenza. Il nuovo requisito R96 consente intanto di proseguire mapping e preparazione dell’import operativo Excel; dopo la risposta consolidare la relativa porzione della policy, quindi modelli/migrazioni e importer con modalità di confronto e prove su copie. I criteri di collaudo nel rapporto non sono test già eseguiti.

Documento quadro 1.84; nuovo rapporto 13. Nessuna modifica applicativa/DDL, import, aggiornamento dei database o collegamento a Garda/S3; nessun test applicativo end-to-end/Windows avviato.


---

## 65. Importazione massiva del parco attrezzature e delle scadenze

### 65.1 Richiesta acquisita R96

L’utente precisa che l’intero parco GVR, SC, SP, accessori PSV e date CND deve poter essere importato massivamente da XLS come già avveniva in Garda; ricostruzione dai verbali e inserimento individuale sono inadeguati. R96 entra nel perimetro operativo DM. Comprende schede/classificazioni, dati tecnici, ultime attività/prossime scadenze, tarature e collegamenti. Serve per nuovi clienti e aggiornamenti successivi, oltre alla migrazione iniziale.

Creato `14_Importazione_massiva_parco_attrezzature_e_scadenze_2026-10-09.md`; il rapporto 13 distingue ora import ordinario Excel e riallineamento dei dump. Nessun documento storico è obbligatorio per creare schede e scadenze; nessun verbale, report, incarico o fattura fittizio viene previsto per giustificare le date dichiarate.

### 65.2 Riscontro Garda

Riletti `cust/lavori_batch_cli.php` e motore `std/gi_imports_cli.php` adsrl. Tre batch dedicati XLSX: attrezzature, configurazione tecnica GVR, valvole. L’import attrezzature legge direttamente ultima/prossima funzionamento, integrità, interna, SC/SP, CND e supplementare, lasciando NULL i riferimenti alle ultime verifiche. Inserisce classificazioni risolte dai cataloghi e richiama ricalcolo/aggiornamenti di lavori non effettuati.

Accessori: matricola, DN e altri parametri, ultima/prossima taratura, associazione tramite sede e matricola informale dell’attrezzatura. Configurazione GVR: camere/elementi con PS/TS/volume/DN; modalità di integrazione o reset distinta. La procedura dedicata di inserimento segnala i record già migrati tramite vincoli unici, senza essere un aggiornamento generalizzato.

Il motore generico supporta XLS/XLSX/CSV/ODS e inserimento, aggiornamento, inserimento+aggiornamento, richiedendo colonne di match e aggiornando le sole colonne mappate tramite salvataggio ordinario. Può aggiornare più record corrispondenti: non si dichiara che il nuovo blocco delle ambiguità sia già una regola Garda. Non è stata provata la configurazione di ogni azione specifica né eseguita alcuna procedura PHP.

### 65.3 Modello comune e proposte

Asset, attributi/camere, accessori/associazioni e scadenze v0.3 consentono dati iniziali senza verbali: ultima/prossima, fonte e incarico facoltativo. Il nuovo elenco cliente non deve possedere ID Garda. Occorrono chiavi nel contesto cliente/sede, mappatura e provenienza file/foglio/riga; la riga non è identità persistente.

Classificazione acquisita/validata secondo R74, non inferita automaticamente; tubazioni senza interna R94; DN escluso dai volumi R80; riferimento report CND se disponibile R85 senza inventarne il documento. DM e I&C leggono il parco comune, senza doppia importazione o sincronizzazione manuale R95.

Proposte ancora da consolidare secondo R73: anteprima modifiche/errori; match multipli da risolvere; cella vuota in aggiornamento distinta da cancellazione esplicita; fonte/priorità delle date rispetto a calcoli e lavori reali; integrazione/sostituzione delle camere. Le regole Garda osservate e questi miglioramenti sono distinti nel rapporto. Non si approva tacitamente una deroga solo perché riportata nel documento.

### 65.4 Stato e prossimo passo

Requisito registrato, primo riscontro dei percorsi Excel completato. Segue mapping dettagliato delle colonne obbligatorie/applicabili e degli effetti degli hook, prima del modello Excel definitivo e del motore di caricamento. La scelta COES-01 sulle anagrafiche durante la convivenza resta aperta, separata dall’import operativo del parco.

Documento quadro 1.84; registro R01–R96 e rapporti 13–14. Nessun importer, modello XLSX, nuova migrazione o test applicativo dichiarato disponibile in questo passaggio. Codice, DDL e database invariati; nessun originale S3 richiesto.


---

## 66. Mapping Excel, effetti di aggiornamento e continuità dell’analisi

### 66.1 Richiesta e artefatti

L’utente autorizza il seguito e chiede di mantenere sempre aggiornati i documenti per proseguire da un’altra istanza. R12 è precisata, senza duplicarla con un nuovo requisito. Creati rapporto `15_Mapping_Excel_parco_e_regole_aggiornamento_Garda_2026-10-09.md` e scheda `00_Ripresa_progetto_gestionale_integrato.md`; rapporto 14 aggiornato a 1.1. Registro invariato R01–R96.

La scheda di ripresa indica documenti prioritari, materiali, limiti dell’implementazione, vincoli e quesiti correnti. Il documento quadro resta riferimento generale; la scheda è un indice di stato, non una seconda fonte autonoma di requisiti. Prima di una modifica da altra istanza occorre leggere le versioni attuali; se divergono, riconciliare senza sovrascrivere la nuova analisi.

### 66.2 Copertura e riscontri

Mappate tutte le intestazioni richieste nei tre batch dedicati: 47 attrezzature, 11 camere/configurazione GVR, 12 accessori. Colonne facoltative lette ma non richieste annotate a parte; chiavi e destinatari nel modello v0.3 sono proposte, non codice importer.

Identità Garda: sede + matricola informale attrezzatura; sede + matricola accessorio; coppia bene/accessorio unica. Procedura camere cerca invece solo matricola informale e può trovare più sedi; integrazione camere per chiave descrizione/numero fabbrica normalizzati, reset una volta per asset/batch. Questa differenza non autorizza un nuovo aggiornamento indistinto.

Distinti obblighi batch e maschere: numero fabbrica/costruttore/modello sono obbligatori nel batch, avvisi nella maschera. Regex dei componenti matricola nelle maschere non equivale a prova della loro applicazione nel batch diretto. Il gruppo SC/SP/GVR non è ordinariamente modificabile nel metadato. Le date periodiche legate a ultima verifica sono protette dal salvataggio ordinario.

### 66.3 Scadenze e lavori aperti

Il ricalcolo Garda riprende ultima/prossima dalla verifica effettuata più recente per data rilascio, componente per componente GVR e separatamente SC/SP. Senza verifica conserva le date della scheda. Non è un ricalcolo generalizzato della periodicità ministeriale. CND/supplementari usano le date della scheda e non richiedono report per esistere. Una sola data ultima non genera una voce futura di periodica senza prossima; tarature associate seguono una regola distinta, anche se la prossima è assente.

Gli hook propagano dati nei lavori assegnati/programmati/registrati, con percorsi diversi per componenti non compilabili, dati da precedente per record non salvati e configurazione tecnica. Le selezioni non coinvolgono effettuate. Le valvole aggiornano tutti i beni associati; sintesi tarature minima prossima e massima ultima. Legame con riga preventivo mantenuto/ricercato se compatibile; niente nuovo preventivo automatico. Applicabilità tubazioni R94 non si deduce dal solo loop generico del ricalcolo.

Query sulla copia adsrl in sola lettura: parco GVR 7.729, SC 1.359, SP 258, accessori 3.311. Prossima data senza FK ultima verifica: F 2.591, I 5.201, interna 146, SC/SP 303. Conteggi per componente sovrapposti, senza filtro attivo: non numero di importati Excel o arretrato. Almeno una data CND in 5.188 beni. Nessun importer o PHP eseguito.

### 66.4 Chiarimenti e prossimo passo

IMP-01: proposta cella vuota in aggiornamento = conserva valore; cancellazione esplicita distinta. La semantica finale del vecchio motore dipende dalla preparazione del record: non dichiararla risolta dal solo parser date. Prima domanda da porre all’utente.

IMP-02: proposta match nel contesto cliente/sede e risoluzione delle ambiguità, rispetto agli aggiornamenti multipli del vecchio motore/procedura camere. Richiede valutazione R73, non già approvata dal generico “procediamo”. COES-01 resta aperta nel rapporto 13 sulle anagrafiche nella fase intermedia. Continuare una domanda alla volta, con le preparazioni indipendenti.

Segue consolidamento della semantica aggiornata, colonne aggiuntive per chiavi/provenienza/report CND e modello Excel prima dell’importer. Non ripartire dal PHP né far dipendere il parco da documenti S3 o verbali storici. Documento quadro 1.85; nessuna modifica di DDL/applicazione/database, nuovo collaudo Windows o cutover.


---

## 67. Prassi dell’import massivo e riscontro delle celle vuote

### 67.1 Chiarimento dell’utente

Alla domanda IMP-01 l’utente dichiara di non sapere rispondere: l’importazione massiva era sempre gestita dalla software house, mentre gli operatori popolavano solo il file XLS. R96 integra questa prassi, senza un nuovo requisito duplicato. La risposta non sceglie “vuoto = conserva” né “vuoto = cancella”, e non delega implicitamente ogni deroga alle regole Garda.

Non reiterare la stessa domanda tecnica astratta. Ricostruire il comportamento dalle fonti e chiedere, quando utile, solo informazioni sul contenuto e uso degli elenchi oppure valutare un effetto concreto nella futura anteprima. Non trasformare l’utente in configuratore di policy del motore.

### 67.2 Riscontro aggiuntivo Garda

Riletti parsing per tipo e merge del motore generico: `std/gi_imports_cli.php:270–296,620–695`, `std/fw/gi_grid.php:4742–4776,4804–4970,5055–5135,3154–3250`, salvataggio ordinario `std/fw/gi_save.php`. Record importato costruito prima della lettura del record esistente; aggiornamento applica solo campi mappati effettivamente prodotti dal parser/default tramite array_replace.

Data vuota: parser non assegna il campo; senza valori configurati/default pertinenti l’update conserva la data letta dal database. Testo vuoto: parser può produrre stringa vuota se il record importato non aveva già un valore configurato; se modificabile e ammesso dal salvataggio può svuotare il testo esistente. Numeri vuoti non producono un numero; enum/booleani possono comunque ricevere un default. Non esiste una regola uniforme dimostrata per tutti i tipi/canali.

I batch attrezzature/accessori dedicati usano inserimento o segnalazione “già migrata”; non equivalgono al motore generico di aggiornamento. Le camere hanno invece integrazione/reset propri, già documentati. Questo riscontro statico non prova quale configurazione operativa usasse la software house sui file compilati dall’utente, né costituisce un test runtime PHP.

### 67.3 Stato, documenti e seguito

Rapporto 15 aggiornato a 1.1 con matrice di parsing/merge e limite della configurazione effettiva; rapporto 14 a 1.2 e scheda di ripresa 00 a 1.1. IMP-01 è un riscontro tecnico proseguito e una proposta futura da consolidare, non una domanda bloccante rimasta senza risposta. IMP-02 e COES-01 restano aperte nei rispettivi ambiti; niente approvazione per assenza di risposta.

Proseguire specifica dei modelli e gestione delle anomalie, con chiavi e colonne aggiuntive, mantenendo semplice la compilazione dell’XLS. Eventuale comportamento uniforme diverso da Garda resta proposta R73 e sarà valutato su un effetto concreto prima del codice pertinente. Documento quadro 1.86, registro R01–R96; nessuna nuova importazione, modifica applicativa/DDL o test Windows.


---

## 68. Priorità al gestionale integrato completo per il collaudo locale

### 68.1 Decisione R97

L’utente propone di preparare il modello di importazione alla fine e indica come obiettivo a breve una versione completa del gestionale integrato, con le funzioni attuali, da provare in locale. Accolto il rinvio del modello Excel; R96 resta nel perimetro necessario prima dell’uso DM sul nuovo parco. Non sospendere il lavoro sui moduli per questioni di celle vuote/match nel futuro Excel.

Test locale delle tre attività e attivazione di produzione sono distinti: rimane R05, DPR prima e DM/I&C dopo validazione nell’uso. I dump già disponibili servono al popolamento di copie di test, con dati/provenienze e anomalie espliciti. L’assenza S3 non blocca il codice, ma va dichiarata dove serve un allegato storico effettivo.

### 68.2 Codice base e matrice di completamento

Riletta candidatura 0.8.0: modelli clienti/sedi/impianti DPR, preventivi/verifiche legati a impianto, modulo finanza con società e ambito, migrazioni Alembic, registrazione router e modulo scadenze. Quest’ultimo ha solo il file di inizializzazione; non è il servizio tecnico unificato. Non esistono già i moduli operativi completi DM/I&C, l’export INAIL o i compensi I&C. Le dichiarazioni del solo schema v0.3 non sono codice di queste funzioni.

Creato `16_Perimetro_versione_integrata_per_collaudo_locale_2026-10-09.md`: famiglie di funzioni attuali/requisiti, stato nella base, risultati del collaudo, dipendenze di implementazione e limiti. È una prima matrice, non certificazione di parità di ogni azione/variante Garda. Regole non riproposte restano soggette a R73.

### 68.3 Ordine operativo

B1 nucleo comune e migrazioni con regressione DPR; B2 flussi DM/I&C e scadenze; B3 documenti/VerbalizzAI/INAIL; B4 raccordo economico, compensi e import storico quadrato; B5 parità delle ulteriori azioni, pacchetto Windows, backup/ripristino e modello/import Excel finale. B1 è il prossimo lavoro applicativo; non richiede un’ulteriore conferma generica del progetto già autorizzato. Nessun ramo completo o nuova versione dichiarati disponibili dal solo piano.

IMP-01/02 rinviati alla fase finale dell’import operativo. COES-01 da chiudere per la convivenza di produzione, senza bloccare le copie di collaudo. Non chiedere nuovamente stack/offline/rinvii già decisi. Aggiornare matrice e documenti a ogni incremento concreto con codice e prove realmente eseguiti; chiedere solo dubbi funzionali non risolti dal sorgente o dal registro.

### 68.4 Stato della consegna

Documento quadro 1.87, registro R01–R97. Rapporto 16 nuovo; scheda 00 1.2, rapporto 14 1.3 e rapporto 15 1.2 aggiornati per evitare che un’altra istanza riparta dal modello Excel. Codice/DDL/database invariati in questo passaggio; nessun nuovo test, pacchetto completo, deploy o cutover eseguito. La 0.8.0 resta una base DPR con i limiti già documentati.


## 69. Primo incremento applicativo del nucleo comune — candidatura 0.9.0

**Input:** dopo R97 l’utente autorizza a procedere. È stato implementato codice su copia della 0.8.0; non soltanto un nuovo piano. Rapporto `17_Primo_incremento_nucleo_comune_0.9.0_2026-10-09.md` contiene perimetro effettivo, riscontri, prove e istruzioni. R97 resta obiettivo della versione completa; questo incremento B1a non chiude B1–B5.

Sono disponibili nuove schede comuni SC/SP/GVR/PSV, nove tabelle del nucleo e cataloghi Garda (6 famiglie, 31 all.7, 72 ID specifiche, 162 associazioni: 271 righe con tutti i campi originari in JSON), classificazione manuale, camere con litri/DN e totale dei soli litri, valvole condivise molti-a-molti, date dichiarate per componente e numero report CND. Tubazioni prive di visita interna (R94). Modifiche con versione, permessi/CSRF e registro; dismissione conserva la scheda. Date/accessori comuni non richiedono una sincronizzazione manuale DM/I&C. Le attività I&C non sono ancora collegate.

La migrazione **0011** mantiene ID e collegamenti DPR e aggiunge `impianti.asset_id` unico/obbligatorio con FK. Durante la transizione gli impianti restano proprietari dei campi DPR; il bene comune ne è una proiezione di sola lettura aggiornata nello stesso commit attraverso le scritture ORM del programma, import DPR compreso. Le API comuni rifiutano la modifica diretta del DPR. La proiezione non è un secondo archivio e non richiede un comando manuale, ma è una duplicazione transitoria di campi da superare completando il raccordo. Il modello definitivo di proprietà del DPR non viene dichiarato già attuato. Il progetto v0.3 a 85 tabelle resta una proposta complessiva distinta dalla migrazione effettivamente applicata.

**Prove osservate:** 133 test passati (121 della base DPR e 12 nuovi del nucleo comune). Suite Linux/Python 3.12.14/SQLite; dodici nuove prove del nucleo, comprese migrazione 0010→0011 con offerta/verifiche, rollback atomico DPR, cataloghi completi, classificazione, camere, date, PSV condivise, permessi e backup/ripristino del nuovo parco. Schema/FK e migrazione da 0008 coperti dalla suite. Prova DOM+HTTP dell’interfaccia riuscita su scenario GVR/camere/CND/PSV e modifica scheda; non è una prova grafica Windows. I PDF ordinari restano gli stub della suite, le prove marcate `pdf_vero` seguono il comportamento esistente; nessuna nuova campagna DM di Word/PDF reali. Installazione/uso Windows, PostgreSQL e produzione non osservati.

**Limiti e prossimo lavoro:** completare gli attributi/maschere specifici e il caricamento quadrato delle tre sorgenti, poi raccordare preventivi e incarichi DM/I&C al bene e alle componenti. Lo scadenzario completo Garda, gli aggiornamenti da lavori effettuati, tariffe/composte, generatori e nomi N01–N14, INAIL, contabilità DM/I&C, compensi e import esiti Aruba restano nel perimetro. Nessuna regola è registrata eliminata o derogata per il fatto di non essere ancora sviluppata. Non è stato realizzato un importer incrementale dei dump né un modello Excel. IMP-01/02 rimangono rinviati alla fase finale e COES-01 alla convivenza di produzione. VerbalizzAI incorporato resta 0.3.32.3; nessuna modifica al sorgente autonomo/VPS e nessun originale S3 richiesto.

**Consegna:** `Gestionale_AD_v0.9.0_nucleo_comune_Windows_2026-10-09.zip`, istruzioni per archivio locale di collaudo separato. Prima di aggiornare un archivio precedente usare una copia completa; il programma crea il backup pre-migrazione. Per tornare alla 0.8 occorre il suo backup, non aprire un database 0011 con il programma vecchio. Quadro 1.88, rapporto 16 aggiornato a 1.1, rapporto 17 e scheda 00 aggiornati per la prosecuzione da altra istanza.


## 70. Blocco della duplicazione di preventivi DPR — R98

L’utente segnala che la 0.8.0 sembra consentire un secondo preventivo sulla stessa scadenza e chiede che il primo debba essere annullato prima di crearne un altro. Riprodotto realmente via HTTP: P_001 e P_002 per lo stesso impianto. Il vecchio servizio controllava duplicati soltanto nello stesso preventivo, mentre la UI e la scheda mostravano un avviso senza bloccare la scrittura.

Riletto ingecert `cust/_custom.php`, `gi_preventivi_righe_save_before`: blocco su altra riga dello stesso impianto/tipo accettata, con verifica ancora assegnata/programmata/registrata o assente. Riletti legame scadenza/riga e generatore batch. Il requisito utente anticipa il blocco già alle bozze: è una differenza funzionale autorizzata, non una pretesa identità con tutti i canali Garda.

Implementata regola comune backend/griglia: riga periodica non annullata in offerta non annullata/sostituita, senza verifica completata eseguita/riesaminata. Si considerano anche righe rifiutate finché non annullate. Annullamento per riga o dell’offerta libera la prestazione; rimozione/eliminazione della bozza resta nei limiti già esistenti. Verifica completata libera la prestazione successiva; RV negativo → registrata torna bloccante. Non si usa la data del preventivo per distinguere il ciclo. VS indipendenti e revisioni sostitutive restano ammesse, così come integrativi per altre prestazioni.

Controllati creazione, scadenze, aggiunta, cambio tipo, revisione, riattivazione/accettazione e generazione nuovi incarichi. Il backend risponde 409 con numero esistente; la maschera disabilita Procedi per VP già coperta e offre un collegamento al preventivo. Transazioni/lucchetto preservano rollback completo e unicità operativa in un processo locale. Nessuna nuova migrazione e nessuna bonifica automatica dei dati precedenti; due incarichi già creati richiedono valutazione, non cancellazione indiscriminata.

Consegne: 0.8.1 per il collaudo DPR precedente, 0.9.1 come base evolutiva. Suite complete 135/147 test passati Linux/Python 3.12.14/SQLite, più suite specifiche 14/14 rieseguite dopo l’estensione del caso legacy. DOM con JavaScript reale/API simulate verifica blocco VP, link e scelta VS; backend HTTP provato separatamente. Windows e server multiprocesso non osservati. Rapporto 18 e risultati nei pacchetti. VerbalizzAI autonomo/VPS invariati; incorporato 0.3.32.3.

## 71. Maschere AD_DM e critica alla candidatura 0.9

L’utente propone e invia menu/maschere Garda, sottolineando che il frontend aiuta a capire l’uso dell’applicazione. Tutte le 15 immagini sono state recuperate e lette. Mostrano menu Clienti e Attrezzature, scheda GVR e scheda SC/SP per un esempio SC: Identificazione, Class. INAIL, Caratt. GVR o SC/SP, Verifiche GVR o SC/SP, Altro. Configurazione GVR non espansa e linguetta Altro non aperta; non assumere visibili tutti i menu o tutte le relazioni.

L’utente giudica poco sensata la 0.9 dal punto di vista del frontend e ribadisce che struttura/logiche adsrl Garda sono corrette e riferimento principale. Critica recepita: la UI generica iniziale non rende riconoscibile il lavoro DM e il backend è davvero incompleto. Le tabelle/camere/date comuni e i test non provano schede, tariffazione, generatori o INAIL completi.

Rapporto 19 confronta immagini, `cust/meta/attrezzature.js`, salvataggio/ricalcolo `cust/_custom.php`, tracciato batch e codice beni 0.9. Sono censiti campi identità/cliente/sede, esenzione a tre valori (No/Sì/ISO17020), matricola strutturata e vincoli, costruttore/CF, reparto/riferimento/CE, all.7/famiglia/ID/codici derivati, tipo descrittivo verbale, GVR/PED/insieme/pacco/configurazione, portata/panieri, verifiche e date separate per componente. Vincoli di matricola parziali nel nucleo sono lacune da colmare, non deroghe approvate. JSON tecnico generico non equivale a implementazione dei singoli attributi.

Punto funzionale confermato nel sorgente: ultima verifica collegata e coppia di date non sono lo stesso dato. Le date vengono protette e aggiornate dal lavoro effettuato pertinente; iniziali senza storico sono date di scheda. CND/supplementari e report restano distinti. Non introdurre un ricalcolo generico, né inventare verbali per date importate. R80, R85, R94 e regole generatori/nomenclatura restano vincolanti.

**Prossimo lavoro:** completare backend e maschere GVR/SC/SP secondo i gruppi/campi/azioni Garda, con riferimenti navigabili e confronto dei risultati, poi raccordare offerte/incarichi ai beni/componenti. La 0.9.1 consegnata qui contiene la correzione DPR, non una nuova UI DM; non chiamarla completa o presentarla come soluzione alla critica. Nessuna rinuncia a funzionalità Garda acquisita. R97/Excel alla fine e sequenza di produzione R05 restano invariati.

## 72. Organizzazione Windows — raccomandazione

Alla domanda su tre progetti/cartelle è stata consigliata la distinzione fra VerbalizzAI autonomo e Gestionale AD integrato come evoluzione di AD_dpr, conservando quest’ultimo nelle versioni storiche senza sviluppo parallelo. Proposta Stabile/Beta per programma, archivi dati separati esplicitamente configurati, archivio versioni e backup datati. Rapporto 20 contiene percorsi d’esempio e chiarisce launcher collaudo, WatchGuard, migrazioni e configurazione dati. Il nuovo gestionale resta Beta. È una raccomandazione organizzativa, non una scelta confermata dall’utente né una modifica eseguita sul suo PC.


## 73. Preventivo cliente/sede e prossimo rilascio con DM — R99

L’utente ricostruisce la differenza fra AD_DM, con offerta legata alla sede, e AD_DPR modificato per offrire al cliente più impianti di sedi diverse (esempio Comune/edifici). Precisa che la fattura è al cliente, non alla sede, e chiede che il prossimo codice sia già integrato con DM.

**Verifica:** adsrl contiene già cliente e sede nella testata, entrambi obbligatori; sede dipendente dal cliente, non modificabile ordinariamente dopo creazione. La riga legge la sede dal preventivo e filtra le attrezzature su quella sede. ingecert contiene cliente, nessun campo sede di testata; la riga filtra impianti sul cliente. Catena anagrafica cliente→sedi→attrezzature DM o impianti DPR confermata. Fonte metadati e DDL dei dump del 7 ottobre, non deduzione dalle sole immagini; non ricostruisce cronologicamente le versioni precedenti.

Query in sola lettura sugli staging: adsrl 1.849 offerte/9.878 righe, ingecert 1.009/1.866; 168 preventivi DPR con impianti di più sedi. In adsrl 4 offerte con attrezzature di più sedi effettive, 32 righe con sede attuale del bene diversa dalla sede di testata, 1 testata con cliente diverso da quello della sede; 5 righe DPR con impianto di un diverso cliente corrente. Cause non accertate; non etichettare automaticamente come errore o sanare spostando i beni. I&C ha cliente/sede di testata; nel riscontro tutte le 349 testate hanno sede e nessun disallineamento cliente/sede della testata.

**Proposta:** mantenere l’anagrafica corretta e uniformare la struttura del preventivo: cliente intestatario obbligatorio, sede di contesto dove pertinente, beni/sedi delle prestazioni sulle righe, fotografie/provenienze. Il disegno v0.3 già prevede questa combinazione; non serve un nuovo schema da zero. DPR multisede preservato; normale DM per sede preservato nel servizio/UI. Consentire nuove offerte DM multisede è una scelta funzionale distinta e non acquisita: R73, senza applicazione tacita tramite un campo facoltativo. La sede DM determina anche contatti/email dell’offerta (`gi_rpt_preventivi_close_html_after`), dunque non va eliminata o sostituita automaticamente dall’email cliente.

Importazione senza impedimento strutturale: conservare una testata e tutte le righe per ogni documento originale, serie/numero/importi/stati, sede di contesto DM/I&C e provenienza; nessuna sede unica inventata sul DPR, nessuna suddivisione o aggregazione automatica degli storici. I collegamenti anagrafici correnti non provano sempre la sede storica della prestazione; usare dati copiati/originali disponibili e registrare le discrepanze. Verificare FK, conteggi, importi e agganci lavori/fatture/allegati, senza ricalcolare accettati/emessi. Mancanza S3 non impedisce il mapping ma non consente di dichiarare recuperati i contenuti.

**R99 acquisita:** prossimo rilascio funzionale con DPR e DM realmente integrati, secondo le schede/regole Garda e perimetro INAIL; non un ulteriore pacchetto di solo nucleo generico. Le correzioni 0.8.1/0.9.1 già realizzate restano manutenzione/base e non quel rilascio. I&C e la sequenza di produzione rimangono nel progetto; non nasce un terzo gestionale. Nessun nuovo DDL, importer o flusso DM applicato per effetto di questa discussione. Rapporto 21 conserva riscontri e proposta. Quadro 1.90, registro R01–R99, ripresa 1.5 e perimetro 1.3.


### 73.1 Dubbio successivo su indirizzi e conservazione dei flussi attuali

L’utente considera cliente intestatario, sede di riferimento e beni nelle righe, osserva che gli indirizzi appartengono alle sedi e teme incoerenza con l’attuale sistema. Chiede il rischio di mantenere la differenza DM/DPR; nessuna nuova scelta definitiva acquisita.

Raccomandato preservare gli usi attuali nel nucleo comune: DM per sede e DPR per cliente multisede. È una diversità di filtro commerciale, non un ostacolo al database unico. Gli indirizzi correnti sono derivati dalla sede del bene, quelli degli emessi fotografati e immutabili; non farli ridigitare o introdurre una seconda anagrafica indirizzi. Resta il limite noto DM di offerte distinte per sedi diverse, senza un nuovo rischio strutturale. La futura estensione multisede DM resta da valutare espressamente, ma il nucleo comune già predisposto evita una riscrittura anagrafica.

Importazione conservativa con sede di contesto DM preservata, righe/bene/provenienza, nessuna divisione/fusione degli originali; discrepanze da segnalare. L’indirizzo storico non disponibile non viene inventato dall’attuale anagrafica. Rapporto 21 sezione 7 dettaglia rischi e raccomandazione; nessuna modifica DDL/servizi o consenso tacito in questo chiarimento.

### 73.2 Prosecuzione autorizzata

L’utente risponde «ok procediamo» alla raccomandazione di mantenere gli usi attuali nel nucleo comune. Si prosegue quindi con DM per sede e DPR per cliente multisede, senza estendere il DM al multisede ordinario. La ristrutturazione tecnica resta quella necessaria al raccordo, con R73 e R99 conservate. Il riscontro preliminare del codice conferma le lacune delle schede native comuni: i campi e controlli Garda vanno completati prima del flusso commerciale DM. Non è stata prodotta una nuova versione applicativa in questo passaggio.

## 74. Lavoro parallelo con altre istanze e LLM

L’utente intende aprire istanze parallele anche su altri LLM e chiede best practices per evitare incoerenze. Preparato **22_Protocollo_lavoro_parallelo_Gestionale_AD_2026-10-09.md** (1.0) con baseline 0.9.1/SHA256, quadro 1.91, ripresa 1.6 e incarichi pronti. Il kit di contesto include documenti 00/04/16/19/21/22, senza duplicare sorgenti, dump o immagini. Questi materiali vanno forniti effettivamente alle istanze che ne hanno bisogno: citare il nome di un file non dà accesso al suo contenuto.

**Raccomandazione organizzativa, non configurazione eseguita:** partire con un integratore INT-01 per schema/servizi comuni/migrazioni/rilascio, DM-01 per analisi Garda e QA-01 per verifica indipendente. INAIL-01 può analizzare subito tracciati/regole e implementare dopo un contratto dati. Git locale consigliato, rami e cartelle/database di prova distinti, un incarico alla volta in integrazione. Quadro e ripresa aggiornati da un solo responsabile; le altre istanze consegnano evidenze e proposte. Non introduce un nuovo vincolo di approvazione per normali scelte tecniche già autorizzate.

Il report stabilisce consegne con base, file, evidenze Garda, decisioni, patch, prove effettive, limiti e dipendenze. La concordanza fra LLM non prova una regola; mancanza di conflitti testuali non prova compatibilità funzionale. Nessun agente/istanza esterna avviato, nessun repository creato sul PC dell’utente, nessun nuovo test applicativo eseguito durante il coordinamento. Base ancora 0.9.1/migrazione 0011; R01–R99 invariati. L’obiettivo successivo resta il raccordo operativo DPR–DM, non un altro nucleo generico.


## 75. Prosecuzione senza istanze parallele — incremento applicativo DPR–DM

L’utente conferma che nessuna istanza parallela è stata avviata e chiede di continuare qui. Nessun agente o altro LLM è stato lanciato. Realizzato codice **0.10.0-dev**, a partire dalla 0.9.1 conservata, con nuovo checkpoint recuperabile; **non è ancora il rilascio completo R99**.

Implementate schede tecniche a linguette, matricola 4/1/5/2, esenzione F/T/I, classificazione richiesta per le nuove schede, parametri GVR/SC-SP/camere e famiglia GVR derivata. Offerte DM sulle stesse tabelle/servizi DPR: cliente+sede obbligatori, sole attrezzature della sede, serie distinta, righe con bene e fotografia, tariffe Garda GVR/SC-SP, combinazioni, sconti e licenza opzionale. Il DPR conserva cliente multisede. R73/R99 e divieto di multisede ordinario DM restano.

Migrazione applicativa **0012**: estensione testata/righe comuni, `dm_tariffe` (314 righe con origine) e `dm_incarichi`. Questi ultimi vengono creati idempotentemente dopo accettazione scritta e RC conforme; **solo stato da assegnare**. Non segnare implementati affidamento/esecuzione/verbali DM, scadenze da lavori, fatturazione DM collegata o INAIL. Amministrazione DPR precedente resta disponibile. Nessuna importazione completa di adsrl/iec o motore incrementale realizzato in questo passaggio.

Modello Word DM originale dal backup con elenchi, clausola licenza e stesso servizio di anteprima/approvazione/ritocco/invio. Nome file DM e destinatario sede riscontrati nel PHP. Fotografie emessi preservate. L’arrotondamento DM è verificato anche nei wrapper `gi_bcdiv`/`gi_bcmul`: 311,17 € scontati del 12,5% diventano 270,72 € secondo Garda. Non cambiarlo tacitamente; DPR conserva il proprio comportamento. Il test Word ha fatto correggere la rimozione della tabella prezzo licenza quando la clausola è esclusa.

**Prove finali:** 168 test passati nella suite completa finale (147 della base e 21 DM), Linux/Python 3.12.14/SQLite; 1 avviso della suite. Ruff E9/F sui file applicativi interessati e controllo sintattico JavaScript passati. Alembic non rileva differenze fra schema 0012 e modelli dichiarati.. Migrazione da 0011 con beni/camere e offerta DPR inviata verifica i vecchi campi/ID/riferimenti e FK; conserva eventi e registra l’aggiornamento, con backup pre-migrazione. DOM+HTTP effettivo prova scheda GVR, dati tecnici, camere L/DN, CND/report/PSV, nuova offerta DM e riga multipla tariffata. Word originale effettivamente compilato, inclusione/esclusione clausola licenza provata. PDF ordinari simulati: nessuna campagna PDF DM reale; Windows/produzione/PostgreSQL non osservati.

Approfondimento **23_Incremento_sviluppo_DPR_DM_0.10.0-dev_2026-10-09.md**, stato e prove inclusi nel checkpoint. Rapporti 16/19/21 e scheda 00 aggiornati. Nessuna rinuncia funzionale approvata: mancano ancora il completamento delle maschere/azioni, EX/tariffario/scadenze, flusso tecnico DM/generatori/nomi N01–N14, contabilità collegata e INAIL, poi I&C. Excel resta alla fine; S3 non richiesto, VerbalizzAI autonomo/VPS invariati, incorporato 0.3.32.3.

**Ripresa:** usare il checkpoint 0.10.0-dev e le versioni correnti 00/04/16/19/21/23. Il kit parallelo della sezione 74 è storico sulla baseline 0.9.1 e non include questo codice; aggiornarne il contesto se in futuro si assegnano istanze. Non aprire più gestionali autonomi o ricreare la migrazione 0012. Prossimo blocco applicativo: verifiche DM/aggiornamenti per componente, generatore e documenti, fatturazione collegata e INAIL, riscontrando le regole Garda prima del codice.


Identificazione del checkpoint salvato: `Gestionale_AD_0.10.0-dev_checkpoint_DPR_DM_2026-10-09.zip`, SHA256 `b1a84cf70387e6491db3b9299b17497a500644dfc03dbe283d90b857befb9b67`, 277 file, 1,914,979 byte. Hash del pacchetto esterno, da verificare prima di integrare contributi futuri.

## 76. Flusso tecnico DM e tre ambienti nella stessa applicazione

La 0.10 creava incarichi DM soltanto da assegnare. Ora sono disponibili assegnazione singola/multipla, indipendenza, programmazione facoltativa, scheda tecnica, registrazione, sospensione/ripresa e annullamento. Numerazione GVR separata da SC-SP condivisa, contributi A1/A2 e data riepilogativa per componenti del lavoro riscontrati negli hook adsrl.

Camere, PS/TS/fluidi e tipo verbale aggiornano la scheda comune e le bozze aperte nella stessa transazione; Pes/Tes restano dati del lavoro. Preventivi emessi conservano la fotografia. Salva e registra è atomico: dati non validi non lasciano modifiche del master o numeri consumati. Versioni obbligatorie controllano la concorrenza.

Tipo attrezzatura verbale manuale, distinto da all.7; 38 definizioni tecniche dai metadati Garda con condizioni esplicite. Schema 0013, nessuna riscrittura dei preventivi. Migrazione 0012 popolata verificata; downgrade bloccato se perderebbe lavoro tecnico.

## Ambienti operativi e indirizzi di accesso

Un backend e un database applicativo comuni, tre ambienti di navigazione: **AD_DPR**, **AD_DM** (GVR/SC/SP) e **I&C S.r.l.** Il selettore Attività mantiene le anagrafiche comuni, filtra il menu e non concede permessi. Le API continuano a controllare ruoli e titolarità dei lavori. La preferenza di navigazione non determina emittente, sezionale o contabilità.

Ingressi locali già disponibili: `/ad-dpr`, `/ad-dm`, `/iec`; selezionano direttamente l’ambiente, anche arrivando da un collegamento. Le pagine comuni conservano la scelta; le pagine operative DPR/DM la rendono coerente con il modulo aperto. I&C mostra una pagina esplicita di funzioni ancora da realizzare; non espone la fatturazione DPR come se fosse I&C. Nell’ambiente DM non viene presentata la fatturazione DPR come fatturazione DM.

**Chiarimento dell’utente:** nella versione definitiva vuole indirizzi distinti per i tre ambienti, o almeno un accesso AD_DPR/AD_DM e uno separato I&C. Questo è acquisito. Due o tre URL/nomi host sono configurazioni di ingresso della stessa applicazione, non tre gestionali da mantenere. La configurazione dei domini, del proxy e delle autorizzazioni per ambito in produzione è ancora da realizzare; gli ingressi locali non sono una prova di separazione dei domini o di isolamento dei dati. Il selettore è utile al collaudo e agli utenti autorizzati su più attività.

Sviluppo: una sola installazione/avvio, un archivio di prova, passaggio fra le attività senza riavviare. Collaudo e produzione usano archivi distinti. AD_DM e AD_DPR appartengono ad AD S.r.l.; I&C S.r.l. mantiene emittente/contabilità distinti. Nessuna fusione di preventivi o fatture DM/DPR introdotta da questa navigazione.

## Evidenze, limiti e prossimo passo

**Prove finali:** 189 test passati nella suite completa (168 della base, 16 nuovi tecnici DM e 5 ambienti), Linux/Python 3.12.14/SQLite, 1 avviso di deprecazione del test client. Controllati schema/migrazioni rispetto ai modelli, migrazione 0012 popolata, numerazione concorrente, backup/ripristino, autorizzazioni e atomicità delle modifiche. Due prove DOM+HTTP passate con JavaScript/backend effettivi: schede/date/PSV/preventivi DM e assegnazione/programmazione/scheda tecnica/registrazione. Controlli Ruff E9/F sui file modificati e sintassi dei cinque JavaScript interessati passati. La diagnostica più ampia conserva segnalazioni preesistenti di base/terzi; VerbalizzAI incorporato non modificato. Conversione PDF delle offerte simulata nei server di prova, Windows/produzione/PostgreSQL e LibreOffice DM reale non osservati.

DOM+HTTP effettivo per schede/preventivi e percorso tecnico fino a registrazione; PDF offerte simulati nei server di prova. Nessuna prova Windows, produzione, PostgreSQL o emissione LibreOffice DM reale. VerbalizzAI incorporato ancora 0.3.32.3, autonomo/VPS invariati; S3 non richiesto.

Riproposizione selettiva dai precedenti, import completo dello storico, tecnico affiliato/CND della verifica, aggiornamento delle scadenze da lavori effettuati, generatori Word/PDF e nomi N01–N14, riesame DM, invio, fatturazione collegata e INAIL restano aperti. I&C/EX/import incrementale da completare; modello operativo Excel alla fine. L’assenza è lavoro pendente, non rinuncia approvata. Non trasferire automaticamente al DM il riesame negativo DPR.

Per la ripresa: quadro 1.93, scheda 00 1.8, rapporti 16 1.5 e 19 1.3; stato/manuale e prove incluse nel codice. Nessuna istanza parallela avviata. Prossimo blocco: precedenti e generatore/documenti DM con parità Garda, poi completamento tecnico/finanza/INAIL. Non ricreare 0012/0013 o trattare gli ambienti come archivi indipendenti.


## 77. Trasferimento fedele e obiettivo del prodotto completo — 10 ottobre 2026

Federico ribadisce che Garda funziona bene e che il progetto nasce dal costo delle implementazioni del fornitore. Richiede fedeltà delle logiche/flussi e nessuna omissione, salvo cambiamenti concordati o necessari all’unificazione; vuole un unico prodotto completo in tempi brevi, senza dover assumere il ruolo di sviluppatore. Questi indirizzi sono registrati come R101–R106 e prevalgono sulle precedenti proposte incompatibili.

Percorso concordato come direzione del lavoro, con scelte tecniche gestite dall’assistente: conservare la base integrata dove compatibile, incorporare VerbalizzAI aggiornato, trasferire tutte le funzioni DM/I&C e controllare DPR, riconciliare una copia dei dati e collaudare la candidata completa. La sincronizzazione adsrl↔iec viene sostituita dal dato condiviso, mantenendo gli effetti operativi pertinenti. Non si trasformano le anomalie/proposte dei cataloghi in correzioni automaticamente approvate. Riduzione dei click, percorso documentale definitivo e rifacimento dashboard DM sono gli interventi esplicitamente indicati.

Realizzato un checkpoint interno **0.11.1-dev**, con VerbalizzAI **1.0.1 rc2** incorporato. Lo strumento di aggiornamento ora tratta gli import multipli e valida sorgenti/modelli prima di sostituire la versione incorporata; recupera la precedente se il cambio di cartella fallisce. I sorgenti del generatore differiscono dall’allegato soltanto per gli import resi relativi; modelli Word rev.02 identici. Nessuna modifica dello schema oltre alla 0013, nessun nuovo ciclo DM/I&C o dashboard realizzato.

Il rapporto **25** descrive il metodo e il traguardo; il rapporto **26** censisce 151 regole e i metadati dichiarati. Questo inventario non è un attestato di parità né un audit esaustivo di tutte le funzioni PHP/framework. Ogni assenza resta lavoro aperto.

Controlli e limiti effettivi nello stato 0.11.1-dev e nei risultati inclusi nel checkpoint. R99/R106 non sono chiuse. Il checkpoint si conserva per proseguire lo sviluppo; non si chiede di installarlo come se fosse il gestionale completo. Windows, VPS, produzione e migrazione completa restano da collaudare.

## 78. Documenti e chiusura AD_dm — checkpoint interno 0.12.0-dev

Prosecuzione sulla stessa base Python, senza istanze parallele. VerbalizzAI 1.0.1 rc2 conservato; migrazione 0014. Il ciclo DM comprende ora precedenti nativi selettivi, Word/PDF GVR/SC/SP dai due modelli Garda originali, etichette, firma comune, ritocco controllato, consultazione e conferma del PDF, chiusura, riesame e invio del definitivo conservato. Modelli controllati e fotografie distinguono versioni e dati del documento. Scheda tecnica PDF caricata obbligatoria per V1 nel percorso ordinario.

Riesame DM conforme al comportamento adsrl osservato: qualsiasi stato, N senza riapertura, chiusura senza azzeramento. Le scadenze riprendono l’ultima effettuata pertinente per componente; una retrodatata non sostituisce una più recente. Annullamento riprende precedente o date iniziali. CND con confronto PHP `>=`, avviso se più vecchio e conservazione del riferimento al report in assenza di nuovo numero.

Prove e fonti nel rapporto 27, stato 0.12 e risultati del collaudo; matrice 26 aggiornata soltanto per i percorsi riscontrati. Suite generale: 213 passati; ampliamento CND: 4 passati, di cui 2 aggiuntivi rispetto alla suite, per 215 casi distinti. DOM+HTTP fino a chiusura/riesame, tre conversioni DM LibreOffice reali e ispezione delle quattro pagine dei campioni. Controlli E9/F e sintassi JavaScript passati; invio SMTP simulato. Nessuna prova Windows o operazione in produzione.

Non sono chiuse tutte le regole Garda. Eccezione multipla ai PDF, correzioni dopo chiusura, tutte le autorizzazioni/azioni e date protette restano aperte. AD-31 segnala il blocco di indipendenza DPR ereditato dalla base DM 0.11: non è acquisito come deroga approvata e va allineato prima della candidata completa. Storico Garda non ancora importato nei precedenti.

Fatturazione/incassi DM collegati, EX, INAIL, I&C, dashboard e migrazione completa/incrementale restano nel progetto. Proseguire con finanza DM e pacchetti INAIL, poi I&C e riconciliazione. R01–R106 invariati, R99/R106 aperte; nessun checkpoint presentato come prodotto completo o nuova installazione operativa richiesta.
