# Ripresa autonoma NEXUS 0.17.0 — 13 ottobre 2026

## Punto di ripartenza

Usare il **pacchetto NEXUS 0.17.0 di questa consegna**, non ricominciare da 0.12 o ricongiungere nuovamente i vecchi fork. Questa versione deriva direttamente dal ZIP 0.16 ricevuto il 13/10, SHA-256 `9f715435fc3f27dcf37e5d11b534ba1b277b2046c81a0ff5595009d876e69639`. Versione nel codice `gestionale/__init__.py`: **0.17.0**. Schema Alembic **0027**, catena unica 0001–0027; nessuna migrazione DDL nuova. Niente commit Git attribuito a questa consegna: identità del codice tramite ZIP, versione e manifest SHA-256.

Leggere, in quest'ordine: README e migrazione; documento 44 (delta e risultati); questo documento; documento 46 (prossimo lavoro); documento 47 e fonti ricevute per le parole originali. I vecchi documenti di ripresa descrivono la rispettiva data e sono superati sullo stato del codice dal presente documento. I quattro documenti ricevuti sono conservati sotto `documentazione/fonti_ricevute_2026-10-13/`: 18, 36, 37, 38. Il documento quadro storico incluso nella base non sostituisce la ripresa ricevuta 18 versione 1.17.

## Lavoro concluso qui

Correzioni C17–C26 e nuova regola C28 implementate: filtri e date; gruppi Scadenze per urgenza con colonna cliente/sede davanti; Attrezzature per prossima data; raggruppamenti più leggibili; gestione oggetti distinta DPR/DM; barre griglia; master dei requisiti RC; righe obbligatoriamente nel singolo preventivo, anche sul server/Excel; selector DM corretto e spiegazione utenti disattivi; salvataggio coordinato della scheda Utente; diagnostica/validazione Word-PDF; divieto di riesame del proprio verbale.

Le funzioni di calcolo/riesame storico/affidamento/fatturazione esistenti sono preservate salvo le correzioni descritte. Nessun account reale riattivato, nessun database operativo manipolato, nessun dato delle schermate utilizzato nei nuovi test. VerbalizzAI **1.0.1 rc2** e i suoi sorgenti incorporati sono invariati byte per byte, così come i modelli Word ricevuti.

## Decisioni nuove approvate — testi esatti

Federico ha approvato le proposte formulate nell'analisi C17–C26:

> per gruppi scadenze ok

Riferimento approvato: gruppi dalla prima scadenza più urgente, date crescenti dentro ciascun gruppo.

> per gestione parco come hai indicato tu. proceci

Riferimento approvato: gestione impianti AD_DPR ai ruoli DPR; gestione attrezzature AD_DM, comprese GVR/SC/SP/PSV, ai ruoli DM; ruoli comuni secondo permessi assegnati. Gestione = creare/modificare/dismettere dati anagrafici; affidare/eseguire le verifiche resta un permesso distinto.

> procedi pure

Autorizzata l'implementazione e il collaudo della versione successiva.

Nuova regola C28:

> aggiungo un elemnento: il verificatore (RT Federico nell'esempio) NON deve poter riesaminare il proprio vverbale!

Implementata per DPR e DM senza eccezione RT/amministratore. In DM anche le operazioni in blocco sono atomiche. Non retro-correggere silenziosamente i riesami già registrati: l'archivio operativo non è stato fornito per questa verifica.

Prossimo lavoro C27, approvazione esatta:

> ok concordo procediamo prima con 0.17 con correzioni approvate e dopo passaggio a postgreSQL. nmi raccomando documenta tutto a latere così che io possa proseguire con un'altra istanza di LLM

**Prima 0.17, poi PostgreSQL.** Il passaggio PostgreSQL e l'importazione completa/coerente MariaDB Garda sono autorizzati e prioritari dopo la presente consegna, **non implementati né collaudati**. Il testo della richiesta originaria è nelle note 36/47; il piano conseguente è nel documento 46.

Non assegnare qui numeri R inventati. Registro canonico ricevuto fino a **R143**, prossimo numero da assegnare nel progetto canonico R144. Per C17–C26 i testi originali sono nel documento 36, senza ricostruzioni o finti virgolettati. I documenti ricevuti 18/37 indicano storicamente sviluppo affidato a Claude: Federico ha autorizzato esplicitamente questa implementazione qui; non usare quella disposizione organizzativa per bloccare il lavoro già autorizzato.

## Validazione e limiti concreti

- Base 0.16 rieseguita: 317 pass, 1 warning.
- Suite completa 0.17: **346 pass**, 5 copie del warning TestClient, `pytest -q -n 4 --dist loadfile`.
- Ultima aggiunta al registro dell'export: **14 test mirati passati** dopo la suite.
- **11 percorsi browser passati**, zero errori JavaScript / risposte 500 nei percorsi provati. Runner riproducibile `strumenti/collaudo_browser_017.py`.
- Prova aggiornamento da codice 0.16 a 0.17: **63 tabelle preservate**, catalogo permessi escluso dal confronto perché aggiorna etichette, schema 0027; vecchie concessioni preservate e nuovi vincoli di attività efficaci.
- Controlli critici Python, compilazione e sintassi di tutti i 37 JS passati. Lint generale di stile non completato.
- Linux Python 3.12.3, Chromium 134, Playwright 1.51.0; conversioni reali su LibreOfficeDev 26.8 alpha. Nessuna prova sulla macchina Windows dell'utente; ripetere i percorsi essenziali nella sua installazione LibreOffice.
- Il file Word reale di circa 1,2 MB non è stato ricevuto. È passato un Word sintetico di dimensione analoga con conversione reale, ma ciò non dimostra la causa o la soluzione del caso reale. Per chiuderlo serve il file originale o una riproduzione e il log della conversione. Errori ora distinti per allegato/generato e formato/struttura/dimensione.

Non sommare i pass dei test mirati a quelli della suite come se fossero casi nuovi. I log falliti delle iterazioni precedenti sono conservati per trasparenza; l'esito di riferimento è `report_collaudo/0.17.0/017-suite-release.txt` e i controlli finali citati nel documento 44.

## Riprodurre il collaudo

Ambiente isolato, dipendenze `requirements-sviluppo.txt`, quindi:

```bash
python -m pytest -q -n 4 --dist loadfile
python -m pytest -q tests/test_griglie.py tests/test_collaudo_017.py::test_contesto_righe_non_eliminabile_filtri_excel_e_menu
```

Per browser installare `requirements-collaudo-browser.txt`, poi `python -m playwright install chromium` e `python strumenti/collaudo_browser_017.py`. Quest'ultimo crea un archivio temporaneo sintetico, avvia un server su loopback, effettua le prove e rimuove i dati alla fine; non usare un archivio operativo. La prova di aggiornamento si ripete con `python strumenti/verifica_aggiornamento_017.py --base-dir CARTELLA_CODICE_0.16.0`; usa entrambe le versioni in processi separati su dati temporanei sintetici; non è un'autorizzazione a fare prove su produzione.

## File tecnici da cui continuare

| Area | Riferimenti |
|---|---|
| Permessi | `core/permessi.py` (`GESTIONE_PER_ATTIVITA`), `moduli/utenti/accesso.py`, `servizio.py`, `api.py`; `static/js/schede.js`, `ruoli.js` |
| Griglie | `core/griglia.py`: filtri strutturati, Richiesta.contesto/raggruppa, minimi per gruppo su risultato filtrato; `moduli/griglie/api.py`: controllo attività e audit export; `static/js/griglia.js` |
| Scadenze/Attrezzature | `moduli/anagrafica/griglie.py`, `beni/griglie.py`; colonne offerte aggiunte in `preventivi/griglie.py` |
| Preventivi e righe | `preventivi/griglie.py`, `static/js/preventivi.js`, `righe_preventivi.js`, menu `web/pagine.py` |
| Scheda Utente | `utenti/api.py` PUT con dati_tecnici nella stessa transazione; `static/js/utenti.js` coda/condivisione versione; `schede.js` profilo/firma; `dm/api.py` controllo versione della firma |
| Word/PDF | `verifiche/servizio.py::carica_verbale`, `core/pdf.py`, `verifiche/api.py`; controllo identità prima della conversione |
| Divieto riesame proprio | `verifiche/servizio.py::riesame`, `dm/documenti.py::riesame`; interfacce `verifiche.js`, `incarichi_dm.js` |
| Test | `tests/test_collaudo_017.py`; test precedenti adattati a contesto e RT distinto, helper esplicito `conftest.revisore`; conversioni rapide con PDF sintetici validi |

## Prossima attività concreta

Eseguire il piano del documento 46. Prima audit delle dipendenze SQLite e inventario aggiornato delle fonti MariaDB/allegati, poi PostgreSQL come ambiente di riferimento; migrazioni, transazioni/concorrenza/registro/numerazioni e backup/ripristino verificati. Importazione direttamente da copia MariaDB/staging fedele nel modello PostgreSQL, tracciabilità ID e trasformazioni, nessuno scarto silenzioso, riconciliazione funzionale/economica e prova generale prima dell'apertura. Non presentare l'importatore attuale come completo.

Non ampliare I&C/EX, XML/Aruba o riscrivere VerbalizzAI nel medesimo intervento senza una richiesta specifica. I limiti e le approvazioni dei modelli DM ricevuti rimangono quelli della 0.16. Non dedurre che il fatto di usare PostgreSQL risolva da solo la migrazione Garda.
