# 38 · Differenze della 0.12.10 rispetto alla 0.12.9

12/10/2026 · Redatto da Claude · Schema Alembic **0019**, invariato: nessuna migrazione.

Fonte: le maschere AD_DM dettate da Federico il 12/10/2026, 09:39–09:49, raccolte nel documento di progetto 30, e la sua indicazione «per ora va bene così procediamo con le implementazioni».

## 1. Viste di partenza delle griglie

Ogni griglia può avere una **vista di partenza per attività**. La vista stabilisce:
- colonne visibili e loro ordine;
- raggruppamento;
- filtri.

Vale quando l'utente non ha una sua configurazione predefinita. Le altre colonne restano in «Colonne». Il raggruppamento e i filtri si tolgono con «Azzera filtri». Le configurazioni salvate dall'utente valgono come prima.

## 2. Maschere AD_DM

| Pagina | Colonne di partenza | Raggruppamento e filtri |
|---|---|---|
| **Clienti** (attività AD_DM) | ragione sociale, codice fiscale, indirizzo, CAP, comune, provincia, regione, referente commerciale | — |
| **Sedi operative** (AD_DM) | denominazione, indirizzo, CAP, comune, provincia, regione, cliente, nome, email e telefono del referente | — |
| **Attrezzature GVR** (nuova voce) | reparto, rif. interno, descrizione, matricola informale, n. fabbrica, PS, V, anno di costruzione, ultimo/prossimo funzionamento, ultima/prossima integrità, ultima/prossima visita interna, ultimi/prossimi CND, esente verifica, dismessa | per sede operativa (cliente › sede); dismesse nascoste |
| **Attrezzature SC/SP** (nuova voce) | come le GVR ma senza PS e V; ultima/prossima verifica, ultima/prossima indagine supplementare | come sopra |
| **Scadenze** | reparto, rif. interno, descrizione, matricola informale, n. fabbrica, data ultima verifica, data scadenza, tipo verifica (prima periodica / successiva), tipo scadenza (verifica periodica; funzionamento, integrità, visita interna), stato della scadenza | per sede operativa; solo allegato VII (le EX con «Attività EX») |
| **Preventivi** | numero/anno, data, stato, **fatturato** (No / Parziale / Totale sulle righe accettate), cliente, sede operativa, totale standard, totale, **riesame** (No / Sì, esito positivo / Sì, esito negativo) | — |
| **Verifiche GVR** (nuova voce) | numero verifica (verbale), data rilascio verbale, prossima verifica, sede operativa, verificatore, stato, gruppo, descrizione, matricola informale, n. fabbrica, reparto, rif. interno, tipo verifica, tipo verifica GVR, costruttore, anno di costruzione, **regime** (affidamento INAIL / affidamento datore di lavoro, dal verbale come in Garda), preventivo, **fattura**, **esporta INAIL** (Sì se l'incarico è in un'esportazione) | — |
| **Verifiche SC/SP** (nuova voce) | come le GVR senza tipo verifica GVR, costruttore, anno e regime | — |
| **Fatture** (AD_DM: nuova pagina «Fatture e incassi AD_DM»; anche AD_DPR) | 🖨 stampa rapida del PDF di cortesia, tipo (TD01, TD02, TD04), numero/anno/sezionale, data, cliente, fattura elettronica generata (Sì/No), totale imponibile, totale dovuto | attività della pagina; «Tutti gli ambiti» le mostra tutte |

**Menu AD_DM:**
- Attrezzature: **Attrezzature GVR**, **Attrezzature SC/SP**, Valvole di sicurezza, Tipi e tariffe;
- Verifiche: **Verifiche GVR**, **Verifiche SC/SP**;
- **Fatture**: in AD_DM prima non c'era.

I vecchi indirizzi `/attrezzature` (tutte) e `/incarichi-dm` (tutti gli incarichi) restano e accendono la voce corrispondente del menu. La «Fattura le selezionate…» delle righe DM apre la bozza nella pagina Fatture AD_DM.

**Uniformità con AD_DPR.** La pagina Fatture del DPR usa la stessa griglia. Per le altre pagine del DPR le maschere non sono ancora state indicate: restano com'erano.

## 3. Note

- **Valvole di sicurezza:** in sospeso, come chiesto.
- **Bozze nella griglia delle fatture:** numero vuoto e totali a zero finché non si emettono. Il totale della bozza si vede nella scheda.
- **Esente:** «No», «Sì» oppure «ISO 17020».
- **Date dei CND:** vengono dalle scadenze dei CND: un nuovo CND aggiorna ultima e prossima.

## 4. Prove

| Prova | Esito |
|---|---|
| `tests/test_maschere_dm.py` (nuovo, 3 test) | viste di partenza di clienti, sedi, attrezzature GVR e SC/SP, scadenze, preventivi, verifiche GVR e SC/SP; attrezzature GVR e SC/SP in elenchi separati con reparto, descrizione, PS, V, CND ed esente; verifiche GVR con fattura ed «esporta INAIL»; preventivi con fatturato e riesame; pagine nuove |
| Prova dell'interfaccia con Chromium | Attrezzature GVR raggruppate per sede, Verifiche GVR, Preventivi, Fatture AD_DM e AD_DPR sulla griglia con 🖨; nessun errore JavaScript |
| Suite completa | **272 test passati** (Linux, Python 3.13), `report_collaudo/pytest_0.12.10.txt` |

## 5. Prossimo passo

**VerbalizzAI_DM** (documento 28, punto 18; R123), con le regole di riproposta:
- GVR: «breve descrizione» e tabella delle camere da un verbale all'altro;
- SC/SP: si ripropone l'ultimo verbale.
