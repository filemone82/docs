# Versione integrata per il collaudo locale

Versione 1.5 — 9 ottobre 2026. Nuova priorità R97: arrivare a un gestionale integrato DPR/DM/I&C eseguibile in locale con le funzioni attuali; modello operativo Excel da preparare alla fine. Documento di perimetro, riscontro del codice e ordine di implementazione, non consegna di una versione completa già disponibile.

## 1. Obiettivo concreto

Un solo programma avviabile su Windows locale, nucleo dati comune, viste pertinenti per DPR, DM e I&C. Deve permettere prove operative: compilare/modificare schede, preventivare, affidare e registrare attività, produrre/gestire documenti, riesaminare dove previsto, fatturare e registrare incassi. Per DM deve includere la rendicontazione INAIL; per I&C i compensi commerciali e il collegamento ai beni/scadenze comuni. Cataloghi e regole Garda restano riferimento funzionale, con le modifiche già concordate.

Il rinvio del modello Excel non elimina R96 né rinvia la corretta rappresentazione dei dati importabili. L’import operativo massivo va completato prima dell’uso DM su nuovi parchi. Per costruzione e primi test del software si useranno copie dei dump ricevuti e dati di prova documentati, senza ricostruire il parco dai verbali. L’import iniziale dai backup e l’import operativo Excel sono lavori distinti.

Il collaudo locale delle tre attività può precedere le loro attivazioni in produzione: la sequenza R05 resta DPR prima, DM/I&C dopo validazione. Non occorre aspettare il modello Excel per iniziare il codice del nucleo e dei moduli.

## 2. Riscontro della base 0.8.0 (precedente all’incremento 0.9.0)

Base riletta: `Gestionale_AD_v0.8.0`, in particolare `STATO_IMPLEMENTAZIONE_0.8.0.md`, `gestionale/app.py`, modelli/servizi anagrafica, preventivi, verifiche, finanza, `core/migrazioni.py`, importer Garda e modulo scadenze. La lettura non è una nuova esecuzione dei test.

- Anagrafica attuale: clienti, sedi, impianti DPR; mancano modelli applicativi delle attrezzature SC/SP/GVR, accessori e classificazioni DM.
- Righe preventivo e verifiche fanno riferimento a `impianti.id`. Non basta aggiungere etichette DM/I&C al menu: collegamenti e servizi devono utilizzare il bene comune pertinente.
- Finanza contiene società, ambito, fatture, righe, scadenze economiche, esportazioni/esiti, incassi e allocazioni. È una base da riutilizzare, da raccordare a offerte/prestazioni DM/I&C e rispettivi sezionali; non certifica già questi due percorsi.
- Il modulo `scadenze` è attualmente il solo file di inizializzazione. Non costituisce lo scadenzario tecnico comune progettato.
- Non sono presenti moduli completi DM, rendicontazione INAIL o compensi collaboratori I&C nell’applicazione riletta.
- VerbalizzAI integrato nella base è 0.3.32.3 e conserva il proprio archivio. Il nuovo adattatore sul nucleo comune e il confronto con la versione autonoma consolidata restano lavoro necessario.
- La migrazione automatica Alembic e la verifica delle FK esistono nella base, ma non applicano già lo schema progettuale v0.3; quest’ultimo non va sovrapposto al database 0.8 senza migrazioni dedicate.

Questa distinzione evita di chiamare “completa” una versione che mostra menu o dati ma non esegue i flussi richiesti.

## 3. Matrice delle funzioni da portare al collaudo

“Base” significa codice disponibile da conservare/raccordare, non validazione operativa già conclusa. “Da realizzare” significa funzionalità o collegamento mancante. La matrice copre le famiglie già analizzate: il registro dettagliato Garda deve ancora verificare tutte le azioni e varianti, senza ometterle tacitamente.

| Famiglia | Stato rispetto alla 0.8.0 | Risultato richiesto nel collaudo integrato |
|---|---|---|
| Accesso, ruoli, impostazioni | Base comune | Permessi e visibilità per società/ambito/azione coerenti; tecnico DM/DPR distinto da collaboratore commerciale I&C. |
| Clienti, sedi, contatti, dati fiscali | Base comune DPR | Un’anagrafica condivisa con provenienze, senza variazione dei dati fotografati negli emessi. Preservare relazioni e avvisi utili. |
| Impianti DPR e stato tecnico | Base DPR | Conservare schede, elementi, ultime osservazioni e collegamenti VerbalizzAI passando al bene comune. |
| Attrezzature SC/SP/GVR | Da realizzare | Schede complete, matricole, classificazioni all.7/ID specifica/famiglia, parametri, esenzioni, dismissione e cataloghi. |
| Camere GVR e accessori | Da realizzare | Configurazione, volumi/DN, PSV e altri accessori, tarature e associazioni correnti senza inventare uno storico montaggi. |
| Cataloghi e tariffari DM | Da realizzare | Prima art.4/art.5 secondo messa in servizio, successive e componenti, multipla secondo riga preventivata, sconti R92 e contributi. Valori storici preservati. |
| Preventivi DPR | Base DPR | Documenti, iter Word/PDF, risposta scritta, accettazione anche parziale, RC, blocchi e integrativi conservati. |
| Preventivi DM/EX | Da realizzare | Sezionali, righe legate a bene e componenti, tariffe/contributi, trasferta e generazioni dalle scadenze secondo Garda. Separazione DM/EX. |
| Preventivi I&C | Da realizzare | Punti/sottopunti, prezzi a corpo e sconti pertinenti, tipi di attività, accettazioni e collaboratore. |
| Incarichi e verifiche DPR | Base DPR | Affidamento/indipendenza, programmazione distinta e facoltativa, registrazione, sospensione, VP/VS annuali condivisi, finalizzazione e RV negativo → registrata. |
| Verifiche DM | Da realizzare | Flussi e numerazioni DM, componenti GVR legate alla prestazione, tecnico, generatore, schede di prima verifica, riesame e aggiornamenti tecnici pertinenti. |
| Attività I&C e report | Da realizzare | Attività per sottopunto, date CND/supplementari/tarature, riferimento numero report, caricamento e invio del report. Integrazione del software tecnico esterno quando disponibile. |
| Documenti, versioni, download e invio | Base DPR da estendere | Contenuti storici, iter LibreOffice, revisioni dove concordate, nomi N01–N14 e legami ai lavori. Invii solo attraverso operazioni autorizzate nel gestionale. |
| Scadenzario tecnico comune | Da realizzare | Componenti separate, date iniziali senza verbali, dati da lavori reali, selezione e collegamento al preventivo; DM/I&C leggono lo stesso dato R95. |
| Rendicontazione INAIL | Da realizzare | Selezione e tracciato, Excel e ZIP, allegati e nomenclatura, deduplicazione fatture e riepilogo anomalie. Prova di produzione dei pacchetti; caricamento ASA manuale. |
| Fatture e note di credito | Base economica da raccordare | Emittenti/serie/sezionali distinti, intestatario terzo al momento della fattura, righe libere o da prestazioni, aggregazioni ammesse, acconti e rettifiche parziali/totali. |
| XML e PDF fattura | Base economica da validare | Documenti coerenti e tentativi conservati; download XML per Aruba e gestione dello scarto. La sola validazione XSD storico non certifica conformità fiscale corrente. |
| Incassi e residui | Base economica da raccordare | Pagamenti manuali, ripartizione su più fatture ammesse, residui e storni, separazione contabilità delle società. |
| Compensi commerciali I&C | Da realizzare | Percentuali, maturazione/collegamento a incassi e fatture collaboratori secondo le regole già analizzate. |
| Ricerca, filtri, esportazioni e azioni multiple | Base griglie da estendere | Operazioni sulle tre attività e relativi limiti/permessi. Il registro deve censire le azioni Garda, non soltanto le tabelle. |
| Backup, ripristino, registro | Base da estendere | Backup verificabile dell’intero nuovo archivio e documenti disponibili, recupero coerente e tracciamento modifiche nelle tre attività. |
| Migrazione per i test | Solo import iniziale ingecert nella base | Caricamento delle tre sorgenti su archivio di test con identità/relazioni quadrate; allegati mancanti dichiarati. Il vecchio migratore distruttivo è soltanto prova su destinazione sacrificabile. |
| Import operativo XLS/XLSX | R96, rinviato alla fase finale | Modello e caricamento parco/scadenze con anomalie e aggiornamenti definiti. Non necessario per cominciare il nucleo; necessario prima dell’uso DM sul nuovo parco. |

Fonti funzionali: quadro/registro, rapporti 06–15 e menu/metadati dei tre Garda. Confermati menu DM clienti/attrezzature/scadenze/preventivi/verifiche/fatture e I&C clienti/scadenze/preventivi/attività/fatture/compensi. La lettura dei menu non prova la completa equivalenza dei servizi.

## 4. Ordine di implementazione

| Blocco | Lavoro | Criterio di completamento |
|---|---|---|
| B1 — nucleo comune | Modelli/migrazioni per società, ambiti, beni, cataloghi, provenienze, scadenze e collegamenti. Migrazione dedicata del DPR esistente con conservazione delle identità/documenti. | Database aggiornabile su copia e FK integre; il DPR continua a eseguire i propri flussi. Schede dei beni delle tre attività disponibili senza duplicazione DM/I&C. |
| B2 — moduli operativi | Preventivi e incarichi DM, attività/preventivi I&C, tariffazione/cataloghi, aggiornamenti tecnici e scadenzario. | Scenari reali e combinati: una prestazione produce il numero corretto di incarichi/documenti e modifica le sole componenti pertinenti. |
| B3 — documenti e INAIL | Generatore DM, integrazione VerbalizzAI sul modello pertinente, report e revisioni, nomi allegati, INAIL. | Word/PDF effettivamente prodotti e verificati, storico conservato, pacchetti INAIL controllabili con documenti disponibili. |
| B4 — amministrazione integrata | Raccordo fatture/incassi dei tre ambiti, serie, contributi, compensi I&C, import storico quadrato e funzioni fiscali pertinenti. | Offerta → attività → documento → fattura → incasso per tutti gli ambiti, con contabilità separata ed esiti tracciati. |
| B5 — pacchetto Windows e parità | Azioni ulteriori emerse dal confronto, prove, dati importati, avvio, backup/ripristino; modello/import Excel finale. | Pacchetto scaricabile con stato per funzione e prove, senza etichettare “completo” un blocco mancante. |

I blocchi descrivono dipendenze, non una richiesta di approvare cinque nuove architetture o una stima in giorni. DPR già esistente ed economico devono essere riutilizzati dove coerenti. La matrice va aggiornata a ogni consegna con codice/prove effettivi; un menu o un modello dati non basta per segnare il completamento.

## 5. Prove e dati locali

La versione di collaudo deve avere archivio separato dall’esercizio e documentare i record originari dei casi di prova. Usare i dump ricevuti per schede e storici, preservando origini, serie e importi. Mai rieseguire tutti gli hook storici per ricostruire scadenze: acquisire stato e provenienza, con differenze segnalate.

Documenti creati nel collaudo possono esercitare anteprima/generazione/INAIL; non sostituiscono gli originali storici. Nei test con backup reali l’assenza S3 resta un limite esplicito per download e pacchetti che richiedono quegli allegati. Non serve richiedere adesso tutto S3 per sviluppare le funzioni.

Prove trasversali necessarie: nessuna perdita nella migrazione DPR, regole per famiglia, tariffe/importi, numerazione separata corretta, documenti storici non modificati da scheda, scadenze condivise, INAIL, compensi, fatturazione/incassi, permessi e ripristino. I precedenti test della 0.8 non dimostrano i nuovi flussi: vanno eseguiti test pertinenti dopo il codice. Il passaggio di perimetro iniziale non eseguiva nuovi test. Il successivo incremento 0.9.0 è verificato nella sezione 7 e nel rapporto 17.

## 6. Rinvii e decisioni da conservare

R97 rinvia modello operativo Excel e relativi dettagli IMP-01/02 alla fase finale; non blocca B1. COES-01 riguarda la convivenza di produzione e si può chiudere prima del cutover, senza impedirne il collaudo su copie. I rinvii già decisi per import estratti conto, gestione dedicata pluriennali e integrazione futura software report restano quelli del registro, senza nuove eliminazioni.

Aruba: la prima modalità conserva il download XML/caricamento manuale; l’import degli esiti richiesto resta lavoro da realizzare nella modalità concordata. Invio di fatture/esiti reali, deploy e cutover non vengono eseguiti per effetto delle prove locali.

**Stato aggiornato:** consegnato il primo incremento B1a, candidatura 0.9.0. B1 non integralmente completato, B2–B5 ancora da sviluppare; la versione completa delle tre attività rimane obiettivo R97. Nessuna percentuale o data di disponibilità inventata.


## 7. Stato dopo il primo incremento 0.9.0

Codice disponibile nel pacchetto `Gestionale_AD_v0.9.0_nucleo_comune_Windows_2026-10-09.zip`; rapporto 17 descrive implementazione, proprietà transitoria DPR e prove. La matrice della sezione 3 descrive il punto di partenza 0.8; le seguenti righe aggiornano le aree interessate senza segnare un'intera famiglia completa.

| Area | Stato effettivo 0.9.0 | Da completare |
|---|---|---|
| Beni/cataloghi | Schede comuni iniziali SC/SP/GVR/PSV; quattro cataloghi Garda e compatibilità; classificazione manuale. | Tutti gli attributi specifici, esenzioni, maschere e provenienze/migrazione delle tre sorgenti. |
| Camere/accessori | Camere L/DN, somma dei litri, PSV condivise, associazioni correnti e lettura tarature comuni. | Parametri completi, impiego nei generatori e collegamento ai lavori I&C/DM. |
| Date | Date iniziali dichiarate per componente e numero report, date DPR proiettate, esclusione interna tubazioni; ricerca/paginazione. | Scadenzario operativo completo, offerte/affidamenti e aggiornamento da lavori eseguiti secondo Garda. |
| DPR e migrazione | Migrazione 0011 con ID/riferimenti preservati; asset DPR in sola lettura aggiornato nella stessa transazione. | Completare la proprietà definitiva dei campi e il raccordo dei lavori al bene comune. |
| Backup e controlli | Nuove tabelle comprese nel backup e ripristino provato; versioni, permessi, CSRF, audit. | Collaudo grafico e uso Windows, copertura delle ulteriori funzioni integrate. |
| B2–B4 | Perimetro invariato, moduli completi non disponibili. | Offerte/incarichi DM/I&C, documenti/INAIL, amministrazione/compensi e import pertinenti. |

133 test passati (121 della base DPR e 12 nuovi del nucleo comune); prova interfaccia DOM+HTTP riuscita. Windows/produzione non verificati. Prossimo lavoro: schede tecniche complete e raccordo offerte/incarichi ai beni e componenti; Excel resta alla fine.


## 8. Correzione DPR e riscontro delle maschere AD_DM

Candidatura evolutiva corrente 0.9.1, manutenzione 0.8.1 per chi prova ancora il DPR precedente. R98 impedisce il secondo preventivo sulla periodica non completata; rapporto 18 descrive punti protetti, differenza dalle sole righe accettate Garda e limiti. Schema 0010/0011 invariato. Suite complete 135/147 test passati; 14 regressioni specifiche e prova DOM separata. I moduli completi DM/I&C rimangono da realizzare.

Le 15 schermate utente sono state aperte e confrontate con maschera/salvataggio/scadenze adsrl. L’utente critica il frontend 0.9 e ribadisce Garda come riferimento corretto. Rapporto 19 elenca campi, dipendenze, riferimenti e lacune: esenzioni a tre valori, matricola/vincoli, identificazione completa, classificazione/codici, GVR/SC-SP e ultimi lavori per componente. Prossimo incremento: completare queste schede nel backend e renderle operative con i gruppi Garda. B1a non diventa B1 completo per effetto di questo riscontro o dei test. La UI DM non è riscritta nella 0.9.1.

Rapporto 20 propone cartelle Windows, programma/dati e Stabile/Beta. AD_dpr è la base precedente del progetto integrato, non un terzo ramo attivo. Excel resta alla fine; nessuna omissione funzionale approvata in questo passaggio. Il criterio di parità deve comprendere maschere e azioni, non soltanto tabelle.


## 9. Prossimo codice già integrato con DM (R99)

Richiesta esplicita dell’utente: il prossimo rilascio funzionale deve avere DPR e DM realmente raccordati; la manutenzione 0.8.1/0.9.1 già pronta non equivale a quel risultato. B1/B2/B3 DM non si chiudono con maschere generiche; INAIL resta essenziale. I&C rimane nell’architettura e nel completamento successivo.

Rapporto 21 verifica offerte DM per cliente+sede e DPR al cliente con impianti multisede. Struttura comune consigliata: cliente obbligatorio, sede di contesto dove pertinente, righe con beni/sedi e fotografie. Il v0.3 già lo rappresenta; codice DM ancora da attuare. Mantenere comportamento DM per sede finché l’eventuale estensione multisede non venga valutata esplicitamente. Preservare destinatari sede, tariffe e sezionali; nessuna unificazione automatica delle offerte DM/DPR.

Importazione conservativa possibile con mapping delle origini e anomalie esplicite: non dividere multisede DPR, non fondere vecchie offerte DM, non ricalcolare storici. Le discrepanze trovate negli staging non autorizzano correzioni automatiche. Nessuna nuova importazione o modifica DDL in questa discussione.


## 10. Incremento 0.10.0-dev — raccordo commerciale DM

Rapporto 23 descrive codice e prove. Aggiunte schede tecniche e controlli, modello Word originale, 314 tariffe con provenienza, offerte DM per sede sulle tabelle e servizi comuni del DPR. Migrazione 0012 preserva i dati precedenti. Dopo risposta scritta/RC conforme vengono creati incarichi DM idempotenti **soltanto da assegnare**; non è implementata la macchina tecnica DM.

Prove finali: 168 test passati nella suite completa finale (147 della base e 21 DM), Linux/Python 3.12.14/SQLite; 1 avviso della suite. Ruff E9/F sui file applicativi interessati e controllo sintattico JavaScript passati. Alembic non rileva differenze fra schema 0012 e modelli dichiarati.. DOM+HTTP scheda GVR e offerta DM riuscito; Word originale compilato, clausola licenza verificata; nessuna nuova conversione PDF DM reale o prova Windows. B1/B2 avanzano ma non sono chiusi; B3/B4 DM e B5 restano da completare. R99 non soddisfatta da questo checkpoint. Non sono eliminate funzioni della matrice.

Prossimo blocco: verifiche tecniche/aggiornamenti componenti, generatore/documenti/nomi Garda, fatturazione DM collegata e INAIL, con completamento di EX/tariffari/scadenze/azioni. I&C successivo nel nucleo comune; Excel alla fine. Nessuna istanza parallela avviata, import completo dei tre dump o accesso S3 eseguito. Ripresa dal checkpoint 0.10.0-dev, non dalla 0.9.1 storica.

## 11. Incremento 0.11.0-dev — B2 parziale e navigazione

Incarichi DM fino a registrazione, schede tecniche/camere con aggiornamento atomico del master, numerazione/contributi e versioni obbligatorie. Tre ambienti selezionabili e ingressi /ad-dpr, /ad-dm, /iec sul backend comune. Richiesti indirizzi distinti nel definitivo almeno AD/I&C. Non è B2 completo né rilascio R99: precedenti/generatori/RV/finanza DM/INAIL e I&C rimangono pendenti. Rapporto 24 e stato/manuale nel codice dettagliano cosa provare.

**Prove finali:** 189 test passati nella suite completa (168 della base, 16 nuovi tecnici DM e 5 ambienti), Linux/Python 3.12.14/SQLite, 1 avviso di deprecazione del test client. Controllati schema/migrazioni rispetto ai modelli, migrazione 0012 popolata, numerazione concorrente, backup/ripristino, autorizzazioni e atomicità delle modifiche. Due prove DOM+HTTP passate con JavaScript/backend effettivi: schede/date/PSV/preventivi DM e assegnazione/programmazione/scheda tecnica/registrazione. Controlli Ruff E9/F sui file modificati e sintassi dei cinque JavaScript interessati passati. La diagnostica più ampia conserva segnalazioni preesistenti di base/terzi; VerbalizzAI incorporato non modificato. Conversione PDF delle offerte simulata nei server di prova, Windows/produzione/PostgreSQL e LibreOffice DM reale non osservati.
