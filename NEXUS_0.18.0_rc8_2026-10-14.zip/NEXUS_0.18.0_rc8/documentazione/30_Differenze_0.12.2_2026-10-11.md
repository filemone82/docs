# 30 · Differenze della 0.12.2 rispetto alla 0.12.1-wip1

11/10/2026 · Redatto da Claude · Riferimento: documento 18 «Ripresa unica», § 4 (passo A).

**Base:** `Gestionale_AD_0.12.1-wip1_checkpoint_2026-10-11.zip`, SHA-256 `66ceb0369db069e71136a33f33c70d7eb36debc7bf222d6c6211a444d6d6c686`.
**Versione nel codice:** `0.12.2`.
**Schema:** invariato, Alembic **0015**. Nessuna nuova migrazione.

## Cosa cambia per chi usa il programma

### A1 · Indipendenza bloccante in DPR e DM (R110)

La dichiarazione di indipendenza è preimpostata su «Sì». Con «No» la verifica non si può:
- **programmare**;
- **registrare**;
- **eseguire**: nel DPR con l'emissione del verbale o il caricamento del Word; nel DM con la generazione del Word/PDF o la chiusura.

Il messaggio spiega di riassegnare la verifica a un altro tecnico. La riassegnazione riporta la dichiarazione a «Sì» per il nuovo tecnico. Se l'indipendenza viene esclusa dopo la registrazione, la verifica resta registrata ma non si chiude.

- **Prima:**
  - nel DPR il blocco c'era su registrazione ed esecuzione, non sulla programmazione;
  - nel DM la 0.12.1-wip1 aveva **tolto** il blocco per uniformarsi a Garda adsrl.
- **Ora:** stesso controllo per tutti (`verifiche.servizio.richiedi_indipendenza`), chiamato da DPR e DM. Per il DM è la deroga ad adsrl approvata l'11/10/2026 (chiude AD-31).

### A2 · Riesame negativo del verbale DM: ciclo completo (R108/R109)

- **La nota del RT è in evidenza per il tecnico.** Il tecnico assegnato vede nella linguetta «Incarico» un riquadro rosso con data, autore e nota del riesame non conforme, e l'indicazione di cosa fare. Prima la nota era solo nella linguetta «Riesame». Il tecnico continua a non vedere i lavori degli altri e non può riesaminare il proprio.
- **Le date CND tornano indietro alla riapertura.**
  - Una chiusura scrive le date CND sul bene. Se il riesame riapre il lavoro, quelle date tornano ai valori precedenti. Lo stesso vale se si annulla un lavoro già chiuso.
  - **Prima** restavano le date da correggere. La nuova chiusura le confrontava con quelle sbagliate, e una data corretta più vicina veniva scartata (regola Garda «non sovrascrivere una prossima CND successiva»).
  - Se dopo la chiusura qualcuno ha corretto a mano la CND sul bene, la correzione prevale e non si ripristina nulla.
- **Scadenze di funzionamento, integrità e interna:** tornano alla verifica effettuata precedente oppure alle date iniziali dichiarate. Se non c'erano date, restano vuote. Comportamento già presente, ora provato nei due casi.
- **Nuova chiusura:** richiede un nuovo riesame. Ogni riesame resta nello storico con il PDF esaminato.

### A3 · Storico dei riesami del preventivo (R109)

Il programma conservava già tutti i riesami del contratto, ma mostrava solo l'ultimo. Ora:
- l'API restituisce `riesami`, l'elenco completo dal più recente, con esito, punti di controllo, note, autore e data;
- la linguetta «Riesame» del preventivo mostra lo storico quando i riesami sono più di uno.

Lo storico dei riesami del **verbale** era già presente nel DPR (`storico_riesami`) e nel DM (`riesami`).

### A4 · Visita interna solo per GV/INS GV (DM-07)

Nel catalogo Garda la visita interna biennale esiste solo per due famiglie GVR:
- **a2** «Generatori di vapore»;
- **a3** «Generatori di acqua surriscaldata».

Per tutte le altre famiglie è «N.A.».

- **Prima:** la si escludeva solo per le tubazioni (a4).
- **Ora:** non si propone e non si accetta per recipienti, tubazioni, generatori di calore e forni, né sul bene né nel preventivo né nell'incarico. Senza famiglia GVR non si propone.
- Non si può cambiare la classificazione di un bene che ha date di visita interna, se la nuova famiglia non la prevede.
- Portato dal ramo WIP nato dalla 0.11, con test nuovi.

### A6 · Migrazione 0015 provata con dati

Test nuovo:
1. archivio con fatture emesse;
2. ritorno a 0014: le fatture restano integre;
3. ritorno a 0015: dati identici e schema uguale ai modelli;
4. con una riga «prestazione intera» il ritorno a 0014 è **rifiutato**, e lo schema resta 0015 con i dati intatti.

Così il difetto di atomicità visto nel ramo WIP è escluso per la 0015.

### A7 · VerbalizzAI identico alla versione in produzione (R111)

- `strumenti/aggiorna_verbalizzai.py` ora scrive `gestionale/terzi/verbalizzai/IMPRONTE_ORIGINE.json` con l'impronta SHA-256 di ogni file copiato.
- Rieseguendo lo strumento sullo zip in produzione `VerbalizzAI_AD_v1.0.1_rc2.zip`, la copia rigenerata è **identica byte per byte** a quella già presente: l'unica novità è il file delle impronte.
- Il test nuovo `tests/test_verbalizzai_identico.py` fallisce se un file di VerbalizzAI dentro il gestionale viene modificato o aggiunto.

## File modificati

**Applicativi:**
- `gestionale/__init__.py` (versione)
- `gestionale/moduli/verifiche/servizio.py`
- `gestionale/moduli/dm/tecnico.py`, `dm/documenti.py`, `dm/scadenze.py`, `dm/servizio.py`
- `gestionale/moduli/beni/servizio.py`
- `gestionale/moduli/preventivi/servizio.py`
- `gestionale/static/js/incarichi_dm.js`, `gestionale/static/js/preventivi.js`
- `strumenti/aggiorna_verbalizzai.py`

**Nuovi:**
- `gestionale/terzi/verbalizzai/IMPRONTE_ORIGINE.json`
- `tests/test_verbalizzai_identico.py`

**Test modificati:** `test_dm_tecnico.py`, `test_dm_documenti.py`, `test_dm_preventivi.py`, `test_beni.py`, `test_finanza.py`, `test_preventivi.py`.

## Prove eseguite (Linux, Python 3.13.16, SQLite, LibreOffice 24.2)

| Prova | Esito |
|---|---|
| Suite completa `python -m pytest -q` | **222 passati**, 0 falliti, 1 avviso, 358 s. Log `report_collaudo/pytest_0.12.2.txt` e `.xml` |
| Base 0.12.1-wip1 rieseguita prima delle modifiche, stesso ambiente | 215 passati |
| Test nuovi o modificati per il passo A | indipendenza DPR e DM, riesame negativo con e senza date iniziali, CND corretta a mano, storico riesami preventivo, visita interna su recipiente e su generatore di vapore, migrazione 0015 popolata, identità VerbalizzAI |
| `ruff check --select E9,F` sui file Python modificati | Passato (`report_collaudo/ruff_0.12.2.txt`) |
| `node --check` sui due file JavaScript modificati | Passato |

## Non verificato in questa consegna

- **Interfaccia nel browser:** riquadro della nota di riesame DM e storico dei riesami del preventivo. Controllata solo la sintassi JavaScript.
- **Installazione e uso su Windows**, Microsoft Word, PostgreSQL.
- **Python 3.12:** i test sono stati eseguiti con Python 3.13. Le dipendenze e il codice non usano funzioni specifiche della 3.13, ma la prova su 3.12 (quella prevista su Windows) resta da fare con `ESEGUI_TEST_WINDOWS.bat`.
- **Fatture DM e lotti INAIL:** restano la bozza backend della 0.12.1-wip1, senza modifiche e senza test dedicati (documento 18, A5).

## Punti aperti emersi

1. **`tipo_prox_verifica` dopo una riapertura.** Alla chiusura di un lavoro DM il bene passa a «V2» (successiva). Se il riesame riapre l'unico lavoro chiuso, il bene resta «V2» anche senza verifiche effettuate. Va controllato sul codice Garda cosa accade e allineato. Non modificato.
2. **Beni importati senza famiglia GVR:** da ora non ammettono la visita interna. L'importazione da Garda deve portare la famiglia (passo B).
3. **Fatture già emesse e lotti INAIL già generati prima di una riapertura:** restano immutati, come previsto. Va deciso come segnalarli all'operatore (passo D).
