# 35 · Differenze della 0.12.7 rispetto alla 0.12.6

11/10/2026 · Redatto da Claude · Schema Alembic **0018**, invariato: nessuna migrazione. Fonte: decisione di Federico **R122**, del pomeriggio dell'11/10/2026.

## 1. Una sola scheda tecnica per l'impianto (R122)

> «una sola scheda tecnica per l'impianto. diciamo che tutti i campi del verbale (ad esclusione di "positivo" / "negativo", durata verifica, persona presente in occasione della verifica, resistenza di terra, sono attributi dell'impianto. il verbale precompilato di verbalizzAI ripropone l'ultimo aggiornamento.»

VerbalizzAI funziona già così: il verbale è la fotografia della verifica, la «Scheda impianto» è lo stato aggiornato da cui riparte la bozza successiva. Anche i campi che esclude coincidono con l'elenco di Federico.

Il gestionale invece teneva una **seconda copia** in `Impianto.caratteristiche`, scritta dal verbale. Questa copia non seguiva:
- la scelta «Conserva la scheda impianto» fatta all'emissione;
- le correzioni e le adozioni fatte nella scheda di VerbalizzAI;
- gli annullamenti.

**Dalla 0.12.7:**
- **Fa fede la scheda di VerbalizzAI.** VerbalizzAI 1.0.1 rc2 non è stato modificato (R111): se ne usano solo le funzioni.
- **La copia nel gestionale è solo di lettura.** Contiene caratteristiche, potenza ed elementi e serve a offerte, ricerche ed elenchi. Ricorda da quale impianto di VerbalizzAI e da quale revisione della scheda proviene. Si riallinea da sola (`gestionale/moduli/verbali/scheda.py`):

| Quando | Cosa succede |
|---|---|
| Emissione del verbale | Le **date** (ultima e prossima verifica, periodicità) vengono dal verbale emesso; la **scheda tecnica** viene da quella di VerbalizzAI, aggiornata o conservata secondo la scelta fatta all'emissione |
| Scheda corretta a mano, adottata da uno storico, verbale annullato o ripristinato, Word storici importati, rilettura, ripristino da backup (in VerbalizzAI) | Riallineamento automatico degli impianti coinvolti |
| Verbale precedente caricato dalla verifica (0.12.6) | Le date seguono la regola di prima. La scheda si aggiorna se il Word è più recente; se è il primo Word, resta «da confermare», come in VerbalizzAI |
| Collegamento di un impianto di VerbalizzAI (Gestione › Verbali di VerbalizzAI) | Riallineamento dalla scheda dell'impianto collegato |
| **Word caricato a mano su una verifica** (verbale fatto con il VerbalizzAI esterno) | Il Word entra anche nell'archivio dei verbali, sull'impianto giusto, e aggiorna la scheda come un'emissione, mai all'indietro: la bozza della verifica successiva riparte da lì. Se non si può, la verifica è comunque eseguita e un messaggio lo spiega |
| Apertura della scheda dell'impianto | Se la copia è indietro, per esempio dopo un ripristino, si riallinea |
| «Riallinea» dei verbali (`/api/verbali/riallinea`) | Riallinea anche tutte le schede |

Un impianto con verbali ma senza scheda (archivi nati fuori dal flusso normale) usa l'ultimo verbale valido. È anche il verbale da cui VerbalizzAI farebbe ripartire la bozza.

**Scheda dell'impianto nel gestionale.** La linguetta «Caratteristiche ed elementi» diventa **«Scheda tecnica»** e contiene:
- lo stato della scheda: confermata, da confermare o da riesaminare, con data, verbale di origine e provenienza (es. «dati inseriti a mano»);
- le voci (tutti i gruppi di caselle M01, comprese tensione limite, prescrizioni particolari, guasti AT e tensioni di contatto, che prima mancavano) e gli elementi dell'impianto;
- il pulsante **«Modifica scheda tecnica»** (o «Apri», senza il permesso «impianti.stato_tecnico»). Apre direttamente la «Scheda impianto» di VerbalizzAI, con la stessa maschera, la conferma e lo storico: non c'è una seconda maschera da tenere allineata.

Non sono nella scheda, perché appartengono al singolo verbale:
- esito, durata, persona presente, resistenza di terra (proposta nella bozza solo come valore del verbale precedente);
- numero, date, motivo, periodicità spuntata, strumenti, note, non conformità, valori misurati sugli elementi.

**Potenza.** VerbalizzAI la scrive come «250 kW»: ora si legge e alimenta le offerte. Prima il gestionale la scartava. I valori in kVA non si convertono.

## 2. Altre modifiche

- **Caricamento a mano del verbale.** Nella verifica, eventuali note sulla scheda compaiono nel messaggio di conferma.
- **Pagina dei verbali.** L'indirizzo `/verbali?scheda=<impianto>&modulo=M01` apre la Scheda impianto. Lo gestisce `ponte_verbali.js`, che è del gestionale; `app.js` di VerbalizzAI non cambia.

## 3. Prove

| Prova | Esito |
|---|---|
| Suite completa, Linux, Python 3.13 | **251 passati** (`report_collaudo/pytest_0.12.7.txt`) |
| `tests/test_scheda_tecnica.py` (nuovo) | emissione con «Aggiorna»; correzione a mano in VerbalizzAI riallineata nel gestionale con voce nel registro; emissione con «Conserva» (la scheda resta quella del verbale precedente, le date vengono dal verbale emesso); Word caricato a mano che entra nell'archivio dei verbali e diventa il precedente; apertura della scheda da gestionale; lettura della potenza |
| Interfaccia (Chromium, ambiente di prova) | linguetta «Scheda tecnica» vuota e compilata; «Modifica scheda tecnica» apre la Scheda impianto di VerbalizzAI; nessun errore JavaScript |
| Identità di VerbalizzAI 1.0.1 rc2 | test di identità verde |

**Non verificato:** il riallineamento su un archivio reale grande, con migliaia di impianti collegati. Una scheda si riallinea in pochi millisecondi, ma il «Riallinea» generale non è stato cronometrato sul dump reale.

## 4. Decisioni registrate nella stessa giornata

- **R122**: questo documento.
- **R123**: verbali AD_dm con la logica di VerbalizzAI. È la proposta del documento 24 del progetto, con le risposte di Federico. Si realizza nelle 0.13.0–0.13.3; le fatture DPR passano alla 0.14.
