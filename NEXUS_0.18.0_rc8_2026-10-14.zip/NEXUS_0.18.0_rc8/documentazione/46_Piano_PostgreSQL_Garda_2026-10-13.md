# Passaggio a PostgreSQL e importazione completa Garda

## Decisione e stato

Approvazione esatta di Federico, 13/10/2026:

> ok concordo procediamo prima con 0.17 con correzioni approvate e dopo passaggio a postgreSQL. nmi raccomando documenta tutto a latere così che io possa proseguire con un'altra istanza di LLM

Prima 0.17 con correzioni approvate; poi PostgreSQL per il database principale. Stato: pianificato e autorizzato, **non implementato e non collaudato**. L'importazione completa e coerente MariaDB di Garda è un requisito ESSENZIALE per la produzione, non ancora soddisfatto dall'importatore esistente. Nessun dato operativo è stato modificato in questa consegna.

## Perché intervenire prima della produzione

La base 0.17 usa `core/db.py` con URL SQLite e PRAGMA, RLock del processo e un solo scrittore. Query specifiche in `moduli/anagrafica/griglie.py`, `beni/griglie.py`, `utenti/griglie.py`, `strumenti/griglie.py`, `finanza/griglie.py`, `tariffario/griglie.py` usano group_concat, date("now", "localtime"), julianday e modificatori SQLite. `moduli/backup/servizio.py` usa l'API sqlite3 e ripristina un file. Migrazioni Alembic e modelli vanno verificati su PostgreSQL reale, comprese quelle con batch_alter_table, default booleani, vincoli e indici parziali.

SQLAlchemy non rende automaticamente portabili queste operazioni. Scegliere una versione PostgreSQL supportata e usarne la stessa versione principale in sviluppo, collaudo e produzione. SQLite può restare per dimostrazioni isolate solo se esplicitamente desiderato; non serve assumere un obbligo di supportare entrambi in produzione. Il componente VerbalizzAI 1.0.1 rc2 va preservato: il suo archivio SQLite interno è un confine distinto, con backup coordinato e recupero coerente da progettare senza riscriverlo automaticamente.

## Fase A — compatibilità e concorrenza

- Configurazione della connessione separata dal percorso dati; credenziali fuori dal pacchetto, pool e transazioni verificati.
- Portare e provare tutte le migrazioni da archivio vuoto; definire una procedura provata di trasferimento dei soli archivi di collaudo SQLite già creati, separata dall'importazione Garda.
- Sostituire funzioni SQL dipendenti da SQLite e verificare filtri, date in Europe/Rome/UTC, ordinamenti, NULL, ricerca e raggruppamenti su PostgreSQL.
- I blocchi RLock non proteggono più processi: proteggere numerazioni, assegnazioni, fatture, registro a catena e controllo versioni con operazioni atomiche e blocchi/transazioni del database appropriati. Verificare aggiornamenti contemporanei su connessioni/processi distinti; niente max(numero)+1 senza protezione. Non promettere assenza di buchi nei numeri tecnici delle sequenze PostgreSQL; i numeri dei documenti seguono le regole applicative concordate.
- Vincoli NOT NULL, FK, UNIQUE e indici parziali abilitati e verificati; non disabilitarli per nascondere errori di importazione.
- Backup PostgreSQL più documenti e archivio VerbalizzAI: fissare un punto coerente, verificare il ripristino in ambiente separato e documentare tempi/recupero.
- Eseguire la suite completa su PostgreSQL e i test di concorrenza aggiuntivi. Prestazioni su volumi rappresentativi, non solo pochi record.

**Criterio di uscita:** avvio/migrazione, flussi DPR/DM, permessi, numerazioni, conflitti, registro, griglie, export e ripristino tutti provati sul database scelto. Non dichiarare supporto PostgreSQL dal solo avvio dell'app.

## Fase B — inventario e contratto dei dati Garda

Lavorare su una copia coerente e immutabile MariaDB, senza interventi distruttivi su Garda. Inventariare versioni, motori delle tabelle (InnoDB o altri), codifica/collation, schema, chiavi effettive, tabelle, viste, trigger/routine/eventi rilevanti, conteggi e allegati esterni/BLOB. Verificare tutte le società/archivi coinvolti: ID uguali di archivi diversi non sono la stessa identità.

Creare un dizionario versionato per ogni tabella/campo e codice di stato. Destinazioni: operativo NEXUS, storico consultabile con dati originali conservati, o esclusione esplicitamente motivata e approvata. Non chiamare «completa» l'importazione se comprende solo anagrafiche e attrezzature. Preventivi/revisioni/righe, incarichi, verbali, numerazioni, fatture/crediti, pagamenti/scadenze/incassi, allegati e audit, ove presenti, devono avere destinazione e criteri di verifica.

Conservare una mappa univoca (archivio origine, tabella, ID Garda) → ID NEXUS e tracciabilità della trasformazione per record. Per duplicati di clienti/sedi: niente unioni automatiche basate sul solo nome; regole approvate e preservazione dei riferimenti originali. Evidenziare date zero/non valide, campi vuoti, NULL, decimali, arrotondamenti, valuta, fusi, enum, cancellazioni e incongruenze già presenti. Non correggere in silenzio la storia. Conservare separatamente ciò che non è ancora rappresentabile, senza fingere che sia già operativo.

## Fase C — importatore e riconciliazione

Percorso: MariaDB sorgente → copia/staging fedele → trasformazioni versionate → modello PostgreSQL NEXUS. Nessun passaggio necessario dal modello SQLite NEXUS. Gli strumenti esistenti `moduli/garda/importa.py`, `importa_dm.py`, `dump.py`, `strumenti/importa_da_garda.py` e `audit_contabilita_garda.py` sono una base da auditare, non la prova di completezza.

L'importazione dello storico non deve attivare nuove fatture, incarichi, invii, scadenze ricalcolate o numerazioni. Ogni esecuzione ha ID, hash della sorgente/allegati, versione dello schema e dell'importatore, contatori, anomalie e log. Riesecuzione controllata senza duplicati; fase di analisi senza scrittura, importazione su database nuovo e promozione solo dopo verifica. Transazioni/checkpoint e ripresa da errore progettati secondo il volume; nessuno scarto silenzioso.

Rapporto automatico obbligatorio:

| Controllo | Criterio |
|---|---|
| Copertura | Ogni tabella e categoria dell'inventario ha una destinazione/esclusione approvata |
| Quantità | Conteggi sorgente/destinazione e motivazione verificabile di ogni aggregazione o scarto |
| Collegamenti | Zero nuovi riferimenti orfani; eventuali orfani sorgente evidenziati e risolti con scelta tracciata |
| Identità | Mappa stabile, zero collisioni tra archivi, riesecuzione senza duplicati |
| Documenti | Conteggi, dimensioni/hash e collegamento al documento/cliente/incarico corretto |
| Stati e numerazioni | Revisioni, annullamenti, esiti, sequenze e documenti successivi coerenti con la storia |
| Economico | Imponibile, IVA, totale, crediti, incassi e residui per società/anno riconciliati, differenze spiegate |
| Operatività | Casi completi scelti con chi conosce Garda e controllati in NEXUS, non solo conteggi |

Ripetere da zero sullo stesso snapshot: stesso risultato. Prova generale con copia completa recente, tempi misurati, allegati inclusi, rapporto delle anomalie e firma delle verifiche funzionali da parte dei referenti.

## Fase D — passaggio definitivo

Definire fermo operativo, responsabilità e criteri di apertura. Procedura iniziale raccomandata: sospendere scritture Garda; copia finale coerente + allegati allo stesso punto; importazione; riconciliazione; apertura NEXUS. Conservare Garda in sola lettura per consultazione e audit. Se il fermo non è accettabile, progettare esplicitamente acquisizione delle modifiche/delta o CDC, ordinamento e riconciliazione: non improvvisare una doppia scrittura permanente.

Ritorno indietro: semplice prima dell'apertura NEXUS; dopo nuove scritture serve un piano di recupero e reinserimento delle operazioni, non basta ripristinare un vecchio backup. Provarlo prima della produzione. Database e documenti devono essere ripristinabili insieme.

## Informazioni ancora da verificare

Versione/esatta configurazione MariaDB Garda, inventario completo aggiornato, motori/codifiche, società/archivi, volume e documenti esterni, tempi massimi di fermo e di recupero, disponibilità dell'ambiente PostgreSQL e referenti per riconciliazione funzionale/contabile. Usare il materiale Garda già disponibile come punto di partenza, verificando quanto è aggiornato e completo. Non richiedere nuovamente file che sono già nel progetto senza averne controllato la presenza.

## Fonti primarie consultate il 13/10/2026

- SQLite, appropriate uses: https://www.sqlite.org/whentouse.html — un solo scrittore per file, casi adatti ai database client/server.
- PostgreSQL, constraints: https://www.postgresql.org/docs/current/ddl-constraints.html — integrità referenziale, unicità e vincoli; differenze sui NULL da verificare.
- MariaDB, mariadb-dump: https://mariadb.com/docs/server/clients-and-utilities/backup-restore-and-import-clients/mariadb-dump — snapshot coerente per tabelle transazionali e limiti con DDL/motori non transazionali; routine/eventi vanno inclusi quando rilevanti. Un dump SQL MariaDB non è direttamente lo schema PostgreSQL del nuovo gestionale.
