# Ripresa del progetto — gestionale integrato AD

Versione 1.10 — 10 ottobre 2026, ora italiana. Documento quadro corrente **1.95**, registro **R01–R106**. Questa scheda serve a proseguire l’analisi da un’altra istanza; è un indice operativo. Le decisioni complete e le successive correzioni sono nel documento quadro.

## Indicazione corrente — trasferimento fedele e candidata completa

**Formato delle consegne richiesto da Federico il 10 ottobre 2026:** ogni stato di avanzamento deve includere un README con istruzioni di installazione, avvio e aggiornamento pertinenti alla versione. Nella 0.12 il file è README_INSTALLAZIONE.md, incluso nel pacchetto e disponibile separatamente. Distinguere sempre prova locale e uso in produzione; non presentare istruzioni non osservate come installazione collaudata.

Leggere prima il rapporto **25_Percorso_gestionale_completo_2026-10-10.md**, la sezione 77 del quadro e il rapporto 26. Garda funziona bene: conservare TUTTE le regole/funzioni, senza semplificazioni o omissioni tacite; variazioni concordate o necessarie all’unificazione, con effetti espliciti. Obiettivo autonomia dal fornitore, un prodotto con tre frontend e backend comune. Federico è ingegnere gestionale: guidare scelte tecniche e chiedere solo decisioni operative concrete.

Base corrente interna **0.12.0-dev**, schema 0014, VerbalizzAI incorporato **1.0.1 rc2**. Il ciclo DM prosegue da registrata a Word/PDF, conferma del definitivo, effettuata, riesame e date per componente; dettaglio e limiti nel rapporto 27/stato 0.12. Fatturazione DM collegata, EX, INAIL, I&C, dashboard e migrazione completa restano da terminare. Non presentare checkpoint come rilascio R99/R106: traguardo di collaudo è la candidata completa. Le sezioni successive conservano gli stati storici.

**Prossimo lavoro:** fatturazione DM collegata e pacchetti INAIL, poi I&C e riconciliazione. Matrice 26 aggiornata per i percorsi effettivamente provati; le altre regole rimangono aperte. Verificare anche AD-31 (blocco DPR ereditato nel DM), eccezione multipla AD-21 e correzioni dopo chiusura; nessuna deroga acquisita automaticamente. Non ricreare migrazioni 0012–0014 o gestionali autonomi, non chiedere di installare ogni checkpoint.

Percorso documentale richiesto per offerte/verbali DM: ritocco ammesso, controllo PDF, definitivo conservato e invio dello stesso file. Dashboard DM da rifare; nessuna nuova grafica già implementata/approvata. Inventario metadati e regole non equivale a parità completa. Proseguire sullo stesso progetto, con VerbalizzAI/AD_dpr riusati dove compatibili; non avviare tre nuove applicazioni.

## Da dove riprendere

1. Leggere la **versione attuale** di `04_Documento_quadro_gestionale_integrato_2026-10-08.md`: introduzione/stato, registro, ultime sezioni 64–76; approfondire le altre sezioni secondo il tema.
2. **Priorità corrente R97:** leggere `16_Perimetro_versione_integrata_per_collaudo_locale_2026-10-09.md` (1.5) e `17_Primo_incremento_nucleo_comune_0.9.0_2026-10-09.md` (1.0). Base precedente **0.9.1**, B1a con correzione dei duplicati DPR R98; manutenzione **0.8.1** per il collaudo precedente. Codice corrente di sviluppo **0.11.0-dev**, tecnico DM e ambienti operativi, rapporto **24**; rapporto 23/base 0.10 storici. Leggere anche rapporti **18** (correzione), **19** (maschere Garda/lacune), **20** (cartelle Windows) e **21** (cliente/sede del preventivo e import); versione completa DPR/DM/I&C ancora da terminare, Excel alla fine. Rapporti Excel 14 (1.3) e 15 (1.2) restano evidenze per la fase finale.
3. Per migrazione e convivenza leggere `13_Proposta_riallineamento_incrementale_e_convivenza_Garda_2026-10-09.md` (1.0). È una proposta, con COES-01 aperta.

**Chiarimento corrente:** l’utente compilava XLS e la software house gestiva l’importazione. Non conosce la semantica tecnica delle celle vuote. Non reiterare IMP-01 come domanda astratta né registrarla approvata. Riscontro Garda nel rapporto 15 sezione 10: comportamento diverso per tipi/canali; configurazione concreta storica non dimostrata. Eventuali differenze future si valuteranno su effetti concreti secondo R73.

**Prossimo lavoro applicativo — R99:** continuare dal checkpoint 0.11.0-dev e rapporto 24. Incarichi DM fino alla registrazione, aggiornamento master/bozze e selettore dei tre ambienti implementati. Riproporre precedenti selettivamente e completare generatori/documenti/nominativi N01–N14, aggiornamenti da lavori effettuati, riesame DM, fatturazione collegata e INAIL; poi I&C. R99 non è soddisfatta. Ingressi distinti nel definitivo richiesti dall’utente (R100), almeno AD e I&C; domini/autorizzazioni per ambito di produzione non ancora implementati. Stessa applicazione, non tre copie o database. 0.10/0.9.1 preservate; non ricreare 0012/0013.

**Prove della base precedente:** suite complete 135 test 0.8.1 e 147 test 0.9.1 passati; 14 nuove regressioni, suite specifiche rieseguite dopo estensione del caso legacy, DOM della scadenza con API simulate e backend HTTP verificato separatamente. Nessuna migrazione aggiuntiva: 0010/0011. Windows non osservato. Duplicati già presenti non annullati automaticamente. B1/DM/I&C/INAIL incompleti; Excel e IMP-01/02 rinviati, COES-01 di produzione non blocca queste prove.

## Obiettivo e vincoli da conservare

- Ricostruzione Python: Garda PHP/dump sono riferimento funzionale, non codice da adattare. AD_DPR (`ingecert`) prima in produzione dopo validazione, AD_DM (`adsrl`) e I&C (`iec`) successivamente; backend pensato fin dall’inizio per tutti.
- AD S.r.l. e I&C S.r.l. sono emittenti/contabilità distinte. La fusione della precedente I&C snc non implica inattività dell’attuale I&C S.r.l.
- R73: omissioni o differenze delle regole Garda richiedono valutazione e consenso; ristrutturazione tecnica per database comune ammessa, con effetti funzionali esplicitati. Conservare nomi allegati N01–N14, tariffazione, classificazioni e flussi già verificati.
- DPR iniziale include fatturazione e incassi completi. Prove iniziali locali Windows, online, senza bozze offline. Ruoli/permessi governano gli operatori; evitare passaggi e registrazioni duplicati.
- R88: tecnici DM/DPR e collaboratori commerciali I&C restano distinti. R95: beni/scadenze comuni eliminano la sincronizzazione manuale. Non riprodurre il vecchio ponte come nuovo flusso.
- R99: prossimo rilascio funzionale DPR+DM, non altro prototipo di solo nucleo. INAIL resta essenziale; I&C rimane nel perimetro successivo.
- R98: periodica già preventivata non ripreventivabile prima di annullamento o completamento del lavoro; revisioni/VS/integrativi distinti preservati, controllo backend e nessuna bonifica automatica.
- R97: priorità a versione integrata locale con funzioni attuali; modello Excel alla fine, R96 conservato.
- R96: l’utente popolava il modello XLS, la software house caricava i dati. Import operativo massivo XLS/XLSX SC/SP/GVR, accessori/PSV, classificazioni, configurazioni, ultime/prossime date e CND. Non richiede ricostruzione da verbali o inserimento individuale. Chiavi elenchi cliente non devono richiedere un ID Garda.
- R74 classificazioni manuali/importate; SC oltre dieci anni modifica all.7 secondo la prassi chiarita. R80 somma volumi camere, DN escluso. R94 tubazioni senza visita interna. R85 numero report CND, software tecnico esterno da integrare in futuro.
- Conservare fotografie storiche di preventivi/verbali emessi; attrezzatura corrente evolutiva. Preventivo accettato non modificabile, aggiunte mediante integrativo. Numerazione DPR unica annua VP/VS. Dettagli e altre regole nel registro completo.
- INAIL DM essenziale: trimestrale, nomi e tracciato da mantenere, caricamento manuale Excel/ZIP A.S.A.; generazione non prova acquisizione portale. Nessuna verifica di conformità alle specifiche attuali viene certificata dal solo audit del vecchio generatore.
- Nessun originale S3 richiesto ora. Metadati disponibili non provano contenuto/hash dei file. Non operare sul VPS VerbalizzAI per effetto del lavoro sul gestionale.

## Stato reale del lavoro

| Area | Disponibile / limite |
|---|---|
| DPR | Codice corrente 0.11.0-dev sul nucleo DPR; checkpoint 0.10 e baseline 0.9.1 preservati. Contiene VerbalizzAI 0.3.32.3; non prova integrazione dell’ultima versione autonoma. Collaudo locale Windows e completamento restano necessari. |
| Schema unificato | Proposta v0.3 con 85 tabelle, 230 FK e diagrammi E-R nel pacchetto `Gestionale_AD_schema_ER_v0.3_2026-10-09.zip`. Verifica strutturale su SQLite, non migrazione dell’applicazione o prova PostgreSQL/produzione. |
| DM/I&C | Checkpoint 0.11.0-dev: preventivi e RC, incarichi DM fino a registrazione, schede/camere e selettore. Emissione DM non disponibile. Completamento maschere/azioni, tecnico, INAIL, fatturazione collegata DM e I&C ancora aperti. |
| Excel | Mappate 47 colonne attrezzature, 11 configurazione GVR, 12 accessori dei batch. Hook e date protette analizzati; nessun modello XLSX/importer realizzato o file cliente caricato. |
| Incrementale | La prova v0.2 ricrea la destinazione; l’importatore DPR 0.8 richiede archivio inizialmente vuoto. Nessuno è un motore incrementale. Il v0.3 ha registri, ma la base applicata per campo richiede estensione esplicita. |
| VerbalizzAI autonomo | Progetto/produzione separati. L’ultima versione consolidata e il suo archivio vanno acquisiti prima dell’adattatore; non aggiornare il VPS né assumere la versione del prototipo come versione in esercizio. |

## Riscontri correnti da non perdere

Il ricalcolo Garda usa le date scheda se manca una verifica effettuata; altrimenti prende ultima/prossima della verifica più recente per rilascio, componente per componente. Non ricalcola genericamente tutte le periodicità. CND/supplementari restano date di scheda. Un’ultima data da sola non crea la futura scadenza periodica. Accessori associati hanno regole differenti e aggiornano tutti i beni coinvolti. Gli hook aggiornano lavori aperti, non quelli effettuati mediante quelle selezioni.

La procedura camere cerca per sola matricola informale, mentre gli asset sono unici per sede+matricola: match multipli IMP-02 proposti da risolvere, senza consenso acquisito. Le chiavi camere descrizione/numero fabbrica e reset/integrazione restano distinte dall’identità dell’attrezzatura.

Non riaprire il falso problema della scelta del più vecchio per `gvr_tub_stato`: corretto e documentato nei rapporti 07/11, Garda sceglie il più recente fra integrità/interna e a parità mantiene integrità. Nessun difetto su quella base.

## Materiali ed evidenze per approfondire

Archivio sorgenti/database: `backup_gestionale.7z`. Materiali architetturali precedenti: `gestionale_poc_v0.2.zip`, schema/mapping/quadrature e prototipo `Gestionale_AD_v0.7.1.zip`. Non eseguire il vecchio migratore su una destinazione con lavoro da conservare.

Approfondimenti attuali: 21 struttura cliente/sede nelle offerte, proposta e import; 18 correzione R98 0.8.1/0.9.1; 19 maschere utente e riscontro/lacune adsrl; 20 cartelle Windows; 17 codice/prove 0.9.0; 16 perimetro/implementazione della versione integrata; 06 regole DM/INAIL e nomi allegati; 07 generatore DM (1.4); 11 percorso GVR; 12 percorso I&C–DM; 13 incrementale; 14 import massivo; 15 mapping Excel. Schema/dizionario/E-R: file 08–10 nel pacchetto v0.3. Modelli Word GVR/SC-SP ricevuti sono modelli, non esempi compilati che provino un percorso completo.

## Come aggiornare i documenti

R12 richiede aggiornamento a ogni passaggio significativo: quadro, approfondimenti pertinenti e questa scheda. Registrare decisione dell’utente, evidenza Garda, proposta, stato implementativo e controlli effettivamente svolti. Nessuna approvazione/test inventata. Prima di modificare leggere le versioni correnti; se un’altra istanza le ha aggiornate, integrare quel lavoro. Mantenere le identità dei documenti esistenti e non creare copie concorrenti del quadro.

Per avviare un’altra istanza si può indicare: **“Riprendi il progetto Gestionale integrato leggendo la versione attuale della scheda 00, del documento quadro 04 e dei rapporti indicati per il lavoro corrente. Continua una domanda alla volta e aggiorna i documenti.”** Se un materiale citato non è disponibile, dichiararlo: non ricostruire il sorgente da un riassunto.


## Nota tecnica per proseguire dal codice 0.9.1

Migrazione corrente 0011: nove nuove tabelle comuni e `impianti.asset_id`. I flussi DPR restano proprietari dei loro dati, proiettati automaticamente sul parco nello stesso commit ORM; API comuni DPR in sola lettura. È una duplicazione transitoria nel medesimo DB, da superare completando il raccordo, non due archivi né un comando manuale. Gli asset DM/PSV sono nativi comuni. `asset_origini` non equivale a un importer incrementale. Le date native sono dichiarate; non generano verifiche/report e non implementano ancora l'algoritmo completo di aggiornamento da lavori DM/I&C. Il target E-R v0.3 rimane distinto dallo schema applicativo effettivo.


Nota sulle schermate: tutte le 15 immagini ricevute sono state lette e hanno le rispettive identità persistenti. Il rapporto 19 elenca i nomi; gli screenshot non mostrano la configurazione GVR espansa, la linguetta Altro o tutti i menu. Proseguire dal sorgente senza chiedere di nuovo tutti i materiali. Esenzione No/Sì/ISO17020, vincoli matricola 4/1/5/2, codici derivati INAIL e protezione date con verifica collegata sono riscontri importanti. Questa lacuna dei campi matricola è ripristinata nel checkpoint 0.10.0-dev; le vecchie schede incomplete non vengono riempite artificialmente. Le altre lacune del rapporto 19 restano da completare.


## Nuovo riscontro sulle offerte (rapporto 21)

Cliente→sedi→beni conservato. DM Garda ha cliente+sede obbligatori in testata e filtra la riga sulla sede; DPR ha cliente senza sede di testata e impianti di sedi diverse nelle righe. Nel dump 168 preventivi DPR multisede. Proposta comune già compatibile con v0.3: cliente obbligatorio, sede di contesto pertinente, righe con bene/sede, fotografie e origini. Mantenere l’uso DM per sede; **nuovo DM multisede non approvato** e non deducibile dalla sola richiesta di database unico. Contatti email delle offerte DM vengono dalla sede, da conservare. Fattura al cliente/terzo nella fase fatturazione, mai equiparare sede a soggetto fiscale.

Le query osservano discrepanze: adsrl 4 offerte con più sedi effettive, 32 righe con sede attuale bene diversa dalla testata, 1 testata cliente/sede discordante; ingecert 5 righe con diverso cliente corrente. Cause non dimostrate. Import conservativo senza riscrivere anagrafiche, dividere/fondere offerte, inventare una sede unica DPR o ricostruire fotografie sconosciute. Il servizio commerciale DM è attuato nel checkpoint della sezione seguente; l’import storico conservativo resta da completare.


Dubbio successivo (rapporto 21 §7): l’utente teme la coerenza degli indirizzi e chiede cosa rischi mantenendo gli usi attuali. Raccomandato nucleo comune con DM per sede e DPR cliente multisede; differenza di filtro, non due database. Indirizzi da sede, fotografie emessi immutabili. Il limite DM per sede resta noto; multisede DM non approvato. Nessuna scelta definitiva inventata o importazione dichiarata già risolta.

## Coordinamento corrente — istanze parallele

Successivo «ok procediamo»: autorizzata la prosecuzione del raccordo conservando DM per sede e DPR multisede (quadro §73.2; rapporto 21 versione 1.1). L’utente chiede poi consigli per altre istanze/LLM. Leggere il **protocollo 22, versione 1.0**, con prompt e incarichi INT-01, DM-01, QA-01 e possibile INAIL-01. È una proposta organizzativa pronta da assegnare; nessun agente esterno o nuovo repository già avviato.

Baseline ancora **0.9.1**, migrazione **0011**, SHA256 ZIP `7d96ff6804ea98bc8ce5c7e74371cb7ce0d7f9d6ddb53e6ff160ca6981069339`. Nessun nuovo codice o collaudo eseguito nel passaggio di coordinamento. Si è riletta la base: schede DM incomplete; prossimo sviluppo campi/controlli Garda e raccordo preventivi/incarichi. Non presentare questa consegna documentale come rilascio funzionale R99.

Unico integratore raccomandato per schema, migrazioni, servizi condivisi e documenti ufficiali; altre istanze consegnano report/patch con base ed evidenze. Rami/cartelle e database di prova distinti. Kit di contesto disponibile con 00/04/16/19/21/22: non contiene codice, dump o immagini, da aggiungere secondo l’incarico. Altri LLM non hanno automaticamente accesso ai materiali citati. R73 e tutte le decisioni del quadro prevalgono sulle ricostruzioni autonome.


## Stato corrente — checkpoint 0.10.0-dev, rapporto 23

L’ultimo messaggio autorizza a proseguire qui e conferma **nessuna istanza parallela attiva**. Nessun agente/LLM avviato. Le sezioni precedenti sulla 0.9.1 descrivono la baseline, non il nuovo codice corrente.

Riprendere da `Gestionale_AD_0.10.0-dev_checkpoint_DPR_DM_2026-10-09.zip`, cartella `Gestionale_AD_integrato_sviluppo`. Migrazione **0012**, modello Word DM originale e 314 tariffe Garda con origine. File di stato `STATO_IMPLEMENTAZIONE_0.10.0-dev.md`; prove in `report_collaudo`. Il target E-R v0.3 resta distinto dall’applicativo. Non ricreare 0011/0012, non perdere il checkpoint ripartendo dalla 0.9.1.

Disponibili: schede tecniche a linguette e nuovi controlli; preventivi DM cliente+sede sulle tabelle comuni DPR, righe SC/SP/GVR, tariffazione/combinazioni/sconti, licenza opzionale, documenti/approvazione/invio, fotografie, risposta scritta e RC. **Incarichi DM soltanto da assegnare** dopo RC conforme, idempotenti. DPR cliente multisede e servizi precedenti preservati. DM multisede ordinario non approvato. Non chiamare completo il DM o soddisfatta R99.

Prove: 168 test passati nella suite completa finale (147 della base e 21 DM), Linux/Python 3.12.14/SQLite; 1 avviso della suite. Ruff E9/F sui file applicativi interessati e controllo sintattico JavaScript passati. Alembic non rileva differenze fra schema 0012 e modelli dichiarati.. DOM+HTTP GVR e creazione dell’offerta DM con attrezzatura/combinazione/tariffa riusciti. Word originale compilato e clausola licenza con/senza tabella prezzo verificata. Conversione PDF DM reale e grafica Windows non provate; i test ordinari simulano il convertitore. Migrazione 0011 popolata preserva campi/ID/riferimenti precedenti e FK, con evento e backup d’aggiornamento.

Proseguire con **flusso tecnico DM e aggiornamenti per componenti**, generatore GVR/SC-SP/schede, nomi N01–N14, fatturazione collegata e INAIL trimestrale. Completare riferimenti/azioni maschere, EX/tariffari/scadenze e caricamento quadrato dei dump; I&C resta nel perimetro successivo, Excel alla fine. R73 invariata: funzioni mancanti sono lavoro aperto, non omissioni autorizzate. COES-01 di produzione non blocca sviluppo su copie. S3 non richiesto; VerbalizzAI autonomo/VPS invariati.

Riscontro da conservare: Garda arrotonda la frazione percentuale a scala 2 con `gi_bcdiv`, poi il prezzo con `gi_bcmul`; 311,17 € e 12,5% → 270,72 €. Non “correggere” senza valutazione. Il preventivo emesso usa la fotografia e non i dati correnti modificati dopo. La creazione di incarichi non dimostra ancora esecuzione, verbali, scadenze operative o fatture DM.

Se si aprono istanze in futuro: aggiornare la base del protocollo 22 al checkpoint corrente; il kit originale conserva 0.9.1/quadro 1.91. Fornire effettivamente codice, fonti e documenti correnti alle istanze; oggi non esistono consegne parallele da integrare.


Identificazione del checkpoint salvato: `Gestionale_AD_0.10.0-dev_checkpoint_DPR_DM_2026-10-09.zip`, SHA256 `b1a84cf70387e6491db3b9299b17497a500644dfc03dbe283d90b857befb9b67`, 277 file, 1,914,979 byte. Hash del pacchetto esterno, da verificare prima di integrare contributi futuri.

## Ripresa aggiornata — 0.11.0-dev

## Ambienti operativi e indirizzi di accesso

Un backend e un database applicativo comuni, tre ambienti di navigazione: **AD_DPR**, **AD_DM** (GVR/SC/SP) e **I&C S.r.l.** Il selettore Attività mantiene le anagrafiche comuni, filtra il menu e non concede permessi. Le API continuano a controllare ruoli e titolarità dei lavori. La preferenza di navigazione non determina emittente, sezionale o contabilità.

Ingressi locali già disponibili: `/ad-dpr`, `/ad-dm`, `/iec`; selezionano direttamente l’ambiente, anche arrivando da un collegamento. Le pagine comuni conservano la scelta; le pagine operative DPR/DM la rendono coerente con il modulo aperto. I&C mostra una pagina esplicita di funzioni ancora da realizzare; non espone la fatturazione DPR come se fosse I&C. Nell’ambiente DM non viene presentata la fatturazione DPR come fatturazione DM.

**Chiarimento dell’utente:** nella versione definitiva vuole indirizzi distinti per i tre ambienti, o almeno un accesso AD_DPR/AD_DM e uno separato I&C. Questo è acquisito. Due o tre URL/nomi host sono configurazioni di ingresso della stessa applicazione, non tre gestionali da mantenere. La configurazione dei domini, del proxy e delle autorizzazioni per ambito in produzione è ancora da realizzare; gli ingressi locali non sono una prova di separazione dei domini o di isolamento dei dati. Il selettore è utile al collaudo e agli utenti autorizzati su più attività.

Sviluppo: una sola installazione/avvio, un archivio di prova, passaggio fra le attività senza riavviare. Collaudo e produzione usano archivi distinti. AD_DM e AD_DPR appartengono ad AD S.r.l.; I&C S.r.l. mantiene emittente/contabilità distinti. Nessuna fusione di preventivi o fatture DM/DPR introdotta da questa navigazione.

**Prove finali:** 189 test passati nella suite completa (168 della base, 16 nuovi tecnici DM e 5 ambienti), Linux/Python 3.12.14/SQLite, 1 avviso di deprecazione del test client. Controllati schema/migrazioni rispetto ai modelli, migrazione 0012 popolata, numerazione concorrente, backup/ripristino, autorizzazioni e atomicità delle modifiche. Due prove DOM+HTTP passate con JavaScript/backend effettivi: schede/date/PSV/preventivi DM e assegnazione/programmazione/scheda tecnica/registrazione. Controlli Ruff E9/F sui file modificati e sintassi dei cinque JavaScript interessati passati. La diagnostica più ampia conserva segnalazioni preesistenti di base/terzi; VerbalizzAI incorporato non modificato. Conversione PDF delle offerte simulata nei server di prova, Windows/produzione/PostgreSQL e LibreOffice DM reale non osservati.
