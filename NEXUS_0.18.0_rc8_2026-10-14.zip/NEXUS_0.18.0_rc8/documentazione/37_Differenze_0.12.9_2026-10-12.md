# 37 · Differenze della 0.12.9 rispetto alla 0.12.8

12/10/2026 · Redatto da Claude · Schema Alembic **0019**, invariato: nessuna migrazione.

Fonte: note di collaudo di Federico del 12/10/2026 mattina (documento di progetto 28) e riverifica del revisore della 0.12.8. Su richiesta di Federico («analizza se alcune di queste osservazioni … siano proprie anche della sezione AD_dpr. in tal caso uniformiamo le modifiche!!») ogni modifica dell'interfaccia vale per DPR e DM; il § 9 riassume l'analisi.

## 1. Il preventivo DM contiene solo le verifiche dell'allegato VII (R129)

> «il preventivo AD_dm che riguarda le verifiche allegato VII D.Lgs. 81/08 ha unicamente verifiche periodiche (e prime periodiche) di attrezzature di sollevamento, verifiche periodiche (e prime periodiche) di funzionamento, visita interna e integrità di attrezzature e insiemi GVR. […] Al momento mi interessa che il preventivo DM filtri SOLO le verifiche allegato VII D.Lgs. 81/08. Piuttosto metterei un filtro / comando "prepara preventivo EX", fermo restando che "prepara preventivo DM" può attingere solo da verifiche sc, sp, gvr, di attrezzature non esenti.»

Le due categorie:
- **DM all. VII:**
  - GVR con funzionamento, integrità o visita interna;
  - SC e SP con la verifica SC/SP;
  - in entrambi i casi solo attrezzature con «Esente verifiche» = No.
- **EX:** tutto il resto, cioè CND, indagini supplementari, efficienza (taratura) delle valvole, e ogni attività di attrezzature esenti o in regime volontario ISO 17020.

**In Scadenze (AD_DM):**
- colonna «Regime»;
- «Da preventivare DM», che vale Sì solo per le verifiche dell'allegato VII non già preventivate;
- filtri rapidi «Da preventivare DM» e **«Attività EX»**;
- **«Prepara preventivo DM…»** rifiuta le scadenze EX con un messaggio che le elenca, e distingue quelle già in un preventivo;
- **«Prepara preventivo EX…»** per ora spiega che i preventivi EX non esistono ancora (né in Garda né qui) e che verranno progettati sul modello di I&C.

La 0.12.8 chiamava queste attività «I&C»: era un errore. Lo stesso controllo vale sul server, cioè in `/api/dm/preventivi/da-scadenze` e nell'aggiunta manuale delle attrezzature.

## 2. Schede ridimensionabili (R130, DPR e DM)

> «scelto pannello a e b»

Vale per tutte le schede del programma: preventivo, incarico, verifica, cliente, sede, impianto, attrezzatura, fattura, utente.
- **Larghezza predefinita:** in proporzione alla finestra, circa il 70% e mai meno di 820 px. Allargando la finestra la scheda si allarga.
- **Maniglia sul bordo sinistro:** si trascina per allargare o stringere la scheda. Il doppio clic torna alla larghezza iniziale.
- **Pulsante ⤢ «A tutto schermo»:** con ⤡ si torna alla larghezza di prima.
- La larghezza scelta si ricorda in quel browser, per ogni pagina.

## 3. Affidamento dalla scheda del preventivo, come in Garda (DPR e DM)

> «nel riquadro "azioni" comparirebbe un'icona (ammette selezioni multiple su più righe) che fa aprire un popup per la selezione del verificatore affidatario. la selezione multipla è fondamentale!»

Nuovi elementi della linguetta «Righe» della scheda del preventivo:
- **colonna «Verifica affidata» (DPR) o «Incarico» (DM)** con stato e verificatore;
- **pulsante 👤 «Affida»** su ogni riga ancora aperta. Se la riga è fra quelle spuntate, l'affidamento vale per tutte le spuntate;
- **«👤 Affida le selezionate…»** fra i comandi delle righe;
- **«‹ Prec. preventivo» e «Succ. preventivo ›»** per passare al preventivo vicino nell'elenco, senza chiudere la scheda.

La finestra di scelta del verificatore è la stessa ovunque:
- righe della scheda;
- Preventivi › Righe dei preventivi;
- Verifiche DPR;
- Verifiche DM.

Tutte o nessuna: se una verifica non si può affidare, per esempio perché già eseguita, non cambia nulla e il messaggio lo dice.

## 4. Verifiche AD_DM sulla griglia standard

> «in verifiche non c'è la selezione multipla, che è importante»

La pagina Verifiche (AD_DM) usa ora la stessa griglia delle Verifiche DPR e delle Righe dei preventivi:
- casella **«seleziona tutte»**;
- filtri per colonna, colonne a scelta, Excel, righe per pagina;
- filtri rapidi: Da assegnare, Assegnate a me, Da registrare, Registrate, Da riesaminare, Da fatturare, Tutte;
- **«👤 Affida le selezionate…»** e **«Riesamina le selezionate…»**;
- ognuno vede solo i propri incarichi, se non ha il permesso di vederli tutti (come nel DPR).

La nuova griglia è `incarichi_dm` (`gestionale/moduli/dm/griglie.py`).

## 5. Dati del tecnico una volta per tutte; linguetta «Verbale»

> «in incarico richiede i dati del tecnico, in teoria non deve succedere, nel menu gestione lo si deve fare una volta per tutte»; «la "scheda tecnica" va chiamata verbale»

**Dati del tecnico.** Nome, cognome, qualifica e codice fiscale, stampati nei verbali, si inseriscono:
- nella scheda dell'utente, in Gestione › Utenti e permessi, riquadro «Dati del tecnico (verbali)»;
- oppure, per il proprio, in «Il mio profilo».

Nell'incarico DM si vedono soltanto. Se manca qualcosa, un avviso indica dove completarli.

**Nomi.** Nell'incarico DM la linguetta «Scheda tecnica» si chiama **«Verbale»**, e il pulsante diventa «Salva i dati del verbale». «Scheda tecnica» resta solo per il documento della prima verifica periodica.

## 6. Termini di esecuzione configurabili (DPR e DM)

**Dove si configura.** Gestione › Configurazione › **Termini di esecuzione**. Valori di partenza, aggiunti anche agli archivi esistenti al primo avvio:
- «30 gg. da conferma d'ordine»;
- «60 gg. da conferma d'ordine»;
- «Entro la scadenza della verifica»;
- «Da concordare con il cliente».

**Nel preventivo.** Il campo «Termine di esecuzione» propone l'elenco; il testo resta libero.

## 7. Residui della riverifica del revisore (AD-REV-002, AD-REV-005)

| Rilievo | Correzione | Prova |
|---|---|---|
| **AD-REV-002**, parità di data | Fra più impianti di VerbalizzAI collegati allo stesso impianto vale quello che contiene il verbale valido più recente, con **la stessa chiave completa di VerbalizzAI**: data, poi aggiornamento del verbale, poi id. Il numero dei verbali non conta più. Riquadro «Verbale precedente», bozza e scelta dell'impianto seguono un'unica regola | `test_ad_rev_002_parita_di_data_vale_l_aggiornamento`: tre verbali fino al 10/03/2026 contro uno dello stesso giorno aggiornato dopo. Vale il secondo, e la bozza usa lo stesso. Il test fallisce con il codice della 0.12.8 |
| **AD-REV-005**, eliminazioni implicite | Le provenienze si marcano con l'evento SQLAlchemy `persistent_to_deleted`, che vale per ogni oggetto davvero eliminato. Comprende gli **orfani** (righe tolte con «Togli selezionate») e le **cascate** (preventivo eliminato con le sue righe), che `before_flush` non vedeva | `test_ad_rev_005_righe_tolte_e_preventivo_eliminato`: riga tolta → solo la sua provenienza marcata; preventivo eliminato → tutte. Il test fallisce con il codice della 0.12.8 |

Il registro dei rilievi aggiornato è `documentazione/Registro_rilievi_Gestionale_AD_0.12.9.txt`.

## 8. Altre correzioni

- **Righe dei preventivi DM:** «Verifica» e «Attività GVR» mostrano le etichette, per esempio «Verifica periodica successiva» o «Funzionamento + interna», non più i codici.
- **Test di velocità del registro:** la soglia passa da 1,0 a 1,5 s. Su Windows si era misurato 1,05 s con il PC carico; il codice non è cambiato.

## 9. Analisi: quali osservazioni valgono anche per AD_DPR

| Osservazione | Vale per il DPR? | Fatto |
|---|---|---|
| Scheda stretta, non ridimensionabile | Sì: le schede sono le stesse | R130 su tutte le schede |
| Affidamento multiplo dalla scheda del preventivo | Sì | Righe del preventivo uguali per DPR e DM |
| Verifiche con selezione multipla | Il DPR aveva già la griglia con «seleziona tutte» | DM portato sulla stessa griglia; stessa finestra «Affida» |
| Riesame di più verifiche insieme | Nel DM sì; nel DPR no, perché il RT riesamina guardando il verbale | Invariato. Da decidere se serve nel DPR |
| Dati del tecnico | Nel DPR firma e qualifica sono gestite da VerbalizzAI (Firme dei verificatori) | Solo DM. Nel DPR non c'è il problema |
| «Scheda tecnica» → «Verbale» | No: nel DPR la scheda tecnica è dell'impianto (R122) | Solo DM |
| Termini di esecuzione | Sì | Elenco comune |
| Accettazione prima dell'invio | Già impedita in entrambi | — |
| Registrazione in blocco (punto 13) | Nel DPR la registrazione passa dal verbale di VerbalizzAI | Da decidere (0.12.10) |
| Ruoli per attività (punto 14) | Sì, riguarda entrambi | Da decidere (0.12.10) |

## 10. Prove

| Prova | Esito |
|---|---|
| `tests/test_scadenze_preventivo_dm.py` | regime «DM all. VII» o «EX»; CND rifiutata come EX; attrezzatura esente («Sì» e «ISO17020») → EX, rifiutata |
| `tests/test_righe_affida.py` (2 test nuovi) | griglia `incarichi_dm`: stato, gruppo, tipo, filtri; righe filtrate per preventivo; dati del tecnico letti e salvati dalla scheda utente; riquadro nel profilo |
| `tests/test_rilievi_revisore.py` (2 test nuovi) | AD-REV-002 parità di data; AD-REV-005 orfani e cascata |
| `tests/test_menu_attivita.py::test_termini_di_esecuzione_configurabili` | elenco, pagina, riquadro in Configurazione |
| Prova dell'interfaccia con Chromium (copia dell'ambiente di prova) | scheda larga 70% della finestra, trascinamento e «a tutto schermo»; righe DM e DPR con «Affida» e finestra del verificatore (rifiuto chiaro per un incarico già effettuato); Verifiche DM sulla griglia; incarico con «Verbale» e dati del tecnico in sola lettura; utente con «Dati del tecnico». Nessun errore JavaScript |
| Suite completa | **269 test passati** (Linux, Python 3.13), `report_collaudo/pytest_0.12.9.txt` |

## 11. Non fatto in questa versione (documento 28)

- **Licenze gestionale (R131)**: mancano la data di inizio e i giorni di anticipo dell'avviso.
- **Ruoli per attività (punto 14)** e **registrazione in blocco (punto 13)**: da decidere.
- **Verbali DM come in VerbalizzAI (punti 16–17)**, nella 0.13.0–0.13.1:
  - anteprima e impaginazione come VerbalizzAI;
  - doppio salvataggio nella cartella `GVR` o `SC_SP` / anno di emissione / sede;
  - nome «potabile» `GVR_0012-26 …`, con il numero su **quattro cifre**: in un anno si superano i 1000 verbali GVR.
