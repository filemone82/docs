# Gestionale integrato differenze e consegna

11 ottobre 2026. Destinatario Federico Amateis. Versione di lavoro 0.12.1-wip1, migrazione 0015.

Questo documento contiene soltanto ciò che cambia rispetto allo ZIP Gestionale_AD_0.12.0-dev_checkpoint_documenti_DM_2026-10-10.zip. Il documento quadro 1.95, la ripresa 1.10 e il rapporto 27 restano il riferimento per quanto già consegnato. Le funzioni descritte sotto sono distinte dai risultati dei test.

## Consegna del codice

Prima di questa consegna non è stato recuperato uno ZIP software successivo alla 0.12.0-dev. Gli avanzamenti ulteriori descritti in precedenza nella conversazione non costituiscono codice recuperato o collaudo verificabile. In particolare non sono disponibili un ciclo I&C completo né un import completo dei tre Garda prodotto dopo la 0.12.

La consegna attuale conserva il codice effettivamente presente dopo la ripresa, identificato adesso come 0.12.1-wip1. È un checkpoint in lavorazione: non soddisfa la richiesta di prodotto completo. Il file ZIP comprende sorgenti, versione applicativa, migrazione 0015, README_INSTALLAZIONE.md aggiornato, questo documento, elenco delle differenze per file e risultati dei controlli disponibili.

| Voce | Valore |
|---|---|
| Base confrontata | Gestionale_AD_0.12.0-dev_checkpoint_documenti_DM_2026-10-10.zip |
| Versione nel codice | 0.12.1-wip1 in gestionale/__init__.py |
| Schema nuovo | Alembic 0015, precedente 0014 |
| File applicativi | 7 aggiunti e 10 modificati, incluso il numero di versione |
| File di test | 2 modificati, nessun nuovo test dedicato DM finanza o INAIL |
| Consegna | Codice in lavorazione, con parti del backend ancora senza prove dedicate |

Non sono inclusi ambiente .venv, archivi operativi, dump Garda, credenziali o database usati nelle prove. Il confronto digitale completo è in documentazione/29_Differenze_file_0.12.1-wip1.json; indica anche le impronte dei file. I documenti e i risultati della 0.12 conservati nello ZIP hanno valore storico.

## Differenze funzionali presenti nel codice

### Collegamento delle prestazioni DM alle fatture

Il servizio finanziario accetta ambiti DPR, DM, EX e IEC e controlla la società emittente: AD per DPR, DM ed EX; IEC per IEC. La lista delle prestazioni fatturabili e la lista fatture possono essere filtrate per ambito. Per DM il controllo di fatturabilità ordinaria richiede incarico effettuato e riesame C; rimangono accettazione della riga e riesame conforme del preventivo. Il codice impedisce di collegare una prestazione a una fattura di un altro ambito e verifica il committente delle righe aggregate.

Per una fattura ordinaria DM una riga collegata occupa l'intera prestazione anche se l'importo è ritoccato manualmente. Il nuovo campo prestazione_intera serve a evitare che una differenza economica riapra automaticamente un residuo fatturabile. Descrizione e riferimenti fiscali includono attrezzatura, tipo di verifica, preventivo, ordine e incarico DM. La numerazione per DM, EX e IEC usa la sequenza comune di fatture e note di credito nello stesso ambito; il percorso DPR conserva la sua distinzione.

Sono modifiche del backend. Non esistono test dedicati nuovi che provino l'intero ciclo DM fino a emissione, note di credito, esiti e incasso. L'accettazione delle fatture libere EX e IEC non implementa i cicli commerciali e tecnici EX o I&C. Le pagine finanziarie continuano a usare DPR.

### Archivio dei PDF delle fatture

Sono aggiunti archiviazione del PDF generato, caricamento di un PDF esterno e download delle versioni archiviate. Il collegamento memorizza revisione del documento, revisione XML e impronta della fotografia della fattura. Il PDF corrente deve corrispondere a questi dati. Il download ordinario della fattura preferisce il PDF archiviato corrispondente; se manca mantiene il precedente percorso di rigenerazione.

Il caricamento usa il controllo PDF già presente nel modulo DM e archivia i byte ricevuti. L'archiviazione è prevista dopo emissione e richiede versione della fattura corrente. Queste API e la nuova tabella fatture_documenti sono presenti; non sono stati eseguiti test dedicati di caricamento, obsolescenza dopo correzione XML, concorrenza o confronto dei byte nel lotto INAIL.

### Preparazione e conservazione dei lotti INAIL

Sono aggiunti candidati, anteprima, creazione e download dei lotti, storico e reimpostazione motivata del flag di esportazione. Il tracciato JSON contiene le 62 colonne estratte dalla funzione Garda gi_verifiche_esporta_inail. Il codice prepara un Excel con due righe di intestazione, tre ZIP di verbali, schede tecniche e fatture, più un manifest, dentro un archivio complessivo. Le celle testuali sono scritte come testo e gli importi come valori numerici.

La preparazione richiede un incarico effettuato, verbale PDF definitivo, una sola fattura ordinaria DM collegata all'intera prestazione e PDF fiscale corrente archiviato. Per V1 richiede la scheda tecnica definitiva. Sono presenti controlli su campi obbligatori o condizionali, lunghezze, PDF e collisioni dei nomi; la creazione può scartare le righe in errore solo su scelta esplicita di usare quelle valide. I PDF vengono letti dall'archivio; il codice conserva il lotto prodotto e aggiorna il flag esportata_inail.

Il nuovo permesso dm.inail parte da responsabile tecnico e amministratore. Esportata significa archivio generato; non significa ricevuta del portale. Nessun lotto nuovo è stato collaudato fino al confronto con Garda o caricato sul portale INAIL. Mancano anche prove su aggregazione di più verifiche nella stessa fattura, riesportazione, dati storici, tariffe/contributi effettivi e validazione di richieste malformate. Il codice riporta alcuni valori legacy, compreso il codice fiscale dell'organismo; il loro utilizzo operativo non è validato da questa consegna.

### Indipendenza nel percorso tecnico DM

È rimosso il blocco di programmazione e registrazione DM quando indipendenza è falsa. Il campo rimane memorizzato. Il cambiamento corregge il controllo DPR ereditato che il rapporto della 0.12 segnalava come difformità rispetto ad adsrl. Il test tecnico aggiornato esercita programmazione e registrazione con indipendenza falsa, sospensione e ripresa nello stato registrata. Non è una nuova deroga richiesta all'utente.

### Riesame DM negativo e rientro a registrata

Un riesame negativo su un incarico effettuato riporta lo stato a registrata, conserva nota, storico e PDF già definitivo, reimposta esportata_inail a falso e richiama il ricalcolo delle scadenze tecniche. Alla successiva chiusura il codice azzera il riesame N per richiederne uno nuovo. La decisione è registrata qui come R108; nel ramo documentale di audit era stata impropriamente numerata R101.

Il test modificato prova ritorno a registrata, conservazione del definitivo e presenza di due riesami. Non prova ancora il ciclo completo di correzione, rigenerazione e nuovo riesame, né tutti gli effetti sulle date. Il ricalcolo CND conseguente al rientro non è stato implementato. Rimangono da verificare accesso del tecnico alla nota, date con e senza precedenti, fatture già emesse e nuova esportazione successiva a un lotto esistente. Il lotto storico non viene riscritto dal cambio di stato.

## Migrazione nuova

La revisione 0015_fatturazione_dm_e_lotti_inail.py aggiunge tre tabelle: fatture_documenti, dm_esportazioni_inail e dm_esportazioni_inail_righe. Aggiunge inoltre esportata_inail a dm_incarichi e prestazione_intera a fatture_righe, entrambe inizialmente false. Include indici e vincoli di collegamento e unicità.

Il downgrade contiene un blocco se esistono PDF fiscali, lotti INAIL o righe fatturate come prestazione intera. Questa protezione è codice presente; non è stata provata con i nuovi dati popolati. Per tornare indietro il README indica di usare programma e dati precedenti conservati, senza collegare la 0.12 a un database aggiornato.

## Controlli effettivamente eseguiti

| Controllo | Esito e limite |
|---|---|
| Regressione mirata dopo le modifiche: test_finanza.py, test_dm_tecnico.py, test_dm_documenti.py | 49 passati, 1 avviso, 76,19 secondi. Risultato osservato nella sessione; il log grezzo di questa invocazione non è stato conservato. Comprende i due test aggiornati, non un nuovo collaudo INAIL. |
| Suite completa del codice di lavoro: python -m pytest -q con rapporto JUnit | 215 passati, 1 avviso, 312,36 secondi. Log e XML pytest_0.12.1-wip1 in report_collaudo. Nessun nuovo test dedicato finanza DM/INAIL è stato aggiunto. |
| Prova diretta della migrazione 0014→0015 | Passata. Schema uguale ai modelli, zero errori di chiavi esterne; conservati 72 ID specifiche, 6 famiglie GVR, 31 tipi, 162 compatibilità e 314 tariffe. Archivio sintetico senza incarichi né righe fattura preesistenti. Log migrazione_0015_sintetica.txt e script di prova inclusi. |
| Ruff E9/F sui file applicativi nuovi o modificati e sulla 0015 | Passato dopo rimozione di tre import inutilizzati. Log ruff_0.12.1-wip1.txt. È un controllo statico, non una prova delle funzioni. |

I conteggi sono sottoinsiemi e riesecuzioni della stessa suite: non vanno sommati. Non sono stati aggiunti test dedicati delle nuove API finanziarie DM o INAIL. I due test modificati verificano le transizioni indicate sopra. Gli altri test finanziari restano principalmente quelli del percorso DPR; il loro superamento non attesta la parità DM.

Non sono state eseguite nuove prove DOM o interfaccia per le nuove parti, installazioni Windows, migrazioni PostgreSQL, import dei tre dump Garda, invii email reali o pubblicazioni. Non sono attestati un collaudo di produzione, la validità fiscale degli output nuovi o l'accettazione INAIL.

## Lavoro rimasto a metà dopo questo incremento

| Parte avviata | Cosa manca per considerarla terminata |
|---|---|
| Fatturazione DM | Test del ciclo completo, prezzi manuali e blocchi di doppio collegamento, aggregazioni, note di credito, esiti e incassi; interfaccia DM; confronto con Garda. |
| PDF delle fatture | Test di upload e generazione, versioni, correzione XML, concorrenza e confronto dei byte archiviati. |
| INAIL | Lotti sintetici e storici completi, riscontro delle 62 colonne e periodicità, nomi e allegati, tariffe/contributi, selezioni errate, riesportazioni e schermata operativa. |
| Riesame negativo DM | Correzione e nuova chiusura, nuovo riesame, visibilità nota al tecnico, ricalcolo CND, date senza precedenti e conseguenze fiscali/INAIL. |
| Migrazione 0015 | Prova specifica con incarichi e fatture già popolati a 0014 e blocco del downgrade con dati nuovi a 0015. |

I&C, migrazione completa e incrementale dei tre gestionali e dashboard non hanno un incremento applicativo recuperabile in questa consegna. Restano nel perimetro già documentato; non vengono presentati come nuove funzioni raggiunte. Nemmeno l'apertura alle fatture libere IEC o EX li rende completi.

## Decisioni successive al quadro 1 punto 95

Questa consegna estende il registro del pacchetto, che termina a R106, con R107 e R108. Sono numeri attribuiti in questo documento per evitare collisioni; non vengono presentati come numeri già consolidati nella conversazione precedente. Le citazioni seguenti derivano dal recupero dei messaggi, con date convertite in Europe/Rome.

### R107 Proseguire fino a un prodotto viable

Messaggio utente del 10 ottobre 2026, ore 08:46:21:

> ok ho visto cosa hai fatto, secondo me sarebbe opportuno tu iterassi fino al raggiungimento di un prodotto "viable" cosa dici?

L'indicazione autorizza la prosecuzione verso un prodotto utilizzabile. Non elimina funzioni o controlli già richiesti. Questo checkpoint non chiude quel traguardo.

### R108 Riesame negativo DM con ritorno a registrata

Domanda dell'assistente del 10 ottobre 2026, ore 21:58:09:

> anche in AD_DM, quando il responsabile tecnico dà esito negativo al riesame, la verifica deve tornare automaticamente a “registrata”?

Approvazione utente del 10 ottobre 2026, ore 21:58:40, mantenuta nella grafia recuperata:

> Si

Il quadro 1.95 incluso nella 0.12 usa già R101 per la fedeltà a Garda. Un documento separato aggiornato come 1.101 e R101_riesame_DM_approvato.md usano R101 per questa approvazione e si riferiscono ancora al codice 0.11/schema 0013. Si tratta di un conflitto tra i registri, non di una rinumerazione valida di R101–R106. In questo delta l'approvazione diventa R108. Nei nomi del test e nei commenti del codice può comparire ancora R101 come riferimento storico del ramo audit.

### Richiesta di ripresa per altre istanze con testo originale incompleto

È documentata una richiesta del 10 ottobre 2026 alle 22:18:21 di preparare a ogni avanzamento un documento senza perdita di informazioni, utilizzabile con sorgente e database da altre istanze LLM. Il documento 26 e il quadro separato la collegano al requisito R12. Il recupero non fornisce in modo affidabile il messaggio originale integrale: non riporto una parafrasi tra virgolette né attribuisco un nuovo numero R a un testo incompleto. Il documento 26 dichiara inoltre di non essere una trascrizione integrale della chat.

Non è stato recuperato un registro completo e coerente delle eventuali altre decisioni dopo R106. Questa consegna conserva solo le decisioni per cui è disponibile il testo indicato sopra, senza dedurre approvazioni dai messaggi dell'assistente o dalle scelte tecniche del codice.

### Istruzioni direttamente disponibili in questa conversazione

Le richieste attuali sono disponibili integralmente e fissano la forma della consegna. Non introducono una nuova deroga funzionale Garda.

> Continua questa attività

> scrivimi tutto quanto raggiunto sinora in un documento

L'ultima istruzione restringe quella richiesta ai soli delta. Testo esatto:

> Prima di chiudere questa conversazione mi servono tre cose, senza riassumere di nuovo ciò che è già nel pacchetto 0.12.0-dev (documento quadro 1.95, ripresa 1.10, rapporto 27):
>
> 1. Il pacchetto ZIP scaricabile dell’ultimo codice che hai prodotto dopo la 0.12.0-dev, con versione, migrazione e README. Se non esiste una consegna successiva alla 0.12, dimmelo chiaramente.
> 2. Un elenco delle sole differenze rispetto alla 0.12.0-dev: funzioni aggiunte o modificate, test effettivamente eseguiti con risultato, cosa è rimasto a metà.
> 3. Le decisioni nuove o modificate dopo il documento quadro 1.95 (registro R oltre R106), con il testo esatto della mia richiesta o approvazione.
>
> Non dichiarare implementato o collaudato ciò che non lo è.

## File del codice che cambiano

File aggiunti, tutti relativi alla radice del programma:

- gestionale/migrazioni/versions/0015_fatturazione_dm_e_lotti_inail.py
- gestionale/moduli/dm/inail.py
- gestionale/moduli/dm/inail_api.py
- gestionale/moduli/dm/inail_campi_garda.json
- gestionale/moduli/finanza/prestazioni.py
- gestionale/moduli/finanza/documenti.py
- gestionale/moduli/finanza/documenti_api.py

File applicativi modificati:

- gestionale/__init__.py
- gestionale/app.py
- gestionale/core/permessi.py
- gestionale/modelli.py
- gestionale/moduli/dm/documenti.py
- gestionale/moduli/dm/modelli.py
- gestionale/moduli/dm/tecnico.py
- gestionale/moduli/finanza/api.py
- gestionale/moduli/finanza/modelli.py
- gestionale/moduli/finanza/servizio.py

Test modificati: tests/test_dm_documenti.py e tests/test_dm_tecnico.py. README_INSTALLAZIONE.md è riscritto per la consegna in lavorazione. Sono aggiunti questo delta, il documento Word, il confronto per file e i rapporti attuali. VERSIONI.md conserva la cronologia precedente e riceve un avviso per il nuovo checkpoint; i vecchi documenti di stato non attestano le nuove parti.
