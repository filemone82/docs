# 39 · Differenze della 0.13.0 rispetto alla 0.12.10

12/10/2026 · Redatto da Claude · Schema Alembic **0020** (nuova migrazione, § 6).

Prima parte di **VerbalizzAI_DM** (R123, documento di progetto 24 § 5; documento 28, punto 18).

Federico, 12/10/2026, 09:18:

> «verbalizzAI non sarà un tool unico del dpr, dobbiamo implementarlo anche per il DM. n.b. garda di fatto lo contiene già (a modo suo), tramite popolamento dei campi verbali a partire dall'ultima verifica (funzionamento), inoltre i campi "breve descrizione" e la tabella con i dati delle camere anche è un attributo dell'attrezzatura quindi riproposto ad ogni verbale (funzionamento, visita interna, integrità). per sc/sp è più semplice, si ripropone di default il contenuto dell'ultimo verbale.»

Alle 10:25 Federico ha mandato sette verbali di riferimento (GVR di funzionamento, visita interna e PVP integrità; SC; SP). Indicazioni:

> «per le firme è diversa, diciamo che bisognerà modificare il tool firme in maniera tale che ogni utente abbia una firma dpr e una firma dm, il gestionale utilizza quella corretta. per la cartella di prova ok»

## 1. Dati del verbale come attributi dell'attrezzatura

Nella scheda di un'attrezzatura GVR o SC/SP c'è la nuova linguetta **«Dati del verbale»**. Raccoglie i dati che passano da un verbale al successivo, in gruppi:

| Gruppo | Campi | Si aggiorna con |
|---|---|---|
| Attrezzatura o insieme (GVR) | attrezzatura / insieme a pressione | qualsiasi verbale GVR, solo se la scelta è esplicita (come Garda) |
| Accessori e dispositivi | accessori di sicurezza, dispositivi di controllo e di regolazione, altri accessori, valvole di intercettazione | verbale con funzionamento |
| Acqua di alimento e conduttore | parametri dell'acqua, conduttore, abilitazione, rilascio | verbale con funzionamento, famiglia a2 |
| Stato di conservazione delle tubazioni | stato di conservazione | il più recente fra integrità e visita interna (a parità di data, l'integrità) |
| Osservazioni · funzionamento / integrità / visita interna | osservazioni | verbale con quella componente |
| Testi del verbale SC/SP | condizioni generali, organi principali, comportamento nelle prove, configurazione e dati tecnici, osservazioni | ogni verbale SC/SP |

**Provenienza.** Ogni gruppo dice da dove viene il suo valore: «Dal verbale V/GVR/… del …», oppure «Corretto a mano il … da …».

**Correzione a mano.** Il pulsante «Correggi» chiede i nuovi valori, una data di riferimento e una nota. La correzione:
- vale per i verbali successivi, finché un verbale con data più recente non la aggiorna;
- resta nello «Storico delle correzioni» e nel registro operazioni;
- arriva subito anche alle bozze aperte non ancora salvate.

La breve descrizione del funzionamento e le camere erano già attributi dell'attrezzatura (linguetta «Caratt. GVR»): si ripropongono in ogni verbale, come chiesto.

**Bozza del verbale.** Riparte da questi dati, solo nei gruppi pertinenti alle attività verificate. Senza correzioni a mano il risultato è identico alla regola di Garda `copia_dati_precedente_verifica`: i test di parità esistenti passano senza modifiche. La provenienza di ogni campo indica anche se arriva da una correzione.

## 2. Pes e Tes di confronto

Nel verbale GVR con funzionamento, accanto a Pes e Tes di ogni camera compaiono quelli del funzionamento precedente: «prec.: 7,5 bar · 170 °C», con numero e data del verbale. Il valore precedente serve solo da confronto e non si copia nel nuovo verbale.

## 3. Firma DPR e firma DM distinte

- **Firma DM** di ogni tecnico: si carica nella scheda dell'utente (Gestione › Utenti e permessi) o in «Il mio profilo», nel riquadro «Dati del tecnico». Si accettano PNG o JPG, minimo 50 × 20 pixel come la firma DPR di VerbalizzAI (consigliata una scansione di almeno 300 × 100); si può sostituire o togliere.
- **Firma DPR:** resta quella di VerbalizzAI (Configurazione › Firme dei verificatori).
- **Uso:** i verbali DM usano **solo la firma DM**; prima usavano la firma comune di VerbalizzAI. Senza firma DM, l'incarico mostra un avviso.
- **Prossimo passo:** il blocco dell'emissione senza firma arriva con il nuovo flusso di firma (0.13.1).

## 4. Copia nella cartella dei verbali DM

Nuova impostazione in `config.json`: **`cartella_verbali_dm`**.
- Vuota (predefinita): nessuna copia.
- Ora: cartella di prova sul PC di Federico.
- In produzione: una cartella del server.

All'emissione («effettuata»), il PDF del verbale e, per la prima periodica, la scheda tecnica si copiano due volte in `GVR` o `SC_SP` / anno di emissione / sede operativa:
- con il **nome INAIL**: «verbale <matricola><data prossima>.pdf»;
- con il **nome leggibile**, ricavato dai verbali di Federico:
  - `GVR_1234-2026 - ROSSI LAVORAZIONI S.r.l. - 2000_123456_VR - funzionamento.pdf`;
  - per SC/SP con descrizione e rif. interno;
  - «PVP» davanti all'attività per la prima periodica.

I caratteri non ammessi da Windows diventano «-».

Se la copia non riesce (cartella non raggiungibile), il verbale resta emesso e un avviso lo dice.

**Da confermare con Federico:** il formato del nome leggibile, proposto alle 10:30 secondo i suoi file.

## 5. Struttura dei verbali di riferimento (per la 0.13.1)

Dai sette verbali di Federico:
- **GVR:** un solo modello. Le sezioni 1 (configurazione, camere, breve descrizione, generatori), 2 (dispositivi di protezione), 3 (stato di conservazione: visita interna, integrità, tubazioni) e 4 (osservazioni) ci sono sempre. Le parti non pertinenti si chiudono con «///». Seguono esito, firme e le tre date prossime.
- **SC/SP:** punti 1–5, caselle della tipologia di attrezzatura, portata, esito, firme, data della prossima verifica.

I modelli M-DM-GVR e M-DM-SCSP della 0.13.1 manterranno esattamente questa struttura. Cambieranno impaginazione e firma, come in VerbalizzAI.

## 6. Migrazione 0020

Nuova tabella `dm_schede_verbale`, con le versioni dei gruppi:
- campi;
- origine (manuale o verbale);
- data di riferimento;
- nota;
- autore e data.

Le righe si aggiungono soltanto. Gli archivi esistenti non cambiano: finché non ci sono correzioni, i gruppi si ricavano dai verbali effettuati. Il ritorno alla 0019 toglie la tabella.

## 7. Prove

| Prova | Esito |
|---|---|
| `tests/test_scheda_verbale_dm.py` (nuovo, 4 test) | scheda dal verbale con provenienza; correzione a mano che passa alla bozza successiva e resta nello storico; verbale più recente che supera la correzione; gruppi e campi non validi rifiutati; Pes/Tes precedenti come confronto, non copiati; firma DM caricata, letta, rifiutata se non è un'immagine, tolta; nel Word DM la firma DM; copia nella cartella con nome INAIL e nome leggibile in `GVR/2026` |
| `tests/test_dm_documenti.py::test_firma_comune_pdf_e_backup_ripristino_dm` (aggiornato) | la firma DPR di VerbalizzAI non entra più nel verbale DM; la firma DM sì; backup e ripristino invariati |
| Parità con Garda (`test_precedenti_selettivi…`, `test_effettuata_retrodatata…`) | invariati e verdi |
| Prova dell'interfaccia con Chromium (copia dell'ambiente di prova migrata 0019 → 0020) | linguetta «Dati del verbale» con provenienza e «Correggi»; riquadro della firma DM nel profilo; nessun errore JavaScript |
| Suite completa | **276 test passati** (Linux, Python 3.13), `report_collaudo/pytest_0.13.0.txt` |

## 8. Prossimo passo: 0.13.1

- Modelli M-DM-GVR e M-DM-SCSP, con la struttura dei verbali di riferimento, da approvare in PDF con dati inventati.
- Anteprima «BOZZA» con lo spazio della firma riservato.
- Firma ed emissione solo con la firma DM e con lo stesso numero di pagine dell'anteprima.
- Riquadro firme intero in fondo alla pagina.
- «Aggiorna / Conserva i dati del verbale».
