# Modello dati: riesame e contratto preliminare

Inventario riproducibile in `evidenze/modello_dati_018.json`, generato da `strumenti/contratto_modello_dati.py`: 63 tabelle e 98 relazioni dichiarate. È il modello applicativo, non l'introspezione di un server PostgreSQL collaudato.

I tre dump Garda del 7 ottobre contengono 62/52/51 tabelle fisiche, tutte con PK, rispettivamente 28/23/23 indici UNIQUE, nessuna FK dichiarata. Gli hook PHP gestiscono ulteriori controlli. I 27 collegamenti logici selezionati non presentano orfani; la verifica non copre tutti i riferimenti o l'intero storico economico.

## Relazioni principali

```mermaid
flowchart TD
    Cliente --> Sede
    Cliente --> Preventivo
    Sede --> Bene
    Preventivo --> Riga
    Bene --> Riga
    Riga --> Lavoro
    Bene --> Lavoro
    Lavoro --> Documento
    Riga --> RigaFattura
    Fattura --> RigaFattura
```

Il diagramma riassume relazioni: Bene comprende impianti DPR e asset DM; Lavoro comprende verifiche DPR e incarichi DM. Le righe economiche possono essere senza bene e la riga di fattura può avere altre origini. Il diagramma non impone cardinalità nuove.

| Regola | Garanzia esistente | Verifica ancora necessaria |
|---|---|---|
| Identità cliente/sede/bene | PK e FK verso il record padre | Riconciliazione dei duplicati fra archivi e provenienza completa |
| Cliente e sede del preventivo | FK indipendenti | Coerenza reciproca ed eccezioni già approvate; non basta che entrambi esistano |
| Bene della riga | FK e CHECK per non indicare contemporaneamente impianto e asset | Righe a corpo ammesse e coerenza con attività/sede |
| Riga, bene e lavoro | FK e unicità parziale del lavoro attivo | Verifica/incarico riferiti al bene della riga; revoche/annullamenti/storico |
| Numerazioni | UNIQUE negli ambiti definiti e gate di scrittura | Prove native fra processi, contatori importati e serie per società/attività |
| Riesame indipendente | C28 nel backend sul verificatore ID | Identità stabile del riesaminatore nello storico, senza inventare persone mancanti |
| Documenti emessi | Fotografie e archivio; revisioni con identità e sostituzione | Immutabilità dello storico ed eventuali dati già salvati con vecchi difetti |
| Origini | Unicità sistema/tabella/id e gestione eliminazioni | Collegamenti polimorfi, fusioni e destino di ogni categoria importata |
| Importi | Centesimi interi a 64 bit | Riconciliazione di imponibile/IVA/crediti/incassi/residui sui tre archivi |

Il database protegge identità, riferimenti e invarianti esprimibili; il backend protegge permessi, transizioni e coerenze fra oggetti. L'interfaccia guida l'operatore. Non sono state introdotte FK composte o restrizioni operative nuove sulla base di supposizioni.

Non è una dichiarazione di copertura completa delle 151 regole storiche Garda. Il dizionario dei dati, le eccezioni dello storico e la riconciliazione completa restano parte del lavoro di migrazione. Nessun nuovo numero R assegnato.
