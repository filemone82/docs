# 41 · Differenze della 0.14.0 rispetto alla 0.13.1

12/10/2026 · Redatto da Claude · Schema Alembic **0022** (nuova migrazione, § 8).

Richiesta di Federico (12/10/2026, 13:29): «scrivessi il codice di nexus, per i ruoli per attività, fatture dpr complete e verbali dm finiti».

Le fatture DPR c'erano già dalla 0.7: TD01, TD02 e TD04, righe dai preventivi, XML validato, incassi ripartiti, nota di credito. Questa versione colma le differenze con Garda annotate nei documenti 14, 15 e 18 (FIN-04…06):
- dati del cedente;
- documenti collegati;
- modalità di pagamento con rate;
- nome del file per lo SdI;
- ricevute SdI;
- XML in blocco;
- scadenzario.

**Limite dichiarato.** Non ho XML veri di Garda né ricevute vere di Aruba (richiesti il 12/10, ancora da ricevere). Il riferimento è quindi lo schema ufficiale FatturaPA 1.2 e la struttura delle tabelle di Garda (documento 14). Prima della produzione va fatto il confronto con qualche fattura vera e una prova di caricamento su Aruba (§ 10).

## 1. Dati fiscali di AD completi (Garda «configurazioni»)

In **Fatture › Dati fiscali AD** ci sono ora anche:
- REA (ufficio e numero);
- capitale sociale;
- socio unico o più soci;
- stato di liquidazione;
- telefono, fax ed email.

Nell'XML del cedente compaiono i blocchi **IscrizioneREA** e **Contatti**. Il **riferimento amministrazione** del cliente (dato del cliente in Garda) va nel cedente, come richiede la FatturaPA.

## 2. Documento emesso in seguito a (Garda «documenti collegati»)

**Dove si inserisce:** «Dati documento» della bozza, una riga per documento.

**Tipi:**
- ordine d'acquisto;
- contratto;
- convenzione;
- ricezione;
- fattura collegata.

**Dati di ogni documento:**
- numero e data;
- **CIG**, **CUP** e commessa/convenzione.

**Nell'XML** ogni documento va nel suo blocco (DatiOrdineAcquisto, DatiContratto, DatiConvenzione, DatiRicezione, DatiFattureCollegate), nell'ordine dello schema.

**Compatibilità:**
- l'«ordine» semplice delle versioni precedenti resta valido e si mostra come ordine d'acquisto;
- la nota di credito porta sempre la fattura originaria come fattura collegata.

## 3. Modalità di pagamento con le regole di Garda (tipi_pagamento)

**Dove si configura:** Fatture › **Modalità di pagamento**. Per ogni modalità:
- **codice FatturaPA**, da MP01 a MP23;
- **rate**: giorni, percentuale del totale, «fine mese»;
- con fine mese, «**paga il giorno N del mese dopo**»;
- «**sposta le scadenze del 31/8 e del 31/12 al 10 del mese dopo**»;
- «**salda subito**»: il documento risulta incassato all'emissione (es. contanti, carta), con un incasso registrato;
- **predefinita**: una sola.

**Modalità della fattura:** si sceglie come in Garda:
1. quella del **preventivo**, se le righe vengono da un solo preventivo;
2. poi quella del **cliente**;
3. poi la **predefinita**.

Si può anche scegliere a mano nei «Dati documento». La scheda della bozza dice quale si userà e da dove viene.

**Scadenze:**
- all'emissione, se non sono state scritte a mano, si calcolano dalla modalità;
- nella bozza c'è «**Calcola dalla modalità di pagamento**»;
- prima della 0.14 c'era sempre una sola scadenza alla data del documento: senza modalità resta così.

**Modalità esistenti:**
- **nate prima della 0.14:** le regole si ricavano dal nome (es. «Bonifico 60 gg F.M.» → MP05, 60 giorni, fine mese; «Ri.Ba.» → MP12) finché non si salvano. Vanno **controllate una volta**;
- **importate da Garda:** l'importazione (ingecert) porta codice, rate, fine mese, spostamento, «salda subito» e predefinita (`tipi_pagamento_scadenze`).

## 4. Nome del file per lo SdI

**Prima:** il nome era `IT<partita IVA>_<id><tentativo>`, che dalla fattura n. 4096 superava i 5 caratteri di progressivo ammessi dallo SdI. Il file sarebbe stato scartato.

**Ora:**
- ogni tentativo XML ha un nome unico `IT<trasmittente>_<progressivo di 5 caratteri>.xml`;
- il progressivo, uguale al **ProgressivoInvio** dell'XML, basta per 60 milioni di invii;
- il nome si vede nella scheda della fattura e si usa per scaricare.

Le esportazioni già fatte conservano il nome di allora.

## 5. Ricevute dello SdI da file (esiti Aruba)

In Fatture c'è il pulsante «**⬆ Carica ricevute SdI…**» (permesso «Registrare esiti XML»). Si scelgono uno o più file XML, oppure uno ZIP, scaricati da Aruba. Ogni ricevuta si collega alla sua fattura tramite il nome del file inviato:

| Ricevuta | Effetto |
|---|---|
| Ricevuta di consegna (RC) | consegnata |
| Notifica di scarto (NS) | scartata, con codici e descrizioni degli errori; poi «Correggi scarto» come prima |
| Mancata consegna (MC) | mancata consegna (la fattura è comunque emessa: è nel cassetto fiscale del cliente) |
| Attestazione di trasmissione (AT) | mancata consegna (PA non raggiungibile) |
| Esito della PA (NE, EC01 / EC02) | accettata / rifiutata, con la motivazione |
| Decorrenza termini (DT) | accettata dalla PA per decorrenza dei termini |

Il caricamento si comporta così:
- **stessa ricevuta due volte:** non cambia nulla;
- **file non pertinente** (ricevuta di un'altra fattura, file che non è una ricevuta, esito incoerente come una consegna dopo uno scarto): non si registra, e la tabella finale dice il motivo;
- **un file sbagliato non blocca gli altri.**

La registrazione a mano dell'esito resta disponibile.

## 6. XML delle fatture in blocco

Nella griglia delle fatture si spuntano le righe e si preme «**⬇ XML delle selezionate (ZIP)**». Lo ZIP contiene l'ultimo XML di ogni fattura emessa, con il nome SdI, pronto da caricare su Aruba. Le bozze spuntate non entrano e sono elencate in un `LEGGIMI.txt`. Corrisponde al «genera XML» in blocco di Garda.

## 7. Scadenze di pagamento e avvisi

**Scadenze di pagamento** (menu Fatture, AD_DPR e AD_DM; equivale ai «pagamenti» di Garda):
- una riga per rata delle fatture emesse;
- per ogni rata: scadenza, importo, modalità, fattura, cliente, residuo della fattura e stato «Scaduta», «Da incassare» o «Saldata»;
- gli incassi coprono le rate in ordine di scadenza;
- filtri rapidi; il clic apre la fattura.

**Avvisi nella bozza** (non bloccano l'emissione):
- righe senza IVA (nature N1–N4) oltre 77,47 € senza bollo: va valutato il bollo virtuale di 2,00 €;
- fattura a una pubblica amministrazione senza ordine, contratto o CIG.

## 8. Migrazione 0022

Nuove colonne, nessun dato esistente cambia:
- `elenchi_valori.regole_json`: regole delle modalità di pagamento;
- `fatture_esportazioni.nome_file`: nome SdI, con indice.

## 9. Prove

| Prova | Esito |
|---|---|
| `tests/test_fatture_complete.py` (nuovo, 8 test) | REA, capitale, socio unico, contatti nell'XML valido; ordine e contratto con CIG, CUP e commessa nell'ordine dello schema; documenti non validi rifiutati; nome SdI con progressivo di 5 caratteri uguale al ProgressivoInvio; regole di pagamento (rate, fine mese, giorno del mese dopo, spostamento 31/8 e 31/12, proposta dal nome, controlli); scadenze dal cliente, dalla predefinita e da «Calcola»; una sola predefinita; «salda subito» con incasso; ricevute RC, NS (in ZIP, con errori), file sconosciuti, esito incoerente, file non ricevuta, idempotenza; NE EC02 con motivazione; XML in blocco con LEGGIMI; scadenzario con rata saldata e da incassare; avviso del bollo |
| Test esistenti delle fatture | invariati: senza modalità, una scadenza alla data del documento come prima |
| Prova dell'interfaccia con Chromium (copia dell'ambiente di prova migrata 0021 → 0022) | Fatture con «XML delle selezionate» e «Carica ricevute SdI…»; Modalità di pagamento e scheda delle regole; bozza con «Documento emesso in seguito a»; Scadenze di pagamento; nessun errore JavaScript |
| Suite completa | **292 test passati** (Linux, Python 3.13), `report_collaudo/pytest_0.14.0.txt` |

## 10. Da fare prima della produzione delle fatture

1. **Confronto con Garda:**
   - 3–5 XML veri di Garda: TD01 con ordine e CIG, TD04, PA con split payment, cliente esente con bollo;
   - le ricevute SdI corrispondenti.

   Generati gli stessi documenti in NEXUS, confronto blocco per blocco.
2. **Prova su Aruba:** caricamento di un XML di NEXUS in ambiente di prova (o una prima fattura vera seguita a mano), lettura della ricevuta.
3. **Controllo delle modalità di pagamento** importate o ricavate dal nome.
4. **Numerazione di partenza:** l'importazione da ingecert prosegue dall'ultimo numero di Garda (D76). Va verificata con il dump del giorno del passaggio.
5. **Storico economico di ingecert** (fatture e incassi passati): importazione completa nella 0.16, come da documento 18.
