# 34 · Differenze della 0.12.6 rispetto alla 0.12.5

11/10/2026 · Redatto da Claude · Schema Alembic **0018** (nuova). Fonti: appunti di Federico del pomeriggio (15:07–15:54) e osservazioni del revisore indipendente sulla 0.12.5.

## 1. Indipendenza del verificatore (R119)

Decisione di Federico, 15:54: «è il verificatore assegnatario (idem se responsabile tecnico assegnatario) che la deve dichiarare, di default lascio sì, se no torna a RT per riassegnazione».

- **Chi la dichiara.** Solo l'utente a cui è affidata la verifica (DPR) o l'incarico (DM). Se l'assegnatario è il responsabile tecnico, la dichiara lui. Nessun altro può dichiarare al posto suo: il server risponde «non permesso».
- **Valore predefinito.** «Sì». Il verificatore vede la casella «Dichiaro la mia indipendenza per questa verifica» già spuntata. Gli altri utenti la vedono in sola lettura.
- **Con «No».** Il programma chiede conferma, poi la verifica torna «Da assegnare»: senza verificatore, senza data prevista e, nel DM, senza la bozza del tecnico. Il responsabile tecnico la trova nella coda «Da assegnare» con la nota in rosso «X ha dichiarato di NON essere indipendente il …: da riassegnare». La dichiarazione resta nel registro.
- **Quando si dichiara.** Fino alla registrazione: la verifica deve essere «assegnata» o «programmata». Dopo la registrazione il numero del verbale è già assegnato e la dichiarazione non si cambia più. Se emerge un conflitto, il responsabile tecnico riassegna la verifica; il numero del verbale resta lo stesso.
- **Restano i blocchi di R110**: senza indipendenza non si programma, non si registra e non si esegue.
- **Dati.** Nuova colonna `indipendenza_esclusa` in `verifiche` e `dm_incarichi`.

## 2. Ruoli e permessi (R121)

Decisione di Federico, 15:54: «i permessi e gli utenti sono fondamentali. meglio se personalizzabili e non fissi. di base ci sarà amministratore …, responsabile tecnico …, verificatore …».

È già così dalla 0.1:
- da Gestione › Ruoli e permessi si creano ruoli nuovi, anche copiando i permessi di un ruolo esistente;
- a ogni ruolo si assegnano i 53 permessi uno per uno;
- il server li controlla a ogni operazione.

I ruoli di base sono:

| Ruolo | Cosa fa |
|---|---|
| **Amministratore** | Tutto |
| **Responsabile tecnico** | Affida gli incarichi, esegue verifiche, riesamina contratti e verbali |
| **Verificatore** | Esegue le verifiche assegnate a lui |

In un archivio nuovo il ruolo «Tecnico» si chiama ora «Verificatore». Negli archivi esistenti i nomi restano quelli scelti e si cambiano da Ruoli e permessi. La «Segreteria» resta un ruolo predefinito facoltativo (preventivi, fatture). La categoria di permessi «Parco comune» ora si chiama «Attrezzature (AD_DM)».

**Ancora da fare:**
- i **permessi per attività** (chi lavora in AD_DPR, AD_DM, I&C);
- la **visibilità del commerciale** limitata ai propri clienti (Garda `show_clienti_propri`);
- le **due schermate «Verifiche»**, una per amministrazione e responsabile tecnico e una per il verificatore, in DPR e DM: si preparano prima i mockup.

## 3. Affidamento dalle righe dei preventivi

Richiesta di Federico, 15:07: «come in Garda».

- **Righe dei preventivi (DPR).** Nuove colonne «Stato verifica» e «Verificatore», e il filtro «Da affidare». Si spuntano le righe e si preme «Affida le selezionate…». L'operazione è «tutte o nessuna».
- **Righe dei preventivi DM.** È un elenco nuovo, nel menu Preventivi di AD_DM, con attrezzatura, attività GVR, stato dell'incarico e tecnico, e lo stesso comando.
- **Righe senza verifica.** La verifica nasce dal riesame del contratto conforme (D17, ISO/IEC 17020): una riga accettata ma non ancora riesaminata non si affida, e il messaggio lo spiega.

## 4. Verbale precedente e data di emissione

Simulazione di Federico con un cliente DPR, 15:11.

**Causa.** Il Word importato dalla pagina «Verbali» finiva su un impianto di VerbalizzAI separato, non collegato a quello del gestionale. In più, una bozza già aperta non si ricalcolava. Nel VerbalizzAI da solo l'impianto è uno solo, per questo funzionava.

**Rimedio.** Nella verifica c'è ora il riquadro «Verbale precedente»:
- dice da quale verbale partirà la bozza, o che partirà vuota;
- permette di caricare lì il Word dell'ultimo verbale, che va sull'impianto giusto;
- se quel Word era già stato importato dalla pagina «Verbali», collega quell'impianto (con il suo storico) invece di importarlo due volte;
- se la bozza era già aperta, la rifà, dopo aver chiesto conferma.

**Scheda dell'impianto del gestionale.** Si aggiorna anche lei: date, periodicità, potenza, caratteristiche ed elementi. Vale lo stesso criterio del verbale caricato sulla verifica: mai all'indietro.

**Data di emissione.** Nella bozza è ora uguale alla data del verbale e la segue finché non si cambia a mano, come in VerbalizzAI. Le bozze già aperte si sistemano alla riapertura.

**LibreOffice.** L'anteprima PDF dei verbali usa il percorso «libreoffice» di `config.json`, come i preventivi. Prima lo cercava solo nelle cartelle standard.

VerbalizzAI 1.0.1 rc2 non è stato modificato: lo controlla il test di identità.

**Ancora aperto.** L'errore «Il server di VerbalizzAI non risponde» sull'anteprima non si riproduce qui: l'anteprima risponde in 7 secondi. Per capirne la causa servono il file `gestionale.log` e la finestra del programma.

## 5. Osservazioni del revisore sulla 0.12.5

| Rilievo | Esito nella 0.12.6 |
|---|---|
| Schede Cliente e Sede orientate al DPR | Nell'attività AD_DM: conteggi delle attrezzature, linguetta «Attrezzature» nella sede, collegamenti ad attrezzature, valvole, **Scadenze AD_DM** (ora un elenco completo, una riga per attività), preventivi DM, righe e verifiche DM. Si resta nelle pagine DM. Nell'attività AD_DPR le schede restano come prima. |
| Bug in «Possibili doppioni» di sede | Dopo ogni unione o esclusione l'elenco si rilegge dal server. |
| Fusione dei clienti | Il cliente di adsrl si fonde solo se un solo cliente ha la stessa partita IVA o lo stesso codice fiscale **e** gli altri numeri presenti coincidono. Negli altri casi entra come nuovo, con l'avviso, e la coppia compare in **Clienti › Possibili doppioni**, da unire o da dichiarare diversa. L'unione di due clienti sposta sedi, preventivi e incassi; rifiuta i casi con fatture sul cliente che verrebbe eliminato. |
| Riferimenti alle origini | Nuova tabella **`origini`** (R120): sistema, tabella e id di Garda → cliente, sede, impianto, preventivo, riga o verifica. Le importazioni ingecert e adsrl la riempiono. Le unioni di sedi e clienti la aggiornano. La migrazione 0018 la ricava negli archivi esistenti dal «Rif. gestionale attuale» e dalle note dei clienti fusi. Nelle schede compare come «Provenienza». Le attrezzature e gli accessori restano nella loro tabella `asset_origini`. |

**Sul dump reale** (ingecert e adsrl del 07/10):

| Voce | Numero |
|---|---|
| Clienti fusi (corrispondenza certa) | 164 |
| Clienti non fusi, da confermare | 12 |
| Clienti nuovi | 612 |
| Sedi unite automaticamente | 66 (le sedi dei 12 clienti non fusi restano separate) |
| Corrispondenze registrate | 11.591 da ingecert, 1.856 da adsrl |
| Coppie in «Clienti › Possibili doppioni» | 124 (comprese quelle già presenti dentro ingecert) |

Quadrature: sedi attese 3.688 = presenti 3.688; 12.657 beni su 12.657 nella sede giusta; collegamenti 3.399 su 3.399.

Per preventivi, righe e verifiche degli archivi già importati l'id di Garda non era stato conservato: le corrispondenze si hanno ripetendo l'importazione con la 0.12.6.

## Test nuovi o aggiornati

| File | Cosa controlla |
|---|---|
| `tests/test_righe_affida.py` | Affidamento dalle righe, DPR e DM |
| `tests/test_verbale_precedente.py` | Word caricato dalla verifica; Word già importato dalla pagina «Verbali»; data di emissione; LibreOffice di `config.json`; scheda dell'impianto |
| `tests/test_clienti_origini.py` | Corrispondenze registrate dalle due importazioni; fusione solo se certa; unione dei clienti con spostamento delle corrispondenze; recupero nella migrazione 0018; scadenze DM e schede nel contesto DM |
| `tests/test_dm_tecnico.py`, `tests/test_finanza.py` | Aggiornati alla regola R119 |

## Prove

| Prova | Esito |
|---|---|
| Suite completa, Linux, Python 3.13.16 | **246 passati** (`report_collaudo/pytest_0.12.6.txt`) |
| Interfaccia (Chromium, ambiente di prova) | Cliente e sede in AD_DM, Scadenze AD_DM, doppioni dei clienti, righe da affidare, verbale precedente: nessun errore JavaScript |
| Verbale precedente con LibreOffice reale | Anteprima PDF in 7 secondi |

## Da decidere

- **Una sola fonte per i dati tecnici dell'impianto.** Proposta: fa fede la scheda di VerbalizzAI, che è la base del verbale successivo, e il gestionale la riprende a ogni emissione o conferma dello stato.
- **Mockup** delle due schermate «Verifiche», una per amministrazione e responsabile tecnico e una per il verificatore.
