# AD_DM — confronto fra maschere Garda e primo nucleo 0.9

Versione 1.3 — 9 ottobre 2026. Documento di riscontro e completamento, collegato a R73/R97. Le schermate ricevute sono fonti operative; il sorgente e il database `adsrl` restano il riferimento funzionale principale.

**Stato corrente:** la sezione 9 descrive il blocco tecnico e gli ambienti 0.11.0-dev; sezione 8 conserva la 0.10. I riscontri delle lacune precedenti restano storici, non descrivono tutti i campi attuali.

## 1. Indicazione dell’utente e stato reale

L’utente giudica poco sensata la 0.9.0 dal punto di vista del frontend e sottolinea che dalla sua interfaccia non può valutare se il backend sia completo. Ribadisce che le logiche e la struttura di AD_DM Garda sono corrette e costituiscono il riferimento principale.

Il riscontro è fondato: la 0.9 è un primo nucleo comune e non una versione AD_DM completa. Nel backend esistono identità iniziali, cataloghi, camere semplificate, associazioni PSV e date dichiarate. Mancano ancora campi/regole e collegamenti operativi, tariffazione e flussi DM, documenti e INAIL. I test del nucleo non certificano la copertura di queste funzioni assenti.

Non si propone di sostituire le maschere operative con una lista generica di beni come soluzione definitiva. Il prossimo incremento deve completare il contenuto delle schede e restituire gruppi di campi e collegamenti riconoscibili, verificandone la semantica Garda. Non si aggiunge un nuovo flusso solo per adattarsi al prototipo.

## 2. Materiali effettivamente osservati

Sono state aperte e lette tutte le 15 immagini. I primi tentativi di visualizzazione segnalavano file non disponibili; i file sono poi risultati accessibili e sono stati recuperati e letti. Le immagini originali non sono modificate.

| Immagini | Contenuto osservabile |
|---|---|
| `image.png` | Menu Clienti: clienti, sedi operative, tipi pagamento, aliquote IVA; porzione della navigazione generale. Non rappresenta tutti i menu del programma. |
| `image(1).png` | Menu Attrezzature: attrezzature, valvole di sicurezza, tipi attrezzature, tipi attrezzature GVR, ID specifiche, associazioni tipo/ID e tariffari SC/SP e GVR. |
| `image(2).png`–`image(4).png` | Identificazione GVR, parte iniziale e prosecuzione. |
| `image(5).png` | Classificazione INAIL GVR. |
| `image(6).png`–`image(7).png` | Caratteristiche GVR, pulsante della configurazione e descrizione processo. La configurazione ripetibile non è espansa. |
| `image(8).png` | Verifiche GVR: ultimi collegamenti e date per componente, CND. |
| `image(9).png`, `image(10).png`, `image(20261009-112102).png` | Identificazione SC/SP, su un caso SC, nelle diverse porzioni verticali. |
| `image(20261009-112110).png` | Classificazione INAIL SC/SP. |
| `image(20261009-112115).png` | Caratteristiche SC/SP. |
| `image(20261009-112121).png` | Verifiche SC/SP e indagine supplementare. |

Sorgenti riletti: `adsrl/codice/files/public_html/cust/meta/attrezzature.js`, `cust/_custom.php` (salvataggio e ricalcolo attrezzatura), `cust/lavori_batch_cli.php` (tracciato e import). Codice corrente confrontato: `gestionale/moduli/beni/{modelli,servizio}.py`, `gestionale/static/js/beni.js`. Il rapporto 07 e le sezioni 37–43 del quadro contengono l’analisi precedente da conservare.

## 3. Struttura della scheda da recuperare

Garda rende visibili cinque linguette pertinenti al gruppo scelto:

| Gruppo di informazioni | GVR | SC/SP |
|---|---|---|
| Identificazione | Identità, sede/cliente, matricola, esenzione, stato e dati del costruttore. | Stesso gruppo comune, con i campi pertinenti. |
| Classificazione INAIL | Tipo all.7, famiglia GVR, ID specifica, codici derivati e tipo descrittivo del verbale. | Tipo all.7, ID specifica, codici derivati e tipo descrittivo del verbale. |
| Caratteristiche | PS, volume, TS, superficie/produzione, messa in servizio, fluido/PED, insieme/pacco, configurazione e processo. | Portata e panieri idroestrattori. |
| Verifiche | Funzionamento, integrità, interna, CND; ultimi riferimenti distinti dalle date. | Verifica SC/SP e indagine supplementare; ultimo riferimento distinto dalle date. |
| Altro | Linguetta presente ma contenuto non mostrato negli screenshot; sorgente include dati di aggiornamento e campi PSV non visibili in form. | Stesso limite della documentazione visiva. |

Il raggruppamento non obbliga a riprodurre colori o grafica datata. Obbliga a mantenere accessibili i dati che l’operatore usa insieme, i riferimenti navigabili e gli effetti corretti del salvataggio. Nessuna nuova architettura è approvata tramite le immagini.

## 4. Identificazione — inventario e lacune

| Campi Garda | Riscontro della base 0.9 | Completamento necessario |
|---|---|---|
| `id` (Codice) | ID del bene e origine separata disponibili. | Nell’import conservare e rendere riconoscibile il codice originario; non fingere che ID canonico e codice Garda coincidano sempre. |
| `sede_operativa`, cliente derivato e `inattiva` | FK sede e cliente derivato presenti. | Ricerca/apertura della sede e del cliente, stato sede visibile nella scheda; non far digitare due volte il cliente. |
| `utente_cliente`, `referente_commerciale` | Non raccordati nella scheda bene. | Preservare semantica, origine e autorizzazioni; non confonderli con tecnico verificatore o collaboratore I&C. |
| `anno_matricola`, `cod_att_matricola`, `num_matricola`, `prov_immatr` | Quattro campi presenti, ma vincoli solo parziali. | Garda richiede 4 cifre, 1 carattere alfanumerico, 5 cifre e 2 lettere. La base ammette lunghezze più ampie per codice/numero: lacuna da correggere, non deroga approvata. Zeri iniziali preservati. |
| `matr_informale` | Presente e unicità sede+matricola. | Preservare forma originale e uso nei documenti; non confondere con la matricola strutturata dell’insieme. |
| `num_fabbrica` | Presente. | Conservare il warning di dato mancante Garda e i limiti/casi di import, senza alterare fotografie emesse. |
| `esente_verifiche` | Non implementato come campo/controllo dedicato. | **Non è un semplice sì/no:** metadati Garda prevedono No, Sì e ISO17020. Portare valori e loro effetti prima di dichiarare il campo equivalente. |
| `dismessa`, `gruppo_attr` | Gruppo e dismissione disponibili. | Conservare effetti su selezioni/scadenze e compatibilità dei campi; dismissione non equivale a cancellazione. |
| `tipo_prox_verifica` | Non raccordato ai flussi DM. | Prima/successiva secondo Garda; campo protetto quando esiste una verifica collegata pertinente. |
| `rag_soc_costr`, `cf_costr`, `modello`, `anno_costr` | Costruttore, modello e anno presenti; CF costruttore non dedicato. | Completare tutti i campi e validazioni pertinenti. |
| `descr_attr`, `reparto`, `rif_interno`, `marcatura_ce`, `note_attr` | Denominazione e note generiche non rappresentano separatamente tutto l’inventario. | Ripristinare i campi distinti e il loro impiego nei verbali/import; non fonderli in un unico testo senza valutazione. |

In Garda alcune informazioni della scheda sono lette dalle viste anziché essere colonne modificabili. Il confronto non deve trasformare ciascuna etichetta in una nuova colonna o consentirne la modifica diretta indiscriminata.

## 5. Classificazione INAIL

| Funzione Garda | Stato e criterio |
|---|---|
| Scelta manuale `tipo_attr` | Catalogo all.7 presente. Il completamento conserva la registrazione manuale/importata, non introduce un classificatore automatico obbligatorio. |
| Famiglia `tipo_attr_gvr` | Catalogo presente. Nei metadati Garda il tipo trascina famiglia e codici derivati: preservare la dipendenza e i campi in sola lettura dove previsti. |
| `id_spec` | Catalogo e compatibilità presenti. Garda filtra per tipo SC/SP oppure famiglia GVR; controllare anche il backend. |
| `tipo_attr_inail`, `tipo_attr_gvr_inail`, `id_spec_inail` | Codici ricavabili dai cataloghi, non esposti come gruppo operativo equivalente nella scheda attuale. Renderli leggibili senza chiedere di ricopiarli. |
| `tipo_attr_verbale` | Non sostituibile con il codice INAIL. È un campo descrittivo usato nel verbale; da completare. |
| `alert_tipo_attr` | Semaforo non visibile nel form, presente nei metadati. Conservare l’avviso secondo le regole già analizzate. L’immagine non dimostra da sola quando scatti. |

Resta R74: per SC il superamento dei dieci anni può comportare la modifica manuale della categoria all.7; non rinominare questo dato come ID specifica. La classificazione INAIL legge gli attributi dell’attrezzatura, mentre i verbali già emessi mantengono il proprio contenuto storico.

## 6. Caratteristiche GVR e configurazioni

| Campi/funzioni | Stato e lavoro necessario |
|---|---|
| `ps_attr_gvr`, `volume_attr_gvr`, `ts_attr_gvr`, `sup_risc_attr_gvr`, `prod_attr_gvr` | Non hanno ancora tutti controlli/form dedicati nel nucleo. Il contenitore JSON tecnico non ne implementa regole, etichette e impiego nei generatori. |
| `sogg_messa_servizio_gvr` | Campo nativo presente; da raccordare a tariffazione e verifica prima art.4/art.5 secondo le regole già analizzate. |
| `gruppo_fluido`, `cat_ped` | Da completare nei controlli e form: valori Garda 1/2 per fluido e I/II/III/IV per PED. |
| `matr_insieme` | Campo/regex dedicati non implementati. Garda usa `AAAA/F/NNNNN/PR`; non confonderlo con la matricola informale del singolo bene. |
| `id_pacco_bombola` | Da completare e conservare con i relativi legami nel tracciato INAIL/import. |
| `gvr_conf_dati_tecnici` | Nel sorgente è una sezione ripetibile. Gli screenshot mostrano il pulsante, non i dettagli espansi. |
| Campi della configurazione | `gvr_att`, `gvr_nf`, `gvr_ps`, `gvr_ts`, `gvr_nat`, `gvr_stt`, `gvr_grp`, `gvr_vol`, `gvr_dn`: attrezzatura/camera, numero fabbrica, pressioni/temperature, fluido e L/DN. La camera iniziale 0.9 è semplificata; non copre già ogni campo. |
| `gvr_breve_descr_funz` | Descrizione del processo distinta dalle note generiche e dall’identificazione: da completare. |

R80 rimane: totale volume = somma dei volumi in litri; DN escluso. Non si deduce dallo screenshot la configurazione interna dei 196 litri mostrati nell’esempio. R94: tubazioni senza visita interna. Le logiche di camere/tariffe/generatore restano quelle ricostruite dai sorgenti, non vengono reinterpretate sulla base di una singola schermata.

## 7. Caratteristiche SC/SP

Garda espone `portata_attr_sc_sp` e `n_panieri_idroestr`. Il secondo è intero ed è etichettato “Numero panieri di riserva”. La base 0.9 non li offre ancora come campi dedicati. La portata è dichiarata come testo nei metadati: non si deduce un’unità obbligatoria dal solo valore “10.000” dello screenshot e non si introduce una conversione senza verificare il suo uso nel tracciato/generatore.

## 8. Verifiche, date e possibilità di modifica

| Gruppo | Riferimenti e date Garda |
|---|---|
| GVR funzionamento | `ultima_funz` navigabile; `data_ult_funz`, `data_prox_funz`. |
| GVR integrità | `ultima_integrita` navigabile; `data_ult_integrita`, `data_prox_integrita`. |
| GVR interna | `ultima_interna` navigabile; `data_ult_interna`, `data_prox_interna`, se pertinente. |
| GVR CND | `data_ult_cnd`, `data_prox_cnd`; il nuovo requisito aggiunge il numero report, normalmente per singola attrezzatura. |
| SC/SP | `ultima_scsp` navigabile; `data_ult_scsp`, `data_prox_scsp`. |
| SC/SP indagine supplementare | `data_ult_suppl`, `data_prox_suppl`. |

Questi campi non sono soltanto input del frontend. `gi_attrezzature_save_before` protegge le date e il tipo prossimo quando esiste il collegamento alla verifica; `ricalcola_scadenze_attrezzatura` prende le ultime verifiche **effettuate** pertinenti per componente, ordinate per data di rilascio. Le verifiche multiple contribuiscono alle componenti che includono. In assenza di una verifica collegata pertinente si usano le date della scheda, secondo l’analisi già svolta. Non calcolare genericamente tutte le scadenze da una sola data.

La base 0.9 permette date iniziali dichiarate, un riferimento testuale e fonte protetta; **non ha ancora i collegamenti ai lavori DM e il loro aggiornamento operativo**. Mostrare queste date in una tabella comune non equivale alla linguetta Verifiche Garda. Il completamento dovrà consentire la navigazione al lavoro reale e distinguere una data iniziale importata da quella prodotta da un verbale/report.

`gi_attrezzature_change_after` richiama ricalcolo scadenze e aggiornamenti dei lavori non effettuati, con i filtri pertinenti. Le fotografie emesse non vanno sovrascritte. Non rieseguire questi hook su tutto lo storico durante la migrazione: acquisire stato/provenienza e quadrature.

## 9. Menu, collegamenti e cataloghi

Il menu Attrezzature conferma che cataloghi e tariffari sono strumenti operativi accessibili, non semplici tabelle nascoste. Importare le righe dei cataloghi non completa già la gestione/modifica dei cataloghi prevista da Garda. Le PSV hanno un percorso proprio collegato alle attrezzature; cliente e sede hanno ricerca/apertura dirette. Il tecnico non deve ricostruire a mano le relazioni da un elenco generico.

Linguetta Altro, pannello configurazione espanso, menu restante, elenco con azioni e scheda PSV non sono mostrati in questa serie. Il sorgente permette di proseguire senza bloccare il lavoro; eventuali altre immagini aiuteranno la verifica dell’uso reale. Non si inventano né si eliminano funzioni perché non compaiono in queste immagini.

## 10. Prossimo incremento e criterio di verifica

1. Completare la corrispondenza campi/valori/vincoli della scheda e le provenienze nel backend, a partire da questo inventario e dagli approfondimenti precedenti.
2. Organizzare form GVR e SC/SP con i gruppi Garda, campi pertinenti al tipo e riferimenti navigabili; separare scheda e storico del lavoro, senza nascondere le lacune dietro input generici.
3. Confrontare sul medesimo caso dati, controlli e risultati: cosa si può modificare, cosa viene derivato, cosa cambia nella scadenza e cosa rimane congelato.
4. Collegare offerte/incarichi e componenti al bene comune, conservando tariffazione e combinazioni; quindi generatori/documenti e INAIL secondo B2/B3.

Questo è un criterio di completamento, non la dichiarazione che le maschere siano già riscritte. La 0.9.1 consegnata nel medesimo passaggio contiene il solo intervento sui duplicati DPR; non elimina le lacune DM qui censite. Nessuna regola Garda mancante è registrata come rinunciata. Excel resta alla fine, INAIL essenziale; R73 resta vincolante.


## 11. Chiarimento successivo su sede dell’offerta e rilascio DM

Rapporto 21 verifica cliente/sede della testata DM e multisede DPR, con query e conseguenze conservative dell’importazione. R99 richiede il prossimo rilascio funzionale già integrato con DM: completare le maschere è parte del lavoro, ma non basta a dichiarare disponibile il modulo. La 0.9.1 di manutenzione preparata prima del chiarimento non è quel rilascio. Nessuna estensione ordinaria al multisede DM approvata; mantenere filtro e contatti della sede mentre si attua il nucleo comune.


## 8. Riscontro implementativo 0.10.0-dev

Rapporto 23 aggiorna lo stato rispetto alla 0.9 criticata. Implementati i gruppi di linguette, i campi tecnici tipizzati SC/SP/GVR/camere, matricola 4/1/5/2 con zeri, esenzione a tre valori, tipo prossima verifica, obbligatorietà all.7/ID per le nuove schede e compatibilità. La famiglia GVR deriva da all.7, come il trascinamento Garda. CF costruttore, descrizione/reparto/riferimento/CE, fluidi/PED/insieme/pacco/processo, portata/panieri sono disponibili senza conversioni numeriche arbitrarie dei testi.

Le vecchie schede incomplete non ricevono valori inventati. Controllo dei campi modificati e dell’ingresso nel preventivo. Dati ulteriori conservati nel JSON; le caratteristiche dell’altro gruppo sono pulite secondo il salvataggio Garda. La prova DOM+HTTP conferma inserimento/modifica/parametri, camere L/DN, CND/report, PSV e nuova offerta DM; non prova resa grafica Windows.

**Ancora aperti:** portale/gestione licenze e altri riferimenti commerciali, completa navigazione ultimi lavori/generatori, protezione e aggiornamenti da lavori DM eseguiti, dismissione/azioni ulteriori e parità dei menu. Le date dichiarate e il primo incarico dopo RC non equivalgono a verifiche DM eseguite. Nessuna lacuna è segnata derogata. Il presente incremento non chiude integralmente questa lista o R99.

## 9. Maschera incarico DM e ambienti 0.11.0-dev

Scheda a linguette Incarico/Scheda tecnica/Operazioni: assegnazione, programmazione, campi pertinenti GVR/SC-SP, camere L/DN e registrazione. Tipo attrezzatura verbale è manuale (RG/RV ecc.), distinto dalla classificazione all.7, anche nella scheda comune; riscontro metadati e hook adsrl. Salva e registra è atomico; master e bozze aperte restano coerenti, fotografia commerciale immutata.

Selettore AD_DM/AD_DPR/I&C: menu contestuali, dati comuni preservati. GVR/SC/SP dentro AD_DM. I&C dichiara funzioni ancora da realizzare; finanza DPR non presentata come finanza DM/I&C. Indirizzi distinti nel definitivo richiesti dall’utente, almeno AD e I&C; ingressi locali già predisposti.

Non ancora equivalenza completa Garda: precedenti, generatori/allegati, riesame, scadenze da effettuazione, finanza e INAIL da completare secondo R73. Rapporto 24.

**Prove finali:** 189 test passati nella suite completa (168 della base, 16 nuovi tecnici DM e 5 ambienti), Linux/Python 3.12.14/SQLite, 1 avviso di deprecazione del test client. Controllati schema/migrazioni rispetto ai modelli, migrazione 0012 popolata, numerazione concorrente, backup/ripristino, autorizzazioni e atomicità delle modifiche. Due prove DOM+HTTP passate con JavaScript/backend effettivi: schede/date/PSV/preventivi DM e assegnazione/programmazione/scheda tecnica/registrazione. Controlli Ruff E9/F sui file modificati e sintassi dei cinque JavaScript interessati passati. La diagnostica più ampia conserva segnalazioni preesistenti di base/terzi; VerbalizzAI incorporato non modificato. Conversione PDF delle offerte simulata nei server di prova, Windows/produzione/PostgreSQL e LibreOffice DM reale non osservati.
