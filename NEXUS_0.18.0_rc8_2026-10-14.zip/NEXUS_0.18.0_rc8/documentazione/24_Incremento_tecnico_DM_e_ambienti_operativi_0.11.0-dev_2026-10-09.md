# Incremento 0.11.0-dev — tecnico DM e ambienti operativi

Versione 1.0 — 9 ottobre 2026, ora italiana. Checkpoint di sviluppo, non rilascio funzionale completo R99. Base 0.10 conservata.

## Cambiamenti rispetto alla 0.10

La 0.10 creava incarichi DM soltanto da assegnare. Ora sono disponibili assegnazione singola/multipla, indipendenza, programmazione facoltativa, scheda tecnica, registrazione, sospensione/ripresa e annullamento. Numerazione GVR separata da SC-SP condivisa, contributi A1/A2 e data riepilogativa per componenti del lavoro riscontrati negli hook adsrl.

Camere, PS/TS/fluidi e tipo verbale aggiornano la scheda comune e le bozze aperte nella stessa transazione; Pes/Tes restano dati del lavoro. Preventivi emessi conservano la fotografia. Salva e registra è atomico: dati non validi non lasciano modifiche del master o numeri consumati. Versioni obbligatorie controllano la concorrenza.

Tipo attrezzatura verbale manuale, distinto da all.7; 38 definizioni tecniche dai metadati Garda con condizioni esplicite. Schema 0013, nessuna riscrittura dei preventivi. Migrazione 0012 popolata verificata; downgrade bloccato se perderebbe lavoro tecnico.

## Ambienti operativi e indirizzi di accesso

Un backend e un database applicativo comuni, tre ambienti di navigazione: **AD_DPR**, **AD_DM** (GVR/SC/SP) e **I&C S.r.l.** Il selettore Attività mantiene le anagrafiche comuni, filtra il menu e non concede permessi. Le API continuano a controllare ruoli e titolarità dei lavori. La preferenza di navigazione non determina emittente, sezionale o contabilità.

Ingressi locali già disponibili: `/ad-dpr`, `/ad-dm`, `/iec`; selezionano direttamente l’ambiente, anche arrivando da un collegamento. Le pagine comuni conservano la scelta; le pagine operative DPR/DM la rendono coerente con il modulo aperto. I&C mostra una pagina esplicita di funzioni ancora da realizzare; non espone la fatturazione DPR come se fosse I&C. Nell’ambiente DM non viene presentata la fatturazione DPR come fatturazione DM.

**Chiarimento dell’utente:** nella versione definitiva vuole indirizzi distinti per i tre ambienti, o almeno un accesso AD_DPR/AD_DM e uno separato I&C. Questo è acquisito. Due o tre URL/nomi host sono configurazioni di ingresso della stessa applicazione, non tre gestionali da mantenere. La configurazione dei domini, del proxy e delle autorizzazioni per ambito in produzione è ancora da realizzare; gli ingressi locali non sono una prova di separazione dei domini o di isolamento dei dati. Il selettore è utile al collaudo e agli utenti autorizzati su più attività.

Sviluppo: una sola installazione/avvio, un archivio di prova, passaggio fra le attività senza riavviare. Collaudo e produzione usano archivi distinti. AD_DM e AD_DPR appartengono ad AD S.r.l.; I&C S.r.l. mantiene emittente/contabilità distinti. Nessuna fusione di preventivi o fatture DM/DPR introdotta da questa navigazione.

## Evidenze, limiti e prossimo passo

**Prove finali:** 189 test passati nella suite completa (168 della base, 16 nuovi tecnici DM e 5 ambienti), Linux/Python 3.12.14/SQLite, 1 avviso di deprecazione del test client. Controllati schema/migrazioni rispetto ai modelli, migrazione 0012 popolata, numerazione concorrente, backup/ripristino, autorizzazioni e atomicità delle modifiche. Due prove DOM+HTTP passate con JavaScript/backend effettivi: schede/date/PSV/preventivi DM e assegnazione/programmazione/scheda tecnica/registrazione. Controlli Ruff E9/F sui file modificati e sintassi dei cinque JavaScript interessati passati. La diagnostica più ampia conserva segnalazioni preesistenti di base/terzi; VerbalizzAI incorporato non modificato. Conversione PDF delle offerte simulata nei server di prova, Windows/produzione/PostgreSQL e LibreOffice DM reale non osservati.

DOM+HTTP effettivo per schede/preventivi e percorso tecnico fino a registrazione; PDF offerte simulati nei server di prova. Nessuna prova Windows, produzione, PostgreSQL o emissione LibreOffice DM reale. VerbalizzAI incorporato ancora 0.3.32.3, autonomo/VPS invariati; S3 non richiesto.

Riproposizione selettiva dai precedenti, import completo dello storico, tecnico affiliato/CND della verifica, aggiornamento delle scadenze da lavori effettuati, generatori Word/PDF e nomi N01–N14, riesame DM, invio, fatturazione collegata e INAIL restano aperti. I&C/EX/import incrementale da completare; modello operativo Excel alla fine. L’assenza è lavoro pendente, non rinuncia approvata. Non trasferire automaticamente al DM il riesame negativo DPR.

Per la ripresa: quadro 1.93, scheda 00 1.8, rapporti 16 1.5 e 19 1.3; stato/manuale e prove incluse nel codice. Nessuna istanza parallela avviata. Prossimo blocco: precedenti e generatore/documenti DM con parità Garda, poi completamento tecnico/finanza/INAIL. Non ricreare 0012/0013 o trattare gli ambienti come archivi indipendenti.
