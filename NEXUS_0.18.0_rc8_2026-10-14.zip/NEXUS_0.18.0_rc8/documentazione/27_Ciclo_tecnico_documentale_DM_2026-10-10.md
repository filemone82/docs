# Ciclo tecnico e documentale AD_dm — 0.12.0-dev

10 ottobre 2026. Quadro 1.95, ripresa 1.10, R01–R106 invariati. Base 0.11.1-dev conservata; nuovo schema applicativo 0014. Obiettivo: tutte le funzioni Garda compatibili nel gestionale unico.

L’incremento permette di produrre e conservare i verbali DM, confermare il PDF consultato, chiudere il lavoro e registrarne il riesame. Il definitivo conservato è lo stesso allegato dal percorso email. Non è ancora il prodotto completo; non si chiede a Federico di installare ogni checkpoint.

## Sorgenti e risultato

| Parte | Fonte Garda adsrl | Risultato e confine |
|---|---|---|
| Precedenti | `_custom.php`, `copia_dati_precedente_verifica` | Ultimi effettuati pertinenti F/I/N e SC/SP, per data/ID e con regole specifiche sulle tubazioni; solo prima del primo salvataggio. Provenienza per campo. Storico importato ancora aperto. |
| Dati e modelli | `cust/meta/verifiche.js`, `cust/gi_views.php`, `cust/modelli/verbale-gvr.docx`, `verbale-sc-sp.docx` | Campi manuali/derivati, camere L/DN, sbarrature e firma comune. Word originali identici al backup; modello, revisione e impronta nella fotografia. |
| Etichette | `std/fw/gi_word.php`, `gi_word_placeholder_value_fmt_get` | `l=1`: casella + spazio non separabile + etichetta; per gli altri campi, etichetta e valore. JSON delle 150 etichette originali con impronta della fonte. Il controllo visivo ha rilevato il parametro inizialmente ignorato: corretto e coperto dalle prove Word/PDF. |
| PDF richiesti | `_custom.php`, `gi_verifiche_save_before` | Nel percorso ordinario, verbale PDF e per V1 scheda tecnica PDF caricata. Eccezione alla richiesta dei PDF nella modifica multipla ancora aperta. |
| Nomi | `_custom.php`, `gi_inail_filename_gen` e stampa | Nome ordinario sanificato e limitato a 80 caratteri; alla chiusura, matricola formale + `data_pvp` senza separatori. Altri nomi e allegati fiscali da verificare. |
| Riesame | Metadati verifiche e hook di riesame/chiusura | Qualunque stato; autore/data, storico e nota per N. N non riapre; chiusura non azzera. Riesame multiplo atomico. Nessuna riapertura automatica DPR trasferita al DM. |
| Scadenze | `_custom.php`, `ricalcola_scadenze_attrezzatura` | Ultima effettuata per componente e data di rilascio. Retrodatata non sostituisce una più recente. Annullamento riprende precedente o date iniziali. V2 dopo una effettuata. Protezioni di maschera e tutti i collegamenti ancora da verificare. |
| CND | `_custom.php`, `gi_verifiche_change_after`; R85–R86 | Integrità su bene con CND: date aggiornate se la prossima è uguale/successiva o assente nel master. Il PHP usa `>=`; «successiva» nel catalogo è una sintesi. Avviso se più vecchia; riferimento al report conservato senza nuovo numero. Nessun rapporto CND inventato. |

I precedenti sono lavori nativi del nuovo archivio, non lo storico già importato dai dump. I due Word provengono dal codice Garda disponibile: eventuali modelli operativi configurati esternamente non sono attestati identici.

## Maschera e conservazione

In `AD_dm › Incarichi DM` sono disponibili scheda tecnica, dati del verificatore, documenti, riesame e operazioni. Dopo registrazione: genera Word/PDF, eventuale ritocco o caricamento, consulta il corrente, conferma e chiudi. V1 richiede anche la scheda tecnica caricata; documenti precedenti nello storico.

Il confronto del Word usa il controllo di contenuto già presente in VerbalizzAI. Modifiche di dati, caselle o immagini non passano come impaginazione. Il PDF esterno resta byte per byte e richiede il controllo dell’operatore: non si dichiara una verifica semantica automatica.

La chiusura controlla versioni, PDF corrente, impronta e fotografia di scheda/modello/firma. Il percorso ordinario non sostituisce il definitivo dopo chiusura. L’email prepara destinatario della sede, copia ufficio e allegati archiviati; invio su azione dell’operatore abilitato. SMTP simulato nel collaudo.

Nome/cognome separati servono per generare il Word; qualifica e firma grafica non diventano obblighi per caricare il PDF esterno. Dati del tecnico sullo stesso utente e affiancamento verso un tecnico attivo.

0014 aggiunge documenti/riesami/invii DM, dati tecnici identificativi dell’utente, metadati di chiusura/affiancamento e riferimento delle scadenze al lavoro. File nell’archivio comune per impronta; date iniziali conservate. Migrazione verificata da 0013 popolata; downgrade impedito se perderebbe nuovi dati. Backup/ripristino comprende anche PDF e firma. Nessuna prova di migrazione completa adsrl/iec o PostgreSQL.

## Collaudo

**Regressione passata: 213 test nella suite generale e quattro scenari CND supplementari (due aggiuntivi), per 215 casi distinti.** Risultati in `report_collaudo/pytest_finale_0.12.0-dev.txt` e `.xml`.

DOM+HTTP con JavaScript/backend effettivi fino a conferma, chiusura e riesame; convertitore sintetico nel solo server di prova. Tre test `pdf_vero` DM usano LibreOffice reale. Renderizzate e ispezionate tutte le quattro pagine dei campioni GVR/SC/SP con dati sintetici e firma; corrette le etichette senza modificare gli originali.

Prove su hash/documenti obsoleti, requisiti V1, ritocchi, permessi, email con allegato identico al definitivo, riesame negativo/preesistente, conflitto multiplo, precedenti GVR e salvataggio, CND più vecchio/uguale/più recente e numero report, retrodatazione, annullamento, migrazione e backup. Nessun invio esterno, prova Windows o azione in produzione.

## Perimetro aperto

Matrice 26: verifica progressiva di 151 regole, non dichiarazione di parità. AD-21: eccezione multipla; AD-22: export INAIL; AD-28: storici importati e campagna completa delle tipologie. Correzioni dopo chiusura, tutte le azioni di griglia, filtri per referenti/clienti e date derivate protette restano da verificare.

AD-31: il blocco di indipendenza DPR è ereditato dalla base DM 0.11, mentre adsrl non lo applica. R63 nasce dal primo DPR. Lo scostamento viene registrato, senza acquisirlo come deroga approvata; da allineare prima della candidata completa.

Restano fatturazione/incassi DM collegati, EX, INAIL, I&C, dashboard, import completo/incrementale e collaudo dei tre ambienti. Nessuna funzione eliminata. Prossimo blocco: fatturazione DM e pacchetti INAIL; successivo: I&C sui beni comuni. Le sincronizzazioni separate saranno sostituite dal dato condiviso conservandone gli effetti pertinenti.

Tecnologia e base restano quelle Python/VerbalizzAI allegate. VerbalizzAI è incorporato nel backend comune e conserva per ora l’archivio SQLite raccordato; unificazione fisica e riconciliazione devono preservare identità, documenti e storico. R99/R106 restano aperte.
