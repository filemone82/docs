# 36 · Differenze della 0.12.8 rispetto alla 0.12.7

11/10/2026 · Redatto da Claude · Schema Alembic **0019** (nuova migrazione, § 9).

Fonti:
- le note di collaudo di Federico della sera dell'11/10/2026, N1–N9 (documento di progetto 26), con le decisioni **R124** (revoca dell'accettazione) e **R125** (fatture dalle righe dei preventivi);
- la richiesta sul menu (gruppi richiudibili, Gestione, cataloghi in una schermata) e su utenti e permessi «come in VerbalizzAI»;
- il registro dei rilievi del revisore sulla 0.12.6, **AD-REV-001…005** e AD-DEC-001;
- la rilettura del codice di Garda (adsrl), § 8.

VerbalizzAI 1.0.1 rc2 non è stato modificato (R111): se ne usano solo le funzioni.

## 1. Preventivi: accettazione, revoca e riesame (N2–N5, R124)

**Revoca dell'accettazione (R124).** Nella linguetta «Righe» del preventivo c'è «Revoca accettazione…» (DPR e DM).
- Il motivo è obbligatorio. Chi, quando, perché e lo stato precedente si registrano nella tabella `preventivi_righe_revoche` e nel registro operazioni.
- La riga torna «in attesa».
- La verifica DPR o l'incarico DM nati dalla riga:
  - se sono ancora «da assegnare», si annullano con lo stesso motivo;
  - se sono già affidati o oltre, la revoca si ferma e il messaggio dice di annullare prima la verifica.
- Nella linguetta «Riesame» compare l'elenco «Revoche dell'accettazione».
- Una riga accettata non si cambia più in «rifiutata», «annullata» o «in attesa» con i pulsanti normali: il messaggio rimanda a «Revoca accettazione…».

**«Accetta» su righe già accettate (N3).** Non cambia nulla. Il messaggio è «Le righe selezionate sono già «Accettata»: nessuna modifica.». L'evidenza dell'accettazione non si sovrascrive.

**Selezione e stato (N4).**
- La prima colonna si chiama «Sel.» e ha la casella «seleziona tutte».
- L'ultima colonna si chiama «Stato della riga».
- La casella serve solo a scegliere le righe su cui agire.

**Riesame non ripetibile (N5).**
- Dopo un riesame conforme il modulo «Nuovo riesame» non compare più. Al suo posto c'è la frase «non serve ripeterlo».
- Il modulo ricompare in due casi:
  - l'ultimo esito è non conforme;
  - una riga revocata è stata riaccettata dopo l'ultimo riesame.
- Anche l'API rifiuta un riesame non necessario.
- Le righe accettate in un secondo momento su un preventivo già riesaminato (accettazione parziale, poi completata) diventano subito verifiche, come in Garda.
- Il caso «righe aggiunte» della nota N5 non si presenta: le righe si aggiungono solo a un preventivo «creato», e quindi prima del riesame.

**Verifiche annullate.** Una riga revocata e poi riaccettata genera una nuova verifica o un nuovo incarico; quello annullato resta in archivio. Per questo il vincolo «una verifica per riga» vale solo per le verifiche non annullate (§ 9).

## 2. Fatture dalle righe dei preventivi, come in Garda (N6, N7, R125)

**Regola unica «da fatturare»** (`gestionale/moduli/finanza/da_fatturare.py`). È la condizione di Garda «Genera fattura cliente» applicata ai dati del gestionale. Una riga è da fatturare se valgono tutte e tre:
- la riga è accettata e l'ultimo riesame del contratto è conforme;
- il lavoro è concluso:
  - DPR: verifica «riesaminata» con riesame del verbale conforme;
  - DM: incarico «effettuato» con riesame conforme;
  - le voci senza impianto o attrezzatura (trasferta, a corpo) diventano fatturabili con la prima verifica fatturabile del loro preventivo;
- la riga non è già fatturata:
  - conta il netto delle fatture valide meno le note di credito emesse;
  - una fattura stornata per intero riporta la riga tra le «da fatturare»;
  - nel DM la riga si fattura per intero (IE-38);
  - un acconto TD02 sul preventivo non conta come fatturazione.

**Dove si vede:**
- **Verifiche** (DPR) e **Verifiche** (incarichi DM): filtro rapido «Da fatturare» e pulsante «Vai alle righe da fatturare →».
- **Righe dei preventivi** (DPR e DM): filtro rapido «Da fatturare» e colonna «Da fatturare».

**«Fattura le selezionate…»** (righe dei preventivi):
- crea una bozza di fattura con una riga per ogni riga di preventivo scelta;
- si sceglie se creare una nuova fattura o aggiungere le righe a una bozza dello stesso cliente e attività (la «fattura da integrare» di Garda), poi intestatario (proposto: il cliente) e data;
- si ferma, e lo dice, se le righe non sono da fatturare, se sono di clienti diversi o di attività diverse (DPR e DM);
- l'IVA è quella del cliente intestatario, altrimenti il 22%;
- il riferimento d'ordine viene dal preventivo, se le righe sono di un solo preventivo;
- poi si apre la bozza nella pagina Fatture, dove si controlla e si emette.

**Non ancora pari a Garda** (si completa nella 0.14, servono XML veri di Garda):
- XML completo, esiti Aruba e storico di ingecert;
- le scadenze di pagamento: in Garda vengono da preventivo, poi cliente, poi valore predefinito; qui si inseriscono con «Scadenze» nella bozza.

**Piccola correzione.** Nella bozza la quantità si legge «1» e non più «1.000000».

## 3. AD_DM: preventivi dalle scadenze, PVP e sconto del cliente (N8, N9, AD-13)

**Scadenze AD_DM → preventivo (N8)**, come «Crea preventivo da scadenze» di Garda:
- In Scadenze (contesto AD_DM) ogni riga ha la casella di selezione, con «seleziona tutte».
- Filtri rapidi:
  - per scadenza: Scadute, Entro 30 giorni, Entro 90 giorni;
  - per stato: Da preventivare;
  - per tipo di attrezzatura: GVR, SC/SP, Tarature;
  - Tutte.
- «Prepara preventivo DM…» crea **una riga per scadenza**. In Garda è `$merge=false`, e nel dump adsrl non ci sono righe combinate.
- **La combinazione di più attività GVR non è mai automatica.** Si sceglie a mano modificando la riga (funzionamento, integrità, funzionamento + integrità…). Se la combinazione copre l'attività di un'altra riga della stessa attrezzatura nello stesso preventivo, il messaggio indica quella riga da togliere.
- **Più sedi selezionate:** un preventivo per sede. La nota N8 diceva di fermarsi; si è seguito Garda, che lega il preventivo DM alla sede.
- **Preventivo esistente:** con un numero (es. 12 o 12/2026) le righe si aggiungono a quel preventivo DM. Deve essere «creato» e della stessa sede.
- Restano fuori, e il messaggio dice quali sono:
  - le scadenze già in un preventivo (divieto di ripreventivare, AD-12);
  - le attrezzature esenti o dismesse;
  - CND, supplementari e tarature (attività I&C).

**Prima verifica periodica o successiva (N9):**
- **Proposta.** Il tipo si propone dall'attributo «Tipo prossima verifica» dell'attrezzatura (Garda `tipo_prox_verifica`). Quando un'attrezzatura ha più scadenze, la più vicina porta il tipo (AD-40).
- **Etichette** dell'attributo «Soggetta a messa in servizio» nella scheda GVR:
  - «Sì · soggetta (art. 4 D.M. 329/04)»;
  - «No · non soggetta (art. 5 D.M. 329/04)».
- **Blocco.** Una prima periodica GVR con quell'attributo non compilato si blocca con un messaggio che lo chiede. Prima finiva in silenzio nella colonna V2.
- **Colonna della tariffa.** Nella riga del preventivo si legge «Tariffa: colonna V1» (o V2, V3, V4).

**Sconto predefinito del cliente (AD-13).** È una regola di Garda che mancava. In adsrl 151 clienti hanno uno sconto predefinito, e il 38% delle righe dei preventivi è scontato.
- Nella scheda del cliente c'è il campo «Sconto predefinito AD_DM %».
- Le nuove righe dei preventivi DM lo applicano, comprese quelle create dalle scadenze.
- L'importazione da adsrl lo riporta.
- Gli sconti DPR restano quelli di prima (D38).

## 4. Menu richiudibile, Configurazione e «Tipi e tariffe»

**Menu.** I gruppi si aprono e chiudono con un clic sul titolo.
- Il gruppo della pagina aperta è sempre aperto.
- Gli altri restano come li ha lasciati l'utente: la scelta si ricorda nel browser.
- I gruppi con una sola voce (Scadenze, Verifiche DM, Fatture) sono collegamenti diretti.

| Gruppo | Voci |
|---|---|
| Clienti | Clienti, Sedi operative |
| Impianti (DPR) | Impianti, Tariffario |
| Attrezzature (DM) | Attrezzature, Valvole di sicurezza, **Tipi e tariffe** |
| Scadenze · Preventivi · Verifiche · Fatture | come prima |
| Gestione | **Utenti e permessi**, **Configurazione**, Comuni (ISTAT) |

**Configurazione** (`/configurazione`) raccoglie in una pagina, a riquadri, ciò che prima stava sparso nel menu. Ogni utente vede solo i riquadri per cui ha il permesso.
- Modelli dei documenti:
  - modelli dei verbali di VerbalizzAI (M01, M02, M03);
  - modelli Word di preventivi e verbali DM.
- Firme dei verificatori e strumenti di misura (sezioni di VerbalizzAI).
- Tipi di pagamento, aliquote IVA, elenchi di valori, commerciali.
- Impostazioni email.
- Importazione dati, Verbali di VerbalizzAI (archivio e collegamenti), registro operazioni, backup e integrità.

I vecchi indirizzi funzionano ancora e, aperti, illuminano «Configurazione» nel menu.

**Tipi e tariffe** (`/cataloghi`, AD_DM) riunisce in una schermata a linguette i sei cataloghi di Garda in sola lettura:
- tipi di attrezzature;
- tipi attrezzature GVR;
- ID specifiche;
- tipi attr. / ID specifiche;
- tariffe SC/SP;
- tariffe GVR.

I vecchi indirizzi `/cataloghi/<nome>` aprono la linguetta giusta.

## 5. Utenti e permessi come in VerbalizzAI

«Utenti e permessi» (`/utenti`) è una pagina sola, come in VerbalizzAI:
- in alto l'elenco degli utenti;
- sotto «Permessi per ruolo»: una colonna per ruolo, una casella per operazione, e «Salva permessi» per tutte le modifiche insieme. L'Amministratore ha sempre tutto;
- infine l'elenco dei ruoli, con «Nuovo ruolo».

`/ruoli` porta alla sezione dei permessi della stessa pagina.

## 6. Rilievi del revisore sulla 0.12.6 (AD-REV-001…005)

Ogni rilievo è riprodotto da un test nell'applicazione completa, in `tests/test_rilievi_revisore.py`. Il registro aggiornato è `documentazione/Registro_rilievi_Gestionale_AD_0.12.8.txt`: ogni rilievo è «RISOLTO DA VERIFICARE · 0.12.8».

| Rilievo | Correzione | Prova |
|---|---|---|
| **AD-REV-001** Word più recente caricato, bozza ancora con i dati vecchi | Regola R122 (decisione AD-DEC-001): fa fede la scheda tecnica di VerbalizzAI. Un Word più recente della scheda la aggiorna, e la bozza riparte da lì. Un Word più vecchio non la riporta indietro. Gli esiti si dicono: «Scheda tecnica dell'impianto aggiornata con i dati di questo verbale (cambiano: …)», oppure «Il Word è precedente alla scheda tecnica … la scheda non cambia … Dati diversi nel Word: …» | caso 10/20 rifatto con le descrizioni «LPS 10», «LPS 20» e «LPS 5»: scheda e bozza «LPS 20», riquadro «Verbale precedente» uguale alla bozza |
| **AD-REV-002** Scelto uno storico meno recente | Criterio unico, lo stesso di VerbalizzAI quando crea la bozza: fra gli impianti di VerbalizzAI collegati vale quello con il verbale valido più recente (data del verbale, poi aggiornamento). Il riquadro «Verbale precedente» mostra proprio il verbale che userà la bozza | 2023/2024/2025 contro 2026: vale VP/001/26 e `baseline_id` della bozza uguale al riquadro |
| **AD-REV-003** Collegamento di un altro impianto sovrascritto | Se il Word è già nell'archivio e collegato a un altro impianto della stessa sede, il caricamento si ferma: il messaggio dice a quale impianto è collegato e dove correggere il collegamento. Nessuno spostamento silenzioso | caso A/B: errore 400 che cita l'impianto, collegamento invariato |
| **AD-REV-004** Recapiti non riconciliati nella fusione dei clienti | Nella fusione automatica adsrl → cliente DPR: i campi vuoti si completano da AD_dm, con nota nel cliente «Completati da Garda AD_dm: …». I valori diversi restano quelli già presenti, con un avviso nel cliente («Recapiti diversi in Garda AD_dm … controlla») e nel rapporto. Due nuovi contatori nel rapporto di importazione. Nessuna precedenza generale di una fonte: si completa il vuoto, si segnala il diverso | PEC vuota → completata; email diversa → conservata con avviso; contatore = 1 |
| **AD-REV-005** Provenienze orfane dopo l'eliminazione | Quando si elimina un cliente, una sede, un impianto, un preventivo, una riga o una verifica, la loro provenienza da Garda resta, marcata «eliminato il …» (`origini.eliminato_il`). Così il destino del record importato resta ricostruibile e la provenienza non si attacca a un oggetto nuovo che riceve lo stesso numero | cliente importato ed eliminato: provenienza marcata e non più restituita per quell'id |

## 7. Correzione già annunciata: ZIP di verbali al posto del backup (N1)

**Segnalazione di Federico, 18:55.** In Gestione › Verbali di VerbalizzAI › «1. Importa l'archivio di VerbalizzAI» ha caricato uno ZIP di 125 MB con i verbali di un impianto. Il programma ha risposto «Errore imprevisto del programma».

**Causa.** Quella funzione accetta solo il «Backup completo» di VerbalizzAI, cioè il file `…adbackup.zip` con dentro `manifest.json`. Il programma non ha importato né modificato nulla.

**Rimedio.** Prima del controllo il programma guarda dentro lo ZIP e risponde con un messaggio chiaro:
- **ZIP con Word o PDF:** dice quanti ne contiene, spiega che non è un backup e indica dove si caricano i verbali Word: Verbali › «+ Importa Word storici», oppure il riquadro «Verbale precedente» della verifica.
- **File che non è uno ZIP**, oppure **ZIP senza `manifest.json`:** lo dice.
- **Qualsiasi altro difetto del backup:** diventa «backup non valido», non più un errore imprevisto.

Un'importazione fallita non lascia traccia nel registro operazioni. I dettagli degli errori imprevisti sono in `gestionale.log`, nella cartella dei dati.

## 8. Rilettura del codice di Garda (adsrl)

Codice letto: `_custom.php`, `lavori_batch_cli.php` e i metadati `meta/*.js`, letti dalla copia in `D:\backup_gestionale`.

**Regole confermate, già presenti o realizzate in questa versione:**
- **Preventivo da scadenze** (`gi_scadenze_preventivi_crea`):
  - una riga per scadenza;
  - preventivo indicato solo se «creato» e della stessa sede;
  - tipo da `tipo_prox_verifica` (AD-40);
  - modalità di pagamento dal cliente;
  - entrano solo funzionamento, integrità, interna e SC/SP non già coperte, di attrezzature né dismesse né esenti.
- **Fattura dalle righe** (`gi_preventivi_righe_fattura_cliente_genera`):
  - condizione «effettuata, non fatturata, riesame conforme»;
  - descrizione secondo AD-55;
  - IVA del cliente o predefinita;
  - integrazione di una fattura esistente.
- **Divieto di ripreventivare** (AD-12): era già coperto da `controlla_copertura`.

**Regola che mancava, ora realizzata:** lo sconto predefinito del cliente (`sconto_def`, AD-13), § 3.

**Da decidere (domanda a Federico):** Garda permette di cambiare il tipo di verifica GVR (funzionamento, integrità, combinazione) sulla verifica stessa, dopo il preventivo. Qui si cambia solo sulla riga del preventivo. Resta così finché non lo decide.

## 9. Migrazione 0019

`0019_revoche_e_origini_eliminate`:
- **Nuova tabella** `preventivi_righe_revoche`: riga, preventivo, motivo, stato precedente, verifica o incarico annullati, data e autore.
- **`origini.eliminato_il`:** data dell'eliminazione dell'oggetto di destinazione.
- **`clienti.sconto_dm`:** sconto predefinito AD_DM, in centesimi di punto; vale 0 se non indicato.
- **Vincolo «una verifica per riga»** (DPR `verifiche.riga_id`, DM `dm_incarichi.riga_id`): l'unicità vale ora solo per le righe non annullate, con un indice parziale. In più c'è un indice semplice per le ricerche.
- **Ritorno alla 0018:** si blocca, con un messaggio, se una riga ha già più di un lavoro (uno annullato e uno nuovo).

La migrazione è stata provata sulla copia dell'ambiente di prova della 0.12.7 (0018 → 0019) e nei test che confrontano modelli e migrazioni.

## 10. Prove

| Prova | Esito |
|---|---|
| `tests/test_revoca_accettazione.py` (nuovo) | revoca con motivo; verifica «da assegnare» annullata; revoca bloccata con verifica affidata; «Accetta» ripetuto senza effetto; riaccettazione → nuovo riesame → nuova verifica |
| `tests/test_fattura_da_righe.py` (nuovo) | filtro «Da fatturare» di verifiche e righe (non prima del riesame del verbale); trasferta e «a corpo» insieme alla verifica; una riga non pronta blocca tutto; bozza con una riga per riga; bozza proposta per le aggiunte; emessa e stornata per intero → di nuovo da fatturare |
| `tests/test_scadenze_preventivo_dm.py` (nuovo) | una riga per scadenza, mai combinate; CND rifiutata (I&C); scadenze coperte non ripreventivabili; combinazione a mano che copre un'altra riga segnalata; un preventivo per sede; preventivo indicato (solo se «creato»); PVP dalla scadenza più vicina; blocco senza «soggetta a messa in servizio»; sconto del cliente; colonna di tariffa |
| `tests/test_rilievi_revisore.py` (nuovo) | AD-REV-001…005, 5 casi |
| `tests/test_menu_attivita.py` (riscritto) | gruppi del menu DM e DPR; Configurazione; Tipi e tariffe e vecchi indirizzi; Utenti e permessi |
| `tests/test_verbali.py::test_zip_che_non_e_un_backup` | ZIP di Word/PDF e file non ZIP: messaggio chiaro, codice 400 |
| Confronto modelli ↔ migrazioni (`compare_metadata`) | nessuna differenza con la 0019 |
| Prova dell'interfaccia con Chromium, su una copia dell'ambiente di prova migrata 0018 → 0019 | menu richiudibile, Configurazione, Tipi e tariffe, Utenti e permessi, Scadenze DM → preventivo, «Accetta» ripetuto, revoca e nuovo riesame, «Fattura le selezionate…» → bozza: nessun errore JavaScript |
| Suite completa | vedi `report_collaudo/pytest_0.12.8.txt` |

Risultato della suite completa: **263 test passati** (Linux, Python 3.13), `report_collaudo/pytest_0.12.8.txt`.

## 11. Cosa non è stato verificato

- **Windows e LibreOffice del PC dell'ufficio:** la suite e la prova dell'interfaccia sono state eseguite su Linux.
- **Dump reali di Garda:** l'importazione adsrl con lo sconto predefinito e la riconciliazione dei recapiti è provata su un dump ridotto. Sul dump reale non è stata rifatta: i due nuovi contatori del rapporto si vedranno alla prossima importazione.
- **Fatture:** l'XML della bozza creata dalle righe è quello di prima, non ancora pari a Garda (0.14).
- **Rilievi AD-REV:** sono «risolti da verificare». La chiusura spetta al revisore.
