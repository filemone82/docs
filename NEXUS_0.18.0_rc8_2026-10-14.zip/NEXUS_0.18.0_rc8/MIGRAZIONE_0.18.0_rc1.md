# Passaggio alla 0.18.0 rc1

Questa base ricompone la 0.17.0 ricevuta e le correzioni mancanti della 0.16.1. Conserva C17–C28, VerbalizzAI 1.0.1 rc2 e i modelli Word originali.

Per l'archivio SQLite lo schema resta 0027 e il DDL compilato è invariato. Conservare il backup dell'archivio di collaudo e usare una copia prima dell'avvio della nuova versione. La correzione non ricostruisce automaticamente numeri già cambiati da vecchie revisioni né i riferimenti commerciali già perduti.

Per PostgreSQL leggere il documento 49. È una preparazione in rc: 35 prove native non eseguite. La prima apertura richiede un database dedicato vuoto e inizializza la baseline congelata 0027. Non converte o sovrascrive il file SQLite e non importa automaticamente Garda.

Le decisioni funzionali restano nel registro canonico ricevuto fino a R143 e nelle approvazioni C17–C28. Restano aperti AD-REV-014/015 e gli altri limiti dichiarati. Per lo stato del codice leggere `RIPRESA_NEXUS_0.18.0_rc1.txt`; i vecchi checkpoint sono storici.
