"""Griglie di utenti e ruoli."""

from __future__ import annotations

from sqlalchemy import func, select
from sqlalchemy.orm import aliased

from ...core.sql_portabile import oggi_italiano, data_tra_giorni, anno_dopo, giorni_fra, testi_uniti, json_testo
from ...core.griglia import Colonna, Griglia, registra
from .modelli import Ruolo, RuoloPermesso, Utente, UtenteRuolo

_R2 = aliased(Ruolo)
# 0.16: con più ruoli la colonna li elenca tutti, il principale per primo
_ALTRI = (select(testi_uniti(_R2.nome, " + ")).select_from(UtenteRuolo).join(_R2, UtenteRuolo.ruolo_id == _R2.id)
          .where(UtenteRuolo.utente_id == Utente.id).correlate(Utente).scalar_subquery())
_RUOLI = func.coalesce(Ruolo.nome + " + " + _ALTRI, Ruolo.nome)

registra(Griglia(
    codice="utenti",
    titolo="Utenti",
    permesso="sistema.utenti",
    da=lambda: Utente.__table__.join(Ruolo.__table__, Utente.ruolo_id == Ruolo.id),
    ordine_predefinito=[("nome", "asc")],
    colonne=[
        Colonna("id", "N.", "numero", Utente.id, visibile=False, larghezza=70),
        Colonna("username", "Nome utente", "testo", Utente.username, larghezza=150),
        Colonna("nome", "Nome e cognome", "testo", Utente.nome, larghezza=200),
        Colonna("email", "Email", "testo", Utente.email, larghezza=220),
        Colonna("ruolo", "Ruoli", "testo", _RUOLI, larghezza=220),
        Colonna("attivo", "Attivo", "booleano", Utente.attivo, larghezza=90),
        Colonna("bloccato_fino", "Bloccato fino a", "dataora", Utente.bloccato_fino, visibile=False, larghezza=150),
        Colonna("cambio_password_richiesto", "Password provvisoria", "booleano", Utente.cambio_password_richiesto, visibile=False, larghezza=120),
        Colonna("ultimo_accesso", "Ultimo accesso", "dataora", Utente.ultimo_accesso, larghezza=150),
        Colonna("creato_il", "Creato il", "dataora", Utente.creato_il, visibile=False, larghezza=150),
    ],
))

_utenti_del_ruolo = (select(func.count(Utente.id)).where((Utente.ruolo_id == Ruolo.id) | Utente.id.in_(
    select(UtenteRuolo.utente_id).where(UtenteRuolo.ruolo_id == Ruolo.id))).correlate(Ruolo).scalar_subquery())
_permessi_del_ruolo = select(func.count()).select_from(RuoloPermesso).where(RuoloPermesso.ruolo_id == Ruolo.id).correlate(Ruolo).scalar_subquery()

registra(Griglia(
    codice="ruoli",
    titolo="Ruoli",
    permesso="sistema.ruoli",
    da=lambda: Ruolo.__table__,
    ordine_predefinito=[("nome", "asc")],
    colonne=[
        Colonna("id", "N.", "numero", Ruolo.id, visibile=False, larghezza=70),
        Colonna("nome", "Ruolo", "testo", Ruolo.nome, larghezza=200),
        Colonna("attivita", "Attività", "testo", Ruolo.attivita, larghezza=120),     # R132: vuoto = comune
        Colonna("descrizione", "Descrizione", "testo", Ruolo.descrizione, larghezza=380),
        Colonna("attivo", "Attivo", "booleano", Ruolo.attivo, larghezza=90),
        Colonna("di_sistema", "Di sistema", "booleano", Ruolo.di_sistema, larghezza=100,
                descrizione="Il ruolo di sistema (Amministratore) ha sempre tutti i permessi"),
        Colonna("utenti", "Utenti", "numero", _utenti_del_ruolo, larghezza=90),
        Colonna("permessi", "Permessi assegnati", "numero", _permessi_del_ruolo, larghezza=120,
                descrizione="Per l'Amministratore vale «tutti»"),
    ],
))
