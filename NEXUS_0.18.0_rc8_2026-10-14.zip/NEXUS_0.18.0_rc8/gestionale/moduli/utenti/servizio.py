"""Regole su utenti, ruoli e permessi (D22, D24, D37).

Principi:
- gli utenti non si cancellano: si disattivano (restano nel registro delle operazioni);
- un ruolo si elimina solo se nessun utente lo ha mai avuto assegnato; altrimenti si disattiva;
- il ruolo Amministratore ha sempre tutti i permessi e deve restare almeno un amministratore attivo;
- ogni modifica è scritta nel registro con «prima / dopo».
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ...core.config import Config
from ...core.db import adesso
from ...core.errori import Conflitto, ErroreUtente, NonTrovato
from ...core.permessi import CATALOGO, DA_RT, GEMELLI, GESTIONE_PER_ATTIVITA, PER_CODICE, RUOLI_PREDEFINITI, attivita_di, espandi
from ...core.sicurezza import controlla_password_nuova, hash_password, password_temporanea
from ..registro import servizio as registro
from .modelli import Permesso, Ruolo, RuoloPermesso, Sessione, Utente, UtenteRuolo, ruoli_di

RE_USERNAME = re.compile(r"^[a-z0-9._-]{3,60}$")
RE_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


@dataclass
class Attore:
    """Chi sta facendo l'operazione (per il registro)."""

    id: int | None
    nome: str


# ---------------------------------------------------------------- avvio


def allinea_catalogo(s: Session) -> None:
    """Allinea la tabella `permessi` al catalogo nel codice; le voci nuove vanno ai ruoli predefiniti."""
    esistenti = {p.codice: p for p in s.execute(select(Permesso)).scalars()}
    ruoli = {r.codice: r for r in s.execute(select(Ruolo)).scalars()}
    nuovi: list[str] = []
    for ordine, m in enumerate(CATALOGO):
        p = esistenti.pop(m.codice, None)
        if p is None:
            s.add(Permesso(codice=m.codice, area=m.area, descrizione=m.descrizione, ordine=ordine, disponibile=m.disponibile))
            nuovi.append(m.codice)
        else:
            p.area, p.descrizione, p.ordine, p.disponibile = m.area, m.descrizione, ordine, m.disponibile
    for obsoleto in esistenti.values():  # voce tolta dal catalogo
        s.delete(obsoleto)
    s.flush()
    for codice in nuovi:
        for codice_ruolo in {g for c in PER_CODICE[codice].partenza
                             for g in ((c,) if codice in GESTIONE_PER_ATTIVITA else GEMELLI.get(c, (c,)))}:
            if codice_ruolo in ruoli:
                s.add(RuoloPermesso(ruolo_id=ruoli[codice_ruolo].id, permesso_codice=codice))
    s.flush()


def crea_ruoli_predefiniti(s: Session) -> None:
    if s.execute(select(func.count()).select_from(Ruolo)).scalar():
        return
    for codice, nome, descrizione, di_sistema, attivita in RUOLI_PREDEFINITI:
        s.add(Ruolo(codice=codice, nome=nome, descrizione=descrizione, di_sistema=di_sistema, attivita=attivita))
    s.flush()


def inizializza(s: Session) -> None:
    """Prima i ruoli, poi il catalogo (così i permessi di partenza vengono assegnati)."""
    crea_ruoli_predefiniti(s)
    allinea_catalogo(s)


# ---------------------------------------------------------------- lettura


def permessi_di_ruolo(s: Session, ruolo: Ruolo) -> set[str]:
    if ruolo.di_sistema:
        return {m.codice for m in CATALOGO}
    if not ruolo.attivo:
        return set()
    codici = set(s.execute(select(RuoloPermesso.permesso_codice).where(RuoloPermesso.ruolo_id == ruolo.id)).scalars())
    return espandi(codici)


def primo_avvio_necessario(s: Session) -> bool:
    return not s.execute(select(func.count()).select_from(Utente)).scalar()


def utente_o_404(s: Session, utente_id: int) -> Utente:
    u = s.get(Utente, utente_id)
    if u is None:
        raise NonTrovato("Utente non trovato: forse la pagina non è aggiornata.")
    return u


def ruolo_o_404(s: Session, ruolo_id: int) -> Ruolo:
    r = s.get(Ruolo, ruolo_id)
    if r is None:
        raise NonTrovato("Ruolo non trovato: forse la pagina non è aggiornata.")
    return r


def dati_utente(u: Utente) -> dict:
    return {
        "username": u.username,
        "nome": u.nome,
        "email": u.email,
        "ruolo": " + ".join(r.nome for r in ruoli_di(u)) if u.ruolo else "",
        "attivo": u.attivo,
    }


PRIORITA_VZ = ("amministratore", "responsabile_tecnico", "tecnico", "tecnico_dm_dpr", "segreteria")


def ruolo_vz(ruoli: list) -> str:
    """Codice del ruolo da passare a VerbalizzAI (modulo dei verbali DPR) quando l'utente ha più ruoli: il più ampio fra
    quelli che valgono nel DPR (amministratore, poi RT DPR, poi verificatore); altrimenti il principale."""
    codici = [r.codice for r in ruoli]
    return next((c for c in PRIORITA_VZ if c in codici), codici[0] if codici else "")


def _ha_ruolo(ruolo_id: int):  # noqa: ANN202
    from sqlalchemy import exists, or_
    return or_(Utente.ruolo_id == ruolo_id, exists().where(UtenteRuolo.utente_id == Utente.id, UtenteRuolo.ruolo_id == ruolo_id))


def _ruoli_scelti(s: Session, dati: dict, attuali: set[int] = frozenset()) -> list[Ruolo]:
    """0.16: ruolo principale (`ruolo_id`) più eventuali altri (`altri_ruoli`), senza doppioni. Amministratore, se c'è,
    diventa il principale. I ruoli già assegnati e poi disattivati restano ammessi finché non si tolgono."""
    ids = [int(dati.get("ruolo_id") or 0)] + [int(x) for x in (dati.get("altri_ruoli") or []) if x]
    ids = list(dict.fromkeys(i for i in ids if i))
    if not ids:
        raise ErroreUtente("Scegli almeno un ruolo.")
    ruoli = [ruolo_o_404(s, i) if i in attuali else _ruolo_assegnabile(s, i) for i in ids]
    ruoli.sort(key=lambda r: not r.di_sistema)
    return ruoli


# ---------------------------------------------------------------- controlli


def _controlla_versione(oggetto, versione: int | None) -> None:  # noqa: ANN001
    if versione is not None and oggetto.versione != versione:
        raise Conflitto()


def _normalizza_username(username: str) -> str:
    u = (username or "").strip().lower()
    if not RE_USERNAME.match(u):
        raise ErroreUtente("Nome utente non valido: usa da 3 a 60 caratteri tra lettere minuscole, numeri, punto, trattino.")
    return u


def _controlla_email(email: str) -> str:
    e = (email or "").strip()
    if e and not RE_EMAIL.match(e):
        raise ErroreUtente("Indirizzo email non valido: controlla che sia nella forma nome@dominio.it.")
    return e


def _amministratori_attivi(s: Session, escluso_id: int | None = None) -> int:
    q = select(func.count()).select_from(Utente).join(Ruolo).where(Utente.attivo.is_(True), Ruolo.di_sistema.is_(True))
    if escluso_id is not None:
        q = q.where(Utente.id != escluso_id)
    return s.execute(q).scalar() or 0


def _ruolo_assegnabile(s: Session, ruolo_id: int) -> Ruolo:
    r = ruolo_o_404(s, ruolo_id)
    if not r.attivo:
        raise ErroreUtente(f"Il ruolo «{r.nome}» è disattivato: riattivalo o scegline un altro.")
    return r


# ---------------------------------------------------------------- utenti


def crea_primo_amministratore(s: Session, cfg: Config, username: str, nome: str, password: str) -> Utente:
    if not primo_avvio_necessario(s):
        raise ErroreUtente("Il programma è già stato configurato: accedi con il tuo utente.")
    username = _normalizza_username(username)
    if not (nome or "").strip():
        raise ErroreUtente("Scrivi nome e cognome dell'amministratore.")
    errore = controlla_password_nuova(password, cfg.lunghezza_minima_password, username)
    if errore:
        raise ErroreUtente(errore)
    admin = s.execute(select(Ruolo).where(Ruolo.codice == "amministratore")).scalar_one()
    u = Utente(username=username, nome=nome.strip(), ruolo_id=admin.id, password_hash=hash_password(password, cfg.iterazioni_password))
    s.add(u)
    s.flush()
    registro.scrivi(s, utente=u, azione="utente.primo_avvio", oggetto_tipo="utente", oggetto_id=u.id,
                    descrizione=f"Primo avvio: creato l'amministratore «{u.username}»")
    return u


def crea_utente(s: Session, cfg: Config, attore: Attore, dati: dict) -> tuple[Utente, str]:
    username = _normalizza_username(dati.get("username", ""))
    if s.execute(select(Utente).where(Utente.username == username)).scalar():
        raise ErroreUtente(f"Esiste già un utente «{username}»: scegli un altro nome utente.")
    nome = (dati.get("nome") or "").strip()
    if not nome:
        raise ErroreUtente("Scrivi nome e cognome dell'utente.")
    ruoli = _ruoli_scelti(s, dati)
    ruolo = ruoli[0]
    provvisoria = password_temporanea()
    u = Utente(
        username=username,
        nome=nome,
        email=_controlla_email(dati.get("email", "")),
        ruolo_id=ruolo.id,
        password_hash=hash_password(provvisoria, cfg.iterazioni_password),
        cambio_password_richiesto=True,
    )
    u.altri_ruoli = ruoli[1:]
    s.add(u)
    s.flush()
    registro.scrivi(s, utente=attore, azione="utente.crea", oggetto_tipo="utente", oggetto_id=u.id,
                    descrizione=f"Creato l'utente «{u.username}» ({u.nome}) con ruolo «{' + '.join(r.nome for r in ruoli)}»",
                    dettagli={"dopo": dati_utente(u)})
    return u, provvisoria


def modifica_utente(s: Session, attore: Attore, utente_id: int, dati: dict) -> Utente:
    u = utente_o_404(s, utente_id)
    _controlla_versione(u, dati.get("versione"))
    prima = dati_utente(u)
    nome = (dati.get("nome") or "").strip()
    if not nome:
        raise ErroreUtente("Scrivi nome e cognome dell'utente.")
    ruoli = _ruoli_scelti(s, dati, {r.id for r in ruoli_di(u)})
    nuovo_ruolo = ruoli[0]
    if u.ruolo.di_sistema and not nuovo_ruolo.di_sistema and u.attivo and _amministratori_attivi(s, escluso_id=u.id) == 0:
        raise ErroreUtente("È l'ultimo amministratore attivo: prima assegna il ruolo Amministratore a un altro utente.")
    u.nome = nome
    u.email = _controlla_email(dati.get("email", ""))
    u.ruolo_id = nuovo_ruolo.id
    u.ruolo = nuovo_ruolo
    u.altri_ruoli = ruoli[1:]
    u.versione += 1
    s.flush()
    diff = registro.differenze(prima, dati_utente(u))
    if diff:
        registro.scrivi(s, utente=attore, azione="utente.modifica", oggetto_tipo="utente", oggetto_id=u.id,
                        descrizione=f"Modificato l'utente «{u.username}»: " + ", ".join(diff), dettagli={"modifiche": diff})
    return u


def imposta_attivo(s: Session, attore: Attore, utente_id: int, attivo: bool, versione: int | None) -> Utente:
    u = utente_o_404(s, utente_id)
    _controlla_versione(u, versione)
    if u.attivo == attivo:
        return u
    if not attivo:
        if u.id == attore.id:
            raise ErroreUtente("Non puoi disattivare te stesso.")
        if u.ruolo.di_sistema and _amministratori_attivi(s, escluso_id=u.id) == 0:
            raise ErroreUtente("È l'ultimo amministratore attivo: non si può disattivare.")
        s.query(Sessione).filter(Sessione.utente_id == u.id).delete()
    else:
        _ruolo_assegnabile(s, u.ruolo_id)
    u.attivo = attivo
    u.versione += 1
    registro.scrivi(s, utente=attore, azione="utente.riattiva" if attivo else "utente.disattiva", oggetto_tipo="utente",
                    oggetto_id=u.id, descrizione=f"{'Riattivato' if attivo else 'Disattivato'} l'utente «{u.username}»")
    return u


def reimposta_password(s: Session, cfg: Config, attore: Attore, utente_id: int) -> str:
    u = utente_o_404(s, utente_id)
    provvisoria = password_temporanea()
    u.password_hash = hash_password(provvisoria, cfg.iterazioni_password)
    u.cambio_password_richiesto = True
    u.tentativi_falliti = 0
    u.bloccato_fino = None
    u.versione += 1
    s.query(Sessione).filter(Sessione.utente_id == u.id).delete()
    registro.scrivi(s, utente=attore, azione="utente.password_reimpostata", oggetto_tipo="utente", oggetto_id=u.id,
                    descrizione=f"Reimpostata la password dell'utente «{u.username}» (provvisoria, da cambiare al primo accesso)")
    return provvisoria


def sblocca(s: Session, attore: Attore, utente_id: int) -> Utente:
    u = utente_o_404(s, utente_id)
    u.tentativi_falliti = 0
    u.bloccato_fino = None
    u.versione += 1
    registro.scrivi(s, utente=attore, azione="utente.sblocca", oggetto_tipo="utente", oggetto_id=u.id,
                    descrizione=f"Sbloccato l'utente «{u.username}» dopo i tentativi di accesso falliti")
    return u


def cambia_propria_password(s: Session, cfg: Config, utente_id: int, attuale: str, nuova: str, impronta_sessione: str) -> None:
    from ...core.sicurezza import verifica_password

    u = utente_o_404(s, utente_id)
    if not verifica_password(attuale or "", u.password_hash):
        raise ErroreUtente("La password attuale non è corretta.")
    errore = controlla_password_nuova(nuova or "", cfg.lunghezza_minima_password, u.username)
    if errore:
        raise ErroreUtente(errore)
    if attuale == nuova:
        raise ErroreUtente("La nuova password deve essere diversa da quella attuale.")
    u.password_hash = hash_password(nuova, cfg.iterazioni_password)
    u.cambio_password_richiesto = False
    u.versione += 1
    # Le altre sessioni aperte dello stesso utente vengono chiuse.
    s.query(Sessione).filter(Sessione.utente_id == u.id, Sessione.impronta != impronta_sessione).delete()
    registro.scrivi(s, utente=u, azione="utente.cambio_password", oggetto_tipo="utente", oggetto_id=u.id,
                    descrizione=f"L'utente «{u.username}» ha cambiato la propria password")


MISURE_TESTO = {"normale": "Normale", "grande": "Grande"}


def imposta_testo(s: Session, utente_id: int, misura: str) -> None:
    """Misura del testo scelta dall'utente per sé (D57)."""
    if misura not in MISURE_TESTO:
        raise ErroreUtente("Misura del testo non valida.")
    u = utente_o_404(s, utente_id)
    if u.testo == misura:
        return
    vecchia = u.testo
    u.testo = misura
    u.versione += 1
    registro.scrivi(s, utente=u, azione="utente.misura_testo", oggetto_tipo="utente", oggetto_id=u.id,
                    descrizione=f"«{u.username}» ha scelto il testo {MISURE_TESTO[misura].lower()}",
                    dettagli={"prima": vecchia, "dopo": misura})


def utente_bloccato(u: Utente) -> int:
    """Minuti di blocco rimanenti (0 se non bloccato)."""
    if u.bloccato_fino and u.bloccato_fino > adesso():
        return max(1, int((u.bloccato_fino - adesso()).total_seconds() // 60) + 1)
    return 0


def registra_tentativo_fallito(s: Session, cfg: Config, u: Utente) -> None:
    u.tentativi_falliti += 1
    if u.tentativi_falliti >= cfg.tentativi_prima_del_blocco:
        u.bloccato_fino = adesso() + timedelta(minutes=cfg.minuti_blocco)
        u.tentativi_falliti = 0
        registro.scrivi(s, utente=None, azione="accesso.blocco", oggetto_tipo="utente", oggetto_id=u.id,
                        descrizione=f"Utente «{u.username}» bloccato per {cfg.minuti_blocco} minuti dopo "
                                    f"{cfg.tentativi_prima_del_blocco} password sbagliate")


# ---------------------------------------------------------------- ruoli


def _dati_ruolo(r: Ruolo) -> dict:
    return {"nome": r.nome, "descrizione": r.descrizione, "attivo": r.attivo, "attività": r.attivita or "tutte"}


def _attivita(valore, attuale: str = "") -> str:
    """Testo normalizzato «DPR», «DM», «DPR,DM» o "" (comune)."""
    if valore is None:
        return attuale
    if not isinstance(valore, (list, str)):
        raise ErroreUtente("Attività del ruolo non valida.")
    scelte = valore.split(",") if isinstance(valore, str) else valore
    if any(x not in ("DPR", "DM", "") for x in scelte):
        raise ErroreUtente("Attività del ruolo: scegli AD_DPR, AD_DM, entrambe o nessuna (ruolo comune).")
    return ",".join(x for x in ("DPR", "DM") if x in scelte)


def controlla_attivita_rt(attivita: str, permessi: set[str], nome: str) -> None:
    """R132: chi affida o riesamina i verbali (RT) ha una sola attività; un ruolo comune non può farlo."""
    if permessi & DA_RT and len(attivita_di(attivita)) != 1:
        raise ErroreUtente(f"Il ruolo «{nome}» affida o riesamina le verifiche: è un ruolo da responsabile tecnico e deve "
                           "avere una sola attività (AD_DPR oppure AD_DM). Un verificatore può avere entrambe.")


def _codice_da_nome(s: Session, nome: str) -> str:
    base = re.sub(r"[^a-z0-9]+", "_", nome.lower()).strip("_")[:30] or "ruolo"
    codice, n = base, 2
    while s.execute(select(Ruolo).where(Ruolo.codice == codice)).scalar():
        codice, n = f"{base}_{n}", n + 1
    return codice


def crea_ruolo(s: Session, attore: Attore, dati: dict) -> Ruolo:
    nome = (dati.get("nome") or "").strip()
    if not nome:
        raise ErroreUtente("Scrivi il nome del ruolo.")
    if s.execute(select(Ruolo).where(func.lower(Ruolo.nome) == nome.lower())).scalar():
        raise ErroreUtente(f"Esiste già un ruolo «{nome}».")
    r = Ruolo(codice=_codice_da_nome(s, nome), nome=nome, descrizione=(dati.get("descrizione") or "").strip(),
              attivita=_attivita(dati.get("attivita")))
    s.add(r)
    s.flush()
    copiati: list[str] = []
    if dati.get("copia_da"):
        origine = ruolo_o_404(s, int(dati["copia_da"]))
        copiati = sorted(permessi_di_ruolo(s, origine))
        if not dati.get("attivita") and not origine.di_sistema:   # nessuna scelta: quella del ruolo copiato
            r.attivita = origine.attivita
        controlla_attivita_rt(r.attivita, set(copiati), r.nome)
        for codice in copiati:
            s.add(RuoloPermesso(ruolo_id=r.id, permesso_codice=codice))
    registro.scrivi(s, utente=attore, azione="ruolo.crea", oggetto_tipo="ruolo", oggetto_id=r.id,
                    descrizione=f"Creato il ruolo «{r.nome}»" + (f" copiando {len(copiati)} permessi" if copiati else ""),
                    dettagli={"dopo": _dati_ruolo(r), "permessi": copiati})
    return r


def modifica_ruolo(s: Session, attore: Attore, ruolo_id: int, dati: dict) -> Ruolo:
    r = ruolo_o_404(s, ruolo_id)
    _controlla_versione(r, dati.get("versione"))
    if r.di_sistema:
        raise ErroreUtente("Il ruolo Amministratore non si modifica: ha sempre tutti i permessi.")
    prima = _dati_ruolo(r)
    nome = (dati.get("nome") or "").strip()
    if not nome:
        raise ErroreUtente("Scrivi il nome del ruolo.")
    altro = s.execute(select(Ruolo).where(func.lower(Ruolo.nome) == nome.lower(), Ruolo.id != r.id)).scalar()
    if altro:
        raise ErroreUtente(f"Esiste già un ruolo «{nome}».")
    attivo = bool(dati.get("attivo", r.attivo))
    if r.attivo and not attivo:
        utenti_attivi = s.execute(select(func.count()).select_from(Utente).where(_ha_ruolo(r.id), Utente.attivo.is_(True))).scalar()
        if utenti_attivi:
            raise ErroreUtente(f"Il ruolo «{r.nome}» è assegnato a {utenti_attivi} utenti attivi: assegna loro un altro ruolo prima di disattivarlo.")
    attivita = _attivita(dati.get("attivita"), r.attivita)
    controlla_attivita_rt(attivita, set(s.execute(select(RuoloPermesso.permesso_codice).where(RuoloPermesso.ruolo_id == r.id)).scalars()), nome)
    r.nome, r.descrizione, r.attivo, r.attivita = nome, (dati.get("descrizione") or "").strip(), attivo, attivita
    r.versione += 1
    diff = registro.differenze(prima, _dati_ruolo(r))
    if diff:
        registro.scrivi(s, utente=attore, azione="ruolo.modifica", oggetto_tipo="ruolo", oggetto_id=r.id,
                        descrizione=f"Modificato il ruolo «{r.nome}»: " + ", ".join(diff), dettagli={"modifiche": diff})
    return r


def elimina_ruolo(s: Session, attore: Attore, ruolo_id: int) -> None:
    r = ruolo_o_404(s, ruolo_id)
    if r.di_sistema:
        raise ErroreUtente("Il ruolo Amministratore non si elimina.")
    usato = s.execute(select(func.count()).select_from(Utente).where(_ha_ruolo(r.id))).scalar()
    if usato:
        raise ErroreUtente(f"Il ruolo «{r.nome}» è (o è stato) assegnato a {usato} utenti: non si elimina, si può disattivare.")
    nome = r.nome
    s.delete(r)
    registro.scrivi(s, utente=attore, azione="ruolo.elimina", oggetto_tipo="ruolo", oggetto_id=ruolo_id,
                    descrizione=f"Eliminato il ruolo «{nome}» (mai assegnato a nessun utente)")


def salva_permessi_ruolo(s: Session, attore: Attore, ruolo_id: int, codici: list[str], versione: int | None) -> Ruolo:
    r = ruolo_o_404(s, ruolo_id)
    _controlla_versione(r, versione)
    if r.di_sistema:
        raise ErroreUtente("Il ruolo Amministratore ha sempre tutti i permessi: non si modifica.")
    sconosciuti = [c for c in codici if c not in PER_CODICE]
    if sconosciuti:
        raise ErroreUtente("Permessi sconosciuti: " + ", ".join(sconosciuti) + ". Ricarica la pagina.")
    prima = set(s.execute(select(RuoloPermesso.permesso_codice).where(RuoloPermesso.ruolo_id == r.id)).scalars())
    dopo = set(codici)
    if prima == dopo:
        return r
    controlla_attivita_rt(r.attivita, espandi(dopo), r.nome)
    for c in prima - dopo:
        s.query(RuoloPermesso).filter(RuoloPermesso.ruolo_id == r.id, RuoloPermesso.permesso_codice == c).delete()
    for c in dopo - prima:
        s.add(RuoloPermesso(ruolo_id=r.id, permesso_codice=c))
    r.versione += 1
    aggiunti, tolti = sorted(dopo - prima), sorted(prima - dopo)
    descr = [PER_CODICE[c].descrizione for c in aggiunti]
    descr_tolti = [PER_CODICE[c].descrizione for c in tolti]
    testo = f"Permessi del ruolo «{r.nome}»"
    if aggiunti:
        testo += " · aggiunti: " + "; ".join(descr)
    if tolti:
        testo += " · tolti: " + "; ".join(descr_tolti)
    registro.scrivi(s, utente=attore, azione="ruolo.permessi", oggetto_tipo="ruolo", oggetto_id=r.id, descrizione=testo,
                    dettagli={"aggiunti": aggiunti, "tolti": tolti, "prima": sorted(prima), "dopo": sorted(dopo)})
    return r
