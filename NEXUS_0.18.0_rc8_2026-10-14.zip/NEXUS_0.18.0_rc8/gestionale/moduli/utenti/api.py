"""Interfaccia JSON: accesso, profilo, utenti, ruoli, permessi."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Request, Response
from pydantic import BaseModel, Field
from sqlalchemy import select

from ...core.db import Archivio
from ...core.errori import ErroreUtente
from ...core.permessi import CATALOGO, GESTIONE_PER_ATTIVITA, INCLUDE
from ...web.dipendenze import COOKIE_SESSIONE, archivio, controlla_origine, ip, richiede, utente
from . import accesso, servizio
from .accesso import UtenteCorrente
from .modelli import Ruolo, RuoloPermesso, Utente

router = APIRouter(prefix="/api")


class DatiAccesso(BaseModel):
    username: str = Field(max_length=60)
    password: str = Field(max_length=200)


class DatiPrimoAvvio(DatiAccesso):
    nome: str = Field(max_length=120)


class DatiCambioPassword(BaseModel):
    attuale: str = Field(max_length=200)
    nuova: str = Field(max_length=200)


class DatiUtente(BaseModel):
    username: str = Field(default="", max_length=60)
    nome: str = Field(max_length=120)
    email: str = Field(default="", max_length=200)
    ruolo_id: int
    altri_ruoli: list[int] = Field(default_factory=list)   # 0.16: più ruoli per utente
    versione: int | None = None
    dati_tecnici: dict | None = None  # C25: salvataggio atomico di tutta la scheda


class DatiVersione(BaseModel):
    versione: int | None = None


class DatiRuolo(BaseModel):
    nome: str = Field(max_length=80)
    descrizione: str = Field(default="", max_length=500)
    attivo: bool = True
    copia_da: int | None = None
    attivita: list[str] | None = None   # R132: ["DPR"], ["DM"], ["DPR", "DM"] o [] (ruolo comune)
    versione: int | None = None


class DatiPermessiRuolo(BaseModel):
    ruolo_id: int
    permessi: list[str]
    versione: int | None = None


def _imposta_cookie(request: Request, risposta: Response, codice: str) -> None:
    cfg = request.app.state.archivio.cfg
    risposta.set_cookie(COOKIE_SESSIONE, codice, httponly=True, samesite="strict", secure=cfg.https,
                        max_age=cfg.ore_durata_massima_sessione * 3600, path="/")


# ---------------------------------------------------------------- accesso


@router.post("/accesso")
def entra(dati: DatiAccesso, request: Request, risposta: Response, arc: Archivio = Depends(archivio)) -> dict:
    controlla_origine(request)
    codice = accesso.accedi(arc, dati.username, dati.password, ip(request))
    _imposta_cookie(request, risposta, codice)
    return {"ok": True}


@router.post("/primo-avvio")
def primo_avvio(dati: DatiPrimoAvvio, request: Request, risposta: Response, arc: Archivio = Depends(archivio)) -> dict:
    controlla_origine(request)
    with arc.scrittura() as s:
        servizio.crea_primo_amministratore(s, arc.cfg, dati.username, dati.nome, dati.password)
    codice = accesso.accedi(arc, dati.username, dati.password, ip(request))
    _imposta_cookie(request, risposta, codice)
    return {"ok": True}


@router.post("/uscita")
def esci(request: Request, risposta: Response, _u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    accesso.esci(arc, request.cookies.get(COOKIE_SESSIONE))
    risposta.delete_cookie(COOKIE_SESSIONE, path="/")
    return {"ok": True}


@router.get("/io")
def io(u: UtenteCorrente = Depends(utente)) -> dict:
    return u.per_interfaccia()


class DatiTesto(BaseModel):
    misura: str = Field(max_length=10)


@router.put("/io/testo")
def cambia_testo(dati: DatiTesto, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        servizio.imposta_testo(s, u.id, dati.misura)
    return {"ok": True, "testo": dati.misura}


@router.post("/io/password")
def cambia_password(dati: DatiCambioPassword, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        servizio.cambia_propria_password(s, arc.cfg, u.id, dati.attuale, dati.nuova, u.impronta_sessione)
    return {"ok": True}


# ---------------------------------------------------------------- utenti


def _utente_json(x: Utente) -> dict:
    ruoli = servizio.ruoli_di(x)
    return {"id": x.id, "username": x.username, "nome": x.nome, "email": x.email, "ruolo_id": x.ruolo_id,
            "ruoli_id": [r.id for r in ruoli], "ruolo": " + ".join(r.nome for r in ruoli), "attivo": x.attivo, "versione": x.versione,
            "bloccato_minuti": servizio.utente_bloccato(x), "cambio_password_richiesto": x.cambio_password_richiesto}


@router.get("/utenti/{utente_id}")
def leggi_utente(utente_id: int, _u: UtenteCorrente = Depends(richiede("sistema.utenti")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        return _utente_json(servizio.utente_o_404(s, utente_id))


@router.post("/utenti")
def crea_utente(dati: DatiUtente, u: UtenteCorrente = Depends(richiede("sistema.utenti")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        nuovo, provvisoria = servizio.crea_utente(s, arc.cfg, u.come_attore(), dati.model_dump())
        risultato = _utente_json(nuovo)
    risultato["password_provvisoria"] = provvisoria
    return risultato


@router.put("/utenti/{utente_id}")
def modifica_utente(utente_id: int, dati: DatiUtente, u: UtenteCorrente = Depends(richiede("sistema.utenti")),
                    arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        x = servizio.modifica_utente(s, u.come_attore(), utente_id, dati.model_dump())
        if dati.dati_tecnici is not None:
            from ..dm import documenti
            documenti.salva_profilo(s, u, utente_id, {**dati.dati_tecnici, "versione": x.versione})
        return _utente_json(x)


@router.post("/utenti/{utente_id}/disattiva")
def disattiva(utente_id: int, dati: DatiVersione, u: UtenteCorrente = Depends(richiede("sistema.utenti")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return _utente_json(servizio.imposta_attivo(s, u.come_attore(), utente_id, False, dati.versione))


@router.post("/utenti/{utente_id}/riattiva")
def riattiva(utente_id: int, dati: DatiVersione, u: UtenteCorrente = Depends(richiede("sistema.utenti")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return _utente_json(servizio.imposta_attivo(s, u.come_attore(), utente_id, True, dati.versione))


@router.post("/utenti/{utente_id}/password")
def reimposta_password(utente_id: int, u: UtenteCorrente = Depends(richiede("sistema.utenti")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        provvisoria = servizio.reimposta_password(s, arc.cfg, u.come_attore(), utente_id)
    return {"password_provvisoria": provvisoria}


@router.post("/utenti/{utente_id}/sblocca")
def sblocca(utente_id: int, u: UtenteCorrente = Depends(richiede("sistema.utenti")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return _utente_json(servizio.sblocca(s, u.come_attore(), utente_id))


# ---------------------------------------------------------------- ruoli e permessi


def _ruolo_json(r: Ruolo) -> dict:
    return {"id": r.id, "codice": r.codice, "nome": r.nome, "descrizione": r.descrizione, "attivo": r.attivo,
            "di_sistema": r.di_sistema, "versione": r.versione, "attivita": [x for x in ("DPR", "DM") if x in (r.attivita or "").split(",")]}


@router.get("/ruoli")
def elenco_ruoli(u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> list[dict]:
    if not (u.puo("sistema.utenti") or u.puo("sistema.ruoli")):
        raise ErroreUtente("Non hai il permesso per vedere i ruoli.", 403)
    with arc.lettura() as s:
        return [_ruolo_json(r) for r in s.execute(select(Ruolo).order_by(Ruolo.di_sistema.desc(), Ruolo.nome)).scalars()]


@router.post("/ruoli")
def crea_ruolo(dati: DatiRuolo, u: UtenteCorrente = Depends(richiede("sistema.ruoli")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return _ruolo_json(servizio.crea_ruolo(s, u.come_attore(), dati.model_dump()))


@router.put("/ruoli/{ruolo_id}")
def modifica_ruolo(ruolo_id: int, dati: DatiRuolo, u: UtenteCorrente = Depends(richiede("sistema.ruoli")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return _ruolo_json(servizio.modifica_ruolo(s, u.come_attore(), ruolo_id, dati.model_dump()))


@router.delete("/ruoli/{ruolo_id}")
def elimina_ruolo(ruolo_id: int, u: UtenteCorrente = Depends(richiede("sistema.ruoli")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        servizio.elimina_ruolo(s, u.come_attore(), ruolo_id)
    return {"ok": True}


@router.get("/permessi/matrice")
def matrice(_u: UtenteCorrente = Depends(richiede("sistema.ruoli")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        ruoli = list(s.execute(select(Ruolo).order_by(Ruolo.di_sistema.desc(), Ruolo.id)).scalars())
        assegnati: dict[int, list[str]] = {r.id: [] for r in ruoli}
        for rp in s.execute(select(RuoloPermesso)).scalars():
            assegnati.setdefault(rp.ruolo_id, []).append(rp.permesso_codice)
        return {
            "ruoli": [_ruolo_json(r) | {"permessi": sorted(assegnati.get(r.id, []))} for r in ruoli],
            "permessi": [{"codice": m.codice, "area": m.area, "descrizione": m.descrizione, "disponibile": m.disponibile,
                          "comprende": list(INCLUDE.get(m.codice, ())), "attivita": GESTIONE_PER_ATTIVITA.get(m.codice, "")} for m in CATALOGO],
        }


@router.put("/permessi/ruolo")
def salva_permessi(dati: DatiPermessiRuolo, u: UtenteCorrente = Depends(richiede("sistema.ruoli")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        r = servizio.salva_permessi_ruolo(s, u.come_attore(), dati.ruolo_id, dati.permessi, dati.versione)
        return _ruolo_json(r)
