"""Utenti, ruoli, permessi e sessioni (decisioni D22, D24, D37)."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ...core.db import Base, adesso


class Ruolo(Base):
    __tablename__ = "ruoli"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    codice: Mapped[str] = mapped_column(String(40), unique=True)
    nome: Mapped[str] = mapped_column(String(80), unique=True)
    descrizione: Mapped[str] = mapped_column(Text, default="")
    attivo: Mapped[bool] = mapped_column(Boolean, default=True)
    # Il ruolo Amministratore è «di sistema»: ha sempre tutti i permessi e non si modifica,
    # così nessuno può restare chiuso fuori dal programma.
    di_sistema: Mapped[bool] = mapped_column(Boolean, default=False)
    # R132: attività dei permessi tecnici ("DPR", "DM", "DPR,DM"); vuoto = ruolo comune (segreteria, amministratore)
    attivita: Mapped[str] = mapped_column(String(20), default="", server_default="")
    creato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    versione: Mapped[int] = mapped_column(Integer, default=1)

    permessi: Mapped[list["RuoloPermesso"]] = relationship(back_populates="ruolo", cascade="all, delete-orphan")


class Permesso(Base):
    """Micro-attività (D24). L'elenco vive nel codice (core/permessi.py) e viene allineato all'avvio."""

    __tablename__ = "permessi"

    codice: Mapped[str] = mapped_column(String(60), primary_key=True)
    area: Mapped[str] = mapped_column(String(40))
    descrizione: Mapped[str] = mapped_column(String(200))
    ordine: Mapped[int] = mapped_column(Integer, default=0)
    disponibile: Mapped[bool] = mapped_column(Boolean, default=False)  # False = funzione «in arrivo»


class RuoloPermesso(Base):
    __tablename__ = "ruoli_permessi"

    ruolo_id: Mapped[int] = mapped_column(ForeignKey("ruoli.id", ondelete="CASCADE"), primary_key=True)
    permesso_codice: Mapped[str] = mapped_column(ForeignKey("permessi.codice", ondelete="CASCADE"), primary_key=True)

    ruolo: Mapped[Ruolo] = relationship(back_populates="permessi")


class Utente(Base):
    __tablename__ = "utenti"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(60), unique=True)  # sempre minuscolo
    nome: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(200), default="")
    ruolo_id: Mapped[int] = mapped_column(ForeignKey("ruoli.id", ondelete="RESTRICT"), index=True)
    attivo: Mapped[bool] = mapped_column(Boolean, default=True)
    password_hash: Mapped[str] = mapped_column(String(300))
    cambio_password_richiesto: Mapped[bool] = mapped_column(Boolean, default=False)
    testo: Mapped[str] = mapped_column(String(10), default="normale", server_default="normale")  # misura del testo (D57)
    tentativi_falliti: Mapped[int] = mapped_column(Integer, default=0)
    bloccato_fino: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    ultimo_accesso: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    creato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    versione: Mapped[int] = mapped_column(Integer, default=1)

    ruolo: Mapped[Ruolo] = relationship()
    # 0.16 (Federico, 12/10/2026, 17:58): più ruoli per utente, a caselle (es. RT DPR + Verificatore DM). `ruolo` resta il
    # principale (quello mostrato negli elenchi); gli altri sono qui. Ogni permesso vale nell'attività del ruolo che lo dà.
    altri_ruoli: Mapped[list[Ruolo]] = relationship(secondary="utenti_ruoli", order_by="Ruolo.nome")
    dati_tecnici_json: Mapped[str] = mapped_column(Text, default="{}", server_default="{}")


class UtenteRuolo(Base):
    """Ruoli aggiuntivi di un utente (oltre al principale `utenti.ruolo_id`)."""

    __tablename__ = "utenti_ruoli"

    utente_id: Mapped[int] = mapped_column(ForeignKey("utenti.id", ondelete="CASCADE"), primary_key=True)
    ruolo_id: Mapped[int] = mapped_column(ForeignKey("ruoli.id", ondelete="RESTRICT"), primary_key=True, index=True)


def ruoli_di(u: "Utente") -> list[Ruolo]:
    """Tutti i ruoli dell'utente, il principale per primo."""
    return [u.ruolo] + [r for r in u.altri_ruoli if r.id != u.ruolo_id]


class Sessione(Base):
    __tablename__ = "sessioni"

    # Nel database si salva solo l'impronta del codice di sessione, mai il codice stesso.
    impronta: Mapped[str] = mapped_column(String(64), primary_key=True)
    utente_id: Mapped[int] = mapped_column(ForeignKey("utenti.id", ondelete="CASCADE"), index=True)
    csrf: Mapped[str] = mapped_column(String(64))
    creata_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    ultima_attivita: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    scade_il: Mapped[datetime] = mapped_column(DateTime)
    indirizzo_ip: Mapped[str] = mapped_column(String(60), default="")

    utente: Mapped[Utente] = relationship()
