"""Accesso: login, sessioni, blocco dopo tentativi falliti.

- Il browser riceve un codice di sessione casuale in un cookie «HttpOnly» e «SameSite=Strict»;
  nel database si salva solo l'impronta del codice.
- La sessione scade dopo `minuti_inattivita` senza attività e comunque dopo `ore_durata_massima_sessione`.
- Ogni sessione ha un proprio codice anti-contraffazione (CSRF) da rimandare nelle richieste che modificano dati.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta

from sqlalchemy import delete, select

from ...core.db import Archivio, adesso
from ...core.errori import ErroreUtente, NonAutenticato
from ...core.permessi import GESTIONE_PER_ATTIVITA, TECNICI, attivita_di
from ...core.sicurezza import codice_casuale, da_aggiornare, hash_password, impronta_testo, verifica_password
from ..registro import servizio as registro
from . import servizio
from .modelli import Sessione, Utente, ruoli_di

MESSAGGIO_CREDENZIALI = "Nome utente o password non corretti."
_FINTI: dict[int, str] = {}


def _hash_finto(iterazioni: int) -> str:
    if iterazioni not in _FINTI:
        _FINTI[iterazioni] = hash_password("utente-inesistente", iterazioni)
    return _FINTI[iterazioni]


@dataclass
class UtenteCorrente:
    id: int
    username: str
    nome: str
    ruolo: str
    amministratore: bool
    permessi: set[str] = field(default_factory=set)
    csrf: str = ""
    impronta_sessione: str = ""
    cambio_password_richiesto: bool = False
    testo: str = "normale"
    ruolo_codice: str = ""
    attivita: frozenset = frozenset()   # R132: vuoto = tutte
    # 0.16: permessi per attività dei ruoli che li danno ("" = ruoli comuni, validi ovunque)
    per_attivita: dict = field(default_factory=dict)

    def puo(self, codice: str, attivita: str | None = None) -> bool:
        """La gestione di impianti/attrezzature implica sempre l'attività dell'oggetto (C20).
        Con `attivita` ("DPR"/"DM") un permesso tecnico vale solo se lo dà un ruolo di quell'attività (R132). Con più ruoli
        (0.16) conta il ruolo che dà il permesso: «RT DPR + Verificatore DM» riesamina nel DPR ma non nel DM."""
        if codice not in self.permessi:
            return False
        vincolata = GESTIONE_PER_ATTIVITA.get(codice)
        if vincolata:
            if attivita and attivita != vincolata:
                return False
            attivita = vincolata
        if not attivita or (codice not in TECNICI and not vincolata) or self.amministratore:
            return True
        if not self.per_attivita:  # compatibilità (utente costruito senza dettaglio per attività)
            return not (self.attivita and attivita not in self.attivita)
        return codice in self.per_attivita.get("", ()) or codice in self.per_attivita.get(attivita, ())

    def in_attivita(self, attivita: str) -> bool:
        return not self.attivita or attivita in self.attivita

    def come_attore(self) -> servizio.Attore:
        return servizio.Attore(id=self.id, nome=self.nome)

    def per_interfaccia(self) -> dict:
        return {
            "id": self.id,
            "username": self.username,
            "nome": self.nome,
            "ruolo": self.ruolo,
            "amministratore": self.amministratore,
            "permessi": sorted(c for c in self.permessi if self.puo(c)),
            "permessi_per_attivita": {a: sorted(c for c in self.permessi if self.puo(c, a)) for a in ("DPR", "DM")},
            "cambio_password_richiesto": self.cambio_password_richiesto,
            "testo": self.testo,
            "attivita": sorted(self.attivita),
        }


def accedi(archivio: Archivio, username: str, password: str, ip: str) -> str:
    """Verifica le credenziali e apre una sessione. Restituisce il codice di sessione per il cookie."""
    cfg = archivio.cfg
    username = (username or "").strip().lower()
    errore: ErroreUtente | None = None
    codice = ""
    with archivio.scrittura() as s:
        u = s.execute(select(Utente).where(Utente.username == username)).scalar()
        if u is None:
            verifica_password(password or "", _hash_finto(cfg.iterazioni_password))  # stesso tempo: non rivela se l'utente esiste
            errore = ErroreUtente(MESSAGGIO_CREDENZIALI, 401)
        elif minuti := servizio.utente_bloccato(u):
            errore = ErroreUtente(f"Troppi tentativi sbagliati: accesso bloccato. Riprova tra {minuti} minuti o chiedi all'amministratore di sbloccarti.", 423)
        elif not verifica_password(password or "", u.password_hash):
            servizio.registra_tentativo_fallito(s, cfg, u)  # resta salvato anche se l'accesso fallisce
            errore = ErroreUtente(MESSAGGIO_CREDENZIALI, 401)
        elif not u.attivo:
            errore = ErroreUtente("Questo utente è disattivato: chiedi all'amministratore.", 403)
        elif not u.ruolo.attivo:
            errore = ErroreUtente(f"Il ruolo «{u.ruolo.nome}» è disattivato: chiedi all'amministratore.", 403)
        if errore is None:
            codice = _apri_sessione(s, cfg, u, ip, password)
    if errore is not None:
        raise errore
    return codice


def _apri_sessione(s, cfg, u: Utente, ip: str, password: str) -> str:  # noqa: ANN001
    if da_aggiornare(u.password_hash, cfg.iterazioni_password):
        u.password_hash = hash_password(password, cfg.iterazioni_password)  # iterazioni aumentate
    u.tentativi_falliti = 0
    u.bloccato_fino = None
    ora = adesso()
    u.ultimo_accesso = ora
    codice = codice_casuale()
    s.execute(delete(Sessione).where(Sessione.scade_il < ora))  # pulizia delle sessioni scadute
    s.add(Sessione(
        impronta=impronta_testo(codice),
        utente_id=u.id,
        csrf=codice_casuale(24),
        creata_il=ora,
        ultima_attivita=ora,
        scade_il=ora + timedelta(hours=cfg.ore_durata_massima_sessione),
        indirizzo_ip=(ip or "")[:60],
    ))
    registro.scrivi(s, utente=u, azione="accesso.entrata", oggetto_tipo="utente", oggetto_id=u.id,
                    descrizione=f"Accesso di «{u.username}»", dettagli={"ip": ip})
    return codice


def leggi_sessione(archivio: Archivio, codice: str | None) -> UtenteCorrente:
    if not codice:
        raise NonAutenticato("Accedi per continuare.")
    cfg = archivio.cfg
    impronta = impronta_testo(codice)
    ora = adesso()
    with archivio.lettura() as s:
        sess = s.get(Sessione, impronta)
        if sess is None:
            raise NonAutenticato()
        u = sess.utente
        scaduta = sess.scade_il < ora or sess.ultima_attivita < ora - timedelta(minutes=cfg.minuti_inattivita)
        if scaduta or not u.attivo or not u.ruolo.attivo:
            da_chiudere = True
        else:
            da_chiudere = False
            ruoli = [r for r in ruoli_di(u) if r.attivo]
            per_attivita: dict[str, set] = {}
            for r in ruoli:
                for a in (attivita_di(r.attivita) or {""}):
                    per_attivita.setdefault(a, set()).update(servizio.permessi_di_ruolo(s, r))
            amministratore = any(r.di_sistema for r in ruoli)
            comuni = amministratore or any(not attivita_di(r.attivita) for r in ruoli)
            corrente = UtenteCorrente(
                id=u.id,
                username=u.username,
                nome=u.nome,
                ruolo=" + ".join(r.nome for r in ruoli),
                ruolo_codice=servizio.ruolo_vz(ruoli),
                attivita=frozenset() if comuni else frozenset().union(*(attivita_di(r.attivita) for r in ruoli)),
                amministratore=amministratore,
                permessi=set().union(*per_attivita.values()),
                per_attivita={k: frozenset(v) for k, v in per_attivita.items()},
                csrf=sess.csrf,
                impronta_sessione=impronta,
                cambio_password_richiesto=u.cambio_password_richiesto,
                testo=u.testo or "normale",
            )
            da_aggiornare_attivita = sess.ultima_attivita < ora - timedelta(seconds=60)
    if da_chiudere:
        with archivio.scrittura() as s:
            s.execute(delete(Sessione).where(Sessione.impronta == impronta))
        raise NonAutenticato()
    if da_aggiornare_attivita:  # si scrive al massimo una volta al minuto per sessione
        with archivio.scrittura() as s:
            sess = s.get(Sessione, impronta)
            if sess is not None:
                sess.ultima_attivita = ora
    return corrente


def esci(archivio: Archivio, codice: str | None) -> None:
    if not codice:
        return
    impronta = impronta_testo(codice)
    with archivio.scrittura() as s:
        sess = s.get(Sessione, impronta)
        if sess is not None:
            registro.scrivi(s, utente=sess.utente, azione="accesso.uscita", oggetto_tipo="utente", oggetto_id=sess.utente_id,
                            descrizione=f"Uscita di «{sess.utente.username}»")
            s.delete(sess)
