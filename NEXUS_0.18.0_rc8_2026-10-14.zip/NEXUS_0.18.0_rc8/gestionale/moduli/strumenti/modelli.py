"""Strumenti di misura di AD_DM e I&C (C16, 0.16): gli strumenti AD_DPR restano nel registro di VerbalizzAI."""

from __future__ import annotations

from datetime import date

from sqlalchemy import Boolean, CheckConstraint, Date, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ...core.db import Base
from ...core.modelli_comuni import Tracciato


class StrumentoMisura(Base, Tracciato):
    __tablename__ = "strumenti_misura"
    __table_args__ = (CheckConstraint("attivita IN ('DM','IEC')", name="attivita"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    attivita: Mapped[str] = mapped_column(String(4), index=True)
    denominazione: Mapped[str] = mapped_column(String(200))
    costruttore: Mapped[str] = mapped_column(String(120), default="")
    modello: Mapped[str] = mapped_column(String(120), default="")
    matricola: Mapped[str] = mapped_column(String(120), default="")
    campo_misura: Mapped[str] = mapped_column(String(200), default="")
    ente_taratura: Mapped[str] = mapped_column(String(200), default="")
    certificato: Mapped[str] = mapped_column(String(120), default="")
    data_taratura: Mapped[date | None] = mapped_column(Date)
    scadenza_taratura: Mapped[date | None] = mapped_column(Date, index=True)
    attivo: Mapped[bool] = mapped_column(Boolean, default=True)
    note: Mapped[str] = mapped_column(Text, default="")
