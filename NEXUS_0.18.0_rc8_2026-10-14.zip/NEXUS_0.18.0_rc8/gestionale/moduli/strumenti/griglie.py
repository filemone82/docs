"""Griglia degli strumenti di misura AD_DM e I&C (C16, 0.16)."""

from __future__ import annotations

from sqlalchemy import case, func, literal

from ...core.sql_portabile import oggi_italiano, data_tra_giorni, anno_dopo, giorni_fra, testi_uniti, json_testo
from ...core.griglia import Colonna, Griglia, registra
from .modelli import StrumentoMisura

OGGI = oggi_italiano()
STATO = case(
    (StrumentoMisura.scadenza_taratura.is_(None), literal("Senza scadenza")),
    (StrumentoMisura.scadenza_taratura < OGGI, literal("Scaduta")),
    (StrumentoMisura.scadenza_taratura <= data_tra_giorni(OGGI, 30), literal("Entro 30 giorni")),
    else_=literal("In corso"))

registra(Griglia(
    codice="strumenti_misura", titolo="Strumenti di misura", permesso="strumenti.vedere", da=lambda: StrumentoMisura.__table__,
    ordine_predefinito=[("denominazione", "asc")],
    ambito=lambda a: StrumentoMisura.attivita == a,
    colonne=[
        Colonna("id", "N.", "numero", StrumentoMisura.id, visibile=False, larghezza=70),
        Colonna("denominazione", "Strumento", "testo", StrumentoMisura.denominazione, larghezza=220),
        Colonna("costruttore", "Costruttore", "testo", StrumentoMisura.costruttore, larghezza=150),
        Colonna("modello", "Modello", "testo", StrumentoMisura.modello, larghezza=130),
        Colonna("matricola", "Matricola", "testo", StrumentoMisura.matricola, larghezza=130),
        Colonna("campo_misura", "Campo di misura", "testo", StrumentoMisura.campo_misura, larghezza=150, visibile=False),
        Colonna("ente_taratura", "Ente di taratura", "testo", StrumentoMisura.ente_taratura, larghezza=160, visibile=False),
        Colonna("certificato", "Certificato", "testo", StrumentoMisura.certificato, larghezza=120),
        Colonna("data_taratura", "Taratura", "data", StrumentoMisura.data_taratura, larghezza=110),
        Colonna("scadenza_taratura", "Scadenza", "data", StrumentoMisura.scadenza_taratura, larghezza=110),
        Colonna("stato", "Stato", "elenco", STATO, larghezza=120, opzioni=("Scaduta", "Entro 30 giorni", "In corso", "Senza scadenza")),
        Colonna("attivo", "In uso", "booleano", StrumentoMisura.attivo, larghezza=80),
        Colonna("attivita", "Attività", "elenco", StrumentoMisura.attivita, larghezza=80, opzioni=("DM", "IEC"), visibile=False),
    ],
))
