"""Strumenti di misura AD_DM e I&C: scheda, controlli, registro (C16, 0.16)."""

from __future__ import annotations

from datetime import date
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ...core.db import adesso
from ...core.errori import Conflitto, ErroreUtente, NonTrovato
from ..registro import servizio as registro
from .modelli import StrumentoMisura

TESTI = {"denominazione": 200, "costruttore": 120, "modello": 120, "matricola": 120, "campo_misura": 200,
         "ente_taratura": 200, "certificato": 120, "note": 4000}
NOMI = {"DM": "AD_DM", "IEC": "I&C"}


def json_strumento(x: StrumentoMisura) -> dict:
    return {"id": x.id, "attivita": x.attivita, **{k: getattr(x, k) for k in TESTI},
            "data_taratura": x.data_taratura.isoformat() if x.data_taratura else None,
            "scadenza_taratura": x.scadenza_taratura.isoformat() if x.scadenza_taratura else None,
            "attivo": x.attivo, "versione": x.versione}


def _data(v: Any, nome: str) -> date | None:
    if v in (None, ""):
        return None
    try:
        return date.fromisoformat(str(v))
    except ValueError:
        raise ErroreUtente(f"{nome}: data non valida.") from None


def leggi(s: Session, id: int, attivita: str) -> StrumentoMisura:
    x = s.get(StrumentoMisura, id)
    if x is None or x.attivita != attivita:
        raise NonTrovato("Strumento non trovato.")
    return x


def salva(s: Session, attore: Any, attivita: str, dati: dict, id: int | None = None) -> StrumentoMisura:
    if attivita not in NOMI:
        raise ErroreUtente("Gli strumenti AD_DPR si gestiscono nel registro di VerbalizzAI.")
    if id is None:
        x, prima = StrumentoMisura(attivita=attivita, creato_da=attore.nome), None
    else:
        x = leggi(s, id, attivita)
        if dati.get("versione") is not None and int(dati["versione"]) != x.versione:
            raise Conflitto()
        prima = json_strumento(x)
    for k, n in TESTI.items():
        if k in dati or id is None:
            v = str(dati.get(k) or "").strip()
            if len(v) > n:
                raise ErroreUtente(f"{k}: massimo {n} caratteri.")
            setattr(x, k, v)
    if not x.denominazione:
        raise ErroreUtente("Scrivi la denominazione dello strumento (es. «Spessimetro a ultrasuoni»).")
    for k, nome in (("data_taratura", "Data di taratura"), ("scadenza_taratura", "Scadenza della taratura")):
        if k in dati or id is None:
            setattr(x, k, _data(dati.get(k), nome))
    if x.data_taratura and x.scadenza_taratura and x.scadenza_taratura < x.data_taratura:
        raise ErroreUtente("La scadenza della taratura non può precedere la data di taratura.")
    if "attivo" in dati:
        x.attivo = bool(dati["attivo"])
    if x.matricola and s.scalar(select(func.count(StrumentoMisura.id)).where(
            StrumentoMisura.attivita == attivita, func.lower(StrumentoMisura.matricola) == x.matricola.lower(),
            StrumentoMisura.id != (x.id or 0))):
        raise ErroreUtente(f"Esiste già uno strumento {NOMI[attivita]} con matricola «{x.matricola}».")
    x.modificato_da, x.modificato_il = attore.nome, adesso()
    if id is None:
        s.add(x)
    else:
        x.versione += 1
    s.flush()
    registro.scrivi(s, utente=attore, azione="strumento.crea" if prima is None else "strumento.modifica", oggetto_tipo="strumento",
                    oggetto_id=x.id, descrizione=f"{'Creato' if prima is None else 'Modificato'} lo strumento {NOMI[attivita]} «{x.denominazione}»",
                    dettagli={"dopo": json_strumento(x)} if prima is None else {"modifiche": registro.differenze(prima, json_strumento(x))})
    return x
