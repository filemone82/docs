"""API comune; le scritture DPR passano sempre dalle API DPR esistenti."""

from fastapi import APIRouter, Body, Depends, Query
from sqlalchemy import func, or_, select
from ...core.db import Archivio
from ...web.dipendenze import archivio, richiede
from ..anagrafica.modelli import Cliente, Sede
from ..utenti.accesso import UtenteCorrente
from . import servizio as v
from .modelli import Asset, ScadenzaTecnica

router = APIRouter(prefix="/api/beni")


@router.get("/cataloghi")
def cataloghi(
    _u: UtenteCorrente = Depends(richiede("beni.vedere")),
    arc: Archivio = Depends(archivio),
):
    with arc.lettura() as s:
        return v.cataloghi(s)


@router.get("/senza-prossima")
def senza_prossima(
    _u: UtenteCorrente = Depends(richiede("scadenze.vedere")),
    arc: Archivio = Depends(archivio),
):
    """R142: attrezzature senza la prossima verifica di un'attività obbligatoria (fuori dallo scadenziario)."""
    with arc.lettura() as s:
        return v.senza_prossima(s)


@router.get("/scadenze")
def scadenze(
    gruppo: str = "",
    componente: str = "",
    solo_attivi: bool = True,
    q: str = "",
    pagina: int = Query(1, ge=1),
    per_pagina: int = Query(100, ge=1, le=500),
    _u: UtenteCorrente = Depends(richiede("scadenze.vedere")),
    arc: Archivio = Depends(archivio),
):
    with arc.lettura() as s:
        # Si conservano anche date prive di prossima scadenza: sono dati tecnici,
        # non obblighi futuri generati artificialmente.
        query = (
            select(ScadenzaTecnica, Asset, Sede, Cliente)
            .join(Asset, ScadenzaTecnica.asset_id == Asset.id)
            .join(Sede, Asset.sede_id == Sede.id)
            .join(Cliente, Sede.cliente_id == Cliente.id)
        )
        if solo_attivi:
            query = query.where(
                Asset.dismesso.is_(False),
                Sede.attiva.is_(True),
                Cliente.attivo.is_(True),
            )
        if gruppo:
            query = query.where(Asset.gruppo == gruppo)
        if componente:
            query = query.where(ScadenzaTecnica.componente == componente)
        if q.strip():
            t = "%" + q.strip().lower() + "%"
            query = query.where(
                or_(
                    func.lower(Asset.matr_informale).like(t),
                    func.lower(Asset.denominazione).like(t),
                    func.lower(Cliente.ragione_sociale).like(t),
                )
            )
        total = s.scalar(select(func.count()).select_from(query.subquery()))
        rows = s.execute(
            query.order_by(
                ScadenzaTecnica.data_prossima.asc().nulls_last(), ScadenzaTecnica.id
            )
            .offset((pagina - 1) * per_pagina)
            .limit(per_pagina)
        )
        return {
            "totale": total,
            "pagina": pagina,
            "righe": [
                v.scadenza_json(x)
                | {
                    "asset_id": a.id,
                    "gruppo": a.gruppo,
                    "bene": a.denominazione or a.matr_informale or f"Impianto {a.id}",
                    "matricola": a.matr_informale,
                    "sede": sd.denominazione,
                    "cliente": c.ragione_sociale,
                }
                for x, a, sd, c in rows
            ],
        }


@router.get("")
def elenco(
    q: str = "",
    gruppo: str = "",
    sede_id: int | None = None,
    solo_attivi: bool = False,
    pagina: int = Query(1, ge=1),
    per_pagina: int = Query(50, ge=1, le=500),
    _u: UtenteCorrente = Depends(richiede("beni.vedere")),
    arc: Archivio = Depends(archivio),
):
    with arc.lettura() as s:
        query = (
            select(Asset, Sede, Cliente)
            .join(Sede, Asset.sede_id == Sede.id)
            .join(Cliente, Sede.cliente_id == Cliente.id)
        )
        if gruppo:
            query = query.where(Asset.gruppo == gruppo)
        if sede_id:
            query = query.where(Asset.sede_id == sede_id)
        if solo_attivi:
            query = query.where(
                Asset.dismesso.is_(False),
                Sede.attiva.is_(True),
                Cliente.attivo.is_(True),
            )
        if q.strip():
            t = "%" + q.strip().lower() + "%"
            query = query.where(
                or_(
                    func.lower(Asset.matr_informale).like(t),
                    func.lower(Asset.denominazione).like(t),
                    func.lower(Cliente.ragione_sociale).like(t),
                    func.lower(Sede.denominazione).like(t),
                )
            )
        total = s.scalar(select(func.count()).select_from(query.subquery()))
        rows = s.execute(
            query.order_by(Asset.id).offset((pagina - 1) * per_pagina).limit(per_pagina)
        )
        return {
            "totale": total,
            "pagina": pagina,
            "righe": [
                {
                    "id": a.id,
                    "gruppo": a.gruppo,
                    "denominazione": a.denominazione,
                    "matricola": a.matr_informale,
                    "cliente": c.ragione_sociale,
                    "sede": sd.denominazione,
                    "dismesso": a.dismesso,
                    "attivo": not a.dismesso and sd.attiva and c.attivo,
                    # N9 (0.12.8): per proporre prima periodica o successiva nel preventivo DM
                    "tipo_prox_verifica": __import__("json").loads(a.attributi_json or "{}").get("tipo_prox_verifica", ""),
                }
                for a, sd, c in rows
            ],
        }


@router.get("/{asset_id}")
def scheda(
    asset_id: int,
    _u: UtenteCorrente = Depends(richiede("beni.vedere")),
    arc: Archivio = Depends(archivio),
):
    with arc.lettura() as s:
        return v.scheda(s, v.leggi(s, asset_id))


@router.post("")
def crea(
    dati: dict = Body(...),
    u: UtenteCorrente = Depends(richiede("beni.gestire")),
    arc: Archivio = Depends(archivio),
):
    with arc.scrittura() as s:
        return v.scheda(s, v.salva(s, u.come_attore(), dati))


@router.put("/{asset_id}")
def modifica(
    asset_id: int,
    dati: dict = Body(...),
    u: UtenteCorrente = Depends(richiede("beni.gestire")),
    arc: Archivio = Depends(archivio),
):
    with arc.scrittura() as s:
        return v.scheda(s, v.salva(s, u.come_attore(), dati, asset_id))


@router.put("/{asset_id}/scadenze")
def date_tecniche(
    asset_id: int,
    dati: dict = Body(...),
    u: UtenteCorrente = Depends(richiede("beni.scadenze")),
    arc: Archivio = Depends(archivio),
):
    with arc.scrittura() as s:
        return v.scheda(s, v.salva_scadenza(s, u.come_attore(), asset_id, dati))


@router.delete("/{asset_id}/scadenze/{componente}")
def elimina_data(
    asset_id: int,
    componente: str,
    dati: dict = Body(...),
    u: UtenteCorrente = Depends(richiede("beni.scadenze")),
    arc: Archivio = Depends(archivio),
):
    with arc.scrittura() as s:
        return v.scheda(
            s, v.elimina_scadenza(s, u.come_attore(), asset_id, componente, dati)
        )


@router.post("/{asset_id}/camere")
def camera(
    asset_id: int,
    dati: dict = Body(...),
    u: UtenteCorrente = Depends(richiede("beni.gestire")),
    arc: Archivio = Depends(archivio),
):
    with arc.scrittura() as s:
        return v.scheda(s, v.salva_camera(s, u.come_attore(), asset_id, dati))


@router.put("/{asset_id}/camere/{camera_id}")
def modifica_camera(
    asset_id: int,
    camera_id: int,
    dati: dict = Body(...),
    u: UtenteCorrente = Depends(richiede("beni.gestire")),
    arc: Archivio = Depends(archivio),
):
    with arc.scrittura() as s:
        return v.scheda(
            s, v.salva_camera(s, u.come_attore(), asset_id, dati, camera_id)
        )


@router.delete("/{asset_id}/camere/{camera_id}")
def elimina_camera(
    asset_id: int,
    camera_id: int,
    dati: dict = Body(...),
    u: UtenteCorrente = Depends(richiede("beni.gestire")),
    arc: Archivio = Depends(archivio),
):
    with arc.scrittura() as s:
        return v.scheda(
            s, v.elimina_camera(s, u.come_attore(), asset_id, camera_id, dati)
        )


@router.post("/{asset_id}/accessori")
def accessorio(
    asset_id: int,
    dati: dict = Body(...),
    u: UtenteCorrente = Depends(richiede("beni.gestire")),
    arc: Archivio = Depends(archivio),
):
    with arc.scrittura() as s:
        return v.scheda(s, v.associa(s, u.come_attore(), asset_id, dati))


@router.delete("/{asset_id}/accessori")
def rimuovi_accessorio(
    asset_id: int,
    dati: dict = Body(...),
    u: UtenteCorrente = Depends(richiede("beni.gestire")),
    arc: Archivio = Depends(archivio),
):
    with arc.scrittura() as s:
        return v.scheda(s, v.associa(s, u.come_attore(), asset_id, dati, True))


@router.post("/{asset_id}/dismesso")
def dismesso(
    asset_id: int,
    dati: dict = Body(...),
    u: UtenteCorrente = Depends(richiede("beni.dismetti")),
    arc: Archivio = Depends(archivio),
):
    with arc.scrittura() as s:
        return v.scheda(s, v.dismetti(s, u.come_attore(), asset_id, dati))
