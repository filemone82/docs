"""Nucleo comune del parco beni; primo incremento B1 (R73, R94, R97)."""
