"""Identità comuni, cataloghi Garda, camere, accessori e date tecniche.

La scheda DPR rimane proprietaria dei suoi campi durante la transizione: il suo
asset è una proiezione aggiornata nella stessa transazione, non editabile qui.
SC/SP/GVR/PSV sono invece schede native comuni. Nessun verbale viene fabbricato
per giustificare una data iniziale dichiarata.
"""

from __future__ import annotations
from datetime import date
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..anagrafica.modelli import Sede
from sqlalchemy import (
    Boolean,
    CheckConstraint,
    Date,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from ...core.db import Base
from ...core.modelli_comuni import Tracciato


class FamigliaGvr(Base):
    __tablename__ = "cls_tipi_attrezzature_gvr"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    codice: Mapped[str] = mapped_column(String(20))
    descrizione: Mapped[str] = mapped_column(Text)
    origine_json: Mapped[str] = mapped_column(Text)


class TipoAttrezzatura(Base):
    __tablename__ = "cls_tipi_attrezzature"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    gruppo: Mapped[str] = mapped_column(String(8))
    codice: Mapped[str] = mapped_column(String(20))
    descrizione: Mapped[str] = mapped_column(Text)
    famiglia_gvr_id: Mapped[int | None] = mapped_column(
        ForeignKey("cls_tipi_attrezzature_gvr.id", ondelete="RESTRICT")
    )
    # SQLite eredita VARCHAR(20) dalla 0011 (nessun limite effettivo);
    # PostgreSQL usa TEXT dalla 0028, perché le descrizioni Garda lo superano.
    tipo_ver_gvr_1: Mapped[str | None] = mapped_column(String(20).with_variant(Text(), "postgresql"))
    tipo_ver_gvr_2: Mapped[str | None] = mapped_column(String(20).with_variant(Text(), "postgresql"))
    tipo_ver_gvr_3: Mapped[str | None] = mapped_column(String(20).with_variant(Text(), "postgresql"))
    origine_json: Mapped[str] = mapped_column(Text)


class IdSpecifica(Base):
    __tablename__ = "cls_id_specifiche"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    gruppo: Mapped[str] = mapped_column(String(8))
    codice: Mapped[str] = mapped_column(String(20))
    descrizione: Mapped[str] = mapped_column(Text)
    origine_json: Mapped[str] = mapped_column(Text)


class CompatibilitaClassificazione(Base):
    __tablename__ = "cls_tipi_attr_id_specifiche"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    gruppo: Mapped[str] = mapped_column(String(8))
    tipo_attr_id: Mapped[int | None] = mapped_column(
        ForeignKey("cls_tipi_attrezzature.id", ondelete="RESTRICT")
    )
    famiglia_gvr_id: Mapped[int | None] = mapped_column(
        ForeignKey("cls_tipi_attrezzature_gvr.id", ondelete="RESTRICT")
    )
    id_spec_id: Mapped[int] = mapped_column(
        ForeignKey("cls_id_specifiche.id", ondelete="RESTRICT")
    )
    origine_json: Mapped[str] = mapped_column(Text)


class Asset(Base, Tracciato):
    __tablename__ = "asset"
    __table_args__ = (
        CheckConstraint("gruppo IN ('DPR','SC','SP','GVR','PSV')", name="gruppo"),
        CheckConstraint(
            "classe_identita IN ('dpr','attrezzatura','accessorio')",
            name="classe_identita",
        ),
        UniqueConstraint(
            "sede_id",
            "classe_identita",
            "matr_informale",
            name="uq_asset_matricola_sede",
        ),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    gruppo: Mapped[str] = mapped_column(String(8), index=True)
    classe_identita: Mapped[str] = mapped_column(String(20))
    sede_id: Mapped[int] = mapped_column(
        ForeignKey("sedi.id", ondelete="RESTRICT"), index=True
    )
    denominazione: Mapped[str] = mapped_column(String(300), default="")
    matr_informale: Mapped[str | None] = mapped_column(String(100))
    anno_matricola: Mapped[str] = mapped_column(String(4), default="")
    cod_att_matricola: Mapped[str] = mapped_column(String(10), default="")
    num_matricola: Mapped[str] = mapped_column(String(30), default="")
    prov_immatr: Mapped[str] = mapped_column(String(2), default="")
    num_fabbrica: Mapped[str] = mapped_column(String(100), default="")
    costruttore: Mapped[str] = mapped_column(String(250), default="")
    modello: Mapped[str] = mapped_column(String(150), default="")
    anno_costruzione: Mapped[int | None] = mapped_column(Integer)
    tipo_attr_id: Mapped[int | None] = mapped_column(
        ForeignKey("cls_tipi_attrezzature.id", ondelete="RESTRICT")
    )
    tipo_attr_gvr_id: Mapped[int | None] = mapped_column(
        ForeignKey("cls_tipi_attrezzature_gvr.id", ondelete="RESTRICT")
    )
    id_spec_id: Mapped[int | None] = mapped_column(
        ForeignKey("cls_id_specifiche.id", ondelete="RESTRICT")
    )
    soggetto_messa_servizio: Mapped[bool | None] = mapped_column(Boolean)
    dismesso: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    note: Mapped[str] = mapped_column(Text, default="")
    attributi_json: Mapped[str] = mapped_column(Text, default="{}")
    sede: Mapped["Sede"] = relationship("Sede")
    scadenze: Mapped[list["ScadenzaTecnica"]] = relationship(
        back_populates="asset", cascade="all, delete-orphan"
    )
    camere: Mapped[list["CameraGvr"]] = relationship(
        back_populates="asset", cascade="all, delete-orphan"
    )
    origini: Mapped[list["AssetOrigine"]] = relationship(
        back_populates="asset", cascade="all, delete-orphan"
    )


class AssetOrigine(Base):
    __tablename__ = "asset_origini"
    __table_args__ = (UniqueConstraint("sistema", "tabella", "id_origine"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    asset_id: Mapped[int] = mapped_column(
        ForeignKey("asset.id", ondelete="CASCADE"), index=True
    )
    sistema: Mapped[str] = mapped_column(String(40))
    tabella: Mapped[str] = mapped_column(String(80))
    id_origine: Mapped[str] = mapped_column(String(80))
    dati_origine_json: Mapped[str] = mapped_column(Text, default="{}")
    asset: Mapped[Asset] = relationship(back_populates="origini")


class CameraGvr(Base, Tracciato):
    __tablename__ = "asset_camere_gvr"
    __table_args__ = (
        UniqueConstraint("asset_id", "chiave"),
        CheckConstraint("unita IN ('L','DN')", name="unita"),
        CheckConstraint("valore_decimi >= 0", name="valore_non_negativo"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    asset_id: Mapped[int] = mapped_column(
        ForeignKey("asset.id", ondelete="RESTRICT"), index=True
    )
    identificazione: Mapped[str] = mapped_column(String(150))
    num_fabbrica: Mapped[str] = mapped_column(String(100), default="")
    chiave: Mapped[str] = mapped_column(String(260))
    unita: Mapped[str] = mapped_column(String(2))
    valore_decimi: Mapped[int] = mapped_column(Integer)
    attributi_json: Mapped[str] = mapped_column(Text, default="{}")
    asset: Mapped[Asset] = relationship(back_populates="camere")


class AssetRelazione(Base, Tracciato):
    __tablename__ = "asset_relazioni"
    __table_args__ = (
        UniqueConstraint("asset_id", "accessorio_id"),
        CheckConstraint("asset_id <> accessorio_id", name="beni_diversi"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    asset_id: Mapped[int] = mapped_column(
        ForeignKey("asset.id", ondelete="RESTRICT"), index=True
    )
    accessorio_id: Mapped[int] = mapped_column(
        ForeignKey("asset.id", ondelete="RESTRICT"), index=True
    )


class ScadenzaTecnica(Base, Tracciato):
    __tablename__ = "scadenze_tecniche"
    __table_args__ = (
        UniqueConstraint("asset_id", "componente"),
        CheckConstraint(
            "componente IN ('dpr','funzionamento','integrita','interna','scsp','cnd','supplementare','taratura')",
            name="componente",
        ),
        CheckConstraint("fonte IN ('dichiarata','dpr','dm')", name="fonte"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    asset_id: Mapped[int] = mapped_column(
        ForeignKey("asset.id", ondelete="RESTRICT"), index=True
    )
    componente: Mapped[str] = mapped_column(String(20))
    data_ultima: Mapped[date | None] = mapped_column(Date)
    data_prossima: Mapped[date | None] = mapped_column(Date, index=True)
    numero_report: Mapped[str] = mapped_column(String(100), default="")
    fonte: Mapped[str] = mapped_column(String(20))
    nota: Mapped[str] = mapped_column(Text, default="")
    incarico_dm_id: Mapped[int | None] = mapped_column(ForeignKey("dm_incarichi.id", ondelete="RESTRICT"))
    dati_iniziali_json: Mapped[str] = mapped_column(Text, default="{}", server_default="{}")
    asset: Mapped[Asset] = relationship(back_populates="scadenze")
