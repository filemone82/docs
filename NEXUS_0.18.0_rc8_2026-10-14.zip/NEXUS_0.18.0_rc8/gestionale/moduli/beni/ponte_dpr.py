"""Proiezione DPR nella stessa transazione di ogni scrittura ORM, import compresi.

Durante B1 i flussi DPR restano proprietari dei loro campi e delle loro date.
La scheda comune è sola lettura per DPR; nessuna sincronizzazione manuale.
Le scritture SQL esterne al programma non sono supportate.
"""

import json
from sqlalchemy import event, insert, select
from sqlalchemy.orm import Session
from ..anagrafica.modelli import Impianto
from .modelli import Asset, AssetOrigine, ScadenzaTecnica


@event.listens_for(Session, "before_flush")
def proietta_dpr(s, _contesto, _istanze):
    pending = []
    for i in list(s.new) + list(s.dirty):
        if not isinstance(i, Impianto) or i in s.deleted:
            continue
        a = i.asset
        if a is None:
            a = Asset(gruppo="DPR", classe_identita="dpr", matr_informale=None)
            i.asset = a
        for comune, dpr in [
            ("sede_id", "sede_id"),
            ("denominazione", "denominazione"),
            ("dismesso", "dismesso"),
            ("anno_matricola", "matricola_anno"),
            ("cod_att_matricola", "matricola_attivita"),
            ("num_matricola", "matricola_numero"),
            ("prov_immatr", "matricola_provincia"),
            ("note", "note"),
        ]:
            setattr(
                a,
                comune,
                getattr(i, dpr)
                or (
                    False
                    if comune == "dismesso"
                    else ""
                    if comune != "sede_id"
                    else None
                ),
            )
        for k in ("creato_il", "modificato_il", "creato_da", "modificato_da"):
            v = getattr(i, k)
            if v is not None:
                setattr(a, k, v)
        a.versione = i.versione or 1
        # Dati tecnici correnti, senza intervenire sulle fotografie nei verbali.
        fields = (
            "tipologia",
            "potenza_kw",
            "cabine_mt_bt",
            "sottostazioni_at_mt",
            "asta",
            "numero_aste",
            "gabbia",
            "gabbia_fascia",
            "gas",
            "polveri",
            "zone",
            "periodicita_anni",
            "codice_esterno",
        )
        a.attributi_json = json.dumps(
            {k: getattr(i, k) for k in fields}
            | {
                "caratteristiche_originali": i.caratteristiche or "",
                "pod": [p.pod for p in i.pod],
            },
            ensure_ascii=False,
            sort_keys=True,
        )
        x = next((x for x in a.scadenze if x.componente == "dpr"), None)
        if i.ultima_verifica_data or i.prossima_verifica or i.ultima_verifica_numero:
            if x is None:
                x = ScadenzaTecnica(componente="dpr", fonte="dpr", nota="", versione=1)
                a.scadenze.append(x)
            x.data_ultima = i.ultima_verifica_data
            x.data_prossima = i.prossima_verifica
            x.numero_report = i.ultima_verifica_numero or ""
            x.versione = i.versione or 1
            for k in ("creato_il", "modificato_il", "creato_da", "modificato_da"):
                v = getattr(i, k)
                if v is not None:
                    setattr(x, k, v)
        elif x is not None:
            a.scadenze.remove(x)
        pending.append(i)
    for i in list(s.deleted):
        if isinstance(i, Impianto) and i.asset is not None:
            s.delete(i.asset)
    s.info["beni_dpr_origini"] = pending


@event.listens_for(Session, "after_flush_postexec")
def riferimenti_dpr(s, _contesto):
    # Gli ID nascono nel flush; inserimento SQL nella medesima transazione.
    # L'origine è una chiave stabile e non dipende da nomi o indirizzi.
    conn = s.connection()
    for i in s.info.pop("beni_dpr_origini", []):
        q = select(AssetOrigine.id).where(
            AssetOrigine.sistema == "gestionale_dpr",
            AssetOrigine.tabella == "impianti",
            AssetOrigine.id_origine == str(i.id),
        )
        if conn.scalar(q) is None:
            conn.execute(
                insert(AssetOrigine).values(
                    asset_id=i.asset_id,
                    sistema="gestionale_dpr",
                    tabella="impianti",
                    id_origine=str(i.id),
                    dati_origine_json="{}",
                )
            )
