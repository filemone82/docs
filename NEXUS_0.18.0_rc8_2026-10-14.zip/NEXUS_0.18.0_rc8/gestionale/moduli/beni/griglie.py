"""Griglie di AD_dm (0.12.5, menu come in Garda: «Attrezzature» — R117).

Attrezzature (SC, SP, GVR) e valvole di sicurezza / accessori (PSV) con tutte le colonne utili, filtrabili, ordinabili
ed esportabili come gli altri elenchi (D43), con i dati della sede e del cliente. I cataloghi di Garda (tipi di
attrezzature, tipi GVR, ID specifiche, compatibilità, tariffe SC/SP e GVR) in sola lettura: si modificano solo con
un aggiornamento controllato del programma (sono gli stessi ID di Garda).
"""

from __future__ import annotations

from sqlalchemy import Integer, String, and_, case, cast, func, literal, or_, select
from sqlalchemy.orm import aliased

from ...core.sql_portabile import oggi_italiano, data_tra_giorni, anno_dopo, giorni_fra, testi_uniti, json_testo
from ...core.sql_json_booleano import json_booleano_intero
from ...core.griglia import REGISTRO_GRIGLIE, Colonna, Griglia, registra
from ..anagrafica.griglie import _con_dati_cliente, colonne_cliente, colonne_sede
from ..anagrafica.modelli import Cliente, Sede
from ..dm.modelli import TariffaDM
from .modelli import (
    Asset,
    AssetRelazione,
    CameraGvr,
    CompatibilitaClassificazione,
    FamigliaGvr,
    IdSpecifica,
    ScadenzaTecnica,
    TipoAttrezzatura,
)

Tipo = aliased(TipoAttrezzatura, name="tipo_attr")
Famiglia = aliased(FamigliaGvr, name="famiglia_gvr")
Spec = aliased(IdSpecifica, name="id_spec")
Collegata = aliased(Asset, name="collegata")

GRUPPI = {"SC": "SC", "SP": "SP", "GVR": "GVR"}
OGGI = oggi_italiano()
MATRICOLA = case(
    (and_(Asset.anno_matricola == "", Asset.num_matricola == ""), literal("")),
    else_=Asset.anno_matricola + "/" + Asset.cod_att_matricola + "/" + Asset.num_matricola + "/" + Asset.prov_immatr,
)


def _prossima(componente: str | None):
    q = select(func.min(ScadenzaTecnica.data_prossima)).where(ScadenzaTecnica.asset_id == Asset.id)
    if componente:
        q = q.where(ScadenzaTecnica.componente == componente)
    return q.correlate(Asset).scalar_subquery()


def _ultima(componente: str):
    return (select(func.max(ScadenzaTecnica.data_ultima)).where(ScadenzaTecnica.asset_id == Asset.id, ScadenzaTecnica.componente == componente)
            .correlate(Asset).scalar_subquery())


PROSSIMA = _prossima(None)
STATI = ("Scaduta", "Entro 30 giorni", "Entro 90 giorni", "Entro 1 anno", "Oltre 1 anno", "Senza data")
STATO = case(
    (PROSSIMA.is_(None), literal("Senza data")),
    (PROSSIMA < OGGI, literal("Scaduta")),
    (PROSSIMA <= data_tra_giorni(OGGI, 30), literal("Entro 30 giorni")),
    (PROSSIMA <= data_tra_giorni(OGGI, 90), literal("Entro 90 giorni")),
    (PROSSIMA <= anno_dopo(OGGI), literal("Entro 1 anno")),
    else_=literal("Oltre 1 anno"),
)
VOLUME = (select(func.coalesce(func.sum(CameraGvr.valore_decimi), 0) / 10.0)
          .where(CameraGvr.asset_id == Asset.id, CameraGvr.unita == "L").correlate(Asset).scalar_subquery())
N_CAMERE = select(func.count(CameraGvr.id)).where(CameraGvr.asset_id == Asset.id).correlate(Asset).scalar_subquery()
N_VALVOLE = select(func.count(AssetRelazione.id)).where(AssetRelazione.asset_id == Asset.id).correlate(Asset).scalar_subquery()
COLLEGATA_A = (select(testi_uniti(Collegata.matr_informale, ", ")).select_from(AssetRelazione)
               .join(Collegata, Collegata.id == AssetRelazione.asset_id)
               .where(AssetRelazione.accessorio_id == Asset.id).correlate(Asset).scalar_subquery())


def attributo(chiave: str):
    return func.coalesce(json_testo(Asset.attributi_json, chiave), "")


SEDE_OPERATIVA = func.coalesce(Cliente.ragione_sociale, "") + " › " + func.coalesce(Sede.denominazione, "")
DESCRIZIONE = func.coalesce(func.nullif(attributo("descr_attr"), ""), Asset.denominazione)
ESENTE = case({"T": "Sì", "I": "ISO 17020"}, value=attributo("esente_verifiche"), else_="No")
TIPO_SCADENZA = case({"scsp": "Verifica periodica", "funzionamento": "Funzionamento", "integrita": "Integrità", "interna": "Visita interna",
                      "cnd": "CND", "supplementare": "Indagine supplementare", "taratura": "Taratura"},
                     value=ScadenzaTecnica.componente, else_=ScadenzaTecnica.componente)


def _da_bene():
    base = (Asset.__table__.join(Sede.__table__, Asset.sede_id == Sede.id).join(Cliente.__table__, Sede.cliente_id == Cliente.id))
    return (_con_dati_cliente(base).outerjoin(Tipo, Asset.tipo_attr_id == Tipo.id)
            .outerjoin(Famiglia, Asset.tipo_attr_gvr_id == Famiglia.id).outerjoin(Spec, Asset.id_spec_id == Spec.id))


def _comuni(vis: set[str]) -> list[Colonna]:
    def c(campo, etich, tipo, espr, larghezza=130, **kw):
        return Colonna(campo, etich, tipo, espr, visibile=campo in vis, larghezza=larghezza, **kw)

    return [
        c("id", "N.", "numero", Asset.id, 70),
        c("matr_informale", "Matricola informale", "testo", Asset.matr_informale, 150),
        c("matricola", "Matricola INAIL", "testo", MATRICOLA, 150),
        c("num_fabbrica", "N. fabbrica", "testo", Asset.num_fabbrica, 120),
        c("costruttore", "Costruttore", "testo", Asset.costruttore, 170),
        c("modello", "Modello", "testo", Asset.modello, 130),
        c("denominazione", "Descrizione", "testo", Asset.denominazione, 200),
        c("dismesso", "Dismessa", "booleano", Asset.dismesso, 90),
        c("note", "Note", "testo", Asset.note, 200),
        c("modificato_il", "Ultima modifica", "dataora", Asset.modificato_il, 140),
        c("modificato_da", "Modificata da", "testo", Asset.modificato_da, 140),
    ]


registra(Griglia(
    codice="attrezzature", titolo="Attrezzature", permesso="beni.vedere", da=_da_bene,
    condizione=lambda _u: Asset.gruppo.in_(tuple(GRUPPI)),
    ordine_predefinito=[("cliente_ragione_sociale", "asc"), ("sede_denominazione", "asc"), ("matr_informale", "asc")],
    colonne=[
        Colonna("gruppo", "Gruppo", "elenco", Asset.gruppo, larghezza=80, opzioni=tuple(GRUPPI)),
        *_comuni({"matr_informale", "matricola", "costruttore", "modello", "dismesso"}),
        Colonna("anno_costruzione", "Anno costruzione", "numero", Asset.anno_costruzione, visibile=False, larghezza=100),
        Colonna("tipo_codice", "Tipo (all. 7)", "testo", Tipo.codice, larghezza=80),
        Colonna("tipo_descrizione", "Tipo di attrezzatura", "testo", Tipo.descrizione, visibile=False, larghezza=300),
        Colonna("famiglia_codice", "Tipo GVR", "testo", Famiglia.codice, larghezza=80),
        Colonna("famiglia_descrizione", "Tipo GVR (descrizione)", "testo", Famiglia.descrizione, visibile=False, larghezza=250),
        Colonna("spec_codice", "ID specifica", "testo", Spec.codice, larghezza=90),
        Colonna("spec_descrizione", "ID specifica (descrizione)", "testo", Spec.descrizione, visibile=False, larghezza=250),
        Colonna("marcatura_ce", "Marcatura CE", "booleano", json_booleano_intero(Asset.attributi_json, "marcatura_ce"),
                visibile=False, larghezza=90),
        Colonna("reparto", "Reparto", "testo", attributo("reparto"), visibile=False),
        Colonna("rif_interno", "Rif. interno", "testo", attributo("rif_interno"), visibile=False),
        Colonna("tipo_prox_verifica", "Tipo prossima verifica", "testo", attributo("tipo_prox_verifica"), visibile=False, larghezza=110),
        Colonna("ps", "PS (bar)", "testo", attributo("ps_attr_gvr"), visibile=False, larghezza=80),
        Colonna("volume", "Volume camere (L)", "numero", VOLUME, visibile=False, larghezza=110,
                descrizione="Somma delle camere in litri (le tubazioni in DN non entrano)"),
        Colonna("n_camere", "N. camere", "numero", N_CAMERE, visibile=False, larghezza=80),
        Colonna("n_valvole", "N. valvole", "numero", N_VALVOLE, visibile=False, larghezza=80),
        Colonna("prossima", "Prossima scadenza", "data", PROSSIMA, larghezza=120, descrizione="La più vicina fra tutte le attività"),
        Colonna("stato_scadenza", "Stato scadenza", "elenco", STATO, larghezza=130, opzioni=STATI),
        Colonna("funz_ultima", "Funzionamento · ultima", "data", _ultima("funzionamento"), visibile=False, larghezza=110),
        Colonna("funz_prossima", "Funzionamento · prossima", "data", _prossima("funzionamento"), visibile=False, larghezza=110),
        Colonna("integrita_ultima", "Integrità · ultima", "data", _ultima("integrita"), visibile=False, larghezza=110),
        Colonna("integrita_prossima", "Integrità · prossima", "data", _prossima("integrita"), visibile=False, larghezza=110),
        Colonna("interna_ultima", "Visita interna · ultima", "data", _ultima("interna"), visibile=False, larghezza=110),
        Colonna("interna_prossima", "Visita interna · prossima", "data", _prossima("interna"), visibile=False, larghezza=110),
        Colonna("cnd_ultima", "CND · ultimi", "data", _ultima("cnd"), visibile=False, larghezza=110),
        Colonna("cnd_prossima", "CND · prossimi", "data", _prossima("cnd"), visibile=False, larghezza=110),
        Colonna("scsp_ultima", "Verifica SC/SP · ultima", "data", _ultima("scsp"), visibile=False, larghezza=110),
        Colonna("scsp_prossima", "Verifica SC/SP · prossima", "data", _prossima("scsp"), visibile=False, larghezza=110),
        Colonna("suppl_ultima", "Indagine supplementare · ultima", "data", _ultima("supplementare"), visibile=False, larghezza=110),
        Colonna("suppl_prossima", "Indagine supplementare · prossima", "data", _prossima("supplementare"), visibile=False, larghezza=110),
        *colonne_sede("sede_", "Sede", visibili=("denominazione", "comune")),
        *colonne_cliente("cliente_", "Cliente", visibili=("ragione_sociale",)),
    ],
))

# ---------------------------------------------------------------- 0.12.10: maschere di Federico (doc. 30, §§ 3–4)
# «Attrezzature GVR» e «Attrezzature SC/SP» come voci distinte, raggruppate per sede operativa del cliente, dismesse
# nascoste in partenza. Le date ultima/prossima vengono dalle scadenze per componente (CND compresi: un nuovo CND fa
# «slittare» la scadenza).


def _colonne_maschera(gvr: bool) -> list[Colonna]:
    date = ([("funz", "funzionamento", "funzionamento"), ("integrita", "integrita", "integrità"), ("interna", "interna", "visita interna"),
             ("cnd", "cnd", "CND")] if gvr else [("scsp", "scsp", "verifica"), ("suppl", "supplementare", "indagine supplementare")])
    colonne = [
        Colonna("sede_operativa", "Sede operativa", "testo", SEDE_OPERATIVA, larghezza=260),
        Colonna("gruppo", "Gruppo", "elenco", Asset.gruppo, larghezza=80, opzioni=("GVR",) if gvr else ("SC", "SP")),
        Colonna("reparto", "Reparto", "testo", attributo("reparto"), larghezza=150),
        Colonna("rif_interno", "Rif. interno", "testo", attributo("rif_interno"), larghezza=120),
        Colonna("descrizione", "Descrizione", "testo", DESCRIZIONE, larghezza=200),
        Colonna("matr_informale", "Matricola informale", "testo", Asset.matr_informale, larghezza=150),
        Colonna("num_fabbrica", "N. fabbrica", "testo", Asset.num_fabbrica, larghezza=110),
    ]
    if gvr:
        colonne += [Colonna("ps", "PS", "testo", attributo("ps_attr_gvr"), larghezza=70),
                    Colonna("volume", "V", "testo", attributo("volume_attr_gvr"), larghezza=80,
                            descrizione="Volume dell'attrezzatura GVR (scheda); la somma delle camere è nella colonna «Volume camere»")]
    colonne.append(Colonna("anno_costruzione", "Anno costr.", "numero", Asset.anno_costruzione, larghezza=90))
    for campo, componente, nome in date:
        ultimi = "Ultimi" if componente == "cnd" else ("Ultima" if not nome.startswith("funz") else "Ultimo")
        prossimi = "Prossimi" if componente == "cnd" else ("Prossima" if not nome.startswith("funz") else "Prossimo")
        colonne += [Colonna(f"{campo}_ultima", f"{ultimi} {nome}", "data", _ultima(componente), larghezza=110),
                    Colonna(f"{campo}_prossima", f"{prossimi} {nome}", "data", _prossima(componente), larghezza=110)]
    colonne += [
        Colonna("esente", "Esente verifica", "elenco", ESENTE, larghezza=100, opzioni=("No", "Sì", "ISO 17020")),
        Colonna("dismesso", "Dismessa", "booleano", Asset.dismesso, larghezza=90),
        Colonna("id", "N.", "numero", Asset.id, visibile=False, larghezza=70),
        Colonna("matricola", "Matricola INAIL", "testo", MATRICOLA, visibile=False, larghezza=150),
        Colonna("costruttore", "Costruttore", "testo", Asset.costruttore, visibile=False, larghezza=170),
        Colonna("modello", "Modello", "testo", Asset.modello, visibile=False, larghezza=130),
        Colonna("tipo_codice", "Tipo (all. 7)", "testo", Tipo.codice, visibile=False, larghezza=80),
        Colonna("tipo_prox_verifica", "Tipo prossima verifica", "elenco",
                case({"V1": "Prima periodica", "V2": "Successiva"}, value=attributo("tipo_prox_verifica"), else_=""), visibile=False,
                larghezza=120, opzioni=("Prima periodica", "Successiva")),
        Colonna("prossima", "Prossima scadenza", "data", PROSSIMA, visibile=False, larghezza=120),
        Colonna("stato_scadenza", "Stato scadenza", "elenco", STATO, visibile=False, larghezza=130, opzioni=STATI),
        Colonna("note", "Note", "testo", Asset.note, visibile=False, larghezza=200),
    ]
    if gvr:
        colonne += [Colonna("famiglia_codice", "Tipo GVR", "testo", Famiglia.codice, visibile=False, larghezza=80),
                    Colonna("volume_camere", "Volume camere (L)", "numero", VOLUME, visibile=False, larghezza=110),
                    Colonna("n_valvole", "N. valvole", "numero", N_VALVOLE, visibile=False, larghezza=80)]
    return colonne + [*colonne_sede("sede_", "Sede"), *colonne_cliente("cliente_", "Cliente")]


def _vista(gvr: bool) -> dict:
    visibili = [c.campo for c in _colonne_maschera(gvr) if c.visibile and c.campo not in ("sede_operativa", "gruppo")]
    # la sede operativa è nell'intestazione del gruppo, come in Garda: la colonna resta disponibile ma non si vede
    return {"": {"colonne": visibili, "raggruppa": "sede_operativa", "filtri": [("dismesso", "no")]}}


for _codice, _titolo, _gruppi in (("attrezzature_gvr", "Attrezzature GVR", ("GVR",)), ("attrezzature_scsp", "Attrezzature SC/SP", ("SC", "SP"))):
    registra(Griglia(
        codice=_codice, titolo=_titolo, permesso="beni.vedere", da=_da_bene,
        condizione=(lambda g: (lambda _u: Asset.gruppo.in_(g)))(_gruppi),
        ordine_predefinito=[("sede_operativa", "asc"), ("reparto", "asc"), ("matr_informale", "asc")],
        colonne=_colonne_maschera(_codice == "attrezzature_gvr"),
        viste_predefinite=_vista(_codice == "attrezzature_gvr"),
    ))


registra(Griglia(
    codice="valvole", titolo="Valvole di sicurezza e accessori", permesso="beni.vedere", da=_da_bene,
    condizione=lambda _u: Asset.gruppo == "PSV",
    ordine_predefinito=[("cliente_ragione_sociale", "asc"), ("sede_denominazione", "asc"), ("matr_informale", "asc")],
    colonne=[
        *_comuni({"matr_informale", "costruttore", "modello", "dismesso"}),
        Colonna("tip_accessorio", "Tipologia", "testo", attributo("tip_accessorio"), larghezza=170),
        Colonna("dn", "DN", "testo", attributo("dn"), larghezza=70),
        Colonna("diametro", "Diametro", "testo", attributo("diametro"), visibile=False, larghezza=80),
        Colonna("area", "Area", "testo", attributo("area"), visibile=False, larghezza=80),
        Colonna("ptar", "Ptar", "testo", attributo("ptar"), larghezza=80),
        Colonna("taratura_ultima", "Taratura · ultima", "data", _ultima("taratura"), larghezza=110),
        Colonna("taratura_prossima", "Taratura · prossima", "data", _prossima("taratura"), larghezza=120),
        Colonna("stato_scadenza", "Stato scadenza", "elenco", STATO, visibile=False, larghezza=130, opzioni=STATI),
        Colonna("collegata_a", "Collegata a", "testo", COLLEGATA_A, larghezza=180, descrizione="Matricole delle attrezzature collegate"),
        *colonne_sede("sede_", "Sede", visibili=("denominazione", "comune")),
        *colonne_cliente("cliente_", "Cliente", visibili=("ragione_sociale",)),
    ],
))

# ---------------------------------------------------------------- cataloghi di Garda (sola lettura)

TipoGvr = aliased(FamigliaGvr, name="tipo_gvr")
registra(Griglia(
    codice="cat_tipi_attrezzature", titolo="Tipi di attrezzature (all. 7)", permesso="beni.vedere",
    da=lambda: TipoAttrezzatura.__table__.outerjoin(TipoGvr, TipoAttrezzatura.famiglia_gvr_id == TipoGvr.id),
    ordine_predefinito=[("gruppo", "asc"), ("codice", "asc")],
    colonne=[
        Colonna("id", "ID Garda", "numero", TipoAttrezzatura.id, larghezza=80),
        Colonna("gruppo", "Gruppo", "elenco", TipoAttrezzatura.gruppo, larghezza=80, opzioni=("SC", "SP", "GVR")),
        Colonna("codice", "Codice", "testo", TipoAttrezzatura.codice, larghezza=80),
        Colonna("descrizione", "Descrizione", "testo", TipoAttrezzatura.descrizione, larghezza=600),
        Colonna("tipo_gvr", "Tipo GVR", "testo", TipoGvr.codice, larghezza=80),
        Colonna("tipo_ver_gvr_1", "Verifica GVR 1", "testo", TipoAttrezzatura.tipo_ver_gvr_1, larghezza=100),
        Colonna("tipo_ver_gvr_2", "Verifica GVR 2", "testo", TipoAttrezzatura.tipo_ver_gvr_2, larghezza=100),
        Colonna("tipo_ver_gvr_3", "Verifica GVR 3", "testo", TipoAttrezzatura.tipo_ver_gvr_3, larghezza=100),
    ],
))
registra(Griglia(
    codice="cat_tipi_gvr", titolo="Tipi di attrezzature GVR", permesso="beni.vedere", da=lambda: FamigliaGvr.__table__,
    ordine_predefinito=[("codice", "asc")],
    colonne=[
        Colonna("id", "ID Garda", "numero", FamigliaGvr.id, larghezza=80),
        Colonna("codice", "Codice", "testo", FamigliaGvr.codice, larghezza=80),
        Colonna("descrizione", "Descrizione", "testo", FamigliaGvr.descrizione, larghezza=700),
    ],
))
registra(Griglia(
    codice="cat_id_specifiche", titolo="ID specifiche", permesso="beni.vedere", da=lambda: IdSpecifica.__table__,
    ordine_predefinito=[("gruppo", "asc"), ("codice", "asc")],
    colonne=[
        Colonna("id", "ID Garda", "numero", IdSpecifica.id, larghezza=80),
        Colonna("gruppo", "Gruppo", "elenco", IdSpecifica.gruppo, larghezza=80, opzioni=("SC", "SP", "GVR")),
        Colonna("codice", "Codice", "testo", IdSpecifica.codice, larghezza=90),
        Colonna("descrizione", "Descrizione", "testo", IdSpecifica.descrizione, larghezza=650),
    ],
))
CTipo, CSpec, CFam = aliased(TipoAttrezzatura, name="c_tipo"), aliased(IdSpecifica, name="c_spec"), aliased(FamigliaGvr, name="c_fam")
registra(Griglia(
    codice="cat_compatibilita", titolo="Tipi di attrezzature / ID specifiche", permesso="beni.vedere",
    da=lambda: (CompatibilitaClassificazione.__table__.outerjoin(CTipo, CompatibilitaClassificazione.tipo_attr_id == CTipo.id)
                .outerjoin(CFam, CompatibilitaClassificazione.famiglia_gvr_id == CFam.id)
                .outerjoin(CSpec, CompatibilitaClassificazione.id_spec_id == CSpec.id)),
    ordine_predefinito=[("gruppo", "asc"), ("tipo", "asc"), ("spec", "asc")],
    colonne=[
        Colonna("id", "ID Garda", "numero", CompatibilitaClassificazione.id, larghezza=80),
        Colonna("gruppo", "Gruppo", "elenco", CompatibilitaClassificazione.gruppo, larghezza=80, opzioni=("SC", "SP", "GVR")),
        Colonna("tipo", "Tipo (all. 7)", "testo", CTipo.codice, larghezza=90),
        Colonna("tipo_descrizione", "Tipo di attrezzatura", "testo", CTipo.descrizione, larghezza=320),
        Colonna("famiglia", "Tipo GVR", "testo", CFam.codice, larghezza=80),
        Colonna("spec", "ID specifica", "testo", CSpec.codice, larghezza=90),
        Colonna("spec_descrizione", "ID specifica (descrizione)", "testo", CSpec.descrizione, larghezza=320),
    ],
))
TSpec, TCompat, TTipo, TCSpec = (aliased(IdSpecifica, name="t_spec"), aliased(CompatibilitaClassificazione, name="t_compat"),
                                 aliased(TipoAttrezzatura, name="t_tipo"), aliased(IdSpecifica, name="t_cspec"))


def _da_tariffe():
    return (TariffaDM.__table__.outerjoin(TSpec, TariffaDM.id_spec_id == TSpec.id)
            .outerjoin(TCompat, TariffaDM.compatibilita_id == TCompat.id)
            .outerjoin(TTipo, TCompat.tipo_attr_id == TTipo.id).outerjoin(TCSpec, TCompat.id_spec_id == TCSpec.id))


registra(Griglia(
    codice="cat_tariffe_scsp", titolo="Tariffe SC/SP", permesso="beni.vedere", da=_da_tariffe,
    condizione=lambda _u: TariffaDM.gruppo == "SCSP", ordine_predefinito=[("gruppo", "asc"), ("tipo_attr", "asc"), ("spec", "asc"), ("tipo", "asc")],
    colonne=[
        Colonna("gruppo", "Gruppo", "elenco", TCompat.gruppo, larghezza=80, opzioni=("SC", "SP")),
        Colonna("tipo_attr", "Tipo (all. 7)", "testo", TTipo.codice, larghezza=90),
        Colonna("tipo_descrizione", "Tipo di attrezzatura", "testo", TTipo.descrizione, larghezza=330),
        Colonna("spec", "ID specifica", "testo", TCSpec.codice, larghezza=90),
        Colonna("spec_descrizione", "ID specifica (descrizione)", "testo", TCSpec.descrizione, larghezza=260),
        Colonna("tipo", "Verifica", "elenco", TariffaDM.tipo, larghezza=80, opzioni=("V1", "V2")),
        Colonna("importo", "Tariffa", "importo", TariffaDM.importo, larghezza=100),
    ],
))
registra(Griglia(
    codice="cat_tariffe_gvr", titolo="Tariffe GVR", permesso="beni.vedere", da=_da_tariffe,
    condizione=lambda _u: TariffaDM.gruppo == "GVR", ordine_predefinito=[("spec", "asc"), ("tipo", "asc")],
    colonne=[
        Colonna("spec", "ID specifica", "testo", TSpec.codice, larghezza=90),
        Colonna("spec_descrizione", "ID specifica (descrizione)", "testo", TSpec.descrizione, larghezza=450),
        Colonna("tipo", "Verifica", "elenco", TariffaDM.tipo, larghezza=80, opzioni=("V1", "V2", "V3", "V4")),
        Colonna("importo", "Tariffa", "importo", TariffaDM.importo, larghezza=100),
    ],
))

# ---------------------------------------------------------------- scadenze DM (0.12.6, percorso Cliente → Sede → Attrezzature → Scadenze)

COMPONENTI_DM = {"funzionamento": "Funzionamento", "integrita": "Integrità", "interna": "Visita interna", "cnd": "CND",
                 "scsp": "Verifica SC/SP", "supplementare": "Indagine supplementare", "taratura": "Taratura"}
OGGI_S = oggi_italiano()
STATO_S = case(
    (ScadenzaTecnica.data_prossima.is_(None), literal("Senza data")),
    (ScadenzaTecnica.data_prossima < OGGI_S, literal("Scaduta")),
    (ScadenzaTecnica.data_prossima <= data_tra_giorni(OGGI_S, 30), literal("Entro 30 giorni")),
    (ScadenzaTecnica.data_prossima <= data_tra_giorni(OGGI_S, 90), literal("Entro 90 giorni")),
    (ScadenzaTecnica.data_prossima <= anno_dopo(OGGI_S), literal("Entro 1 anno")),
    else_=literal("Oltre 1 anno"),
)
GIORNI_S = giorni_fra(ScadenzaTecnica.data_prossima, OGGI_S)


def _copertura():  # noqa: ANN202
    """AD-41 (0.12.8): la scadenza è «presa in carico» da una riga di preventivo DM non rifiutata né annullata, dello stesso
    bene e della stessa attività (una combinata copre ciascuna componente), con lavoro assente o ancora aperto."""
    from sqlalchemy import exists, or_

    from ..dm.modelli import IncaricoDM
    from ..preventivi.modelli import Preventivo, RigaPreventivo
    codice = case({"funzionamento": "funz", "integrita": "integrita", "interna": "interna"}, value=ScadenzaTecnica.componente, else_="")
    chiusi = exists().where(IncaricoDM.riga_id == RigaPreventivo.id, IncaricoDM.stato.in_(("effettuata", "annullata")))
    aperti = exists().where(IncaricoDM.riga_id == RigaPreventivo.id, IncaricoDM.stato.notin_(("effettuata", "annullata")))
    return (select(case((Preventivo.revisione > 0, Preventivo.codice + " rev. " + cast(Preventivo.revisione, String)), else_=Preventivo.codice))
            .select_from(RigaPreventivo).join(Preventivo, RigaPreventivo.preventivo_id == Preventivo.id)
            .where(RigaPreventivo.asset_id == ScadenzaTecnica.asset_id, RigaPreventivo.stato.notin_(("annullata", "rifiutata")),
                   Preventivo.ambito == "DM", Preventivo.stato.notin_(("annullato", "sostituito")),
                   or_(ScadenzaTecnica.componente == "scsp", RigaPreventivo.tipo_verifica_gvr.contains(codice)),
                   or_(~chiusi, aperti))
            .order_by(RigaPreventivo.id.desc()).limit(1).correlate(ScadenzaTecnica).scalar_subquery())


COPERTURA = _copertura()
ESENTE = func.coalesce(json_testo(Asset.attributi_json, "esente_verifiche"), "F")
# R129 (0.12.9, Federico 12/10/2026): il preventivo DM contiene SOLO le verifiche dell'allegato VII D.Lgs. 81/08:
# funzionamento, integrità e visita interna di attrezzature e insiemi GVR, verifiche SC/SP, di attrezzature non esenti.
# CND, indagini supplementari, efficienza (taratura) delle valvole e verifiche in regime volontario ISO/IEC 17020
# (attrezzatura esente o «ISO17020») sono attività EX (sezionale EX), che si preventiveranno a parte.
ALLEGATO_VII = and_(or_(and_(Asset.gruppo == "GVR", ScadenzaTecnica.componente.in_(("funzionamento", "integrita", "interna"))),
                        and_(Asset.gruppo.in_(("SC", "SP")), ScadenzaTecnica.componente == "scsp")),
                    ESENTE == "F")
REGIME = case((ALLEGATO_VII, literal("DM all. VII")), else_=literal("EX"))
PREVENTIVABILE = case((and_(ALLEGATO_VII, COPERTURA.is_(None)), literal("Sì")), else_=literal("No"))


def _prima_scadenza():  # noqa: ANN202
    s2 = aliased(ScadenzaTecnica)
    return (select(s2.id).where(s2.asset_id == ScadenzaTecnica.asset_id, s2.data_prossima.is_not(None),
                                s2.componente.in_(("funzionamento", "integrita", "interna", "scsp")))
            .order_by(s2.data_prossima, s2.id).limit(1).correlate(ScadenzaTecnica).scalar_subquery())


TIPO_PER_SCADENZA = case(
    (and_(attributo("tipo_prox_verifica") == "V1", ScadenzaTecnica.id == _prima_scadenza()), literal("Prima periodica")),
    (attributo("tipo_prox_verifica").in_(("V1", "V2")), literal("Successiva")),
    else_=literal(""))


def _da_scadenze():  # noqa: ANN202
    base = (ScadenzaTecnica.__table__.join(Asset.__table__, ScadenzaTecnica.asset_id == Asset.id)
            .join(Sede.__table__, Asset.sede_id == Sede.id).join(Cliente.__table__, Sede.cliente_id == Cliente.id))
    return _con_dati_cliente(base)


registra(Griglia(
    codice="scadenze_dm", titolo="Scadenze AD_DM", permesso="scadenze.vedere", da=_da_scadenze,
    condizione=lambda _u: and_(Asset.gruppo.in_(("SC", "SP", "GVR", "PSV")), Asset.dismesso.is_(False)),
    ordine_predefinito=[("data_prossima", "asc")],
    colonne=[
        Colonna("id", "N.", "numero", ScadenzaTecnica.id, visibile=False, larghezza=70),
        Colonna("asset_id", "N. attrezzatura", "numero", Asset.id, visibile=False, larghezza=90),
        Colonna("gruppo", "Gruppo", "elenco", Asset.gruppo, larghezza=80, opzioni=("SC", "SP", "GVR", "PSV")),
        Colonna("matr_informale", "Attrezzatura", "testo", Asset.matr_informale, larghezza=170),
        Colonna("matricola", "Matricola INAIL", "testo", MATRICOLA, visibile=False, larghezza=150),
        Colonna("componente", "Attività", "elenco", case(COMPONENTI_DM, value=ScadenzaTecnica.componente, else_=ScadenzaTecnica.componente),
                larghezza=170, opzioni=tuple(COMPONENTI_DM.values())),
        Colonna("data_ultima", "Ultima", "data", ScadenzaTecnica.data_ultima, larghezza=110),
        Colonna("data_prossima", "Prossima", "data", ScadenzaTecnica.data_prossima, larghezza=110),
        Colonna("stato_scadenza", "Stato scadenza", "elenco", STATO_S, larghezza=130, opzioni=STATI),
        Colonna("giorni", "Giorni alla scadenza", "numero", GIORNI_S, visibile=False, larghezza=110),
        Colonna("tipo_prox_verifica", "Tipo prossima verifica", "elenco", TIPO_PER_SCADENZA, larghezza=130,
                opzioni=("Prima periodica", "Successiva"),
                descrizione="C13 (0.16): «Prima periodica» (PVP) solo sulla prima scadenza dell'attrezzatura; le altre sono successive"),
        Colonna("preventivo", "Preventivo", "testo", COPERTURA, larghezza=120,
                descrizione="Preventivo DM che ha già in carico questa attività (riga non rifiutata, lavoro non concluso)"),
        Colonna("regime", "Regime", "elenco", REGIME, larghezza=110, opzioni=("DM all. VII", "EX"),
                descrizione="DM all. VII: verifiche periodiche dell'allegato VII D.Lgs. 81/08 (GVR funzionamento, integrità, interna; "
                            "SC/SP) di attrezzature non esenti. EX: CND, indagini supplementari, efficienza delle valvole, regime volontario ISO 17020"),
        Colonna("da_preventivare", "Da preventivare DM", "elenco", PREVENTIVABILE, larghezza=110, opzioni=("Sì", "No"),
                descrizione="Verifica dell'allegato VII non già in un preventivo DM (Garda AD-42)"),
        Colonna("numero_report", "Ultimo verbale / report", "testo", ScadenzaTecnica.numero_report, larghezza=150),
        Colonna("fonte", "Fonte della data", "testo", ScadenzaTecnica.fonte, visibile=False, larghezza=110),
        Colonna("nota", "Nota", "testo", ScadenzaTecnica.nota, visibile=False, larghezza=250),
        Colonna("sede_operativa", "Sede operativa", "testo", SEDE_OPERATIVA, visibile=False, larghezza=260),
        Colonna("reparto", "Reparto", "testo", attributo("reparto"), visibile=False, larghezza=150),
        Colonna("rif_interno", "Rif. interno", "testo", attributo("rif_interno"), visibile=False, larghezza=120),
        Colonna("descrizione", "Descrizione", "testo", DESCRIZIONE, visibile=False, larghezza=200),
        Colonna("num_fabbrica", "N. fabbrica", "testo", Asset.num_fabbrica, visibile=False, larghezza=110),
        Colonna("tipo_scadenza", "Tipo scadenza", "elenco", TIPO_SCADENZA, visibile=False, larghezza=150,
                opzioni=("Verifica periodica", "Funzionamento", "Integrità", "Visita interna", "CND", "Indagine supplementare", "Taratura")),
        *colonne_sede("sede_", "Sede", visibili=("denominazione", "comune")),
        *colonne_cliente("cliente_", "Cliente", visibili=("ragione_sociale",)),
    ],
))
# 0.12.10 (doc. 30, § 5): raggruppate per sede operativa; di partenza solo le verifiche dell'allegato VII (le EX dal filtro)
REGISTRO_GRIGLIE["scadenze_dm"].viste_predefinite = {"": {
    "colonne": ["sede_operativa", "reparto", "rif_interno", "descrizione", "matr_informale", "num_fabbrica", "data_ultima", "data_prossima",
                "tipo_prox_verifica", "tipo_scadenza", "stato_scadenza"],
    "raggruppa": "sede_operativa", "filtri": [("regime", "DM all. VII")]}}

REGISTRO_GRIGLIE["scadenze_dm"].gruppi_per_scadenza = "data_prossima"

# C17: scadenza tecnica più vicina, non ordine alfabetico delle sedi.
for _codice in ("attrezzature_gvr", "attrezzature_scsp", "attrezzature"):
    _g = REGISTRO_GRIGLIE[_codice]
    _g.ordine_predefinito = [("prossima", "asc")]
    _g.gruppi_per_scadenza = "prossima"
    if _codice == "attrezzature":
        _g.viste_predefinite = {"": {"colonne": [c.campo for c in _g.colonne if c.visibile],
                                    "raggruppa": "sede_denominazione"}}
