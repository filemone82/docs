"""Operazioni del nucleo beni; classificazione manuale e date iniziali dichiarate."""

from __future__ import annotations
import json
import re
from datetime import date
from decimal import Decimal, InvalidOperation
from sqlalchemy import select
from ...core.db import adesso
from ...core.errori import Conflitto, ErroreUtente, NonTrovato
from ..anagrafica.modelli import Impianto, Sede
from ..registro import servizio as registro
from .modelli import (
    Asset,
    AssetRelazione,
    CameraGvr,
    ScadenzaTecnica,
    FamigliaGvr,
    TipoAttrezzatura,
    IdSpecifica,
    CompatibilitaClassificazione,
)

GRUPPI = {
    "SC": "Sollevamento cose",
    "SP": "Sollevamento persone",
    "GVR": "Pressione",
    "PSV": "Valvola di sicurezza",
}
COMPONENTI = {
    "DPR": ("dpr",),
    "GVR": ("funzionamento", "integrita", "interna", "cnd"),
    "SC": ("scsp", "supplementare"),
    "SP": ("scsp", "supplementare"),
    "PSV": ("taratura",),
}
TESTI = {
    "denominazione": 300,
    "matr_informale": 100,
    "anno_matricola": 4,
    "cod_att_matricola": 1,
    "num_matricola": 5,
    "prov_immatr": 2,
    "num_fabbrica": 100,
    "costruttore": 250,
    "modello": 150,
    "note": 8000,
}


def intero(x, nome, opzionale=False):
    if opzionale and x in (None, ""):
        return None
    if isinstance(x, bool) or not str(x).isdigit():
        raise ErroreUtente(f"{nome}: scrivi un numero intero positivo.")
    n = int(x)
    if n <= 0 or n > 2**63 - 1:
        raise ErroreUtente(f"{nome}: numero fuori intervallo.")
    return n


def testo(x, nome, massimo):
    t = str(x or "").strip()
    if len(t) > massimo:
        raise ErroreUtente(f"{nome}: massimo {massimo} caratteri.")
    return t


def data(x, nome):
    if x in (None, ""):
        return None
    try:
        return date.fromisoformat(str(x))
    except (ValueError, TypeError):
        raise ErroreUtente(f"{nome}: data non valida (anno-mese-giorno).") from None


def json_dati(x):
    if not isinstance(x, dict):
        raise ErroreUtente("Gli attributi aggiuntivi devono essere un oggetto.")
    try:
        t = json.dumps(x, ensure_ascii=False, sort_keys=True, allow_nan=False)
    except (ValueError, TypeError):
        raise ErroreUtente("Attributi aggiuntivi non validi.") from None
    if len(t) > 100000:
        raise ErroreUtente("Attributi aggiuntivi troppo grandi.")
    return t


def versione(a, x):
    if x in (None, ""):
        raise ErroreUtente("Versione della scheda mancante: ricarica la pagina.")
    if intero(x, "Versione") != a.versione:
        raise Conflitto()


def leggi(s, asset_id):
    a = s.get(Asset, asset_id)
    if a is None:
        raise NonTrovato("Bene non trovato.")
    return a


def nativo(a):
    if a.gruppo == "DPR":
        raise ErroreUtente(
            "Questo impianto si modifica dalla scheda Impianti DPR. Il parco comune si aggiorna automaticamente."
        )


def traccia(s, attore, a, azione, prima):
    a.versione = (a.versione or 0) + 1
    a.modificato_da = getattr(attore, "nome", "") or "Sistema"
    a.modificato_il = adesso()
    s.flush()
    registro.scrivi(
        s,
        utente=attore,
        azione=azione,
        oggetto_tipo="asset",
        oggetto_id=a.id,
        descrizione=f"{azione}: {a.denominazione or a.matr_informale or a.id}",
        dettagli={"prima": prima, "dopo": scheda(s, a)},
    )
    # Garda: ogni modifica del master aggiorna i soli lavori DM aperti.
    from ..dm.tecnico import propaga
    propaga(s, attore, a.id)


def tubazione(s, a):
    f = s.get(FamigliaGvr, a.tipo_attr_gvr_id) if a.tipo_attr_gvr_id else None
    return f is not None and f.codice == "a4"


FAMIGLIE_CON_INTERNA = ("a2", "a3")


def visita_interna(s, a):
    """DM-07: nel catalogo Garda (cls tipi attrezzature, tipi 24/25) la visita interna biennale esiste solo per le
    famiglie GVR a2 «Generatori di vapore» e a3 «Generatori di acqua surriscaldata» (GV e INS GV); per tutte le
    altre, tubazioni comprese, è «N.A.». Senza famiglia GVR non si propone."""
    f = s.get(FamigliaGvr, a.tipo_attr_gvr_id) if a.tipo_attr_gvr_id else None
    return a.gruppo == "GVR" and f is not None and f.codice in FAMIGLIE_CON_INTERNA


def controlla_classificazione(s, a):
    tipo = s.get(TipoAttrezzatura, a.tipo_attr_id) if a.tipo_attr_id else None
    fam = s.get(FamigliaGvr, a.tipo_attr_gvr_id) if a.tipo_attr_gvr_id else None
    spec = s.get(IdSpecifica, a.id_spec_id) if a.id_spec_id else None
    if a.tipo_attr_id and (tipo is None or tipo.gruppo != a.gruppo):
        raise ErroreUtente(
            "Apparecchi all. 7: classificazione non compatibile con il gruppo."
        )
    if a.tipo_attr_gvr_id and (fam is None or a.gruppo != "GVR"):
        raise ErroreUtente("Famiglia GVR non valida per questo bene.")
    if tipo and tipo.famiglia_gvr_id and tipo.famiglia_gvr_id != a.tipo_attr_gvr_id:
        raise ErroreUtente(
            "La classificazione all. 7 richiede la corrispondente famiglia GVR."
        )
    if a.id_spec_id:
        if spec is None or spec.gruppo != a.gruppo:
            raise ErroreUtente("ID specifica non compatibile con il gruppo.")
        filtro = (
            CompatibilitaClassificazione.famiglia_gvr_id == a.tipo_attr_gvr_id
            if a.gruppo == "GVR"
            else CompatibilitaClassificazione.tipo_attr_id == a.tipo_attr_id
        )
        if not s.scalar(
            select(CompatibilitaClassificazione.id)
            .where(
                filtro,
                CompatibilitaClassificazione.id_spec_id == a.id_spec_id,
                CompatibilitaClassificazione.gruppo == a.gruppo,
            )
            .limit(1)
        ):
            raise ErroreUtente(
                "Associazione fra classificazione e ID specifica non prevista dal catalogo Garda."
            )
    if a.gruppo == "GVR" and not visita_interna(s, a) and any(
        x.componente == "interna" and (x.data_ultima or x.data_prossima) for x in a.scadenze
    ):
        raise ErroreUtente(
            "La scheda contiene date di visita interna, prevista solo per generatori di vapore e di acqua "
            "surriscaldata (GV/INS GV): risolvile prima di cambiare la classificazione."
        )
    if a.gruppo == "PSV" and (tipo or fam or spec):
        raise ErroreUtente(
            "Gli accessori non usano la classificazione delle attrezzature."
        )


def salva(s, attore, dati, asset_id=None):
    sconosciuti = set(dati) - (
        set(TESTI)
        | {
            "sede_id",
            "gruppo",
            "anno_costruzione",
            "tipo_attr_id",
            "tipo_attr_gvr_id",
            "id_spec_id",
            "soggetto_messa_servizio",
            "attributi",
            "dati_dm",
            "date_iniziali",
            "protegge",
            "versione",
        }
    )
    if sconosciuti:
        raise ErroreUtente("Campi non riconosciuti: " + ", ".join(sorted(sconosciuti)))
    nuovo = asset_id is None
    if nuovo:
        gruppo = dati.get("gruppo")
        if gruppo not in GRUPPI:
            raise ErroreUtente(
                "Scegli SC, SP, GVR o PSV. Gli impianti DPR si creano nella loro scheda."
            )
        a = Asset(
            gruppo=gruppo,
            classe_identita="accessorio" if gruppo == "PSV" else "attrezzatura",
            versione=0,
            attributi_json="{}",
            dismesso=False,
        )
        for k in TESTI:
            setattr(a, k, None if k == "matr_informale" else "")
        a.creato_da = getattr(attore, "nome", "") or "Sistema"
        a.creato_il = adesso()
        prima = None
    else:
        a = leggi(s, asset_id)
        nativo(a)
        versione(a, dati.get("versione"))
        prima = scheda(s, a)
        if "gruppo" in dati and dati["gruppo"] != a.gruppo:
            raise ErroreUtente(
                "Il gruppo non si cambia nella modifica ordinaria, come in Garda."
            )
    with s.no_autoflush:
        if "sede_id" in dati or nuovo:
            sid = intero(dati.get("sede_id"), "Sede")
            sd = s.get(Sede, sid)
            if sd is None:
                raise ErroreUtente("Sede non trovata.")
            if a.sede_id != sid and not sd.attiva:
                raise ErroreUtente(
                    "La sede è chiusa: riattivala prima di aggiungere beni."
                )
            a.sede_id = sid
        for k, n in TESTI.items():
            if k in dati:
                setattr(a, k, testo(dati[k], k, n))
        if not a.matr_informale:
            raise ErroreUtente(
                "Scrivi l'identificativo della valvola (n. di serie o targhetta)." if a.gruppo == "PSV"
                else "Scrivi la matricola informale."
            )
        if a.gruppo == "PSV" and any(getattr(a, k) for k in ("anno_matricola", "cod_att_matricola", "num_matricola", "prov_immatr")
                                     if k in dati):
            # R141 (Federico, 12/10/2026, 17:43): «le psv andrebbero gestite a parte perché non hanno matricola»
            raise ErroreUtente("Gli accessori di sicurezza non hanno matricola INAIL.")
        a.prov_immatr = a.prov_immatr.upper()
        if a.anno_matricola and (
            len(a.anno_matricola) != 4 or not a.anno_matricola.isdigit()
        ):
            raise ErroreUtente("Anno della matricola: quattro cifre.")
        if "anno_costruzione" in dati:
            a.anno_costruzione = intero(
                dati["anno_costruzione"], "Anno costruzione", True
            )
            if a.anno_costruzione and not 1000 <= a.anno_costruzione <= 9999:
                raise ErroreUtente("Anno costruzione: quattro cifre.")
        for k in ("tipo_attr_id", "tipo_attr_gvr_id", "id_spec_id"):
            if k in dati:
                setattr(a, k, intero(dati[k], k, True))
        if "soggetto_messa_servizio" in dati:
            if a.gruppo != "GVR" or (
                dati["soggetto_messa_servizio"] is not None
                and type(dati["soggetto_messa_servizio"]) is not bool
            ):
                raise ErroreUtente(
                    "Messa in servizio: sì, no o non indicato, solo per GVR."
                )
            a.soggetto_messa_servizio = dati["soggetto_messa_servizio"]
        if "attributi" in dati:
            a.attributi_json = json_dati(dati["attributi"])
        from . import scheda_dm
        if "dati_dm" in dati:
            scheda_dm.salva(a, dati["dati_dm"])
        elif nuovo and a.gruppo != "PSV":
            scheda_dm.salva(a, {"esente_verifiche": "F"})
        if "attributi" in dati:
            raw = json.loads(a.attributi_json)
            scheda_dm.valida({k: v for k, v in raw.items() if k in scheda_dm.campi(a.gruppo)}, scheda_dm.campi(a.gruppo))
        scheda_dm.controlla_matricola(a, nuovi=nuovo, dati=dati)
        if a.gruppo == "GVR" and a.tipo_attr_id and "tipo_attr_gvr_id" not in dati:
            tipo = s.get(TipoAttrezzatura, a.tipo_attr_id)
            if tipo:
                a.tipo_attr_gvr_id = tipo.famiglia_gvr_id
        controlla_classificazione(s, a)
        if a.gruppo in ("GVR", "SC", "SP"):
            if (nuovo or any(k in dati for k in ("tipo_attr_id", "id_spec_id"))) and (not a.tipo_attr_id or not a.id_spec_id):
                raise ErroreUtente("Apparecchi all. 7 e ID specifica sono obbligatori, come in Garda.")
            attrs = json.loads(a.attributi_json)
            cambiati = set(dati.get("dati_dm", {})) | (set(dati.get("attributi", {})) if isinstance(dati.get("attributi"), dict) else set())
            for campo, label in (("esente_verifiche", "Esente verifiche"), ("tipo_prox_verifica", "Tipo prossima verifica")):
                if (nuovo or campo in cambiati) and not attrs.get(campo):
                    raise ErroreUtente(f"{label}: scegli un valore, come in Garda.")
        q = select(Asset.id).where(
            Asset.sede_id == a.sede_id,
            Asset.classe_identita == a.classe_identita,
            Asset.matr_informale == a.matr_informale,
        )
        if not nuovo:
            q = q.where(Asset.id != a.id)
        if s.scalar(q.limit(1)):
            raise ErroreUtente(
                "Matricola già presente nella stessa sede. Apri la scheda esistente."
            )
    if nuovo:
        s.add(a)
        date_iniziali(s, attore, a, dati.get("date_iniziali"))
        protegge(s, attore, a, dati.get("protegge"))
    elif dati.get("protegge"):
        raise ErroreUtente("I collegamenti di un accessorio esistente si cambiano dalla scheda dell'attrezzatura.")
    if not nuovo and dati.get("date_iniziali"):
        raise ErroreUtente("Le date si registrano con la nuova attrezzatura; dopo si correggono in «Date tecniche».")
    traccia(s, attore, a, "asset.crea" if nuovo else "asset.modifica", prima)
    return a


NOMI_COMPONENTI = {"funzionamento": "funzionamento", "integrita": "integrità", "interna": "visita interna", "scsp": "verifica SC/SP",
                   "taratura": "taratura"}


def obbligatorie(s, a):
    """R142 (Federico, 12/10/2026, 17:46 e 17:49): alla registrazione la prossima verifica è obbligatoria per SC/SP e,
    nei GVR, per funzionamento, integrità e visita interna se prevista (GV / INS GV), così l'attrezzatura entra subito
    nelle Scadenze. Ultima data e riferimento sono facoltativi."""
    if a.gruppo in ("SC", "SP"):
        return ["scsp"]
    if a.gruppo == "GVR":
        # «se applicabile»: come nel catalogo di Garda, dove un'attività «N.A.» o vuota non si fa per quel tipo
        # (es. tubazioni b4: niente funzionamento; generatori di calore a5: solo la verifica quinquennale)
        tipo = s.get(TipoAttrezzatura, a.tipo_attr_id) if a.tipo_attr_id else None

        def prevista(v):  # noqa: ANN001, ANN202
            return tipo is None or str(v or "").strip().upper() not in ("", "N.A.", "NA", "N.A")
        return ([c for c, v in (("funzionamento", tipo.tipo_ver_gvr_1 if tipo else "x"), ("integrita", tipo.tipo_ver_gvr_2 if tipo else "x"))
                 if prevista(v)] + (["interna"] if visita_interna(s, a) else []))
    return []


def protegge(s, attore, a, ids):
    """R141: un accessorio nuovo può nascere già collegato alle attrezzature GVR della stessa sede che protegge."""
    if not ids:
        return
    if a.gruppo != "PSV" or not isinstance(ids, list):
        raise ErroreUtente("Solo un accessorio di sicurezza protegge attrezzature GVR.")
    s.flush()
    for x in dict.fromkeys(intero(i, "Attrezzatura") for i in ids):
        att = s.get(Asset, x)
        if att is None or att.gruppo != "GVR" or att.sede_id != a.sede_id:
            raise ErroreUtente("L'accessorio protegge solo attrezzature GVR della sua sede.")
        s.add(AssetRelazione(asset_id=att.id, accessorio_id=a.id, creato_da=attore.nome, modificato_da=attore.nome))


def date_iniziali(s, attore, a, valori):
    richieste = obbligatorie(s, a)
    facoltative = ["taratura"] if a.gruppo == "PSV" else []
    valori = valori or {}
    if not isinstance(valori, dict):
        raise ErroreUtente("Date della prima registrazione non valide.")
    for c in facoltative:  # taratura della valvola: facoltativa (attività EX)
        if not any((valori.get(c) or {}).get(k) for k in ("data_ultima", "data_prossima")):
            valori.pop(c, None)
    richieste = richieste + [c for c in facoltative if c in valori]
    fuori = set(valori) - set(richieste)
    if fuori:
        raise ErroreUtente("Date non previste per questa attrezzatura: " + ", ".join(NOMI_COMPONENTI.get(x, x) for x in sorted(fuori)) + ".")
    mancano = [c for c in richieste if not (valori.get(c) or {}).get("data_prossima")]
    if mancano:
        raise ErroreUtente("Prossima verifica obbligatoria (serve per le Scadenze): manca per "
                           + ", ".join(NOMI_COMPONENTI[c] for c in mancano) + ".")
    for c in richieste:
        v = valori[c]
        if not isinstance(v, dict) or set(v) - {"data_ultima", "data_prossima", "numero_report"}:
            raise ErroreUtente("Date della prima registrazione non valide.")
        ultima, prossima = data(v.get("data_ultima"), "data_ultima"), data(v.get("data_prossima"), "data_prossima")
        if ultima and prossima and prossima < ultima:
            raise ErroreUtente(f"{NOMI_COMPONENTI[c].capitalize()}: la prossima verifica non può precedere l'ultima.")
        nome = getattr(attore, "nome", "") or "Sistema"
        a.scadenze.append(ScadenzaTecnica(componente=c, fonte="dichiarata", versione=1, data_ultima=ultima, data_prossima=prossima,
                                          numero_report=testo(v.get("numero_report"), "numero_report", 100),
                                          nota="Data dichiarata alla registrazione dell'attrezzatura.",
                                          creato_da=nome, modificato_da=nome))


def senza_prossima(s):
    """R142: attrezzature SC, SP e GVR non dismesse, in sedi attive, a cui manca la prossima verifica di un'attività
    obbligatoria: senza quella data non compaiono nello scadenziario."""
    righe = []
    q = (select(Asset).join(Sede, Asset.sede_id == Sede.id)
         .where(Asset.gruppo.in_(("SC", "SP", "GVR")), Asset.dismesso.is_(False), Sede.attiva.is_(True)).order_by(Asset.id))
    for a in s.scalars(q):
        attrs = json.loads(a.attributi_json or "{}")
        if attrs.get("esente_verifiche", "F") != "F":
            continue
        presenti = {x.componente for x in a.scadenze if x.data_prossima}
        manca = [c for c in obbligatorie(s, a) if c not in presenti]
        if manca:
            righe.append({"id": a.id, "gruppo": a.gruppo, "matricola": a.matr_informale or "", "denominazione": a.denominazione,
                          "sede": a.sede.denominazione, "cliente": a.sede.cliente.ragione_sociale,
                          "mancano": [NOMI_COMPONENTI[c] for c in manca]})
    return righe


def scadenza_json(x):
    return {
        "id": x.id,
        "componente": x.componente,
        "data_ultima": x.data_ultima.isoformat() if x.data_ultima else None,
        "data_prossima": x.data_prossima.isoformat() if x.data_prossima else None,
        "numero_report": x.numero_report,
        "fonte": x.fonte,
        "nota": x.nota,
        "versione": x.versione,
    }


def scheda(s, a):
    from . import scheda_dm
    d = {k: getattr(a, k) for k in TESTI}
    d.update(
        {
            "id": a.id,
            "gruppo": a.gruppo,
            "sede_id": a.sede_id,
            "anno_costruzione": a.anno_costruzione,
            "tipo_attr_id": a.tipo_attr_id,
            "tipo_attr_gvr_id": a.tipo_attr_gvr_id,
            "id_spec_id": a.id_spec_id,
            "soggetto_messa_servizio": a.soggetto_messa_servizio,
            "dismesso": a.dismesso,
            "attributi": json.loads(a.attributi_json),
            "campi_dm": scheda_dm.definizioni(a.gruppo),
            "avvisi": scheda_dm.avvisi(a),
            "versione": a.versione,
        }
    )
    sd = a.sede
    d.update(
        {
            "sede": sd.denominazione,
            "cliente": sd.cliente.ragione_sociale,
            "cliente_id": sd.cliente_id,
            "attivo": not a.dismesso and sd.attiva and sd.cliente.attivo,
            "impianto_dpr_id": s.scalar(
                select(Impianto.id).where(Impianto.asset_id == a.id)
            )
            if a.gruppo == "DPR"
            else None,
            "scadenze": sorted(
                [scadenza_json(x) for x in a.scadenze], key=lambda x: x["componente"]
            ),
            "componenti": componenti(s, a),
            "camere": [
                {
                    "id": x.id,
                    "identificazione": x.identificazione,
                    "num_fabbrica": x.num_fabbrica,
                    "unita": x.unita,
                    "valore": str(Decimal(x.valore_decimi) / 10),
                    "attributi": json.loads(x.attributi_json),
                    "versione": x.versione,
                }
                for x in sorted(a.camere, key=lambda x: x.id or 0)
            ],
            "volume_totale_litri": str(
                Decimal(sum(x.valore_decimi for x in a.camere if x.unita == "L")) / 10
            ),
            "origini": [
                {"sistema": x.sistema, "tabella": x.tabella, "id_origine": x.id_origine}
                for x in a.origini
            ],
        }
    )
    rel = list(
        s.scalars(
            select(AssetRelazione)
            .where(AssetRelazione.asset_id == a.id)
            .order_by(AssetRelazione.id)
        )
    )
    d["accessori"] = [
        {
            "relazione_id": r.id,
            "id": r.accessorio_id,
            "matricola": leggi(s, r.accessorio_id).matr_informale,
        }
        for r in rel
    ]
    d["taratura_accessori"] = taratura_accessori(s, rel)
    if a.gruppo == "PSV":  # R141: le attrezzature GVR che l'accessorio protegge
        d["protegge"] = [{"id": x.id, "matricola": x.matr_informale or "", "denominazione": x.denominazione or ""}
                         for x in s.scalars(select(Asset).join(AssetRelazione, AssetRelazione.asset_id == Asset.id)
                                            .where(AssetRelazione.accessorio_id == a.id).order_by(Asset.id))]
    return d


def componenti(s, a):
    c = list(COMPONENTI[a.gruppo])
    if a.gruppo == "GVR" and not visita_interna(s, a):
        c.remove("interna")
    return c


def taratura_accessori(s, rel):
    sc = []
    for r in rel:
        p = leggi(s, r.accessorio_id)
        if p.dismesso or not p.sede.attiva:
            continue
        sc.extend(x for x in p.scadenze if x.componente == "taratura")
    ultime = [x.data_ultima for x in sc if x.data_ultima]
    prossime = [x.data_prossima for x in sc if x.data_prossima]
    return {
        "data_ultima": max(ultime).isoformat() if ultime else None,
        "data_prossima": min(prossime).isoformat() if prossime else None,
    }


def salva_scadenza(s, attore, asset_id, dati):
    if set(dati) - {
        "componente",
        "data_ultima",
        "data_prossima",
        "numero_report",
        "nota",
        "versione",
    }:
        raise ErroreUtente("Campi della scadenza non riconosciuti.")
    a = leggi(s, asset_id)
    nativo(a)
    versione(a, dati.get("versione"))
    prima = scheda(s, a)
    comp = dati.get("componente")
    if comp not in componenti(s, a):
        raise ErroreUtente(
            "Componente non applicabile al bene. Le tubazioni non hanno visita interna."
        )
    x = next((x for x in a.scadenze if x.componente == comp), None)
    if x is None:
        x = ScadenzaTecnica(
            componente=comp,
            fonte="dichiarata",
            versione=1,
            creato_da=attore.nome,
            modificato_da=attore.nome,
        )
        a.scadenze.append(x)
    else:
        if x.fonte != "dichiarata":
            raise ErroreUtente(
                "Data collegata a un flusso operativo: correggila da quel flusso."
            )
        x.versione += 1
    for k in ("data_ultima", "data_prossima"):
        if k in dati:
            setattr(x, k, data(dati[k], k))
    for k, n in [("numero_report", 100), ("nota", 8000)]:
        if k in dati:
            setattr(x, k, testo(dati[k], k, n))
    x.modificato_da = attore.nome
    x.modificato_il = adesso()
    traccia(s, attore, a, "asset.scadenza", prima)
    return a


def elimina_scadenza(s, attore, asset_id, comp, dati):
    a = leggi(s, asset_id)
    nativo(a)
    versione(a, dati.get("versione"))
    prima = scheda(s, a)
    x = next((x for x in a.scadenze if x.componente == comp), None)
    if x is None:
        raise NonTrovato("Scadenza non trovata.")
    if x.fonte != "dichiarata":
        raise ErroreUtente("Questa scadenza si gestisce dal suo flusso operativo.")
    a.scadenze.remove(x)
    traccia(s, attore, a, "asset.scadenza_elimina", prima)
    return a


def salva_camera(s, attore, asset_id, dati, camera_id=None):
    a = leggi(s, asset_id)
    nativo(a)
    versione(a, dati.get("versione"))
    prima = scheda(s, a)
    if a.gruppo != "GVR":
        raise ErroreUtente("Le camere appartengono a beni GVR.")
    if set(dati) - {
        "versione",
        "identificazione",
        "num_fabbrica",
        "unita",
        "valore",
        "attributi",
        "dati_tecnici",
    }:
        raise ErroreUtente("Campi della camera non riconosciuti.")
    ident = testo(dati.get("identificazione"), "Identificazione", 150)
    nf = testo(dati.get("num_fabbrica"), "Numero fabbrica", 100)
    if not ident:
        raise ErroreUtente("Scrivi l’identificazione della camera o tubazione.")
    chiave = ident.lower() + "|" + nf.lower()
    if any(x.chiave == chiave and x.id != camera_id for x in a.camere):
        raise ErroreUtente("Camera già presente: apri quella esistente.")
    unita = dati.get("unita")
    if unita not in ("L", "DN"):
        raise ErroreUtente("Scegli litri oppure DN (mm).")
    try:
        t = str(dati.get("valore")).strip().replace(" ", "")
        if "," in t:
            t = t.replace(".", "").replace(",", ".")
        elif re.fullmatch(r"-?\d{1,3}(\.\d{3})+", t):
            # Stessa convenzione dei campi numerici DPR, senza passare da float.
            t = t.replace(".", "")
        dec = Decimal(t)
        if (
            not dec.is_finite()
            or dec < 0
            or dec * 10 != (dec * 10).to_integral_value()
            or dec > Decimal("922337203685477580.7")
        ):
            raise InvalidOperation
    except (InvalidOperation, ValueError):
        raise ErroreUtente(
            "Volume/DN: numero non negativo con al massimo un decimale."
        ) from None
    x = (
        next((x for x in a.camere if x.id == camera_id), None)
        if camera_id is not None
        else None
    )
    if camera_id is not None and x is None:
        raise NonTrovato("Camera non trovata in questa scheda.")
    if x is None:
        x = CameraGvr(versione=1, creato_da=attore.nome)
        a.camere.append(x)
    else:
        x.versione += 1
    x.identificazione = ident
    x.num_fabbrica = nf
    x.chiave = chiave
    x.unita = unita
    x.valore_decimi = int(dec * 10)
    x.attributi_json = json_dati(
        dati.get("attributi", json.loads(x.attributi_json or "{}"))
    )
    if "dati_tecnici" in dati:
        from .scheda_dm import CAMERA, valida
        raw = json.loads(x.attributi_json)
        raw.update(valida(dati["dati_tecnici"], CAMERA))
        x.attributi_json = json.dumps(raw, ensure_ascii=False)
    x.modificato_da = attore.nome
    x.modificato_il = adesso()
    traccia(s, attore, a, "asset.camera", prima)
    return a


def elimina_camera(s, attore, asset_id, camera_id, dati):
    a = leggi(s, asset_id)
    nativo(a)
    versione(a, dati.get("versione"))
    prima = scheda(s, a)
    x = next((x for x in a.camere if x.id == camera_id), None)
    if x is None:
        raise NonTrovato("Camera non trovata.")
    a.camere.remove(x)
    traccia(s, attore, a, "asset.camera_elimina", prima)
    return a


def associa(s, attore, asset_id, dati, elimina=False):
    a = leggi(s, asset_id)
    nativo(a)
    versione(a, dati.get("versione"))
    prima = scheda(s, a)
    p = leggi(s, intero(dati.get("accessorio_id"), "Accessorio"))
    if a.gruppo != "GVR" or p.gruppo != "PSV":
        raise ErroreUtente("Associa una valvola PSV a un bene GVR.")
    r = s.scalar(
        select(AssetRelazione).where(
            AssetRelazione.asset_id == a.id, AssetRelazione.accessorio_id == p.id
        )
    )
    if elimina:
        if r is None:
            raise NonTrovato("Associazione non trovata.")
        s.delete(r)
    elif r is not None:
        raise ErroreUtente("Valvola già associata.")
    else:
        s.add(
            AssetRelazione(
                asset_id=a.id,
                accessorio_id=p.id,
                creato_da=attore.nome,
                modificato_da=attore.nome,
            )
        )
    traccia(
        s,
        attore,
        a,
        "asset.accessorio_rimuovi" if elimina else "asset.accessorio_associa",
        prima,
    )
    return a


def dismetti(s, attore, asset_id, dati):
    a = leggi(s, asset_id)
    nativo(a)
    versione(a, dati.get("versione"))
    prima = scheda(s, a)
    v = dati.get("dismesso")
    motivo = testo(dati.get("motivo"), "Motivo", 1000)
    if type(v) is not bool:
        raise ErroreUtente("Indica se il bene è dismesso.")
    if v and not motivo:
        raise ErroreUtente("Scrivi il motivo della dismissione.")
    a.dismesso = v
    traccia(
        s,
        attore,
        a,
        "asset.dismetti" if v else "asset.riattiva",
        {"scheda": prima, "motivo": motivo},
    )
    return a


def cataloghi(s):
    from .scheda_dm import definizioni, CAMERA
    return {
        "schede_dm": {gr: definizioni(gr) for gr in ("SC", "SP", "GVR", "PSV")},
        "camera_dm": [{"nome": k, "etichetta": v[0], "massimo": v[2]} for k, v in CAMERA.items()],
        "gruppi": GRUPPI,
        "famiglie_gvr": [
            {"id": x.id, "codice": x.codice, "descrizione": x.descrizione}
            for x in s.scalars(select(FamigliaGvr).order_by(FamigliaGvr.id))
        ],
        "tipi_attrezzature": [
            {
                "id": x.id,
                "gruppo": x.gruppo,
                "codice": x.codice,
                "descrizione": x.descrizione,
                "famiglia_gvr_id": x.famiglia_gvr_id,
                "tipo_ver_gvr_1": x.tipo_ver_gvr_1,
                "tipo_ver_gvr_2": x.tipo_ver_gvr_2,
                "tipo_ver_gvr_3": x.tipo_ver_gvr_3,
            }
            for x in s.scalars(select(TipoAttrezzatura).order_by(TipoAttrezzatura.id))
        ],
        "id_specifiche": [
            {
                "id": x.id,
                "gruppo": x.gruppo,
                "codice": x.codice,
                "descrizione": x.descrizione,
            }
            for x in s.scalars(select(IdSpecifica).order_by(IdSpecifica.id))
        ],
        "compatibilita": [
            {
                "gruppo": x.gruppo,
                "tipo_attr_id": x.tipo_attr_id,
                "famiglia_gvr_id": x.famiglia_gvr_id,
                "id_spec_id": x.id_spec_id,
            }
            for x in s.scalars(
                select(CompatibilitaClassificazione).order_by(
                    CompatibilitaClassificazione.id
                )
            )
        ],
    }
