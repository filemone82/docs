"""Attributi della scheda DM: nomi e valori da adsrl/cust/meta/attrezzature.js.

I testi tecnici restano testi; non si inventano unità o conversioni. I valori
aggiuntivi sono conservati nel JSON della scheda, con validazione esplicita.
"""

import json
import re

from ...core.errori import ErroreUtente

COMUNI = {
    "cf_costr": ("CF costruttore", "testo", 16),
    "descr_attr": ("Descrizione attrezzatura", "area", 8000),
    "reparto": ("Reparto", "testo", 200),
    "rif_interno": ("Riferimento interno", "testo", 200),
    "marcatura_ce": ("Marcatura CE", "booleano", 0),
    "esente_verifiche": ("Esente verifiche", "enum", {"F": "No", "T": "Sì", "I": "ISO17020"}),
    "tipo_prox_verifica": ("Tipo prossima verifica", "enum", {"V1": "Prima periodica", "V2": "Successiva"}),
}
GVR = {
    # C11 (0.16, Federico 12/10/2026: «il tipo attrezzature verbale SOLO nel gvr»)
    "tipo_attr_verbale": ("Tipo attrezzatura verbale (es. RG, RV, GV, INS, TUB)", "testo", 200),
    "ps_attr_gvr": ("PS attrezzatura GVR", "testo", 200),
    "volume_attr_gvr": ("Volume attrezzatura GVR", "testo", 200),
    "ts_attr_gvr": ("TS attrezzatura GVR", "testo", 200),
    "sup_risc_attr_gvr": ("Superficie riscaldamento", "testo", 200),
    "prod_attr_gvr": ("Produzione", "testo", 200),
    "gruppo_fluido": ("Gruppo fluido", "enum", {"1": "Pericoloso", "2": "Non pericoloso"}),
    "cat_ped": ("Categoria PED", "enum", {k: k for k in ("I", "II", "III", "IV")}),
    "matr_insieme": ("Matricola insieme", "testo", 15),
    "id_pacco_bombola": ("ID pacco bombola", "testo", 15),
    "gvr_breve_descr_funz": ("Descrizione funzionamento/processo", "area", 8000),
}
SCSP = {
    "portata_attr_sc_sp": ("Portata attrezzatura SC/SP", "testo", 200),
    "n_panieri_idroestr": ("Numero panieri di riserva", "intero", 0),
}
PSV = {  # adsrl/cust/meta/valvole_sicurezza.js (0.12.4): erano solo nel database di Garda
    "tip_accessorio": ("Tipologia accessorio", "enum", {"valvola di sicurezza": "Valvola di sicurezza", "disco di rottura": "Disco di rottura",
                                                         "valvola intercettazione combustibile": "Valvola di intercettazione combustibile"}),
    "dn": ("DN", "testo", 50),
    "diametro": ("Diametro", "testo", 50),
    "area": ("Area", "testo", 50),
    "ptar": ("Pressione di taratura (Ptar)", "testo", 50),
}
CAMERA = {k: (label, "testo", 200) for k, label in {
    "gvr_ps": "PS (bar)", "gvr_ts": "TS (°C)", "gvr_nat": "Fluido: natura",
    "gvr_stt": "Fluido: stato", "gvr_grp": "Fluido: gruppo",
}.items()}


def campi(gruppo):
    if gruppo == "PSV":
        return PSV
    return COMUNI | (GVR if gruppo == "GVR" else SCSP if gruppo in ("SC", "SP") else {})


def definizioni(gruppo):
    return [{"nome": k, "etichetta": label, "tipo": tipo,
             **({"valori": v} if tipo == "enum" else {"massimo": v})}
            for k, (label, tipo, v) in campi(gruppo).items()]


def valida(dati, catalogo):
    if not isinstance(dati, dict) or set(dati) - set(catalogo):
        raise ErroreUtente("Attributi DM non riconosciuti.")
    out = {}
    for k, val in dati.items():
        label, tipo, limite = catalogo[k]
        if tipo == "booleano":
            if val is not None and not isinstance(val, bool):
                raise ErroreUtente(f"{label}: scegli Sì o No.")
            out[k] = val
        elif tipo == "intero":
            if val in (None, ""):
                out[k] = None
            elif isinstance(val, bool) or not re.fullmatch(r"[0-9]+", str(val)):
                raise ErroreUtente(f"{label}: scrivi un intero non negativo.")
            else:
                out[k] = int(val)
        else:
            if not isinstance(val, (str, int, float)) and val is not None:
                raise ErroreUtente(f"{label}: valore non valido.")
            t = str(val or "").strip()
            if tipo == "enum" and t and t not in limite:
                raise ErroreUtente(f"{label}: valore non previsto.")
            if tipo != "enum" and len(t) > limite:
                raise ErroreUtente(f"{label}: massimo {limite} caratteri.")
            if k == "matr_insieme" and t and not re.fullmatch(r"[0-9]{4}/[A-Za-z0-9]/[0-9]{5}/[A-Za-z]{2}", t):
                raise ErroreUtente("Matricola insieme: formato AAAA/F/NNNNN/PR.")
            out[k] = t
    return out


def salva(a, dati):
    correnti = json.loads(a.attributi_json or "{}")
    correnti.update(valida(dati, campi(a.gruppo)))
    # Esattamente come gi_attrezzature_save_before: niente campi dell'altro gruppo.
    for k in (SCSP if a.gruppo == "GVR" else GVR):
        if k != "tipo_attr_verbale":  # C11: su SC/SP importate il valore resta conservato (non si mostra né si modifica)
            correnti.pop(k, None)
    a.attributi_json = json.dumps(correnti, ensure_ascii=False)


def controlla_matricola(a, nuovi=False, dati=None):
    if a.gruppo not in ("GVR", "SC", "SP"):
        return
    regole = {"anno_matricola": (r"[0-9]{4}", "4 cifre"),
              "cod_att_matricola": (r"[A-Za-z0-9]", "un carattere alfanumerico"),
              "num_matricola": (r"[0-9]{5}", "5 cifre, conservando gli zeri"),
              "prov_immatr": (r"[A-Za-z]{2}", "2 lettere")}
    for k, n in {"num_fabbrica": 50, "costruttore": 60, "modello": 60}.items():
        if (nuovi or k in (dati or {})) and len(getattr(a, k) or "") > n:
            raise ErroreUtente(f"{k}: massimo {n} caratteri, come in Garda.")
    for k, (regex, messaggio) in regole.items():
        # Schede pregresse 0.9 incomplete non vengono riempite artificialmente.
        # Si controllano creazione, campi toccati e ingresso nel flusso DM.
        if nuovi or k in (dati or {}):
            if not re.fullmatch(regex, getattr(a, k) or ""):
                raise ErroreUtente(f"{k}: servono {messaggio}.")


def avvisi(a):
    return [f"{nome} non indicato" for key, nome in (("num_fabbrica", "Numero fabbrica"),
            ("costruttore", "Costruttore"), ("modello", "Modello")) if not getattr(a, key)]
