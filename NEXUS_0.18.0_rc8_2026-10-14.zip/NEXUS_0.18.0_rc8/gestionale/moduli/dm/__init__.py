"""Regole specifiche DM sul nucleo anagrafico e commerciale comune."""
