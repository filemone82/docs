"""Impaginazione dei verbali DM come in VerbalizzAI (0.15, R123; documento 24 § 5, documento 28 punti 17–18).

I modelli restano quelli di AD (M14-PO01_dm per i GVR, M11-PO01_dm per SC/SP): sono documenti del sistema di gestione
e non si toccano. Cambia solo la generazione:

- **riquadro firme intero**: le tabelle «Luogo, data», «Firme» e «Data della prossima verifica» non si spezzano fra due
  pagine (righe non divisibili, paragrafi «mantieni con il successivo»);
- **riquadro firme in fondo alla pagina**: come VerbalizzAI 1.0.0 rc3, una prima conversione con un segnalibro
  invisibile sotto il riquadro dice dove cade; la generazione definitiva aggiunge sopra il riquadro lo spazio che
  manca al fondo dell'area di testo (misurato una volta per modello con una pagina «sonda»);
- **spazio firma riservato** nell'anteprima: al posto della firma un'immagine trasparente con lo stesso ingombro,
  così all'emissione la firma prende il suo posto senza cambiare righe né pagine; il numero di pagine si controlla.

Le misure richiedono LibreOffice; se non si riesce a misurare, il riquadro resta dove cade (sempre intero).
"""

from __future__ import annotations

import hashlib
import io
import re
import threading
from zipfile import ZIP_DEFLATED, ZipFile

from lxml import etree

from ...core import word

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
WP = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
A = "http://schemas.openxmlformats.org/drawingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
RISERVATO = "AD_SPAZIO_FIRMA_DM"
RID_RISERVATO, RID_FIRMA = "rIdDMSpazioFirma", "rIdDMFirma"
SEGNO, SONDA, MARGINE = "ADFIRMADM", "ADSONDADM", 6.0


def _w(tag):
    return f"{{{W}}}{tag}"


def _testo(el):
    return "".join(t.text or "" for t in el.iter(_w("t")))


# ---------------------------------------------------------------- riquadro firme intero

def blocco_firme(body) -> list:
    """Le tabelle del riquadro finale: «Luogo, data» (se subito prima), «Firma del Verificatore», «prossima verifica»
    (se subito dopo), con gli eventuali paragrafi vuoti in mezzo."""
    figli = list(body)
    i = next((k for k, x in enumerate(figli) if x.tag == _w("tbl") and "firma del verificatore" in _testo(x).casefold()), None)
    if i is None:
        return []
    inizio, fine = i, i

    def vuoto(x):
        return x.tag == _w("p") and not _testo(x).strip() and x.find(".//" + _w("drawing")) is None

    k = i - 1
    while k >= 0 and vuoto(figli[k]):
        k -= 1
    if k >= 0 and figli[k].tag == _w("tbl") and "luogo" in _testo(figli[k]).casefold():
        inizio = k
    k = i + 1
    while k < len(figli) and vuoto(figli[k]):
        k += 1
    if k < len(figli) and figli[k].tag == _w("tbl") and "prossima" in _testo(figli[k]).casefold():
        fine = k
    return figli[inizio:fine + 1]


def tieni_insieme(root) -> int:
    body = root.find(_w("body"))
    blocco = blocco_firme(body)
    if not blocco:
        return 0
    ultimi = set()
    ultima_tabella = [x for x in blocco if x.tag == _w("tbl")][-1]
    righe = ultima_tabella.findall(_w("tr"))
    if righe:
        ultimi = set(righe[-1].iter(_w("p")))
    for x in blocco:
        for tr in x.iter(_w("tr")):
            pr = tr.find(_w("trPr"))
            if pr is None:
                pr = etree.Element(_w("trPr"))
                tr.insert(0, pr)
            if pr.find(_w("cantSplit")) is None:
                pr.append(etree.Element(_w("cantSplit")))
        for p in x.iter(_w("p")):
            if p in ultimi:
                continue
            ppr = p.find(_w("pPr"))
            if ppr is None:
                ppr = etree.Element(_w("pPr"))
                p.insert(0, ppr)
            if ppr.find(_w("keepNext")) is None:
                ppr.insert(0, etree.Element(_w("keepNext")))
    return len(blocco)


def _paragrafino(testo="", prima=0, tieni=False, livello=False):
    """Paragrafo alto 1 punto, carattere bianco da 1 punto (come VerbalizzAI)."""
    p = etree.Element(_w("p"))
    pr = etree.SubElement(p, _w("pPr"))
    if tieni:
        etree.SubElement(pr, _w("keepNext"))
    etree.SubElement(pr, _w("spacing"), {_w("before"): str(int(prima)), _w("after"): "0", _w("line"): "20", _w("lineRule"): "exact"})
    if livello:
        etree.SubElement(pr, _w("outlineLvl"), {_w("val"): "0"})
    rpr = etree.SubElement(pr, _w("rPr"))
    etree.SubElement(rpr, _w("color"), {_w("val"): "FFFFFF"})
    etree.SubElement(rpr, _w("sz"), {_w("val"): "2"})
    if testo:
        r = etree.SubElement(p, _w("r"))
        rp = etree.SubElement(r, _w("rPr"))
        etree.SubElement(rp, _w("color"), {_w("val"): "FFFFFF"})
        etree.SubElement(rp, _w("sz"), {_w("val"): "2"})
        t = etree.SubElement(r, _w("t"))
        t.text = testo
    return p


def coda_minima(root) -> int:
    """I paragrafi vuoti dopo il riquadro (il modello finisce con un paragrafo vuoto dopo la tabella) diventano alti
    1 punto: con il riquadro spinto in fondo, altrimenti, il paragrafo finale aprirebbe una pagina bianca. Ne resta
    almeno uno, perché Word vuole un paragrafo dopo l'ultima tabella."""
    body = root.find(_w("body"))
    blocco = blocco_firme(body)
    if not blocco:
        return 0
    dopo, n = blocco[-1].getnext(), 0
    while dopo is not None and dopo.tag == _w("p"):
        prossimo = dopo.getnext()
        if _testo(dopo).strip() or dopo.find(".//" + _w("drawing")) is not None:
            break
        sect = dopo.find(_w("pPr") + "/" + _w("sectPr"))
        nuovo = _paragrafino()
        if sect is not None:
            nuovo.find(_w("pPr")).append(sect)
        dopo.addprevious(nuovo)
        body.remove(dopo)
        n += 1
        dopo = prossimo
    return n


def segna(root) -> bool:
    """Generazione di misura: segnalibro invisibile subito sotto il riquadro firme."""
    body = root.find(_w("body"))
    blocco = blocco_firme(body)
    if not blocco or root.findall(".//" + _w("pPr") + "/" + _w("sectPr")):
        return False
    blocco[-1].addnext(_paragrafino(SEGNO, livello=True))
    return True


def spingi_in_fondo(root, spazio: float) -> bool:
    if not spazio or spazio < 2:
        return False
    body = root.find(_w("body"))
    blocco = blocco_firme(body)
    if not blocco:
        return False
    blocco[0].addprevious(_paragrafino(prima=round((spazio - 1) * 20), tieni=True))
    return True


# ---------------------------------------------------------------- misure sul PDF

_fondi: dict[str, float | None] = {}
_lucchetto = threading.Lock()


def _parti(docx: bytes):
    with ZipFile(io.BytesIO(docx)) as z:
        return {n: z.read(n) for n in z.namelist()}


def _scrivi(parti: dict) -> bytes:
    out = io.BytesIO()
    with ZipFile(out, "w", ZIP_DEFLATED) as z:
        for n, raw in parti.items():
            z.writestr(n, raw)
    return out.getvalue()


def chiave_pagina(docx: bytes) -> str:
    parti = _parti(docx)
    root = etree.fromstring(parti["word/document.xml"])
    sect = root.find(_w("body") + "/" + _w("sectPr"))
    pezzi = [etree.tostring(sect) if sect is not None else b""]
    pezzi += [parti[n] for n in sorted(parti) if re.match(r"word/(header|footer)\d+\.xml$", n)]
    return hashlib.sha256(b"\0".join(pezzi)).hexdigest()


def fondo_pagina(docx: bytes, converti) -> float | None:
    """Quota (punti PDF dal basso) dell'ultimo paragrafo da 1 punto che entra nella prima pagina."""
    from ...terzi.verbalizzai import pdfconv
    chiave = chiave_pagina(docx)
    with _lucchetto:
        if chiave in _fondi:
            return _fondi[chiave]
    try:
        parti = _parti(docx)
        root = etree.fromstring(parti["word/document.xml"])
        body = root.find(_w("body"))
        sect = body.find(_w("sectPr"))
        for c in list(body):
            body.remove(c)
        for i in range(900):
            body.append(_paragrafino(SONDA + str(i), livello=True))
        if sect is not None:
            body.append(sect)
        parti["word/document.xml"] = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
        punti, totale = pdfconv.outline_points(converti(_scrivi(parti)))
        ys = [y for t, pg, y in punti if t.strip().startswith(SONDA) and pg == 0 and y is not None]
        fondo = min(ys) if totale > 1 and len(ys) > 100 else None
    except Exception:  # noqa: BLE001 - senza misura il riquadro resta dove cade
        fondo = None
    with _lucchetto:
        _fondi[chiave] = fondo
    return fondo


def spazio_mancante(docx_misura: bytes, pdf_misura: bytes, converti) -> float:
    from ...terzi.verbalizzai import pdfconv
    try:
        punti, _ = pdfconv.outline_points(pdf_misura)
    except Exception:  # noqa: BLE001
        return 0.0
    segni = [(pg, y) for t, pg, y in punti if t.strip() == SEGNO]
    if len(segni) != 1 or segni[0][1] is None:
        return 0.0
    fondo = fondo_pagina(docx_misura, converti)
    if fondo is None:
        return 0.0
    return max(0.0, round(segni[0][1] - fondo - MARGINE, 1))


def pagine(pdf: bytes) -> int:
    from pypdf import PdfReader
    return len(PdfReader(io.BytesIO(pdf)).pages)


# ---------------------------------------------------------------- firma: spazio riservato e sostituzione

def sostituisci_firma(docx: bytes, firma: bytes) -> bytes:
    """Emissione: nell'anteprima (anche ritoccata in Word) l'immagine dello spazio riservato diventa la firma DM, con
    lo stesso ingombro. Errore se lo spazio non c'è più (ritocco che lo ha tolto)."""
    from ...core.errori import ErroreUtente
    from ...terzi.verbalizzai import templates
    parti = _parti(docx)
    root = word._leggi_xml(parti["word/document.xml"])
    trovati = [d for d in root.iter(f"{{{WP}}}docPr") if RISERVATO in (d.get("name", ""), d.get("descr", ""))]
    if not trovati:
        raise ErroreUtente("Nell'anteprima manca lo spazio riservato alla firma: rigenera l'anteprima "
                           "(nel ritocco Word non va cancellato il riquadro della firma).")
    fmt, _, _ = templates.image_info(firma)
    ext = "png" if fmt == "png" else "jpeg"
    for i, d in enumerate(trovati, 1):
        d.set("name", f"Firma DM {i}")
        d.set("descr", f"Firma DM {i}")
        inline = d.getparent()
        for blip in inline.iter(f"{{{A}}}blip"):
            blip.set(f"{{{R}}}embed", RID_FIRMA)
    parti["word/document.xml"] = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
    media = f"media/dm_firma.{ext}"
    parti["word/" + media] = firma
    rels = word._leggi_xml(parti["word/_rels/document.xml.rels"])
    ns_rel = "http://schemas.openxmlformats.org/package/2006/relationships"
    for e in list(rels):
        if e.get("Id") == RID_FIRMA:
            rels.remove(e)
    etree.SubElement(rels, f"{{{ns_rel}}}Relationship", Id=RID_FIRMA, Target=media,
                     Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image")
    parti["word/_rels/document.xml.rels"] = etree.tostring(rels, xml_declaration=True, encoding="UTF-8")
    ct = word._leggi_xml(parti["[Content_Types].xml"])
    if not any(e.get("Extension") == ext for e in ct):
        etree.SubElement(ct, "{http://schemas.openxmlformats.org/package/2006/content-types}Default", Extension=ext,
                         ContentType="image/" + ext)
    parti["[Content_Types].xml"] = etree.tostring(ct, xml_declaration=True, encoding="UTF-8")
    return _scrivi(parti)


def ha_spazio_riservato(docx: bytes) -> bool:
    root = word._leggi_xml(_parti(docx)["word/document.xml"])
    return any(RISERVATO in (d.get("name", ""), d.get("descr", "")) for d in root.iter(f"{{{WP}}}docPr"))


def applica(docx: bytes, misura: bool = False, spazio: float = 0.0) -> bytes:
    """Riquadro intero; con `misura` il segnalibro sotto il riquadro; con `spazio` il distanziatore sopra."""
    parti = _parti(docx)
    root = word._leggi_xml(parti["word/document.xml"])
    tieni_insieme(root)
    coda_minima(root)
    if misura:
        segna(root)
    elif spazio:
        spingi_in_fondo(root, spazio)
    parti["word/document.xml"] = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
    return _scrivi(parti)
