from typing import Annotated

from fastapi import APIRouter, Body, Depends
from fastapi.responses import Response
from sqlalchemy import select

from ...core.db import Archivio
from ...core.errori import ErroreUtente, NonTrovato
from ...web.dipendenze import archivio, richiede
from ..documenti import servizio as documenti
from ..utenti.accesso import UtenteCorrente
from . import inail, tecnico
from .modelli import IncaricoDM, EsportazioneINAIL

router = APIRouter(prefix='/api/dm/inail')
U = Annotated[UtenteCorrente, Depends(richiede('dm.inail', 'DM'))]
A = Annotated[Archivio, Depends(archivio)]


@router.get('/candidati')
def candidati(u: U, arc: A):
    with arc.lettura() as s:
        return [{'id': v.id, 'versione': v.versione, 'codice': v.codice_verbale,
                 'data': str(v.data_rilascio), 'esportata': v.esportata_inail}
                for v in s.scalars(select(IncaricoDM).where(IncaricoDM.stato == 'effettuata').order_by(IncaricoDM.id))]


@router.post('/anteprima')
def anteprima(d: Annotated[dict, Body(...)], u: U, arc: A):
    with arc.lettura() as s:
        return inail.anteprima(s, arc, d.get('incarichi'))


@router.post('/lotti')
def crea(d: Annotated[dict, Body(...)], u: U, arc: A):
    with arc.scrittura() as s:
        return inail.crea(s, arc, u, d)


@router.get('/lotti')
def lotti(u: U, arc: A):
    with arc.lettura() as s:
        return [{'id': x.id, 'data': x.creato_il.isoformat(), 'utente': x.creato_da,
                 'url': f'/api/dm/inail/lotti/{x.id}/file'}
                for x in s.scalars(select(EsportazioneINAIL).order_by(EsportazioneINAIL.id.desc()))]


@router.get('/lotti/{id}/file')
def scarica(id: int, u: U, arc: A):
    with arc.lettura() as s:
        x = s.get(EsportazioneINAIL, id)
        if not x:
            raise NonTrovato('Lotto INAIL non trovato.')
        _, raw = documenti.leggi(s, arc.cfg.cartella_documenti, x.documento_id)
    return Response(raw, media_type='application/zip',
        headers={'Content-Disposition': f'attachment; filename="INAIL_lotto_{id}.zip"'})


@router.post('/reimposta')
def reimposta(d: Annotated[dict, Body(...)], u: U, arc: A):
    xs = d.get('incarichi')
    if not isinstance(xs, list) or not xs or len(xs) > 1000 or not str(d.get('motivo', '')).strip():
        raise ErroreUtente('Scegli le verifiche e indica il motivo della riesportazione.')
    ids = []
    with arc.scrittura() as s:
        for item in xs:
            v = tecnico.leggi(s, item['id'])
            tecnico.versione_obbligatoria(v, item.get('versione'))
            if v.id in ids:
                raise ErroreUtente('Selezione duplicata.')
            ids.append(v.id)
            v.esportata_inail = False
            tecnico.scrivi(s, u, v, 'reimposta_inail', {'motivo': d['motivo']})
    return {'reimpostate': len(ids)}
