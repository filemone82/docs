"""Documenti DM, fotografie di emissione e riesame specifico Garda.

Il PDF visto e confermato è archiviato per impronta ed è quello trasmesso.
Il riesame negativo applica la deroga R101 approvata, preservando lo storico.
"""
import hashlib
import io
import json
import re
from uuid import uuid4

from pypdf import PdfReader
from sqlalchemy import select

from ...core import pdf
from ...core.db import adesso
from ...core.date import iso_locale
from ...core.errori import ErroreUtente, NonTrovato, PermessoNegato
from ...terzi.verbalizzai.finalization import content_signature
from ..beni.modelli import TipoAttrezzatura, IdSpecifica, FamigliaGvr
from ..documenti import servizio as archivio
from ..documenti.modelli import Documento
from ..utenti.modelli import Utente
from .modelli import DocumentoDM, RiesameDM
from . import tecnico, word

PROFILO = {'nome', 'cognome', 'qualifica', 'codice_fiscale'}


def dumps(x):
    return json.dumps(x, sort_keys=True, ensure_ascii=False, separators=(',', ':'))


def profilo_json(u):
    raw = json.loads(u.dati_tecnici_json)
    return {'utente_id': u.id, 'versione': u.versione, **{k: '' for k in PROFILO}, **{k: v for k, v in raw.items() if k in PROFILO},
            'firma_dm': bool(raw.get('firma_dm_documento_id'))}


# ---------------------------------------------------------------- 0.13.0: firma grafica per i verbali DM
# Federico, 12/10/2026: «ogni utente abbia una firma dpr e una firma dm, il gestionale utilizza quella corretta».
# La firma DPR resta quella di VerbalizzAI (Configurazione › Firme dei verificatori); la firma DM è nell'archivio dei
# documenti del gestionale, collegata al profilo del tecnico. I verbali DM usano solo la firma DM.
def _puo_firma(u, id):
    if not u.puo('sistema.utenti') and not (u.id == id and u.puo('verifiche.esegui', 'DM')):
        raise PermessoNegato('Puoi aggiornare soltanto la tua firma.')


def firma_dm(s, arc, utente_id):
    x = s.get(Utente, utente_id)
    doc_id = json.loads(x.dati_tecnici_json).get('firma_dm_documento_id') if x else None
    if not doc_id:
        return None
    return archivio.leggi(s, arc.cfg.cartella_documenti, doc_id)[1]


def salva_firma_dm(s, arc, u, id, raw, nome):
    from ...terzi.verbalizzai.templates import image_info
    _puo_firma(u, id)
    target = s.get(Utente, id)
    if target is None:
        raise NonTrovato('Utente non trovato.')
    if len(raw) > 2 * 1024 * 1024:
        raise ErroreUtente('Immagine della firma troppo grande: massimo 2 MB.')
    try:
        fmt, w, h = image_info(raw)
    except ValueError as e:
        raise ErroreUtente(str(e)) from None
    if w < 50 or h < 20:   # stesso limite della firma DPR di VerbalizzAI (AD-REV-008)
        raise ErroreUtente(f'Immagine della firma troppo piccola ({w} × {h} pixel): il minimo è 50 × 20 pixel; '
                           'per una firma leggibile si consiglia una scansione di almeno 300 × 100 pixel.')
    doc = archivio.salva(s, arc.cfg.cartella_documenti, raw, nome, 'image/png' if fmt == 'png' else 'image/jpeg', u.id,
                         'Firma grafica per i verbali DM')
    dati = json.loads(target.dati_tecnici_json)
    dati['firma_dm_documento_id'] = doc.id
    target.dati_tecnici_json = dumps(dati)
    target.versione += 1
    from ..registro import servizio as registro
    registro.scrivi(s, utente=u.come_attore(), azione='utente.firma_dm', oggetto_tipo='utente', oggetto_id=id,
                    descrizione='Caricata la firma grafica per i verbali DM', dettagli={'documento_id': doc.id})
    return profilo_json(target)


def togli_firma_dm(s, u, id):
    _puo_firma(u, id)
    target = s.get(Utente, id)
    if target is None:
        raise NonTrovato('Utente non trovato.')
    dati = json.loads(target.dati_tecnici_json)
    if dati.pop('firma_dm_documento_id', None):
        target.dati_tecnici_json = dumps(dati)
        target.versione += 1
        from ..registro import servizio as registro
        registro.scrivi(s, utente=u.come_attore(), azione='utente.firma_dm', oggetto_tipo='utente', oggetto_id=id,
                        descrizione='Tolta la firma grafica per i verbali DM')
    return profilo_json(target)


def salva_profilo(s, u, id, dati):
    target = s.get(Utente, id)
    if target is None:
        raise NonTrovato('Tecnico non trovato.')
    if not u.puo('sistema.utenti') and not (u.id == id and u.puo('verifiche.esegui', 'DM')):
        raise PermessoNegato('Puoi aggiornare soltanto i tuoi dati tecnici.')
    tecnico.versione_obbligatoria(target, dati.get('versione'))
    if set(dati) - PROFILO - {'versione'}:
        raise ErroreUtente('Campi del profilo non riconosciuti.')
    raw = json.loads(target.dati_tecnici_json)
    for k in PROFILO & set(dati):
        val = dati[k]
        if not isinstance(val, str) or len(val) > (16 if k == 'codice_fiscale' else 120):
            raise ErroreUtente('Dati tecnico non validi: ' + k)
        raw[k] = val.strip().upper() if k == 'codice_fiscale' else val.strip()
    target.dati_tecnici_json = dumps(raw)
    target.versione += 1
    from ..registro import servizio as registro
    registro.scrivi(s, utente=u.come_attore(), azione='utente.dati_tecnici', oggetto_tipo='utente',
        oggetto_id=id, descrizione='Aggiornati dati identificativi del tecnico DM')
    return profilo_json(target)


def dati_revisione(v):
    """R134: riferimento al documento sostituito, indipendente dalla data della nuova revisione."""
    numero = getattr(v, 'revisione', 0) or 0
    if not numero:
        return {'numero': 0, 'dicitura': ''}
    storico = json.loads(v.revisioni_json or '[]')
    prima = next((x for x in reversed(storico) if x.get('revisione') == numero), None)
    if not prima or not prima.get('emesso_il'):
        raise ErroreUtente('Manca la data del verbale sostituito nello storico della revisione: controlla il riferimento.')
    codice = prima.get('codice_precedente') or v.codice_verbale  # compatibilità con la 0.16.0
    if prima.get('precedente'):
        codice += f" rev. {prima['precedente']}"
    try:
        data = word.data(prima['emesso_il'])
    except (TypeError, ValueError):
        raise ErroreUtente('La data del verbale sostituito nello storico della revisione non è valida.') from None
    return {'numero': numero, 'codice_precedente': codice, 'data_precedente': prima['emesso_il'],
            'dicitura': f'Sostituisce il verbale n. {codice} emesso il {data}.'}


def valori(s, v, arc):
    a, r, _ = tecnico.dati_lavoro(s, v)
    d = json.loads(v.bozza_json)
    raw = json.loads(a.attributi_json)
    u = s.get(Utente, v.verificatore_id)
    profilo = profilo_json(u)
    fam = s.get(FamigliaGvr, a.tipo_attr_gvr_id) if a.tipo_attr_gvr_id else None
    tipo = s.get(TipoAttrezzatura, a.tipo_attr_id)
    spec = s.get(IdSpecifica, a.id_spec_id)
    parti = tecnico.componenti(a.gruppo, r.tipo_verifica_gvr)
    sede = a.sede
    firma = firma_dm(s, arc, u.id)  # 0.13.0: la firma DM del tecnico, non quella DPR di VerbalizzAI
    vfields = dict(d['campi'])
    for k in ('gvr_es_spess_data', 'gvr_tub_data', 'gvr_ril_il'):
        if k in vfields:
            vfields[k] = word.data(vfields[k])
    revisione = dati_revisione(v)
    codice_stampato = f'{a.gruppo} {v.numero}/{v.anno}'
    if revisione['numero']:
        codice_stampato += f" · rev. {revisione['numero']}"
    if revisione['numero']:
        vfields['revisione_dicitura'] = revisione['dicitura']
    vfields.update({'rp_codice': codice_stampato, 'cliente': sede.cliente.ragione_sociale,
        'att_modello': '/' if a.modello.casefold() in ('n.a.', 'n.a', 'na') else a.modello,
        'tipo_attr': d.get('tipo_attr', ''), 'data_rilascio_verbale': word.data(d.get('data_rilascio')),
        'esito_ok': d['esito'] == 'Positivo', 'esito_ko': d['esito'] == 'Negativo',
        'gvr_ver_prima': r.tipo_verifica_dm == 'V1', 'gvr_ver_funz': 'funz' in parti,
        'gvr_ver_integr': 'integrita' in parti, 'gvr_ver_intern': 'interna' in parti,
        'gvr_stato_funz': a.gruppo == 'GVR' and 'funz' in parti,
        'gvr_stato_cons': a.gruppo == 'GVR' and r.tipo_verifica_gvr != 'funz',
        'gvr_capacita': d.get('volume_totale_litri', ''),
        'gvr_sup_risc': raw.get('sup_risc_attr_gvr', '') if fam and fam.codice == 'a2' else '///',
        'gvr_prod': raw.get('prod_attr_gvr', '') if fam and fam.codice == 'a2' else '///',
        'sc_sp_ver_prima': r.tipo_verifica_dm == 'V1', 'sc_sp_ver_succ': r.tipo_verifica_dm == 'V2'})
    for k in tecnico.DATE:
        vfields['data_prox_' + k] = word.data(d.get('date', {}).get(k))
    c = tipo.codice if tipo else ''
    sid = spec.codice if spec else ''
    flags = {'sc_sp_gru': a.gruppo == 'SC' and c in ('a1','a2','a3','a4','b1','b2','b3'),
        'sc_sp_pont_mob': a.gruppo == 'SP' and c in ('b','c'), 'sc_sp_piatt_auto': a.gruppo == 'SP' and c == 'e',
        'sc_sp_carr_semov': a.gruppo == 'SC' and c == 'c', 'sc_sp_pont_sosp': a.gruppo == 'SP' and c == 'd' and sid == '2',
        'sc_sp_carr_frutt': a.gruppo == 'SP' and c == 'd' and sid == '1',
        'sc_sp_idroestr': a.gruppo == 'SC' and c in ('d1','d2','d3'),
        'sc_sp_scala': a.gruppo == 'SP' and c == 'a', 'sc_sp_ascens': a.gruppo == 'SP' and c == 'f'}
    vfields.update(flags)
    # Sbarrature di stampa, non cancellazione dei dati della bozza (hook Garda).
    if a.gruppo == 'GVR':
        if 'funz' not in parti:
            for k in ('gvr_acc_sicur','gvr_disp_contr','gvr_disp_regol','gvr_altri_acc','gvr_valv_interc'):
                vfields[k] = '///'
        if r.tipo_verifica_gvr == 'funz':
            for k in ('gvr_esame_vis_gen','gvr_prove_sicur_gen','gvr_es_spess_eseg','gvr_es_spess_esito',
                      'gvr_altre_prove','gvr_tub_prove','gvr_tub_esito','gvr_tub_stato'):
                vfields[k] = '///'
        if not ('funz' in parti and fam and fam.codice == 'a2'):
            vfields.update(gvr_check_param_acqua=False, gvr_check_conduttore=False, gvr_cond='///', gvr_abil_n='///', gvr_ril_il='')
    vals = {**{'v.' + k: val for k, val in vfields.items()},
        'a.matr_informale': a.matr_informale, 'a.num_fabbrica': a.num_fabbrica,
        'a.rag_soc_costr': a.costruttore, 'a.portata_attr_sc_sp': raw.get('portata_attr_sc_sp', ''),
        'o.indirizzo': sede.indirizzo, 'o.comune': sede.comune, 'o.prov': sede.provincia,
        'u.nome': profilo['nome'], 'u.cognome': profilo['cognome'], 'u.qualifica': profilo['qualifica']}
    camere = []
    for x in d.get('camere', []):
        row = dict(x.get('attributi', {}), gvr_att=x['identificazione'], gvr_nf=x['num_fabbrica'],
            gvr_vol=x['valore'] if x['unita'] == 'L' else '', gvr_dn=x['valore'] if x['unita'] == 'DN' else '',
            gvr_pes=x.get('gvr_pes', ''), gvr_tes=x.get('gvr_tes', ''))
        camere.append({k: row.get(k, '') for k in ('gvr_att','gvr_nf','gvr_vol','gvr_dn','gvr_ps','gvr_ts','gvr_nat','gvr_stt','gvr_grp','gvr_pes','gvr_tes')})
    from ..documenti import modelli_servizio
    m = modelli_servizio.in_uso(s, 'verbale_dm_gvr' if a.gruppo == 'GVR' else 'verbale_dm_scsp')
    _, modello = archivio.leggi(s, arc.cfg.cartella_documenti, m.documento_id)
    fotografia = {'bozza': d, 'valori': vals, 'camere': camere, 'tecnico_id': u.id,
                 'modello_sha256': hashlib.sha256(modello).hexdigest(), 'firma_sha256': hashlib.sha256(firma).hexdigest() if firma else ''}
    if revisione['numero']:
        fotografia['revisione_verbale'] = revisione
    fotografia['modello'] = {'id': m.id, 'codice': m.codice, 'revisione': m.revisione}
    impronta = hashlib.sha256(dumps(fotografia).encode()).hexdigest()
    nome = f'{a.gruppo}_{v.numero}-{v.anno} - {sede.cliente.ragione_sociale} - {a.matr_informale} - {tecnico.TIPI[r.tipo_verifica_dm]}'
    nome = re.sub(r'[^a-z0-9_ -]+', ' ', nome, flags=re.I).strip()[:80]
    return {'fotografia': fotografia, 'impronta': impronta, 'modello': modello, 'valori': vals,
            'camere': camere, 'firma': firma, 'nome': nome}


def valida_pdf(raw):
    if len(raw) > 25 * 1024 * 1024 or not raw.startswith(b'%PDF-'):
        raise ErroreUtente('Carica un PDF valido, massimo 25 MB.')
    try:
        reader = PdfReader(io.BytesIO(raw))
        if reader.is_encrypted or not 1 <= len(reader.pages) <= 500:
            raise ValueError()
        for page in reader.pages:
            _ = page.mediabox
    except Exception:
        raise ErroreUtente('PDF non leggibile o protetto: esportalo nuovamente senza password.') from None


def corrente(s, v, tipo='verbale', formato='pdf'):
    return s.scalar(select(DocumentoDM).where(DocumentoDM.incarico_id == v.id, DocumentoDM.tipo == tipo,
        DocumentoDM.formato == formato, DocumentoDM.attuale.is_(True)).order_by(DocumentoDM.id.desc()))


def elenco(s, v):
    return [{'id': x.id, 'tipo': x.tipo, 'formato': x.formato, 'nome': x.nome_file, 'attuale': x.attuale,
        'definitivo': x.definitivo_il is not None, 'origine': x.origine, 'creato_da': x.creato_da,
        'creato_il': iso_locale(x.creato_il), 'impronta': s.get(Documento, x.documento_id).impronta,
        'url': f'/api/dm/incarichi/{v.id}/documenti/{x.id}'}
        for x in s.scalars(select(DocumentoDM).where(DocumentoDM.incarico_id == v.id).order_by(DocumentoDM.id.desc()))]


def salva(s, arc, u, v, prep, files, tipo='verbale', origine='generato'):
    if tipo not in ('verbale', 'scheda_tecnica'):
        raise ErroreUtente('Tipo documento non valido.')
    for x in s.scalars(select(DocumentoDM).where(DocumentoDM.incarico_id == v.id, DocumentoDM.tipo == tipo,
                       DocumentoDM.attuale.is_(True))):
        x.attuale = False
    gruppo = str(uuid4())
    bozza = ' - BOZZA' if tipo == 'verbale' and origine in ('anteprima', 'word_ritoccato') else ''
    for formato, raw in files.items():
        if formato not in ('pdf', 'docx'):
            continue
        mime = 'application/pdf' if formato == 'pdf' else 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        rev = f' rev. {v.revisione}' if getattr(v, 'revisione', 0) and tipo == 'verbale' else ''  # R134 (0.16)
        name = prep['nome'] + rev + ('' if tipo == 'verbale' else ' - scheda tecnica') + bozza + '.' + formato
        doc = archivio.salva(s, arc.cfg.cartella_documenti, raw, name, mime, u.id)
        s.add(DocumentoDM(incarico_id=v.id, documento_id=doc.id, tipo=tipo, formato=formato, gruppo=gruppo,
            nome_file=name, attuale=True, impronta_dati=prep['impronta'],
            fotografia_json=dumps(prep['fotografia'] | ({'pagine': files['pagine']} if files.get('pagine') else {})),
            origine=origine, creato_da=u.nome))
    tecnico.scrivi(s, u, v, 'documento_' + origine, tecnico.stato(v))
    s.flush()


def prepara(s, arc, u, v, versione):
    tecnico.versione_obbligatoria(v, versione)
    tecnico.esecutore(u, v)
    tecnico.dpr.richiedi_indipendenza(v)  # R110
    tecnico.attivabile(s, v)
    if v.stato != 'registrata':
        raise ErroreUtente('Registra prima la scheda tecnica del verbale.')
    tecnico._valida_registrazione(s, v, json.loads(v.bozza_json))
    return valori(s, v, arc)


def compila(prep, arc, word_ritoccato=None):
    """0.15: anteprima come in VerbalizzAI. Spazio della firma riservato (la firma DM entra all'emissione), riquadro
    firme intero e spinto in fondo alla pagina (misura sul PDF di LibreOffice). Il Word ritoccato si converte com'è."""
    from . import impaginazione as imp
    if not word_ritoccato and not all(prep['valori']['u.' + k] for k in ('nome', 'cognome')):
        raise ErroreUtente('Completa nome e cognome del tecnico prima di generare il Word (campi obbligatori Garda).')
    if not word_ritoccato and not prep['firma']:
        raise ErroreUtente('Il tecnico non ha ancora la firma DM: caricala in «Il mio profilo» (o in Gestione › Utenti) '
                           'prima dell\'anteprima. Nei verbali DM si usa solo la firma DM.')
    if word_ritoccato:
        docx = word_ritoccato
    else:
        def converti(x):
            return pdf.da_word(x, arc.cfg.libreoffice)
        base = word.compila(prep['modello'], prep['valori'], prep['camere'], prep['firma'], riserva=True)
        misura = imp.applica(base, misura=True)
        spazio = imp.spazio_mancante(misura, converti(misura), converti)
        docx = imp.applica(base, spazio=spazio)
    raw = pdf.da_word(docx, arc.cfg.libreoffice)
    valida_pdf(raw)
    return {'docx': docx, 'pdf': raw, 'pagine': imp.pagine(raw)}


def ritocco(s, arc, u, v, dati, raw):
    prep = prepara(s, arc, u, v, dati.get('versione'))
    ref = corrente(s, v, formato='docx')
    if ref is None or ref.impronta_dati != prep['impronta']:
        raise ErroreUtente('Rigenera prima il Word: i dati sono cambiati.')
    _, old = archivio.leggi(s, arc.cfg.cartella_documenti, ref.documento_id)
    try:
        if content_signature(old) != content_signature(raw):
            raise ValueError('Ritocco Word: puoi modificare l’impaginazione. Per cambiare i dati correggi la scheda e rigenera.')
    except ValueError as e:
        raise ErroreUtente(str(e)) from None
    return prep


SIGLE_GVR = {'funz': 'funz', 'integrita': 'integr', 'interna': 'interna'}   # senza punto: «funz..pdf» no


def attivita_gvr(s, v) -> str:
    """«funz», «integr», «interna» o le combinazioni, nell'ordine funzionamento, integrità, interna: «funz-integr»."""
    _a, r, _ = tecnico.dati_lavoro(s, v)
    parti = set((r.tipo_verifica_gvr or '').split('_'))
    return '-'.join(SIGLE_GVR[k] for k in ('funz', 'integrita', 'interna') if k in parti)


def nome_inail(s, v, tipo):
    a, _, _ = tecnico.dati_lavoro(s, v)
    if not v.data_pvp:
        raise ErroreUtente('Manca la prossima data della verifica.')
    matr = a.anno_matricola + a.cod_att_matricola + a.num_matricola + a.prov_immatr
    nome = ('verbale' if tipo == 'verbale' else 'scheda tecnica') + ' ' + matr + v.data_pvp.strftime('%d%m%Y')
    if a.gruppo == 'GVR':
        # Federico (12/10/2026, 13:32, AD-REV-007): per i GVR il nome indica anche l'attività, così funzionamento e
        # integrità con la stessa prossima data non finiscono sullo stesso file
        nome += ' ' + attivita_gvr(s, v)
    if getattr(v, 'revisione', 0):  # R134 (0.16): la revisione non sovrascrive il verbale emesso prima
        nome += f' rev. {v.revisione}'
    return nome + '.pdf'


ANTEPRIME = ('anteprima', 'word_ritoccato')


def _anteprima_confermata(s, u, v, dati):
    """Presa visione: il PDF confermato è l'anteprima corrente (stesso documento e stessa impronta)."""
    doc = corrente(s, v)
    if not doc or dati.get('documento_id') != doc.id:
        raise ErroreUtente('Conferma il PDF corrente dopo averlo controllato.')
    if dati.get('impronta_pdf') != s.get(Documento, doc.documento_id).impronta:
        raise ErroreUtente('Il PDF confermato non coincide con il PDF corrente.')
    return doc


def firma_per_emissione(s, arc, u, v, dati):
    """0.15, fuori dalla transazione di scrittura: la firma DM prende il posto dello spazio riservato nell'anteprima
    confermata; il PDF firmato deve avere le stesse pagine dell'anteprima. None per i PDF caricati già pronti."""
    from . import impaginazione as imp
    tecnico.esecutore(u, v)
    doc = _anteprima_confermata(s, u, v, dati)
    if doc.origine not in ANTEPRIME:
        return None
    prep = valori(s, v, arc)
    if doc.impronta_dati != prep['impronta']:
        raise ErroreUtente('I dati o la firma sono cambiati dopo l\'anteprima: rigenerala e controllala di nuovo.')
    if not prep['firma']:
        raise ErroreUtente('Il tecnico non ha la firma DM: caricala prima dell\'emissione.')
    word_doc = s.scalar(select(DocumentoDM).where(DocumentoDM.incarico_id == v.id, DocumentoDM.gruppo == doc.gruppo,
                                                  DocumentoDM.formato == 'docx'))
    if word_doc is None:
        raise ErroreUtente('Manca il Word dell\'anteprima: rigenerala.')
    _, docx = archivio.leggi(s, arc.cfg.cartella_documenti, word_doc.documento_id)
    _, anteprima = archivio.leggi(s, arc.cfg.cartella_documenti, doc.documento_id)
    firmato = imp.sostituisci_firma(docx, prep['firma'])
    raw = pdf.da_word(firmato, arc.cfg.libreoffice)
    valida_pdf(raw)
    prima, dopo = imp.pagine(anteprima), imp.pagine(raw)
    if prima != dopo:
        raise ErroreUtente(f'Con la firma il verbale passa da {prima} a {dopo} pagine: l\'impaginazione non è più quella '
                           'controllata. Rigenera l\'anteprima.')
    return {'doc_id': doc.id, 'impronta': prep['impronta'], 'docx': firmato, 'pdf': raw, 'pagine': dopo}


def effettua(s, arc, u, v, dati, firmati=None):
    tecnico.versione_obbligatoria(v, dati.get('versione'))
    tecnico.esecutore(u, v)
    tecnico.dpr.richiedi_indipendenza(v)  # R110
    a, r, _ = tecnico.attivabile(s, v)
    if v.stato != 'registrata':
        raise ErroreUtente('La verifica deve essere registrata.')
    tecnico._valida_registrazione(s, v, json.loads(v.bozza_json))
    doc = _anteprima_confermata(s, u, v, dati)
    prep = valori(s, v, arc)
    if doc.impronta_dati != prep['impronta']:
        raise ErroreUtente('I dati sono cambiati dopo la produzione del PDF: rigenera o ricarica il documento.')
    if doc.origine in ANTEPRIME:
        # 0.15: emissione con la firma DM al posto dello spazio riservato (preparata fuori transazione)
        if not firmati or firmati['doc_id'] != doc.id or firmati['impronta'] != prep['impronta']:
            raise ErroreUtente('Anteprima cambiata durante la firma: riprova.', 409)
        salva(s, arc, u, v, prep, {'pdf': firmati['pdf'], 'docx': firmati['docx'], 'pagine': firmati['pagine']}, 'verbale', 'firmato')
        doc = corrente(s, v)
    scheda = corrente(s, v, tipo='scheda_tecnica')
    if r.tipo_verifica_dm == 'V1' and scheda is None:
        raise ErroreUtente('Per la prima periodica carica anche la scheda tecnica PDF.')
    if scheda and scheda.impronta_dati != prep['impronta']:
        raise ErroreUtente('I dati sono cambiati dopo il caricamento della scheda tecnica: ricaricala.')
    prima = tecnico.stato(v)
    conservati = _dati_da_conservare(s, a, v, dati.get('dati_verbale', 'aggiorna'))
    for x in (doc, scheda):
        if x:
            _, raw = archivio.leggi(s, arc.cfg.cartella_documenti, x.documento_id)
            valida_pdf(raw)
            x.definitivo_il, x.nome_file = adesso(), nome_inail(s, v, x.tipo)
    v.stato, v.effettuata_il, v.effettuata_da = 'effettuata', adesso(), u.nome
    # Una nuova chiusura dopo il rientro R101 richiede un nuovo riesame.
    if v.riesame_esito == 'N':
        v.riesame_fatto, v.riesame_esito = False, ''
    s.flush()
    _conserva(s, u, a, v, conservati)
    from .scadenze import cnd, ricalcola
    avvisi = cnd(s, u.come_attore(), a, v)
    ricalcola(s, u.come_attore(), a)
    tecnico.scrivi(s, u, v, 'incarico_effettua', prima)
    avvisi = list(avvisi or [])
    avvisi += salva_in_cartella(s, arc, v, [x for x in (doc, scheda) if x])
    return avvisi


def _dati_da_conservare(s, a, v, scelta):
    """«Aggiorna / Conserva i dati del verbale» (documento 24 § 4.2): con «conserva» i dati dell'attrezzatura restano
    quelli di prima per i verbali successivi; il verbale emesso resta com'è."""
    if scelta not in ('aggiorna', 'conserva'):
        raise ErroreUtente('Dati del verbale: scegli «aggiorna» o «conserva».')
    if scelta == 'aggiorna':
        return {}
    from . import scheda_verbale
    return {g: x for g, x in scheda_verbale.corrente(s, a).items() if x}


def _conserva(s, u, a, v, conservati):
    from .modelli import SchedaVerbaleDM
    for g, x in conservati.items():
        s.add(SchedaVerbaleDM(asset_id=a.id, gruppo=g, campi_json=dumps(x['campi']), origine='conservata',
                              incarico_id=v.id, data_riferimento=v.data_rilascio or adesso().date(),
                              nota=f'Dati conservati all\'emissione del verbale {v.codice_verbale}', creato_da=u.nome))
    if conservati:
        s.flush()


# ---------------------------------------------------------------- 0.13.0: copia nella cartella dei verbali DM
_VIETATI = re.compile(r'[\\/:*?"<>|\x00-\x1f]+')


def _pulisci(x):
    return re.sub(r'\s+', ' ', _VIETATI.sub('-', str(x or ''))).strip(' .-')


def nome_potabile(s, v, tipo='verbale'):
    """Nome «potabile» come nei verbali di Federico (12/10/2026): «GVR_1234-2026 - ROSSI LAVORAZIONI S.r.l. - 2000_123456_VR
    - funzionamento», «SC_40-2026 - <cliente> - 15_654321_AL - Carrello semovente - n. int. 64»."""
    a, r, _ = tecnico.dati_lavoro(s, v)
    raw = json.loads(a.attributi_json)
    matr = (a.anno_matricola or '') + '_' + (a.cod_att_matricola or '') + '_' + (a.num_matricola or '') + '_' + (a.prov_immatr or '')
    matr = '_'.join(x for x in matr.split('_') if x) or (a.matr_informale or '').replace('/', '_')
    parti = [f'{a.gruppo}_{v.numero}-{v.anno}', a.sede.cliente.ragione_sociale, matr]
    descrizione = (raw.get('descr_attr') or '').strip().splitlines()[0][:60] if raw.get('descr_attr') else ''
    if a.gruppo != 'GVR' and descrizione:
        parti.append(descrizione)
    if raw.get('rif_interno'):
        parti.append(str(raw['rif_interno']))
    if a.gruppo == 'GVR':
        nomi = {'funz': 'funzionamento', 'integrita': 'integrità', 'interna': 'visita interna'}
        att = ' + '.join(nomi[k] for k in ('funz', 'integrita', 'interna') if k in tecnico.componenti(a.gruppo, r.tipo_verifica_gvr))
        parti.append(('PVP ' if r.tipo_verifica_dm == 'V1' else '') + att)
    if tipo != 'verbale':
        parti.append('scheda tecnica')
    return ' - '.join(_pulisci(x) for x in parti if _pulisci(x))[:200] + '.pdf'


def salva_in_cartella(s, arc, v, documenti_dm):
    """Copia del PDF definitivo (e della scheda tecnica) nella destinazione dei verbali DM, divisa in
    GVR | SC_SP / anno di emissione / sede operativa, due volte: nome INAIL e nome «potabile». Un errore di scrittura
    non annulla l'emissione: si segnala.
    rc8 (punto 5): le destinazioni si impostano in Gestione › Configurazione › Destinazioni dei documenti
    (moduli/documenti/destinazioni.py); `cartella_verbali_dm` di config.json resta il valore iniziale dei verbali DM.
    Le schede tecniche vanno nella loro destinazione se impostata, altrimenti con i verbali (come prima della rc8)."""
    from pathlib import Path
    from ..documenti import destinazioni
    radice_verbali = destinazioni.percorso(s, arc.cfg, 'verbali_dm')
    radice_schede = destinazioni.percorso(s, arc.cfg, 'schede_dm') or radice_verbali
    a, _r, _ = tecnico.dati_lavoro(s, v)
    anno = v.data_rilascio.year if v.data_rilascio else v.anno
    sotto = Path('GVR' if a.gruppo == 'GVR' else 'SC_SP') / str(anno) / (_pulisci(a.sede.denominazione) or _pulisci(a.sede.cliente.ragione_sociale))
    avvisi, cartelle = [], []
    for x in documenti_dm:
        radice = radice_schede if x.tipo == 'scheda_tecnica' else radice_verbali
        if not radice:
            continue
        cartella = Path(radice) / sotto
        try:
            cartella.mkdir(parents=True, exist_ok=True)
            _, raw = archivio.leggi(s, arc.cfg.cartella_documenti, x.documento_id)
            for nome in (x.nome_file, nome_potabile(s, v, x.tipo)):
                avviso = _scrivi_senza_sovrascrivere(cartella, _pulisci(nome.removesuffix('.pdf')), raw)
                if avviso:
                    avvisi.append(avviso)
        except OSError as e:
            cosa = 'della scheda tecnica DM' if x.tipo == 'scheda_tecnica' else 'del verbale DM'
            avvisi.append(f'Verbale emesso, ma la copia {cosa} nella sua cartella non è riuscita ({cartella}): {e}. Scaricalo dalla linguetta Documenti.')
            continue
        if cartella not in cartelle:
            cartelle.append(cartella)
    return [f'Copia salvata in {c}.' for c in cartelle] + avvisi


def _scrivi_senza_sovrascrivere(cartella, base: str, raw: bytes) -> str | None:
    """Nessun PDF diverso sostituisce in silenzio una copia già presente (AD-REV-007). Stesso contenuto: niente da
    fare. Contenuto diverso: la copia va in «<nome> (2).pdf» (o il primo numero libero) e si segnala il conflitto,
    perché il nome INAIL dipende solo da matricola e prossima data e due verbali possono averlo uguale."""
    dest = cartella / (base + '.pdf')
    if not dest.exists():
        dest.write_bytes(raw)
        return None
    if dest.read_bytes() == raw:
        return None
    n = 2
    while (alt := cartella / f'{base} ({n}).pdf').exists():
        if alt.read_bytes() == raw:
            return None
        n += 1
    alt.write_bytes(raw)
    return (f'Nella cartella c\'era già «{dest.name}» con un contenuto diverso (un altro verbale con lo stesso nome): '
            f'non è stato sostituito, la nuova copia è «{alt.name}». Controlla quale serve per la rendicontazione INAIL.')


def riesame(s, u, v, dati):
    if not u.puo('verifiche.riesame', 'DM'):
        raise PermessoNegato('Non puoi riesaminare i verbali.')
    if u.id == v.verificatore_id:
        raise PermessoNegato('Non puoi riesaminare il tuo verbale: serve un altro responsabile tecnico abilitato.')
    tecnico.versione_obbligatoria(v, dati.get('versione'))
    fatto = dati.get('fatto', True)
    esito, nota = dati.get('esito', ''), dati.get('nota', '')
    if type(fatto) is not bool or esito not in ('', 'C', 'N') or not isinstance(nota, str):
        raise ErroreUtente('Riesame: scegli Conforme o Non conforme.')
    if fatto and (not esito or esito == 'N' and not nota.strip()):
        raise ErroreUtente('Servono esito e, se non conforme, una nota di riesame.')
    prima = tecnico.stato(v)
    doc = corrente(s, v)
    s.add(RiesameDM(incarico_id=v.id, documento_id=doc.documento_id if doc else None,
        fatto=fatto, esito=esito, nota=nota.strip(), eseguito_da=u.nome))
    v.riesame_fatto, v.riesame_esito, v.riesame_nota = fatto, esito, nota.strip()
    v.riesame_il, v.riesame_da = adesso(), u.nome
    if fatto and esito == 'N' and v.stato == 'effettuata':
        v.stato = 'registrata'
        # Il lotto già generato resta immutabile; la nuova chiusura sarà riesportabile.
        v.esportata_inail = False
        s.flush()
        from .scadenze import annulla_cnd, ricalcola
        a, _, _ = tecnico.dati_lavoro(s, v)
        annulla_cnd(s, u.come_attore(), a, v)
        ricalcola(s, u.come_attore(), a)
    tecnico.scrivi(s, u, v, 'riesame', prima)
    s.flush()


def utente_firma(s, u, id):
    _puo_firma(u, id)
    target = s.get(Utente, id)
    if target is None:
        raise NonTrovato('Utente non trovato.')
    return target
