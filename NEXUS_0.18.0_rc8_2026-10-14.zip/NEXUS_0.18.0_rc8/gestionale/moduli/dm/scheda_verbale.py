"""Dati del verbale DM come attributi dell'attrezzatura (0.13.0, R123, documento 24 § 4.1).

Ogni gruppo ha un valore corrente con la sua provenienza:
- dal **verbale effettuato** più recente pertinente al gruppo (la regola di Garda `copia_dati_precedente_verifica`,
  ora esplicita e visibile);
- oppure da una **versione salvata** (`dm_schede_verbale`): correzione a mano con data di riferimento, o scelta
  all'emissione. Vale la più recente per data di riferimento; a parità vince la versione salvata.
La scheda non va mai all'indietro: un verbale più vecchio della versione corrente non la cambia.

Restano solo nel verbale (risposte di Federico, documento 24 § 7): tipo V1/V2, combinazione, regime, date, CND, esito
e motivi, prove eseguite in quella verifica, Pes e Tes (mostrati come valore del verbale precedente).
La breve descrizione del funzionamento e le camere sono già attributi dell'attrezzatura (scheda Caratt. GVR).
"""

from __future__ import annotations

import json
from datetime import date

from sqlalchemy import select

from ...core.errori import ErroreUtente
from ..beni.modelli import FamigliaGvr
from ..preventivi.modelli import RigaPreventivo
from .modelli import IncaricoDM, SchedaVerbaleDM
from .servizio import componenti

ACQUA = ('gvr_check_param_acqua', 'gvr_check_conduttore', 'gvr_cond', 'gvr_abil_n', 'gvr_ril_il')
ACCESSORI = ('gvr_acc_sicur', 'gvr_disp_contr', 'gvr_disp_regol', 'gvr_altri_acc', 'gvr_valv_interc')
SCSP = ('sc_sp_cond_gen', 'sc_sp_esame_org_princ', 'sc_sp_comp_prove_funz', 'sc_sp_conf_dati_tecn', 'sc_sp_osservazioni')

# gruppo: (titolo, campi, componente che lo aggiorna: None = qualsiasi verbale del gruppo di attrezzature)
GRUPPI_GVR = {
    'gvr_generale': ("Attrezzatura o insieme", ('gvr_ver_attr', 'gvr_ver_insieme'), None),
    'gvr_accessori': ("Accessori e dispositivi (funzionamento)", ACCESSORI, 'funz'),
    'gvr_acqua': ("Acqua di alimento e conduttore (funzionamento, famiglia a2)", ACQUA, 'funz'),
    'gvr_conservazione': ("Stato di conservazione delle tubazioni (integrità o visita interna)", ('gvr_tub_stato',), 'integrita|interna'),
    'gvr_osserv_funz': ("Osservazioni · funzionamento", ('gvr_osserv',), 'funz'),
    'gvr_osserv_integrita': ("Osservazioni · integrità", ('gvr_osserv',), 'integrita'),
    'gvr_osserv_interna': ("Osservazioni · visita interna", ('gvr_osserv',), 'interna'),
}
GRUPPI_SCSP = {'scsp': ("Testi del verbale SC/SP", SCSP, None)}


def gruppi(a) -> dict:
    return GRUPPI_GVR if a.gruppo == 'GVR' else GRUPPI_SCSP


def _famiglia(s, a) -> str:
    f = s.get(FamigliaGvr, a.tipo_attr_gvr_id) if a.tipo_attr_gvr_id else None
    return f.codice if f else ''


def _parti(s, v) -> set:
    r = s.get(RigaPreventivo, v.riga_id)
    return componenti('GVR' if r.tipo_verifica_gvr else 'SC', r.tipo_verifica_gvr)


def effettuati(s, asset_id: int) -> list:
    """Verbali effettuati, dal più recente (data di rilascio, poi id): come Garda."""
    return list(s.scalars(select(IncaricoDM).where(IncaricoDM.asset_id == asset_id, IncaricoDM.stato == 'effettuata')
                          .order_by(IncaricoDM.data_rilascio.desc(), IncaricoDM.id.desc())))


def _pertinente(s, v, componente: str | None) -> bool:
    return componente is None or bool(set(componente.split('|')) & _parti(s, v))


def _da_verbale(s, a, gruppo: str, verbali: list) -> dict | None:
    _titolo, campi, comp = gruppi(a)[gruppo]
    if gruppo == 'gvr_conservazione':
        # Garda: il più recente fra l'ultimo di integrità e l'ultimo di visita interna; a parità di data l'integrità
        ultimi = [next((v for v in verbali if _pertinente(s, v, k)), None) for k in ('integrita', 'interna')]
        ultimi = [v for v in ultimi if v]
        verbali = [max(ultimi, key=lambda v: v.data_rilascio)] if ultimi else []
    for v in verbali:
        if not _pertinente(s, v, comp):
            continue
        valori = json.loads(v.bozza_json or '{}').get('campi', {})
        if gruppo == 'gvr_generale' and valori.get('gvr_ver_attr') == valori.get('gvr_ver_insieme'):
            return None   # Garda: si ripropone solo una scelta esplicita
        return {'campi': {k: valori[k] for k in campi if k in valori}, 'origine': 'verbale', 'incarico_id': v.id,
                'codice': v.codice_verbale, 'data': v.data_rilascio.isoformat() if v.data_rilascio else None, 'nota': '',
                'da': ''}
    return None


def _salvata(x: SchedaVerbaleDM, s) -> dict:
    v = s.get(IncaricoDM, x.incarico_id) if x.incarico_id else None
    return {'campi': json.loads(x.campi_json), 'origine': x.origine, 'incarico_id': x.incarico_id,
            'codice': v.codice_verbale if v else '', 'data': x.data_riferimento.isoformat(), 'nota': x.nota,
            'da': x.creato_da, 'il': x.creato_il.isoformat(timespec='minutes') if x.creato_il else None, 'id': x.id}


def corrente(s, a) -> dict:
    """{gruppo: valore corrente con provenienza, o None}."""
    verbali = effettuati(s, a.id)
    out = {}
    for g in gruppi(a):
        dal_verbale = _da_verbale(s, a, g, verbali)
        ultima = s.scalar(select(SchedaVerbaleDM).where(SchedaVerbaleDM.asset_id == a.id, SchedaVerbaleDM.gruppo == g)
                          .order_by(SchedaVerbaleDM.data_riferimento.desc(), SchedaVerbaleDM.id.desc()).limit(1))
        salvata = _salvata(ultima, s) if ultima else None
        if salvata and (not dal_verbale or (dal_verbale['data'] or '') <= salvata['data']):
            out[g] = salvata
        else:
            out[g] = dal_verbale
    return out


def scheda_json(s, a) -> dict:
    cur = corrente(s, a)
    storico = [_salvata(x, s) | {'gruppo': x.gruppo} for x in s.scalars(
        select(SchedaVerbaleDM).where(SchedaVerbaleDM.asset_id == a.id).order_by(SchedaVerbaleDM.id.desc()))]
    fam = _famiglia(s, a)
    from .tecnico import CAMPI
    definizioni = {f['name']: {'etichetta': f['label'], 'tipo': f['type'], 'area': f.get('display') == 'textarea'} for f in CAMPI}
    return {'asset_id': a.id, 'gruppo_attrezzatura': a.gruppo, 'definizioni': definizioni, 'gruppi': [
        {'codice': g, 'titolo': t, 'campi': list(c), 'valore': cur[g],
         'pertinente': not (g == 'gvr_acqua' and fam != 'a2')}
        for g, (t, c, _comp) in gruppi(a).items()], 'storico': storico}


def correggi(s, attore, a, gruppo: str, dati: dict) -> None:
    """Correzione a mano di un gruppo, con data di riferimento (predefinita oggi) e nota."""
    if gruppo not in gruppi(a):
        raise ErroreUtente('Gruppo della scheda non valido per questa attrezzatura.')
    _t, campi, _c = gruppi(a)[gruppo]
    valori = dati.get('campi') or {}
    if not isinstance(valori, dict) or set(valori) - set(campi):
        raise ErroreUtente('Campi non validi per questo gruppo della scheda.')
    try:
        giorno = date.fromisoformat(dati['data_riferimento']) if dati.get('data_riferimento') else date.today()
    except ValueError:
        raise ErroreUtente('Data di riferimento non valida.') from None
    prima = (corrente(s, a).get(gruppo) or {}).get('campi', {})
    nuovi = {k: valori.get(k, prima.get(k, False if k.startswith(('gvr_check', 'gvr_ver_')) else '')) for k in campi}
    for k, x in nuovi.items():
        if not isinstance(x, (str, bool)) or isinstance(x, str) and len(x) > 8000:
            raise ErroreUtente('Valore non valido: ' + k)
    s.add(SchedaVerbaleDM(asset_id=a.id, gruppo=gruppo, campi_json=json.dumps(nuovi, ensure_ascii=False), origine='manuale',
                          data_riferimento=giorno, nota=str(dati.get('nota') or '')[:2000], creato_da=attore.nome))
    s.flush()
    from ..registro import servizio as registro
    registro.scrivi(s, utente=attore, azione='dm.scheda_verbale_correggi', oggetto_tipo='asset', oggetto_id=a.id,
                    descrizione=f'Corretti a mano i dati del verbale «{gruppi(a)[gruppo][0]}» dell\'attrezzatura {a.matr_informale or a.id}',
                    dettagli={'gruppo': gruppo, 'prima': prima, 'dopo': nuovi, 'data_riferimento': giorno.isoformat()})


def _chiave_osservazione(x: dict) -> tuple:
    """Verbale combinato senza funzionamento (integrità + interna): vale la più recente per data di riferimento. A
    parità di data vince la correzione a mano sul verbale (come in `corrente`); fra due correzioni la più recente (id
    della versione), fra due verbali quello con id maggiore (AD-REV-006)."""
    manuale = x['origine'] != 'verbale'
    return (x['data'] or '', manuale, (x.get('id') or 0) if manuale else (x['incarico_id'] or 0))


def riproponi(s, a, r, d) -> dict:
    """Bozza dalla scheda: solo i gruppi pertinenti alle componenti del nuovo verbale (stesso risultato della regola di
    Garda finché nessuno corregge a mano). `provenienza_precedenti` dice da dove viene ogni campo."""
    cur = corrente(s, a)
    provenienza = {}

    def copia(g):
        x = cur.get(g)
        if not x:
            return
        for k, val in x['campi'].items():
            if k in d['campi']:
                d['campi'][k] = val
                provenienza[k] = {'incarico_id': x['incarico_id'], 'codice': x['codice'], 'data_rilascio': x['data'],
                                  'origine': x['origine'], 'versione_id': x.get('id'), 'gruppo': g}

    if a.gruppo != 'GVR':
        copia('scsp')
    else:
        parti = componenti(a.gruppo, r.tipo_verifica_gvr)
        copia('gvr_generale')
        if 'funz' in parti:
            copia('gvr_accessori')
            if _famiglia(s, a) == 'a2':
                copia('gvr_acqua')
        if r.tipo_verifica_gvr != 'funz':
            copia('gvr_conservazione')
        osserv = [cur[f'gvr_osserv_{k}'] for k in ('funz', 'integrita', 'interna') if k in parti and cur.get(f'gvr_osserv_{k}')]
        if 'funz' in parti:
            # Federico (12/10/2026, 13:32): nel verbale combinato le osservazioni dell'ultimo verbale di funzionamento
            # (compresa una correzione a mano di quel gruppo)
            copia('gvr_osserv_funz')
        elif osserv:
            migliore = max(osserv, key=_chiave_osservazione)
            for g in ('gvr_osserv_funz', 'gvr_osserv_integrita', 'gvr_osserv_interna'):
                if cur.get(g) is migliore:
                    copia(g)
                    break
    d['provenienza_precedenti'] = provenienza
    return d


def pes_tes_precedenti(s, a) -> dict:
    """Pes e Tes del verbale di funzionamento precedente, per camera: si mostrano come confronto (non si copiano)."""
    for v in effettuati(s, a.id):
        if 'funz' not in _parti(s, v):
            continue
        out = {}
        for c in json.loads(v.bozza_json or '{}').get('camere', []):
            if c.get('gvr_pes') or c.get('gvr_tes'):
                out[c.get('chiave', '')] = {'gvr_pes': c.get('gvr_pes', ''), 'gvr_tes': c.get('gvr_tes', ''),
                                            'codice': v.codice_verbale, 'data': v.data_rilascio.isoformat() if v.data_rilascio else None}
        return out
    return {}
