"""I due modelli Garda originali, conservati byte per byte nel pacchetto.

Adattamento in memoria dei modificatori dei segnaposto; firma dall'archivio
comune VerbalizzAI. Non viene sostituito il contenuto tecnico del modello.
"""
import io
import json
import re
from copy import deepcopy
from datetime import date
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

from lxml import etree

from ...core import word
from ...core.errori import ErroreUtente
from ...terzi.verbalizzai import templates

ETICHETTE = json.loads((Path(__file__).parents[2] / 'dati/DM_etichette_stampa_Garda.json').read_text(encoding='utf-8'))['campi']


def data(val):
    return date.fromisoformat(val).strftime('%d/%m/%Y') if val else ''


def _dicitura_revisione(root, valori):
    """Aggiunge il riferimento R134 nel documento generato; i modelli approvati restano invariati."""
    testo = valori.get('v.revisione_dicitura')
    if not testo or testo in ''.join(t.text or '' for t in root.iter(word._w('t'))):
        return
    codice = valori.get('v.rp_codice', '')
    p = next((p for p in root.iter(word._w('p')) if codice and codice in
              ''.join(t.text or '' for t in p.iter(word._w('t')))), None)
    if p is None:
        raise ErroreUtente('Il modello DM non mostra il codice del verbale: manca il riferimento della revisione.')
    r = etree.SubElement(p, word._w('r'))
    stile = p.find('.//' + word._w('rPr'))
    if stile is not None:
        r.append(deepcopy(stile))
    etree.SubElement(r, word._w('br'))
    etree.SubElement(r, word._w('t')).text = testo


def compila(modello, valori, camere, firma, riserva=False):
    """Con `riserva` (anteprima, 0.15) al posto della firma va un'immagine trasparente con lo stesso ingombro, che
    all'emissione diventa la firma DM (impaginazione.sostituisci_firma) senza spostare righe né pagine."""
    formatted = {k: ('☒' if val else '☐') if type(val) is bool else val for k, val in valori.items()}
    formatted['u.firma'] = '__DM_FIRMA__' if firma else ''

    def modificatori(m):
        key, params = m.group(1), m.group(2)
        options = dict(x.strip().split('=', 1) for x in params.split(','))
        if set(options) - {'l', 'w', 'h'}:
            raise ErroreUtente('Modificatore del modello DM non supportato: ' + params)
        if options.get('l', '0') != '0':
            campo = ETICHETTE.get(key.removeprefix('v.'))
            if key not in formatted or not campo:
                raise ErroreUtente('Etichetta del modello DM non riconosciuta: ' + key)
            # gi_word_placeholder_value_fmt_get: casella + NBSP + etichetta;
            # per gli altri campi, etichetta + ": " + valore.
            named = key + '__etichetta'
            val = formatted[key]
            formatted[named] = (str(val) + '\u00a0' + campo['etichetta']
                if campo.get('boolean_style') == 'checkbox'
                else campo['etichetta'] + ': ' + ('' if val is None else str(val)))
            return '{{' + named + '}}'
        return '{{' + key + '}}'

    out = io.BytesIO()
    with word._apri(modello) as z, ZipFile(out, 'w', ZIP_DEFLATED) as dst:
        for info in z.infolist():
            raw = z.read(info.filename)
            if word.PARTI.match(info.filename):
                root = word._leggi_xml(raw)
                for p in root.iter(word._w('p')):
                    word._unisci_segnaposto(p)
                for t in root.iter(word._w('t')):
                    if t.text:
                        t.text = re.sub(r'\{\{([\w.]+)\(([^{}]*)\)\}\}', modificatori, t.text)
                raw = etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)
            dst.writestr(info, raw)
    docx, missing = word.compila(out.getvalue(), formatted, {'c': camere})
    if missing:
        raise ErroreUtente('Campi del modello DM senza corrispondenza: ' + ', '.join(missing))
    out = io.BytesIO()
    with word._apri(docx) as z, ZipFile(out, 'w', ZIP_DEFLATED) as dst:
        files = {n: z.read(n) for n in z.namelist()}
        for n, raw in list(files.items()):
            if not word.PARTI.match(n):
                continue
            root = word._leggi_xml(raw)
            if n == 'word/document.xml':
                _dicitura_revisione(root, formatted)
            for t in list(root.iter(word._w('t'))):
                if '__DM_FIRMA__' in (t.text or ''):
                    t.text = (t.text or '').replace('__DM_FIRMA__', '')
                    fmt, w, h = templates.image_info(firma)
                    ratio = min(7 * 360000 / w, 1.5 * 360000 / h)
                    ingombro = (int(w * ratio), int(h * ratio))
                    if riserva:
                        from .impaginazione import RID_RISERVATO, RISERVATO
                        drawing = templates.signature_run(RID_RISERVATO, w, h, RISERVATO, None, ingombro)
                    else:
                        drawing = templates.signature_run('rIdDMFirma', w, h, extent=ingombro)
                    from xml.etree import ElementTree
                    run = t.getparent()
                    run.addnext(etree.fromstring(ElementTree.tostring(drawing)))
                if '\n' in (t.text or ''):
                    chunks = t.text.replace('\r', '').split('\n')
                    t.text = chunks[0]
                    pos = t
                    for chunk in chunks[1:]:
                        br = etree.Element(word._w('br'))
                        pos.addnext(br)
                        nxt = etree.Element(word._w('t'))
                        nxt.text = chunk
                        nxt.set(word.XML_SPACE, 'preserve')
                        br.addnext(nxt)
                        pos = nxt
            files[n] = etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)
        if firma:
            fmt, w, h = templates.image_info(firma)
            ext = 'png' if fmt == 'png' else 'jpeg'
            target, rid, immagine = f'media/dm_firma.{ext}', 'rIdDMFirma', firma
            if riserva:
                from .impaginazione import RID_RISERVATO
                ratio = min(7 * 360000 / w, 1.5 * 360000 / h)
                target, rid, ext = 'media/dm_spazio_firma.png', RID_RISERVATO, 'png'
                immagine = templates.placeholder_png(int(w * ratio), int(h * ratio))
            files['word/' + target] = immagine
            rel = 'http://schemas.openxmlformats.org/package/2006/relationships'
            root = word._leggi_xml(files['word/_rels/document.xml.rels'])
            etree.SubElement(root, '{' + rel + '}Relationship', Id=rid, Target=target,
                Type='http://schemas.openxmlformats.org/officeDocument/2006/relationships/image')
            files['word/_rels/document.xml.rels'] = etree.tostring(root, xml_declaration=True, encoding='UTF-8')
            root = word._leggi_xml(files['[Content_Types].xml'])
            if not any(e.get('Extension') == ext for e in root):
                etree.SubElement(root, '{http://schemas.openxmlformats.org/package/2006/content-types}Default',
                    Extension=ext, ContentType='image/' + ext)
            files['[Content_Types].xml'] = etree.tostring(root, xml_declaration=True, encoding='UTF-8')
        for n, raw in files.items():
            dst.writestr(n, raw)
    return out.getvalue()
