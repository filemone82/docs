"""Incarichi DM e contenuti tecnici, da metadati e hook Garda.

La fotografia dell'offerta rimane separata dalla bozza e dai PDF definitivi.
"""
from __future__ import annotations

import json
from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

from sqlalchemy import select

from ...core.db import adesso
from ...core.date import iso_locale
from ...core.errori import ErroreUtente, NonTrovato, PermessoNegato
from ..anagrafica.servizio import _data, _modificato, controlla_versione
from ..beni import servizio as beni
from ..beni.modelli import FamigliaGvr
from ..preventivi.modelli import Preventivo, RigaPreventivo
from ..registro import servizio as registro
from ..verifiche import servizio as dpr
from .modelli import ContatoreDM, IncaricoDM, STATI_DM
from .servizio import TIPI, GVR, componenti

APERTE = ('assegnata', 'programmata', 'registrata')
CAMPI = json.loads((Path(__file__).parents[2] / 'dati/DM_campi_verifica_Garda.json').read_text(encoding='utf-8'))['campi']
CAT = {f['name']: f for f in CAMPI}
DATE = {'funz': 'funzionamento', 'integrita': 'integrita', 'interna': 'interna', 'scsp': 'scsp'}


def versione_obbligatoria(v, valore):
    if valore in (None, "") or isinstance(valore, bool):
        raise ErroreUtente('Ricarica la scheda: serve la versione corrente.')
    try:
        numero = int(valore)
    except (TypeError, ValueError):
        raise ErroreUtente('Versione non valida.') from None
    controlla_versione(v, numero)


def leggi(s, id):
    v = s.get(IncaricoDM, id)
    if v is None:
        raise NonTrovato('Incarico DM non trovato.')
    return v


def vedere(u, v):
    return dpr.puo_vedere(u, v, 'DM')


def esecutore(u, v):
    dpr._richiedi_esecutore(u, v, 'DM')
    if not v.verificatore_id:
        raise ErroreUtente('Assegna prima l’incarico a un tecnico.')
    if v.stato not in APERTE:
        raise ErroreUtente('L’incarico deve essere assegnato, programmato o registrato.')


def dati_lavoro(s, v):
    a = beni.leggi(s, v.asset_id)
    r = s.get(RigaPreventivo, v.riga_id)
    p = s.get(Preventivo, r.preventivo_id)
    if p.ambito != 'DM' or r.asset_id != a.id:
        raise ErroreUtente('Collegamento incarico/riga/attrezzatura non coerente.')
    return a, r, p


def attivabile(s, v):
    a, r, p = dati_lavoro(s, v)
    if a.dismesso or not a.sede.attiva or not a.sede.cliente.attivo:
        raise ErroreUtente('Attrezzatura, sede o cliente non attivi.')
    from ..preventivi.modelli import Riesame
    ultimo = s.scalar(select(Riesame).where(Riesame.preventivo_id == p.id).order_by(Riesame.id.desc()))
    if r.stato != 'accettata' or p.stato in ('annullato', 'sostituito') or ultimo is None or ultimo.esito != 'conforme':
        raise ErroreUtente('Servono riga accettata e ultimo riesame dell’offerta conforme.')
    if a.gruppo == 'GVR' and not beni.visita_interna(s, a) and 'interna' in componenti(a.gruppo, r.tipo_verifica_gvr):
        raise ErroreUtente('La visita interna è prevista solo per GV/INS GV: riesamina la prestazione rispetto alla scheda corrente.')
    return a, r, p


def famiglia(s, a):
    f = s.get(FamigliaGvr, a.tipo_attr_gvr_id) if a.tipo_attr_gvr_id else None
    return f.codice if f else ''


def iniziale(s, v):
    a, r, _ = dati_lavoro(s, v)
    raw = json.loads(a.attributi_json)
    d = {'campi': {}, 'camere': [], 'date': {}, 'esito': 'Positivo',
         'regime': 'A2' if r.tipo_verifica_dm == 'V2' else '', 'data_rilascio': None,
         'motivazione_sospensione': '', 'provenienza_precedenti': {}, 'cnd': {}}
    for f in CAMPI:
        if f['name'].startswith('gvr_') and a.gruppo != 'GVR' or f['name'].startswith('sc_sp_') and a.gruppo == 'GVR':
            continue
        d['campi'][f['name']] = False if f['type'] == 'boolean' else None if f['type'] == 'date' else ''
    if a.gruppo == 'GVR':
        d['campi']['gvr_ver_attr'] = not bool(raw.get('matr_insieme'))
        d['campi']['gvr_ver_insieme'] = bool(raw.get('matr_insieme'))
    from .precedenti import riproponi
    return aggiorna_da_asset(s, v, riproponi(s, a, r, d))


def aggiorna_da_asset(s, v, d):
    """Master → lavori aperti. Pes/Tes solo nella bozza e solo con funzionamento."""
    a, r, _ = dati_lavoro(s, v)
    if not v.bozza_salvata:
        from .precedenti import riproponi
        riproponi(s, a, r, d)
    foto = beni.scheda(s, a)
    d['asset_versione'] = a.versione
    d['scheda_corrente'] = foto
    d['tipo_attr'] = foto['attributi'].get('tipo_attr_verbale', '')
    if a.gruppo == 'GVR':
        funz = 'funz' in componenti(a.gruppo, r.tipo_verifica_gvr)
        vecchie = {x['chiave']: x for x in d.get('camere', [])}
        camere = []
        for c in foto['camere']:
            k = c['identificazione'].lower().strip() + '|' + c['num_fabbrica'].lower().strip()
            row = dict(c, chiave=k)
            old = vecchie.get(k, {})
            row['gvr_pes'] = old.get('gvr_pes', '') if funz else ''
            row['gvr_tes'] = old.get('gvr_tes', '') if funz else ''
            camere.append(row)
        d['camere'] = camere
        # 0.13.0 (R123): Pes e Tes restano nel verbale; quelli del funzionamento precedente si mostrano per confronto
        from .scheda_verbale import pes_tes_precedenti
        d['pes_tes_precedenti'] = pes_tes_precedenti(s, a) if funz else {}
        d['volume_totale_litri'] = foto['volume_totale_litri']
        d['campi']['gvr_breve_descr_funz'] = foto['attributi'].get('gvr_breve_descr_funz', '')
    pertinenti = componenti(a.gruppo, r.tipo_verifica_gvr)
    sc = {x['componente']: x for x in foto['scadenze']}
    for key, comp in DATE.items():
        if key not in pertinenti:
            d['date'][key] = sc.get(comp, {}).get('data_prossima')
    return d


def propaga(s, attore, asset_id):
    """Stessa transazione del salvataggio della scheda; anche le bozze già salvate."""
    for v in s.scalars(select(IncaricoDM).where(IncaricoDM.asset_id == asset_id, IncaricoDM.stato.in_(APERTE))):
        prima = json.loads(v.bozza_json)
        dopo = aggiorna_da_asset(s, v, json.loads(v.bozza_json) if v.bozza_json != '{}' else iniziale(s, v))
        if prima != dopo:
            v.bozza_json = json.dumps(dopo, ensure_ascii=False)
            _modificato(v, attore)
            registro.scrivi(s, utente=attore, azione='dm.incarico_aggiorna_da_scheda', oggetto_tipo='incarico_dm',
                            oggetto_id=v.id, descrizione='Aggiornata bozza DM dalla scheda corrente',
                            dettagli={'asset_id': asset_id, 'asset_versione': dopo['asset_versione']})


def scrivi(s, u, v, azione, prima):
    _modificato(v, u.come_attore())
    registro.scrivi(s, utente=u.come_attore(), azione='dm.' + azione, oggetto_tipo='incarico_dm', oggetto_id=v.id,
                    descrizione=f'Incarico DM {v.codice_verbale or v.id}: {azione}',
                    dettagli={'prima': prima, 'dopo': stato(v)})


def stato(v):
    return {'stato': v.stato, 'verificatore_id': v.verificatore_id, 'indipendenza': v.indipendenza,
            'data_programmata': str(v.data_programmata) if v.data_programmata else None,
            'codice_verbale': v.codice_verbale, 'bozza': json.loads(v.bozza_json),
            'motivo_sospensione': v.motivo_sospensione, 'motivo_annullamento': v.motivo_annullamento}


def assegna(s, u, v, dati):
    versione_obbligatoria(v, dati.get('versione'))
    if v.stato not in ('da_assegnare', *APERTE, 'sospesa'):
        raise ErroreUtente('Questo incarico non è riassegnabile.')
    attivabile(s, v)
    ids = {x['id'] for x in dpr.verificatori(s, 'DM')}
    chi = beni.intero(dati.get('verificatore_id'), 'Tecnico')
    if chi not in ids:
        raise ErroreUtente('Scegli un tecnico attivo abilitato a eseguire verifiche.')
    prima = stato(v)
    if v.verificatore_id != chi:
        v.indipendenza = True
    v.verificatore_id = chi
    v.assegnata_il, v.assegnata_da = adesso(), u.nome
    if v.stato == 'da_assegnare':
        v.stato = 'assegnata'
        v.bozza_json = json.dumps(iniziale(s, v), ensure_ascii=False)
    scrivi(s, u, v, 'incarico_assegna', prima)


def programma(s, u, v, dati):
    versione_obbligatoria(v, dati.get('versione'))
    esecutore(u, v)
    dpr.richiedi_indipendenza(v)  # R110
    attivabile(s, v)
    if v.stato not in ('assegnata', 'programmata'):
        raise ErroreUtente('La programmazione riguarda gli incarichi assegnati o programmati.')
    giorno = _data(dati, 'data_programmata', 'Data prevista')
    if not giorno:
        raise ErroreUtente('Indica la data prevista.')
    prima = stato(v)
    v.data_programmata, v.stato = giorno, 'programmata'
    scrivi(s, u, v, 'incarico_programma', prima)


def definizioni(s, a, r):
    out = []
    funz = 'funz' in componenti(a.gruppo, r.tipo_verifica_gvr)
    for f in CAMPI:
        k = f['name']
        if k.startswith('gvr_') and a.gruppo != 'GVR' or k.startswith('sc_sp_') and a.gruppo == 'GVR':
            continue
        cond = f.get('form_visible', '')
        if '$tipo_verifica_gvr!="funz"' in cond and r.tipo_verifica_gvr == 'funz':
            continue
        if '$tipo_verifica_gvr=="funz"' in cond and not funz:
            continue
        if "$tipo_attr_gvr== 'a2'" in cond and famiglia(s, a) != 'a2':
            continue
        out.append({'nome': k, 'etichetta': f['label'], 'tipo': f['type'], 'area': f.get('display') == 'textarea',
                    'richiesto': f.get('required', False), 'valori_suggeriti': f.get('values', []),
                    'conduttore': "$gvr_check_conduttore == 'T'" in cond})
    return out


def salva_bozza(s, u, v, dati):
    versione_obbligatoria(v, dati.get('versione'))
    esecutore(u, v)
    a, r, _ = attivabile(s, v)
    if set(dati) - {'versione', 'asset_versione', 'campi', 'camere', 'date', 'esito', 'regime', 'data_rilascio', 'motivazione_sospensione', 'tipo_attr', 'cnd', 'affiancamento_id'}:
        raise ErroreUtente('Campi della bozza non riconosciuti.')
    # La maschera può toccare la configurazione comune: serve anche la versione del bene.
    versione_obbligatoria(a, dati.get('asset_versione'))
    prima = stato(v)
    d = json.loads(v.bozza_json) if v.bozza_json != '{}' else iniziale(s, v)
    # Da questo salvataggio i contenuti sono del tecnico: non riproporli dal precedente.
    v.bozza_salvata = True
    fields = dati.get('campi', {})
    if not isinstance(fields, dict) or set(fields) - {f['nome'] for f in definizioni(s, a, r)}:
        raise ErroreUtente('Attributi tecnici non pertinenti alla prestazione DM.')
    for k, val in fields.items():
        f = CAT[k]
        if f['type'] == 'boolean':
            if type(val) is not bool:
                raise ErroreUtente(f"{f['label']}: scegli sì o no.")
        elif f['type'] == 'date':
            val = _data({k: val}, k, f['label'])
            val = val.isoformat() if val else None
        elif not isinstance(val, str):
            raise ErroreUtente(f"{f['label']}: occorre un testo.")
        d['campi'][k] = val
    if 'esito' in dati:
        if dati['esito'] not in ('Positivo', 'Negativo', 'Sospeso', 'A vuoto'):
            raise ErroreUtente('Esito non previsto da Garda.')
        d['esito'] = dati['esito']
    if 'regime' in dati:
        if dati['regime'] not in ('', 'A1', 'A2') or r.tipo_verifica_dm == 'V2' and dati['regime'] != 'A2':
            raise ErroreUtente('Regime: A1 o A2; per successive solo A2, come in Garda.')
        d['regime'] = dati['regime']
    if 'data_rilascio' in dati:
        data = _data(dati, 'data_rilascio', 'Data rilascio')
        d['data_rilascio'] = data.isoformat() if data else None
    if 'motivazione_sospensione' in dati:
        if not isinstance(dati['motivazione_sospensione'], str):
            raise ErroreUtente('La motivazione deve essere un testo.')
        d['motivazione_sospensione'] = dati['motivazione_sospensione']
    date_in = dati.get('date', {})
    if not isinstance(date_in, dict) or set(date_in) - set(DATE):
        raise ErroreUtente('Date non pertinenti alla prestazione.')
    pertinenti = componenti(a.gruppo, r.tipo_verifica_gvr)
    for k, val in date_in.items():
        if k not in pertinenti:
            raise ErroreUtente('Modifica solo le prossime date della prestazione preventivata.')
        val = _data({k: val}, k, 'Prossima ' + k)
        d['date'][k] = val.isoformat() if val else None
    if 'affiancamento_id' in dati:
        aid = beni.intero(dati['affiancamento_id'], 'Tecnico in affiancamento', True)
        if aid and aid not in {x['id'] for x in dpr.verificatori(s, 'DM')}:
            raise ErroreUtente('Scegli un tecnico in affiancamento attivo.')
        v.affiancamento_id = aid
    if 'cnd' in dati:
        sc = next((x for x in a.scadenze if x.componente == 'cnd'), None)
        con_cnd = sc and (sc.data_ultima or sc.data_prossima)
        c = dati['cnd']
        if not isinstance(c, dict) or set(c) - {'ultima', 'prossima', 'numero_report'}:
            raise ErroreUtente('Dati CND non validi.')
        if c and not (a.gruppo == 'GVR' and 'integrita' in pertinenti and con_cnd and d['date'].get('integrita')):
            raise ErroreUtente('CND della verifica disponibili solo per integrità di un bene con CND e prossima integrità.')
        d['cnd'] = {}
        for k in ('ultima', 'prossima'):
            val = _data(c, k, 'CND ' + k)
            d['cnd'][k] = val.isoformat() if val else None
        report = c.get('numero_report', '')
        if not isinstance(report, str) or len(report) > 100:
            raise ErroreUtente('Numero report CND: massimo 100 caratteri.')
        d['cnd']['numero_report'] = report.strip()
    if not d['date'].get('integrita'):
        d['cnd'] = {}
    if 'camere' in dati:
        if a.gruppo != 'GVR' or not isinstance(dati['camere'], list) or len(dati['camere']) > 500:
            raise ErroreUtente('Configurazione camere non valida.')
        ammissibili = {'id', 'identificazione', 'num_fabbrica', 'unita', 'valore', 'dati_tecnici', 'gvr_pes', 'gvr_tes'}
        ids = set()
        pes = {}
        for c in dati['camere']:
            if not isinstance(c, dict) or set(c) - ammissibili:
                raise ErroreUtente('Campi della camera non riconosciuti.')
            if any(not isinstance(c.get(k, ''), str) for k in ('identificazione','num_fabbrica','gvr_pes','gvr_tes')):
                raise ErroreUtente('Identificazione, numero fabbrica e Pes/Tes devono essere testi.')
            cid = beni.intero(c.get('id'), 'Camera', True)
            if cid and cid in ids:
                raise ErroreUtente('Camera ripetuta nella configurazione.')
            if cid:
                ids.add(cid)
            request = {k: val for k, val in c.items() if k not in ('id', 'gvr_pes', 'gvr_tes')}
            request['versione'] = a.versione
            beni.salva_camera(s, u.come_attore(), a.id, request, cid)
            for k in ('gvr_pes', 'gvr_tes'):
                if not isinstance(c.get(k, ''), str):
                    raise ErroreUtente('Pes/Tes sono testi tecnici.')
            key = c['identificazione'].lower().strip() + '|' + c.get('num_fabbrica', '').lower().strip()
            pes[key] = {k: c.get(k, '') for k in ('gvr_pes', 'gvr_tes')}
        # La configurazione inviata è completa: elimina solo le camere preesistenti omesse.
        originali = {c['id'] for c in prima['bozza'].get('camere', [])}
        for cid in originali - ids:
            beni.elimina_camera(s, u.come_attore(), a.id, cid, {'versione': a.versione})
        d['camere'] = [dict(chiave=k, **op) for k, op in pes.items()]
    if 'tipo_attr' in dati and a.gruppo == 'GVR':  # C11: il tipo attrezzatura del verbale è solo dei GVR
        beni.salva(s, u.come_attore(), {'versione': a.versione, 'dati_dm': {'tipo_attr_verbale': dati['tipo_attr']}}, a.id)
    if a.gruppo == 'GVR' and 'gvr_breve_descr_funz' in fields:
        beni.salva(s, u.come_attore(), {'versione': a.versione,
                   'dati_dm': {'gvr_breve_descr_funz': fields['gvr_breve_descr_funz']}}, a.id)
    d = aggiorna_da_asset(s, v, d)
    v.bozza_json = json.dumps(d, ensure_ascii=False)
    v.bozza_salvata = True
    # Una registrata rimane registrata solo se i suoi dati sono ancora validi.
    if v.stato == 'registrata':
        _valida_registrazione(s, v, d)
        _registra_numero(s, v, d)
    scrivi(s, u, v, 'incarico_bozza', prima)


def _valida_registrazione(s, v, d):
    a, r, _ = dati_lavoro(s, v)
    if not d.get('esito') or not d.get('data_rilascio') or not d.get('regime'):
        raise ErroreUtente('Per registrare servono esito, data rilascio e regime.')
    if d['esito'] == 'Sospeso' and not d.get('motivazione_sospensione', '').strip():
        raise ErroreUtente('Indica la motivazione dell’esito sospeso.')
    if d['esito'] == 'Negativo' and not d['campi'].get('esito_motivi', '').strip():
        raise ErroreUtente('Indica i motivi dell’esito negativo.')
    if a.gruppo == 'GVR' and d['campi'].get('gvr_ver_attr') == d['campi'].get('gvr_ver_insieme'):
        raise ErroreUtente('Scegli attrezzatura oppure insieme, uno solo.')
    if any(not d['date'].get(k) for k in componenti(a.gruppo, r.tipo_verifica_gvr)):
        raise ErroreUtente('Indica le prossime date delle componenti preventivate.')
    for flag, obbligatori in (('gvr_es_spess_check', ('gvr_es_spess_eseg','gvr_es_spess_data','gvr_es_spess_esito')),
                              ('gvr_altre_prove_check', ('gvr_altre_prove',))):
        if d['campi'].get(flag) and any(not d['campi'].get(k) for k in obbligatori):
            raise ErroreUtente('Completa i dati della prova selezionata: ' + CAT[flag]['label'])


def _registra_numero(s, v, d):
    a, r, _ = dati_lavoro(s, v)
    giorno = date.fromisoformat(d['data_rilascio'])
    gruppo = 'GVR' if a.gruppo == 'GVR' else 'SC-SP'
    revisione = bool(getattr(v, 'revisione', 0))
    if revisione and not (v.numero and v.anno and v.codice_verbale):
        raise ErroreUtente('La revisione deve conservare il numero del verbale originario: controlla lo storico.')
    # R134: anno del numero e data di emissione della revisione possono essere diversi.
    if not v.numero or (v.anno != giorno.year and not revisione):
        cont = s.get(ContatoreDM, (gruppo, giorno.year))
        if cont is None:
            cont = ContatoreDM(gruppo=gruppo, anno=giorno.year, ultimo=0)
            s.add(cont)
        cont.ultimo += 1
        v.gruppo_contatore, v.anno, v.numero = gruppo, giorno.year, cont.ultimo
        v.codice_verbale = f'V/{a.gruppo}/{v.numero:04d}/{v.anno % 100:02d}'
    v.data_rilascio = giorno
    v.data_pvp = min(date.fromisoformat(d['date'][k]) for k in componenti(a.gruppo, r.tipo_verifica_gvr))
    v.contributo = int((Decimal(r.tariffa_standard) * Decimal('0.15' if d['regime'] == 'A1' else '0.05')).quantize(Decimal('1'), rounding=ROUND_HALF_UP))


def registra(s, u, v, dati):
    versione_obbligatoria(v, dati.get('versione'))
    esecutore(u, v)
    dpr.richiedi_indipendenza(v)  # R110
    attivabile(s, v)
    d = json.loads(v.bozza_json)
    _valida_registrazione(s, v, d)
    prima = stato(v)
    _registra_numero(s, v, d)
    v.stato = 'registrata'
    scrivi(s, u, v, 'incarico_registra', prima)


ANNI = {'annuale': 1, 'biennale': 2, 'triennale': 3, 'quadriennale': 4, 'quinquennale': 5, 'decennale': 10}
CHIAVE_PERIODICITA = {'funz': 'tipo_ver_gvr_1', 'integrita': 'tipo_ver_gvr_2', 'interna': 'tipo_ver_gvr_3'}


def prossima_calcolata(s, a, componente, giorno):
    """Registrazione multipla (doc. 28 p. 13): data vuota = calcolata dalla periodicità del catalogo di Garda
    (es. «Verifica funzionamento: biennale» → +2 anni − 1 giorno). Se il catalogo non la dice, None."""
    from ..beni.modelli import TipoAttrezzatura
    tipo = s.get(TipoAttrezzatura, a.tipo_attr_id) if a.tipo_attr_id else None
    if tipo is None or componente not in CHIAVE_PERIODICITA:
        return None
    testo = (getattr(tipo, CHIAVE_PERIODICITA[componente]) or '').lower()
    anni = next((n for k, n in ANNI.items() if k in testo), None)
    if not anni:
        return None
    try:
        fine = giorno.replace(year=giorno.year + anni)
    except ValueError:  # 29 febbraio
        fine = giorno.replace(year=giorno.year + anni, day=28)
    from datetime import timedelta
    return fine - timedelta(days=1)


def registra_in_blocco(s, u, richieste, dati):
    """Documento 28, punto 13 (deciso, Federico 12/10/2026 11:13 e 11:25): «Registra le selezionate…», solo AD_DM.
    Una data di rilascio e le prossime date uguali per tutti (GVR: funzionamento, integrità, visita interna, ciascuna
    applicata solo agli incarichi con quella componente; vuota = calcolata dalla periodicità); esito e regime restano
    quelli della scheda se già scritti. Numero del verbale alla registrazione, in ordine di data e poi di incarico.
    Tutto o niente: il primo incarico che non passa i controlli ferma tutto e il messaggio dice quale e perché."""
    giorno = _data(dati, 'data_rilascio', 'Data di rilascio')
    if not giorno:
        raise ErroreUtente('Indica la data di rilascio del verbale.')
    esito = dati.get('esito') or 'Positivo'
    if esito not in ('Positivo', 'Negativo', 'Sospeso'):
        raise ErroreUtente('Esito non valido.')
    date_comuni = dati.get('date') or {}
    if not isinstance(date_comuni, dict):
        raise ErroreUtente('Date non valide.')
    incarichi = []
    for rd in richieste:
        v = leggi(s, beni.intero(rd.get('id'), 'Incarico'))
        versione_obbligatoria(v, rd.get('versione'))
        incarichi.append(v)
    registrati = []
    for v in sorted(incarichi, key=lambda x: x.id):
        a, r, _ = dati_lavoro(s, v)
        nome = f"{a.matr_informale or a.id} (incarico n. {v.id})"
        try:
            if v.stato not in ('assegnata', 'programmata'):
                raise ErroreUtente('si registrano insieme solo incarichi assegnati o programmati, non ancora registrati.')
            d = json.loads(v.bozza_json)
            d['data_rilascio'] = giorno.isoformat()
            d['esito'] = d.get('esito') or esito
            d['regime'] = d.get('regime') or ('A2' if r.tipo_verifica_dm == 'V2' else dati.get('regime') or '')
            d.setdefault('date', {})
            for k in componenti(a.gruppo, r.tipo_verifica_gvr):
                scelta = date_comuni.get(k)
                if scelta:
                    d['date'][k] = date.fromisoformat(str(scelta)).isoformat()
                elif not d['date'].get(k):
                    calcolata = prossima_calcolata(s, a, k, giorno)
                    if calcolata is None:
                        raise ErroreUtente(f'manca la prossima data ({k}) e il catalogo non indica la periodicità: scrivila.')
                    d['date'][k] = calcolata.isoformat()
            v.bozza_json = json.dumps(d, ensure_ascii=False)
            registra(s, u, v, {'versione': v.versione})
        except (ErroreUtente, PermessoNegato) as e:
            messaggio = getattr(e, 'messaggio', str(e))
            raise type(e)(f'{nome}: {messaggio} Nessun incarico è stato registrato.') from None
        registrati.append({'id': v.id, 'codice_verbale': v.codice_verbale})
    return registrati


def azione(s, u, v, nome, dati):
    versione_obbligatoria(v, dati.get('versione'))
    prima = stato(v)
    if nome == 'annulla':
        # R135 (0.16, Federico 12/10/2026: «annullamento, lo può fare verificatore o rt. la numerazione non cambia»):
        # l'RT con il permesso, oppure il verificatore a cui è affidato; il numero del verbale resta occupato.
        if not (u.puo('verifiche.annulla', 'DM') or (v.verificatore_id == u.id and u.puo('verifiche.esegui', 'DM'))):
            raise PermessoNegato('Annulla l’incarico l’RT oppure il verificatore a cui è affidato.')
        if v.stato == 'annullata':
            raise ErroreUtente('L’incarico è già annullato.')
        motivo = dati.get('motivo', '')
        if not isinstance(motivo, str) or not motivo.strip():
            raise ErroreUtente('Indica il motivo dell’annullamento.')
        era_effettuata = v.stato == 'effettuata'
        v.stato, v.motivo_annullamento = 'annullata', motivo.strip()
        s.flush()
        from .scadenze import annulla_cnd, ricalcola
        if era_effettuata:
            annulla_cnd(s, u.come_attore(), dati_lavoro(s, v)[0], v)
        ricalcola(s, u.come_attore(), dati_lavoro(s, v)[0])
    elif nome == 'revisione':
        # R134 (0.16, Federico 12/10/2026: «revisione ok come proposto e già praticato per dpr»): il verbale emesso si
        # riapre per una revisione con lo stesso numero (rev. N+1) e un motivo; il verbale emesso resta in archivio e,
        # alla nuova emissione, risulta sostituito. Le date tornano quelle di prima finché la revisione non è emessa.
        if not (u.puo('verifiche.revisione', 'DM') or (v.verificatore_id == u.id and u.puo('verifiche.esegui', 'DM'))):
            raise PermessoNegato('La revisione la apre l’RT oppure il verificatore a cui è affidato.')
        if v.stato != 'effettuata':
            raise ErroreUtente('Si rivede solo un verbale emesso (incarico «effettuato»).')
        motivo = dati.get('motivo', '')
        if not isinstance(motivo, str) or not motivo.strip():
            raise ErroreUtente('Indica il motivo della revisione.')
        storico = json.loads(v.revisioni_json or '[]')
        storico.append({'revisione': v.revisione + 1, 'motivo': motivo.strip()[:1000], 'il': adesso().isoformat(timespec='seconds'),
                        'da': u.nome, 'emesso_il': v.data_rilascio.isoformat() if v.data_rilascio else None,
                        'precedente': v.revisione, 'codice_precedente': v.codice_verbale})
        v.revisioni_json = json.dumps(storico, ensure_ascii=False)
        v.revisione += 1
        v.stato = 'registrata'
        v.riesame_fatto, v.riesame_esito, v.riesame_nota = False, '', ''
        v.esportata_inail = False  # il lotto già generato resta immutabile; la revisione sarà riesportabile
        s.flush()
        from .scadenze import annulla_cnd, ricalcola
        annulla_cnd(s, u.come_attore(), dati_lavoro(s, v)[0], v)
        ricalcola(s, u.come_attore(), dati_lavoro(s, v)[0])
    elif nome == 'riprendi':
        dpr._richiedi_esecutore(u, v, 'DM')
        if v.stato != 'sospesa':
            raise ErroreUtente('L’incarico non è sospeso.')
        attivabile(s, v)
        v.stato = v.stato_prima_sospensione
        v.motivo_sospensione = ''
        v.bozza_json = json.dumps(aggiorna_da_asset(s, v, json.loads(v.bozza_json)), ensure_ascii=False)
    else:
        if nome == 'indipendenza':  # R119: solo il verificatore assegnato; con «No» torna al RT
            dpr.dichiara_indipendenza(u, v, dati.get('indipendenza'), dm=True)
            scrivi(s, u, v, 'incarico_' + nome, prima)
            return v
        esecutore(u, v)
        if nome == 'sospendi':
            motivo = dati.get('motivo', '')
            if not isinstance(motivo, str) or not motivo.strip():
                raise ErroreUtente('Indica il motivo della sospensione.')
            v.stato_prima_sospensione = v.stato
            v.stato, v.motivo_sospensione = 'sospesa', motivo.strip()
        else:
            raise NonTrovato('Azione non disponibile in questo incremento DM.')
    scrivi(s, u, v, 'incarico_' + nome, prima)


def scheda(s, v):
    from ..utenti.modelli import Utente
    a, r, p = dati_lavoro(s, v)
    u = s.get(Utente, v.verificatore_id) if v.verificatore_id else None
    from .documenti import elenco, profilo_json
    from .modelli import RiesameDM, InvioDM
    from ..finanza.servizio import fattura_della_riga
    return {'id': v.id, 'asset_id': a.id, 'riga_id': r.id, 'preventivo_id': p.id, 'preventivo': p.codice,
            'fattura': fattura_della_riga(s, r.id),  # R139 (0.16)
            'revisione': v.revisione, 'revisioni': json.loads(v.revisioni_json or '[]'),  # R134 (0.16)
            'cliente': a.sede.cliente.ragione_sociale, 'cliente_id': a.sede.cliente_id,
            'sede': a.sede.denominazione, 'sede_id': a.sede_id, 'gruppo': a.gruppo,
            'attrezzatura': a.denominazione or a.matr_informale, 'matricola': a.matr_informale,
            'stato': v.stato, 'stato_testo': STATI_DM[v.stato], 'versione': v.versione,
            'verificatore_id': v.verificatore_id, 'verificatore': u.nome if u else '',
            'profilo_tecnico': profilo_json(u) if u else None, 'affiancamento_id': v.affiancamento_id,
            'data_programmata': v.data_programmata.isoformat() if v.data_programmata else None,
            'tipo': r.tipo_verifica_dm, 'tipo_testo': TIPI[r.tipo_verifica_dm],
            'combinazione': r.tipo_verifica_gvr, 'combinazione_testo': GVR.get(r.tipo_verifica_gvr, ''),
            'componenti': sorted(componenti(a.gruppo, r.tipo_verifica_gvr)),
            'indipendenza': v.indipendenza, 'indipendenza_esclusa': v.indipendenza_esclusa, 'codice_verbale': v.codice_verbale,
            'esportata_inail': v.esportata_inail,
            'data_pvp': v.data_pvp.isoformat() if v.data_pvp else None, 'contributo': v.contributo,
            'bozza': json.loads(v.bozza_json), 'fotografia_preventivo': json.loads(v.fotografia_json),
            'campi': definizioni(s, a, r), 'asset_versione': a.versione,
            'motivo_sospensione': v.motivo_sospensione, 'motivo_annullamento': v.motivo_annullamento,
            'documenti': elenco(s, v), 'effettuata_il': iso_locale(v.effettuata_il),
            'riesame': {'fatto': v.riesame_fatto, 'esito': v.riesame_esito, 'nota': v.riesame_nota,
                        'data': iso_locale(v.riesame_il), 'utente': v.riesame_da},
            'riesami': [{'id': x.id, 'fatto': x.fatto, 'esito': x.esito, 'nota': x.nota,
                        'documento_id': x.documento_id, 'utente': x.eseguito_da, 'data': iso_locale(x.eseguito_il)}
                       for x in s.scalars(select(RiesameDM).where(RiesameDM.incarico_id == v.id).order_by(RiesameDM.id.desc()))],
            'invii': [{'destinatari': x.destinatari, 'copia': x.copia, 'oggetto': x.oggetto, 'esito': x.esito,
                       'utente': x.inviato_da, 'data': iso_locale(x.inviato_il)}
                      for x in s.scalars(select(InvioDM).where(InvioDM.incarico_id == v.id).order_by(InvioDM.id.desc()))],
            'modificato_il': iso_locale(v.modificato_il), 'modificato_da': v.modificato_da}
