"""Ultima effettuata per componente; nessuna periodicità dedotta o inventata."""
import json
from datetime import date

from ..anagrafica.servizio import _modificato
from ..beni.modelli import ScadenzaTecnica
from ..beni import servizio as beni
from .precedenti import effettuate, pertinente

COMP = {'funz': 'funzionamento', 'integrita': 'integrita', 'interna': 'interna', 'scsp': 'scsp'}


def ricalcola(s, attore, a):
    tutti = effettuate(s, a.id)
    for k in (('funz', 'integrita', 'interna') if a.gruppo == 'GVR' else ('scsp',)):
        ultimo = next((v for v in tutti if pertinente(s, v, k)), None)
        x = next((x for x in a.scadenze if x.componente == COMP[k]), None)
        if ultimo:
            if x is None:
                x = ScadenzaTecnica(componente=COMP[k], fonte='dichiarata', numero_report='', nota='',
                    versione=1, creato_da=attore.nome, modificato_da=attore.nome)
                a.scadenze.append(x)
            if x.dati_iniziali_json in (None, '{}'):
                x.dati_iniziali_json = json.dumps({'data_ultima': str(x.data_ultima) if x.data_ultima else None,
                    'data_prossima': str(x.data_prossima) if x.data_prossima else None, 'fonte': x.fonte})
            x.data_ultima = ultimo.data_rilascio
            x.data_prossima = date.fromisoformat(json.loads(ultimo.bozza_json)['date'][k])
            x.incarico_dm_id, x.fonte = ultimo.id, 'dm'
            _modificato(x, attore)
        elif x and x.fonte == 'dm':
            origin = json.loads(x.dati_iniziali_json)
            x.data_ultima = date.fromisoformat(origin['data_ultima']) if origin.get('data_ultima') else None
            x.data_prossima = date.fromisoformat(origin['data_prossima']) if origin.get('data_prossima') else None
            x.incarico_dm_id, x.fonte = None, origin.get('fonte', 'dichiarata')
            _modificato(x, attore)
    if tutti:
        raw = json.loads(a.attributi_json)
        raw['tipo_prox_verifica'] = 'V2'
        a.attributi_json = json.dumps(raw, ensure_ascii=False)
    _modificato(a, attore)
    s.flush()
    from .tecnico import propaga
    propaga(s, attore, a.id)


def cnd(s, attore, a, v):
    d = json.loads(v.bozza_json)
    if a.gruppo != 'GVR' or not d.get('cnd', {}).get('prossima'):
        return []
    dati = d['cnd']
    x = next((x for x in a.scadenze if x.componente == 'cnd'), None)
    prossima = date.fromisoformat(dati['prossima'])
    if x and x.data_prossima and x.data_prossima > prossima:
        return ['CND: la prossima data del bene è successiva; non è stata sovrascritta (regola Garda).']
    # Valori prima di questa chiusura: servono a ripristinarli se il riesame riapre il lavoro (R108/R109).
    precedenti = {'data_ultima': str(x.data_ultima) if x and x.data_ultima else None,
                  'data_prossima': str(x.data_prossima) if x and x.data_prossima else None,
                  'numero_report': x.numero_report if x else '', 'nuova': x is None}
    beni.salva_scadenza(s, attore, a.id, {'versione': a.versione, 'componente': 'cnd',
        'data_ultima': dati.get('ultima'), 'data_prossima': dati['prossima'],
        'numero_report': dati.get('numero_report') or (x.numero_report if x else '')})
    x = next(x for x in a.scadenze if x.componente == 'cnd')
    x.incarico_dm_id = v.id
    scritto = {'data_ultima': str(x.data_ultima) if x.data_ultima else None,
               'data_prossima': str(x.data_prossima) if x.data_prossima else None, 'numero_report': x.numero_report}
    x.dati_iniziali_json = json.dumps({'cnd_prima_di_incarico': v.id, **precedenti, 'scritto': scritto})
    return []


def annulla_cnd(s, attore, a, v):
    """Riapertura (riesame negativo) o annullamento di un lavoro chiuso: le date CND che quel lavoro aveva scritto
    tornano ai valori precedenti, così la nuova chiusura le confronta con il dato giusto e non con quello da correggere.
    Se dopo la chiusura qualcuno ha già corretto a mano la CND (altro lavoro collegato), non si tocca nulla."""
    if a.gruppo != 'GVR':
        return
    x = next((x for x in a.scadenze if x.componente == 'cnd'), None)
    if x is None or x.incarico_dm_id != v.id:
        return
    prima = json.loads(x.dati_iniziali_json or '{}')
    if prima.get('cnd_prima_di_incarico') != v.id:
        return
    attuale = {'data_ultima': str(x.data_ultima) if x.data_ultima else None,
               'data_prossima': str(x.data_prossima) if x.data_prossima else None, 'numero_report': x.numero_report}
    if attuale != prima.get('scritto'):
        return  # corretta a mano dopo la chiusura: prevale la correzione
    x.data_ultima = date.fromisoformat(prima['data_ultima']) if prima.get('data_ultima') else None
    x.data_prossima = date.fromisoformat(prima['data_prossima']) if prima.get('data_prossima') else None
    x.numero_report = prima.get('numero_report') or ''
    x.incarico_dm_id, x.dati_iniziali_json = None, '{}'
    x.versione += 1
    _modificato(x, attore)
    _modificato(a, attore)
    s.flush()
