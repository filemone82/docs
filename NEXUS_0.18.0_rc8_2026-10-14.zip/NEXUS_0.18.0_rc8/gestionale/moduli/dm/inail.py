"""Rendicontazione manuale A.S.A. conforme al tracciato estratto da Garda.

Il lotto conserva Excel, tre ZIP e fotografie; esportato non significa ricevuto dal portale.
"""
import hashlib
import io
import json
from decimal import Decimal
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

from openpyxl import Workbook
from openpyxl.styles import PatternFill
from sqlalchemy import select

from ...core.errori import ErroreUtente
from ..anagrafica.modelli import Cliente
from ..beni.modelli import TipoAttrezzatura, FamigliaGvr, IdSpecifica
from ..documenti import servizio as archivio
from ..finanza import documenti as fatture_pdf
from ..finanza.modelli import Fattura, RigaFattura
from ..utenti.modelli import Utente
from . import tecnico, documenti
from .modelli import EsportazioneINAIL, RigaEsportazioneINAIL

CAMPI = json.loads(Path(__file__).with_name('inail_campi_garda.json').read_text(encoding='utf-8'))['fields']


def dumps(x):
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def fattura(s, v):
    fs = list(s.scalars(select(Fattura).join(RigaFattura).where(RigaFattura.riga_preventivo_id == v.riga_id,
        RigaFattura.prestazione_intera.is_(True), Fattura.ambito == 'DM', Fattura.tipo == 'TD01',
        Fattura.stato.not_in(('bozza', 'scartata')))).unique())
    if len(fs) != 1:
        raise ErroreUtente('Serve una sola fattura DM emessa collegata all’intera prestazione.')
    return fs[0]


def periodicita(tipo, combinazione):
    singles = {'funz': tipo.tipo_ver_gvr_1, 'integrita': tipo.tipo_ver_gvr_2, 'interna': tipo.tipo_ver_gvr_3}
    if combinazione in singles:
        val = singles[combinazione] or ''
        return '' if val == 'N.A.' else val
    mixed = {'funz_integrita_interna': 'Ver. funzionamento biennale + Ver. integrità + Visita interna',
             'funz_interna': 'Ver. funzionamento biennale + Visita interna',
             'integrita_interna': 'Visita interna + Ver. integrità'}
    if combinazione in mixed:
        return mixed[combinazione]
    if combinazione == 'funz_integrita':
        for k in ('biennale', 'triennale', 'quadriennale', 'quinquennale'):
            if k in (singles['funz'] or ''):
                return 'Ver. funzionamento ' + k + ' + Ver. integrità'
    return ''


def riga(s, arc, v):
    if v.stato != 'effettuata':
        raise ErroreUtente('Verifica non effettuata.')
    if v.esportata_inail:
        raise ErroreUtente('Verifica già esportata: reimposta il flag per riesportarla.')
    a, rp, p = tecnico.dati_lavoro(s, v)
    c, se = s.get(Cliente, p.cliente_id), a.sede
    raw = json.loads(a.attributi_json)
    bozza = json.loads(v.bozza_json)
    tipo = s.get(TipoAttrezzatura, a.tipo_attr_id)
    fam = s.get(FamigliaGvr, a.tipo_attr_gvr_id) if a.tipo_attr_gvr_id else None
    spec = s.get(IdSpecifica, a.id_spec_id) if a.id_spec_id else None
    u = s.get(Utente, v.verificatore_id)
    prof = documenti.profilo_json(u)
    f = fattura(s, v)
    fdoc = fatture_pdf.corrente(s, f)
    if fdoc is None:
        raise ErroreUtente('Manca il PDF archiviato della fattura corrente.')
    vd = documenti.corrente(s, v)
    if not vd or not vd.definitivo_il:
        raise ErroreUtente('Manca il verbale PDF definitivo.')
    # INAIL legge classificazione/anagrafica correnti come Garda, il verbale conserva la sua fotografia.
    d = {x['field']: '' for x in CAMPI}
    d.update(regime_verifica=bozza.get('regime', '').lstrip('A'), anno_matricola=a.anno_matricola,
        cod_att_matricola=a.cod_att_matricola, num_matricola=a.num_matricola, prov_immatr=a.prov_immatr,
        esito_verifica=bozza.get('esito', ''), tipo_verifica=rp.tipo_verifica_dm.lstrip('V'),
        motivazione_sospensione=v.motivo_sospensione if bozza.get('esito') == 'Sospeso' else '',
        data_rilascio_verbale=v.data_rilascio.strftime('%d/%m/%Y') if v.data_rilascio else '',
        data_pvp=v.data_pvp.strftime('%d/%m/%Y') if v.data_pvp else '',
        dl_rag_sociale=c.ragione_sociale, dl_indirizzo=c.indirizzo, dl_comune=c.comune, dl_cap=c.cap,
        dl_prov=c.provincia, dl_reg=c.regione, dl_cod_fisc=c.codice_fiscale or c.partita_iva,
        dl_part_iva=c.partita_iva or c.codice_fiscale, gruppo_attr=a.gruppo,
        tipo_attr_inail=tipo.codice if tipo else '', tipo_attr_gvr_inail=fam.codice if fam else '',
        tipo_verifica_GVR=periodicita(tipo, rp.tipo_verifica_gvr) if a.gruppo == 'GVR' and tipo else '',
        sogg_messa_servizio_gvr=('si' if a.soggetto_messa_servizio else 'no')
            if a.gruppo == 'GVR' and fam and fam.codice not in ('a4', 'a5') else '',
        id_spec_inail=spec.codice if spec else '',
        n_panieri_idroestr=raw.get('n_panieri_idroestr', '') if a.gruppo == 'SC' and tipo and tipo.codice.lower() in ('d1','d2','d3') else '',
        modello_attr=a.modello, num_fabbrica=a.num_fabbrica, marcatura_ce='si' if raw.get('marcatura_ce') else 'no',
        sv_nome_tecn=prof.get('nome', ''), sv_cognome_tecn=prof.get('cognome', ''), sv_CF_tecn=prof.get('codice_fiscale', ''),
        tariffa_app=str(Decimal(rp.tariffa_applicata)/100), tariffa_regolare=str(Decimal(rp.tariffa_standard)/100),
        contibuto_sogg_tit=str(Decimal(v.contributo)/100), attr_indirizzo=se.indirizzo, attr_comune=se.comune,
        attr_cap=se.cap, attr_provincia=se.provincia, attr_regione=se.regione,
        rag_soc_costr=a.costruttore, cf_costr=raw.get('cf_costr', ''), sv_cod_fiscale='11113100017',
        matr_insieme=raw.get('matr_insieme', '') if a.gruppo == 'GVR' else '',
        id_pacco_bombola=raw.get('id_pacco_bombola', '') if a.gruppo == 'GVR' else '',
        riferimento_Interno_Sa=v.codice_verbale + ' - ID ' + str(v.id))
    if v.affiancamento_id:
        d['sv_CF_tecn_aff'] = documenti.profilo_json(s.get(Utente, v.affiancamento_id)).get('codice_fiscale', '')
    files = []
    name = documenti.nome_inail(s, v, 'verbale')
    d['verbale'] = name[:-4]
    files.append(('verbali', name, vd.documento_id))
    d['fattura'] = name.replace('verbale ', 'fattura ')[:-4]
    files.append(('fatture', d['fattura'] + '.pdf', fdoc.documento_id))
    sd = documenti.corrente(s, v, 'scheda_tecnica')
    if rp.tipo_verifica_dm == 'V1':
        if not sd or not sd.definitivo_il:
            raise ErroreUtente('Manca la scheda tecnica PDF definitiva per la prima periodica.')
        d['scheda_tecnica'] = documenti.nome_inail(s, v, 'scheda_tecnica')[:-4]
        files.append(('schede_tecniche', d['scheda_tecnica'] + '.pdf', sd.documento_id))
    missing, large = [], []
    for col in CAMPI:
        k = col['field']
        d[k] = '' if d.get(k) is None else d.get(k, '')
        req = col['required'] is True
        req |= k == 'scheda_tecnica' and d['tipo_verifica'] == '1'
        req |= k == 'motivazione_sospensione' and d['esito_verifica'] == 'Sospeso'
        req |= a.gruppo == 'GVR' and k in ('tipo_attr_gvr_inail', 'tipo_verifica_GVR', 'sogg_messa_servizio_gvr')
        if k == 'sogg_messa_servizio_gvr' and d['tipo_attr_gvr_inail'] in ('a4', 'a5'):
            req = False
        req |= k == 'n_panieri_idroestr' and a.gruppo == 'SC' and d['tipo_attr_inail'].lower() in ('d1','d2','d3')
        if req and str(d[k]).strip() == '':
            missing.append(col['label'])
        if col['max'] and len(str(d[k])) > col['max']:
            large.append(col['label'] + ' (max ' + str(col['max']) + ')')
    if missing or large:
        raise ErroreUtente('INAIL: ' + '; '.join(filter(None, [
            'campi obbligatori: ' + ', '.join(missing) if missing else '',
            'campi troppo lunghi: ' + ', '.join(large) if large else ''])))
    for _, _, did in files:
        _, blob = archivio.leggi(s, arc.cfg.cartella_documenti, did)
        documenti.valida_pdf(blob)
    return {'incarico_id': v.id, 'versione': v.versione, 'fattura_id': f.id,
            'fattura_documento_id': fdoc.documento_id, 'dati': d, 'files': files}


def anteprima(s, arc, ids):
    if not isinstance(ids, list) or not ids or len(ids) > 1000 or len(ids) != len(set(ids)):
        raise ErroreUtente('Seleziona da 1 a 1000 verifiche distinte.')
    result, errors = [], []
    for id in ids:
        v = tecnico.leggi(s, id)
        try:
            result.append(riga(s, arc, v))
        except ErroreUtente as e:
            errors.append({'id': id, 'codice': v.codice_verbale, 'errore': e.messaggio})
    return {'righe': result, 'errori': errors}


def zip_bytes(files):
    out = io.BytesIO()
    with ZipFile(out, 'w', ZIP_DEFLATED) as z:
        for nome, raw in sorted(files.items()):
            z.writestr(nome, raw)
    return out.getvalue()


def crea(s, arc, u, dati):
    prepared = anteprima(s, arc, dati.get('incarichi'))
    if prepared['errori'] and not dati.get('solo_validi', False):
        raise ErroreUtente('Export bloccato: correggi le righe in errore o scegli esplicitamente solo quelle valide.')
    rows = prepared['righe']
    if not rows:
        raise ErroreUtente('Nessuna verifica esportabile.')
    wb = Workbook()
    ws = wb.active
    ws.title = 'INAIL'
    ws.append(['Dato obbligatorio' if x['required'] is True else 'Dato condizionale' if x['required'] == 'cond' else 'Dato opzionale' for x in CAMPI])
    ws.append([x['label'] for x in CAMPI])
    for cell, col in zip(ws[1], CAMPI, strict=True):
        cell.fill = PatternFill('solid', fgColor='FF0000' if col['required'] is True else 'FFFF00' if col['required'] == 'cond' else '92D050')
    archives = {k: {} for k in ('verbali','schede_tecniche','fatture')}
    invoice_names = {}
    manifest = {'tracciato': 'Garda 62 colonne', 'ricevuta_portale': False, 'righe': [], 'errori': prepared['errori'], 'allegati': []}
    for r in rows:
        for group, name, did in r['files']:
            if group == 'fatture':
                name = invoice_names.setdefault(r['fattura_id'], name)
                r['dati']['fattura'] = name[:-4]
            doc, raw = archivio.leggi(s, arc.cfg.cartella_documenti, did)
            if name in archives[group] and archives[group][name] != raw:
                raise ErroreUtente('Collisione di nomi INAIL con documenti diversi: ' + name)
            if name not in archives[group]:
                manifest['allegati'].append({'gruppo': group, 'nome': name, 'documento_id': did, 'sha256': doc.impronta})
            archives[group][name] = raw
        ws.append([float(Decimal(str(r['dati'][x['field']]))) if x['type'] in ('DECIMAL','INT') and r['dati'][x['field']] != '' else str(r['dati'][x['field']]) for x in CAMPI])
        for cell, col in zip(ws[ws.max_row], CAMPI, strict=True):
            if col['type'] not in ('DECIMAL','INT'):
                cell.data_type = 's'  # zeri iniziali e nessuna formula da testo inserito dall'utente
            elif col['type'] == 'DECIMAL':
                cell.number_format = '0.00'
        manifest['righe'].append({'id': r['incarico_id'], 'versione': r['versione'], 'fattura_id': r['fattura_id'], 'dati': r['dati']})
    b = io.BytesIO()
    wb.save(b)
    files = {'INAIL.xlsx': b.getvalue(), 'manifest.json': dumps(manifest).encode()}
    files.update({k + '.zip': zip_bytes(v) for k, v in archives.items()})
    raw = zip_bytes(files)
    doc = archivio.salva(s, arc.cfg.cartella_documenti, raw, 'INAIL.zip', 'application/zip', u.id)
    x = EsportazioneINAIL(documento_id=doc.id, manifest_json=dumps(manifest), creato_da=u.nome)
    s.add(x)
    s.flush()
    for r in rows:
        v = tecnico.leggi(s, r['incarico_id'])
        v.esportata_inail = True
        tecnico.scrivi(s, u, v, 'export_inail', {'esportazione_id': x.id})
        s.add(RigaEsportazioneINAIL(esportazione_id=x.id, incarico_id=v.id, dati_json=dumps(r['dati'])))
    s.flush()
    return {'id': x.id, 'esportate': len(rows), 'errori': prepared['errori'], 'sha256': hashlib.sha256(raw).hexdigest(),
            'url': f'/api/dm/inail/lotti/{x.id}/file'}
