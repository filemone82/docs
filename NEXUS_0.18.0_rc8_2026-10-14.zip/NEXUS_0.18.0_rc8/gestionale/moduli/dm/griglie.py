"""Griglia degli incarichi DM (0.12.9, Federico 12/10/2026): come Righe dei preventivi e Verifiche DPR — selezione
multipla con «seleziona tutte», filtri per colonna, Excel; ognuno vede solo i propri incarichi se non ha
«verifiche.vedere_tutte»."""

from __future__ import annotations
from ...core.sql_portabile import json_testo

from sqlalchemy import String, and_, case, cast, exists, false, func, select, true
from sqlalchemy.orm import aliased

from ...core.griglia import Colonna, Griglia, registra
from ..anagrafica.griglie import _con_dati_cliente, colonne_cliente, colonne_sede, etichetta
from ..anagrafica.modelli import Cliente, Sede
from ..beni.modelli import Asset
from ..preventivi.modelli import Preventivo, RigaPreventivo
from ..utenti.modelli import Utente
from .modelli import STATI_DM, IncaricoDM
from .servizio import GVR, TIPI

Tecnico = aliased(Utente, name="tecnico_dm")
RigaDM = aliased(RigaPreventivo, name="riga_dm")
PreventivoDM = aliased(Preventivo, name="preventivo_dm")
PREVENTIVO = case((PreventivoDM.revisione > 0, PreventivoDM.codice + " rev. " + cast(PreventivoDM.revisione, String)), else_=PreventivoDM.codice)
RIESAME = case((IncaricoDM.riesame_esito == "C", "Conforme"), (IncaricoDM.riesame_esito == "N", "Non conforme"), else_="")


from ..beni.griglie import DESCRIZIONE, SEDE_OPERATIVA, attributo  # noqa: E402
from ..finanza.modelli import Fattura, RigaFattura  # noqa: E402
from .modelli import RigaEsportazioneINAIL  # noqa: E402

REGIME = case({"A1": "Affidamento INAIL", "A2": "Affidamento datore di lavoro"},
              value=json_testo(IncaricoDM.bozza_json, "regime"), else_="")
FATTURA = (select(Fattura.codice).join(RigaFattura, RigaFattura.fattura_id == Fattura.id)
           .where(RigaFattura.riga_preventivo_id == IncaricoDM.riga_id, Fattura.tipo != "TD04", Fattura.stato != "scartata",
                  Fattura.codice != "").order_by(Fattura.id.desc()).limit(1).correlate(IncaricoDM).scalar_subquery())
ESPORTATA = case((exists().where(RigaEsportazioneINAIL.incarico_id == IncaricoDM.id), "Sì"), else_="No")


def _da_fatturare():  # noqa: ANN202
    from ..finanza.da_fatturare import riga_da_fatturare_di
    return case((and_(IncaricoDM.stato == "effettuata", riga_da_fatturare_di(IncaricoDM.riga_id)), "Sì"), else_="No")


def _da():  # noqa: ANN202
    return _con_dati_cliente(
        IncaricoDM.__table__.join(Asset.__table__, IncaricoDM.asset_id == Asset.id)
        .join(Sede.__table__, Asset.sede_id == Sede.id)
        .join(Cliente.__table__, Sede.cliente_id == Cliente.id)
        .join(RigaDM, IncaricoDM.riga_id == RigaDM.id)
        .join(PreventivoDM, RigaDM.preventivo_id == PreventivoDM.id)
        .outerjoin(Tecnico, IncaricoDM.verificatore_id == Tecnico.id))


def _solo_propri(u):  # noqa: ANN001, ANN202
    if u.puo("verifiche.vedere_tutte", "DM"):
        return true()
    if u.puo("verifiche.vedere_proprie", "DM"):
        return IncaricoDM.verificatore_id == u.id
    return false()


COLONNE = [
        Colonna("id", "N. incarico", "numero", IncaricoDM.id, larghezza=90),
        Colonna("versione", "Versione", "numero", IncaricoDM.versione, visibile=False, larghezza=70),
        Colonna("stato", "Stato", "elenco", etichetta(IncaricoDM.stato, STATI_DM), larghezza=130, opzioni=tuple(STATI_DM.values())),
        Colonna("codice_verbale", "Verbale", "testo", IncaricoDM.codice_verbale, larghezza=120),
        Colonna("gruppo", "Gruppo", "elenco", Asset.gruppo, larghezza=80, opzioni=("SC", "SP", "GVR")),
        Colonna("matricola", "Attrezzatura", "testo", Asset.matr_informale, larghezza=160),
        Colonna("asset_id", "N. attrezzatura", "numero", Asset.id, visibile=False, larghezza=90),
        Colonna("tipo", "Verifica", "elenco", case(TIPI, value=RigaDM.tipo_verifica_dm, else_=RigaDM.tipo_verifica_dm), larghezza=190,
                opzioni=tuple(TIPI.values())),
        Colonna("combinazione", "Attività GVR", "elenco", case(GVR, value=RigaDM.tipo_verifica_gvr, else_=RigaDM.tipo_verifica_gvr), larghezza=190,
                opzioni=tuple(GVR.values())),
        Colonna("verificatore", "Tecnico", "testo", Tecnico.nome, larghezza=150),
        Colonna("verificatore_id", "Tecnico (n.)", "numero", IncaricoDM.verificatore_id, visibile=False, larghezza=80),
        Colonna("data_programmata", "Data prevista", "data", IncaricoDM.data_programmata, larghezza=110),
        Colonna("data_rilascio", "Data del verbale", "data", IncaricoDM.data_rilascio, visibile=False, larghezza=110),
        Colonna("data_pvp", "Prossima verifica", "data", IncaricoDM.data_pvp, visibile=False, larghezza=120),
        Colonna("riesame", "Riesame", "elenco", RIESAME, larghezza=110, opzioni=("Conforme", "Non conforme")),
        Colonna("da_riesaminare", "Da riesaminare", "elenco",
                case((and_(IncaricoDM.stato == "effettuata", IncaricoDM.riesame_fatto.is_(False)), "Sì"), else_="No"),
                visibile=False, larghezza=110, opzioni=("Sì", "No")),
        Colonna("da_fatturare", "Da fatturare", "elenco", _da_fatturare(), larghezza=100, opzioni=("Sì", "No"),
                descrizione="Effettuato, riesame conforme, non ancora fatturato (N6)"),
        Colonna("preventivo", "Preventivo", "testo", PREVENTIVO, larghezza=110),
        # 0.12.10 (doc. 30, §§ 7–8): maschere di Federico
        Colonna("sede_operativa", "Sede operativa", "testo", SEDE_OPERATIVA, visibile=False, larghezza=240),
        Colonna("descrizione", "Descrizione", "testo", DESCRIZIONE, visibile=False, larghezza=200),
        Colonna("num_fabbrica", "N. fabbrica", "testo", Asset.num_fabbrica, visibile=False, larghezza=110),
        Colonna("reparto", "Reparto", "testo", attributo("reparto"), visibile=False, larghezza=150),
        Colonna("rif_interno", "Rif. interno", "testo", attributo("rif_interno"), visibile=False, larghezza=120),
        Colonna("costruttore", "Rag. soc. costruttore", "testo", Asset.costruttore, visibile=False, larghezza=170),
        Colonna("anno_costruzione", "Anno costr.", "numero", Asset.anno_costruzione, visibile=False, larghezza=90),
        Colonna("regime", "Regime verifica", "elenco", REGIME, visibile=False, larghezza=170,
                opzioni=("Affidamento INAIL", "Affidamento datore di lavoro")),
        Colonna("fattura", "Fattura", "testo", FATTURA, visibile=False, larghezza=120,
                descrizione="Fattura valida che contiene la riga del preventivo"),
        Colonna("esporta_inail", "Esporta INAIL", "elenco", ESPORTATA, visibile=False, larghezza=100, opzioni=("Sì", "No"),
                descrizione="Sì se l'incarico è già in un'esportazione INAIL"),
        Colonna("preventivo_id", "Preventivo (n. interno)", "numero", PreventivoDM.id, visibile=False, larghezza=80),
        Colonna("riga_id", "Riga del preventivo (n.)", "numero", IncaricoDM.riga_id, visibile=False, larghezza=80),
        *colonne_sede("sede_", "Sede", visibili=("denominazione",)),
        *colonne_cliente("cliente_", "Cliente", visibili=("ragione_sociale",)),
    ]

GVR_VISIBILI = ["codice_verbale", "data_rilascio", "data_pvp", "sede_operativa", "verificatore", "stato", "gruppo", "descrizione", "matricola",
                "num_fabbrica", "reparto", "rif_interno", "tipo", "combinazione", "costruttore", "anno_costruzione", "regime", "preventivo",
                "fattura", "esporta_inail"]
SCSP_VISIBILI = [c for c in GVR_VISIBILI if c not in ("combinazione", "costruttore", "anno_costruzione", "regime")]

for _codice, _titolo, _gruppi, _vis in (("incarichi_dm", "Verifiche AD_DM", None, None),
                                        ("incarichi_gvr", "Verifiche GVR", ("GVR",), GVR_VISIBILI),
                                        ("incarichi_scsp", "Verifiche SC/SP", ("SC", "SP"), SCSP_VISIBILI)):
    registra(Griglia(
        codice=_codice, titolo=_titolo, permesso="verifiche.vedere_proprie", da=_da,
        condizione=(lambda g: (lambda u: and_(_solo_propri(u), Asset.gruppo.in_(g)) if g else _solo_propri(u)))(_gruppi),
        ordine_predefinito=[("id", "desc")],
        colonne=COLONNE,
        viste_predefinite={"": {"colonne": _vis}} if _vis else {},
    ))
