from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, Integer, String, Text, UniqueConstraint, text
from sqlalchemy.orm import Mapped, mapped_column

from ...core.db import Base, adesso
from ...core.modelli_comuni import Centesimi, Tracciato


class TariffaDM(Base):
    __tablename__ = "dm_tariffe"
    __table_args__ = (
        CheckConstraint("gruppo IN ('GVR','SCSP')", name="gruppo"),
        CheckConstraint("importo > 0", name="importo"),
        CheckConstraint("(gruppo='GVR' AND id_spec_id IS NOT NULL AND compatibilita_id IS NULL) OR "
                        "(gruppo='SCSP' AND compatibilita_id IS NOT NULL AND id_spec_id IS NULL)", name="chiave"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    gruppo: Mapped[str] = mapped_column(String(8))
    id_spec_id: Mapped[int | None] = mapped_column(ForeignKey("cls_id_specifiche.id", ondelete="RESTRICT"))
    compatibilita_id: Mapped[int | None] = mapped_column(ForeignKey("cls_tipi_attr_id_specifiche.id", ondelete="RESTRICT"))
    tipo: Mapped[str] = mapped_column(String(2))
    importo: Mapped[int] = mapped_column(Centesimi)
    origine_json: Mapped[str] = mapped_column(Text)


STATI_DM = {
    "da_assegnare": "Da assegnare", "assegnata": "Assegnata", "programmata": "Programmata",
    "registrata": "Registrata", "effettuata": "Effettuata", "sospesa": "Sospesa", "annullata": "Annullata",
}


class IncaricoDM(Base, Tracciato):
    """Una riga commerciale, un lavoro tecnico; riesame DM indipendente dallo stato."""
    __tablename__ = "dm_incarichi"
    __table_args__ = (
        Index("uq_dm_incarichi_riga_attiva", "riga_id", unique=True, sqlite_where=text("stato != 'annullata'"),
              postgresql_where=text("stato != 'annullata'")),
        UniqueConstraint("gruppo_contatore", "anno", "numero", name="uq_dm_incarichi_numero"),
        CheckConstraint("stato IN ('da_assegnare','assegnata','programmata','registrata','effettuata','sospesa','annullata')", name="stato"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    riga_id: Mapped[int] = mapped_column(ForeignKey("preventivi_righe.id", ondelete="RESTRICT"), index=True)
    asset_id: Mapped[int] = mapped_column(ForeignKey("asset.id", ondelete="RESTRICT"), index=True)
    stato: Mapped[str] = mapped_column(String(20), default="da_assegnare")
    # Fotografia commerciale originaria: NON modificata dalla scheda tecnica.
    fotografia_json: Mapped[str] = mapped_column(Text)
    verificatore_id: Mapped[int | None] = mapped_column(ForeignKey("utenti.id", ondelete="RESTRICT"), index=True)
    assegnata_il: Mapped[datetime | None] = mapped_column(DateTime)
    assegnata_da: Mapped[str] = mapped_column(String(120), default="", server_default="")
    data_programmata: Mapped[date | None] = mapped_column(Date)
    indipendenza: Mapped[bool] = mapped_column(Boolean, default=True, server_default="1")
    indipendenza_esclusa: Mapped[str] = mapped_column(Text, default="", server_default="")  # R119
    bozza_json: Mapped[str] = mapped_column(Text, default="{}", server_default="{}")
    bozza_salvata: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")
    gruppo_contatore: Mapped[str | None] = mapped_column(String(8))
    anno: Mapped[int | None] = mapped_column(Integer)
    numero: Mapped[int | None] = mapped_column(Integer)
    codice_verbale: Mapped[str] = mapped_column(String(30), default="", server_default="")
    data_rilascio: Mapped[date | None] = mapped_column(Date)
    data_pvp: Mapped[date | None] = mapped_column(Date)
    contributo: Mapped[int] = mapped_column(Centesimi, default=0, server_default="0")
    stato_prima_sospensione: Mapped[str] = mapped_column(String(20), default="", server_default="")
    motivo_sospensione: Mapped[str] = mapped_column(Text, default="", server_default="")
    motivo_annullamento: Mapped[str] = mapped_column(Text, default="", server_default="")
    affiancamento_id: Mapped[int | None] = mapped_column(ForeignKey("utenti.id", ondelete="RESTRICT"))
    effettuata_il: Mapped[datetime | None] = mapped_column(DateTime)
    effettuata_da: Mapped[str] = mapped_column(String(120), default="", server_default="")
    riesame_fatto: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")
    riesame_esito: Mapped[str] = mapped_column(String(1), default="", server_default="")
    riesame_nota: Mapped[str] = mapped_column(Text, default="", server_default="")
    riesame_il: Mapped[datetime | None] = mapped_column(DateTime)
    riesame_da: Mapped[str] = mapped_column(String(120), default="", server_default="")
    esportata_inail: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0", index=True)
    # R134 (0.16): revisione di un verbale emesso, come nel DPR: stesso numero, rev. N, motivo; storico delle revisioni
    revisione: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    revisioni_json: Mapped[str] = mapped_column(Text, default="[]", server_default="[]")


class ContatoreDM(Base):
    """GVR distinto da SC-SP. Conserva i numeri anche dopo annullamento/cambio anno."""
    __tablename__ = "dm_contatori"
    __table_args__ = (CheckConstraint("gruppo IN ('GVR','SC-SP')", name="gruppo"),)
    gruppo: Mapped[str] = mapped_column(String(8), primary_key=True)
    anno: Mapped[int] = mapped_column(Integer, primary_key=True)
    ultimo: Mapped[int] = mapped_column(Integer)


class DocumentoDM(Base):
    __tablename__ = "dm_documenti"
    __table_args__ = (
        CheckConstraint("tipo IN ('verbale','scheda_tecnica')", name="tipo"),
        CheckConstraint("formato IN ('docx','pdf')", name="formato"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    incarico_id: Mapped[int] = mapped_column(ForeignKey("dm_incarichi.id", ondelete="RESTRICT"), index=True)
    documento_id: Mapped[int] = mapped_column(ForeignKey("documenti.id", ondelete="RESTRICT"))
    tipo: Mapped[str] = mapped_column(String(20))
    formato: Mapped[str] = mapped_column(String(4))
    gruppo: Mapped[str] = mapped_column(String(36))
    nome_file: Mapped[str] = mapped_column(String(255))
    attuale: Mapped[bool] = mapped_column(Boolean, default=True)
    impronta_dati: Mapped[str] = mapped_column(String(64))
    fotografia_json: Mapped[str] = mapped_column(Text)
    origine: Mapped[str] = mapped_column(String(30))
    creato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    creato_da: Mapped[str] = mapped_column(String(120))
    definitivo_il: Mapped[datetime | None] = mapped_column(DateTime)


class RiesameDM(Base):
    __tablename__ = "dm_riesami"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    incarico_id: Mapped[int] = mapped_column(ForeignKey("dm_incarichi.id", ondelete="RESTRICT"), index=True)
    documento_id: Mapped[int | None] = mapped_column(ForeignKey("documenti.id", ondelete="RESTRICT"))
    fatto: Mapped[bool] = mapped_column(Boolean)
    esito: Mapped[str] = mapped_column(String(1))
    nota: Mapped[str] = mapped_column(Text)
    eseguito_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    eseguito_da: Mapped[str] = mapped_column(String(120))


class InvioDM(Base):
    __tablename__ = "dm_invii"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    incarico_id: Mapped[int] = mapped_column(ForeignKey("dm_incarichi.id", ondelete="RESTRICT"), index=True)
    destinatari: Mapped[str] = mapped_column(Text)
    copia: Mapped[str] = mapped_column(Text)
    oggetto: Mapped[str] = mapped_column(String(300))
    testo: Mapped[str] = mapped_column(Text)
    allegati_json: Mapped[str] = mapped_column(Text)
    esito: Mapped[str] = mapped_column(String(300))
    inviato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    inviato_da: Mapped[str] = mapped_column(String(120))


class EsportazioneINAIL(Base):
    __tablename__ = 'dm_esportazioni_inail'
    id: Mapped[int] = mapped_column(primary_key=True)
    documento_id: Mapped[int] = mapped_column(ForeignKey('documenti.id', ondelete='RESTRICT'))
    manifest_json: Mapped[str] = mapped_column(Text)
    creato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    creato_da: Mapped[str] = mapped_column(String(120))


class RigaEsportazioneINAIL(Base):
    __tablename__ = 'dm_esportazioni_inail_righe'
    __table_args__ = (UniqueConstraint('esportazione_id', 'incarico_id'),)
    id: Mapped[int] = mapped_column(primary_key=True)
    esportazione_id: Mapped[int] = mapped_column(ForeignKey('dm_esportazioni_inail.id', ondelete='RESTRICT'), index=True)
    incarico_id: Mapped[int] = mapped_column(ForeignKey('dm_incarichi.id', ondelete='RESTRICT'), index=True)
    dati_json: Mapped[str] = mapped_column(Text)


class SchedaVerbaleDM(Base):
    """0.13.0 (R123, documento 24 § 4.1): dati del verbale che sono attributi dell'attrezzatura, a gruppi. Ogni riga è
    una versione di un gruppo (correzione a mano o «Conserva/Aggiorna» all'emissione); non si modifica né si cancella.
    Il gruppo corrente è la riga più recente oppure, se più nuovo, il verbale effettuato pertinente (regola di Garda
    `copia_dati_precedente_verifica`)."""
    __tablename__ = "dm_schede_verbale"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    asset_id: Mapped[int] = mapped_column(ForeignKey("asset.id", ondelete="RESTRICT"), index=True)
    gruppo: Mapped[str] = mapped_column(String(30))
    campi_json: Mapped[str] = mapped_column(Text)
    origine: Mapped[str] = mapped_column(String(20))           # manuale | verbale
    incarico_id: Mapped[int | None] = mapped_column(ForeignKey("dm_incarichi.id", ondelete="RESTRICT"))
    data_riferimento: Mapped[date] = mapped_column(Date)
    nota: Mapped[str] = mapped_column(Text, default="", server_default="")
    creato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    creato_da: Mapped[str] = mapped_column(String(120))
