"""Riproposizione selettiva Garda, _custom.php:copia_dati_precedente_verifica.

Solo lavori effettuati, ordinati per rilascio e ID. I contenuti salvati e i
documenti effettuati non vengono ricalcolati quando cambia la scheda corrente.
"""

from sqlalchemy import select

from ..preventivi.modelli import RigaPreventivo
from .modelli import IncaricoDM
from .servizio import componenti

ACQUA = ('gvr_check_param_acqua', 'gvr_check_conduttore', 'gvr_cond', 'gvr_abil_n', 'gvr_ril_il')
ACCESSORI = ('gvr_acc_sicur', 'gvr_disp_contr', 'gvr_disp_regol', 'gvr_altri_acc', 'gvr_valv_interc')
SCSP = ('sc_sp_cond_gen', 'sc_sp_esame_org_princ', 'sc_sp_comp_prove_funz', 'sc_sp_conf_dati_tecn', 'sc_sp_osservazioni')


def effettuate(s, asset_id):
    return list(s.scalars(select(IncaricoDM).where(IncaricoDM.asset_id == asset_id,
        IncaricoDM.stato == 'effettuata').order_by(IncaricoDM.data_rilascio.desc(), IncaricoDM.id.desc())))


def pertinente(s, v, componente):
    r = s.get(RigaPreventivo, v.riga_id)
    return componente in componenti('GVR' if r.tipo_verifica_gvr else 'SC', r.tipo_verifica_gvr)


def riproponi(s, a, r, d):
    """0.13.0: la bozza riparte dai dati del verbale dell'attrezzatura (scheda a gruppi, `scheda_verbale`), che
    applicano la stessa regola di Garda e in più accolgono le correzioni a mano."""
    from .scheda_verbale import riproponi as dalla_scheda
    return dalla_scheda(s, a, r, d)
