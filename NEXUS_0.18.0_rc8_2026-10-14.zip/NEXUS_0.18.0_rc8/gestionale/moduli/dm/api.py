from fastapi import APIRouter, Body, Depends, Query, File, Form, UploadFile
from fastapi.responses import Response
from urllib.parse import quote
from sqlalchemy import select, or_

from ...core.db import Archivio
from ...web.dipendenze import archivio, richiede, utente
from ..utenti.accesso import UtenteCorrente
from ..anagrafica.servizio import controlla_versione, _modificato
from ..preventivi import servizio as pv
from ..registro import servizio as registro
from . import servizio, tecnico, documenti
from .modelli import IncaricoDM, TariffaDM, STATI_DM, DocumentoDM, InvioDM

router = APIRouter(prefix="/api/dm")


@router.get("/tariffe")
def tariffe(_u: UtenteCorrente = Depends(richiede("tariffario.vedere")), arc: Archivio = Depends(archivio)):
    with arc.lettura() as s:
        return [{"id": t.id, "gruppo": t.gruppo, "id_spec_id": t.id_spec_id,
                 "compatibilita_id": t.compatibilita_id, "tipo": t.tipo, "importo": t.importo}
                for t in s.scalars(select(TariffaDM).order_by(TariffaDM.id))]


@router.post("/preventivi/{preventivo_id}/attrezzature")
def aggiungi(preventivo_id: int, dati: dict = Body(...),
             u: UtenteCorrente = Depends(richiede("preventivi.modifica")), arc: Archivio = Depends(archivio)):
    with arc.scrittura() as s:
        p = pv.preventivo_o_404(s, preventivo_id)
        controlla_versione(p, dati.get("versione"))
        pv._richiedi_modificabile(p)
        for r in dati.get("attrezzature") or []:
            servizio.nuova_riga(s, p, r)
        pv._totali(p)
        _modificato(p, u.come_attore())
        s.flush()
        registro.scrivi(s, utente=u.come_attore(), azione="preventivo.aggiungi_righe", oggetto_tipo="preventivo",
                        oggetto_id=p.id, descrizione=f"Aggiunte attrezzature al preventivo DM {p.codice}")
        return pv.preventivo_json(s, p)


@router.post("/preventivi/da-scadenze")
def da_scadenze(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("preventivi.modifica")), arc: Archivio = Depends(archivio)):
    """N8 (0.12.8): righe di preventivo DM dalle scadenze selezionate, una per scadenza (Garda AD-42/43)."""
    with arc.scrittura() as s:
        creati = servizio.da_scadenze(s, u.come_attore(), dati)
        return {"preventivi": [{"id": p.id, "codice": pv.etichetta(p), "righe": len(p.righe)} for p in creati]}


@router.get("/incarichi/valori")
def valori(_u: UtenteCorrente = Depends(richiede("verifiche.vedere_proprie", "DM")), arc: Archivio = Depends(archivio)):
    from ..verifiche.servizio import verificatori
    with arc.lettura() as s:
        return {"stati": STATI_DM, "verificatori": verificatori(s, "DM")}


@router.get("/incarichi")
def incarichi(q: str = "", stato: str = "", mie: bool = False, pagina: int = Query(1, ge=1),
              u: UtenteCorrente = Depends(richiede("verifiche.vedere_proprie", "DM")), arc: Archivio = Depends(archivio)):
    from ..beni.modelli import Asset
    from ..anagrafica.modelli import Cliente, Sede
    with arc.lettura() as s:
        query = select(IncaricoDM).join(Asset).join(Sede).join(Cliente)
        if not u.puo("verifiche.vedere_tutte", "DM") or mie:
            query = query.where(IncaricoDM.verificatore_id == u.id)
        if stato == "da_fatturare":  # N6 (0.12.8): effettuato, riesame conforme, riga non ancora fatturata
            from ..finanza.da_fatturare import riga_da_fatturare_di
            query = query.where(IncaricoDM.stato == "effettuata", riga_da_fatturare_di(IncaricoDM.riga_id))
        elif stato:
            query = query.where(IncaricoDM.stato == stato)
        if q.strip():
            termine = '%' + q.strip().replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_') + '%'
            query = query.where(or_(*(c.ilike(termine, escape='\\') for c in
                (Cliente.ragione_sociale, Sede.denominazione, Asset.denominazione, Asset.matr_informale, IncaricoDM.codice_verbale))))
        out = []
        for v in s.scalars(query.order_by(IncaricoDM.id.desc()).offset((pagina-1)*50).limit(50)):
            item = tecnico.scheda(s, v)
            out.append({k: x for k, x in item.items() if k not in ('bozza','fotografia_preventivo','campi','documenti','riesami','invii','profilo_tecnico')})
        return out


def visibile(s, u, id):
    from ...core.errori import PermessoNegato
    v = tecnico.leggi(s, id)
    if not tecnico.vedere(u, v):
        raise PermessoNegato("Questo incarico è assegnato a un altro tecnico.")
    return v


@router.get("/incarichi/{id}")
def scheda(id: int, u: UtenteCorrente = Depends(richiede("verifiche.vedere_proprie", "DM")), arc: Archivio = Depends(archivio)):
    with arc.lettura() as s:
        return tecnico.scheda(s, visibile(s, u, id))


@router.post("/incarichi/assegna-in-blocco")
def blocco(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("verifiche.assegna", "DM")), arc: Archivio = Depends(archivio)):
    from ...core.errori import ErroreUtente
    richieste = dati.get('incarichi')
    if not isinstance(richieste, list) or not 1 <= len(richieste) <= 500 or any(not isinstance(x, dict) for x in richieste):
        raise ErroreUtente('Seleziona da 1 a 500 incarichi.')
    ids = [servizio.beni.intero(x.get('id'), 'Incarico') for x in richieste]
    if len(set(ids)) != len(ids):
        raise ErroreUtente('Incarico ripetuto nella selezione.')
    with arc.scrittura() as s:
        for id, rd in zip(ids, richieste):
            tecnico.assegna(s, u, tecnico.leggi(s, id), {**rd, 'verificatore_id': dati.get('verificatore_id')})
        return {'assegnate': len(ids)}


@router.put("/incarichi/{id}/bozza")
def bozza(id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)):
    with arc.scrittura() as s:
        v = tecnico.leggi(s, id)
        tecnico.salva_bozza(s, u, v, dati)
        return tecnico.scheda(s, v)


# ---------------------------------------------------------------- 0.13.0: dati del verbale dell'attrezzatura (R123)
@router.get('/attrezzature/{asset_id}/dati-verbale')
def dati_verbale(asset_id: int, u: UtenteCorrente = Depends(richiede('beni.vedere')), arc: Archivio = Depends(archivio)):
    from ..beni import servizio as beni
    from . import scheda_verbale
    with arc.lettura() as s:
        return scheda_verbale.scheda_json(s, beni.leggi(s, asset_id))


@router.put('/attrezzature/{asset_id}/dati-verbale/{gruppo}')
def correggi_dati_verbale(asset_id: int, gruppo: str, dati: dict = Body(...), u: UtenteCorrente = Depends(utente),
                          arc: Archivio = Depends(archivio)):
    from ...core.errori import PermessoNegato
    from ..beni import servizio as beni
    from . import scheda_verbale
    if not (u.puo('beni.gestire') or u.puo('verifiche.esegui', 'DM')):
        raise PermessoNegato('Non puoi correggere i dati tecnici delle attrezzature.')
    with arc.scrittura() as s:
        a = beni.leggi(s, asset_id)
        scheda_verbale.correggi(s, u.come_attore(), a, gruppo, dati)
        tecnico.propaga(s, u.come_attore(), a.id)
        return scheda_verbale.scheda_json(s, a)


# ---------------------------------------------------------------- 0.13.0: firma grafica per i verbali DM
@router.get('/tecnici/{id}/firma')
def firma_dm(id: int, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)):
    from ...core.errori import NonTrovato, PermessoNegato
    if not u.puo('sistema.utenti') and u.id != id:
        raise PermessoNegato('Puoi vedere soltanto la tua firma.')
    with arc.lettura() as s:
        raw = documenti.firma_dm(s, arc, id)
        if raw is None:
            raise NonTrovato('Firma DM non caricata.')
    from ...terzi.verbalizzai import templates
    fmt, _, _ = templates.image_info(raw)
    return Response(raw, media_type='image/png' if fmt == 'png' else 'image/jpeg', headers={'Cache-Control': 'no-store'})


@router.post('/tecnici/{id}/firma')
async def carica_firma_dm(id: int, file: UploadFile = File(...), versione: str = Form(""), u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)):
    raw = await file.read()
    with arc.scrittura() as s:
        if versione:
            tecnico.versione_obbligatoria(documenti.utente_firma(s, u, id), versione)
        return documenti.salva_firma_dm(s, arc, u, id, raw, file.filename or 'firma')


@router.delete('/tecnici/{id}/firma')
def togli_firma_dm(id: int, versione: int | None = None, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)):
    with arc.scrittura() as s:
        if versione is not None:
            tecnico.versione_obbligatoria(documenti.utente_firma(s, u, id), versione)
        return documenti.togli_firma_dm(s, u, id)


@router.get('/tecnici/{id}/profilo')
def leggi_profilo(id: int, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)):
    """0.12.9: i dati del tecnico si gestiscono nella scheda dell'utente (Gestione › Utenti e permessi) o nel proprio profilo."""
    from ...core.errori import NonTrovato, PermessoNegato
    from ..utenti.modelli import Utente
    if not u.puo('sistema.utenti') and u.id != id:
        raise PermessoNegato('Puoi vedere soltanto i tuoi dati tecnici.')
    with arc.lettura() as s:
        x = s.get(Utente, id)
        if x is None:
            raise NonTrovato('Utente non trovato.')
        return documenti.profilo_json(x)


@router.put('/tecnici/{id}/profilo')
def profilo(id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)):
    with arc.scrittura() as s:
        return documenti.salva_profilo(s, u, id, dati)


@router.post('/incarichi/{id}/documenti/genera')
def genera(id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)):
    from ...core.errori import ErroreUtente
    with arc.lettura() as s:
        prep = documenti.prepara(s, arc, u, tecnico.leggi(s, id), dati.get('versione'))
    files = documenti.compila(prep, arc)
    with arc.scrittura() as s:
        v = tecnico.leggi(s, id)
        attuale = documenti.prepara(s, arc, u, v, dati.get('versione'))
        if attuale['impronta'] != prep['impronta']:
            raise ErroreUtente('Scheda o firma cambiate durante la conversione: rigenera.', 409)
        documenti.salva(s, arc, u, v, prep, files, 'verbale', 'anteprima')
        return tecnico.scheda(s, v)


@router.post('/incarichi/{id}/documenti/carica')
async def carica_documento(id: int, file: UploadFile = File(...), versione: str = Form(...),
    tipo: str = Form('verbale'), u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)):
    from ...core.errori import ErroreUtente
    raw = await file.read(25 * 1024 * 1024 + 1)
    if tipo not in ('verbale', 'scheda_tecnica'):
        raise ErroreUtente('Tipo di documento non valido.')
    nome = (file.filename or '').lower()
    with arc.lettura() as s:
        v = tecnico.leggi(s, id)
        if nome.endswith('.docx') and tipo == 'verbale':
            prep = documenti.ritocco(s, arc, u, v, {'versione': versione}, raw)
            origine = 'word_ritoccato'
        elif nome.endswith('.pdf'):
            prep = documenti.prepara(s, arc, u, v, versione)
            documenti.valida_pdf(raw)
            origine = 'pdf_caricato'
        else:
            raise ErroreUtente('Verbale: Word .docx ritoccato o PDF; scheda tecnica: PDF.')
    files = documenti.compila(prep, arc, raw) if origine == 'word_ritoccato' else {'pdf': raw}
    with arc.scrittura() as s:
        v = tecnico.leggi(s, id)
        attuale = documenti.prepara(s, arc, u, v, versione)
        if attuale['impronta'] != prep['impronta']:
            raise ErroreUtente('Scheda o firma cambiate durante il caricamento: riprova.', 409)
        documenti.salva(s, arc, u, v, prep, files, tipo, origine)
        return tecnico.scheda(s, v)


@router.get('/incarichi/{id}/documenti/{documento_id}')
def scarica(id: int, documento_id: int, in_linea: bool = False, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)):
    from ..documenti import servizio as archivio_documenti
    from ...core.errori import NonTrovato
    with arc.lettura() as s:
        visibile(s, u, id)
        x = s.get(DocumentoDM, documento_id)
        if x is None or x.incarico_id != id:
            raise NonTrovato('Documento non appartenente a questo incarico.')
        doc, raw = archivio_documenti.leggi(s, arc.cfg.cartella_documenti, x.documento_id)
        modo = 'inline' if in_linea and x.formato == 'pdf' else 'attachment'
        return Response(raw, media_type=doc.tipo_mime, headers={'Content-Disposition': f"{modo}; filename*=UTF-8''{quote(x.nome_file)}"})


@router.post('/incarichi/riesame-in-blocco')
def riesame_blocco(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede('verifiche.riesame', 'DM')), arc: Archivio = Depends(archivio)):
    from ...core.errori import ErroreUtente
    richieste = dati.get('incarichi')
    if not isinstance(richieste, list) or not 1 <= len(richieste) <= 500 or any(not isinstance(x, dict) for x in richieste):
        raise ErroreUtente('Seleziona da 1 a 500 incarichi.')
    ids = [servizio.beni.intero(x.get('id'), 'Incarico') for x in richieste]
    if len(ids) != len(set(ids)):
        raise ErroreUtente('Incarico ripetuto.')
    with arc.scrittura() as s:
        for id, rd in zip(ids, richieste):
            documenti.riesame(s, u, tecnico.leggi(s, id), {**dati, 'versione': rd.get('versione')})
        return {'riesaminate': len(ids)}


@router.post('/incarichi/registra-in-blocco')
def registra_blocco(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede('verifiche.esegui', 'DM')), arc: Archivio = Depends(archivio)):
    """Documento 28, punto 13: registrazione di più incarichi DM con la stessa data (tutto o niente)."""
    from ...core.errori import ErroreUtente
    richieste = dati.get('incarichi')
    if not isinstance(richieste, list) or not 1 <= len(richieste) <= 200 or any(not isinstance(x, dict) for x in richieste):
        raise ErroreUtente('Seleziona da 1 a 200 incarichi.')
    if len({x.get('id') for x in richieste}) != len(richieste):
        raise ErroreUtente('Incarico ripetuto.')
    with arc.scrittura() as s:
        return {'registrati': tecnico.registra_in_blocco(s, u, richieste, dati)}


def _allegati(s, arc, u, v):
    from ...core.errori import ErroreUtente
    if not u.puo('verifiche.invia', 'DM') or not tecnico.vedere(u, v):
        from ...core.errori import PermessoNegato
        raise PermessoNegato('Non puoi inviare i documenti di questa verifica.')
    if v.stato != 'effettuata':
        raise ErroreUtente('Chiudi prima la verifica con il PDF definitivo.')
    docs = [x for x in s.scalars(select(DocumentoDM).where(DocumentoDM.incarico_id == v.id,
        DocumentoDM.attuale.is_(True), DocumentoDM.formato == 'pdf')) if x.definitivo_il]
    if not any(x.tipo == 'verbale' for x in docs):
        raise ErroreUtente('Manca il PDF definitivo del verbale.')
    from ..documenti import servizio as archivio_documenti
    return [(x, archivio_documenti.leggi(s, arc.cfg.cartella_documenti, x.documento_id)[1]) for x in docs]


@router.get('/incarichi/{id}/email')
def bozza_email(id: int, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)):
    from ...core.posta import ImpostazioniPosta
    cfg = ImpostazioniPosta(arc.cfg.cartella_dati, 'DM')  # C15: posta AD_DM
    with arc.lettura() as s:
        v = visibile(s, u, id)
        docs = _allegati(s, arc, u, v)
        a, _, _ = tecnico.dati_lavoro(s, v)
        return {'a': a.sede.referente_email, 'cc': cfg.leggi().get('copia_ufficio', ''),
            'oggetto': f'Verbale {v.codice_verbale} — {a.sede.cliente.ragione_sociale}',
            'testo': f'Spett.le {a.sede.cliente.ragione_sociale},\n\nin allegato trasmettiamo il verbale di verifica.\n\nCordiali saluti\nAD S.r.l.',
            'allegati': [{'id': d.id, 'nome': d.nome_file} for d, _ in docs], 'versione': v.versione}


@router.post('/incarichi/{id}/email')
def invia_email(id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)):
    from ...core import posta
    from ...core.errori import ErroreUtente
    a, cc = posta.dividi_indirizzi(dati.get('a')), posta.dividi_indirizzi(dati.get('cc'))
    oggetto, testo = dati.get('oggetto', ''), dati.get('testo', '')
    if not a or not isinstance(oggetto, str) or not oggetto.strip() or len(oggetto) > 300 or not isinstance(testo, str) or not testo.strip():
        raise ErroreUtente('Completa destinatari, oggetto e testo.')
    with arc.lettura() as s:
        v = visibile(s, u, id)
        tecnico.versione_obbligatoria(v, dati.get('versione'))
        docs = _allegati(s, arc, u, v)
        if dati.get('allegati') != [d.id for d, _ in docs]:
            raise ErroreUtente('Riapri la bozza email: gli allegati non coincidono.')
        files = [(d.nome_file, raw, 'application/pdf') for d, raw in docs]
        ids = [d.documento_id for d, _ in docs]
    cfg = posta.ImpostazioniPosta(arc.cfg.cartella_dati, 'DM').leggi()  # C15: posta AD_DM
    msg = posta.componi(cfg, a, cc, oggetto, testo, files)
    esito = posta.invia(cfg, msg)
    with arc.scrittura() as s:
        v = tecnico.leggi(s, id)
        s.add(InvioDM(incarico_id=id, destinatari='; '.join(a), copia='; '.join(cc), oggetto=oggetto.strip(),
            testo=testo, allegati_json=documenti.dumps(ids), esito=esito, inviato_da=u.nome))
        _modificato(v, u.come_attore())
        registro.scrivi(s, utente=u.come_attore(), azione='dm.invio_email', oggetto_tipo='incarico_dm', oggetto_id=id,
                       descrizione=f'Inviato PDF definitivo {v.codice_verbale}', dettagli={'allegati': ids, 'esito': esito})
        s.flush()
        return tecnico.scheda(s, v) | {'esito_invio': esito}


@router.post("/incarichi/{id}/{azione}")
def cambia(id: int, azione: str, dati: dict = Body(...), u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)):
    from ...core.errori import PermessoNegato
    firmati = None
    if azione == 'effettuata':
        # 0.15: firma DM al posto dello spazio riservato e controllo delle pagine, fuori dalla scrittura (LibreOffice)
        with arc.lettura() as s:
            firmati = documenti.firma_per_emissione(s, arc, u, tecnico.leggi(s, id), dati)
    with arc.scrittura() as s:
        v = tecnico.leggi(s, id)
        if azione == 'assegna':
            if not u.puo('verifiche.assegna', 'DM'):
                raise PermessoNegato('Non puoi assegnare incarichi.')
            tecnico.assegna(s, u, v, dati)
        elif azione == 'programma':
            tecnico.programma(s, u, v, dati)
        elif azione == 'registra':
            if 'bozza' in dati:
                from ...core.errori import ErroreUtente
                if not isinstance(dati['bozza'], dict):
                    raise ErroreUtente('Scheda tecnica non valida.')
                tecnico.salva_bozza(s, u, v, {**dati['bozza'], 'versione': dati.get('versione')})
                tecnico.registra(s, u, v, {'versione': v.versione})
            else:
                tecnico.registra(s, u, v, dati)
        elif azione == 'effettuata':
            avvisi = documenti.effettua(s, arc, u, v, dati, firmati)
            return tecnico.scheda(s, v) | {'avvisi': avvisi}
        elif azione == 'riesame':
            documenti.riesame(s, u, v, dati)
        else:
            tecnico.azione(s, u, v, azione, dati)
        return tecnico.scheda(s, v)
