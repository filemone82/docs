"""Verifiche (fase 5, documento 10): dall\x27accettazione del preventivo al verbale riesaminato."""
