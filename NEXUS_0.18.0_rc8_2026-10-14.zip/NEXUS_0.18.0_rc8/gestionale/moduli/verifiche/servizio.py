"""Regole delle verifiche (fase 5; documento 10 § B.5 e § B.10; decisioni D61–D64)."""

from __future__ import annotations

import json
from datetime import date
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ...core.date import formatta_data, iso_locale, utc_a_locale
from ...core.db import adesso
from ...core.errori import ErroreUtente, NonTrovato, PermessoNegato
from ..anagrafica.modelli import TIPOLOGIE_IMPIANTO, Cliente, Impianto, Sede
from ..anagrafica.servizio import _crea, _data, _modificato, _t, controlla_versione, scadenza
from ..documenti import servizio as documenti
from ..preventivi.modelli import TIPI_VERIFICA, Preventivo
from ..registro import servizio as registro
from ..utenti.modelli import Utente
from . import lettura_verbale
from .modelli import ESITI, ESITI_RIESAME, MODULO_PER_TIPOLOGIA, STATI, TIPI_ELEMENTO, DocumentoVerifica, ElementoImpianto, Verifica, RiesameVerifica

APERTE = ("da_assegnare", "assegnata", "programmata", "registrata", "sospesa")
DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"


def verifica_o_404(s: Session, verifica_id: int) -> Verifica:
    v = s.get(Verifica, verifica_id)
    if v is None:
        raise NonTrovato("Verifica non trovata: ricarica la pagina.")
    return v


def puo_vedere(u: Any, v: Any, attivita: str = "DPR") -> bool:
    return u.puo("verifiche.vedere_tutte", attivita) or (u.puo("verifiche.vedere_proprie", attivita) and v.verificatore_id == u.id)


def _richiedi_esecutore(u: Any, v: Any, attivita: str = "DPR") -> None:
    """Programmare, registrare e caricare il verbale: il verificatore assegnato, oppure chi assegna (RT) per suo conto."""
    if u.puo("verifiche.assegna", attivita):
        return
    if u.puo("verifiche.esegui", attivita) and v.verificatore_id == u.id:
        return
    raise PermessoNegato("Questa verifica è assegnata a un altro verificatore.")


def etichetta(v: Verifica) -> str:
    return v.codice_verbale or f"verifica n. {v.id}"


# ---------------------------------------------------------------- nascita dal preventivo


def crea_da_preventivo(s: Session, attore: Any, p: Preventivo) -> list[Verifica]:
    """D61: dopo il riesame del contratto conforme, una verifica per ogni riga accettata con impianto (mai senza preventivo, V5)."""
    if p.ambito == "DM":
        from ..dm.servizio import genera_incarichi
        return genera_incarichi(s, attore, p)
    # le verifiche annullate (es. revoca R124) non contano: una riga riaccettata e riesaminata ha di nuovo la sua verifica
    gia = set(s.execute(select(Verifica.riga_id).where(Verifica.preventivo_id == p.id, Verifica.stato != "annullata")).scalars())
    nuove = []
    for r in p.righe:
        if r.stato != "accettata" or r.impianto_id is None or r.id in gia:
            continue
        from ..preventivi.copertura import controlla

        controlla(s, r.impianto_id, r.tipo_verifica, p.id)
        v = Verifica(riga_id=r.id, preventivo_id=p.id, impianto_id=r.impianto_id, tipo_verifica=r.tipo_verifica, stato="da_assegnare")
        _crea(s, v, attore)
        nuove.append(v)
    s.flush()
    if nuove:
        registro.scrivi(s, utente=attore, azione="verifica.crea", oggetto_tipo="preventivo", oggetto_id=p.id,
                        descrizione=f"Create {len(nuove)} verifiche «da assegnare» dalle righe accettate del preventivo {p.codice}"
                                    f"{f' rev. {p.revisione}' if p.revisione else ''}",
                        dettagli={"verifiche": [v.id for v in nuove], "impianti": [v.impianto_id for v in nuove]})
    return nuove


def verifica_attiva_della_riga(s: Session, riga_id: int) -> Verifica | None:
    return s.execute(select(Verifica).where(Verifica.riga_id == riga_id, Verifica.stato != "annullata")).scalar()


# ---------------------------------------------------------------- verificatori


def verificatori(s: Session, attivita: str = "DPR") -> list[dict]:
    """Utenti attivi con il permesso di eseguire verifiche in quell'attività (R132: un verificatore DM non compare
    fra quelli DPR e viceversa; il «Verificatore DM e DPR» in entrambi)."""
    from ...core.permessi import attivita_di
    from ..utenti import servizio as utenti

    risultato = []
    for u in s.execute(select(Utente).where(Utente.attivo.is_(True)).order_by(Utente.nome)).scalars():
        # 0.16: con più ruoli basta un ruolo di quell'attività (o comune) che dia «eseguire le verifiche»
        for r in utenti.ruoli_di(u):
            abilitato = r.attivo and (r.di_sistema or not attivita_di(r.attivita) or attivita in attivita_di(r.attivita))
            if abilitato and "verifiche.esegui" in utenti.permessi_di_ruolo(s, r):
                risultato.append({"id": u.id, "nome": u.nome})
                break
    return risultato


# ---------------------------------------------------------------- serializzazione


def verifica_json(s: Session, v: Verifica) -> dict:
    x = s.get(Impianto, v.impianto_id)
    sede = s.get(Sede, x.sede_id)
    cliente = s.get(Cliente, sede.cliente_id)
    p = s.get(Preventivo, v.preventivo_id)
    ver = s.get(Utente, v.verificatore_id) if v.verificatore_id else None
    docs = s.execute(select(DocumentoVerifica).where(DocumentoVerifica.verifica_id == v.id).order_by(DocumentoVerifica.id.desc())).scalars().all()
    dati = json.loads(v.dati_verbale) if v.dati_verbale else None
    return {
        "id": v.id, "stato": v.stato, "stato_testo": STATI[v.stato], "tipo_verifica": v.tipo_verifica, "tipo_testo": TIPI_VERIFICA.get(v.tipo_verifica, ""),
        "impianto_id": x.id, "impianto_tipologia": TIPOLOGIE_IMPIANTO.get(x.tipologia, x.tipologia), "impianto_denominazione": x.denominazione,
        "modulo_atteso": MODULO_PER_TIPOLOGIA.get(x.tipologia, ""), "sede_id": sede.id, "sede": sede.denominazione,
        "sede_indirizzo": " ".join(t for t in (sede.indirizzo, sede.cap, sede.comune, f"({sede.provincia})" if sede.provincia else "") if t),
        "cliente_id": cliente.id, "cliente": cliente.ragione_sociale, "preventivo_id": p.id,
        "preventivo": p.codice + (f" rev. {p.revisione}" if p.revisione else ""), "riga_id": v.riga_id,
        "fattura": __import__("gestionale.moduli.finanza.servizio", fromlist=["fattura_della_riga"]).fattura_della_riga(s, v.riga_id),  # R139
        "verificatore_id": v.verificatore_id, "verificatore": ver.nome if ver else "", "assegnata_il": iso_locale(v.assegnata_il),
        "assegnata_da": v.assegnata_da, "data_programmata": v.data_programmata.isoformat() if v.data_programmata else None,
        "codice_verbale": v.codice_verbale, "verbale_id": v.verbale_id or "", "data_esecuzione": v.data_esecuzione.isoformat() if v.data_esecuzione else None,
        "registrata_il": iso_locale(v.registrata_il), "registrata_da": v.registrata_da,
        "modulo": v.modulo, "esito": v.esito, "esito_testo": ESITI.get(v.esito, ""), "prossima_verifica": v.prossima_verifica.isoformat() if v.prossima_verifica else None,
        "dati_verbale": dati, "avvisi_verbale": [a for a in v.avvisi_verbale.split("\n") if a], "eseguita_il": iso_locale(v.eseguita_il), "caricata_da": v.caricata_da,
        "indipendenza": v.indipendenza, "indipendenza_esclusa": v.indipendenza_esclusa, "motivo_sospensione": v.motivo_sospensione,
        "storico_riesami": [{"id": r.id, "documento_id": r.documento_id, "verbale_id": r.verbale_id, "esito": r.esito, "note": r.note,
                             "eseguito_il": iso_locale(r.eseguito_il), "eseguito_da": r.eseguito_da}
                            for r in s.scalars(select(RiesameVerifica).where(RiesameVerifica.verifica_id == v.id).order_by(RiesameVerifica.id))],
        "riesame_esito": v.riesame_esito, "riesame_esito_testo": ESITI_RIESAME.get(v.riesame_esito, ""), "riesame_note": v.riesame_note,
        "riesame_il": iso_locale(v.riesame_il), "riesame_da": v.riesame_da, "motivo_annullamento": v.motivo_annullamento, "note": v.note,
        "documenti": [{"id": d.id, "formato": d.formato, "documento_id": d.documento_id, "nome_file": d.nome_file, "in_uso": d.in_uso,
                       "creato_il": iso_locale(d.creato_il), "creato_da": d.creato_da} for d in docs],
        "versione": v.versione, "creato_il": iso_locale(v.creato_il), "creato_da": v.creato_da,
        "modificato_il": iso_locale(v.modificato_il), "modificato_da": v.modificato_da,
    }


def _stato(v: Verifica) -> dict:
    return {"stato": v.stato, "verificatore_id": v.verificatore_id, "data_programmata": v.data_programmata.isoformat() if v.data_programmata else None,
            "codice_verbale": v.codice_verbale, "data_esecuzione": v.data_esecuzione.isoformat() if v.data_esecuzione else None,
            "esito": v.esito, "prossima_verifica": v.prossima_verifica.isoformat() if v.prossima_verifica else None, "note": v.note, "indipendenza": v.indipendenza, "motivo_sospensione": v.motivo_sospensione}


def _scrivi(s: Session, attore: Any, v: Verifica, azione: str, descrizione: str, prima: dict, **extra: Any) -> None:
    _modificato(v, attore)
    registro.scrivi(s, utente=attore, azione=azione, oggetto_tipo="verifica", oggetto_id=v.id, descrizione=descrizione,
                    dettagli={"modifiche": registro.differenze(prima, _stato(v)), **extra})


# ---------------------------------------------------------------- passaggi di stato


def assegna(s: Session, attore: Any, verifica_id: int, dati: dict) -> Verifica:
    """RT: sceglie (o cambia) il verificatore, finché la verifica non è eseguita."""
    v = verifica_o_404(s, verifica_id)
    controlla_versione(v, dati.get("versione"))
    if v.stato not in APERTE:
        raise ErroreUtente(f"La verifica è «{STATI[v.stato]}»: non si riassegna.")
    ids = {x["id"] for x in verificatori(s)}
    nuovo = int(dati.get("verificatore_id") or 0)
    if nuovo not in ids:
        raise ErroreUtente("Scegli un verificatore (utente attivo con il permesso di eseguire verifiche).")
    prima = _stato(v)
    if v.verificatore_id != nuovo:
        v.indipendenza = True
    v.verificatore_id, v.assegnata_il, v.assegnata_da = nuovo, adesso(), getattr(attore, "nome", "")
    if v.stato == "da_assegnare":
        v.stato = "assegnata"
    nome = s.get(Utente, nuovo).nome
    _scrivi(s, attore, v, "verifica.assegna", f"Verifica n. {v.id} (impianto n. {v.impianto_id}) assegnata a {nome}", prima)
    return v


def assegna_in_blocco(s: Session, attore: Any, ids: list, verificatore_id: Any) -> dict:
    """O17: più verifiche allo stesso verificatore. Tutte o nessuna: se una non si può assegnare, non cambia nulla."""
    ids = sorted({int(x) for x in ids or []})
    if not ids:
        raise ErroreUtente("Seleziona almeno una verifica.")
    if len(ids) > 500:
        raise ErroreUtente("Troppe verifiche in una volta (massimo 500).")
    problemi = []
    for i in ids:
        v = verifica_o_404(s, i)
        if v.stato not in APERTE:
            problemi.append(f"n. {v.id} ({STATI[v.stato]})")
    if problemi:
        raise ErroreUtente("Non si riassegnano le verifiche già eseguite o annullate: " + ", ".join(problemi) + ". Togli la spunta e riprova.")
    for i in ids:
        assegna(s, attore, i, {"verificatore_id": verificatore_id})
    return {"assegnate": len(ids)}


INDIPENDENZA_ESCLUSA = ("Indipendenza esclusa: il tecnico ha dichiarato di non essere indipendente, quindi non può "
                        "programmare, registrare né eseguire questa verifica. Riassegnala a un altro tecnico.")


def dichiara_indipendenza(attore: Any, v: Any, valore: Any, *, dm: bool = False) -> str:
    """R119 (Federico, 11/10/2026, 15:54): l'indipendenza la dichiara il verificatore a cui è affidata la verifica
    (anche quando è il responsabile tecnico). Preimpostata su «Sì». Con «No» la verifica torna al responsabile tecnico
    da riassegnare: niente verificatore, niente data prevista; resta scritto chi l'ha esclusa e quando.
    Dopo la registrazione (numero del verbale assegnato) non si cambia più: chi assegna può riassegnarla.
    Vale per DPR e DM. Restituisce la descrizione per il registro."""
    if not isinstance(valore, bool):
        raise ErroreUtente("Indica se confermi l'indipendenza (sì o no).")
    if not v.verificatore_id or v.verificatore_id != getattr(attore, "id", None):
        raise PermessoNegato("L'indipendenza la dichiara il verificatore a cui è affidata la verifica.")
    if v.stato not in ("assegnata", "programmata"):
        raise ErroreUtente("L'indipendenza si dichiara prima della registrazione. Se ora c'è un conflitto, chiedi al "
                           "responsabile tecnico di riassegnare la verifica (il numero del verbale resta).")
    if valore:
        v.indipendenza = True
        return f"{getattr(attore, 'nome', '')}: indipendenza confermata"
    quando = utc_a_locale(adesso()).strftime("%d/%m/%Y %H:%M")
    v.indipendenza_esclusa = f"{getattr(attore, 'nome', '')} ha dichiarato di NON essere indipendente il {quando}: da riassegnare."
    v.stato, v.verificatore_id, v.data_programmata, v.indipendenza = "da_assegnare", None, None, True
    if dm:
        v.bozza_json, v.bozza_salvata = "{}", False
    return v.indipendenza_esclusa


def richiedi_indipendenza(v: Any) -> None:
    """R110 (11/10/2026): dichiarazione preimpostata su «Sì»; con «No» la verifica non si programma, non si registra
    e non si esegue. Vale per DPR e DM (stesso controllo, chiamato dai due moduli)."""
    if not v.indipendenza:
        raise ErroreUtente(INDIPENDENZA_ESCLUSA)


def programma(s: Session, attore: Any, verifica_id: int, dati: dict) -> Verifica:
    """Verificatore: data prevista (facoltativa ma consigliata)."""
    v = verifica_o_404(s, verifica_id)
    controlla_versione(v, dati.get("versione"))
    _richiedi_esecutore(attore, v)
    richiedi_indipendenza(v)
    if v.stato not in ("assegnata", "programmata"):
        raise ErroreUtente("Si programma una verifica assegnata e non ancora registrata.")
    giorno = _data(dati, "data_programmata", "Data prevista")
    if giorno is not None:
        anno_ammesso(giorno, "Data prevista")
    if giorno is None:
        raise ErroreUtente("Scrivi la data prevista.")
    prima = _stato(v)
    v.data_programmata = giorno
    v.stato = "programmata"
    v.note = _t(dati, "note", 4000) if "note" in dati else v.note
    _scrivi(s, attore, v, "verifica.programma", f"Verifica n. {v.id} programmata per il {formatta_data(giorno)}", prima)
    return v


NUMERI_LASCIATI = "verifiche.numeri_lasciati"   # rc8 (B2): {"2026": [650]} numeri lasciati liberi da un cambio d'anno


def _numeri_lasciati(s: Session) -> dict:
    from ..impostazioni.modelli import Impostazione
    x = s.get(Impostazione, NUMERI_LASCIATI)
    return json.loads(x.valore) if x else {}


def _lascia_numero(s: Session, anno: int, numero: int) -> None:
    """Il numero resta un buco della serie (scelta di Federico, 14/10/2026): non si riassegna a un'altra verifica."""
    from ..impostazioni.modelli import Impostazione
    x = s.get(Impostazione, NUMERI_LASCIATI)
    valore = json.loads(x.valore) if x else {}
    valore.setdefault(str(anno), [])
    if numero not in valore[str(anno)]:
        valore[str(anno)].append(numero)
    if x is None:
        s.add(Impostazione(chiave=NUMERI_LASCIATI, valore=json.dumps(valore)))
    else:
        x.valore = json.dumps(valore)


def numero_successivo(s: Session, anno: int) -> int:
    ultimo = s.execute(select(func.max(Verifica.numero)).where(Verifica.anno == anno)).scalar() or 0
    return max([ultimo, *_numeri_lasciati(s).get(str(anno), [])]) + 1


def codice_verbale(tipo_verifica: str, anno: int, numero: int) -> str:
    """D62: un solo sezionale annuale per VP (periodica) e VS (straordinaria)."""
    return f"{'VS' if tipo_verifica == 'straordinaria' else 'VP'}/{numero:03d}/{anno % 100:02d}"


def anno_ammesso(giorno: date, etichetta: str) -> None:
    """B1 (rc8, Federico 14/10/2026): la data che si registra deve cadere nell'anno corrente, nel precedente o nel
    successivo. Un anno sbagliato (es. 0226) darebbe un numero di verbale di un altro «anno» (VP/001/26 ripetuto)."""
    oggi = date.today().year
    if not oggi - 1 <= giorno.year <= oggi + 1:
        raise ErroreUtente(f"{etichetta}: anno {giorno.year} non ammesso. Sono ammessi solo {oggi - 1}, {oggi} e {oggi + 1}: "
                           "controlla la data.")


def _numero_libero(s: Session, anno: int, escludi_id: int | None = None) -> int:
    """Primo numero dopo l'ultimo usato nell'anno, con un codice (VP o VS, stesso progressivo) mai usato da altre verifiche.
    Il vincolo (anno, numero) lo garantisce già con anni plausibili; il controllo sul codice protegge anche i dati
    importati o registrati prima della rc8 (B1: anno 226 → «…/26» come il 2026)."""
    numero = numero_successivo(s, anno)
    while True:
        codici = [codice_verbale(t, anno, numero) for t in ("periodica", "straordinaria")]
        q = select(Verifica.id).where(Verifica.codice_verbale.in_(codici))
        if escludi_id is not None:
            q = q.where(Verifica.id != escludi_id)
        if s.scalar(q) is None:
            return numero
        numero += 1


def registra(s: Session, attore: Any, verifica_id: int, dati: dict) -> Verifica:
    """Verificatore: prende il numero del verbale e fissa la data di esecuzione (D62)."""
    v = verifica_o_404(s, verifica_id)
    controlla_versione(v, dati.get("versione"))
    _richiedi_esecutore(attore, v)
    richiedi_indipendenza(v)
    if v.stato not in ("assegnata", "programmata"):
        raise ErroreUtente("Si registra una verifica assegnata (o programmata) e non ancora registrata.")
    giorno = _data(dati, "data_esecuzione", "Data di esecuzione")
    if giorno is None:
        raise ErroreUtente("Scrivi la data di esecuzione.")
    anno_ammesso(giorno, "Data di esecuzione")
    prima = _stato(v)
    v.anno, v.numero = giorno.year, _numero_libero(s, giorno.year, v.id)
    v.codice_verbale = codice_verbale(v.tipo_verifica, v.anno, v.numero)
    v.data_esecuzione, v.stato = giorno, "registrata"
    v.registrata_il, v.registrata_da = adesso(), getattr(attore, "nome", "")
    _scrivi(s, attore, v, "verifica.registra", f"Verifica n. {v.id} registrata: verbale {v.codice_verbale} del {formatta_data(giorno)}", prima)
    return v


def allinea_numero(s: Session, attore: Any, v: Verifica, giorno: date | None, straordinaria: bool | None) -> str | None:
    """B2 (rc8, Federico 14/10/2026): il numero del verbale lo assegna NEXUS e segue la data e il tipo del verbale.
    - stesso anno: il numero resta;
    - anno diverso (ammesso): nuovo numero, il primo libero di quell'anno; il vecchio resta un buco annotato nel registro;
    - periodica ↔ straordinaria: cambia solo il prefisso VP/VS, il numero resta.
    Solo su una verifica «registrata» (verbale non ancora emesso). Restituisce la descrizione della modifica o None."""
    if v.stato != "registrata" or v.numero is None or v.anno is None:
        return None
    tipo = v.tipo_verifica if straordinaria is None else ("straordinaria" if straordinaria else "periodica")
    anno = v.anno
    if giorno is not None and giorno.year != v.anno:
        anno_ammesso(giorno, "Data del verbale")
        anno = giorno.year
    if anno == v.anno and tipo == v.tipo_verifica:
        return None
    prima, vecchio, cambia_anno = _stato(v), v.codice_verbale, anno != v.anno
    if cambia_anno:
        _lascia_numero(s, v.anno, v.numero)
        v.anno, v.numero = anno, _numero_libero(s, anno, v.id)
        v.data_esecuzione = giorno
    v.tipo_verifica = tipo
    v.codice_verbale = codice_verbale(tipo, v.anno, v.numero)
    nota = f" Il numero {vecchio} resta libero nella serie (non usato): cambio dell'anno del verbale." if cambia_anno else ""
    descrizione = f"Verifica n. {v.id}: verbale {vecchio} → {v.codice_verbale} (data o tipo del verbale cambiati).{nota}"
    _scrivi(s, attore, v, "verifica.numero", descrizione, prima, numero_precedente=vecchio)
    return descrizione


def _aggiorna_impianto(s: Session, attore: Any, v: Verifica, letto: dict, scheda: bool = True) -> list[str]:
    return aggiorna_impianto(s, attore, v.impianto_id, letto, v.data_esecuzione, v.codice_verbale, v.prossima_verifica, scheda=scheda)


def aggiorna_impianto(s: Session, attore: Any, impianto_id: int, letto: dict, ultima: date, numero: str, prossima: date | None,
                      scheda: bool = True) -> list[str]:
    """All'esecuzione il verbale aggiorna l'impianto: ultima e prossima verifica, periodicità, caratteristiche, elementi (G39).
    Usata anche dall'importazione dell'archivio di VerbalizzAI (0.5.0) con l'ultimo verbale emesso.
    R122 (0.12.7): con `scheda=False` aggiorna solo date e periodicità; la scheda tecnica (caratteristiche, potenza,
    elementi) la riporta `verbali.scheda.sincronizza_plant` da quella di VerbalizzAI, che è l'unica."""
    from ..anagrafica import servizio as anagrafica

    x = s.get(Impianto, impianto_id)
    prima = anagrafica.dati_impianto(x)
    avvisi = []
    corrente = json.loads(x.caratteristiche or "{}")
    if scheda and corrente.get("data") and ultima.isoformat() < corrente["data"]:
        return ["Verbale storico conservato: lo stato tecnico più recente dell'impianto non è stato sostituito."]
    straordinaria = numero.startswith("VS/")
    if x.ultima_verifica_data and ultima < x.ultima_verifica_data:
        avvisi.append(f"L'impianto ha già un'ultima verifica più recente ({formatta_data(x.ultima_verifica_data)}): date dell'impianto non cambiate.")
    elif not straordinaria:
        x.ultima_verifica_data, x.ultima_verifica_numero = ultima, numero
        if letto["periodicita"] in (2, 5):
            x.periodicita_anni = 2 if x.tipologia == "esplosione" else letto["periodicita"]
        x.prossima_verifica = prossima
    if not scheda:
        _modificato(x, attore)
        dopo = anagrafica.dati_impianto(x)
        registro.scrivi(s, utente=attore, azione="impianto.da_verbale", oggetto_tipo="impianto", oggetto_id=x.id,
                        descrizione=f"Impianto n. {x.id} aggiornato dal verbale {numero} (date e periodicità)",
                        dettagli={"modifiche": registro.differenze(prima, dopo)})
        return avvisi
    stato_tecnico = letto.get("stato_tecnico", {})
    if x.tipologia in ("terra_bt", "terra_at"):
        # La potenza dell'ultimo verbale alimenta anche le prossime offerte. Valori non numerici restano nel profilo.
        from decimal import Decimal, InvalidOperation
        potenza = str(stato_tecnico.get("plant", {}).get("power", "")).strip()
        try:
            valore = Decimal(potenza.replace(",", "."))
            if valore.is_finite() and valore >= 0:
                x.potenza_kw = float(valore)
        except InvalidOperation:
            pass
    x.caratteristiche = json.dumps({"stato_tecnico": stato_tecnico, "modulo": letto["modulo"], "verbale": numero, "data": ultima.isoformat(),
                                    "voci": letto["caratteristiche"]}, ensure_ascii=False)
    # elementi provati: si aggiornano quelli del verbale, gli altri restano ma «non più nel verbale»
    esistenti = {(e.tipo, e.quadro, e.nome, e.occorrenza): e for e in
                 s.execute(select(ElementoImpianto).where(ElementoImpianto.impianto_id == x.id)).scalars()}
    visti = set()
    for el in letto["elementi"]:
        chiave = (el["tipo"], el["quadro"], el["nome"], el["occorrenza"])
        if chiave in visti:
            continue
        visti.add(chiave)
        e = esistenti.get(chiave)
        if e is None:
            e = ElementoImpianto(impianto_id=x.id, tipo=el["tipo"], quadro=el["quadro"], nome=el["nome"], occorrenza=el["occorrenza"])
            s.add(e)
        e.attributi, e.attivo, e.dal_verbale, e.aggiornato_il = json.dumps(el["attributi"], ensure_ascii=False), True, numero, adesso()
    # Un campionamento parziale non dimostra la rimozione degli altri elementi.
    for el in letto.get("elementi_ritirati", []):
        chiave = (el["tipo"], el["quadro"], el["nome"], el["occorrenza"])
        if chiave in esistenti:
            esistenti[chiave].attivo = False
    _modificato(x, attore)
    dopo = anagrafica.dati_impianto(x)
    registro.scrivi(s, utente=attore, azione="impianto.da_verbale", oggetto_tipo="impianto", oggetto_id=x.id,
                    descrizione=f"Impianto n. {x.id} aggiornato dal verbale {numero} (caratteristiche tecniche ed elementi: {len(visti)})",
                    dettagli={"modifiche": registro.differenze(prima, dopo)})
    return avvisi


def carica_verbale(s: Session, cfg: Any, attore: Any, verifica_id: int, docx: bytes, nome_docx: str, pdf: bytes | None, nome_pdf: str,
                   versione: Any, letto: dict | None = None, scheda: bool = True) -> Verifica:
    """Il verbale emesso (Word di VerbalizzAI, più l'eventuale PDF) rende la verifica «eseguita» (D63).

    `letto`: i dati già pronti del verbale compilato nel gestionale (0.6.0): si usano quelli, esatti, invece di rileggere il Word."""
    v = verifica_o_404(s, verifica_id)
    controlla_versione(v, versione)
    _richiedi_esecutore(attore, v)
    richiedi_indipendenza(v)
    if v.stato != "registrata":
        raise ErroreUtente("Il verbale si carica su una verifica registrata (con il numero del verbale).")
    if not docx:
        raise ErroreUtente("Carica il verbale in Word (.docx) emesso con VerbalizzAI.")
    if len(docx) > 25 * 1024 * 1024:
        raise ErroreUtente("Il Word supera il limite di 25 MB.")
    if letto is None:
        letto = lettura_verbale.leggi(docx, nome_docx or "verbale.docx")
    x = s.get(Impianto, v.impianto_id)
    atteso = MODULO_PER_TIPOLOGIA.get(x.tipologia, "")
    if letto["modulo"] != atteso:
        raise ErroreUtente(f"Il verbale è un {letto['modulo']}, ma l'impianto n. {x.id} è «{TIPOLOGIE_IMPIANTO.get(x.tipologia, x.tipologia)}» "
                           f"(serve un {atteso}). Controlla di aver scelto il file giusto.")
    if letto["numero"] != v.codice_verbale:
        raise ErroreUtente(f"Il numero scritto nel verbale ({letto['numero_scritto'] or 'assente'}) non è quello registrato per questa verifica "
                           f"({v.codice_verbale}): correggilo in VerbalizzAI e riemetti il verbale, oppure scegli il file giusto.")
    limite = 25 * 1024 * 1024
    if len(docx) > limite:
        raise ErroreUtente("Il Word supera il limite di 25 MB.")
    generato = pdf is None
    if generato:
        from ...core import pdf as convertitore
        pdf = convertitore.da_word(docx, cfg.libreoffice)
        nome_pdf = nome_docx.rsplit(".", 1)[0] + ".pdf"
    origine = "generato da LibreOffice" if generato else "allegato"
    if len(pdf) > limite:
        raise ErroreUtente(f"Il PDF {origine} supera il limite di 25 MB ({len(pdf) / 1024 / 1024:.1f} MB).")
    if not pdf.startswith(b"%PDF-"):
        raise ErroreUtente(f"Il PDF {origine} non ha un formato PDF valido. Controlla il file o la conversione.")
    from pypdf import PdfReader
    from pypdf.errors import PdfReadError
    import io
    try:
        documento_pdf = PdfReader(io.BytesIO(pdf))
        if documento_pdf.is_encrypted or not len(documento_pdf.pages):
            raise ValueError("PDF protetto o privo di pagine")
    except (PdfReadError, ValueError, KeyError, TypeError):
        raise ErroreUtente(f"Il PDF {origine} non ha un formato PDF valido: è illeggibile, incompleto o protetto.") from None
    avvisi = list(letto["avvisi"])
    if letto["data"] and letto["data"] != v.data_esecuzione:
        avvisi.append(f"Data del verbale {formatta_data(letto['data'])} diversa dalla data di esecuzione registrata {formatta_data(v.data_esecuzione)}.")
    if letto["tipo"] and letto["tipo"] != v.tipo_verifica:
        avvisi.append(f"Il verbale è di verifica {letto['tipo']}, la riga del preventivo era {v.tipo_verifica}.")
    if not letto["esito"]:
        avvisi.append("Esito non letto dal verbale: controllalo.")
    prima = _stato(v)
    if letto.get("data_inizio"):
        v.data_esecuzione = letto["data_inizio"]
    v.modulo, v.esito = letto["modulo"], letto["esito"]
    periodicita = 2 if x.tipologia == "esplosione" else (letto["periodicita"] or x.periodicita_anni)
    v.prossima_verifica = None if v.tipo_verifica == "straordinaria" else (letto["prossima"] or (scadenza(v.data_esecuzione, periodicita) if periodicita else None))
    if v.tipo_verifica != "straordinaria" and letto["prossima"] is None:
        avvisi.append("Prossima verifica non letta dal verbale: calcolata da data di esecuzione e periodicità.")
    # documenti: i caricamenti precedenti restano, «non in uso»
    for d in s.execute(select(DocumentoVerifica).where(DocumentoVerifica.verifica_id == v.id, DocumentoVerifica.in_uso.is_(True))).scalars():
        d.in_uso = False
    for formato, contenuto, nome, tipo in (("docx", docx, nome_docx, DOCX), ("pdf", pdf, nome_pdf, "application/pdf")):
        if not contenuto:
            continue
        nome = (nome or f"{v.codice_verbale.replace('/', '_')}.{formato}")[:200]
        doc = documenti.salva(s, cfg.cartella_documenti, contenuto, nome, tipo, getattr(attore, "id", None), f"Verbale {v.codice_verbale}")
        s.add(DocumentoVerifica(verifica_id=v.id, formato=formato, documento_id=doc.id, nome_file=nome, creato_da=getattr(attore, "nome", "")))
    avvisi += _aggiorna_impianto(s, attore, v, letto, scheda=scheda)
    letto_json = {k: (val.isoformat() if isinstance(val, date) else val) for k, val in letto.items() if k != "elementi"}
    letto_json["n_elementi"] = len(letto["elementi"])
    v.dati_verbale = json.dumps(letto_json, ensure_ascii=False)
    v.avvisi_verbale = "\n".join(avvisi)
    v.stato, v.eseguita_il, v.caricata_da = "eseguita", adesso(), getattr(attore, "nome", "")
    v.riesame_esito, v.riesame_note = "", ""
    s.flush()
    _scrivi(s, attore, v, "verifica.verbale", f"Verifica n. {v.id}: caricato il verbale {v.codice_verbale} (esito {ESITI.get(v.esito, 'non letto')})",
            prima, avvisi=avvisi)
    return v


def riesame(s: Session, attore: Any, verifica_id: int, dati: dict) -> Verifica:
    """RT: riesame del verbale prima della fatturazione (D64). Non conforme → torna «registrata» per ricaricare il verbale corretto."""
    v = verifica_o_404(s, verifica_id)
    if getattr(attore, "id", None) == v.verificatore_id:
        raise PermessoNegato("Non puoi riesaminare il tuo verbale: serve un altro responsabile tecnico abilitato.")
    controlla_versione(v, dati.get("versione"))
    if v.stato != "eseguita":
        raise ErroreUtente("Il riesame si fa su una verifica eseguita (verbale emesso).")
    esito = str(dati.get("esito") or "")
    if esito not in ESITI_RIESAME:
        raise ErroreUtente("Scegli l'esito del riesame.")
    note = str(dati.get("note") or "").strip()[:4000]
    if esito == "non_conforme" and not note:
        raise ErroreUtente("Riesame non conforme: scrivi cosa va corretto nel verbale.")
    prima = _stato(v)
    v.riesame_esito, v.riesame_note, v.riesame_il, v.riesame_da = esito, note, adesso(), getattr(attore, "nome", "")
    doc = s.scalar(select(DocumentoVerifica).where(DocumentoVerifica.verifica_id == v.id,
                   DocumentoVerifica.in_uso.is_(True), DocumentoVerifica.formato == "pdf").order_by(DocumentoVerifica.id.desc()).limit(1))
    s.add(RiesameVerifica(verifica_id=v.id, documento_id=doc.documento_id if doc else None,
                         verbale_id=v.verbale_id, esito=esito, note=note, eseguito_il=v.riesame_il, eseguito_da=v.riesame_da))
    v.stato = "riesaminata" if esito == "conforme" else "registrata"
    _scrivi(s, attore, v, "verifica.riesame", f"Riesame del verbale {v.codice_verbale}: {ESITI_RIESAME[esito]}"
            + ("" if esito == "conforme" else " → da ricaricare corretto"), prima, note=note)
    return v


def annulla(s: Session, attore: Any, verifica_id: int, dati: dict) -> Verifica:
    """Prima dell'esecuzione, con motivo; il numero del verbale eventualmente preso resta usato (non si riassegna)."""
    v = verifica_o_404(s, verifica_id)
    controlla_versione(v, dati.get("versione"))
    motivo = str(dati.get("motivo") or "").strip()[:500]
    if not motivo:
        raise ErroreUtente("Scrivi il motivo dell'annullamento.")
    if v.stato not in APERTE:
        raise ErroreUtente(f"La verifica è «{STATI[v.stato]}»: non si annulla.")
    prima = _stato(v)
    v.stato, v.motivo_annullamento = "annullata", motivo
    _scrivi(s, attore, v, "verifica.annulla", f"Annullata la verifica n. {v.id}" + (f" (verbale {v.codice_verbale} non usato)" if v.codice_verbale else "")
            + f": {motivo}", prima)
    return v


def note(s: Session, attore: Any, verifica_id: int, dati: dict) -> Verifica:
    v = verifica_o_404(s, verifica_id)
    controlla_versione(v, dati.get("versione"))
    prima = _stato(v)
    v.note = _t(dati, "note", 4000)
    _scrivi(s, attore, v, "verifica.note", f"Note della verifica n. {v.id} modificate", prima)
    return v


def elementi_impianto(s: Session, impianto_id: int) -> list[dict]:
    return [{"tipo": e.tipo, "tipo_testo": TIPI_ELEMENTO.get(e.tipo, e.tipo), "quadro": e.quadro, "nome": e.nome, "occorrenza": e.occorrenza,
             "attributi": json.loads(e.attributi or "{}"), "attivo": e.attivo, "dal_verbale": e.dal_verbale}
            for e in s.execute(select(ElementoImpianto).where(ElementoImpianto.impianto_id == impianto_id)
                               .order_by(ElementoImpianto.attivo.desc(), ElementoImpianto.quadro, ElementoImpianto.tipo, ElementoImpianto.id)).scalars()]


def verifiche_impianto(s: Session, impianto_id: int) -> list[dict]:
    return [{"id": v.id, "stato": v.stato, "stato_testo": STATI[v.stato], "codice_verbale": v.codice_verbale,
             "data_esecuzione": v.data_esecuzione.isoformat() if v.data_esecuzione else None, "esito_testo": ESITI.get(v.esito, "")}
            for v in s.execute(select(Verifica).where(Verifica.impianto_id == impianto_id).order_by(Verifica.id.desc())).scalars()]


def documento(s: Session, cfg: Any, verifica_id: int, documento_id: int) -> tuple[Any, bytes]:
    d = s.execute(select(DocumentoVerifica).where(DocumentoVerifica.verifica_id == verifica_id, DocumentoVerifica.documento_id == documento_id)).scalar()
    if d is None:
        raise NonTrovato("Documento non trovato per questa verifica.")
    return documenti.leggi(s, cfg.cartella_documenti, documento_id)



def indipendenza(s, attore, verifica_id, dati):
    v = verifica_o_404(s, verifica_id)
    controlla_versione(v, dati.get("versione"))
    prima = _stato(v)
    descrizione = dichiara_indipendenza(attore, v, dati.get("indipendenza"))
    _scrivi(s, attore, v, "verifica.indipendenza", f"Verifica n. {v.id}: {descrizione}", prima)
    return v

def sospendi(s, attore, verifica_id, dati):
    v = verifica_o_404(s, verifica_id)
    controlla_versione(v, dati.get("versione")); _richiedi_esecutore(attore, v)
    motivo = str(dati.get("motivo", "")).strip()[:500]
    if v.stato not in ("assegnata", "programmata", "registrata") or not motivo:
        raise ErroreUtente("Sospendi una verifica assegnata, programmata o registrata, indicando il motivo.")
    prima = _stato(v); v.stato_prima_sospensione = v.stato; v.stato = "sospesa"; v.motivo_sospensione = motivo
    _scrivi(s, attore, v, "verifica.sospesa", "Verifica sospesa: " + motivo, prima)
    return v

def riprendi(s, attore, verifica_id, dati):
    v = verifica_o_404(s, verifica_id)
    controlla_versione(v, dati.get("versione")); _richiedi_esecutore(attore, v)
    if v.stato != "sospesa":
        raise ErroreUtente("La verifica non è sospesa.")
    prima = _stato(v); v.stato = v.stato_prima_sospensione
    _scrivi(s, attore, v, "verifica.ripresa", "Ripresa dello stesso incarico e numero di verbale", prima)
    return v
