"""Interfaccia JSON delle verifiche (fase 5)."""

from __future__ import annotations

import logging
from urllib.parse import quote

from fastapi import APIRouter, Body, Depends, File, Form, UploadFile
from fastapi.responses import Response

from ...core.db import Archivio
from ...core.errori import PermessoNegato
from ...web.dipendenze import archivio, richiede, utente
from ..utenti.accesso import UtenteCorrente
from . import servizio
from .modelli import ESITI, ESITI_RIESAME, STATI

router = APIRouter(prefix="/api")
PROPRIE = "verifiche.vedere_proprie"


def _json(arc: Archivio, u: UtenteCorrente, verifica_id: int) -> dict:
    with arc.lettura() as s:
        v = servizio.verifica_o_404(s, verifica_id)
        if not servizio.puo_vedere(u, v):
            raise PermessoNegato("Questa verifica è assegnata a un altro verificatore.")
        return servizio.verifica_json(s, v)


@router.get("/verifiche/valori")
def valori(_u: UtenteCorrente = Depends(richiede(PROPRIE, "DPR")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        return {"stati": STATI, "esiti": ESITI, "esiti_riesame": ESITI_RIESAME, "verificatori": servizio.verificatori(s)}


@router.get("/verifiche/{verifica_id}")
def leggi(verifica_id: int, u: UtenteCorrente = Depends(richiede(PROPRIE, "DPR")), arc: Archivio = Depends(archivio)) -> dict:
    return _json(arc, u, verifica_id)


@router.post("/verifiche/assegna-in-blocco")
def assegna_in_blocco(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("verifiche.assegna", "DPR")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.assegna_in_blocco(s, u.come_attore(), dati.get("verifiche") or [], dati.get("verificatore_id"))


@router.post("/verifiche/{verifica_id}/assegna")
def assegna(verifica_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("verifiche.assegna", "DPR")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        servizio.assegna(s, u.come_attore(), verifica_id, dati)
    return _json(arc, u, verifica_id)


@router.post("/verifiche/{verifica_id}/programma")
def programma(verifica_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        servizio.programma(s, u, verifica_id, dati)
    return _json(arc, u, verifica_id)


@router.post("/verifiche/{verifica_id}/registra")
def registra(verifica_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        servizio.registra(s, u, verifica_id, dati)
    return _json(arc, u, verifica_id)


@router.post("/verifiche/{verifica_id}/verbale")
async def carica_verbale(verifica_id: int, word: UploadFile = File(...), pdf_file: UploadFile | None = File(None), versione: str = Form(""),
                         u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    docx = await word.read(25 * 1024 * 1024 + 1)
    pdf = await pdf_file.read(25 * 1024 * 1024 + 1) if pdf_file is not None else None
    with arc.scrittura() as s:
        v = servizio.carica_verbale(s, arc.cfg, u, verifica_id, docx, word.filename or "", pdf,
                                    (pdf_file.filename if pdf_file is not None else "") or "", versione or None)
        impianto_id = v.impianto_id
    note = []
    if getattr(arc, "verbali", None) is not None:
        # R122: il Word entra anche nell'archivio dei verbali e aggiorna la scheda tecnica unica (quella di VerbalizzAI),
        # così la bozza della verifica successiva riparte da qui.
        from starlette.concurrency import run_in_threadpool

        from ..verbali import scheda

        try:
            note = await run_in_threadpool(scheda.adotta_word, arc.verbali, arc, u, impianto_id, docx, word.filename or "verbale.docx")
        except Exception:  # il verbale è caricato; la scheda resta quella del Word (copia del gestionale)
            logging.getLogger(__name__).exception("Scheda tecnica non aggiornata in VerbalizzAI dopo il caricamento del verbale")
            note = ["Il verbale è caricato, ma non è entrato nell'archivio dei verbali (vedi il file di log): la bozza successiva non ripartirà da qui."]
    risposta = _json(arc, u, verifica_id)
    if note:
        risposta["note_scheda"] = note
    return risposta


@router.post("/verifiche/{verifica_id}/riesame")
def riesame(verifica_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("verifiche.riesame", "DPR")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        servizio.riesame(s, u.come_attore(), verifica_id, dati)
    return _json(arc, u, verifica_id)


@router.post("/verifiche/{verifica_id}/annulla")
def annulla(verifica_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("verifiche.annulla", "DPR")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        servizio.annulla(s, u.come_attore(), verifica_id, dati)
    return _json(arc, u, verifica_id)


@router.put("/verifiche/{verifica_id}/note")
def note(verifica_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede(PROPRIE, "DPR")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        v = servizio.verifica_o_404(s, verifica_id)
        if not servizio.puo_vedere(u, v):
            raise PermessoNegato("Questa verifica è assegnata a un altro verificatore.")
        servizio.note(s, u.come_attore(), verifica_id, dati)
    return _json(arc, u, verifica_id)


@router.get("/verifiche/{verifica_id}/documenti/{documento_id}")
def scarica(verifica_id: int, documento_id: int, in_linea: bool = False, u: UtenteCorrente = Depends(richiede(PROPRIE, "DPR")),
            arc: Archivio = Depends(archivio)) -> Response:
    with arc.lettura() as s:
        v = servizio.verifica_o_404(s, verifica_id)
        if not servizio.puo_vedere(u, v):
            raise PermessoNegato("Questa verifica è assegnata a un altro verificatore.")
        doc, contenuto = servizio.documento(s, arc.cfg, verifica_id, documento_id)
    modo = "inline" if in_linea and doc.tipo_mime == "application/pdf" else "attachment"
    return Response(contenuto, media_type=doc.tipo_mime, headers={"Content-Disposition": f"{modo}; filename*=UTF-8''{quote(doc.nome_originale)}"})


@router.get("/impianti/{impianto_id}/verifiche")
def dell_impianto(impianto_id: int, u: UtenteCorrente = Depends(richiede("anagrafica.vedere")), arc: Archivio = Depends(archivio)) -> dict:
    """Scheda dell'impianto: verifiche, caratteristiche tecniche ed elementi provati dall'ultimo verbale (G39)."""
    with arc.lettura() as s:
        return {"verifiche": servizio.verifiche_impianto(s, impianto_id) if u.puo(PROPRIE, "DPR") else [],
                "elementi": servizio.elementi_impianto(s, impianto_id)}


@router.post("/verifiche/{verifica_id}/indipendenza")
def indipendenza(verifica_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        servizio.indipendenza(s, u, verifica_id, dati)
    return _json(arc, u, verifica_id)


@router.post("/verifiche/{verifica_id}/sospendi")
def sospendi(verifica_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        servizio.sospendi(s, u, verifica_id, dati)
    return _json(arc, u, verifica_id)


@router.post("/verifiche/{verifica_id}/riprendi")
def riprendi(verifica_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        servizio.riprendi(s, u, verifica_id, dati)
    return _json(arc, u, verifica_id)
