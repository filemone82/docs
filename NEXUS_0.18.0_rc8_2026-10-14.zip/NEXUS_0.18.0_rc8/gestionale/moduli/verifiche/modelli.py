"""Verifiche (fase 5; documento 10 § B.4–B.5 e § B.10; decisioni D61–D64).

Percorso (indicazioni di Federico del 05/10/2026):
  da assegnare → assegnata (il RT sceglie il verificatore) → programmata (facoltativo: data prevista) →
  registrata (prende il NUMERO DEL VERBALE e fissa la data di esecuzione) → eseguita (solo caricando il verbale) →
  riesaminata (riesame del verbale da parte del RT, poi fatturazione) — oppure annullata (con motivo).
- Nessuna verifica senza preventivo: nasce da una riga accettata dopo il riesame del contratto conforme.
- Numero del verbale annuale, un solo sezionale per VP (periodica) e VS (straordinaria): VP/001/26, VS/002/26…
- Il verbale (Word emesso da VerbalizzAI) si legge con le parti di VerbalizzAI copiate in `gestionale/terzi`;
  all'esecuzione aggiorna l'impianto (ultima e prossima verifica, caratteristiche tecniche, elementi).
"""

from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, ForeignKey, Index, Integer, String, Text, UniqueConstraint, text
from sqlalchemy.orm import Mapped, mapped_column

from ...core.db import Base, adesso
from ...core.modelli_comuni import Tracciato

STATI = {
    "da_assegnare": "Da assegnare",
    "assegnata": "Assegnata",
    "programmata": "Programmata",
    "registrata": "Registrata",
    "eseguita": "Eseguita (verbale emesso)",
    "riesaminata": "Riesaminata (da fatturare)",
    "sospesa": "Sospesa",
    "annullata": "Annullata",
}
ESITI = {"positivo": "Positivo", "negativo": "Negativo"}
ESITI_RIESAME = {"conforme": "Conforme", "non_conforme": "Non conforme"}
# Modulo del verbale di VerbalizzAI per tipologia d'impianto (documento 10 § B.3)
MODULO_PER_TIPOLOGIA = {"terra_bt": "M01", "terra_at": "M01", "scariche": "M02", "esplosione": "M03"}
TIPI_ELEMENTO = {"rcd": "Differenziale", "overcurrent": "Protezione da sovracorrenti", "continuity": "Prova di continuità"}


def _in(campo: str, valori) -> str:  # noqa: ANN001
    return f"{campo} IN ({', '.join(repr(v) for v in valori)})"


class Verifica(Base, Tracciato):
    __tablename__ = "verifiche"
    __table_args__ = (
        UniqueConstraint("anno", "numero", name="uq_verifiche_numero_verbale"),
        CheckConstraint(_in("stato", STATI), name="stato"),
        # 0.12.8 (R124): una sola verifica non annullata per riga; dopo una revoca e una nuova accettazione ne nasce un'altra
        Index("uq_verifiche_riga_attiva", "riga_id", unique=True, sqlite_where=text("stato != 'annullata'"),
              postgresql_where=text("stato != 'annullata'")),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    riga_id: Mapped[int] = mapped_column(ForeignKey("preventivi_righe.id", ondelete="RESTRICT"), index=True)
    preventivo_id: Mapped[int] = mapped_column(ForeignKey("preventivi.id", ondelete="RESTRICT"), index=True)
    impianto_id: Mapped[int] = mapped_column(ForeignKey("impianti.id", ondelete="RESTRICT"), index=True)
    tipo_verifica: Mapped[str] = mapped_column(String(20), default="periodica")
    stato: Mapped[str] = mapped_column(String(20), default="da_assegnare", index=True)
    # assegnazione (RT) e programmazione (verificatore)
    verificatore_id: Mapped[int | None] = mapped_column(ForeignKey("utenti.id", ondelete="RESTRICT"), nullable=True, index=True)
    assegnata_il: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    assegnata_da: Mapped[str] = mapped_column(String(120), default="")
    data_programmata: Mapped[date | None] = mapped_column(Date, nullable=True)
    # registrazione: numero del verbale (annuale, un solo sezionale VP/VS) e data di esecuzione
    anno: Mapped[int | None] = mapped_column(Integer, nullable=True)
    numero: Mapped[int | None] = mapped_column(Integer, nullable=True)
    codice_verbale: Mapped[str] = mapped_column(String(20), default="", index=True)
    verbale_id: Mapped[str] = mapped_column(String(40), default="", server_default="", index=True)  # verbale compilato nel gestionale (0.5.0)
    data_esecuzione: Mapped[date | None] = mapped_column(Date, nullable=True)
    registrata_il: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    registrata_da: Mapped[str] = mapped_column(String(120), default="")
    # esecuzione: dati letti dal verbale caricato
    modulo: Mapped[str] = mapped_column(String(5), default="")
    esito: Mapped[str] = mapped_column(String(20), default="")
    prossima_verifica: Mapped[date | None] = mapped_column(Date, nullable=True)
    dati_verbale: Mapped[str] = mapped_column(Text, default="")        # JSON: letture del verbale (fotografia)
    avvisi_verbale: Mapped[str] = mapped_column(Text, default="")
    eseguita_il: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    caricata_da: Mapped[str] = mapped_column(String(120), default="")
    # riesame del verbale (RT), prima della fatturazione
    riesame_esito: Mapped[str] = mapped_column(String(20), default="")
    riesame_note: Mapped[str] = mapped_column(Text, default="")
    riesame_il: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    riesame_da: Mapped[str] = mapped_column(String(120), default="")
    indipendenza: Mapped[bool] = mapped_column(Boolean, default=True, server_default="1")
    # R119: chi ha dichiarato di NON essere indipendente, quando (la verifica è tornata da assegnare)
    indipendenza_esclusa: Mapped[str] = mapped_column(Text, default="", server_default="")
    stato_prima_sospensione: Mapped[str] = mapped_column(String(20), default="", server_default="")
    motivo_sospensione: Mapped[str] = mapped_column(String(500), default="", server_default="")
    motivo_annullamento: Mapped[str] = mapped_column(String(500), default="")
    note: Mapped[str] = mapped_column(Text, default="")


class DocumentoVerifica(Base):
    """Verbali caricati (Word ed eventuale PDF), anche quelli sostituiti dopo un riesame non conforme."""

    __tablename__ = "verifiche_documenti"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    verifica_id: Mapped[int] = mapped_column(ForeignKey("verifiche.id", ondelete="RESTRICT"), index=True)
    formato: Mapped[str] = mapped_column(String(10))                     # docx | pdf
    documento_id: Mapped[int] = mapped_column(ForeignKey("documenti.id", ondelete="RESTRICT"))
    nome_file: Mapped[str] = mapped_column(String(255))
    in_uso: Mapped[bool] = mapped_column(Boolean, default=True)          # False = sostituito da un caricamento successivo
    creato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    creato_da: Mapped[str] = mapped_column(String(120), default="")


class ElementoImpianto(Base):
    """Elementi provati dell'impianto (quadri, differenziali, protezioni, punti di continuità), dall'ultimo verbale (G39)."""

    __tablename__ = "impianti_elementi"
    __table_args__ = (UniqueConstraint("impianto_id", "tipo", "quadro", "nome", "occorrenza"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    impianto_id: Mapped[int] = mapped_column(ForeignKey("impianti.id", ondelete="CASCADE"), index=True)
    tipo: Mapped[str] = mapped_column(String(20))
    quadro: Mapped[str] = mapped_column(String(200), default="")
    nome: Mapped[str] = mapped_column(String(300), default="")
    occorrenza: Mapped[int] = mapped_column(Integer, default=1)
    attributi: Mapped[str] = mapped_column(Text, default="{}")           # JSON (marca/modello, Idn, In…)
    attivo: Mapped[bool] = mapped_column(Boolean, default=True)          # False = non più presente nell'ultimo verbale
    dal_verbale: Mapped[str] = mapped_column(String(20), default="")
    aggiornato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)


class RiesameVerifica(Base):
    """Storico permanente, riferito al documento realmente riesaminato."""
    __tablename__ = "verifiche_riesami"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    verifica_id: Mapped[int] = mapped_column(ForeignKey("verifiche.id", ondelete="RESTRICT"), index=True)
    documento_id: Mapped[int | None] = mapped_column(ForeignKey("documenti.id", ondelete="RESTRICT"), nullable=True)
    verbale_id: Mapped[str] = mapped_column(String(40), default="")
    esito: Mapped[str] = mapped_column(String(20))
    note: Mapped[str] = mapped_column(Text, default="")
    eseguito_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    eseguito_da: Mapped[str] = mapped_column(String(120), default="")
