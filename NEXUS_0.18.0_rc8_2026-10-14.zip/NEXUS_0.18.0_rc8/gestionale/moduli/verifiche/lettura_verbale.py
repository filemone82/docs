"""Lettura del verbale Word emesso con VerbalizzAI (documento 10 § B.10).

Usa le parti di VerbalizzAI copiate in `gestionale/terzi/verbalizzai` (stessa lettura dei Word che fa VerbalizzAI),
e ne ricava solo ciò che serve al gestionale: modulo, numero e data, esito, prossima verifica, periodicità,
caratteristiche tecniche dell'impianto (le voci che VerbalizzAI ripropone alla verifica successiva) ed elementi provati.
"""

from __future__ import annotations

import io
import re
import zipfile
from datetime import date, datetime

from ...core.errori import ErroreUtente

# Caratteristiche dell'impianto del modulo M01 (messa a terra): campi del verbale e gruppi di caselle
CAMPI_M01 = [("installation_year", "Anno di installazione"), ("power", "Potenzialità"), ("voltage", "Tensione di esercizio (V)"),
             ("pod", "POD"), ("cabins", "Cabine MT (n.)"), ("stations", "Stazioni AT (n.)"), ("if_value", "Corrente di guasto AT"),
             ("tf", "Tempo di intervento (s)"), ("disperser_description", "Sistema disperdente"), ("connections_description", "Connessioni"),
             ("conductors_description", "Conduttori di terra e di protezione"), ("medical_group", "Locali medici: gruppo")]
GRUPPI_M01 = [("environment", "Ambiente"), ("systems", "Sistema di distribuzione"), ("supply", "Alimentazione"),
              ("protections", "Dispositivi di protezione"), ("earth_types", "Dispersore"), ("dico", "Dichiarazione di conformità"),
              ("project", "Progetto"), ("diri", "Dichiarazione di rispondenza"), ("period", "Periodicità")]
CAMPI_ALTRI = {"description": "Descrizione dell'impianto", "environments": "Ambienti"}
ESCLUSI = {"client_name", "site_name", "address", "label", "complete_inventory", "if_unit"}


def _controlla_docx(contenuto: bytes) -> None:
    if len(contenuto) > 25 * 1024 * 1024:
        raise ErroreUtente("Il verbale Word è troppo grande (massimo 25 MB).")
    try:
        z = zipfile.ZipFile(io.BytesIO(contenuto))
    except zipfile.BadZipFile:
        raise ErroreUtente("Il file non è un documento Word .docx valido.") from None
    if "word/document.xml" not in z.namelist():
        raise ErroreUtente("Il file non è un verbale Word .docx (il vecchio formato .doc non è supportato).")
    if sum(i.file_size for i in z.infolist()) > 150 * 1024 * 1024:
        raise ErroreUtente("Il verbale Word è troppo esteso.")
    for nome in z.namelist():
        if nome.endswith(".xml"):
            testa = z.read(nome)[:4096]
            if b"<!DOCTYPE" in testa or b"<!ENTITY" in testa:
                raise ErroreUtente("Il verbale Word contiene parti non ammesse.")


def _data(testo: str) -> date | None:
    m = re.search(r"(\d{2})/(\d{2})/(\d{4})", testo or "")
    if not m:
        return None
    try:
        return date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
    except ValueError:
        return None


def numero_normalizzato(testo: str) -> str:
    """«VP/168/26/», « vp / 168 / 26 » → «VP/168/26»."""
    t = re.sub(r"\s+", "", (testo or "").upper()).rstrip("/")
    m = re.fullmatch(r"(V[PS])/0*(\d{1,4})/(\d{2})", t)
    return f"{m.group(1)}/{int(m.group(2)):03d}/{m.group(3)}" if m else t


def _scelte(flags: dict, gruppo: str, opzioni: list[str], etichette: list[str]) -> str:
    valori = flags.get(gruppo) or {}
    return ", ".join(e for o, e in zip(opzioni, etichette) if valori.get(o))


def leggi(contenuto: bytes, nome_file: str = "verbale.docx") -> dict:
    """Restituisce i dati del verbale; solleva ErroreUtente se il Word non è leggibile."""
    from ...terzi.verbalizzai import wordio

    _controlla_docx(contenuto)
    try:
        d = wordio.parse_word(contenuto, nome_file)
    except Exception as e:  # noqa: BLE001 (qualunque problema di lettura diventa un messaggio comprensibile)
        raise ErroreUtente(f"Il verbale non si riesce a leggere ({e}). È un verbale M01, M02 o M03 emesso con VerbalizzAI?") from None
    return da_dati(d)


def da_dati(d: dict) -> dict:
    """Stessa lettura, dai dati di un verbale di VerbalizzAI (Word letto o verbale compilato nel programma; 0.5.0)."""
    from ...terzi.verbalizzai import forms, wordio

    modulo = d.get("module") or "M01"
    h, flags, impianto = d.get("header") or {}, d.get("flags") or {}, d.get("plant") or {}
    voci: list[dict] = []
    if modulo == "M01":
        for chiave, etichetta in CAMPI_M01:
            valore = str(impianto.get(chiave) or "").strip()
            if chiave == "if_value" and valore and valore != "/":
                valore += " " + (impianto.get("if_unit") or "A")
            if valore and valore != "/":
                voci.append({"etichetta": etichetta, "valore": valore})
        for gruppo, etichetta in GRUPPI_M01:
            testo = _scelte(flags, gruppo, wordio.GROUPS.get(gruppo, []), wordio.LABELS.get(gruppo, []))
            if testo:
                voci.append({"etichetta": etichetta, "valore": testo})
    else:
        for chiave, valore in impianto.items():
            if chiave in ESCLUSI or isinstance(valore, bool) or not str(valore or "").strip():
                continue
            voci.append({"etichetta": CAMPI_ALTRI.get(chiave, chiave), "valore": str(valore).strip()})
        for chiave, _ancora, opzioni, etichette, _multipla, tipo, _scheda in forms.FORMS[modulo]["groups"]:
            if tipo != "struct" or chiave == "check_type":
                continue
            testo = _scelte(flags, chiave, opzioni, etichette)
            if testo:
                voci.append({"etichetta": etichette_gruppo(modulo, chiave), "valore": testo})
    esito_flag = flags.get("outcome") or {}
    esito = "positivo" if esito_flag.get("positive") else "negativo" if esito_flag.get("negative") else ""
    periodo = flags.get("period") or {}
    periodicita = 2 if periodo.get("two") else 5 if periodo.get("five") else (2 if modulo == "M03" else None)
    tipo = flags.get("check_type") or {}
    elementi = [{"tipo": s.get("kind", ""), "quadro": (s.get("board") or "")[:200], "nome": (s.get("name") or "")[:300],
                 "occorrenza": int(s.get("occurrence") or 1), "attributi": s.get("attributes") or {}}
                for s in d.get("samples") or [] if s.get("kind") and not s.get("retired")]
    avvisi = list((d.get("source_meta") or {}).get("warnings") or [])
    from ...terzi.verbalizzai import plantstate
    return {
        "stato_tecnico": plantstate.extract(d),
        "elementi_ritirati": [{"tipo": s.get("kind", ""), "quadro": s.get("board", ""), "nome": s.get("name", ""), "occorrenza": int(s.get("occurrence") or 1)} for s in d.get("samples", []) if s.get("retired")],
        "modulo": modulo, "numero": numero_normalizzato(h.get("number") or ""), "numero_scritto": h.get("number") or "",
        "data": _data(h.get("report_date") or ""), "data_inizio": _data(h.get("start_date") or ""), "prossima": _data(h.get("due_date") or ""),
        "esito": esito, "periodicita": periodicita, "tipo": "straordinaria" if tipo.get("extra") else "periodica" if tipo.get("periodic") else "",
        "verificatori": h.get("inspectors") or "", "cliente": impianto.get("client_name") or "", "indirizzo": impianto.get("address") or "",
        "pod": str(impianto.get("pod") or "").strip(), "caratteristiche": voci, "elementi": elementi, "avvisi": avvisi,
        "letto_il": datetime.now().isoformat(timespec="seconds"),
    }


def etichette_gruppo(modulo: str, chiave: str) -> str:
    """Titolo leggibile di un gruppo di caselle M02/M03 (dalle sezioni della maschera di VerbalizzAI)."""
    nomi = {"dvr": "Documento di valutazione del rischio", "risk": "Valutazione del rischio", "captators": "Captatori", "downconductors": "Calate",
            "electrode": "Dispersore", "spd_criteria": "Criteri per gli SPD", "spm": "SPM", "period": "Periodicità",
            "atmosphere": "Atmosfera esplosiva", "zones_gas": "Zone (gas, vapori, nebbie)", "zones_dust": "Zone (polveri)",
            "plant_docs": "Documentazione dell'impianto elettrico", "certs": "Certificazioni dei componenti", "risk_method": "Metodo di classificazione",
            "cl_gas": "Check list gas", "cl_dust": "Check list polveri", "environment": "Ambiente"}
    return nomi.get(chiave, chiave)
