"""Griglia delle verifiche, con i dati di impianto, sede, cliente e preventivo (D43)."""

from __future__ import annotations

from sqlalchemy import String, and_, case, cast, false, true
from sqlalchemy.orm import aliased

from ...core.griglia import Colonna, Griglia, registra
from ..anagrafica.griglie import _con_dati_cliente, colonne_cliente, colonne_impianto, colonne_sede, etichetta
from ..anagrafica.modelli import Cliente, Impianto, Sede
from ..preventivi.modelli import TIPI_VERIFICA, Preventivo
from ..utenti.modelli import Utente
from .modelli import ESITI, ESITI_RIESAME, STATI, Verifica

Verificatore = aliased(Utente, name="verificatore")


def _da_fatturare():  # noqa: ANN202
    from ..finanza.da_fatturare import riga_da_fatturare_di
    return case((and_(Verifica.stato == "riesaminata", riga_da_fatturare_di(Verifica.riga_id)), "Sì"), else_="No")


_DA_FATTURARE = _da_fatturare()
PREVENTIVO = case((Preventivo.revisione > 0, Preventivo.codice + " rev. " + cast(Preventivo.revisione, String)), else_=Preventivo.codice)


def _da():  # noqa: ANN202
    return _con_dati_cliente(
        Verifica.__table__.join(Impianto.__table__, Verifica.impianto_id == Impianto.id)
        .join(Sede.__table__, Impianto.sede_id == Sede.id)
        .join(Cliente.__table__, Sede.cliente_id == Cliente.id)
        .join(Preventivo.__table__, Verifica.preventivo_id == Preventivo.id)
        .outerjoin(Verificatore, Verifica.verificatore_id == Verificatore.id))


def _solo_proprie(u):  # noqa: ANN001, ANN202
    """Chi non vede tutte le verifiche vede solo quelle assegnate a sé."""
    if u.puo("verifiche.vedere_tutte", "DPR"):
        return true()
    if u.puo("verifiche.vedere_proprie", "DPR"):
        return Verifica.verificatore_id == u.id
    return false()


registra(Griglia(
    codice="verifiche", titolo="Verifiche", permesso="verifiche.vedere_proprie", da=_da, condizione=_solo_proprie,
    ordine_predefinito=[("id", "desc")],
    colonne=[
        Colonna("id", "N. verifica", "numero", Verifica.id, larghezza=90),
        Colonna("stato", "Stato", "elenco", etichetta(Verifica.stato, STATI), larghezza=170, opzioni=tuple(STATI.values())),
        Colonna("codice_verbale", "Verbale", "testo", Verifica.codice_verbale, larghezza=110),
        Colonna("tipo_verifica", "Tipo", "elenco", etichetta(Verifica.tipo_verifica, TIPI_VERIFICA), larghezza=110, opzioni=tuple(TIPI_VERIFICA.values())),
        Colonna("verificatore", "Verificatore", "testo", Verificatore.nome, larghezza=150),
        Colonna("verificatore_id", "Verificatore (n.)", "numero", Verifica.verificatore_id, visibile=False, larghezza=80),
        Colonna("data_programmata", "Data prevista", "data", Verifica.data_programmata, larghezza=110),
        Colonna("data_esecuzione", "Data di esecuzione", "data", Verifica.data_esecuzione, larghezza=120),
        Colonna("esito", "Esito", "elenco", etichetta(Verifica.esito, ESITI), larghezza=90, opzioni=tuple(ESITI.values())),
        Colonna("prossima_verifica", "Prossima verifica", "data", Verifica.prossima_verifica, larghezza=120),
        Colonna("riesame_esito", "Riesame verbale", "elenco", etichetta(Verifica.riesame_esito, ESITI_RIESAME), visibile=False, larghezza=120,
                opzioni=tuple(ESITI_RIESAME.values())),
        Colonna("da_fatturare", "Da fatturare", "elenco", _DA_FATTURARE, larghezza=100, opzioni=("Sì", "No"),
                descrizione="Verbale emesso, riesame conforme, non ancora fatturata (N6, 0.12.8)"),
        Colonna("riga_id", "Riga del preventivo (n.)", "numero", Verifica.riga_id, visibile=False, larghezza=80),
        Colonna("preventivo", "Preventivo", "testo", PREVENTIVO, larghezza=120),
        Colonna("preventivo_id", "Preventivo (n. interno)", "numero", Verifica.preventivo_id, visibile=False, larghezza=80),
        Colonna("assegnata_il", "Assegnata il", "dataora", Verifica.assegnata_il, visibile=False, larghezza=140),
        Colonna("registrata_il", "Registrata il", "dataora", Verifica.registrata_il, visibile=False, larghezza=140),
        Colonna("eseguita_il", "Verbale caricato il", "dataora", Verifica.eseguita_il, visibile=False, larghezza=140),
        Colonna("note", "Note", "testo", Verifica.note, visibile=False, larghezza=200),
        *[c for c in colonne_impianto(("id", "tipologia"), "impianto_", "Impianto") if not c.calcolata],
        *colonne_sede("sede_", "Sede", visibili=("denominazione", "comune")),
        *colonne_cliente("cliente_", "Cliente", visibili=("ragione_sociale",)),
    ],
))
