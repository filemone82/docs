"""Configurazioni delle griglie salvate da ciascun utente (decisione D18)."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from ...core.db import Base, adesso


class ConfigurazioneGriglia(Base):
    __tablename__ = "configurazioni_griglie"
    __table_args__ = (UniqueConstraint("utente_id", "griglia", "nome", name="uq_configurazioni_griglie_nome"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    utente_id: Mapped[int] = mapped_column(ForeignKey("utenti.id", ondelete="CASCADE"), index=True)
    griglia: Mapped[str] = mapped_column(String(60))
    nome: Mapped[str] = mapped_column(String(80))
    dati: Mapped[str] = mapped_column(Text)  # JSON: colonne visibili e ordine, filtri, ordinamento, raggruppamento
    predefinita: Mapped[bool] = mapped_column(Boolean, default=False)
    aggiornata_il: Mapped[datetime] = mapped_column(DateTime, default=adesso, onupdate=adesso)
