"""Interfaccia comune delle griglie: definizione, dati, esportazione Excel, configurazioni salvate."""

from __future__ import annotations

import json
from datetime import date
from urllib.parse import quote

from fastapi import APIRouter, Body, Depends
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy import select

from ...core import griglia as motore
from ...core.db import Archivio
from ...core.errori import ErroreUtente, NonTrovato, PermessoNegato
from ...web.dipendenze import archivio, utente
from ..registro import servizio as registro
from ..utenti.accesso import UtenteCorrente
from .modelli import ConfigurazioneGriglia

router = APIRouter(prefix="/api/griglie")


def _griglia(codice: str, u: UtenteCorrente) -> motore.Griglia:
    g = motore.REGISTRO_GRIGLIE.get(codice)
    if g is None:
        raise NonTrovato("Elenco sconosciuto: ricarica la pagina.")
    if not u.puo(g.permesso):
        raise PermessoNegato()
    return g


def _controlla_contesto(g, r, s):
    if g.contesto_campo == "preventivo_id":
        from ..preventivi.modelli import Preventivo
        p = s.get(Preventivo, r.contesto)
        att = "DM" if g.codice.endswith("_dm") else "DPR"
        if p is None or p.ambito != att:
            raise NonTrovato("Preventivo non trovato per questa attività.")


@router.get("/{codice}/definizione")
def definizione(codice: str, u: UtenteCorrente = Depends(utente)) -> dict:
    g = _griglia(codice, u)
    return g.per_interfaccia() | {"puo_esportare": u.puo("sistema.esporta")}


@router.post("/{codice}/dati")
def dati(codice: str, richiesta: dict = Body(...), u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    g = _griglia(codice, u)
    r = motore.Richiesta.da_json(g, richiesta)
    with arc.lettura() as s:
        _controlla_contesto(g, r, s)
        return motore.dati(g, s, arc, u, r)


@router.post("/{codice}/esporta")
def esporta(codice: str, richiesta: dict = Body(...), u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> Response:
    g = _griglia(codice, u)
    if not u.puo("sistema.esporta"):
        raise PermessoNegato("Non hai il permesso di esportare in Excel. Chiedi all'amministratore.")
    r = motore.Richiesta.da_json(g, richiesta)
    colonne = [str(c) for c in (richiesta.get("colonne") or [])]
    with arc.lettura() as s:
        _controlla_contesto(g, r, s)
        contenuto, n = motore.esporta(g, s, arc, u, r, colonne)
    with arc.scrittura() as s:
        registro.scrivi(s, utente=u.come_attore(), azione="esporta.excel", oggetto_tipo="griglia", oggetto_id=g.codice,
                        descrizione=f"Esportati in Excel {n} righe di «{g.titolo}» ({motore.descrivi_filtri(g, r)})",
                        dettagli={"colonne": colonne, "filtri": r.filtri, "ricerca": r.ricerca, "righe": n,
                                  "contesto": r.contesto, "raggruppa": r.raggruppa})
    nome = f"{g.titolo} {date.today().strftime('%d-%m-%Y')}.xlsx"
    return Response(contenuto, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(nome)}"})


# ---------------------------------------------------------------- configurazioni salvate


class DatiConfigurazione(BaseModel):
    nome: str = Field(min_length=1, max_length=80)
    dati: dict
    predefinita: bool = False


def _json(c: ConfigurazioneGriglia) -> dict:
    return {"id": c.id, "nome": c.nome, "dati": json.loads(c.dati), "predefinita": c.predefinita}


@router.get("/{codice}/configurazioni")
def elenco_configurazioni(codice: str, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> list[dict]:
    _griglia(codice, u)
    with arc.lettura() as s:
        q = select(ConfigurazioneGriglia).where(ConfigurazioneGriglia.utente_id == u.id, ConfigurazioneGriglia.griglia == codice)
        return [_json(c) for c in s.execute(q.order_by(ConfigurazioneGriglia.nome)).scalars()]


@router.post("/{codice}/configurazioni")
def salva_configurazione(codice: str, dati_cfg: DatiConfigurazione, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    _griglia(codice, u)
    testo = json.dumps(dati_cfg.dati, ensure_ascii=False)
    if len(testo) > 50_000:
        raise ErroreUtente("Configurazione troppo grande.")
    nome = dati_cfg.nome.strip()
    with arc.scrittura() as s:
        q = select(ConfigurazioneGriglia).where(ConfigurazioneGriglia.utente_id == u.id, ConfigurazioneGriglia.griglia == codice)
        tutte = list(s.execute(q).scalars())
        c = next((x for x in tutte if x.nome.lower() == nome.lower()), None)
        if c is None:
            c = ConfigurazioneGriglia(utente_id=u.id, griglia=codice, nome=nome, dati=testo)
            s.add(c)
        c.dati = testo
        if dati_cfg.predefinita:
            for x in tutte:
                x.predefinita = False
        c.predefinita = dati_cfg.predefinita
        s.flush()
        return _json(c)


@router.delete("/{codice}/configurazioni/{cfg_id}")
def elimina_configurazione(codice: str, cfg_id: int, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        c = s.get(ConfigurazioneGriglia, cfg_id)
        if c is None or c.utente_id != u.id or c.griglia != codice:
            raise NonTrovato("Configurazione non trovata.")
        s.delete(c)  # è una preferenza personale, non un dato di lavoro: si può eliminare
    return {"ok": True}
