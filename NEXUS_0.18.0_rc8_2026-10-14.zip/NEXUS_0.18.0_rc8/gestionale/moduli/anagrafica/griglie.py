"""Griglie dell'anagrafica (D18, D33, D43).

D43: ogni griglia mostra TUTTI gli attributi dell'entità e delle entità collegate, ciascuno come colonna
filtrabile, ordinabile ed esportabile (in Sedi i dati del cliente, in Impianti quelli di sede e cliente).
All'inizio sono visibili le colonne più usate; le altre si accendono da «Colonne» e si salvano nelle viste.
"""

from __future__ import annotations

from sqlalchemy import Integer, and_, case, cast, func, literal, select
from sqlalchemy.orm import aliased

from ...core.sql_portabile import oggi_italiano, data_tra_giorni, anno_dopo, giorni_fra, testi_uniti, json_testo
from ...core.griglia import REGISTRO_GRIGLIE, Colonna, Griglia, registra
from ..beni.modelli import Asset
from .ambiti import CAMPI, GRUPPI_DM
from .modelli import (
    FASCE_GABBIA,
    TIPI_CLIENTE,
    TIPOLOGIE_IMPIANTO,
    Cliente,
    Commerciale,
    Comune,
    ElencoValore,
    Impianto,
    ImpiantoPod,
    Sede,
)

Pagamento = aliased(ElencoValore, name="pagamento")
Iva = aliased(ElencoValore, name="iva")


def etichetta(colonna, valori: dict):  # noqa: ANN001, ANN201
    """Mostra l'etichetta al posto del codice (es. «Pubblica amministrazione» invece di «pa»)."""
    return case(valori, value=colonna, else_=colonna)


TIPO_CLIENTE = etichetta(Cliente.tipo, TIPI_CLIENTE)
TIPOLOGIA = etichetta(Impianto.tipologia, TIPOLOGIE_IMPIANTO)
FASCIA = etichetta(Impianto.gabbia_fascia, FASCE_GABBIA)

def percentuale(colonna):  # noqa: ANN001, ANN201
    return colonna / 100.0


def colonne_cliente(prefisso: str = "", titolo: str = "", visibili: tuple[str, ...] = ()) -> list[Colonna]:
    """Tutti gli attributi del cliente. Con il prefisso servono anche nelle griglie di sedi e impianti."""
    t = (titolo + " · ") if titolo else ""
    vis = set(visibili)

    def c(campo, etich, tipo, espr, larghezza=150, **kw):  # noqa: ANN001, ANN202
        return Colonna(prefisso + campo, t + etich, tipo, espr, visibile=campo in vis, larghezza=larghezza, **kw)

    return [
        c("id", "N. cliente", "numero", Cliente.id, 90),
        c("ragione_sociale", "Ragione sociale", "testo", Cliente.ragione_sociale, 260),
        c("tipo", "Tipo cliente", "elenco", TIPO_CLIENTE, 150, opzioni=tuple(TIPI_CLIENTE.values())),
        c("indirizzo", "Indirizzo", "testo", Cliente.indirizzo, 200),
        c("cap", "CAP", "testo", Cliente.cap, 70),
        c("comune", "Comune", "testo", Cliente.comune, 150),
        c("provincia", "Prov.", "testo", Cliente.provincia, 60),
        c("regione", "Regione", "testo", Cliente.regione, 120),
        c("nazione", "Nazione", "testo", Cliente.nazione, 70),
        c("partita_iva", "Partita IVA", "testo", Cliente.partita_iva, 120),
        c("codice_fiscale", "Codice fiscale", "testo", Cliente.codice_fiscale, 150),
        c("email_verbali", "Email verbali", "testo", Cliente.email_verbali, 200),
        c("email_fatture", "Email fatture", "testo", Cliente.email_fatture, 200),
        c("pec", "PEC", "testo", Cliente.pec, 200),
        c("codice_sdi", "Codice SDI", "testo", Cliente.codice_sdi, 90),
        c("riferimento_amministrazione", "Rif. amministrazione", "testo", Cliente.riferimento_amministrazione, 120),
        c("commerciale", "Commerciale AD", "testo", Commerciale.nome, 150),
        c("referente_nome", "Referente", "testo", Cliente.referente_nome, 150),
        c("referente_email", "Email referente", "testo", Cliente.referente_email, 180),
        c("referente_telefono", "Tel. referente", "testo", Cliente.referente_telefono, 120),
        c("banca", "Banca", "testo", Cliente.banca, 150),
        c("iban", "IBAN", "testo", Cliente.iban, 230),
        c("dichiarazione_intento", "Dich. d'intento", "booleano", Cliente.dichiarazione_intento, 100),
        c("dichiarazione_numero", "N. dich. d'intento", "testo", Cliente.dichiarazione_numero, 120),
        c("dichiarazione_data", "Data dich. d'intento", "data", Cliente.dichiarazione_data, 120),
        c("ritenuta_percentuale", "Ritenuta %", "numero", percentuale(Cliente.ritenuta_percentuale), 90),
        c("modalita_pagamento", "Modalità di pagamento", "testo", Pagamento.descrizione, 180),
        c("aliquota_iva", "Aliquota IVA", "testo", Iva.descrizione, 200),
        c("termine_esecuzione", "Termine di esecuzione", "testo", Cliente.termine_esecuzione, 200),
        c("sconto_dm", "Sconto predefinito AD_DM %", "numero", Cliente.sconto_dm / 100.0, 110),
        c("sconti_ammessi", "Sconti ammessi", "booleano", Cliente.sconti_ammessi, 100),
        c("attivo", "Cliente attivo", "booleano", Cliente.attivo, 100),
        c("ambito_dpr", "Cliente AD_DPR", "booleano", Cliente.ambito_dpr, 90),
        c("ambito_dm", "Cliente AD_DM", "booleano", Cliente.ambito_dm, 90),
        c("ambito_iec", "Cliente I&C", "booleano", Cliente.ambito_iec, 90),
        c("note", "Note cliente", "testo", Cliente.note, 200),
        c("avvisi", "Da controllare (cliente)", "testo", Cliente.avvisi, 220),
        c("codice_esterno", "Rif. gestionale attuale (cliente)", "testo", Cliente.codice_esterno, 120),
        c("modificato_il", "Ultima modifica cliente", "dataora", Cliente.modificato_il, 140),
        c("modificato_da", "Modificato da (cliente)", "testo", Cliente.modificato_da, 140),
    ]


def colonne_sede(prefisso: str = "", titolo: str = "", visibili: tuple[str, ...] = ()) -> list[Colonna]:
    t = (titolo + " · ") if titolo else ""
    vis = set(visibili)

    def c(campo, etich, tipo, espr, larghezza=150, **kw):  # noqa: ANN001, ANN202
        # «Sede · Sede operativa» → «Sede operativa»: niente ripetizioni nelle etichette
        etichetta_piena = etich if titolo and etich.lower().startswith(titolo.lower()) else t + etich
        return Colonna(prefisso + campo, etichetta_piena, tipo, espr, visibile=campo in vis, larghezza=larghezza, **kw)

    return [
        c("id", "N. sede", "numero", Sede.id, 80),
        c("denominazione", "Sede operativa", "testo", Sede.denominazione, 280),
        c("indirizzo", "Indirizzo sede", "testo", Sede.indirizzo, 200),
        c("cap", "CAP sede", "testo", Sede.cap, 70),
        c("comune", "Comune sede", "testo", Sede.comune, 150),
        c("provincia", "Prov. sede", "testo", Sede.provincia, 60),
        c("regione", "Regione sede", "testo", Sede.regione, 120),
        c("referente_nome", "Referente sede", "testo", Sede.referente_nome, 150),
        c("referente_email", "Email referente sede", "testo", Sede.referente_email, 180),
        c("referente_telefono", "Tel. referente sede", "testo", Sede.referente_telefono, 120),
        c("email_verbali", "Destinatari verbali sede", "testo", Sede.email_verbali, 200),
        c("email_verbali_cc", "Copia verbali sede", "testo", Sede.email_verbali_cc, 200),
        c("note_accesso", "Note di accesso", "testo", Sede.note_accesso, 200),
        c("attiva", "Sede attiva", "booleano", Sede.attiva, 90),
        c("ambito_dpr", "AD_DPR (dal cliente)", "booleano", Sede.ambito_dpr, 90),
        c("ambito_dm", "AD_DM (dal cliente)", "booleano", Sede.ambito_dm, 90),
        c("ambito_iec", "I&C (dal cliente)", "booleano", Sede.ambito_iec, 90),
        c("note", "Note sede", "testo", Sede.note, 200),
        c("avvisi", "Da controllare (sede)", "testo", Sede.avvisi, 220),
        c("codice_esterno", "Rif. gestionale attuale (sede)", "testo", Sede.codice_esterno, 120),
        c("modificato_il", "Ultima modifica sede", "dataora", Sede.modificato_il, 140),
        c("modificato_da", "Modificata da (sede)", "testo", Sede.modificato_da, 140),
    ]


POD_ELENCO = (select(testi_uniti(ImpiantoPod.pod, ", ")).where(ImpiantoPod.impianto_id == Impianto.id)
              .correlate(Impianto).scalar_subquery())
MATRICOLA = case(
    (and_(Impianto.matricola_anno == "", Impianto.matricola_numero == ""), literal("")),
    else_=Impianto.matricola_anno + "/" + Impianto.matricola_attivita + "/" + Impianto.matricola_numero + "/" + Impianto.matricola_provincia,
)
OGGI = oggi_italiano()
GIORNI_ALLA_SCADENZA = giorni_fra(Impianto.prossima_verifica, OGGI)
STATI_SCADENZA = ("Scaduta", "Entro 30 giorni", "Entro 90 giorni", "Entro 1 anno", "Oltre 1 anno", "Senza data")
STATO_SCADENZA = case(
    (Impianto.prossima_verifica.is_(None), literal("Senza data")),
    (Impianto.prossima_verifica < OGGI, literal("Scaduta")),
    (Impianto.prossima_verifica <= data_tra_giorni(OGGI, 30), literal("Entro 30 giorni")),
    (Impianto.prossima_verifica <= data_tra_giorni(OGGI, 90), literal("Entro 90 giorni")),
    (Impianto.prossima_verifica <= anno_dopo(OGGI), literal("Entro 1 anno")),
    else_=literal("Oltre 1 anno"),
)


def colonne_impianto(visibili: tuple[str, ...], prefisso: str = "", titolo: str = "") -> list[Colonna]:
    vis = set(visibili)
    t = (titolo + " · ") if titolo else ""

    def c(campo, etich, tipo, espr, larghezza=130, **kw):  # noqa: ANN001, ANN202
        return Colonna(prefisso + campo, t + etich, tipo, espr, visibile=campo in vis, larghezza=larghezza, **kw)

    return [
        c("id", "N. impianto", "numero", Impianto.id, 90),
        c("codice_esterno", "Codice gestionale attuale", "testo", Impianto.codice_esterno, 110),
        c("tipologia", "Tipologia", "elenco", TIPOLOGIA, 210, opzioni=tuple(TIPOLOGIE_IMPIANTO.values())),
        c("denominazione", "Denominazione impianto", "testo", Impianto.denominazione, 200),
        c("dismesso", "Dismesso", "booleano", Impianto.dismesso, 90),
        c("matricola", "Matricola INAIL", "testo", MATRICOLA, 150),
        c("matricola_anno", "Matr. anno", "testo", Impianto.matricola_anno, 80),
        c("matricola_attivita", "Matr. cod. attività", "testo", Impianto.matricola_attivita, 90),
        c("matricola_numero", "Matr. numero", "testo", Impianto.matricola_numero, 90),
        c("matricola_provincia", "Matr. provincia", "testo", Impianto.matricola_provincia, 80),
        c("potenza_kw", "Potenza kW", "numero", Impianto.potenza_kw, 100),
        c("cabine_mt_bt", "Cabine MT/BT", "numero", Impianto.cabine_mt_bt, 100),
        c("sottostazioni_at_mt", "Sottostazioni AT/MT", "numero", Impianto.sottostazioni_at_mt, 110),
        c("pod", "POD", "testo", POD_ELENCO, 170),
        c("pod_note", "Note POD", "testo", Impianto.pod_note, 160),
        c("asta", "Aste", "booleano", Impianto.asta, 70),
        c("numero_aste", "N. aste", "numero", Impianto.numero_aste, 80),
        c("gabbia", "Gabbia di Faraday", "booleano", Impianto.gabbia, 100),
        c("gabbia_fascia", "Superficie gabbia", "elenco", FASCIA, 130, opzioni=tuple(FASCE_GABBIA.values())),
        c("gas", "Gas/vapori/nebbie", "booleano", Impianto.gas, 100),
        c("polveri", "Polveri", "booleano", Impianto.polveri, 80),
        c("zone", "Zone", "testo", Impianto.zone, 110),
        c("periodicita_anni", "Periodicità (anni)", "numero", Impianto.periodicita_anni, 100),
        c("ultima_verifica_numero", "Ultimo verbale", "testo", Impianto.ultima_verifica_numero, 110),
        c("ultima_verifica_data", "Ultima verifica", "data", Impianto.ultima_verifica_data, 110),
        c("prossima_verifica", "Prossima verifica", "data", Impianto.prossima_verifica, 120),
        c("prossima_calcolata", "Prossima calcolata", "booleano", Impianto.prossima_calcolata, 100,
          descrizione="Sì = ultima verifica + periodicità; No = data scritta a mano"),
        c("stato_scadenza", "Stato scadenza", "elenco", STATO_SCADENZA, 130, opzioni=STATI_SCADENZA),
        c("giorni", "Giorni alla scadenza", "numero", GIORNI_ALLA_SCADENZA, 110,
          descrizione="Negativo = scaduta da quei giorni"),
        c("tariffa", "Tariffa proposta", "importo", None, 120, calcolata=True,
          descrizione="Calcolata dal tariffario in vigore oggi (vuota se manca un dato dell'impianto)"),
        c("note", "Note impianto", "testo", Impianto.note, 200),
        c("avvisi", "Da controllare (impianto)", "testo", Impianto.avvisi, 220),
        c("modificato_il", "Ultima modifica impianto", "dataora", Impianto.modificato_il, 140),
        c("modificato_da", "Modificato da (impianto)", "testo", Impianto.modificato_da, 140),
    ]


def _arricchisci_tariffa(s, righe: list[dict]) -> None:  # noqa: ANN001
    from sqlalchemy.orm import selectinload

    from ..tariffario import servizio as tariffario

    ids = [r["id"] for r in righe]
    impianti = {x.id: x for x in s.execute(select(Impianto).where(Impianto.id.in_(ids)).options(selectinload(Impianto.pod))).scalars()}
    for r in righe:
        x = impianti.get(r["id"])
        r["tariffa"] = tariffario.calcola(s, x)["totale"] if x is not None else None


N_SEDI = select(func.count(Sede.id)).where(Sede.cliente_id == Cliente.id).correlate(Cliente).scalar_subquery()
N_IMPIANTI_CLIENTE = (select(func.count(Impianto.id)).join(Sede, Impianto.sede_id == Sede.id)
                      .where(Sede.cliente_id == Cliente.id).correlate(Cliente).scalar_subquery())
N_IMPIANTI_SEDE = select(func.count(Impianto.id)).where(Impianto.sede_id == Sede.id).correlate(Sede).scalar_subquery()
_DM = and_(Asset.gruppo.in_(GRUPPI_DM), Asset.dismesso.is_(False))
N_ATTREZZATURE_CLIENTE = (select(func.count(Asset.id)).join(Sede, Asset.sede_id == Sede.id)
                          .where(Sede.cliente_id == Cliente.id, _DM).correlate(Cliente).scalar_subquery())
N_ATTREZZATURE_SEDE = select(func.count(Asset.id)).where(Asset.sede_id == Sede.id, _DM).correlate(Sede).scalar_subquery()


def _n_sede(*gruppi):  # noqa: ANN202
    """C8 (0.16): conteggi per gruppo, per i collegamenti «Attrezzature GVR / SC/SP / Accessori ← Sede»."""
    return (select(func.count(Asset.id)).where(Asset.sede_id == Sede.id, Asset.gruppo.in_(gruppi), Asset.dismesso.is_(False))
            .correlate(Sede).scalar_subquery())


def _con_dati_cliente(base):  # noqa: ANN001, ANN202
    """Aggiunge commerciale, modalità di pagamento e aliquota del cliente.

    Le unioni sono «piatte» (una dopo l'altra, senza parentesi): con unioni annidate che contengono
    LEFT JOIN alcune versioni di SQLite (es. 3.45.1) si bloccano con un errore grave."""
    return (base.outerjoin(Commerciale.__table__, Cliente.commerciale_id == Commerciale.id)
            .outerjoin(Pagamento, Cliente.modalita_pagamento_id == Pagamento.id)
            .outerjoin(Iva, Cliente.aliquota_iva_id == Iva.id))


def _da_cliente():  # noqa: ANN202
    return _con_dati_cliente(Cliente.__table__)


registra(Griglia(
    codice="clienti", titolo="Clienti", permesso="anagrafica.vedere", da=_da_cliente,
    ordine_predefinito=[("ragione_sociale", "asc")],
    ambito=lambda a: getattr(Cliente, CAMPI[a]).is_(True),
    colonne=[
        *colonne_cliente(visibili=("ragione_sociale", "tipo", "comune", "provincia", "partita_iva", "codice_fiscale",
                                   "email_verbali", "codice_sdi", "commerciale", "attivo")),
        Colonna("n_sedi", "N. sedi", "numero", N_SEDI, larghezza=80),
        Colonna("n_impianti", "N. impianti", "numero", N_IMPIANTI_CLIENTE, larghezza=90),
        Colonna("n_attrezzature", "N. attrezzature DM", "numero", N_ATTREZZATURE_CLIENTE, larghezza=110, visibile=False,
                descrizione="Attrezzature e accessori SC, SP, GVR, PSV non dismessi"),
    ],
))


def _da_sede():  # noqa: ANN202
    return _con_dati_cliente(Sede.__table__.join(Cliente.__table__, Sede.cliente_id == Cliente.id))


registra(Griglia(
    codice="sedi", titolo="Sedi operative", permesso="anagrafica.vedere", da=_da_sede,
    ordine_predefinito=[("cliente_ragione_sociale", "asc"), ("denominazione", "asc")],
    ambito=lambda a: getattr(Sede, CAMPI[a]).is_(True),
    colonne=[
        *colonne_sede(visibili=("denominazione", "indirizzo", "comune", "provincia", "referente_nome", "attiva")),
        Colonna("n_impianti", "N. impianti", "numero", N_IMPIANTI_SEDE, larghezza=90),
        Colonna("n_attrezzature", "N. attrezzature DM", "numero", N_ATTREZZATURE_SEDE, larghezza=110, visibile=False,
                descrizione="Attrezzature e accessori SC, SP, GVR, PSV non dismessi"),
        Colonna("n_gvr", "N. GVR", "numero", _n_sede("GVR"), larghezza=80, visibile=False),
        Colonna("n_scsp", "N. SC/SP", "numero", _n_sede("SC", "SP"), larghezza=80, visibile=False),
        Colonna("n_psv", "N. accessori (PSV)", "numero", _n_sede("PSV"), larghezza=100, visibile=False),
        *colonne_cliente("cliente_", "Cliente", visibili=("ragione_sociale",)),
    ],
))


def _da_impianto():  # noqa: ANN202
    return _con_dati_cliente(Impianto.__table__.join(Sede.__table__, Impianto.sede_id == Sede.id)
                             .join(Cliente.__table__, Sede.cliente_id == Cliente.id))


registra(Griglia(
    codice="impianti", titolo="Impianti", permesso="anagrafica.vedere", da=_da_impianto,
    ordine_predefinito=[("cliente_ragione_sociale", "asc"), ("sede_denominazione", "asc")],
    arricchisci=_arricchisci_tariffa,
    colonne=[
        *colonne_impianto(("id", "tipologia", "denominazione", "potenza_kw", "pod", "periodicita_anni",
                           "ultima_verifica_data", "prossima_verifica", "dismesso")),
        *colonne_sede("sede_", "Sede", visibili=("denominazione", "comune")),
        *colonne_cliente("cliente_", "Cliente", visibili=("ragione_sociale",)),
    ],
))

registra(Griglia(
    codice="commerciali", titolo="Commerciali", permesso="anagrafica.vedere", da=lambda: Commerciale.__table__,
    ordine_predefinito=[("nome", "asc")],
    ambito=lambda a: getattr(Commerciale, CAMPI[a]).is_(True),   # C16 (0.16): commerciali per attività
    colonne=[
        Colonna("id", "N.", "numero", Commerciale.id, visibile=False, larghezza=70),
        Colonna("nome", "Nome e cognome", "testo", Commerciale.nome, larghezza=220),
        Colonna("email", "Email", "testo", Commerciale.email, larghezza=220),
        Colonna("telefono", "Telefono", "testo", Commerciale.telefono, larghezza=140),
        Colonna("attivo", "Attivo", "booleano", Commerciale.attivo, larghezza=90),
        Colonna("clienti", "Clienti", "numero", select(func.count(Cliente.id)).where(Cliente.commerciale_id == Commerciale.id)
                .correlate(Commerciale).scalar_subquery(), larghezza=90),
        Colonna("note", "Note", "testo", Commerciale.note, larghezza=240),
        Colonna("ambito_dpr", "AD_DPR", "booleano", Commerciale.ambito_dpr, larghezza=90),
        Colonna("ambito_dm", "AD_DM", "booleano", Commerciale.ambito_dm, larghezza=90),
        Colonna("ambito_iec", "I&C", "booleano", Commerciale.ambito_iec, larghezza=90, visibile=False),
    ],
))

# Lo scadenziario: gli stessi impianti, esclusi i dismessi (D10), ordinati per prossima verifica.
# Le colonne del preventivo collegato (D19) si aggiungono dal modulo preventivi (vedi app.py).
SCADENZE = registra(Griglia(
    codice="scadenze", titolo="Scadenze", permesso="scadenze.vedere", da=_da_impianto,
    condizione=lambda _u: Impianto.dismesso.is_(False),
    ordine_predefinito=[("prossima_verifica", "asc")],
    arricchisci=_arricchisci_tariffa,
    colonne=[
        *colonne_impianto(("stato_scadenza", "prossima_verifica", "giorni", "tipologia", "potenza_kw", "periodicita_anni",
                           "ultima_verifica_data", "tariffa")),
        *colonne_sede("sede_", "Sede", visibili=("denominazione", "comune", "provincia")),
        *colonne_cliente("cliente_", "Cliente", visibili=("ragione_sociale",)),
    ],
))

# Elenco dei comuni ISTAT (D49): si consulta con l'anagrafica, si modifica con le impostazioni
USI_COMUNE = (select(func.count(Cliente.id)).where(Cliente.comune_istat == Comune.codice_istat).correlate(Comune).scalar_subquery()
              + select(func.count(Sede.id)).where(Sede.comune_istat == Comune.codice_istat).correlate(Comune).scalar_subquery())
registra(Griglia(
    codice="comuni", titolo="Comuni", permesso="anagrafica.vedere", da=lambda: Comune.__table__, chiave="codice_istat",
    ordine_predefinito=[("nome", "asc")],
    colonne=[
        Colonna("codice_istat", "Codice ISTAT", "testo", Comune.codice_istat, larghezza=110),
        Colonna("nome", "Comune", "testo", Comune.nome, larghezza=220),
        Colonna("sigla", "Prov.", "testo", Comune.sigla, larghezza=70),
        Colonna("provincia", "Provincia", "testo", Comune.provincia, larghezza=160),
        Colonna("regione", "Regione", "testo", Comune.regione, larghezza=160),
        Colonna("cap", "CAP", "testo", func.replace(Comune.cap, "|", ", "), larghezza=200),
        Colonna("codice_catastale", "Codice catastale", "testo", Comune.codice_catastale, larghezza=110),
        Colonna("attivo", "In elenco", "booleano", Comune.attivo, larghezza=90, descrizione="No = soppresso, non più proposto"),
        Colonna("usi", "Clienti e sedi", "numero", USI_COMUNE, larghezza=100),
    ],
))

__all__ = ["colonne_cliente", "colonne_sede", "colonne_impianto"]


# 0.12.10 (doc. 30, §§ 1–2): maschere di partenza di Clienti e Sedi operative con l'attività AD_DM
REGISTRO_GRIGLIE["clienti"].viste_predefinite = {"DM": {"colonne": [
    "ragione_sociale", "codice_fiscale", "indirizzo", "cap", "comune", "provincia", "regione", "commerciale"]}}
REGISTRO_GRIGLIE["sedi"].viste_predefinite = {"DM": {"colonne": [
    "denominazione", "indirizzo", "cap", "comune", "provincia", "regione", "cliente_ragione_sociale",
    "referente_nome", "referente_email", "referente_telefono"]}}

# C17–C19: cliente in prima colonna; gruppi ordinati per prima scadenza filtrata.
SCADENZE.gruppi_per_scadenza = "prossima_verifica"
SCADENZE.viste_predefinite = {"": {"colonne": ["cliente_ragione_sociale", *[
    c.campo for c in SCADENZE.colonne if c.visibile and c.campo != "cliente_ragione_sociale"]],
    "raggruppa": "cliente_ragione_sociale"}}
