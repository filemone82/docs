"""Importazione iniziale dell'anagrafica dal gestionale attuale (G5, G6, G34).

Tre file Excel, tutti facoltativi:
- CLIENTI: copia della griglia Clienti (il gestionale attuale non la esporta). Se c'è una riga di
  intestazione con i nomi delle colonne si usano quelli; altrimenti l'ordine delle colonne predefinite
  (ragione sociale, indirizzo, CAP, comune, provincia, regione, partita IVA, email, PEC, codice fiscale,
  codice SDI, modalità di pagamento, aliquota IVA). Le righe possono essere spostate di qualche colonna
  (succede incollando più pagine): ogni riga si legge dalla prima cella piena.
- SEDI OPERATIVE: copia della griglia Sedi (cliente, sede, indirizzo, CAP, comune, provincia, regione,
  referente, email, telefono, note), con le stesse regole.
- IMPIANTI: esportazione Excel della griglia Impianti (con intestazione).

Regole:
- ANTEPRIMA prima di tutto: nulla viene scritto finché non si conferma;
- solo AGGIUNTE: ciò che esiste già (stesso nome di cliente, stessa sede dello stesso cliente, stesso
  codice impianto del gestionale attuale) non viene toccato, così l'importazione si può ripetere;
- i dati sporchi non fermano l'importazione: finiscono nel campo «Da controllare» della scheda, che si
  filtra nelle griglie e si svuota quando il dato è sistemato;
- collegamenti per NOME (cliente → sede → impianto), perché i file copiati non hanno codici interni;
- i file importati restano nell'archivio documenti con la loro impronta (evidenza dell'importazione).
"""

from __future__ import annotations

import io
import re
import secrets
import threading
import time
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...core import validazioni as v
from ...core.errori import ErroreUtente
from ..documenti import servizio as documenti
from ..registro import servizio as registro
from . import servizio
from .modelli import Cliente, Comune, ElencoValore, Impianto, ImpiantoPod, Sede

COLONNE_CLIENTI = ["ragione_sociale", "indirizzo", "cap", "comune", "provincia", "regione", "partita_iva", "email",
                   "pec", "codice_fiscale", "codice_sdi", "pagamento", "aliquota_iva"]
COLONNE_SEDI = ["cliente", "denominazione", "indirizzo", "cap", "comune", "provincia", "regione", "referente_nome",
                "referente_email", "referente_telefono", "note"]

# Nomi di intestazione riconosciuti (minuscolo, senza punteggiatura) → campo
INTESTAZIONI = {
    "ragionesociale": "ragione_sociale", "cliente": "cliente", "indirizzo": "indirizzo", "cap": "cap", "comune": "comune",
    "provincia": "provincia", "prov": "provincia", "regione": "regione", "partitaiva": "partita_iva", "piva": "partita_iva",
    "codicefiscale": "codice_fiscale", "email": "email", "mail": "email", "pec": "pec", "codicesdi": "codice_sdi",
    "codicesdipec": "codice_sdi", "sdi": "codice_sdi", "pagamento": "pagamento", "modalitadipagamento": "pagamento",
    "aliquotaiva": "aliquota_iva", "iva": "aliquota_iva", "nazione": "nazione", "note": "note",
    "referentecommerciale": "commerciale", "nomereferente": "referente_nome", "emailreferente": "referente_email",
    "mailreferente": "referente_email", "telreferente": "referente_telefono", "telefonoreferente": "referente_telefono",
    "banca": "banca", "bancacliente": "banca", "iban": "iban", "ibanbancacliente": "iban",
    "riferimentoamministrazionefattelettronica": "riferimento_amministrazione", "riferimentoamministrazione": "riferimento_amministrazione",
    "ritenutadacconto": "ritenuta", "ritenutadaccontoaliquota": "ritenuta",
    "denominazionesedeoperativa": "denominazione", "sedeoperativa": "denominazione", "denominazione": "denominazione",
}

TIPOLOGIE_EXPORT = {"messa a terra < 1.000 v": "terra_bt", "messa a terra > 1.000 v": "terra_at",
                    "scariche atmosferiche": "scariche", "pericolo di esplosione": "esplosione"}


def chiave(testo: Any) -> str:
    """Nome normalizzato per gli abbinamenti: minuscolo, solo lettere e numeri."""
    t = str(testo or "").lower().replace("à", "a").replace("è", "e").replace("é", "e").replace("ì", "i").replace("ò", "o").replace("ù", "u")
    return re.sub(r"[^a-z0-9]", "", t)


def _testo(x: Any, massimo: int = 300) -> str:
    if x is None:
        return ""
    if isinstance(x, float) and x.is_integer():
        x = int(x)
    t = str(x).strip()
    return "" if t in ("…", "..", "nan", "None") else t[:massimo]


def _righe_excel(contenuto: bytes) -> list[list[Any]]:
    from openpyxl import load_workbook

    try:
        wb = load_workbook(io.BytesIO(contenuto), read_only=True, data_only=True)
    except Exception:
        raise ErroreUtente("Il file non è un Excel valido (.xlsx): salvalo di nuovo da Excel come «Cartella di lavoro di Excel».") from None
    righe = [list(r) for r in wb.worksheets[0].iter_rows(values_only=True)]
    wb.close()
    return righe


def _e_rumore(r: list[Any]) -> bool:
    piene = [x for x in r if x not in (None, "")]
    if not piene:
        return True
    primo = str(piene[0])
    return primo.startswith("Visualizza") or (len(piene) == 1 and isinstance(piene[0], (int, float)))


def _intestazione(r: list[Any]) -> dict[int, str] | None:
    mappa = {}
    for i, x in enumerate(r):
        k = chiave(x)
        if k in INTESTAZIONI:
            mappa[i] = INTESTAZIONI[k]
    return mappa if len(mappa) >= 3 else None


def leggi_tabella(contenuto: bytes, predefinite: list[str]) -> tuple[list[dict], str]:
    """Righe come dizionari. Restituisce anche come è stato letto il file (per l'anteprima)."""
    righe = [r for r in _righe_excel(contenuto) if not _e_rumore(r)]
    if not righe:
        return [], "file vuoto"
    mappa = _intestazione(righe[0])
    if mappa:
        return [{campo: r[i] if i < len(r) else None for i, campo in mappa.items()} for r in righe[1:]], \
            "colonne lette dalla riga di intestazione: " + ", ".join(sorted(set(mappa.values())))
    risultato = []
    for r in righe:
        inizio = next(i for i, x in enumerate(r) if x not in (None, ""))
        valori = (r[inizio:] + [None] * len(predefinite))[:len(predefinite)]
        risultato.append(dict(zip(predefinite, valori)))
    return risultato, "nessuna intestazione: colonne nell'ordine predefinito, righe riallineate dalla prima cella piena"


# ---------------------------------------------------------------- piano di importazione


@dataclass
class Problema:
    entita: str
    nome: str
    problema: str


@dataclass
class Piano:
    clienti: dict[str, dict] = field(default_factory=dict)       # chiave → dati
    sedi: dict[tuple[str, str], dict] = field(default_factory=dict)
    impianti: list[dict] = field(default_factory=list)
    gia_presenti: dict[str, int] = field(default_factory=lambda: {"clienti": 0, "sedi": 0, "impianti": 0})
    problemi: list[Problema] = field(default_factory=list)
    lettura: dict[str, str] = field(default_factory=dict)
    file: list[tuple[str, bytes]] = field(default_factory=list)
    nuovi_valori: dict[str, set] = field(default_factory=lambda: {"modalita_pagamento": set(), "aliquota_iva": set()})

    def avviso(self, dati: dict, entita: str, nome: str, testo: str) -> None:
        dati.setdefault("avvisi", []).append(testo)
        self.problemi.append(Problema(entita, nome, testo))

    def riepilogo(self) -> dict:
        conta: dict[str, int] = {}
        for p in self.problemi:
            tipo = re.sub(r"«[^»]*»|\d+([.,]\d+)?", "…", p.problema)
            conta[tipo] = conta.get(tipo, 0) + 1
        return {
            "nuovi": {"clienti": len(self.clienti), "sedi": len(self.sedi), "impianti": len(self.impianti)},
            "gia_presenti": self.gia_presenti,
            "lettura": self.lettura,
            "nuovi_valori": {k: sorted(x) for k, x in self.nuovi_valori.items()},
            "tipi_di_problema": sorted(({"problema": k, "quanti": n} for k, n in conta.items()), key=lambda x: -x["quanti"]),
            "problemi": [{"entita": p.entita, "nome": p.nome, "problema": p.problema} for p in self.problemi],
        }


def _comune(s: Session, cache: dict, nome: str, sigla: str) -> Comune | None:
    k = (chiave(nome), sigla.upper())
    if k not in cache:
        cache[k] = servizio.trova_comune(s, nome, sigla)
    return cache[k]


def _indirizzo(s: Session, piano: Piano, cache: dict, d: dict, r: dict, entita: str, nome: str) -> None:
    d["indirizzo"] = _testo(r.get("indirizzo"), 200)
    nome_comune, sigla = _testo(r.get("comune"), 100), _testo(r.get("provincia"), 2).upper()
    d["cap"] = v.recupera_numero(r.get("cap"), 5) if _testo(r.get("cap")) else ""
    if d["cap"] and not re.fullmatch(r"\d{5}", d["cap"]):
        piano.avviso(d, entita, nome, f"CAP «{d['cap']}» non valido")
        d["cap"] = ""
    c = _comune(s, cache, nome_comune, sigla) if nome_comune else None
    if c is not None:
        d.update(comune_istat=c.codice_istat, comune=c.nome, provincia=c.sigla, regione=c.regione)
        elenco_cap = c.cap.split("|")
        generico = len(elenco_cap) > 1 and d["cap"].endswith("100")  # CAP generico delle città con più CAP (es. 10100)
        if d["cap"] and d["cap"] not in elenco_cap and not generico:
            piano.avviso(d, entita, nome, f"CAP {d['cap']} diverso da quelli del comune {c.nome}")
    else:
        d.update(comune_istat=None, comune=nome_comune, provincia=sigla, regione=_testo(r.get("regione"), 60))
        if nome_comune:
            piano.avviso(d, entita, nome, f"comune «{nome_comune}» non trovato nell'elenco ISTAT")
    if not d["indirizzo"] or not d["comune"]:
        piano.avviso(d, entita, nome, "indirizzo incompleto (mancante o tagliato nella copia)")


def _modalita(testo: str) -> str:
    """Riconduce le tante scritture della stessa modalità a una sola voce dell'elenco."""
    t = testo.lower().replace("6o", "60").replace(".", "").replace(" ", "")
    if not t:
        return ""
    if "rimessa" in t:
        return "Rimessa diretta"
    giorni = re.search(r"(\d+)gg", t)
    n = giorni.group(1) if giorni else "30"
    if "riba" in t:
        return f"Ri.Ba. {n} gg F.M."
    if "bonifico" in t:
        return f"Bonifico {n} gg F.M." if "fm" in t else f"Bonifico {n} gg D.F."
    return testo.strip()


def analizza_clienti(s: Session, piano: Piano, righe: list[dict], esistenti: dict[str, int], cache: dict) -> None:
    piva_viste: dict[str, str] = {}
    for r in righe:
        nome = _testo(r.get("ragione_sociale"), 250)
        if not nome:
            continue
        k = chiave(nome)
        if k in esistenti:
            piano.gia_presenti["clienti"] += 1
            continue
        if k in piano.clienti:
            piano.avviso(piano.clienti[k], "Cliente", nome, "cliente presente due volte nel file: tenuta la prima riga")
            continue
        d: dict[str, Any] = {"ragione_sociale": nome, "nazione": "IT", "avvisi": []}
        _indirizzo(s, piano, cache, d, r, "Cliente", nome)
        piva = v.recupera_numero(r.get("partita_iva")) if _testo(r.get("partita_iva")) else ""
        cf = v.recupera_numero(r.get("codice_fiscale")) if _testo(r.get("codice_fiscale")) else ""
        if piva and not v.partita_iva_valida(piva):
            piano.avviso(d, "Cliente", nome, f"partita IVA «{piva}» non valida")
        if cf and not v.codice_fiscale_valido(cf):
            piano.avviso(d, "Cliente", nome, f"codice fiscale «{cf}» non valido")
        if not cf:  # D48: obbligatorio
            piano.avviso(d, "Cliente", nome, "manca il codice fiscale (obbligatorio)" + (": spesso coincide con la partita IVA" if piva else ""))
        for numero in {piva, cf} - {""}:
            if numero in piva_viste and piva_viste[numero] != k:
                piano.avviso(d, "Cliente", nome, f"stessa P.IVA/CF {numero} di un altro cliente: possibile doppione")
            piva_viste.setdefault(numero, k)
        d["partita_iva"], d["codice_fiscale"] = piva, cf
        email = "; ".join(v.dividi_email(r.get("email")))
        if email and not v.email_valide(email):
            piano.avviso(d, "Cliente", nome, f"email «{email}» non valida")
        d["email_verbali"] = d["email_fatture"] = email[:500]  # D41: all'inizio coincidono
        pec, sdi = _testo(r.get("pec"), 200), _testo(r.get("codice_sdi"), 60)
        if "@" in sdi:  # PEC scritta nel campo del codice SDI
            if not pec:
                pec = sdi
            sdi = ""
        sdi = re.sub(r"\s", "", sdi).upper()
        if sdi in ("0", "0000000"):
            sdi = ""
        if sdi and not re.fullmatch(r"[A-Z0-9]{6,7}", sdi):
            piano.avviso(d, "Cliente", nome, f"codice SDI «{sdi}» non valido")
            sdi = ""
        if pec and not v.email_valide(pec):
            piano.avviso(d, "Cliente", nome, f"PEC «{pec}» non valida")
        d["pec"], d["codice_sdi"] = pec, sdi
        if not sdi and not pec:
            piano.avviso(d, "Cliente", nome, "né codice SDI né PEC (servono per la fattura elettronica)")
        d["pagamento"] = _modalita(_testo(r.get("pagamento"), 200))
        d["aliquota_iva"] = _testo(r.get("aliquota_iva"), 200)
        for campo in ("referente_nome", "referente_email", "referente_telefono", "banca", "iban", "riferimento_amministrazione", "note"):
            d[campo] = _testo(r.get(campo), 500)
        aliquota = d["aliquota_iva"].lower()
        if "scissione" in aliquota or aliquota.startswith("22sp") or len(sdi) == 6:
            d["tipo"] = "pa"
        elif "condomin" in nome.lower():
            d["tipo"] = "condominio"
        elif len(cf) == 16 and not piva:
            d["tipo"] = "persona_fisica"
        else:
            d["tipo"] = "privato"
        piano.clienti[k] = d


def _cliente_minimo(piano: Piano, nome: str, origine: str) -> str:
    k = chiave(nome)
    if k not in piano.clienti:
        d = {"ragione_sociale": nome[:250], "nazione": "IT", "tipo": "privato", "avvisi": []}
        piano.avviso(d, "Cliente", nome, f"cliente creato dal file {origine}: mancano indirizzo e dati fiscali")
        piano.clienti[k] = d
    return k


def analizza_sedi(s: Session, piano: Piano, righe: list[dict], clienti_db: dict[str, int], sedi_db: set, cache: dict) -> None:
    for r in righe:
        cliente, nome = _testo(r.get("cliente"), 250), _testo(r.get("denominazione"), 300)
        if not cliente or not nome:
            continue
        kc, ks = chiave(cliente), chiave(nome)
        if (kc, ks) in sedi_db:
            piano.gia_presenti["sedi"] += 1
            continue
        if (kc, ks) in piano.sedi:
            piano.avviso(piano.sedi[(kc, ks)], "Sede", nome, "sede presente due volte nel file: tenuta la prima riga")
            continue
        if kc not in clienti_db:
            _cliente_minimo(piano, cliente, "delle sedi")
        d: dict[str, Any] = {"cliente": cliente, "denominazione": nome, "avvisi": []}
        if "??" in nome:
            piano.avviso(d, "Sede", nome, "denominazione con caratteri illeggibili («??»)")
        _indirizzo(s, piano, cache, d, r, "Sede", nome)
        d["referente_nome"] = _testo(r.get("referente_nome"), 120)
        email = "; ".join(v.dividi_email(r.get("referente_email")))
        if email and not v.email_valide(email):
            piano.avviso(d, "Sede", nome, f"email referente «{email}» non valida")
        d["referente_email"] = email[:200]
        d["referente_telefono"] = v.normalizza_telefono(r.get("referente_telefono"))
        d["note"] = _testo(r.get("note"), 4000)
        piano.sedi[(kc, ks)] = d


def _data_excel(x: Any) -> date | None:
    if isinstance(x, datetime):
        return x.date()
    if isinstance(x, date):
        return x
    t = _testo(x)
    if not t:
        return None
    try:
        g, m, a = re.split(r"[/.-]", t)
        return date(int(a), int(m), int(g))
    except ValueError:
        return None


def analizza_impianti(s: Session, piano: Piano, righe: list[dict], clienti_db: dict[str, int], sedi_db: set, codici_db: set) -> None:
    pod_visti: dict[str, str] = {}
    oggi = date.today()
    for r in righe:
        codice = _testo(r.get("Codice"), 40)
        if not codice:
            continue
        if codice in codici_db:
            piano.gia_presenti["impianti"] += 1
            continue
        nome = f"impianto {codice}"
        d: dict[str, Any] = {"codice_esterno": codice, "avvisi": []}
        cliente, sede = _testo(r.get("Cliente"), 250), _testo(r.get("Sede operativa"), 300)
        if not cliente or not sede:
            piano.problemi.append(Problema("Impianto", nome, "senza cliente o sede: non importato"))
            continue
        kc, ks = chiave(cliente), chiave(sede)
        if kc not in clienti_db:
            _cliente_minimo(piano, cliente, "degli impianti")
        if (kc, ks) not in sedi_db and (kc, ks) not in piano.sedi:
            sd = {"cliente": cliente, "denominazione": sede, "avvisi": []}
            piano.avviso(sd, "Sede", sede, "sede creata dal file degli impianti: manca l'indirizzo")
            piano.sedi[(kc, ks)] = sd
        d["sede_chiave"] = (kc, ks)
        tip = TIPOLOGIE_EXPORT.get(_testo(r.get("Tipologia impianto")).lower())
        if tip is None:
            piano.problemi.append(Problema("Impianto", nome, f"tipologia «{_testo(r.get('Tipologia impianto'))}» sconosciuta: non importato"))
            continue
        d["tipologia"] = tip
        d["denominazione"] = _testo(r.get("Denominazione impianto"), 300)
        d["dismesso"] = _testo(r.get("Dismesso")).lower() in ("sì", "si", "true", "1")
        d["matricola_anno"] = _testo(r.get("Anno matr."), 4)
        d["matricola_attivita"] = _testo(r.get("Cod. attività"), 10)
        d["matricola_numero"] = _testo(r.get("Num. matr."), 20)
        d["matricola_provincia"] = _testo(r.get("Prov. immatr."), 2).upper()
        terra = tip in ("terra_bt", "terra_at")
        potenza = r.get("Potenza impianto")
        try:
            d["potenza_kw"] = float(str(potenza).replace(",", ".")) if potenza not in (None, "") else None
        except ValueError:
            d["potenza_kw"] = None
            piano.avviso(d, "Impianto", nome, f"potenza «{potenza}» non numerica")
        if terra and not d["potenza_kw"]:
            piano.avviso(d, "Impianto", nome, "potenza mancante o zero (serve per la tariffa)")
        if d["potenza_kw"] and d["potenza_kw"] > 5000:
            piano.avviso(d, "Impianto", nome, f"potenza molto alta ({d['potenza_kw']:g} kW): controllare")
        for campo, col in (("cabine_mt_bt", "N. di cabine di trasformazione MT/BT"), ("sottostazioni_at_mt", "N. di sottostazioni AT/MT"),
                           ("numero_aste", "Numero parafulmini ad asta")):
            x = r.get(col)
            d[campo] = int(x) if isinstance(x, (int, float)) else (int(x) if _testo(x).isdigit() else None)
            if not d[campo]:
                d[campo] = None  # «0» nel gestionale attuale = dato non pertinente
        if tip == "terra_bt" and (d["cabine_mt_bt"] or d["sottostazioni_at_mt"]):
            piano.avviso(d, "Impianto", nome, "fino a 1.000 V ma con cabine MT/BT: tipologia probabilmente sbagliata "
                                              f"(cabine {d['cabine_mt_bt'] or 0}, sottostazioni {d['sottostazioni_at_mt'] or 0}: "
                                              "se è oltre 1.000 V correggi la tipologia e riscrivi i numeri)")
            d["cabine_mt_bt"] = d["sottostazioni_at_mt"] = None
        pod, resto = v.estrai_pod(r.get("Codice POD"))
        d["pod"], d["pod_note"] = (pod, resto[:2000]) if terra else ([], "")
        if resto and terra:
            piano.avviso(d, "Impianto", nome, "nel campo POD c'è altro testo (spostato in «Note POD»)")
        for p in pod:
            if p in pod_visti:
                piano.avviso(d, "Impianto", nome, f"POD {p} anche sull'{pod_visti[p]}")
            pod_visti.setdefault(p, nome)
        d["asta"] = bool(d["numero_aste"])
        gabbia = _testo(r.get("Parafulmine a gabbia")).lower()
        d["gabbia"] = gabbia.startswith("s")
        d["gabbia_fascia"] = ("oltre_350" if "oltre" in gabbia else "da_101_a_350" if "101" in gabbia else "fino_100" if "100" in gabbia else "") if d["gabbia"] else ""
        if tip == "scariche" and not (d["asta"] or d["gabbia"]):
            piano.avviso(d, "Impianto", nome, "scariche atmosferiche senza aste né gabbia indicate")
        zone = [z.strip() for z in _testo(r.get("Classificazione zone")).split(",") if z.strip()]
        d["zone"] = ", ".join(z for z in ("0", "1", "2", "20", "21", "22") if z in zone)
        d["gas"] = any(z in ("0", "1", "2") for z in zone)
        d["polveri"] = any(z in ("20", "21", "22") for z in zone)
        if tip == "esplosione" and not zone:
            piano.avviso(d, "Impianto", nome, "pericolo di esplosione senza zone indicate")
        per = r.get("Periodicità verifiche")
        d["periodicita_anni"] = int(per) if isinstance(per, (int, float)) and int(per) in (2, 5) else None
        if d["periodicita_anni"] is None:
            piano.avviso(d, "Impianto", nome, "periodicità mancante")
        elif tip == "esplosione" and d["periodicita_anni"] != 2:  # O8: si segnala, non si corregge da soli
            piano.avviso(d, "Impianto", nome, f"pericolo di esplosione con periodicità {d['periodicita_anni']} anni: per legge è 2 anni")
        d["ultima_verifica_data"] = _data_excel(r.get("Ultima verifica"))
        d["ultima_verifica_numero"] = _testo(r.get("Ultima verif."), 40)
        prossima = _data_excel(r.get("Prossima verifica"))
        if d["ultima_verifica_data"] and d["periodicita_anni"]:
            calcolata = servizio.scadenza(d["ultima_verifica_data"], d["periodicita_anni"])
            if prossima and prossima != calcolata:
                piano.avviso(d, "Impianto", nome, f"prossima verifica ricalcolata: era {prossima.strftime('%d/%m/%Y')}, "
                                                  f"ora {calcolata.strftime('%d/%m/%Y')} (ultima verifica + periodicità)")
            d["prossima_verifica"], d["prossima_calcolata"] = calcolata, True
        else:
            d["prossima_verifica"], d["prossima_calcolata"] = prossima, False
            if prossima and prossima < oggi and not d["dismesso"]:
                piano.avviso(d, "Impianto", nome, "prossima verifica già passata e nessuna verifica registrata")
        piano.impianti.append(d)


def analizza(s: Session, clienti: bytes | None, sedi: bytes | None, impianti: bytes | None, nomi: dict[str, str]) -> Piano:
    piano = Piano()
    cache: dict = {}
    clienti_db = {chiave(c.ragione_sociale): c.id for c in s.execute(select(Cliente)).scalars()}
    sedi_db = {(chiave(rs), chiave(den)) for den, rs in s.execute(select(Sede.denominazione, Cliente.ragione_sociale).join(Cliente))}
    codici_db = {c for (c,) in s.execute(select(Impianto.codice_esterno).where(Impianto.codice_esterno != ""))}
    if clienti:
        righe, piano.lettura["clienti"] = leggi_tabella(clienti, COLONNE_CLIENTI)
        analizza_clienti(s, piano, righe, clienti_db, cache)
        piano.file.append((nomi.get("clienti", "clienti.xlsx"), clienti))
    if sedi:
        righe, piano.lettura["sedi"] = leggi_tabella(sedi, COLONNE_SEDI)
        analizza_sedi(s, piano, righe, clienti_db, sedi_db, cache)
        piano.file.append((nomi.get("sedi", "sedi.xlsx"), sedi))
    if impianti:
        tutte = _righe_excel(impianti)
        intest = next((i for i, r in enumerate(tutte[:5]) if "Codice" in r and "Tipologia impianto" in r), None)
        if intest is None:
            raise ErroreUtente("Il file degli impianti non sembra l'esportazione del gestionale attuale: manca la riga con «Codice» e «Tipologia impianto».")
        nomi_col = [str(x or "") for x in tutte[intest]]
        righe = [dict(zip(nomi_col, r)) for r in tutte[intest + 1:] if any(x not in (None, "") for x in r)]
        piano.lettura["impianti"] = f"esportazione del gestionale attuale, {len(nomi_col)} colonne"
        analizza_impianti(s, piano, righe, clienti_db, sedi_db, codici_db)
        piano.file.append((nomi.get("impianti", "impianti.xlsx"), impianti))
    # valori di elenco da aggiungere (modalità di pagamento e aliquote non ancora presenti)
    esistenti = {(x.elenco, x.descrizione.lower()) for x in s.execute(select(ElencoValore)).scalars()}
    for d in piano.clienti.values():
        for elenco, campo in (("modalita_pagamento", "pagamento"), ("aliquota_iva", "aliquota_iva")):
            if d.get(campo) and (elenco, d[campo].lower()) not in esistenti:
                piano.nuovi_valori[elenco].add(d[campo])
    return piano


# ---------------------------------------------------------------- esecuzione


def esegui(s: Session, cfg: Any, attore: Any, piano: Piano) -> dict:
    """Scrive tutto in una sola transazione: o entra tutto o niente."""
    nome_attore = getattr(attore, "nome", "") or "Importazione"
    valori: dict[tuple[str, str], int] = {}
    for x in s.execute(select(ElencoValore)).scalars():
        valori[(x.elenco, x.descrizione.lower())] = x.id
    for elenco, nuovi in piano.nuovi_valori.items():
        for i, descrizione in enumerate(sorted(nuovi)):
            codice = descrizione.split(" - ")[0][:20] if elenco == "aliquota_iva" else ""
            x = ElencoValore(elenco=elenco, descrizione=descrizione[:200], codice=codice, ordine=100 + i,
                             creato_da=nome_attore, modificato_da=nome_attore)
            s.add(x)
            s.flush()
            valori[(elenco, descrizione.lower())] = x.id

    def testo_avvisi(d: dict) -> str:
        return "\n".join(f"Importazione: {a}" for a in d.get("avvisi", []))

    clienti_id = {chiave(c.ragione_sociale): c.id for c in s.execute(select(Cliente)).scalars()}
    for k, d in piano.clienti.items():
        c = Cliente(**{f: d.get(f, "") for f in ("ragione_sociale", "tipo", "nazione", "indirizzo", "comune", "cap", "provincia", "regione",
                                                  "partita_iva", "codice_fiscale", "email_verbali", "email_fatture", "pec", "codice_sdi",
                                                  "referente_nome", "referente_email", "referente_telefono", "banca", "riferimento_amministrazione",
                                                  "note")},
                    comune_istat=d.get("comune_istat"), iban=(d.get("iban") or "")[:34], avvisi=testo_avvisi(d),
                    modalita_pagamento_id=valori.get(("modalita_pagamento", (d.get("pagamento") or "").lower())),
                    aliquota_iva_id=valori.get(("aliquota_iva", (d.get("aliquota_iva") or "").lower())),
                    creato_da=nome_attore, modificato_da=nome_attore)
        s.add(c)
        s.flush()
        clienti_id[k] = c.id
    sedi_id = {(chiave(rs), chiave(x.denominazione)): x.id for x, rs in s.execute(select(Sede, Cliente.ragione_sociale).join(Cliente))}
    for (kc, ks), d in piano.sedi.items():
        x = Sede(cliente_id=clienti_id[kc], denominazione=d["denominazione"],
                 **{f: d.get(f, "") for f in ("indirizzo", "comune", "cap", "provincia", "regione", "referente_nome", "referente_email",
                                              "referente_telefono", "note")},
                 comune_istat=d.get("comune_istat"), avvisi=testo_avvisi(d), creato_da=nome_attore, modificato_da=nome_attore)
        s.add(x)
        s.flush()
        sedi_id[(kc, ks)] = x.id
    for d in piano.impianti:
        x = Impianto(sede_id=sedi_id[d["sede_chiave"]], avvisi=testo_avvisi(d), creato_da=nome_attore, modificato_da=nome_attore,
                     **{f: d[f] for f in ("codice_esterno", "tipologia", "denominazione", "dismesso", "matricola_anno", "matricola_attivita",
                                          "matricola_numero", "matricola_provincia", "potenza_kw", "cabine_mt_bt", "sottostazioni_at_mt",
                                          "pod_note", "asta", "numero_aste", "gabbia", "gabbia_fascia", "gas", "polveri", "zone",
                                          "periodicita_anni", "ultima_verifica_data", "ultima_verifica_numero", "prossima_verifica",
                                          "prossima_calcolata")})
        x.pod = [ImpiantoPod(pod=p, ordine=i) for i, p in enumerate(d["pod"])]
        s.add(x)
    s.flush()
    documenti_salvati = []
    for nome, contenuto in piano.file:
        doc = documenti.salva(s, cfg.cartella_documenti, contenuto, nome,
                              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                              getattr(attore, "id", None), "File importato nell'anagrafica")
        documenti_salvati.append({"nome": nome, "documento_id": doc.id, "impronta": doc.impronta})
    esito = {"clienti": len(piano.clienti), "sedi": len(piano.sedi), "impianti": len(piano.impianti),
             "gia_presenti": piano.gia_presenti, "problemi": len(piano.problemi),
             "nuovi_valori": {k: sorted(x) for k, x in piano.nuovi_valori.items()}, "file": documenti_salvati}
    registro.scrivi(s, utente=attore, azione="anagrafica.importa", oggetto_tipo="importazione",
                    descrizione=f"Importazione anagrafica: {esito['clienti']} clienti, {esito['sedi']} sedi, {esito['impianti']} impianti "
                                f"({esito['problemi']} segnalazioni da controllare)", dettagli=esito)
    return esito


# ---------------------------------------------------------------- anteprime in attesa di conferma


class Anteprime:
    """Il piano resta in memoria (per l'utente che l'ha creato) finché non si conferma, al massimo 1 ora."""

    def __init__(self) -> None:
        self._dati: dict[str, tuple[int, float, Piano]] = {}
        self._lucchetto = threading.Lock()

    def metti(self, utente_id: int, piano: Piano) -> str:
        codice = secrets.token_urlsafe(16)
        with self._lucchetto:
            adesso = time.time()
            self._dati = {k: x for k, x in self._dati.items() if adesso - x[1] < 3600 and x[0] != utente_id}
            self._dati[codice] = (utente_id, adesso, piano)
        return codice

    def prendi(self, utente_id: int, codice: str) -> Piano:
        with self._lucchetto:
            x = self._dati.pop(codice, None)
        if x is None or x[0] != utente_id or time.time() - x[1] > 3600:
            raise ErroreUtente("Anteprima scaduta o già usata: ricarica i file e rifai l'anteprima.")
        return x[2]


ANTEPRIME = Anteprime()
