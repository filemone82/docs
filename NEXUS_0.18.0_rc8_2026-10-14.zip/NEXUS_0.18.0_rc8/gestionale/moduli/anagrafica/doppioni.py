"""Sedi doppie: riconoscerle e unirle (R116, decisione di Federico dell'11/10/2026, 13:55).

Lo stesso stabilimento può esistere due volte: una sede nata in ingecert (AD_dpr) e una in adsrl (AD_dm), perché i
gestionali di Garda non condividevano l'anagrafica. La sede è il luogo fisico, quindi resta UNA sola con gli ambiti
di entrambe e, sotto, impianti e attrezzature.

- Stesso cliente, stesso indirizzo e stesso comune (a parte maiuscole, accenti, punteggiatura, «n.», «civ.») →
  stessa sede: l'importazione le unisce da sola.
- Stesso cliente e stesso comune, indirizzo scritto diversamente → possibile doppione: si propone all'utente, che
  conferma («Unisci») o esclude («Sono sedi diverse»; l'esclusione si ricorda).
- L'unione sposta su una sola sede OGNI riferimento (impianti, attrezzature e accessori, preventivi: tutte le
  colonne che puntano alle sedi, trovate dallo schema), completa i campi vuoti con quelli dell'altra sede e scrive
  nelle note quelli diversi (per ora un solo referente e un solo indirizzo per i verbali). Rifiuta se due beni
  avrebbero la stessa matricola nella stessa sede. Tutto nel registro.
"""

from __future__ import annotations

import difflib
import re
import unicodedata
from typing import Any

from sqlalchemy import and_, delete, func, or_, select, update
from sqlalchemy.orm import Session, aliased

from ...core.db import Base, adesso
from ...core.errori import ErroreUtente, NonTrovato
from ..registro import servizio as registro
from . import ambiti, origini
from .modelli import Cliente, ClienteDoppioneEscluso, Sede, SedeDoppioneEsclusa

PAROLE_INUTILI = re.compile(r"\b(n|nr|num|numero|civ|civico|snc)\b\.?")
CAMPI_DA_COMPLETARE = ("referente_nome", "referente_email", "referente_telefono", "email_verbali", "email_verbali_cc",
                       "note_accesso", "cap", "provincia", "regione", "comune_istat")


def _semplice(testo: Any) -> str:
    t = unicodedata.normalize("NFKD", str(testo or "").replace("°", " ").replace("º", " ")).encode("ascii", "ignore").decode().lower()
    return t


def chiave(testo: Any) -> str:
    """Indirizzo o comune ridotto all'essenziale: «Via Roma, n. 1» = «VIA ROMA 1»."""
    return re.sub(r"[^a-z0-9]", "", PAROLE_INUTILI.sub(" ", _semplice(testo)))


def _civico(testo: Any) -> str:
    numeri = re.findall(r"\d+", _semplice(testo))
    return numeri[0] if numeri else ""


def somiglianza(a: str, b: str) -> float:
    """0…1 fra due indirizzi dello stesso comune: nome della via simile e stesso numero civico."""
    via_a, via_b = re.sub(r"[^a-z]", "", PAROLE_INUTILI.sub(" ", _semplice(a))), re.sub(r"[^a-z]", "", PAROLE_INUTILI.sub(" ", _semplice(b)))
    r = difflib.SequenceMatcher(None, via_a, via_b).ratio() if via_a and via_b else 0.0
    ca, cb = _civico(a), _civico(b)
    return round(r * (1.0 if ca and ca == cb else 0.6), 2)


def gemelle(s: Session, sd: Sede, tra: list[Sede] | None = None) -> list[Sede]:
    """Le altre sedi dello stesso cliente con lo stesso indirizzo e comune."""
    k = (chiave(sd.indirizzo), chiave(sd.comune))
    if not k[0]:
        return []
    elenco = tra if tra is not None else list(s.scalars(select(Sede).where(Sede.cliente_id == sd.cliente_id, Sede.id != sd.id)))
    return [x for x in elenco if x.id != sd.id and x.cliente_id == sd.cliente_id and (chiave(x.indirizzo), chiave(x.comune)) == k]


def candidati(s: Session) -> list[dict]:
    """Coppie di sedi dello stesso cliente nello stesso comune di provenienza DIVERSA (una con impianti AD_DPR, l'altra con
    attrezzature AD_DM:
    lo stesso stabilimento entrato da due gestionali), non ancora escluse, dalle più probabili.
    Le coppie con lo stesso ambito (es. due sedi DPR allo stesso indirizzo, già così in ingecert) non si propongono:
    si uniscono, se serve, dalla scheda della sede («Unisci con…»)."""
    from ..beni.modelli import Asset
    from .modelli import Impianto

    esclusi = {(e.sede_a_id, e.sede_b_id) for e in s.scalars(select(SedeDoppioneEsclusa))}
    impianti = dict(s.execute(select(Impianto.sede_id, func.count(Impianto.id)).group_by(Impianto.sede_id)).all())
    attrezzature = dict(s.execute(select(Asset.sede_id, func.count(Asset.id)).where(Asset.gruppo.in_(ambiti.GRUPPI_DM))
                                  .group_by(Asset.sede_id)).all())
    per_cliente: dict[tuple[int, str], list[Sede]] = {}
    for x in s.scalars(select(Sede)):
        if chiave(x.comune):
            per_cliente.setdefault((x.cliente_id, chiave(x.comune)), []).append(x)
    out = []
    nomi: dict[int, str] = {}
    for gruppo in per_cliente.values():
        if len(gruppo) < 2:
            continue
        gruppo.sort(key=lambda x: x.id)
        for i, a in enumerate(gruppo):
            for b in gruppo[i + 1:]:
                if (a.id, b.id) in esclusi or _provenienza(a, impianti, attrezzature) & _provenienza(b, impianti, attrezzature):
                    continue
                uguale = bool(chiave(a.indirizzo)) and chiave(a.indirizzo) == chiave(b.indirizzo)
                if a.cliente_id not in nomi:
                    nomi[a.cliente_id] = s.get(Cliente, a.cliente_id).ragione_sociale
                out.append({"cliente_id": a.cliente_id, "cliente": nomi[a.cliente_id],
                            "punteggio": 1.0 if uguale else somiglianza(a.indirizzo, b.indirizzo), "stesso_indirizzo": uguale,
                            "a": _breve(a, impianti, attrezzature), "b": _breve(b, impianti, attrezzature)})
    out.sort(key=lambda x: (-x["punteggio"], x["cliente"]))
    return out


def _provenienza(x: Sede, impianti: dict, attrezzature: dict) -> set[str]:
    """R137 (0.16): l'ambito ora è del cliente, uguale per tutte le sue sedi; per riconoscere lo stesso stabilimento
    entrato da due gestionali si guarda il CONTENUTO della sede (impianti → DPR, attrezzature → DM) e, se è vuota,
    da dove viene (codice «dm:» = adsrl)."""
    p = ({"DPR"} if impianti.get(x.id) else set()) | ({"DM"} if attrezzature.get(x.id) else set())
    return p or ({"DM"} if str(x.codice_esterno or "").startswith("dm:") else {"DPR"})


def _breve(x: Sede, impianti: dict, attrezzature: dict) -> dict:
    return {"id": x.id, "denominazione": x.denominazione, "indirizzo": x.indirizzo, "comune": x.comune, "attiva": x.attiva,
            "ambiti": ambiti.elenco(x), "codice_esterno": x.codice_esterno,
            "impianti": impianti.get(x.id, 0), "attrezzature": attrezzature.get(x.id, 0)}


def _conteggi(s: Session, *ids: int) -> tuple[dict, dict]:
    from ..beni.modelli import Asset
    from .modelli import Impianto

    imp = dict(s.execute(select(Impianto.sede_id, func.count(Impianto.id)).where(Impianto.sede_id.in_(ids)).group_by(Impianto.sede_id)).all())
    att = dict(s.execute(select(Asset.sede_id, func.count(Asset.id)).where(Asset.sede_id.in_(ids), Asset.gruppo.in_(ambiti.GRUPPI_DM))
                         .group_by(Asset.sede_id)).all())
    return imp, att


def escludi(s: Session, attore: Any, a_id: int, b_id: int) -> None:
    a_id, b_id = sorted((int(a_id), int(b_id)))
    a, b = s.get(Sede, a_id), s.get(Sede, b_id)
    if a is None or b is None or a_id == b_id:
        raise NonTrovato("Sede non trovata: ricarica la pagina.")
    if s.scalar(select(SedeDoppioneEsclusa.id).where(SedeDoppioneEsclusa.sede_a_id == a_id, SedeDoppioneEsclusa.sede_b_id == b_id)) is None:
        s.add(SedeDoppioneEsclusa(sede_a_id=a_id, sede_b_id=b_id, creato_da=getattr(attore, "nome", "") or ""))
    registro.scrivi(s, utente=attore, azione="sede.non_doppione", oggetto_tipo="sede", oggetto_id=a_id,
                    descrizione=f"Sedi «{a.denominazione}» e «{b.denominazione}» indicate come diverse (non si uniscono)")


ESCLUSIONI = {"sedi_doppioni_esclusi", "clienti_doppioni_esclusi"}


def _riferimenti(verso: str = "sedi") -> list[tuple[Any, Any]]:
    """(tabella, colonna) di ogni chiave esterna verso <verso>.id, letta dallo schema: nessuna dimenticata."""
    out = []
    for t in Base.metadata.sorted_tables:
        if t.name in ESCLUSIONI:
            continue
        for fk in t.foreign_keys:
            if fk.column.table.name == verso and fk.column.name == "id":
                out.append((t, fk.parent))
    return out


def _conflitti(s: Session, origine_id: int, destinazione_id: int, verso: str = "sedi") -> list[str]:
    """Righe che dopo l'unione violerebbero un vincolo di unicità che contiene la sede (es. stessa matricola)."""
    out = []
    for t, col in _riferimenti(verso):
        vincoli = [c for c in t.constraints if getattr(c, "columns", None) is not None and c.__class__.__name__ == "UniqueConstraint"]
        vincoli += [i for i in t.indexes if i.unique]
        for v in vincoli:
            colonne = list(v.columns)
            if col not in colonne:
                continue
            altre = [c for c in colonne if c is not col]
            a, b = aliased(t), aliased(t)
            q = select(*[a.c[c.name] for c in altre]).select_from(a).join(
                b, and_(*[a.c[c.name] == b.c[c.name] for c in altre])).where(a.c[col.name] == origine_id, b.c[col.name] == destinazione_id)
            for riga in s.execute(q.limit(6)).all():
                out.append(f"{t.name}: " + ", ".join(f"{c.name} «{x}»" for c, x in zip(altre, riga, strict=True)))
    return out


def unisci(s: Session, attore: Any, origine_id: int, destinazione_id: int, *, motivo: str = "", registra: bool = True) -> Sede:
    """Unisce la sede «origine» nella sede «destinazione», che resta. L'origine viene eliminata (resta nel registro)."""
    if int(origine_id) == int(destinazione_id):
        raise ErroreUtente("Scegli due sedi diverse.")
    o, d = s.get(Sede, int(origine_id)), s.get(Sede, int(destinazione_id))
    if o is None or d is None:
        raise NonTrovato("Sede non trovata: forse è già stata unita. Ricarica la pagina.")
    if o.cliente_id != d.cliente_id:
        raise ErroreUtente("Si uniscono solo sedi dello stesso cliente.")
    s.flush()
    conflitti = _conflitti(s, o.id, d.id)
    if conflitti:
        raise ErroreUtente("Non si possono unire: nelle due sedi ci sono beni con la stessa matricola. Correggi prima questi: "
                           + "; ".join(conflitti[:5]) + (" …" if len(conflitti) > 5 else ""))
    conti = _conteggi(s, o.id, d.id)
    prima = {"origine": _breve(o, *conti), "destinazione": _breve(d, *conti)}
    diversi = []
    for campo in CAMPI_DA_COMPLETARE:
        vo, vd = getattr(o, campo), getattr(d, campo)
        if vo and not vd:
            setattr(d, campo, vo)
        elif vo and vd and str(vo).strip().lower() != str(vd).strip().lower():
            diversi.append(f"{campo.replace('_', ' ')}: {vo}")
    if chiave(o.denominazione) != chiave(d.denominazione):
        diversi.insert(0, f"denominazione: {o.denominazione}")
    if chiave(o.indirizzo) != chiave(d.indirizzo):
        diversi.insert(1 if diversi else 0, f"indirizzo: {o.indirizzo}, {o.comune}")
    nota = f"Unita la sede «{o.denominazione}» (n. {o.id}" + (f", rif. {o.codice_esterno}" if o.codice_esterno else "") + ")"
    nota += (f" · {motivo}" if motivo else "") + (". Dati diversi dell'altra sede: " + "; ".join(diversi) if diversi else "") + "."
    if o.note:
        nota += f"\nNote dell'altra sede: {o.note}"
    d.note = (d.note + "\n" if d.note else "") + nota
    togli = re.compile(r"^.*possibile doppione.*$\n?", re.MULTILINE | re.IGNORECASE)
    d.avvisi = togli.sub("", "\n".join(x for x in (d.avvisi, togli.sub("", o.avvisi or "")) if x)).strip()
    codici = [c for c in (d.codice_esterno, o.codice_esterno) if c]
    unito = " · ".join(codici)
    d.codice_esterno = unito if len(unito) <= 40 else d.codice_esterno
    for campo in ambiti.CAMPI.values():
        if getattr(o, campo):
            setattr(d, campo, True)
    d.attiva = bool(d.attiva or o.attiva)
    d.versione = (d.versione or 1) + 1
    d.modificato_da = getattr(attore, "nome", "") or d.modificato_da
    d.modificato_il = adesso()
    s.flush()
    spostati = {}
    for t, col in _riferimenti():
        n = s.execute(update(t).where(col == o.id).values({col.name: d.id})).rowcount
        if n:
            spostati[t.name] = n
    s.execute(delete(SedeDoppioneEsclusa).where(or_(SedeDoppioneEsclusa.sede_a_id == o.id, SedeDoppioneEsclusa.sede_b_id == o.id)))
    spostati["origini"] = origini.sposta(s, "sede", o.id, d.id)  # R120
    for x in list(s.identity_map.values()):  # oggetti già caricati che puntavano alla sede unita: si rileggono
        if getattr(x, "sede_id", None) == o.id:
            s.expire(x)
    s.delete(o)
    s.flush()
    d = s.get(Sede, d.id)
    if registra:
        registro.scrivi(s, utente=attore, azione="sede.unisci", oggetto_tipo="sede", oggetto_id=d.id,
                        descrizione=f"Unita la sede «{prima['origine']['denominazione']}» nella sede «{d.denominazione}»"
                                    + (f" ({motivo})" if motivo else ""),
                        dettagli={**prima, "spostati": spostati, "dati_diversi": diversi})
    return d


# ---------------------------------------------------------------- clienti doppi (revisione dell'11/10/2026)

CAMPI_CLIENTE = ("email_verbali", "email_fatture", "pec", "codice_sdi", "riferimento_amministrazione", "commerciale_id",
                 "referente_nome", "referente_email", "referente_telefono", "banca", "iban", "modalita_pagamento_id",
                 "aliquota_iva_id", "termine_esecuzione", "partita_iva", "codice_fiscale", "comune_istat", "cap", "provincia", "regione")


def numeri(c: Cliente) -> set[str]:
    return {x.strip().upper() for x in (c.partita_iva, c.codice_fiscale) if x and x.strip()}


def candidati_clienti(s: Session) -> list[dict]:
    """Coppie di clienti con la stessa partita IVA o lo stesso codice fiscale, non ancora dichiarati diversi."""
    esclusi = {(e.cliente_a_id, e.cliente_b_id) for e in s.scalars(select(ClienteDoppioneEscluso))}
    per_numero: dict[str, list[Cliente]] = {}
    for c in s.scalars(select(Cliente).order_by(Cliente.id)):
        for n in numeri(c):
            per_numero.setdefault(n, []).append(c)
    coppie: dict[tuple[int, int], dict] = {}
    for n, gruppo in per_numero.items():
        for i, a in enumerate(gruppo):
            for b in gruppo[i + 1:]:
                k = (a.id, b.id)
                if k in esclusi or k in coppie:
                    continue
                coppie[k] = {"numero": n, "a": _cliente_breve(s, a), "b": _cliente_breve(s, b)}
    return sorted(coppie.values(), key=lambda x: (x["a"]["ragione_sociale"].lower(), x["b"]["id"]))


def _cliente_breve(s: Session, c: Cliente) -> dict:
    from ..finanza.modelli import Fattura
    from ..preventivi.modelli import Preventivo

    return {"id": c.id, "ragione_sociale": c.ragione_sociale, "partita_iva": c.partita_iva, "codice_fiscale": c.codice_fiscale,
            "comune": c.comune, "ambiti": ambiti.elenco(c), "attivo": c.attivo, "codice_esterno": c.codice_esterno,
            "sedi": s.scalar(select(func.count(Sede.id)).where(Sede.cliente_id == c.id)) or 0,
            "preventivi": s.scalar(select(func.count(Preventivo.id)).where(Preventivo.cliente_id == c.id)) or 0,
            "fatture": s.scalar(select(func.count(Fattura.id)).where(Fattura.cliente_id == c.id)) or 0,
            "origini": origini.di(s, "cliente", c.id)}


def escludi_clienti(s: Session, attore: Any, a_id: int, b_id: int) -> None:
    a_id, b_id = sorted((int(a_id), int(b_id)))
    a, b = s.get(Cliente, a_id), s.get(Cliente, b_id)
    if a is None or b is None or a_id == b_id:
        raise NonTrovato("Cliente non trovato: ricarica la pagina.")
    if s.scalar(select(ClienteDoppioneEscluso.id).where(ClienteDoppioneEscluso.cliente_a_id == a_id,
                                                        ClienteDoppioneEscluso.cliente_b_id == b_id)) is None:
        s.add(ClienteDoppioneEscluso(cliente_a_id=a_id, cliente_b_id=b_id, creato_da=getattr(attore, "nome", "") or ""))
    registro.scrivi(s, utente=attore, azione="cliente.non_doppione", oggetto_tipo="cliente", oggetto_id=a_id,
                    descrizione=f"Clienti «{a.ragione_sociale}» e «{b.ragione_sociale}» indicati come diversi (non si uniscono)")


def unisci_clienti(s: Session, attore: Any, origine_id: int, destinazione_id: int) -> Cliente:
    """Unisce il cliente «origine» nel cliente «destinazione», che resta: sedi, preventivi, fatture e incassi passano
    al cliente che resta; i campi vuoti si completano, quelli diversi vanno nelle note; le corrispondenze con Garda
    seguono. Le fatture già emesse restano come sono (i loro dati fiscali sono fissati nel documento)."""
    from ..finanza.modelli import Fattura

    if int(origine_id) == int(destinazione_id):
        raise ErroreUtente("Scegli due clienti diversi.")
    o, d = s.get(Cliente, int(origine_id)), s.get(Cliente, int(destinazione_id))
    if o is None or d is None:
        raise NonTrovato("Cliente non trovato: forse è già stato unito. Ricarica la pagina.")
    if s.scalar(select(func.count(Fattura.id)).where(Fattura.cliente_id == o.id)) and \
            s.scalar(select(func.count(Fattura.id)).where(Fattura.cliente_id == d.id)):
        raise ErroreUtente("Entrambi i clienti hanno fatture: non si uniscono qui. Contattami per valutare il caso.")
    if s.scalar(select(func.count(Fattura.id)).where(Fattura.cliente_id == o.id)):
        raise ErroreUtente(f"«{o.ragione_sociale}» ha delle fatture: unisci nell'altro verso (resta il cliente con le fatture).")
    s.flush()
    conflitti = _conflitti(s, o.id, d.id, "clienti")
    if conflitti:
        raise ErroreUtente("Non si possono unire: " + "; ".join(conflitti[:5]))
    prima = {"origine": _cliente_breve(s, o), "destinazione": _cliente_breve(s, d)}
    diversi = []
    for campo in CAMPI_CLIENTE:
        vo, vd = getattr(o, campo), getattr(d, campo)
        if vo not in (None, "") and vd in (None, ""):
            setattr(d, campo, vo)
        elif vo not in (None, "") and str(vo).strip().lower() != str(vd).strip().lower():
            diversi.append(f"{campo.replace('_', ' ')}: {vo}")
    if o.ragione_sociale.strip().lower() != d.ragione_sociale.strip().lower():
        diversi.insert(0, f"ragione sociale: {o.ragione_sociale}")
    nota = f"Unito il cliente «{o.ragione_sociale}» (n. {o.id}" + (f", rif. {o.codice_esterno}" if o.codice_esterno else "") + ")"
    nota += (". Dati diversi dell'altro cliente: " + "; ".join(diversi) if diversi else "") + "."
    if o.note:
        nota += f"\nNote dell'altro cliente: {o.note}"
    d.note = (d.note + "\n" if d.note else "") + nota
    d.avvisi = "\n".join(x for x in (d.avvisi, o.avvisi) if x)
    for campo in ambiti.CAMPI.values():
        if getattr(o, campo):
            setattr(d, campo, True)
    d.attivo = bool(d.attivo or o.attivo)
    d.versione = (d.versione or 1) + 1
    d.modificato_da = getattr(attore, "nome", "") or d.modificato_da
    d.modificato_il = adesso()
    s.flush()
    spostati = {}
    for t, col in _riferimenti("clienti"):
        n = s.execute(update(t).where(col == o.id).values({col.name: d.id})).rowcount
        if n:
            spostati[t.name] = n
    s.execute(delete(ClienteDoppioneEscluso).where(or_(ClienteDoppioneEscluso.cliente_a_id == o.id, ClienteDoppioneEscluso.cliente_b_id == o.id)))
    spostati["origini"] = origini.sposta(s, "cliente", o.id, d.id)
    for x in list(s.identity_map.values()):
        if getattr(x, "cliente_id", None) == o.id:
            s.expire(x)
    s.delete(o)
    s.flush()
    registro.scrivi(s, utente=attore, azione="cliente.unisci", oggetto_tipo="cliente", oggetto_id=d.id,
                    descrizione=f"Unito il cliente «{prima['origine']['ragione_sociale']}» nel cliente «{d.ragione_sociale}»",
                    dettagli={**prima, "spostati": spostati, "dati_diversi": diversi})
    return d
