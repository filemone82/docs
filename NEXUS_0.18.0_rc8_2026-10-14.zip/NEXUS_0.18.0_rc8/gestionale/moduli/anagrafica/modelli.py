"""Anagrafica: Cliente 1→N Sede operativa 1→N Impianto (decisioni D7–D10, D35, D38, D39, D41, D42, D44).

Documento 03 § 2. Regole principali (nei servizi, controllate anche dal database dove possibile):
- niente cancellazioni se ci sono dati collegati: il database lo impedisce (chiavi esterne RESTRICT);
- l'impianto «dismesso» resta in archivio ma esce dallo scadenziario (D10);
- prossima verifica = ultima verifica + periodicità (D9), ricalcolata a ogni salvataggio.
"""

from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ...core.db import Base, adesso
from ...core.modelli_comuni import Tracciato

# ---------------------------------------------------------------- valori fissi (codice → etichetta)

TIPI_CLIENTE = {  # D42
    "privato": "Privato",
    "pa": "Pubblica amministrazione",
    "condominio": "Condominio",
    "persona_fisica": "Persona fisica",
}

TIPOLOGIE_IMPIANTO = {  # documento 03 § 2.3; modulo di VerbalizzAI tra parentesi
    "terra_bt": "Messa a terra fino a 1.000 V",        # M01
    "terra_at": "Messa a terra oltre 1.000 V",         # M01
    "scariche": "Scariche atmosferiche",              # M02
    "esplosione": "Luoghi con pericolo di esplosione",  # M03
}

FASCE_GABBIA = {  # D44
    "fino_100": "Fino a 100 m²",
    "da_101_a_350": "Da 101 a 350 m²",
    "oltre_350": "Oltre 350 m²",
}

ZONE = ("0", "1", "2", "20", "21", "22")  # 0-1-2 gas/vapori/nebbie, 20-21-22 polveri
PERIODICITA = (2, 5)


def _in(campo: str, valori) -> str:  # noqa: ANN001
    return f"{campo} IN ({', '.join(repr(v) for v in valori)})"


# ---------------------------------------------------------------- tabelle di supporto


class Comune(Base):
    """Elenco ISTAT dei comuni italiani (compila comune, CAP, provincia e regione)."""

    __tablename__ = "comuni"

    codice_istat: Mapped[str] = mapped_column(String(6), primary_key=True)
    nome: Mapped[str] = mapped_column(String(100), index=True)
    sigla: Mapped[str] = mapped_column(String(2))
    provincia: Mapped[str] = mapped_column(String(80))
    regione: Mapped[str] = mapped_column(String(60))
    cap: Mapped[str] = mapped_column(String(600))           # uno o più CAP separati da «|»
    codice_catastale: Mapped[str] = mapped_column(String(4), default="")
    attivo: Mapped[bool] = mapped_column(Boolean, default=True, server_default="1")  # False = soppresso, non più proposto


class ElencoValore(Base, Tracciato):
    """Valori scelti da elenco e modificabili da menu: modalità di pagamento, aliquote IVA."""

    __tablename__ = "elenchi_valori"
    __table_args__ = (UniqueConstraint("elenco", "descrizione"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    elenco: Mapped[str] = mapped_column(String(40), index=True)   # modalita_pagamento | aliquota_iva
    codice: Mapped[str] = mapped_column(String(20), default="")   # es. 22, 22sp, N8c
    descrizione: Mapped[str] = mapped_column(String(200))
    percentuale: Mapped[int | None] = mapped_column(Integer, nullable=True)  # centesimi di punto: 2200 = 22%
    scissione_pagamenti: Mapped[bool] = mapped_column(Boolean, default=False)
    natura: Mapped[str] = mapped_column(String(10), default="")    # natura IVA per la fattura elettronica (N1…N7)
    # 0.14: regole delle modalità di pagamento (codice MP, rate, fine mese…: finanza/pagamenti.py)
    regole_json: Mapped[str] = mapped_column(Text, default="{}", server_default="{}")
    ordine: Mapped[int] = mapped_column(Integer, default=0)
    attivo: Mapped[bool] = mapped_column(Boolean, default=True)


class Commerciale(Base, Tracciato):
    """Commerciale di AD (D35): proposto nel preventivo del cliente."""

    __tablename__ = "commerciali"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    nome: Mapped[str] = mapped_column(String(120), unique=True)
    email: Mapped[str] = mapped_column(String(200), default="")
    telefono: Mapped[str] = mapped_column(String(60), default="")
    utente_id: Mapped[int | None] = mapped_column(ForeignKey("utenti.id", ondelete="SET NULL"), nullable=True)
    attivo: Mapped[bool] = mapped_column(Boolean, default=True)
    note: Mapped[str] = mapped_column(Text, default="")
    # C16 (0.16, Federico 12/10/2026: commerciali «divisi per ambito»): in quali attività lavora
    ambito_dpr: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")
    ambito_dm: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")
    ambito_iec: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")


# ---------------------------------------------------------------- cliente, sede, impianto


class Indirizzo:
    indirizzo: Mapped[str] = mapped_column(String(200), default="")
    comune_istat: Mapped[str | None] = mapped_column(ForeignKey("comuni.codice_istat", ondelete="SET NULL"), nullable=True)
    comune: Mapped[str] = mapped_column(String(100), default="")
    cap: Mapped[str] = mapped_column(String(10), default="")
    provincia: Mapped[str] = mapped_column(String(2), default="")
    regione: Mapped[str] = mapped_column(String(60), default="")


class Cliente(Base, Indirizzo, Tracciato):
    __tablename__ = "clienti"
    __table_args__ = (CheckConstraint(_in("tipo", TIPI_CLIENTE), name="tipo"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ragione_sociale: Mapped[str] = mapped_column(String(250), index=True)
    tipo: Mapped[str] = mapped_column(String(20), default="privato")
    nazione: Mapped[str] = mapped_column(String(2), default="IT")
    partita_iva: Mapped[str] = mapped_column(String(20), default="", index=True)
    codice_fiscale: Mapped[str] = mapped_column(String(20), default="", index=True)
    # D41: due email (verbali e fatture), possono coincidere; più indirizzi separati da «;»
    email_verbali: Mapped[str] = mapped_column(String(500), default="")
    email_fatture: Mapped[str] = mapped_column(String(500), default="")
    pec: Mapped[str] = mapped_column(String(200), default="")
    codice_sdi: Mapped[str] = mapped_column(String(7), default="")
    riferimento_amministrazione: Mapped[str] = mapped_column(String(20), default="")
    commerciale_id: Mapped[int | None] = mapped_column(ForeignKey("commerciali.id", ondelete="RESTRICT"), nullable=True, index=True)
    referente_nome: Mapped[str] = mapped_column(String(120), default="")
    referente_email: Mapped[str] = mapped_column(String(200), default="")
    referente_telefono: Mapped[str] = mapped_column(String(60), default="")
    banca: Mapped[str] = mapped_column(String(120), default="")
    iban: Mapped[str] = mapped_column(String(34), default="")
    dichiarazione_intento: Mapped[bool] = mapped_column(Boolean, default=False)
    dichiarazione_numero: Mapped[str] = mapped_column(String(60), default="")
    dichiarazione_data: Mapped[date | None] = mapped_column(Date, nullable=True)
    ritenuta_percentuale: Mapped[int | None] = mapped_column(Integer, nullable=True)  # centesimi di punto: 400 = 4%
    # 0.12.8 (Garda adsrl `clienti.sconto_def`, regola AD-13): sconto proposto nelle righe dei preventivi AD_DM, centesimi di punto
    sconto_dm: Mapped[int] = mapped_column(Integer, default=0, server_default="0")
    modalita_pagamento_id: Mapped[int | None] = mapped_column(ForeignKey("elenchi_valori.id", ondelete="RESTRICT"), nullable=True)
    aliquota_iva_id: Mapped[int | None] = mapped_column(ForeignKey("elenchi_valori.id", ondelete="RESTRICT"), nullable=True)
    termine_esecuzione: Mapped[str] = mapped_column(String(300), default="", server_default="")  # proposto nei preventivi
    # D38: sconti bloccati di default; li sblocca chi ha il permesso, con motivo
    sconti_ammessi: Mapped[bool] = mapped_column(Boolean, default=False)
    sconti_motivo: Mapped[str] = mapped_column(String(300), default="")
    attivo: Mapped[bool] = mapped_column(Boolean, default=True)
    note: Mapped[str] = mapped_column(Text, default="")
    avvisi: Mapped[str] = mapped_column(Text, default="")              # problemi da controllare (es. dall'importazione)
    codice_esterno: Mapped[str] = mapped_column(String(40), default="")  # riferimento nel gestionale attuale
    # Ambiti di lavoro (R114): anagrafica unica, ma ogni attività vede solo i suoi. Si accendono da soli quando entra
    # un impianto, un'attrezzatura o un preventivo di quell'ambito; si spengono solo a mano e solo se non serve più.
    ambito_dpr: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0", index=True)
    ambito_dm: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0", index=True)
    ambito_iec: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0", index=True)

    commerciale: Mapped[Commerciale | None] = relationship()
    modalita_pagamento: Mapped[ElencoValore | None] = relationship(foreign_keys=[modalita_pagamento_id])
    aliquota_iva: Mapped[ElencoValore | None] = relationship(foreign_keys=[aliquota_iva_id])


class Sede(Base, Indirizzo, Tracciato):
    __tablename__ = "sedi"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    cliente_id: Mapped[int] = mapped_column(ForeignKey("clienti.id", ondelete="RESTRICT"), index=True)
    denominazione: Mapped[str] = mapped_column(String(300), index=True)
    referente_nome: Mapped[str] = mapped_column(String(120), default="")
    referente_email: Mapped[str] = mapped_column(String(200), default="")
    referente_telefono: Mapped[str] = mapped_column(String(60), default="")
    # destinatari dei verbali propri della sede: se compilati prevalgono sull'email verbali del cliente (D41)
    email_verbali: Mapped[str] = mapped_column(String(500), default="")
    email_verbali_cc: Mapped[str] = mapped_column(String(500), default="")
    note_accesso: Mapped[str] = mapped_column(Text, default="")
    attiva: Mapped[bool] = mapped_column(Boolean, default=True)
    note: Mapped[str] = mapped_column(Text, default="")
    avvisi: Mapped[str] = mapped_column(Text, default="")
    codice_esterno: Mapped[str] = mapped_column(String(40), default="")
    # Ambiti di lavoro (R114): anagrafica unica, ma ogni attività vede solo i suoi. Si accendono da soli quando entra
    # un impianto, un'attrezzatura o un preventivo di quell'ambito; si spengono solo a mano e solo se non serve più.
    ambito_dpr: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0", index=True)
    ambito_dm: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0", index=True)
    ambito_iec: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0", index=True)

    cliente: Mapped[Cliente] = relationship()


class Impianto(Base, Tracciato):
    __tablename__ = "impianti"
    __table_args__ = (
        CheckConstraint(_in("tipologia", TIPOLOGIE_IMPIANTO), name="tipologia"),
        CheckConstraint("periodicita_anni IS NULL OR periodicita_anni IN (2, 5)", name="periodicita"),
        CheckConstraint(f"gabbia_fascia = '' OR {_in('gabbia_fascia', FASCE_GABBIA)}", name="gabbia_fascia"),
        CheckConstraint("potenza_kw IS NULL OR potenza_kw >= 0", name="potenza"),
    )

    asset_id: Mapped[int] = mapped_column(ForeignKey("asset.id", ondelete="RESTRICT"), unique=True)
    asset: Mapped["Asset"] = relationship("Asset")
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sede_id: Mapped[int] = mapped_column(ForeignKey("sedi.id", ondelete="RESTRICT"), index=True)
    tipologia: Mapped[str] = mapped_column(String(20))
    denominazione: Mapped[str] = mapped_column(String(300), default="")
    dismesso: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    # matricola INAIL in quattro parti (gestionale attuale)
    matricola_anno: Mapped[str] = mapped_column(String(4), default="")
    matricola_attivita: Mapped[str] = mapped_column(String(10), default="")
    matricola_numero: Mapped[str] = mapped_column(String(20), default="")
    matricola_provincia: Mapped[str] = mapped_column(String(2), default="")
    # messa a terra
    potenza_kw: Mapped[float | None] = mapped_column(Float, nullable=True)
    cabine_mt_bt: Mapped[int | None] = mapped_column(Integer, nullable=True)
    sottostazioni_at_mt: Mapped[int | None] = mapped_column(Integer, nullable=True)
    pod_note: Mapped[str] = mapped_column(Text, default="")  # testi non riconosciuti come POD (es. n. cliente)
    # scariche atmosferiche
    asta: Mapped[bool] = mapped_column(Boolean, default=False)
    numero_aste: Mapped[int | None] = mapped_column(Integer, nullable=True)
    gabbia: Mapped[bool] = mapped_column(Boolean, default=False)
    gabbia_fascia: Mapped[str] = mapped_column(String(20), default="")
    # pericolo di esplosione
    gas: Mapped[bool] = mapped_column(Boolean, default=False)
    polveri: Mapped[bool] = mapped_column(Boolean, default=False)
    zone: Mapped[str] = mapped_column(String(30), default="")  # es. «0, 1, 2, 22»
    # verifiche (D8, D9)
    # 0.4.0 (G39): caratteristiche tecniche lette dall'ultimo verbale caricato (JSON: modulo, verbale, voci)
    caratteristiche: Mapped[str] = mapped_column(Text, default="", server_default="")
    periodicita_anni: Mapped[int | None] = mapped_column(Integer, nullable=True)
    ultima_verifica_data: Mapped[date | None] = mapped_column(Date, nullable=True)
    ultima_verifica_numero: Mapped[str] = mapped_column(String(40), default="")
    prossima_verifica: Mapped[date | None] = mapped_column(Date, nullable=True, index=True)
    prossima_calcolata: Mapped[bool] = mapped_column(Boolean, default=False)  # True = ultima + periodicità
    note: Mapped[str] = mapped_column(Text, default="")
    avvisi: Mapped[str] = mapped_column(Text, default="")
    codice_esterno: Mapped[str] = mapped_column(String(40), default="", index=True)

    sede: Mapped[Sede] = relationship()
    pod: Mapped[list["ImpiantoPod"]] = relationship(back_populates="impianto", cascade="all, delete-orphan",
                                                    order_by="ImpiantoPod.ordine")


class ImpiantoPod(Base):
    """Uno o più POD per impianto (G35): impianto di terra unico con più forniture, un solo verbale."""

    __tablename__ = "impianti_pod"
    __table_args__ = (UniqueConstraint("impianto_id", "pod"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    impianto_id: Mapped[int] = mapped_column(ForeignKey("impianti.id", ondelete="CASCADE"), index=True)
    pod: Mapped[str] = mapped_column(String(20), index=True)
    ordine: Mapped[int] = mapped_column(Integer, default=0)

    impianto: Mapped[Impianto] = relationship(back_populates="pod")


class SedeDoppioneEsclusa(Base):
    """Coppia di sedi che l'utente ha indicato come DIVERSE (R116): non si propongono più come doppioni.
    sede_a_id < sede_b_id."""

    __tablename__ = "sedi_doppioni_esclusi"
    __table_args__ = (UniqueConstraint("sede_a_id", "sede_b_id", name="uq_sedi_doppioni_esclusi"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sede_a_id: Mapped[int] = mapped_column(ForeignKey("sedi.id", ondelete="CASCADE"), index=True)
    sede_b_id: Mapped[int] = mapped_column(ForeignKey("sedi.id", ondelete="CASCADE"), index=True)
    creato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    creato_da: Mapped[str] = mapped_column(String(120), default="")


class Origine(Base):
    """R120 (revisione dell'11/10/2026): corrispondenza fra l'identificativo di un gestionale di provenienza (Garda:
    ingecert, adsrl, iec) e l'oggetto del gestionale integrato. Serve ai riallineamenti e alla migrazione definitiva:
    un oggetto può avere più origini (es. cliente presente in ingecert e in adsrl, sede unita), un'origine porta a un
    solo oggetto. Le attrezzature e gli accessori hanno la loro tabella (asset_origini)."""

    __tablename__ = "origini"
    __table_args__ = (UniqueConstraint("sistema", "tabella", "id_origine", name="uq_origini_sistema_tabella_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sistema: Mapped[str] = mapped_column(String(30))        # garda_ingecert, garda_adsrl, garda_iec, verbalizzai…
    tabella: Mapped[str] = mapped_column(String(60))        # tabella del gestionale di provenienza
    id_origine: Mapped[str] = mapped_column(String(60))
    entita: Mapped[str] = mapped_column(String(30), index=True)   # cliente, sede, impianto, preventivo, riga_preventivo, verifica
    entita_id: Mapped[int] = mapped_column(Integer, index=True)
    creato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    nota: Mapped[str] = mapped_column(String(300), default="")
    # AD-REV-005 (0.12.8): oggetto eliminato. La corrispondenza resta per ricostruire il destino del record importato,
    # ma non vale più per un oggetto nuovo che riusasse lo stesso identificativo.
    eliminato_il: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class ClienteDoppioneEscluso(Base):
    """Coppia di clienti indicati come DIVERSI pur con la stessa partita IVA o lo stesso codice fiscale (es. uffici
    diversi dello stesso ente): non si propongono più come doppioni. cliente_a_id < cliente_b_id."""

    __tablename__ = "clienti_doppioni_esclusi"
    __table_args__ = (UniqueConstraint("cliente_a_id", "cliente_b_id", name="uq_clienti_doppioni_esclusi"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    cliente_a_id: Mapped[int] = mapped_column(ForeignKey("clienti.id", ondelete="CASCADE"), index=True)
    cliente_b_id: Mapped[int] = mapped_column(ForeignKey("clienti.id", ondelete="CASCADE"), index=True)
    creato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    creato_da: Mapped[str] = mapped_column(String(120), default="")
