"""Corrispondenze con i gestionali di provenienza (R120): registrare, cercare, spostare dopo un'unione."""

from __future__ import annotations

from typing import Any

from sqlalchemy import event, select, update
from sqlalchemy.orm import Session

from ...core.db import adesso
from .modelli import Origine

INGECERT, ADSRL, IEC = "garda_ingecert", "garda_adsrl", "garda_iec"


def registra(s: Session, sistema: str, tabella: str, id_origine: object, entita: str, entita_id: int, nota: str = "") -> Origine:
    """Una riga per (sistema, tabella, id): se c'è già e punta altrove, si aggiorna (vale l'ultima importazione)."""
    chiave = str(id_origine)
    o = s.scalar(select(Origine).where(Origine.sistema == sistema, Origine.tabella == tabella, Origine.id_origine == chiave))
    if o is None:
        o = Origine(sistema=sistema, tabella=tabella, id_origine=chiave, entita=entita, entita_id=entita_id, nota=nota[:300])
        s.add(o)
    else:
        o.entita, o.entita_id, o.eliminato_il = entita, entita_id, None
    return o


def registra_molte(s: Session, sistema: str, righe: list[tuple[str, object, str, int]], nota: str = "") -> int:
    """Importazione su archivio nuovo (nessuna origine di quel sistema): inserimento diretto, senza ricerche."""
    s.flush()
    s.add_all([Origine(sistema=sistema, tabella=t, id_origine=str(i), entita=e, entita_id=eid, nota=nota[:300]) for t, i, e, eid in righe])
    return len(righe)


def di(s: Session, entita: str, entita_id: int) -> list[dict]:
    return [{"sistema": o.sistema, "tabella": o.tabella, "id_origine": o.id_origine, "nota": o.nota}
            for o in s.scalars(select(Origine).where(Origine.entita == entita, Origine.entita_id == entita_id,
                                                     Origine.eliminato_il.is_(None)).order_by(Origine.id))]


def trova(s: Session, sistema: str, tabella: str, id_origine: object) -> Origine | None:
    return s.scalar(select(Origine).where(Origine.sistema == sistema, Origine.tabella == tabella, Origine.id_origine == str(id_origine)))


def sposta(s: Session, entita: str, da_id: int, a_id: int) -> int:
    """Dopo un'unione le origini dell'oggetto eliminato passano a quello che resta."""
    return s.execute(update(Origine).where(Origine.entita == entita, Origine.entita_id == da_id, Origine.eliminato_il.is_(None))
                     .values(entita_id=a_id)).rowcount


def _entita_di(obj: Any) -> str | None:
    from ..preventivi.modelli import Preventivo, RigaPreventivo
    from ..verifiche.modelli import Verifica
    from .modelli import Cliente, Impianto, Sede

    for classe, nome in ((Cliente, "cliente"), (Sede, "sede"), (Impianto, "impianto"), (Preventivo, "preventivo"),
                         (RigaPreventivo, "riga_preventivo"), (Verifica, "verifica")):
        if isinstance(obj, classe):
            return nome
    return None


_CHIAVE = "origini_eliminati"


@event.listens_for(Session, "persistent_to_deleted")
def _annota_eliminato(s: Session, obj: Any) -> None:
    """AD-REV-005: ogni oggetto davvero eliminato nel flush — anche gli orfani tolti da una relazione delete-orphan
    (es. «Togli selezionate» nelle righe del preventivo) e le cancellazioni a cascata, che `before_flush` non vede."""
    if (e := _entita_di(obj)) and getattr(obj, "id", None):
        s.info.setdefault(_CHIAVE, []).append((e, obj.id))


@event.listens_for(Session, "after_flush_postexec")
def segna_eliminati(s: Session, _contesto: Any) -> None:
    """AD-REV-005 (0.12.8, completata nella 0.12.9): l'eliminazione fisica di un oggetto importato marca le sue
    corrispondenze come eliminate, nella stessa transazione. Restano consultabili (destino del record importato) ma
    non si attaccano più a un oggetto nuovo che riusasse lo stesso identificativo."""
    eliminati = s.info.pop(_CHIAVE, [])
    if not eliminati:
        return
    quando = adesso()
    for entita, ident in eliminati:
        s.execute(update(Origine).where(Origine.entita == entita, Origine.entita_id == ident, Origine.eliminato_il.is_(None))
                  .values(eliminato_il=quando))


@event.listens_for(Session, "after_rollback")
def _dimentica(s: Session) -> None:
    s.info.pop(_CHIAVE, None)
