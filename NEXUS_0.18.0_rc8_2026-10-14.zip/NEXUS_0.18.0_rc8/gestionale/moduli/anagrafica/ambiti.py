"""Ambiti di lavoro dei clienti (R114, R137).

L'anagrafica è UNICA (un cliente, una partita IVA, un record), ma ci sono clienti solo AD_DPR (impianti D.P.R. 462/01),
solo AD_DM o I&C (attrezzature di lavoro) e clienti con entrambi. Il cliente porta tre indicatori: ambito_dpr,
ambito_dm, ambito_iec. Gli elenchi di clienti, sedi e preventivi mostrano per comodità solo quelli dell'attività scelta
in alto («Attività»); con un clic si vedono tutti.

R137 (0.16, Federico 12/10/2026, 17:15: «deve essere presente in cliente ed estendersi alle sedi operative del
cliente»): l'ambito è un dato del CLIENTE. Le sedi lo ereditano: le loro colonne ambito_* restano nel database come
COPIA di quelle del cliente, aggiornata qui a ogni scrittura, così ricerche e filtri per sede continuano a funzionare.

Regole:
- si ACCENDONO DA SOLI sul cliente, nella stessa transazione, quando su una sua sede entra un oggetto dell'ambito:
  impianto DPR → DPR; attrezzatura o accessorio (SC, SP, GVR, PSV) → DM; preventivo → il suo ambito. Vale per ogni
  scrittura del programma, importazioni comprese.
- si possono accendere a mano sul cliente (cliente nuovo, ancora senza impianti o attrezzature);
- si SPENGONO solo a mano sul cliente, e solo se non servono più: nessuna sua sede ha impianti non dismessi (DPR) o
  attrezzature/accessori non dismessi (DM).
- non sono un controllo di autorizzazione: chi può vedere l'anagrafica vede comunque tutto togliendo il filtro.
I&C non ha ancora oggetti propri (modulo da fare): per ora l'indicatore si gestisce solo a mano.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy import event, func, select
from sqlalchemy.orm import Session

from ...core.errori import ErroreUtente
from .modelli import Cliente, Impianto, Sede

CAMPI = {"DPR": "ambito_dpr", "DM": "ambito_dm", "IEC": "ambito_iec"}
NOMI = {"DPR": "AD_DPR", "DM": "AD_DM", "IEC": "I&C"}
GRUPPI_DM = ("SC", "SP", "GVR", "PSV")


def elenco(x: Any) -> list[str]:
    """Gli ambiti accesi, nell'ordine DPR, DM, IEC."""
    return [a for a, campo in CAMPI.items() if getattr(x, campo)]


def leggi(dati: dict) -> set[str] | None:
    """Gli ambiti scritti in una richiesta («ambiti»: ["DPR","DM"]); None se la richiesta non ne parla."""
    if "ambiti" not in dati:
        return None
    valore = dati.get("ambiti")
    if valore is None:
        valore = []
    if not isinstance(valore, list) or any(a not in CAMPI for a in valore):
        raise ErroreUtente("Ambiti non validi: scegli fra AD_DPR, AD_DM e I&C.")
    return set(valore)


def accendi(x: Any, ambito: str) -> None:
    if not getattr(x, CAMPI[ambito]):
        setattr(x, CAMPI[ambito], True)


def _in_uso_sede(s: Session, sede_id: int, ambito: str) -> int:
    from ..beni.modelli import Asset

    if ambito == "DPR":
        return s.scalar(select(func.count(Impianto.id)).where(Impianto.sede_id == sede_id, Impianto.dismesso.is_(False))) or 0
    if ambito == "DM":
        return s.scalar(select(func.count(Asset.id)).where(Asset.sede_id == sede_id, Asset.gruppo.in_(GRUPPI_DM),
                                                           Asset.dismesso.is_(False))) or 0
    return 0


def applica_cliente(s: Session, c: Cliente, voluti: set[str] | None) -> None:
    if voluti is None:
        return
    for ambito, campo in CAMPI.items():
        if ambito in voluti:
            setattr(c, campo, True)
        elif getattr(c, campo) and c.id is not None:
            in_uso = [(x.denominazione, n) for x in s.scalars(select(Sede).where(Sede.cliente_id == c.id))
                      if (n := _in_uso_sede(s, x.id, ambito))]
            if in_uso:
                cosa = "impianti" if ambito == "DPR" else "attrezzature o accessori"
                raise ErroreUtente(f"{NOMI[ambito]} non si può togliere al cliente: hanno ancora {cosa} non dismessi le sedi "
                                   + ", ".join(f"«{d}» ({n})" for d, n in in_uso[:5]) + ".")
            setattr(c, campo, False)


def applica_sede(s: Session, x: Sede, voluti: set[str] | None, cliente: Cliente) -> None:
    """R137: la sede eredita sempre gli ambiti del cliente; un valore diverso inviato per la sede non si accetta."""
    if voluti is not None and voluti != set(elenco(cliente)):
        raise ErroreUtente("L'ambito (AD_DPR, AD_DM, I&C) si imposta sul cliente e vale per tutte le sue sedi: "
                           "cambialo dalla scheda del cliente.")
    eredita(x, cliente)


def eredita(x: Sede, cliente: Cliente) -> None:
    for campo in CAMPI.values():
        if getattr(x, campo) != bool(getattr(cliente, campo)):
            setattr(x, campo, bool(getattr(cliente, campo)))


@event.listens_for(Session, "before_flush")
def accendi_ambiti(s: Session, _contesto: Any, _istanze: Any) -> None:
    from ..beni.modelli import Asset
    from ..preventivi.modelli import Preventivo

    clienti: dict[int, tuple[Cliente, set[str]]] = {}
    with s.no_autoflush:
        def cliente_di_sede(oggetto: Any) -> Cliente | None:
            x = oggetto.sede if getattr(oggetto, "sede", None) is not None else (s.get(Sede, oggetto.sede_id) if oggetto.sede_id else None)
            if x is None:
                return None
            return x.cliente if x.cliente is not None else (s.get(Cliente, x.cliente_id) if x.cliente_id else None)

        def segna(c: Cliente | None, ambito: str | None = None) -> None:
            if c is not None:
                voce = clienti.setdefault(id(c), (c, set()))
                if ambito:
                    voce[1].add(ambito)

        for o in list(s.new) + list(s.dirty):
            if o in s.deleted:
                continue
            if isinstance(o, Impianto):
                segna(cliente_di_sede(o), "DPR")
            elif isinstance(o, Asset) and o.gruppo in GRUPPI_DM:
                segna(cliente_di_sede(o), "DM")
            elif isinstance(o, Preventivo) and o.ambito in CAMPI:
                c = o.cliente if getattr(o, "cliente", None) is not None else (s.get(Cliente, o.cliente_id) if o.cliente_id else None)
                segna(c or (cliente_di_sede(o) if o.sede_id else None), o.ambito)
            elif isinstance(o, Sede):
                c = o.cliente if o.cliente is not None else (s.get(Cliente, o.cliente_id) if o.cliente_id else None)
                if c is not None:
                    segna(c)
                    eredita(o, c)
            elif isinstance(o, Cliente):
                segna(o)
        for c, ambiti in clienti.values():
            for a in ambiti:
                accendi(c, a)
            # R137: le sedi del cliente copiano i suoi ambiti (anche quelle non caricate in questa sessione)
            if c.id is not None:
                for x in s.scalars(select(Sede).where(Sede.cliente_id == c.id)):
                    eredita(x, c)
            for x in list(s.new):
                if isinstance(x, Sede) and (x.cliente is c or x.cliente_id == c.id):
                    eredita(x, c)
