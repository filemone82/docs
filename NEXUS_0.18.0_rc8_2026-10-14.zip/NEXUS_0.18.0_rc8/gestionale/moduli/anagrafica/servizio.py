"""Regole dell'anagrafica: clienti, sedi operative, impianti, commerciali, elenchi di valori, comuni.

Principi (documento 03 § 3):
- ogni scrittura controlla la versione (due persone sulla stessa scheda → la seconda viene avvisata);
- ogni creazione, modifica, eliminazione resta nel registro delle operazioni con «prima / dopo»;
- si elimina solo ciò che non ha dati collegati; altrimenti si disattiva (cliente, sede) o si dismette (impianto);
- prossima verifica = ultima verifica + periodicità (D9); senza ultima verifica si scrive a mano.
"""

from __future__ import annotations

import json

import calendar
import csv
from datetime import date, timedelta
from pathlib import Path
from typing import Any

from sqlalchemy import func, insert, select
from sqlalchemy.orm import Session

from ...core import validazioni as v
from ...core.date import iso_locale
from ...core.db import adesso
from ...core.errori import Conflitto, ErroreUtente, NonTrovato
from ..registro import servizio as registro
from . import ambiti
from .modelli import (FASCE_GABBIA, PERIODICITA, TIPI_CLIENTE, TIPOLOGIE_IMPIANTO, ZONE, Cliente, Commerciale, Comune,
                      ElencoValore, Impianto, ImpiantoPod, Sede)

FILE_COMUNI = Path(__file__).resolve().parents[2] / "dati" / "comuni_istat.csv"

ELENCHI = {
    "modalita_pagamento": "Modalità di pagamento",
    "aliquota_iva": "Aliquote IVA",
    "termine_esecuzione": "Termini di esecuzione",   # 0.12.9 (Federico, 12/10/2026): proposti nel preventivo
}

# Valori di partenza (ricavati dall'anagrafica del gestionale attuale, 04/10/2026); si cambiano da menu.
MODALITA_PARTENZA = ["Rimessa diretta", "Bonifico 30 gg F.M.", "Bonifico 60 gg F.M.", "Bonifico 90 gg F.M.",
                     "Bonifico 120 gg F.M.", "Bonifico 30 gg D.F.", "Bonifico 60 gg D.F.", "Ri.Ba. 30 gg F.M."]
# 0.12.9: proposte di partenza, da cambiare in Gestione › Configurazione › Termini di esecuzione
TERMINI_PARTENZA = ["30 gg. da conferma d'ordine", "60 gg. da conferma d'ordine", "Entro la scadenza della verifica",
                    "Da concordare con il cliente"]
ALIQUOTE_PARTENZA = [
    # codice, descrizione, percentuale (centesimi di punto), scissione dei pagamenti, natura
    ("22", "22 - Imponibile 22%", 2200, False, ""),
    ("22sp", "22sp - Imp. 22% con scissione pagamenti", 2200, True, ""),
    ("N8c", "N8c - Non imp. art. 8 c. 1 lett. c DPR 633/72", 0, False, "N3.5"),
]


# ---------------------------------------------------------------- strumenti comuni


def _t(dati: dict, campo: str, massimo: int = 300) -> str:
    return str(dati.get(campo) or "").strip()[:massimo]


def _b(dati: dict, campo: str) -> bool:
    x = dati.get(campo)
    return x is True or str(x).lower() in ("true", "1", "sì", "si", "on")


def _intero(dati: dict, campo: str, etichetta: str, minimo: int = 0) -> int | None:
    x = dati.get(campo)
    if x in (None, ""):
        return None
    try:
        n = int(str(x).strip())
    except ValueError:
        raise ErroreUtente(f"{etichetta}: scrivi un numero intero.") from None
    if n < minimo:
        raise ErroreUtente(f"{etichetta}: il numero non può essere minore di {minimo}.")
    return n


def _decimale(dati: dict, campo: str, etichetta: str) -> float | None:
    x = dati.get(campo)
    if x in (None, ""):
        return None
    try:
        n = v.numero_italiano(x)
    except ValueError:
        raise ErroreUtente(f"{etichetta}: scrivi un numero (virgola per i decimali).") from None
    if n < 0:
        raise ErroreUtente(f"{etichetta}: il numero non può essere negativo.")
    return n


def _data(dati: dict, campo: str, etichetta: str) -> date | None:
    x = dati.get(campo)
    if x in (None, ""):
        return None
    if isinstance(x, date):
        return x
    t = str(x).strip()
    try:
        if "/" in t:
            g, m, a = t.split("/")
            return date(int(a), int(m), int(g))
        return date.fromisoformat(t[:10])
    except ValueError:
        raise ErroreUtente(f"{etichetta}: data non valida (gg/mm/aaaa).") from None


def _percentuale(dati: dict, campo: str, etichetta: str) -> int | None:
    n = _decimale(dati, campo, etichetta)
    if n is None:
        return None
    if n > 100:
        raise ErroreUtente(f"{etichetta}: la percentuale non può superare 100.")
    return int(round(n * 100))


def controlla_versione(oggetto: Any, versione: Any) -> None:
    if versione not in (None, "") and int(versione) != oggetto.versione:
        raise Conflitto()


def _crea(s: Session, oggetto: Any, attore: Any) -> None:
    oggetto.creato_da = oggetto.modificato_da = getattr(attore, "nome", "") or "Sistema"
    oggetto.creato_il = oggetto.modificato_il = adesso()
    s.add(oggetto)
    s.flush()


def _modificato(oggetto: Any, attore: Any) -> None:
    oggetto.versione += 1
    oggetto.modificato_il = adesso()
    oggetto.modificato_da = getattr(attore, "nome", "") or "Sistema"


def scadenza(ultima: date, anni: int) -> date:
    """Prossima verifica: ultima verifica + periodicità, MENO UN GIORNO, come fa il gestionale attuale
    (es. verifica del 10/12/2024 ogni 2 anni → prossima entro il 09/12/2026). Da confermare (doc. 04, G36)."""
    return aggiungi_anni(ultima, anni) - timedelta(days=1)


def aggiungi_anni(d: date, anni: int) -> date:
    """Stessa data N anni dopo; il 29 febbraio diventa 28 febbraio negli anni non bisestili."""
    a = d.year + anni
    return date(a, d.month, min(d.day, calendar.monthrange(a, d.month)[1]))


# ---------------------------------------------------------------- comuni ISTAT


def carica_comuni(s: Session) -> int:
    """Carica l'elenco ISTAT dei comuni la prima volta (circa 7.900 righe, un secondo)."""
    if s.execute(select(func.count()).select_from(Comune)).scalar():
        return 0
    with FILE_COMUNI.open(encoding="utf-8") as f:
        righe = [{"codice_istat": r["codice_istat"], "nome": r["nome"], "sigla": r["sigla"], "provincia": r["provincia"],
                  "regione": r["regione"], "cap": r["cap"], "codice_catastale": r["codice_catastale"]}
                 for r in csv.DictReader(f, delimiter=";")]
    s.execute(insert(Comune), righe)
    return len(righe)


def cerca_comuni(s: Session, testo: str, limite: int = 15) -> list[dict]:
    t = (testo or "").strip()
    if len(t) < 2:
        return []
    attivi = Comune.attivo.is_(True)
    q = select(Comune).where(attivi, func.lower(Comune.nome).like(f"{t.lower()}%")).order_by(func.length(Comune.nome), Comune.nome).limit(limite)
    trovati = list(s.execute(q).scalars())
    if len(trovati) < limite:
        altri = select(Comune).where(attivi, func.lower(Comune.nome).like(f"%{t.lower()}%"), ~Comune.codice_istat.in_([c.codice_istat for c in trovati]))
        trovati += list(s.execute(altri.order_by(Comune.nome).limit(limite - len(trovati))).scalars())
    return [comune_json(c) for c in trovati]


def comune_json(c: Comune) -> dict:
    cap = c.cap.split("|")
    return {"codice_istat": c.codice_istat, "nome": c.nome, "sigla": c.sigla, "provincia": c.provincia,
            "regione": c.regione, "cap": cap, "etichetta": f"{c.nome} ({c.sigla})"}


def dati_comune(c: Comune) -> dict:
    return {"codice_istat": c.codice_istat, "nome": c.nome, "sigla": c.sigla, "provincia": c.provincia, "regione": c.regione,
            "cap": c.cap.split("|"), "codice_catastale": c.codice_catastale, "attivo": c.attivo}


def salva_comune(s: Session, attore: Any, dati: dict, codice_istat: str | None = None) -> Comune:
    """Menu dei comuni (D49): correggere CAP o dati, aggiungere comuni nuovi, togliere quelli soppressi."""
    import re

    if codice_istat:
        c = s.get(Comune, codice_istat)
        if c is None:
            raise NonTrovato("Comune non trovato.")
        prima = dati_comune(c)
    else:
        codice = _t(dati, "codice_istat", 6)
        if not re.fullmatch(r"\d{6}", codice):
            raise ErroreUtente("Codice ISTAT: 6 cifre (es. 001314 per Volpiano).")
        if s.get(Comune, codice) is not None:
            raise ErroreUtente(f"Il codice ISTAT {codice} c'è già.")
        c, prima = Comune(codice_istat=codice), None
    c.nome = _t(dati, "nome", 100)
    c.sigla = _t(dati, "sigla", 2).upper()
    c.provincia = _t(dati, "provincia", 80)
    c.regione = _t(dati, "regione", 60)
    if not (c.nome and len(c.sigla) == 2 and c.regione):
        raise ErroreUtente("Scrivi nome, sigla della provincia (2 lettere) e regione.")
    elenco = dati.get("cap") or []
    if isinstance(elenco, str):
        elenco = re.split(r"[\s,;|]+", elenco)
    elenco = [v.normalizza_cap(x) for x in elenco if str(x).strip()]
    if not elenco:
        raise ErroreUtente("Scrivi almeno un CAP.")
    c.cap = "|".join(dict.fromkeys(elenco))
    c.codice_catastale = _t(dati, "codice_catastale", 4).upper()
    c.attivo = _b(dati, "attivo") if "attivo" in dati else True
    if prima is None:
        s.add(c)
    s.flush()
    dopo = dati_comune(c)
    registro.scrivi(s, utente=attore, azione="comune.crea" if prima is None else "comune.modifica", oggetto_tipo="comune",
                    oggetto_id=c.codice_istat, descrizione=f"Elenco comuni: {'aggiunto' if prima is None else 'modificato'} «{c.nome} ({c.sigla})»",
                    dettagli={"dopo": dopo} if prima is None else {"modifiche": registro.differenze(prima, dopo)})
    return c


def trova_comune(s: Session, nome: str, sigla: str = "") -> Comune | None:
    if not nome:
        return None
    q = select(Comune).where(func.lower(Comune.nome) == nome.strip().lower(), Comune.attivo.is_(True))
    trovati = list(s.execute(q).scalars())
    if sigla:
        stessi = [c for c in trovati if c.sigla == sigla.strip().upper()]
        trovati = stessi or trovati
    return trovati[0] if len(trovati) == 1 or (trovati and sigla) else None


def applica_indirizzo(s: Session, oggetto: Any, dati: dict) -> None:
    """Indirizzo con ricerca del comune (D49): dal codice ISTAT si compilano comune, provincia e regione;
    il CAP si propone se il comune ne ha uno solo. Se il comune è scritto a mano ma c'è nell'elenco,
    viene riconosciuto da solo; altrimenti (estero, non in elenco) resta come scritto."""
    oggetto.indirizzo = _t(dati, "indirizzo", 200)
    codice = _t(dati, "comune_istat", 6)
    cap = v.normalizza_cap(dati.get("cap"))
    if not codice and _t(dati, "comune", 100):
        trovato = trova_comune(s, _t(dati, "comune", 100), _t(dati, "provincia", 2))
        codice = trovato.codice_istat if trovato else ""
    if codice:
        c = s.get(Comune, codice)
        if c is None:
            raise ErroreUtente("Comune non trovato nell'elenco ISTAT: cercalo di nuovo.")
        elenco_cap = c.cap.split("|")
        if not cap and len(elenco_cap) == 1:
            cap = elenco_cap[0]
        oggetto.comune_istat, oggetto.comune, oggetto.provincia, oggetto.regione = c.codice_istat, c.nome, c.sigla, c.regione
    else:  # comune estero o non in elenco: si scrive a mano
        oggetto.comune_istat = None
        oggetto.comune = _t(dati, "comune", 100)
        oggetto.provincia = _t(dati, "provincia", 2).upper()
        oggetto.regione = _t(dati, "regione", 60)
    oggetto.cap = cap


def _indirizzo(o: Any) -> dict:
    return {"indirizzo": o.indirizzo, "comune_istat": o.comune_istat, "comune": o.comune, "cap": o.cap,
            "provincia": o.provincia, "regione": o.regione}


# ---------------------------------------------------------------- elenchi di valori


def prepara_elenchi(s: Session) -> None:
    """Valori di partenza di ogni elenco ancora vuoto (anche negli archivi nati prima di un elenco nuovo)."""
    presenti = set(s.scalars(select(ElencoValore.elenco).distinct()))
    if "modalita_pagamento" not in presenti:
        for i, d in enumerate(MODALITA_PARTENZA):
            s.add(ElencoValore(elenco="modalita_pagamento", descrizione=d, ordine=i, creato_da="Sistema", modificato_da="Sistema"))
    if "aliquota_iva" not in presenti:
        for i, (codice, d, perc, split, natura) in enumerate(ALIQUOTE_PARTENZA):
            s.add(ElencoValore(elenco="aliquota_iva", codice=codice, descrizione=d, percentuale=perc, scissione_pagamenti=split,
                               natura=natura, ordine=i, creato_da="Sistema", modificato_da="Sistema"))
    if "termine_esecuzione" not in presenti:
        for i, d in enumerate(TERMINI_PARTENZA):
            s.add(ElencoValore(elenco="termine_esecuzione", descrizione=d, ordine=i, creato_da="Sistema", modificato_da="Sistema"))
    s.flush()


def elenco_json(x: ElencoValore) -> dict:
    return {"id": x.id, "elenco": x.elenco, "codice": x.codice, "descrizione": x.descrizione,
            "percentuale": None if x.percentuale is None else x.percentuale / 100, "scissione_pagamenti": x.scissione_pagamenti,
            "natura": x.natura, "ordine": x.ordine, "attivo": x.attivo, "versione": x.versione}


def valori_elenco(s: Session, elenco: str, anche_disattivi: bool = True) -> list[dict]:
    q = select(ElencoValore).where(ElencoValore.elenco == elenco)
    if not anche_disattivi:
        q = q.where(ElencoValore.attivo.is_(True))
    return [elenco_json(x) for x in s.execute(q.order_by(ElencoValore.ordine, ElencoValore.descrizione)).scalars()]


def salva_valore(s: Session, attore: Any, dati: dict, valore_id: int | None = None) -> ElencoValore:
    elenco = _t(dati, "elenco", 40)
    if elenco not in ELENCHI:
        raise ErroreUtente("Elenco sconosciuto.")
    descrizione = _t(dati, "descrizione", 200)
    if not descrizione:
        raise ErroreUtente("Scrivi la descrizione.")
    doppio = s.execute(select(ElencoValore).where(ElencoValore.elenco == elenco, func.lower(ElencoValore.descrizione) == descrizione.lower(),
                                                  ElencoValore.id != (valore_id or 0))).scalar()
    if doppio:
        raise ErroreUtente(f"«{descrizione}» c'è già in questo elenco.")
    if valore_id:
        x = s.get(ElencoValore, valore_id)
        if x is None:
            raise NonTrovato("Valore non trovato.")
        controlla_versione(x, dati.get("versione"))
        prima = elenco_json(x)
    else:
        x, prima = ElencoValore(elenco=elenco), None
    x.descrizione, x.codice = descrizione, _t(dati, "codice", 20)
    x.percentuale = _percentuale(dati, "percentuale", "Percentuale")
    x.scissione_pagamenti, x.natura = _b(dati, "scissione_pagamenti"), _t(dati, "natura", 10).upper()
    x.attivo = _b(dati, "attivo") if "attivo" in dati else True
    x.ordine = _intero(dati, "ordine", "Ordine") or 0
    if prima is None:
        _crea(s, x, attore)
    else:
        _modificato(x, attore)
    s.flush()
    registro.scrivi(s, utente=attore, azione="elenco.crea" if prima is None else "elenco.modifica", oggetto_tipo="elenco_valore",
                    oggetto_id=x.id, descrizione=f"{ELENCHI[elenco]}: {'aggiunto' if prima is None else 'modificato'} «{x.descrizione}»",
                    dettagli={"dopo": elenco_json(x)} if prima is None else {"modifiche": registro.differenze(prima, elenco_json(x))})
    return x


def _valore_elenco(s: Session, elenco: str, valore_id: Any, etichetta: str) -> int | None:
    if valore_id in (None, ""):
        return None
    x = s.get(ElencoValore, int(valore_id))
    if x is None or x.elenco != elenco:
        raise ErroreUtente(f"{etichetta}: valore non trovato, ricarica la pagina.")
    return x.id


# ---------------------------------------------------------------- commerciali (D35)


def commerciale_json(c: Commerciale) -> dict:
    return {"id": c.id, "nome": c.nome, "email": c.email, "telefono": c.telefono, "utente_id": c.utente_id,
            "attivo": c.attivo, "note": c.note, "versione": c.versione, "ambiti": ambiti.elenco(c)}


def salva_commerciale(s: Session, attore: Any, dati: dict, commerciale_id: int | None = None) -> Commerciale:
    nome = _t(dati, "nome", 120)
    if not nome:
        raise ErroreUtente("Scrivi nome e cognome del commerciale.")
    if s.execute(select(Commerciale).where(func.lower(Commerciale.nome) == nome.lower(), Commerciale.id != (commerciale_id or 0))).scalar():
        raise ErroreUtente(f"Esiste già un commerciale «{nome}».")
    if commerciale_id:
        c = s.get(Commerciale, commerciale_id)
        if c is None:
            raise NonTrovato("Commerciale non trovato.")
        controlla_versione(c, dati.get("versione"))
        prima = commerciale_json(c)
    else:
        c, prima = Commerciale(), None
    c.nome = nome
    c.email = v.normalizza_email(dati.get("email"), "Email", multipla=False)
    c.telefono = _t(dati, "telefono", 60)
    c.utente_id = int(dati["utente_id"]) if dati.get("utente_id") else None
    c.attivo = _b(dati, "attivo") if "attivo" in dati else True
    c.note = _t(dati, "note", 4000)
    voluti = ambiti.leggi(dati)  # C16: attività del commerciale; un commerciale nuovo senza indicazioni è AD_DPR
    if voluti is None and prima is None:
        voluti = {"DPR"}
    if voluti is not None:
        if not voluti:
            raise ErroreUtente("Indica almeno un'attività del commerciale (AD_DPR, AD_DM, I&C).")
        for a, campo in ambiti.CAMPI.items():
            setattr(c, campo, a in voluti)
    if prima is None:
        _crea(s, c, attore)
    else:
        _modificato(c, attore)
    s.flush()
    registro.scrivi(s, utente=attore, azione="commerciale.crea" if prima is None else "commerciale.modifica", oggetto_tipo="commerciale",
                    oggetto_id=c.id, descrizione=f"{'Creato' if prima is None else 'Modificato'} il commerciale «{c.nome}»",
                    dettagli={"dopo": commerciale_json(c)} if prima is None else {"modifiche": registro.differenze(prima, commerciale_json(c))})
    return c


# ---------------------------------------------------------------- clienti


def cliente_o_404(s: Session, cliente_id: int) -> Cliente:
    c = s.get(Cliente, cliente_id)
    if c is None:
        raise NonTrovato("Cliente non trovato: forse è stato eliminato. Ricarica la pagina.")
    return c


def dati_cliente(c: Cliente) -> dict:
    return {
        "ragione_sociale": c.ragione_sociale, "tipo": c.tipo, "nazione": c.nazione, **_indirizzo(c),
        "partita_iva": c.partita_iva, "codice_fiscale": c.codice_fiscale, "email_verbali": c.email_verbali,
        "email_fatture": c.email_fatture, "pec": c.pec, "codice_sdi": c.codice_sdi,
        "riferimento_amministrazione": c.riferimento_amministrazione, "commerciale_id": c.commerciale_id,
        "referente_nome": c.referente_nome, "referente_email": c.referente_email, "referente_telefono": c.referente_telefono,
        "banca": c.banca, "iban": c.iban, "dichiarazione_intento": c.dichiarazione_intento,
        "dichiarazione_numero": c.dichiarazione_numero,
        "dichiarazione_data": c.dichiarazione_data.isoformat() if c.dichiarazione_data else None,
        "ritenuta_percentuale": None if c.ritenuta_percentuale is None else c.ritenuta_percentuale / 100,
        "sconto_dm": (c.sconto_dm or 0) / 100,
        "modalita_pagamento_id": c.modalita_pagamento_id, "aliquota_iva_id": c.aliquota_iva_id, "termine_esecuzione": c.termine_esecuzione,
        "sconti_ammessi": c.sconti_ammessi, "sconti_motivo": c.sconti_motivo, "attivo": c.attivo, "note": c.note,
        "avvisi": c.avvisi, "codice_esterno": c.codice_esterno, "ambiti": ambiti.elenco(c),
    }


def cliente_json(s: Session, c: Cliente) -> dict:
    n_sedi = s.execute(select(func.count()).select_from(Sede).where(Sede.cliente_id == c.id)).scalar()
    n_impianti = s.execute(select(func.count()).select_from(Impianto).join(Sede).where(Sede.cliente_id == c.id)).scalar()
    from . import origini
    from ..beni.modelli import Asset

    n_attrezzature = s.execute(select(func.count()).select_from(Asset).join(Sede, Asset.sede_id == Sede.id).where(
        Sede.cliente_id == c.id, Asset.gruppo.in_(ambiti.GRUPPI_DM), Asset.dismesso.is_(False))).scalar()
    return {"id": c.id, **dati_cliente(c), "versione": c.versione, "n_sedi": n_sedi, "n_impianti": n_impianti,
            "n_attrezzature": n_attrezzature, "origini": origini.di(s, "cliente", c.id),
            "creato_il": iso_locale(c.creato_il), "creato_da": c.creato_da,
            "modificato_il": iso_locale(c.modificato_il), "modificato_da": c.modificato_da}


def _compila_cliente(s: Session, c: Cliente, dati: dict) -> None:
    c.ragione_sociale = _t(dati, "ragione_sociale", 250)
    if not c.ragione_sociale:
        raise ErroreUtente("Scrivi la ragione sociale (o nome e cognome per le persone fisiche).")
    tipo = _t(dati, "tipo", 20) or "privato"
    if tipo not in TIPI_CLIENTE:
        raise ErroreUtente("Tipo di cliente non valido.")
    c.tipo = tipo
    c.nazione = (_t(dati, "nazione", 2) or "IT").upper()
    applica_indirizzo(s, c, dati)
    c.partita_iva = v.normalizza_partita_iva(dati.get("partita_iva"), c.nazione)
    c.codice_fiscale = v.normalizza_codice_fiscale(dati.get("codice_fiscale"), c.nazione)
    if c.nazione == "IT" and not c.codice_fiscale:  # D48: il codice fiscale è sempre obbligatorio, la P.IVA no
        raise ErroreUtente("Scrivi il codice fiscale: è obbligatorio (per le società di solito coincide con la partita IVA).")
    if c.tipo == "persona_fisica" and c.codice_fiscale and len(c.codice_fiscale) != 16 and c.nazione == "IT":
        raise ErroreUtente("Per una persona fisica il codice fiscale ha 16 caratteri.")
    c.email_verbali = v.normalizza_email(dati.get("email_verbali"), "Email per i verbali")
    c.email_fatture = v.normalizza_email(dati.get("email_fatture"), "Email per le fatture")
    c.pec = v.normalizza_email(dati.get("pec"), "PEC", multipla=False)
    c.codice_sdi = v.normalizza_sdi(dati.get("codice_sdi"))
    if c.tipo == "pa" and c.codice_sdi and len(c.codice_sdi) != 6:
        raise ErroreUtente("Per la pubblica amministrazione il codice destinatario è il codice ufficio di 6 caratteri.")
    c.riferimento_amministrazione = _t(dati, "riferimento_amministrazione", 20)
    commerciale = dati.get("commerciale_id")
    if commerciale not in (None, ""):
        com = s.get(Commerciale, int(commerciale))
        if com is None:
            raise ErroreUtente("Commerciale non trovato: ricarica la pagina.")
        if not com.attivo and com.id != c.commerciale_id:
            raise ErroreUtente(f"Il commerciale «{com.nome}» non è più attivo: scegline un altro.")
        c.commerciale_id = com.id
    else:
        c.commerciale_id = None
    c.referente_nome = _t(dati, "referente_nome", 120)
    c.referente_email = v.normalizza_email(dati.get("referente_email"), "Email del referente")
    c.referente_telefono = _t(dati, "referente_telefono", 60)
    c.banca = _t(dati, "banca", 120)
    c.iban = v.normalizza_iban(dati.get("iban"))
    c.dichiarazione_intento = _b(dati, "dichiarazione_intento")
    c.dichiarazione_numero = _t(dati, "dichiarazione_numero", 60) if c.dichiarazione_intento else ""
    c.dichiarazione_data = _data(dati, "dichiarazione_data", "Data della dichiarazione d'intento") if c.dichiarazione_intento else None
    if c.dichiarazione_intento and not (c.dichiarazione_numero and c.dichiarazione_data):
        raise ErroreUtente("Dichiarazione d'intento: scrivi numero e data (oppure togli la spunta).")
    c.ritenuta_percentuale = _percentuale(dati, "ritenuta_percentuale", "Ritenuta d'acconto")
    if "sconto_dm" in dati:
        c.sconto_dm = _percentuale(dati, "sconto_dm", "Sconto predefinito AD_DM") or 0
    c.modalita_pagamento_id = _valore_elenco(s, "modalita_pagamento", dati.get("modalita_pagamento_id"), "Modalità di pagamento")
    c.aliquota_iva_id = _valore_elenco(s, "aliquota_iva", dati.get("aliquota_iva_id"), "Aliquota IVA")
    c.termine_esecuzione = _t(dati, "termine_esecuzione", 300)
    c.note = _t(dati, "note", 8000)
    c.avvisi = _t(dati, "avvisi", 8000)
    c.codice_esterno = _t(dati, "codice_esterno", 40)
    ambiti.applica_cliente(s, c, ambiti.leggi(dati))


def crea_cliente(s: Session, attore: Any, dati: dict) -> Cliente:
    c = Cliente()
    _compila_cliente(s, c, dati)
    _crea(s, c, attore)
    registro.scrivi(s, utente=attore, azione="cliente.crea", oggetto_tipo="cliente", oggetto_id=c.id,
                    descrizione=f"Creato il cliente «{c.ragione_sociale}»", dettagli={"dopo": dati_cliente(c)})
    return c


def modifica_cliente(s: Session, attore: Any, cliente_id: int, dati: dict) -> Cliente:
    c = cliente_o_404(s, cliente_id)
    controlla_versione(c, dati.get("versione"))
    prima = dati_cliente(c)
    sconti, motivo, attivo = c.sconti_ammessi, c.sconti_motivo, c.attivo  # cambiano solo con operazioni apposite
    _compila_cliente(s, c, dati)
    c.sconti_ammessi, c.sconti_motivo, c.attivo = sconti, motivo, attivo
    modifiche = registro.differenze(prima, dati_cliente(c))
    if modifiche:
        _modificato(c, attore)
        registro.scrivi(s, utente=attore, azione="cliente.modifica", oggetto_tipo="cliente", oggetto_id=c.id,
                        descrizione=f"Modificato il cliente «{c.ragione_sociale}»", dettagli={"modifiche": modifiche})
    return c


def imposta_attivo_cliente(s: Session, attore: Any, cliente_id: int, attivo: bool, versione: Any) -> Cliente:
    c = cliente_o_404(s, cliente_id)
    controlla_versione(c, versione)
    if c.attivo == attivo:
        return c
    c.attivo = attivo
    _modificato(c, attore)
    registro.scrivi(s, utente=attore, azione="cliente.riattiva" if attivo else "cliente.disattiva", oggetto_tipo="cliente",
                    oggetto_id=c.id, descrizione=f"{'Riattivato' if attivo else 'Disattivato'} il cliente «{c.ragione_sociale}»")
    return c


def imposta_sconti(s: Session, attore: Any, cliente_id: int, ammessi: bool, motivo: str, versione: Any) -> Cliente:
    """D38: sconti bloccati di default; si sbloccano sul singolo cliente con un motivo registrato."""
    c = cliente_o_404(s, cliente_id)
    controlla_versione(c, versione)
    motivo = (motivo or "").strip()[:300]
    if ammessi and not motivo:
        raise ErroreUtente("Scrivi il motivo per cui il cliente può avere sconti (es. pubblica amministrazione, gara).")
    c.sconti_ammessi, c.sconti_motivo = ammessi, motivo if ammessi else ""
    _modificato(c, attore)
    registro.scrivi(s, utente=attore, azione="cliente.sconti_sblocca" if ammessi else "cliente.sconti_blocca", oggetto_tipo="cliente",
                    oggetto_id=c.id, descrizione=f"Sconti {'sbloccati' if ammessi else 'bloccati'} per «{c.ragione_sociale}»"
                    + (f": {motivo}" if ammessi else ""))
    return c


def elimina_cliente(s: Session, attore: Any, cliente_id: int) -> None:
    c = cliente_o_404(s, cliente_id)
    n = s.execute(select(func.count()).select_from(Sede).where(Sede.cliente_id == c.id)).scalar()
    if n:
        raise ErroreUtente(f"Il cliente ha {n} sedi operative: non si può eliminare. Se non è più cliente, disattivalo.")
    dati = dati_cliente(c)
    s.delete(c)
    s.flush()
    registro.scrivi(s, utente=attore, azione="cliente.elimina", oggetto_tipo="cliente", oggetto_id=cliente_id,
                    descrizione=f"Eliminato il cliente «{dati['ragione_sociale']}» (senza sedi)", dettagli={"prima": dati})


# ---------------------------------------------------------------- sedi operative


def sede_o_404(s: Session, sede_id: int) -> Sede:
    x = s.get(Sede, sede_id)
    if x is None:
        raise NonTrovato("Sede operativa non trovata: forse è stata eliminata. Ricarica la pagina.")
    return x


def dati_sede(x: Sede) -> dict:
    return {"cliente_id": x.cliente_id, "denominazione": x.denominazione, **_indirizzo(x),
            "referente_nome": x.referente_nome, "referente_email": x.referente_email, "referente_telefono": x.referente_telefono,
            "email_verbali": x.email_verbali, "email_verbali_cc": x.email_verbali_cc, "note_accesso": x.note_accesso,
            "attiva": x.attiva, "note": x.note, "avvisi": x.avvisi, "codice_esterno": x.codice_esterno,
            "ambiti": ambiti.elenco(x)}


def sede_json(s: Session, x: Sede) -> dict:
    from . import origini
    from ..beni.modelli import Asset

    n = s.execute(select(func.count()).select_from(Impianto).where(Impianto.sede_id == x.id)).scalar()
    n_att = s.execute(select(func.count()).select_from(Asset).where(Asset.sede_id == x.id, Asset.gruppo.in_(ambiti.GRUPPI_DM),
                                                                   Asset.dismesso.is_(False))).scalar()
    return {"id": x.id, **dati_sede(x), "n_attrezzature": n_att, "origini": origini.di(s, "sede", x.id), "cliente": x.cliente.ragione_sociale, "cliente_attivo": x.cliente.attivo,
            "email_verbali_cliente": x.cliente.email_verbali, "versione": x.versione, "n_impianti": n,
            "creato_il": iso_locale(x.creato_il), "creato_da": x.creato_da,
            "modificato_il": iso_locale(x.modificato_il), "modificato_da": x.modificato_da}


def _compila_sede(s: Session, x: Sede, dati: dict) -> None:
    cliente = cliente_o_404(s, int(dati.get("cliente_id") or 0))
    if x.cliente_id != cliente.id and not cliente.attivo:
        raise ErroreUtente(f"Il cliente «{cliente.ragione_sociale}» è disattivato: riattivalo prima di aggiungere sedi.")
    x.cliente_id = cliente.id
    x.denominazione = _t(dati, "denominazione", 300)
    if not x.denominazione:
        raise ErroreUtente("Scrivi la denominazione della sede (es. «Stabilimento di Volpiano»).")
    applica_indirizzo(s, x, dati)
    x.referente_nome = _t(dati, "referente_nome", 120)
    x.referente_email = v.normalizza_email(dati.get("referente_email"), "Email del referente")
    x.referente_telefono = _t(dati, "referente_telefono", 60)
    x.email_verbali = v.normalizza_email(dati.get("email_verbali"), "Destinatari dei verbali")
    x.email_verbali_cc = v.normalizza_email(dati.get("email_verbali_cc"), "Destinatari in copia")
    x.note_accesso = _t(dati, "note_accesso", 4000)
    x.note = _t(dati, "note", 8000)
    x.avvisi = _t(dati, "avvisi", 8000)
    x.codice_esterno = _t(dati, "codice_esterno", 40)
    ambiti.applica_sede(s, x, ambiti.leggi(dati), cliente)


def crea_sede(s: Session, attore: Any, dati: dict) -> Sede:
    x = Sede()
    _compila_sede(s, x, dati)
    _crea(s, x, attore)
    registro.scrivi(s, utente=attore, azione="sede.crea", oggetto_tipo="sede", oggetto_id=x.id,
                    descrizione=f"Creata la sede «{x.denominazione}» del cliente «{x.cliente.ragione_sociale}»", dettagli={"dopo": dati_sede(x)})
    return x


def modifica_sede(s: Session, attore: Any, sede_id: int, dati: dict) -> Sede:
    x = sede_o_404(s, sede_id)
    controlla_versione(x, dati.get("versione"))
    prima = dati_sede(x)
    attiva = x.attiva
    _compila_sede(s, x, dati)
    x.attiva = attiva
    modifiche = registro.differenze(prima, dati_sede(x))
    if modifiche:
        _modificato(x, attore)
        s.flush()
        s.refresh(x)
        registro.scrivi(s, utente=attore, azione="sede.modifica", oggetto_tipo="sede", oggetto_id=x.id,
                        descrizione=f"Modificata la sede «{x.denominazione}» ({x.cliente.ragione_sociale})", dettagli={"modifiche": modifiche})
    return x


def imposta_attiva_sede(s: Session, attore: Any, sede_id: int, attiva: bool, versione: Any) -> Sede:
    x = sede_o_404(s, sede_id)
    controlla_versione(x, versione)
    if x.attiva != attiva:
        x.attiva = attiva
        _modificato(x, attore)
        registro.scrivi(s, utente=attore, azione="sede.riattiva" if attiva else "sede.disattiva", oggetto_tipo="sede", oggetto_id=x.id,
                        descrizione=f"Sede «{x.denominazione}» {'riattivata' if attiva else 'chiusa'}")
    return x


def elimina_sede(s: Session, attore: Any, sede_id: int) -> None:
    x = sede_o_404(s, sede_id)
    n = s.execute(select(func.count()).select_from(Impianto).where(Impianto.sede_id == x.id)).scalar()
    if n:
        raise ErroreUtente(f"La sede ha {n} impianti: non si può eliminare. Se è chiusa, segnala come chiusa.")
    from ..beni.modelli import Asset
    if s.scalar(select(func.count()).select_from(Asset).where(Asset.sede_id == x.id)):
        raise ErroreUtente("La sede ha beni nel parco comune: non si può eliminare. Segnala la sede come chiusa.")
    dati = dati_sede(x)
    s.delete(x)
    s.flush()
    registro.scrivi(s, utente=attore, azione="sede.elimina", oggetto_tipo="sede", oggetto_id=sede_id,
                    descrizione=f"Eliminata la sede «{dati['denominazione']}» (senza impianti)", dettagli={"prima": dati})


# ---------------------------------------------------------------- impianti


def impianto_o_404(s: Session, impianto_id: int) -> Impianto:
    x = s.get(Impianto, impianto_id)
    if x is None:
        raise NonTrovato("Impianto non trovato: forse è stato eliminato. Ricarica la pagina.")
    return x


def matricola(x: Impianto) -> str:
    parti = [x.matricola_anno, x.matricola_attivita, x.matricola_numero, x.matricola_provincia]
    return "/".join(parti) if any(parti) else ""


def dati_impianto(x: Impianto) -> dict:
    return {
        "sede_id": x.sede_id, "tipologia": x.tipologia, "denominazione": x.denominazione, "dismesso": x.dismesso,
        "matricola_anno": x.matricola_anno, "matricola_attivita": x.matricola_attivita, "matricola_numero": x.matricola_numero,
        "matricola_provincia": x.matricola_provincia, "potenza_kw": x.potenza_kw, "cabine_mt_bt": x.cabine_mt_bt,
        "sottostazioni_at_mt": x.sottostazioni_at_mt, "pod": [p.pod for p in x.pod], "pod_note": x.pod_note,
        "asta": x.asta, "numero_aste": x.numero_aste, "gabbia": x.gabbia, "gabbia_fascia": x.gabbia_fascia,
        "gas": x.gas, "polveri": x.polveri, "zone": x.zone, "periodicita_anni": x.periodicita_anni,
        "ultima_verifica_data": x.ultima_verifica_data.isoformat() if x.ultima_verifica_data else None,
        "ultima_verifica_numero": x.ultima_verifica_numero,
        "prossima_verifica": x.prossima_verifica.isoformat() if x.prossima_verifica else None,
        "prossima_calcolata": x.prossima_calcolata, "note": x.note, "avvisi": x.avvisi, "codice_esterno": x.codice_esterno,
    }


def impianto_json(s: Session, x: Impianto) -> dict:
    from ..tariffario import servizio as tariffario  # import qui per evitare il giro di importazioni

    sede = x.sede
    return {"id": x.id, "asset_id": x.asset_id, **dati_impianto(x), "versione": x.versione, "matricola": matricola(x),
            "tipologia_testo": TIPOLOGIE_IMPIANTO.get(x.tipologia, x.tipologia),
            "sede": sede.denominazione, "sede_indirizzo": " ".join(p for p in [sede.indirizzo, sede.cap, sede.comune,
                                                                                f"({sede.provincia})" if sede.provincia else ""] if p),
            "cliente_id": sede.cliente_id, "cliente": sede.cliente.ragione_sociale,
            "tariffa": tariffario.calcola(s, x),
            "caratteristiche": json.loads(x.caratteristiche) if x.caratteristiche else None,  # dall'ultimo verbale (G39, 0.4.0)
            "creato_il": iso_locale(x.creato_il), "creato_da": x.creato_da,
            "modificato_il": iso_locale(x.modificato_il), "modificato_da": x.modificato_da}


def ricalcola_prossima(x: Impianto, prossima_manuale: date | None) -> None:
    """D9: con ultima verifica e periodicità la prossima si calcola; altrimenti resta quella scritta a mano."""
    if x.ultima_verifica_data and x.periodicita_anni:
        x.prossima_verifica = scadenza(x.ultima_verifica_data, x.periodicita_anni)
        x.prossima_calcolata = True
    else:
        x.prossima_verifica = prossima_manuale
        x.prossima_calcolata = False


def _compila_impianto(s: Session, x: Impianto, dati: dict) -> None:
    sede = sede_o_404(s, int(dati.get("sede_id") or 0))
    if x.sede_id != sede.id and not sede.attiva:
        raise ErroreUtente(f"La sede «{sede.denominazione}» è chiusa: riattivala prima di aggiungere impianti.")
    x.sede_id = sede.id
    tipologia = _t(dati, "tipologia", 20)
    if tipologia not in TIPOLOGIE_IMPIANTO:
        raise ErroreUtente("Scegli la tipologia dell'impianto.")
    x.tipologia = tipologia
    x.denominazione = _t(dati, "denominazione", 300)
    x.matricola_anno = _t(dati, "matricola_anno", 4)
    if x.matricola_anno and not (x.matricola_anno.isdigit() and len(x.matricola_anno) == 4):
        raise ErroreUtente("Matricola INAIL: l'anno ha 4 cifre.")
    x.matricola_attivita = _t(dati, "matricola_attivita", 10)
    x.matricola_numero = _t(dati, "matricola_numero", 20)
    x.matricola_provincia = _t(dati, "matricola_provincia", 2).upper()

    terra = tipologia in ("terra_bt", "terra_at")
    # Messa a terra: potenza sempre; cabine e sottostazioni solo oltre 1.000 V
    x.potenza_kw = _decimale(dati, "potenza_kw", "Potenza") if terra else None
    if terra and x.potenza_kw is None:
        raise ErroreUtente("Messa a terra: scrivi la potenza in kW (serve anche per la tariffa).")
    cabine = _intero(dati, "cabine_mt_bt", "Cabine MT/BT")
    sottostazioni = _intero(dati, "sottostazioni_at_mt", "Sottostazioni AT/MT")
    if tipologia == "terra_bt" and (cabine or sottostazioni):
        raise ErroreUtente("Cabine MT/BT e sottostazioni AT/MT ci sono solo negli impianti oltre 1.000 V: cambia la tipologia o azzera i numeri.")
    x.cabine_mt_bt = cabine if tipologia == "terra_at" else None
    x.sottostazioni_at_mt = sottostazioni if tipologia == "terra_at" else None
    pod = []
    for p in dati.get("pod") or []:
        if str(p).strip():
            n = v.normalizza_pod(p)
            if n in pod:
                raise ErroreUtente(f"Il POD {n} è scritto due volte.")
            pod.append(n)
    if not terra:
        pod = []
    if [q.pod for q in x.pod] != pod:
        x.pod.clear()
        if x.id is not None:
            s.flush()  # prima si tolgono i vecchi, poi si aggiungono i nuovi (vincolo di unicità)
        x.pod.extend(ImpiantoPod(pod=p, ordine=i) for i, p in enumerate(pod))
    x.pod_note = _t(dati, "pod_note", 2000) if terra else ""

    # Scariche atmosferiche: asta (con numero) e/o gabbia (con fascia di superficie, D44)
    scariche = tipologia == "scariche"
    x.asta = scariche and _b(dati, "asta")
    x.numero_aste = _intero(dati, "numero_aste", "Numero di aste", 1) if x.asta else None
    x.gabbia = scariche and _b(dati, "gabbia")
    x.gabbia_fascia = _t(dati, "gabbia_fascia", 20) if x.gabbia else ""
    if scariche:
        if not (x.asta or x.gabbia):
            raise ErroreUtente("Scariche atmosferiche: indica se ci sono aste, gabbia di Faraday o entrambe.")
        if x.asta and not x.numero_aste:
            raise ErroreUtente("Scrivi il numero di aste (serve per la tariffa).")
        if x.gabbia and x.gabbia_fascia not in FASCE_GABBIA:
            raise ErroreUtente("Gabbia di Faraday: scegli la fascia di superficie protetta.")

    # Pericolo di esplosione: gas/vapori/nebbie (zone 0, 1, 2) e/o polveri (zone 20, 21, 22)
    esplosione = tipologia == "esplosione"
    x.gas, x.polveri = esplosione and _b(dati, "gas"), esplosione and _b(dati, "polveri")
    zone_scelte = dati.get("zone") or []
    if isinstance(zone_scelte, str):
        zone_scelte = [z.strip() for z in zone_scelte.split(",") if z.strip()]
    zone_scelte = [z for z in ZONE if z in {str(z).strip() for z in zone_scelte}] if esplosione else []
    if esplosione:
        if not (x.gas or x.polveri):
            raise ErroreUtente("Pericolo di esplosione: indica se ci sono gas/vapori/nebbie, polveri o entrambi.")
        if not zone_scelte:
            raise ErroreUtente("Pericolo di esplosione: scegli almeno una zona.")
        if not x.gas and any(z in ("0", "1", "2") for z in zone_scelte):
            raise ErroreUtente("Le zone 0, 1, 2 riguardano gas/vapori/nebbie: spunta «gas» o togli quelle zone.")
        if not x.polveri and any(z in ("20", "21", "22") for z in zone_scelte):
            raise ErroreUtente("Le zone 20, 21, 22 riguardano le polveri: spunta «polveri» o togli quelle zone.")
    x.zone = ", ".join(zone_scelte)

    # Verifiche (D8, D9)
    x.periodicita_anni = _intero(dati, "periodicita_anni", "Periodicità")
    if x.tipologia == "esplosione":  # O8: D.P.R. 462/01 art. 6
        if x.periodicita_anni not in (None, 2):
            raise ErroreUtente("Per gli impianti in luoghi con pericolo di esplosione la periodicità è sempre 2 anni (D.P.R. 462/01, art. 6).")
        x.periodicita_anni = 2
    if x.periodicita_anni not in PERIODICITA:
        raise ErroreUtente("Scegli la periodicità delle verifiche: 2 o 5 anni.")
    x.ultima_verifica_data = _data(dati, "ultima_verifica_data", "Data dell'ultima verifica")
    if x.ultima_verifica_data and x.ultima_verifica_data > date.today():
        raise ErroreUtente("La data dell'ultima verifica non può essere nel futuro.")
    x.ultima_verifica_numero = _t(dati, "ultima_verifica_numero", 40)
    ricalcola_prossima(x, _data(dati, "prossima_verifica", "Prossima verifica"))
    x.note = _t(dati, "note", 8000)
    x.avvisi = _t(dati, "avvisi", 8000)
    x.codice_esterno = _t(dati, "codice_esterno", 40)


def crea_impianto(s: Session, attore: Any, dati: dict) -> Impianto:
    x = Impianto(dismesso=False)
    _compila_impianto(s, x, dati)
    _crea(s, x, attore)
    s.refresh(x)
    registro.scrivi(s, utente=attore, azione="impianto.crea", oggetto_tipo="impianto", oggetto_id=x.id,
                    descrizione=f"Creato l'impianto n. {x.id} ({TIPOLOGIE_IMPIANTO[x.tipologia]}) nella sede «{x.sede.denominazione}»",
                    dettagli={"dopo": dati_impianto(x)})
    return x


def modifica_impianto(s: Session, attore: Any, impianto_id: int, dati: dict) -> Impianto:
    x = impianto_o_404(s, impianto_id)
    controlla_versione(x, dati.get("versione"))
    prima = dati_impianto(x)
    dismesso = x.dismesso
    _compila_impianto(s, x, dati)
    x.dismesso = dismesso
    s.flush()
    modifiche = registro.differenze(prima, dati_impianto(x))
    if modifiche:
        _modificato(x, attore)
        s.flush()
        s.refresh(x)
        registro.scrivi(s, utente=attore, azione="impianto.modifica", oggetto_tipo="impianto", oggetto_id=x.id,
                        descrizione=f"Modificato l'impianto n. {x.id} ({x.sede.cliente.ragione_sociale})", dettagli={"modifiche": modifiche})
    return x


def imposta_dismesso(s: Session, attore: Any, impianto_id: int, dismesso: bool, motivo: str, versione: Any) -> Impianto:
    """D10: il dismesso esce dallo scadenziario ma resta in archivio."""
    x = impianto_o_404(s, impianto_id)
    controlla_versione(x, versione)
    if x.dismesso == dismesso:
        return x
    motivo = (motivo or "").strip()[:500]
    if dismesso and not motivo:
        raise ErroreUtente("Scrivi perché l'impianto è dismesso (es. «impianto smantellato», «attività chiusa»).")
    x.dismesso = dismesso
    _modificato(x, attore)
    registro.scrivi(s, utente=attore, azione="impianto.dismetti" if dismesso else "impianto.riattiva", oggetto_tipo="impianto",
                    oggetto_id=x.id, descrizione=f"Impianto n. {x.id} {'dismesso' if dismesso else 'rimesso in servizio'}"
                    + (f": {motivo}" if motivo else ""), dettagli={"motivo": motivo})
    return x


def elimina_impianto(s: Session, attore: Any, impianto_id: int) -> None:
    x = impianto_o_404(s, impianto_id)
    if x.ultima_verifica_data or x.ultima_verifica_numero:
        raise ErroreUtente("L'impianto ha una verifica registrata: non si elimina. Se non c'è più, segnalalo come dismesso.")
    dati = dati_impianto(x)
    s.delete(x)
    s.flush()
    registro.scrivi(s, utente=attore, azione="impianto.elimina", oggetto_tipo="impianto", oggetto_id=impianto_id,
                    descrizione=f"Eliminato l'impianto n. {impianto_id}", dettagli={"prima": dati})


def inizializza(s: Session) -> None:
    carica_comuni(s)
    prepara_elenchi(s)
