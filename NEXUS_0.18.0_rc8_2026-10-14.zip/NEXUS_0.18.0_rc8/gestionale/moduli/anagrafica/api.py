"""Interfaccia JSON dell'anagrafica: clienti, sedi, impianti, commerciali, elenchi, comuni, storico delle schede."""

from __future__ import annotations

import json

from fastapi import APIRouter, Body, Depends
from sqlalchemy import func, or_, select

from ...core.date import iso_locale
from ...core.db import Archivio
from ...core.errori import ErroreUtente, PermessoNegato
from ...web.dipendenze import archivio, richiede, utente
from ..registro.modelli import RegistroOperazione
from ..utenti.accesso import UtenteCorrente
from . import ambiti, doppioni, servizio
from .modelli import FASCE_GABBIA, PERIODICITA, TIPI_CLIENTE, TIPOLOGIE_IMPIANTO, ZONE, Cliente, Commerciale, Comune, Impianto, Sede

router = APIRouter(prefix="/api")
VEDERE = "anagrafica.vedere"


# ---------------------------------------------------------------- valori fissi, comuni, elenchi


@router.get("/anagrafica/valori")
def valori(_u: UtenteCorrente = Depends(utente)) -> dict:
    return {"tipi_cliente": TIPI_CLIENTE, "tipologie": TIPOLOGIE_IMPIANTO, "fasce_gabbia": FASCE_GABBIA,
            "zone": list(ZONE), "periodicita": list(PERIODICITA), "elenchi": servizio.ELENCHI}


@router.get("/comuni")
def comuni(q: str = "", _u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> list[dict]:
    with arc.lettura() as s:
        return servizio.cerca_comuni(s, q)


@router.get("/comuni/{codice_istat}")
def leggi_comune(codice_istat: str, _u: UtenteCorrente = Depends(richiede(VEDERE)), arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        c = s.get(Comune, codice_istat)
        if c is None:
            raise ErroreUtente("Comune non trovato.", 404)
        return servizio.dati_comune(c)


@router.post("/comuni")
def crea_comune(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("sistema.impostazioni")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.dati_comune(servizio.salva_comune(s, u.come_attore(), dati))


@router.put("/comuni/{codice_istat}")
def modifica_comune(codice_istat: str, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("sistema.impostazioni")),
                    arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.dati_comune(servizio.salva_comune(s, u.come_attore(), dati, codice_istat))


@router.get("/elenchi/{elenco}")
def elenco(elenco: str, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> list[dict]:
    if not (u.puo(VEDERE) or u.puo("sistema.impostazioni")):
        raise PermessoNegato()
    with arc.lettura() as s:
        return servizio.valori_elenco(s, elenco)


@router.post("/elenchi")
def crea_valore(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("sistema.impostazioni")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.elenco_json(servizio.salva_valore(s, u.come_attore(), dati))


@router.put("/elenchi/{valore_id}")
def modifica_valore(valore_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("sistema.impostazioni")),
                    arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.elenco_json(servizio.salva_valore(s, u.come_attore(), dati, valore_id))


# ---------------------------------------------------------------- commerciali


@router.get("/commerciali")
def elenco_commerciali(_u: UtenteCorrente = Depends(richiede(VEDERE)), arc: Archivio = Depends(archivio)) -> list[dict]:
    with arc.lettura() as s:
        return [servizio.commerciale_json(c) for c in s.execute(select(Commerciale).order_by(Commerciale.nome)).scalars()]


@router.get("/commerciali/{commerciale_id}")
def leggi_commerciale(commerciale_id: int, _u: UtenteCorrente = Depends(richiede(VEDERE)), arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        c = s.get(Commerciale, commerciale_id)
        if c is None:
            raise ErroreUtente("Commerciale non trovato.", 404)
        return servizio.commerciale_json(c)


@router.post("/commerciali")
def crea_commerciale(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("anagrafica.commerciali")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.commerciale_json(servizio.salva_commerciale(s, u.come_attore(), dati))


@router.put("/commerciali/{commerciale_id}")
def modifica_commerciale(commerciale_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("anagrafica.commerciali")),
                         arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.commerciale_json(servizio.salva_commerciale(s, u.come_attore(), dati, commerciale_id))


# ---------------------------------------------------------------- clienti


@router.get("/clienti/cerca")
def cerca_clienti(q: str = "", ambito: str = "", _u: UtenteCorrente = Depends(richiede(VEDERE)),
                  arc: Archivio = Depends(archivio)) -> list[dict]:
    t = q.strip().lower()
    with arc.lettura() as s:
        query = select(Cliente).order_by(Cliente.ragione_sociale).limit(20)
        if ambito in ambiti.CAMPI:  # R114: solo i clienti di quell'ambito (es. nuovo preventivo DPR)
            query = query.where(getattr(Cliente, ambiti.CAMPI[ambito]).is_(True))
        if t:
            query = query.where(or_(func.lower(Cliente.ragione_sociale).like(f"%{t}%"), Cliente.partita_iva.like(f"%{t}%"),
                                    func.lower(Cliente.codice_fiscale).like(f"%{t}%")))
        return [{"id": c.id, "ragione_sociale": c.ragione_sociale, "comune": c.comune, "provincia": c.provincia,
                 "partita_iva": c.partita_iva, "attivo": c.attivo} for c in s.execute(query).scalars()]


@router.get("/clienti/doppioni")
def clienti_doppi(_u: UtenteCorrente = Depends(richiede(VEDERE)), arc: Archivio = Depends(archivio)) -> list[dict]:
    """Clienti con la stessa partita IVA o lo stesso codice fiscale, da unire o da dichiarare diversi."""
    with arc.lettura() as s:
        return doppioni.candidati_clienti(s)


@router.post("/clienti/doppioni/diversi")
def clienti_diversi(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("anagrafica.clienti")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        doppioni.escludi_clienti(s, u.come_attore(), int(dati.get("a") or 0), int(dati.get("b") or 0))
    return {"ok": True}


@router.post("/clienti/{cliente_id}/unisci")
def unisci_cliente(cliente_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("anagrafica.clienti")),
                   arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.cliente_json(s, doppioni.unisci_clienti(s, u.come_attore(), cliente_id, int(dati.get("destinazione_id") or 0)))


@router.get("/clienti/{cliente_id}")
def leggi_cliente(cliente_id: int, _u: UtenteCorrente = Depends(richiede(VEDERE)), arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        return servizio.cliente_json(s, servizio.cliente_o_404(s, cliente_id))


@router.get("/clienti/{cliente_id}/sedi")
def sedi_del_cliente(cliente_id: int, _u: UtenteCorrente = Depends(richiede(VEDERE)), arc: Archivio = Depends(archivio)) -> list[dict]:
    with arc.lettura() as s:
        n = (select(Sede.id, func.count(Impianto.id).label("n")).outerjoin(Impianto, Impianto.sede_id == Sede.id)
             .where(Sede.cliente_id == cliente_id).group_by(Sede.id).subquery())
        q = select(Sede, n.c.n).join(n, n.c.id == Sede.id).order_by(Sede.denominazione)
        from ..beni.modelli import Asset

        att = dict(s.execute(select(Asset.sede_id, func.count(Asset.id)).join(Sede, Asset.sede_id == Sede.id).where(
            Sede.cliente_id == cliente_id, Asset.gruppo.in_(ambiti.GRUPPI_DM), Asset.dismesso.is_(False)).group_by(Asset.sede_id)).all())
        return [{"id": x.id, "denominazione": x.denominazione, "indirizzo": x.indirizzo, "comune": x.comune,
                 "provincia": x.provincia, "attiva": x.attiva, "n_impianti": k, "n_attrezzature": att.get(x.id, 0), "ambiti": ambiti.elenco(x)}
                for x, k in s.execute(q)]


@router.get("/clienti/{cliente_id}/impianti")
def impianti_del_cliente(cliente_id: int, _u: UtenteCorrente = Depends(richiede(VEDERE)), arc: Archivio = Depends(archivio)) -> list[dict]:
    """Impianti di tutte le sedi del cliente (per aggiungerli a un preventivo, D39)."""
    with arc.lettura() as s:
        q = select(Impianto, Sede).join(Sede).where(Sede.cliente_id == cliente_id).order_by(Sede.denominazione, Impianto.id)
        return [{"id": x.id, "sede": sd.denominazione, "comune": sd.comune, "tipologia": TIPOLOGIE_IMPIANTO[x.tipologia],
                 "denominazione": x.denominazione, "potenza_kw": x.potenza_kw, "dismesso": x.dismesso,
                 "prossima_verifica": x.prossima_verifica.isoformat() if x.prossima_verifica else None} for x, sd in s.execute(q)]


@router.post("/clienti")
def crea_cliente(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("anagrafica.clienti")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.cliente_json(s, servizio.crea_cliente(s, u.come_attore(), dati))


@router.put("/clienti/{cliente_id}")
def modifica_cliente(cliente_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("anagrafica.clienti")),
                     arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.cliente_json(s, servizio.modifica_cliente(s, u.come_attore(), cliente_id, dati))


@router.post("/clienti/{cliente_id}/attivo")
def attivo_cliente(cliente_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("anagrafica.disattiva")),
                   arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        c = servizio.imposta_attivo_cliente(s, u.come_attore(), cliente_id, bool(dati.get("attivo")), dati.get("versione"))
        return servizio.cliente_json(s, c)


@router.post("/clienti/{cliente_id}/sconti")
def sconti_cliente(cliente_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("preventivi.sconti_sblocca")),
                   arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        c = servizio.imposta_sconti(s, u.come_attore(), cliente_id, bool(dati.get("ammessi")), str(dati.get("motivo") or ""), dati.get("versione"))
        return servizio.cliente_json(s, c)


@router.delete("/clienti/{cliente_id}")
def elimina_cliente(cliente_id: int, u: UtenteCorrente = Depends(richiede("anagrafica.clienti")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        servizio.elimina_cliente(s, u.come_attore(), cliente_id)
    return {"ok": True}


# ---------------------------------------------------------------- sedi


@router.get("/sedi/cerca")
def cerca_sedi(q: str = "", cliente_id: int | None = None, ambito: str = "", _u: UtenteCorrente = Depends(richiede(VEDERE)),
               arc: Archivio = Depends(archivio)) -> list[dict]:
    t = q.strip().lower()
    with arc.lettura() as s:
        query = select(Sede, Cliente.ragione_sociale).join(Cliente).order_by(Cliente.ragione_sociale, Sede.denominazione).limit(25)
        if ambito in ambiti.CAMPI:  # R114/R137: solo le sedi dei clienti di quell'ambito (es. nuovo preventivo DM)
            query = query.where(getattr(Sede, ambiti.CAMPI[ambito]).is_(True))
        if ambito == "DM":  # R137: prima le sedi che hanno già attrezzature
            from ..beni.modelli import Asset
            n_att = (select(func.count(Asset.id)).where(Asset.sede_id == Sede.id, Asset.gruppo.in_(ambiti.GRUPPI_DM),
                                                       Asset.dismesso.is_(False)).correlate(Sede).scalar_subquery())
            query = query.order_by(None).order_by((n_att > 0).desc(), Cliente.ragione_sociale, Sede.denominazione)
        if cliente_id:
            query = query.where(Sede.cliente_id == cliente_id)
        if t:
            query = query.where(or_(func.lower(Sede.denominazione).like(f"%{t}%"), func.lower(Cliente.ragione_sociale).like(f"%{t}%"),
                                    func.lower(Sede.comune).like(f"%{t}%")))
        return [{"id": x.id, "denominazione": x.denominazione, "cliente": rs, "cliente_id": x.cliente_id, "comune": x.comune,
                 "provincia": x.provincia, "attiva": x.attiva} for x, rs in s.execute(query)]


@router.get("/sedi/doppioni")
def sedi_doppie(_u: UtenteCorrente = Depends(richiede(VEDERE)), arc: Archivio = Depends(archivio)) -> list[dict]:
    """R116: coppie di sedi dello stesso cliente nello stesso comune, da unire o da dichiarare diverse."""
    with arc.lettura() as s:
        return doppioni.candidati(s)


@router.post("/sedi/doppioni/diverse")
def sedi_diverse(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("anagrafica.sedi")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        doppioni.escludi(s, u.come_attore(), int(dati.get("a") or 0), int(dati.get("b") or 0))
    return {"ok": True}


@router.post("/sedi/{sede_id}/unisci")
def unisci_sede(sede_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("anagrafica.sedi")),
                arc: Archivio = Depends(archivio)) -> dict:
    """Unisce la sede {sede_id} nella sede «destinazione_id», che resta (R116)."""
    with arc.scrittura() as s:
        d = doppioni.unisci(s, u.come_attore(), sede_id, int(dati.get("destinazione_id") or 0))
        return servizio.sede_json(s, d)


@router.get("/sedi/{sede_id}")
def leggi_sede(sede_id: int, _u: UtenteCorrente = Depends(richiede(VEDERE)), arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        return servizio.sede_json(s, servizio.sede_o_404(s, sede_id))


@router.get("/sedi/{sede_id}/impianti")
def impianti_della_sede(sede_id: int, _u: UtenteCorrente = Depends(richiede(VEDERE)), arc: Archivio = Depends(archivio)) -> list[dict]:
    with arc.lettura() as s:
        q = select(Impianto).where(Impianto.sede_id == sede_id).order_by(Impianto.id)
        return [{"id": x.id, "tipologia": TIPOLOGIE_IMPIANTO[x.tipologia], "denominazione": x.denominazione, "potenza_kw": x.potenza_kw,
                 "prossima_verifica": x.prossima_verifica.isoformat() if x.prossima_verifica else None, "dismesso": x.dismesso}
                for x in s.execute(q).scalars()]


@router.post("/sedi")
def crea_sede(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("anagrafica.sedi")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.sede_json(s, servizio.crea_sede(s, u.come_attore(), dati))


@router.put("/sedi/{sede_id}")
def modifica_sede(sede_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("anagrafica.sedi")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.sede_json(s, servizio.modifica_sede(s, u.come_attore(), sede_id, dati))


@router.post("/sedi/{sede_id}/attiva")
def attiva_sede(sede_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("anagrafica.disattiva")),
                arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.sede_json(s, servizio.imposta_attiva_sede(s, u.come_attore(), sede_id, bool(dati.get("attiva")), dati.get("versione")))


@router.delete("/sedi/{sede_id}")
def elimina_sede(sede_id: int, u: UtenteCorrente = Depends(richiede("anagrafica.sedi")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        servizio.elimina_sede(s, u.come_attore(), sede_id)
    return {"ok": True}


# ---------------------------------------------------------------- impianti


@router.get("/impianti/{impianto_id}")
def leggi_impianto(impianto_id: int, _u: UtenteCorrente = Depends(richiede(VEDERE)), arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        return servizio.impianto_json(s, servizio.impianto_o_404(s, impianto_id))


@router.post("/impianti")
def crea_impianto(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("anagrafica.impianti")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.impianto_json(s, servizio.crea_impianto(s, u.come_attore(), dati))


@router.put("/impianti/{impianto_id}")
def modifica_impianto(impianto_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("anagrafica.impianti")),
                      arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.impianto_json(s, servizio.modifica_impianto(s, u.come_attore(), impianto_id, dati))


@router.post("/impianti/{impianto_id}/dismesso")
def dismetti(impianto_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("anagrafica.dismetti")),
             arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        x = servizio.imposta_dismesso(s, u.come_attore(), impianto_id, bool(dati.get("dismesso")), str(dati.get("motivo") or ""), dati.get("versione"))
        return servizio.impianto_json(s, x)


@router.delete("/impianti/{impianto_id}")
def elimina_impianto(impianto_id: int, u: UtenteCorrente = Depends(richiede("anagrafica.impianti")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        servizio.elimina_impianto(s, u.come_attore(), impianto_id)
    return {"ok": True}


# ---------------------------------------------------------------- storico di una scheda (dal registro)

PERMESSO_STORICO = {"asset": "beni.vedere", "preventivo": "preventivi.vedere", "modello": "preventivi.vedere", "comune": VEDERE, "cliente": VEDERE, "sede": VEDERE, "impianto": VEDERE, "commerciale": VEDERE,
                    "tariffa_voce": "tariffario.vedere", "elenco_valore": VEDERE, "verifica": "verifiche.vedere_tutte",
                    "strumento": "strumenti.vedere"}


@router.get("/storico/{tipo}/{oggetto_id}")
def storico(tipo: str, oggetto_id: str, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> list[dict]:
    permesso = PERMESSO_STORICO.get(tipo)
    if permesso is None or not u.puo(permesso, "DPR" if tipo == "verifica" else None):   # R132
        raise PermessoNegato()
    with arc.lettura() as s:
        q = (select(RegistroOperazione).where(RegistroOperazione.oggetto_tipo == tipo, RegistroOperazione.oggetto_id == str(oggetto_id))
             .order_by(RegistroOperazione.id.desc()).limit(200))
        return [{"quando": iso_locale(r.quando), "utente": r.utente_nome, "azione": r.azione, "descrizione": r.descrizione,
                 "dettagli": json.loads(r.dettagli or "{}")} for r in s.execute(q).scalars()]
