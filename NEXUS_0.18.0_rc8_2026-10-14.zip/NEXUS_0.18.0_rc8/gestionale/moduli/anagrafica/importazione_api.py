"""Interfaccia dell'importazione: anteprima (nulla viene scritto) e conferma (backup prima, poi tutto in una transazione)."""

from __future__ import annotations

from fastapi import APIRouter, Body, Depends, File, UploadFile

from ...core.db import Archivio
from ...core.errori import ErroreUtente
from ...web.dipendenze import archivio, richiede
from ..backup import servizio as backup
from ..utenti.accesso import UtenteCorrente
from . import importazione

router = APIRouter(prefix="/api/importazione")
MASSIMO = 20 * 1024 * 1024


async def _leggi(f: UploadFile | None) -> tuple[bytes | None, str]:
    if f is None or not f.filename:
        return None, ""
    contenuto = await f.read(MASSIMO + 1)
    if len(contenuto) > MASSIMO:
        raise ErroreUtente(f"Il file «{f.filename}» è troppo grande (massimo 20 MB).")
    return contenuto or None, f.filename


@router.post("/anteprima")
async def anteprima(clienti: UploadFile | None = File(None), sedi: UploadFile | None = File(None), impianti: UploadFile | None = File(None),
                    u: UtenteCorrente = Depends(richiede("anagrafica.importa")), arc: Archivio = Depends(archivio)) -> dict:
    (c, nc), (s_, ns), (i, ni) = await _leggi(clienti), await _leggi(sedi), await _leggi(impianti)
    if not (c or s_ or i):
        raise ErroreUtente("Scegli almeno un file da importare.")
    with arc.lettura() as s:
        piano = importazione.analizza(s, c, s_, i, {"clienti": nc, "sedi": ns, "impianti": ni})
    return {"codice": importazione.ANTEPRIME.metti(u.id, piano), **piano.riepilogo()}


@router.post("/conferma")
def conferma(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("anagrafica.importa")), arc: Archivio = Depends(archivio)) -> dict:
    piano = importazione.ANTEPRIME.prendi(u.id, str(dati.get("codice") or ""))
    copia = backup.crea(arc, "pre_importazione", u.come_attore())  # si torna indietro con un ripristino
    with arc.scrittura() as s:
        esito = importazione.esegui(s, arc.cfg, u.come_attore(), piano)
    return {**esito, "backup": copia.get("nome")}
