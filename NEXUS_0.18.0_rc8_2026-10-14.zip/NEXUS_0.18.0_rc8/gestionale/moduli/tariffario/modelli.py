"""Tariffario costruito da menu (decisioni D11, D29; documento 03 § 2.4).

Una VOCE dice A COSA si applica (tipologie di impianto) e COME si calcola (criterio + dato dell'impianto).
Gli importi stanno nelle VERSIONI, ciascuna con la sua data di inizio validità: cambiare un prezzo
significa aggiungere una versione nuova, così i calcoli fatti in passato restano spiegabili.
"""

from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ...core.db import Base, adesso
from ...core.modelli_comuni import Centesimi, Tracciato

CRITERI = {
    "scaglioni": "A scaglioni su un dato dell'impianto",
    "unitario": "Prezzo unitario × quantità",
    "fisso": "Prezzo fisso",
}

# Dati dell'impianto su cui si può calcolare una voce
GRANDEZZE = {
    "potenza_kw": "Potenza (kW)",
    "superficie_gabbia": "Superficie gabbia di Faraday (fascia)",
    "numero_aste": "Numero di aste",
    "cabine_mt_bt": "Numero di cabine MT/BT",
    "sottostazioni_at_mt": "Numero di sottostazioni AT/MT",
    "numero_zone": "Numero di zone classificate",
    "numero_pod": "Numero di POD",
    # 0.4.0 (tariffario M03-RG01_dpr rev. 01)
    "asta_presente": "Parafulmine ad asta presente (1 se sì)",
    "aste_in_piu": "Aste oltre la prima",
    "ore": "Ore (scritte nella riga del preventivo)",
    "scelta": "Scelta da un elenco (nella riga del preventivo)",
}
# Grandezze che non vengono dall'impianto ma si scrivono nella riga del preventivo
GRANDEZZE_RIGA = ("ore", "scelta")


class VoceTariffa(Base, Tracciato):
    __tablename__ = "tariffe_voci"
    __table_args__ = (
        CheckConstraint("criterio IN ('scaglioni', 'unitario', 'fisso')", name="criterio"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    codice: Mapped[str] = mapped_column(String(30), unique=True)
    nome: Mapped[str] = mapped_column(String(150))
    tipologie: Mapped[str] = mapped_column(String(100), default="")  # codici separati da virgola (terra_bt,terra_at…)
    criterio: Mapped[str] = mapped_column(String(20))
    grandezza: Mapped[str] = mapped_column(String(30), default="")   # vuota per «fisso»
    # automatica: si somma da sola alla tariffa dell'impianto quando il dato c'è; altrimenti si aggiunge a mano
    automatica: Mapped[bool] = mapped_column(Boolean, default=True)
    attiva: Mapped[bool] = mapped_column(Boolean, default=True)
    ordine: Mapped[int] = mapped_column(Integer, default=0)
    note: Mapped[str] = mapped_column(Text, default="")

    versioni: Mapped[list["VersioneTariffa"]] = relationship(back_populates="voce", cascade="all, delete-orphan",
                                                             order_by="VersioneTariffa.valida_dal")


class VersioneTariffa(Base):
    __tablename__ = "tariffe_versioni"
    __table_args__ = (UniqueConstraint("voce_id", "valida_dal"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    voce_id: Mapped[int] = mapped_column(ForeignKey("tariffe_voci.id", ondelete="CASCADE"), index=True)
    valida_dal: Mapped[date] = mapped_column(Date)
    prezzo: Mapped[int | None] = mapped_column(Centesimi, nullable=True)  # centesimi (criteri «unitario» e «fisso»)
    minimo: Mapped[int | None] = mapped_column(Centesimi, nullable=True)  # centesimi: importo minimo (es. tariffa oraria con minimo)
    note: Mapped[str] = mapped_column(Text, default="")
    creata_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    creata_da: Mapped[str] = mapped_column(String(120), default="")

    voce: Mapped[VoceTariffa] = relationship(back_populates="versioni")
    scaglioni: Mapped[list["ScaglioneTariffa"]] = relationship(back_populates="versione", cascade="all, delete-orphan",
                                                               order_by="ScaglioneTariffa.ordine")


class ScaglioneTariffa(Base):
    __tablename__ = "tariffe_scaglioni"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    versione_id: Mapped[int] = mapped_column(ForeignKey("tariffe_versioni.id", ondelete="CASCADE"), index=True)
    ordine: Mapped[int] = mapped_column(Integer, default=0)
    fino_a: Mapped[float | None] = mapped_column(Float, nullable=True)  # vuoto = «oltre» (ultimo scaglione)
    importo: Mapped[int] = mapped_column(Centesimi)                        # centesimi
    etichetta: Mapped[str] = mapped_column(String(200), default="", server_default="")  # avviso o voce dell'elenco («scelta»)

    versione: Mapped[VersioneTariffa] = relationship(back_populates="scaglioni")


__all__ = ["VoceTariffa", "VersioneTariffa", "ScaglioneTariffa", "CRITERI", "GRANDEZZE", "GRANDEZZE_RIGA"]
