"""Modulo tariffario."""
