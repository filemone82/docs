"""Interfaccia JSON del tariffario."""

from __future__ import annotations

from fastapi import APIRouter, Body, Depends

from ...core.db import Archivio
from ...web.dipendenze import archivio, richiede
from ..utenti.accesso import UtenteCorrente
from . import servizio
from .modelli import CRITERI, GRANDEZZE

router = APIRouter(prefix="/api/tariffario")
GESTIRE = "tariffario.gestire"


@router.get("/valori")
def valori(_u: UtenteCorrente = Depends(richiede("tariffario.vedere"))) -> dict:
    return {"criteri": CRITERI, "grandezze": GRANDEZZE}


@router.get("/voci/{voce_id}")
def leggi_voce(voce_id: int, _u: UtenteCorrente = Depends(richiede("tariffario.vedere")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        return servizio.voce_json(servizio.voce_o_404(s, voce_id))


@router.post("/voci")
def crea_voce(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede(GESTIRE)), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.voce_json(servizio.salva_voce(s, u.come_attore(), dati))


@router.put("/voci/{voce_id}")
def modifica_voce(voce_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede(GESTIRE)), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.voce_json(servizio.salva_voce(s, u.come_attore(), dati, voce_id))


@router.post("/voci/{voce_id}/versioni")
def aggiungi_versione(voce_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede(GESTIRE)), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        x = servizio.aggiungi_versione(s, u.come_attore(), voce_id, dati)
        return servizio.voce_json(x.voce)


@router.put("/versioni/{versione_id}")
def modifica_versione(versione_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede(GESTIRE)), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        x = servizio.modifica_versione(s, u.come_attore(), versione_id, dati)
        return servizio.voce_json(x.voce)


@router.delete("/versioni/{versione_id}")
def elimina_versione(versione_id: int, u: UtenteCorrente = Depends(richiede(GESTIRE)), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        servizio.elimina_versione(s, u.come_attore(), versione_id)
    return {"ok": True}


@router.post("/prova")
def prova(dati: dict = Body(...), _u: UtenteCorrente = Depends(richiede("tariffario.vedere")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        return servizio.prova_calcolo(s, dati)
