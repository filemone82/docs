"""Regole del tariffario (D11, D29) e calcolo della tariffa di un impianto.

- La tariffa di un impianto è la somma delle voci AUTOMATICHE attive che si applicano alla sua tipologia,
  con gli importi della versione in vigore nel giorno del calcolo.
- Le versioni già in vigore non si modificano né si eliminano: per cambiare un prezzo si aggiunge una
  versione con una nuova data di inizio validità. Le versioni future si possono ancora correggere.
- Scaglioni: «fino a» compreso (es. 10 kW rientra nello scaglione «fino a 10») [da confermare, G13].
"""

from __future__ import annotations

from datetime import date
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from ...core.date import iso_locale
from ...core.errori import ErroreUtente, NonTrovato
from ...core.validazioni import numero_italiano
from ..anagrafica.modelli import TIPOLOGIE_IMPIANTO, Impianto
from ..anagrafica.servizio import _b, _crea, _intero, _modificato, _t, controlla_versione
from ..registro import servizio as registro
from .modelli import CRITERI, GRANDEZZE, GRANDEZZE_RIGA, ScaglioneTariffa, VersioneTariffa, VoceTariffa

# Dati che mancano perché la parte d'impianto non c'è (asta, gabbia): la voce semplicemente non si applica
FACOLTATIVE = ("superficie_gabbia", "numero_aste", "asta_presente", "aste_in_piu")
VALORE_FASCIA = {"fino_100": 100.0, "da_101_a_350": 350.0, "oltre_350": 351.0}

# Tariffa terre del gestionale attuale (documento 03 § 2.4), caricata come prima versione
TERRE_PARTENZA = [(10, 15000), (15, 20000), (25, 25000), (50, 30000), (100, 50000), (150, 60000), (200, 70000),
                  (250, 85000), (400, 120000), (650, 135000), (800, 150000), (1000, 170000), (None, 200000)]


def prepara(s: Session) -> None:
    if s.execute(select(func.count()).select_from(VoceTariffa)).scalar():
        return
    voce = VoceTariffa(codice="TERRA-KW", nome="Verifica impianto di messa a terra (scaglioni di potenza)",
                       tipologie="terra_bt,terra_at", criterio="scaglioni", grandezza="potenza_kw", automatica=True,
                       note="Tariffa standard ripresa dal gestionale attuale il 04/10/2026. Da confermare con il tariffario M03-RG01_dpr.",
                       creato_da="Sistema", modificato_da="Sistema")
    versione = VersioneTariffa(valida_dal=date(2026, 1, 1), creata_da="Sistema", note="Prima versione (gestionale attuale)")
    versione.scaglioni = [ScaglioneTariffa(ordine=i, fino_a=f, importo=imp) for i, (f, imp) in enumerate(TERRE_PARTENZA)]
    voce.versioni = [versione]
    s.add(voce)
    s.flush()


# Tariffario M03-RG01_dpr rev. 01 del 30/09/2026 (tariffe D.M. 07/07/2005 + fattispecie di AD), versione 0.4.0
M03_VALIDO_DAL = date(2026, 9, 30)
M03_NOTA = "Da M03-RG01_dpr rev. 01 del 30/09/2026."
TERRE_M03 = [(2.99, 5000, "Sotto 3 kW: tariffa oraria (€ 93/ora, minimo € 50) — usa la voce «TERRA-MENO-3KW»"),
             (10, 15000, ""), (15, 20000, ""), (25, 25000, ""), (50, 30000, ""), (100, 50000, ""), (150, 60000, ""), (200, 70000, ""),
             (250, 85000, ""), (400, 120000, ""), (650, 135000, ""), (800, 150000, ""), (1000, 170000, ""),
             (None, 200000, "Oltre 1.000 kW: tariffa a tempo con minimo € 2.000 — usa la voce «TERRA-OLTRE-1000KW»")]
TUTTE = "terra_bt,terra_at,scariche,esplosione"
TERRE = "terra_bt,terra_at"
TRASFERTA = [("Fino a 4 ore, fino a 50 km", 4300), ("Fino a 4 ore, fino a 100 km", 8000), ("Fino a 4 ore, fino a 150 km", 11600),
             ("Fino a 4 ore, oltre 150 km", 13500), ("Fino a 8 ore, fino a 50 km", 4400), ("Fino a 8 ore, fino a 100 km", 8100),
             ("Fino a 8 ore, fino a 150 km", 11800), ("Fino a 8 ore, oltre 150 km", 13700), ("Oltre 8 ore, fino a 50 km", 6100),
             ("Oltre 8 ore, fino a 100 km", 9800), ("Oltre 8 ore, fino a 150 km", 13500), ("Oltre 8 ore, oltre 150 km", 15300)]
# codice, nome, tipologie, criterio, grandezza, automatica, prezzo, minimo, scaglioni [(fino_a, importo, etichetta)]
VOCI_M03 = [
    ("TERRA-OLTRE-1000KW", "Messa a terra oltre 1.000 kW: a tempo (6430)", TERRE, "unitario", "ore", False, 9300, 200000, None),
    ("TERRA-MENO-3KW", "Messa a terra sotto 3 kW: a ore", TERRE, "unitario", "ore", False, 9300, 5000, None),
    ("TPC", "Misura delle tensioni di passo e contatto, per tecnico (6280)", TERRE, "unitario", "ore", False, 9300, 18600, None),
    ("SCAR-ASTA", "Parafulmine ad asta (6210)", "scariche", "unitario", "asta_presente", True, 10000, None, None),
    ("SCAR-ASTA-PIU", "Ogni asta in più dello stesso complesso (6220)", "scariche", "unitario", "aste_in_piu", True, 5000, None, None),
    ("SCAR-GABBIA", "Parafulmine a gabbia per superficie protetta (6230–6250)", "scariche", "scaglioni", "superficie_gabbia", True, None, None,
     [(100, 10000, ""), (350, 20000, ""), (None, 30000, "")]),
    ("SCAR-STRUTT-ABB", "Strutture metalliche abbinate a verifica di terra (6260)", "scariche", "fisso", "", False, 5000, None, None),
    ("SCAR-STRUTT", "Strutture metalliche non abbinate a verifica di terra (6270)", "scariche", "fisso", "", False, 10000, None, None),
    ("ESPL-ORE", "Impianti in luoghi con pericolo di esplosione: a ore", "esplosione", "unitario", "ore", False, 9300, None, None),
    ("STRAORD-ORE", "Verifica straordinaria con prove parziali: a ore", TUTTE, "unitario", "ore", False, 9300, None, None),
    ("VUOTO", "Sopralluogo a vuoto", TUTTE, "fisso", "", False, 9300, None, None),
    ("DUPLICATO", "Rilascio duplicato di certificazione (6300 / 6440)", TUTTE, "fisso", "", False, 20000, None, None),
    ("TRASFERTA", "Spese di trasferta (tabella per tempo e distanza)", TUTTE, "scaglioni", "scelta", False, None, None,
     [(i + 1, imp, et) for i, (et, imp) in enumerate(TRASFERTA)]),
]


def prepara_m03_rev01(s: Session) -> None:
    """Aggiunge (una volta sola) le voci del tariffario M03-RG01_dpr rev. 01 e la nuova versione della tariffa terre.
    Le voci già presenti con lo stesso codice non vengono toccate (le avrà corrette l'utente)."""
    fatto = False
    terre = s.execute(select(VoceTariffa).where(VoceTariffa.codice == "TERRA-KW")).scalar()
    if terre is not None and not any(v.valida_dal == M03_VALIDO_DAL for v in terre.versioni):
        v = VersioneTariffa(valida_dal=M03_VALIDO_DAL, creata_da="Sistema",
                            note=M03_NOTA + " Sotto 3 kW e oltre 1.000 kW: tariffa a ore (vedi avvisi).")
        v.scaglioni = [ScaglioneTariffa(ordine=i, fino_a=f, importo=imp, etichetta=et) for i, (f, imp, et) in enumerate(TERRE_M03)]
        terre.versioni.append(v)
        fatto = True
    esistenti = set(s.execute(select(VoceTariffa.codice)).scalars())
    ordine = (s.execute(select(func.max(VoceTariffa.ordine))).scalar() or 0) + 1
    for i, (cod, nome, tip, criterio, grandezza, auto, prezzo, minimo, scaglioni) in enumerate(VOCI_M03):
        if cod in esistenti:
            continue
        voce = VoceTariffa(codice=cod, nome=nome, tipologie=tip, criterio=criterio, grandezza=grandezza, automatica=auto, ordine=ordine + i,
                           note=M03_NOTA, creato_da="Sistema", modificato_da="Sistema")
        v = VersioneTariffa(valida_dal=M03_VALIDO_DAL, prezzo=prezzo, minimo=minimo, creata_da="Sistema", note=M03_NOTA)
        v.scaglioni = [ScaglioneTariffa(ordine=j, fino_a=f, importo=imp, etichetta=et) for j, (f, imp, et) in enumerate(scaglioni or [])]
        voce.versioni = [v]
        s.add(voce)
        fatto = True
    if fatto:
        s.flush()
        s.info.pop("tariffario_voci", None)
        registro.scrivi(s, utente=None, azione="tariffario.m03_rev01", oggetto_tipo="tariffa_voce", oggetto_id="M03-RG01",
                        descrizione="Tariffario: caricate le voci del tariffario M03-RG01_dpr rev. 01 del 30/09/2026 (valide dal 30/09/2026)")


# ---------------------------------------------------------------- lettura


def voce_o_404(s: Session, voce_id: int) -> VoceTariffa:
    x = s.get(VoceTariffa, voce_id)
    if x is None:
        raise NonTrovato("Voce del tariffario non trovata: ricarica la pagina.")
    return x


def versione_in_vigore(voce: VoceTariffa, giorno: date) -> VersioneTariffa | None:
    valide = [x for x in voce.versioni if x.valida_dal <= giorno]
    return valide[-1] if valide else None


def versione_json(x: VersioneTariffa, oggi: date) -> dict:
    return {"id": x.id, "valida_dal": x.valida_dal.isoformat(), "prezzo": x.prezzo, "minimo": x.minimo, "note": x.note,
            "creata_il": iso_locale(x.creata_il), "creata_da": x.creata_da, "modificabile": x.valida_dal > oggi,
            "scaglioni": [{"fino_a": g.fino_a, "importo": g.importo, "etichetta": g.etichetta} for g in x.scaglioni]}


def voce_json(x: VoceTariffa) -> dict:
    oggi = date.today()
    vigore = versione_in_vigore(x, oggi)
    return {"id": x.id, "codice": x.codice, "nome": x.nome, "tipologie": [t for t in x.tipologie.split(",") if t],
            "criterio": x.criterio, "grandezza": x.grandezza, "automatica": x.automatica, "attiva": x.attiva,
            "ordine": x.ordine, "note": x.note, "versione": x.versione,
            "versione_in_vigore": vigore.id if vigore else None,
            "versioni": [versione_json(v, oggi) for v in reversed(x.versioni)]}


def dati_voce(x: VoceTariffa) -> dict:
    return {"codice": x.codice, "nome": x.nome, "tipologie": x.tipologie, "criterio": x.criterio, "grandezza": x.grandezza,
            "automatica": x.automatica, "attiva": x.attiva, "ordine": x.ordine, "note": x.note}


# ---------------------------------------------------------------- calcolo


def _quantita(x: Impianto, grandezza: str) -> float | None:
    if grandezza == "potenza_kw":
        return x.potenza_kw
    if grandezza == "superficie_gabbia":
        return VALORE_FASCIA.get(x.gabbia_fascia) if x.gabbia else None
    if grandezza == "numero_aste":
        return x.numero_aste if x.asta else None
    if grandezza == "cabine_mt_bt":
        return x.cabine_mt_bt
    if grandezza == "sottostazioni_at_mt":
        return x.sottostazioni_at_mt
    if grandezza == "numero_zone":
        return len([z for z in x.zone.split(",") if z.strip()]) or None
    if grandezza == "numero_pod":
        return len(x.pod) or None
    if grandezza == "asta_presente":
        return 1.0 if x.asta else None
    if grandezza == "aste_in_piu":
        return float(max((x.numero_aste or 1) - 1, 0)) if x.asta else None
    return None


def _voci_attive(s: Session) -> list[VoceTariffa]:
    """Le voci si leggono una volta per richiesta (servono a ogni riga della griglia)."""
    cache = s.info.get("tariffario_voci")
    if cache is None:
        q = select(VoceTariffa).where(VoceTariffa.attiva.is_(True)).options(
            selectinload(VoceTariffa.versioni).selectinload(VersioneTariffa.scaglioni)).order_by(VoceTariffa.ordine, VoceTariffa.id)
        cache = s.info["tariffario_voci"] = list(s.execute(q).scalars())
    return cache


def _q(n: float) -> str:
    return f"{n:g}".replace(".", ",")


def importo_voce(voce: VoceTariffa, versione: VersioneTariffa, quantita: float | None) -> tuple[int | None, str]:
    """Importo in centesimi e spiegazione; None se manca il dato (dell'impianto o della riga)."""
    if voce.criterio == "fisso":
        return versione.prezzo or 0, "prezzo fisso"
    if quantita is None:
        if voce.grandezza == "ore":
            return None, "scrivi le ore"
        if voce.grandezza == "scelta":
            return None, "scegli la voce dall'elenco"
        return None, f"manca il dato «{GRANDEZZE.get(voce.grandezza, voce.grandezza)}»"
    if voce.criterio == "unitario":
        if not quantita:
            return 0, "quantità zero"
        importo = int(round((versione.prezzo or 0) * quantita))
        unita = " ore" if voce.grandezza == "ore" else ""
        spiegazione = f"{_q(quantita)}{unita} × {(versione.prezzo or 0) / 100:.2f} €".replace(".", ",")
        if versione.minimo and importo < versione.minimo:
            return versione.minimo, spiegazione + f" → minimo {versione.minimo / 100:.2f} €".replace(".", ",")
        return importo, spiegazione
    if voce.grandezza == "scelta":
        g = next((g for g in versione.scaglioni if g.fino_a is not None and int(g.fino_a) == int(quantita)), None)
        return (g.importo, g.etichetta) if g else (None, "voce dell'elenco non valida")
    for g in versione.scaglioni:
        if g.fino_a is None or quantita <= g.fino_a:
            return g.importo, (f"scaglione fino a {_q(g.fino_a)}" if g.fino_a is not None else "scaglione «oltre»")
    return None, "nessuno scaglione adatto: controlla il tariffario"


def avviso_scaglione(voce: VoceTariffa, versione: VersioneTariffa, quantita: float | None) -> str:
    """Testo di avviso dello scaglione usato (es. «sotto 3 kW: tariffa a ore»)."""
    if voce.criterio != "scaglioni" or voce.grandezza == "scelta" or quantita is None:
        return ""
    for g in versione.scaglioni:
        if g.fino_a is None or quantita <= g.fino_a:
            return g.etichetta or ""
    return ""


def voci_orarie_per(s: Session, tipologia: str) -> list[VoceTariffa]:
    """Voci «a ore» non automatiche proprie di una tipologia (es. ESPL-ORE per il pericolo di esplosione)."""
    tutte = set(TIPOLOGIE_IMPIANTO)
    return [v for v in _voci_attive(s) if not v.automatica and v.grandezza == "ore" and tipologia in v.tipologie.split(",")
            and set(v.tipologie.split(",")) != tutte]


def calcola_voce(s: Session, voce_id: int, quantita: float | None, giorno: date | None = None) -> dict:
    """Importo di una voce scelta a mano (riga del preventivo a ore, a scelta, fissa)."""
    voce = next((v for v in _voci_attive(s) if v.id == voce_id), None) or s.get(VoceTariffa, voce_id)
    if voce is None:
        return {"totale": None, "voci": [], "problemi": ["voce del tariffario non trovata"], "avvisi": []}
    versione = versione_in_vigore(voce, giorno or date.today())
    if versione is None:
        return {"totale": None, "voci": [], "problemi": [f"{voce.nome}: nessuna versione in vigore"], "avvisi": []}
    importo, spiegazione = importo_voce(voce, versione, quantita)
    if importo is None:
        return {"totale": None, "voci": [], "problemi": [f"{voce.nome}: {spiegazione}"], "avvisi": []}
    return {"totale": importo, "avvisi": [], "problemi": [],
            "voci": [{"voce": voce.nome, "codice": voce.codice, "importo": importo, "spiegazione": spiegazione,
                      "valida_dal": versione.valida_dal.isoformat()}]}


def calcola(s: Session, x: Impianto, giorno: date | None = None) -> dict:
    """Tariffa standard proposta per l'impianto: totale in centesimi (None se incalcolabile) e dettaglio."""
    giorno = giorno or date.today()
    righe, mancanti, avvisi, totale = [], [], [], 0
    for voce in _voci_attive(s):
        if x.tipologia not in voce.tipologie.split(",") or not voce.automatica:
            continue
        versione = versione_in_vigore(voce, giorno)
        if versione is None:
            mancanti.append(f"{voce.nome}: nessuna versione in vigore")
            continue
        quantita = _quantita(x, voce.grandezza)
        if quantita is None and voce.grandezza in FACOLTATIVE:
            continue  # es. scariche senza gabbia: la voce della gabbia non si applica
        importo, spiegazione = importo_voce(voce, versione, quantita)
        if avviso := avviso_scaglione(voce, versione, quantita):
            avvisi.append(avviso)
        if importo is None:
            if voce.criterio == "scaglioni":
                mancanti.append(f"{voce.nome}: {spiegazione}")
            continue
        if voce.criterio == "unitario" and not importo:
            continue
        righe.append({"voce": voce.nome, "codice": voce.codice, "importo": importo, "spiegazione": spiegazione,
                      "valida_dal": versione.valida_dal.isoformat()})
        totale += importo
    if not righe and not mancanti:
        orarie = voci_orarie_per(s, x.tipologia)
        mancanti.append(f"tariffa a ore: usa la voce «{orarie[0].codice}»" if orarie else "nessuna voce del tariffario per questa tipologia")
    return {"totale": None if mancanti else totale, "voci": righe, "problemi": mancanti, "avvisi": avvisi}


# ---------------------------------------------------------------- scrittura


def _compila_voce(s: Session, x: VoceTariffa, dati: dict) -> None:
    x.codice = _t(dati, "codice", 30).upper()
    x.nome = _t(dati, "nome", 150)
    if not x.codice or not x.nome:
        raise ErroreUtente("Scrivi codice e nome della voce.")
    if s.execute(select(VoceTariffa).where(VoceTariffa.codice == x.codice, VoceTariffa.id != (x.id or 0))).scalar():
        raise ErroreUtente(f"Il codice «{x.codice}» è già usato da un'altra voce.")
    tipologie = [t for t in (dati.get("tipologie") or []) if t in TIPOLOGIE_IMPIANTO]
    if not tipologie:
        raise ErroreUtente("Scegli almeno una tipologia di impianto a cui si applica la voce.")
    x.tipologie = ",".join(tipologie)
    criterio = _t(dati, "criterio", 20)
    if criterio not in CRITERI:
        raise ErroreUtente("Scegli il criterio di calcolo.")
    if x.id and x.criterio and criterio != x.criterio and x.versioni:
        raise ErroreUtente("Il criterio di calcolo non si cambia su una voce che ha già importi: crea una voce nuova e disattiva questa.")
    x.criterio = criterio
    grandezza = _t(dati, "grandezza", 30)
    if criterio != "fisso" and grandezza not in GRANDEZZE:
        raise ErroreUtente("Scegli su quale dato dell'impianto si calcola la voce.")
    x.grandezza = grandezza if criterio != "fisso" else ""
    if x.grandezza == "ore" and criterio != "unitario":
        raise ErroreUtente("Le voci a ore usano il criterio «prezzo unitario × quantità» (prezzo all'ora).")
    if x.grandezza == "scelta" and criterio != "scaglioni":
        raise ErroreUtente("Le voci con elenco a scelta usano il criterio «a scaglioni» (una riga per ogni voce dell'elenco).")
    # le ore e le scelte si scrivono nella riga del preventivo: la voce non può sommarsi da sola
    x.automatica = _b(dati, "automatica") and x.grandezza not in GRANDEZZE_RIGA
    x.attiva = _b(dati, "attiva") if "attiva" in dati else True
    x.ordine = _intero(dati, "ordine", "Ordine") or 0
    x.note = _t(dati, "note", 4000)


def salva_voce(s: Session, attore: Any, dati: dict, voce_id: int | None = None) -> VoceTariffa:
    if voce_id:
        x = voce_o_404(s, voce_id)
        controlla_versione(x, dati.get("versione"))
        prima = dati_voce(x)
    else:
        x, prima = VoceTariffa(), None
    _compila_voce(s, x, dati)
    if prima is None:
        _crea(s, x, attore)
    else:
        _modificato(x, attore)
    s.flush()
    registro.scrivi(s, utente=attore, azione="tariffario.voce_crea" if prima is None else "tariffario.voce_modifica",
                    oggetto_tipo="tariffa_voce", oggetto_id=x.id,
                    descrizione=f"Tariffario: {'creata' if prima is None else 'modificata'} la voce «{x.nome}»",
                    dettagli={"dopo": dati_voce(x)} if prima is None else {"modifiche": registro.differenze(prima, dati_voce(x))})
    return x


def _centesimi(valore: Any, etichetta: str) -> int:
    try:
        n = round(numero_italiano(valore) * 100)
    except ValueError:
        raise ErroreUtente(f"{etichetta}: scrivi un importo (es. 150,00).") from None
    if n < 0:
        raise ErroreUtente(f"{etichetta}: l'importo non può essere negativo.")
    return int(n)


def _compila_versione(voce: VoceTariffa, x: VersioneTariffa, dati: dict) -> None:
    from ..anagrafica.servizio import _data

    valida_dal = _data(dati, "valida_dal", "Valida dal")
    if valida_dal is None:
        raise ErroreUtente("Scrivi da quando vale la versione.")
    if any(v.valida_dal == valida_dal and v.id != x.id for v in voce.versioni):
        raise ErroreUtente("Esiste già una versione che parte dallo stesso giorno: cambia la data.")
    x.valida_dal = valida_dal
    x.note = _t(dati, "note", 2000)
    if voce.criterio == "scaglioni":
        x.prezzo = None
        scaglioni = dati.get("scaglioni") or []
        if not scaglioni:
            raise ErroreUtente("Scrivi almeno uno scaglione.")
        nuovi, precedente = [], None
        for i, g in enumerate(scaglioni):
            fino = (i + 1) if voce.grandezza == "scelta" else g.get("fino_a")
            try:
                fino = None if fino in (None, "") else numero_italiano(fino)
            except ValueError:
                raise ErroreUtente(f"Scaglione {i + 1}: «fino a» deve essere un numero.") from None
            ultimo = i == len(scaglioni) - 1 or voce.grandezza == "scelta"
            if fino is None and not ultimo:
                raise ErroreUtente(f"Scaglione {i + 1}: solo l'ultimo può essere «oltre» (senza limite).")
            if fino is not None and precedente is not None and fino <= precedente:
                raise ErroreUtente(f"Scaglione {i + 1}: i limiti «fino a» devono crescere ({fino:g} non è maggiore di {precedente:g}).")
            precedente = fino if fino is not None else precedente
            nuovi.append(ScaglioneTariffa(ordine=i, fino_a=fino, importo=_centesimi(g.get("importo"), f"Scaglione {i + 1}"),
                                          etichetta=str(g.get("etichetta") or "").strip()[:200]))
        if voce.grandezza == "scelta":
            if any(not g.etichetta for g in nuovi):
                raise ErroreUtente("Elenco a scelta: scrivi la descrizione di ogni voce.")
            for i, g in enumerate(nuovi):
                g.fino_a = float(i + 1)  # nell'elenco a scelta «fino a» è solo il numero d'ordine
        elif nuovi[-1].fino_a is not None:
            raise ErroreUtente("L'ultimo scaglione deve essere «oltre» (lascia vuoto «fino a»), così ogni valore ha una tariffa.")
        x.scaglioni = nuovi
        x.minimo = None
    else:
        if dati.get("prezzo") in (None, ""):
            raise ErroreUtente("Scrivi il prezzo.")
        x.prezzo = _centesimi(dati.get("prezzo"), "Prezzo")
        x.minimo = _centesimi(dati.get("minimo"), "Minimo") if voce.criterio == "unitario" and dati.get("minimo") not in (None, "") else None
        x.scaglioni = []


def aggiungi_versione(s: Session, attore: Any, voce_id: int, dati: dict) -> VersioneTariffa:
    voce = voce_o_404(s, voce_id)
    x = VersioneTariffa(voce_id=voce.id, creata_da=getattr(attore, "nome", ""))
    _compila_versione(voce, x, dati)
    voce.versioni.append(x)
    _modificato(voce, attore)
    s.flush()
    registro.scrivi(s, utente=attore, azione="tariffario.versione_crea", oggetto_tipo="tariffa_voce", oggetto_id=voce.id,
                    descrizione=f"Tariffario: nuova versione di «{voce.nome}» valida dal {x.valida_dal.strftime('%d/%m/%Y')}",
                    dettagli={"versione": versione_json(x, date.today())})
    return x


def _versione_futura(s: Session, versione_id: int) -> VersioneTariffa:
    x = s.get(VersioneTariffa, versione_id)
    if x is None:
        raise NonTrovato("Versione non trovata: ricarica la pagina.")
    if x.valida_dal <= date.today():
        raise ErroreUtente("Questa versione è già in vigore (o lo è stata): non si modifica. Aggiungi una versione nuova con la data da cui cambiano gli importi.")
    return x


def modifica_versione(s: Session, attore: Any, versione_id: int, dati: dict) -> VersioneTariffa:
    x = _versione_futura(s, versione_id)
    prima = versione_json(x, date.today())
    x.scaglioni.clear()
    s.flush()
    _compila_versione(x.voce, x, dati)
    _modificato(x.voce, attore)
    s.flush()
    registro.scrivi(s, utente=attore, azione="tariffario.versione_modifica", oggetto_tipo="tariffa_voce", oggetto_id=x.voce_id,
                    descrizione=f"Tariffario: corretta la versione futura di «{x.voce.nome}» (dal {x.valida_dal.strftime('%d/%m/%Y')})",
                    dettagli={"prima": prima, "dopo": versione_json(x, date.today())})
    return x


def elimina_versione(s: Session, attore: Any, versione_id: int) -> None:
    x = _versione_futura(s, versione_id)
    voce, prima = x.voce, versione_json(x, date.today())
    voce.versioni.remove(x)
    _modificato(voce, attore)
    s.flush()
    registro.scrivi(s, utente=attore, azione="tariffario.versione_elimina", oggetto_tipo="tariffa_voce", oggetto_id=voce.id,
                    descrizione=f"Tariffario: eliminata la versione futura di «{voce.nome}»", dettagli={"prima": prima})


def prova_calcolo(s: Session, dati: dict) -> dict:
    """Calcolo su un impianto immaginario (pulsante «Prova il calcolo» del tariffario)."""
    from ..anagrafica.servizio import _data, _decimale

    x = Impianto(tipologia=_t(dati, "tipologia", 20), potenza_kw=_decimale(dati, "potenza_kw", "Potenza"),
                 cabine_mt_bt=_intero(dati, "cabine_mt_bt", "Cabine"), sottostazioni_at_mt=_intero(dati, "sottostazioni_at_mt", "Sottostazioni"),
                 asta=_b(dati, "asta"), numero_aste=_intero(dati, "numero_aste", "Aste"), gabbia=_b(dati, "gabbia"),
                 gabbia_fascia=_t(dati, "gabbia_fascia", 20), zone=", ".join(dati.get("zone") or []))
    return calcola(s, x, _data(dati, "giorno", "Giorno") or date.today())
