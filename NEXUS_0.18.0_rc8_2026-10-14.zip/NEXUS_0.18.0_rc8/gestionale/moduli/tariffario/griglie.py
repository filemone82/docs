"""Griglia delle voci del tariffario."""

from __future__ import annotations

from sqlalchemy import func, select

from ...core.sql_portabile import oggi_italiano, data_tra_giorni, anno_dopo, giorni_fra, testi_uniti, json_testo
from ...core.griglia import Colonna, Griglia, registra
from ..anagrafica.griglie import etichetta
from ..anagrafica.modelli import TIPOLOGIE_IMPIANTO
from .modelli import CRITERI, GRANDEZZE, VersioneTariffa, VoceTariffa

OGGI = oggi_italiano()
IN_VIGORE_DAL = (select(func.max(VersioneTariffa.valida_dal)).where(VersioneTariffa.voce_id == VoceTariffa.id,
                                                                    VersioneTariffa.valida_dal <= OGGI)
                 .correlate(VoceTariffa).scalar_subquery())
PROSSIMA_DAL = (select(func.min(VersioneTariffa.valida_dal)).where(VersioneTariffa.voce_id == VoceTariffa.id,
                                                                   VersioneTariffa.valida_dal > OGGI)
                .correlate(VoceTariffa).scalar_subquery())
TIPOLOGIE_TESTO = VoceTariffa.tipologie
for _codice, _testo in TIPOLOGIE_IMPIANTO.items():  # codici → nomi leggibili («terra_bt,scariche» → «Messa a terra…, Scariche…»)
    TIPOLOGIE_TESTO = func.replace(TIPOLOGIE_TESTO, _codice, _testo)
TIPOLOGIE_TESTO = func.replace(TIPOLOGIE_TESTO, ",", ", ")
N_VERSIONI = select(func.count(VersioneTariffa.id)).where(VersioneTariffa.voce_id == VoceTariffa.id).correlate(VoceTariffa).scalar_subquery()

registra(Griglia(
    codice="tariffario", titolo="Tariffario", permesso="tariffario.vedere", da=lambda: VoceTariffa.__table__,
    ordine_predefinito=[("ordine", "asc"), ("codice", "asc")],
    colonne=[
        Colonna("id", "N.", "numero", VoceTariffa.id, visibile=False, larghezza=60),
        Colonna("ordine", "Ordine", "numero", VoceTariffa.ordine, larghezza=70),
        Colonna("codice", "Codice", "testo", VoceTariffa.codice, larghezza=110),
        Colonna("nome", "Voce", "testo", VoceTariffa.nome, larghezza=320),
        Colonna("tipologie", "Si applica a", "testo", TIPOLOGIE_TESTO, larghezza=300),
        Colonna("criterio", "Criterio di calcolo", "elenco", etichetta(VoceTariffa.criterio, CRITERI), larghezza=230,
                opzioni=tuple(CRITERI.values())),
        Colonna("grandezza", "Calcolata su", "elenco", etichetta(VoceTariffa.grandezza, GRANDEZZE), larghezza=200,
                opzioni=tuple(GRANDEZZE.values())),
        Colonna("automatica", "Automatica", "booleano", VoceTariffa.automatica, larghezza=90),
        Colonna("attiva", "Attiva", "booleano", VoceTariffa.attiva, larghezza=80),
        Colonna("in_vigore_dal", "Importi in vigore dal", "data", IN_VIGORE_DAL, larghezza=130),
        Colonna("prossima_dal", "Prossimi importi dal", "data", PROSSIMA_DAL, larghezza=130),
        Colonna("versioni", "N. versioni", "numero", N_VERSIONI, larghezza=90),
        Colonna("note", "Note", "testo", VoceTariffa.note, visibile=False, larghezza=240),
        Colonna("modificato_il", "Ultima modifica", "dataora", VoceTariffa.modificato_il, visibile=False, larghezza=140),
    ],
))
