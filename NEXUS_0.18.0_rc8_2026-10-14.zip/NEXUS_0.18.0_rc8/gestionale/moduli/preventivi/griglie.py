"""Griglie dei preventivi e delle righe, con i dati del cliente (e di impianto e sede per le righe) (D43)."""

from __future__ import annotations

from sqlalchemy import String, case, cast, func, select
from sqlalchemy.orm import aliased

from ...core.griglia import REGISTRO_GRIGLIE, Colonna, Griglia, registra
from ..anagrafica.griglie import _con_dati_cliente, colonne_cliente, colonne_impianto, colonne_sede, etichetta
from ..anagrafica.modelli import Cliente, Commerciale, Impianto, Sede
from ..beni.modelli import Asset
from ..dm.modelli import STATI_DM, IncaricoDM
from ..utenti.modelli import Utente
from ..verifiche.modelli import STATI as STATI_VERIFICA
from ..verifiche.modelli import Verifica
from .copertura import condizione_copertura
from .modelli import ESITI_RIESAME, STATI, STATI_RIGA, TIPI_VERIFICA, Preventivo, Riesame, RigaPreventivo

AssetRiga = aliased(Asset, name="asset_riga")

CommercialePreventivo = aliased(Commerciale, name="commerciale_preventivo")
ETICHETTA = case((Preventivo.revisione > 0, Preventivo.codice + " rev. " + cast(Preventivo.revisione, String)),
                 else_=Preventivo.codice)
N_RIGHE = select(func.count(RigaPreventivo.id)).where(RigaPreventivo.preventivo_id == Preventivo.id).correlate(Preventivo).scalar_subquery()
N_ACCETTATE = (select(func.count(RigaPreventivo.id)).where(RigaPreventivo.preventivo_id == Preventivo.id, RigaPreventivo.stato == "accettata")
               .correlate(Preventivo).scalar_subquery())
ESITO_RIESAME = etichetta(select(Riesame.esito).where(Riesame.preventivo_id == Preventivo.id).order_by(Riesame.id.desc()).limit(1)
                          .correlate(Preventivo).scalar_subquery(), ESITI_RIESAME)


def colonne_preventivo(prefisso: str = "", titolo: str = "", visibili: tuple[str, ...] = ()) -> list[Colonna]:
    t = (titolo + " · ") if titolo else ""
    vis = set(visibili)

    def c(campo, etich, tipo, espr, larghezza=130, **kw):  # noqa: ANN001, ANN202
        if prefisso:
            kw.pop("somma", None)  # nelle righe i totali del preventivo si ripeterebbero: niente somma
        return Colonna(prefisso + campo, t + etich, tipo, espr, visibile=campo in vis, larghezza=larghezza, **kw)

    return [
        c("id", "N. interno", "numero", Preventivo.id, 90),
        c("etichetta", "Preventivo", "testo", ETICHETTA, 130),
        c("anno", "Anno", "numero", Preventivo.anno, 70),
        c("numero", "Numero", "numero", Preventivo.numero, 80),
        c("revisione", "Revisione", "numero", Preventivo.revisione, 80),
        c("data", "Data", "data", Preventivo.data, 100),
        c("stato", "Stato", "elenco", etichetta(Preventivo.stato, STATI), 170, opzioni=tuple(STATI.values())),
        c("commerciale", "Commerciale", "testo", CommercialePreventivo.nome, 140),
        c("totale_standard", "Totale standard", "importo", Preventivo.totale_standard, 120, somma=True),
        c("totale", "Totale", "importo", Preventivo.totale, 120, somma=True, descrizione="Somma delle tariffe applicate (righe non rifiutate né annullate)"),
        c("n_righe", "Righe", "numero", N_RIGHE, 70),
        c("n_accettate", "Righe accettate", "numero", N_ACCETTATE, 100),
        c("inviato_il", "Inviato il", "dataora", Preventivo.inviato_il, 140),
        c("rif_ordine", "Rif. ordine cliente", "testo", Preventivo.rif_ordine, 140),
        c("data_ordine", "Data ordine", "data", Preventivo.data_ordine, 100),
        c("riesame", "Riesame", "elenco", ESITO_RIESAME, 110, opzioni=tuple(ESITI_RIESAME.values())),
        c("modalita_pagamento", "Modalità di pagamento", "testo", Preventivo.modalita_pagamento, 170),
        c("termine_esecuzione", "Termine di esecuzione", "testo", Preventivo.termine_esecuzione, 170),
        c("motivo_annullamento", "Motivo annullamento", "testo", Preventivo.motivo_annullamento, 180),
        c("note", "Note preventivo", "testo", Preventivo.note, 180),
        c("modificato_il", "Ultima modifica preventivo", "dataora", Preventivo.modificato_il, 140),
        c("modificato_da", "Modificato da (preventivo)", "testo", Preventivo.modificato_da, 140),
    ]


def _da_preventivo():  # noqa: ANN202
    return _con_dati_cliente(Preventivo.__table__.join(Cliente.__table__, Preventivo.cliente_id == Cliente.id)
                             .outerjoin(CommercialePreventivo, Preventivo.commerciale_id == CommercialePreventivo.id))


registra(Griglia(
    codice="preventivi", titolo="Preventivi DPR", permesso="preventivi.vedere", da=_da_preventivo,
    condizione=lambda u: Preventivo.ambito == "DPR",
    ordine_predefinito=[("anno", "desc"), ("numero", "desc"), ("revisione", "desc")],
    colonne=[
        *colonne_preventivo(visibili=("etichetta", "data", "stato", "totale", "n_righe", "n_accettate", "inviato_il", "rif_ordine", "riesame")),
        *colonne_cliente("cliente_", "Cliente", visibili=("ragione_sociale",)),
    ],
))


def _da_righe():  # noqa: ANN202
    return _con_dati_cliente(
        RigaPreventivo.__table__.join(Preventivo.__table__, RigaPreventivo.preventivo_id == Preventivo.id)
        .outerjoin(CommercialePreventivo, Preventivo.commerciale_id == CommercialePreventivo.id)
        .outerjoin(Impianto.__table__, RigaPreventivo.impianto_id == Impianto.id)   # 0.4.0: righe senza impianto
        .outerjoin(Sede.__table__, Impianto.sede_id == Sede.id)
        .join(Cliente.__table__, Preventivo.cliente_id == Cliente.id))


def colonne_verifica(modello, stati: dict) -> list[Colonna]:
    """0.12.6 (Federico, 11/10/2026): dalle righe accettate si affida l'incarico, come in Garda. Verifica (DPR) o
    incarico (DM) nati dalla riga dopo il riesame del contratto conforme: numero, stato e tecnico."""
    def sotto(colonna):  # noqa: ANN001, ANN202
        # 0.12.8: dopo una revoca (R124) la riga può avere anche verifiche annullate: si mostra la più recente
        return (select(colonna).where(modello.riga_id == RigaPreventivo.id).correlate(RigaPreventivo)
                .order_by(modello.id.desc()).limit(1).scalar_subquery())

    tecnico = (select(Utente.nome).join(modello, modello.verificatore_id == Utente.id)
               .where(modello.riga_id == RigaPreventivo.id).correlate(RigaPreventivo)
               .order_by(modello.id.desc()).limit(1).scalar_subquery())
    return [
        Colonna("verifica_id", "N. verifica", "numero", sotto(modello.id), visibile=False, larghezza=90),
        Colonna("verifica_versione", "Versione verifica", "numero", sotto(modello.versione), visibile=False, larghezza=80),
        Colonna("verifica_stato", "Stato verifica", "elenco", etichetta(sotto(modello.stato), stati), larghezza=150,
                opzioni=tuple(stati.values()), descrizione="Vuoto: verifica non ancora nata (serve il riesame del contratto conforme)"),
        Colonna("verificatore", "Verificatore", "testo", tecnico, larghezza=160),
        Colonna("da_fatturare", "Da fatturare", "elenco", _da_fatturare_sql(), larghezza=100, opzioni=("Sì", "No"),
                descrizione="Lavoro concluso e riesaminato conforme, riga non ancora fatturata (N7/R125, 0.12.8)"),
    ]


def _da_fatturare_sql():  # noqa: ANN202
    from sqlalchemy import case

    from ..finanza.da_fatturare import da_fatturare
    return case((da_fatturare(RigaPreventivo), "Sì"), else_="No")


registra(Griglia(
    codice="righe_preventivi", titolo="Righe dei preventivi", permesso="preventivi.vedere", da=_da_righe,
    condizione=lambda u: Preventivo.ambito == "DPR",
    ordine_predefinito=[("preventivo_anno", "desc"), ("preventivo_numero", "desc"), ("ordine", "asc")],
    colonne=[
        Colonna("id", "N. riga", "numero", RigaPreventivo.id, visibile=False, larghezza=80),
        Colonna("ordine", "Riga", "numero", RigaPreventivo.ordine, larghezza=60),
        Colonna("stato_riga", "Stato riga", "elenco", etichetta(RigaPreventivo.stato, STATI_RIGA), larghezza=110, opzioni=tuple(STATI_RIGA.values())),
        Colonna("tipo_verifica", "Tipo verifica", "elenco", etichetta(RigaPreventivo.tipo_verifica, TIPI_VERIFICA), larghezza=110,
                opzioni=tuple(TIPI_VERIFICA.values())),
        Colonna("riga_sede", "Sede (in stampa)", "testo", RigaPreventivo.sede_nome, larghezza=220),
        Colonna("riga_comune", "Comune (in stampa)", "testo", RigaPreventivo.sede_comune, visibile=False, larghezza=160),
        Colonna("riga_descrizione", "Descrizione", "testo", RigaPreventivo.descrizione, larghezza=140),
        Colonna("tariffa_standard", "Tariffa standard", "importo", RigaPreventivo.tariffa_standard, larghezza=110, somma=True),
        Colonna("sconto", "Sconto %", "numero", RigaPreventivo.sconto / 100.0, larghezza=80),
        Colonna("tariffa_applicata", "Tariffa applicata", "importo", RigaPreventivo.tariffa_applicata, larghezza=120, somma=True),
        Colonna("stato_il", "Stato riga dal", "dataora", RigaPreventivo.stato_il, visibile=False, larghezza=140),
        *colonne_verifica(Verifica, STATI_VERIFICA),
        *colonne_preventivo("preventivo_", "Preventivo", visibili=("etichetta", "data", "stato")),
        *[c for c in colonne_impianto(("id", "tipologia"), "impianto_", "Impianto") if not c.calcolata],
        *colonne_sede("sede_", "Sede", visibili=()),
        *colonne_cliente("cliente_", "Cliente", visibili=("ragione_sociale",)),
    ],
))

# ---------------------------------------------------------------- scadenziario: legame con i preventivi (D19)
# La stessa regola del backend: prestazione periodica non annullata né completata.
_viva = condizione_copertura(Impianto.id)
_ultima = (select(RigaPreventivo.id).join(Preventivo, RigaPreventivo.preventivo_id == Preventivo.id).where(_viva)
           .order_by(RigaPreventivo.id.desc()).limit(1).correlate(Impianto).scalar_subquery())
_riga = aliased(RigaPreventivo, name="riga_aperta")
_prev = aliased(Preventivo, name="preventivo_aperto")
SCAD_PREVENTIVO = (select(case((_prev.revisione > 0, _prev.codice + " rev. " + cast(_prev.revisione, String)), else_=_prev.codice))
                   .select_from(_riga).join(_prev, _riga.preventivo_id == _prev.id).where(_riga.id == _ultima).correlate(Impianto).scalar_subquery())
SCAD_STATO_PREVENTIVO = etichetta(select(_prev.stato).select_from(_riga).join(_prev, _riga.preventivo_id == _prev.id)
                                  .where(_riga.id == _ultima).correlate(Impianto).scalar_subquery(), STATI)
SCAD_STATO_RIGA = etichetta(select(_riga.stato).where(_riga.id == _ultima).correlate(Impianto).scalar_subquery(), STATI_RIGA)
SCAD_ID_PREVENTIVO = select(_riga.preventivo_id).where(_riga.id == _ultima).correlate(Impianto).scalar_subquery()
SCAD_IN_PREVENTIVO = case((_ultima.is_(None), False), else_=True)

COLONNE_SCADENZE_PREVENTIVO = [
    Colonna("in_preventivo", "In un preventivo", "booleano", SCAD_IN_PREVENTIVO, larghezza=100, visibile=False,
            descrizione="Sì = verifica periodica già preventivata, non annullata né completata"),
    Colonna("preventivo", "Preventivo", "testo", SCAD_PREVENTIVO, larghezza=120),
    Colonna("preventivo_id", "N. interno preventivo", "numero", SCAD_ID_PREVENTIVO, visibile=False, larghezza=90),
    Colonna("stato_preventivo", "Stato preventivo", "elenco", SCAD_STATO_PREVENTIVO, larghezza=150, opzioni=tuple(STATI.values())),
    Colonna("stato_riga", "Stato riga", "elenco", SCAD_STATO_RIGA, larghezza=110, opzioni=tuple(STATI_RIGA.values())),
]


def _aggiungi_allo_scadenziario() -> None:
    from ..anagrafica.griglie import SCADENZE

    if any(c.campo == "preventivo" for c in SCADENZE.colonne):
        return
    posizione = next(i for i, c in enumerate(SCADENZE.colonne) if c.campo == "tariffa") + 1
    SCADENZE.colonne[posizione:posizione] = COLONNE_SCADENZE_PREVENTIVO


_aggiungi_allo_scadenziario()


# 0.12.10 (doc. 30, § 6): fatturato (No / Parziale / Totale) sulle righe accettate e riesame in tre valori
def _fatturato():  # noqa: ANN202
    from ..finanza.da_fatturare import gia_fatturata

    rf = aliased(RigaPreventivo, name="riga_fatt")
    accettate = select(func.count(rf.id)).where(rf.preventivo_id == Preventivo.id, rf.stato == "accettata").correlate(Preventivo).scalar_subquery()
    fatturate = (select(func.count(rf.id)).where(rf.preventivo_id == Preventivo.id, rf.stato == "accettata", gia_fatturata(rf))
                 .correlate(Preventivo).scalar_subquery())
    return case((fatturate == 0, "No"), (fatturate >= accettate, "Totale"), else_="Parziale")


FATTURATO = _fatturato()
RIESAME_TRE = case((ESITO_RIESAME.is_(None), "No"), (ESITO_RIESAME == ESITI_RIESAME.get("conforme", "Conforme"), "Sì, esito positivo"),
                   else_="Sì, esito negativo")


registra(Griglia(
    codice="preventivi_dm", titolo="Preventivi DM", permesso="preventivi.vedere", da=_da_preventivo,
    condizione=lambda u: Preventivo.ambito == "DM",
    ordine_predefinito=[("anno", "desc"), ("numero", "desc")],
    colonne=[*colonne_preventivo(visibili=("etichetta", "data", "stato", "totale", "n_righe", "riesame")),
             Colonna("fatturato", "Fatturato", "elenco", FATTURATO, larghezza=100, opzioni=("No", "Parziale", "Totale"),
                     descrizione="Righe accettate fatturate: nessuna, alcune, tutte"),
             Colonna("riesame_tre", "Riesame preventivo", "elenco", RIESAME_TRE, larghezza=150,
                     opzioni=("No", "Sì, esito positivo", "Sì, esito negativo")),
             Colonna("sede", "Sede operativa", "testo", select(Sede.denominazione).where(Sede.id == Preventivo.sede_id).scalar_subquery(), larghezza=220),
             *colonne_cliente("cliente_", "Cliente", visibili=("ragione_sociale",))],
))


def _etichette_dm():  # noqa: ANN202
    from ..dm.servizio import GVR, TIPI  # import tardivo: dm.servizio importa i preventivi

    return dict(TIPI), dict(GVR)


_TIPI_DM, _GVR = _etichette_dm()


def _da_righe_dm():  # noqa: ANN202
    return _con_dati_cliente(
        RigaPreventivo.__table__.join(Preventivo.__table__, RigaPreventivo.preventivo_id == Preventivo.id)
        .outerjoin(CommercialePreventivo, Preventivo.commerciale_id == CommercialePreventivo.id)
        .outerjoin(AssetRiga, RigaPreventivo.asset_id == AssetRiga.id)
        .outerjoin(Sede.__table__, Preventivo.sede_id == Sede.id)
        .join(Cliente.__table__, Preventivo.cliente_id == Cliente.id))


registra(Griglia(
    codice="righe_preventivi_dm", titolo="Righe dei preventivi DM", permesso="preventivi.vedere", da=_da_righe_dm,
    condizione=lambda u: Preventivo.ambito == "DM",
    ordine_predefinito=[("preventivo_anno", "desc"), ("preventivo_numero", "desc"), ("ordine", "asc")],
    colonne=[
        Colonna("id", "N. riga", "numero", RigaPreventivo.id, visibile=False, larghezza=80),
        Colonna("ordine", "Riga", "numero", RigaPreventivo.ordine, larghezza=60),
        Colonna("stato_riga", "Stato riga", "elenco", etichetta(RigaPreventivo.stato, STATI_RIGA), larghezza=110, opzioni=tuple(STATI_RIGA.values())),
        Colonna("gruppo", "Gruppo", "elenco", AssetRiga.gruppo, larghezza=80, opzioni=("SC", "SP", "GVR", "PSV")),
        Colonna("asset_id", "N. attrezzatura", "numero", RigaPreventivo.asset_id, visibile=False, larghezza=90),
        Colonna("matricola", "Attrezzatura", "testo", AssetRiga.matr_informale, larghezza=170),
        Colonna("tipo_verifica_dm", "Verifica", "elenco", case(_TIPI_DM, value=RigaPreventivo.tipo_verifica_dm, else_=RigaPreventivo.tipo_verifica_dm),
                larghezza=130, opzioni=tuple(_TIPI_DM.values())),
        Colonna("tipo_verifica_gvr", "Attività GVR", "elenco", case(_GVR, value=RigaPreventivo.tipo_verifica_gvr, else_=RigaPreventivo.tipo_verifica_gvr),
                larghezza=200, opzioni=tuple(_GVR.values())),
        Colonna("riga_descrizione", "Descrizione", "testo", RigaPreventivo.descrizione, visibile=False, larghezza=160),
        Colonna("tariffa_applicata", "Tariffa applicata", "importo", RigaPreventivo.tariffa_applicata, larghezza=120, somma=True),
        *colonne_verifica(IncaricoDM, STATI_DM),
        *colonne_preventivo("preventivo_", "Preventivo", visibili=("etichetta", "data", "stato")),
        *colonne_sede("sede_", "Sede", visibili=("denominazione",)),
        *colonne_cliente("cliente_", "Cliente", visibili=("ragione_sociale",)),
    ],
))


REGISTRO_GRIGLIE["preventivi_dm"].viste_predefinite = {"": {"colonne": [
    "etichetta", "data", "stato", "fatturato", "cliente_ragione_sociale", "sede", "totale_standard", "totale", "riesame_tre"]}}


# C23 (13/10/2026): righe accessibili solo nel contesto del singolo preventivo.
for codice, campi in (
    ("righe_preventivi", ["riga_sede", "stato_riga", "tipo_verifica", "impianto_id", "impianto_tipologia",
                          "tariffa_applicata", "verifica_stato", "verificatore", "da_fatturare"]),
    ("righe_preventivi_dm", ["sede_denominazione", "stato_riga", "tipo_verifica_dm", "matricola", "gruppo",
                             "tipo_verifica_gvr", "tariffa_applicata", "verifica_stato", "verificatore", "da_fatturare"]),
):
    g = REGISTRO_GRIGLIE[codice]
    g.contesto_campo = "preventivo_id"
    g.viste_predefinite = {"": {"colonne": campi}}
    g.ordine_predefinito = [("ordine", "asc")]
REGISTRO_GRIGLIE["righe_preventivi"].colonna("riga_sede").etichetta = "Sede operativa"
REGISTRO_GRIGLIE["righe_preventivi"].colonna("impianto_id").etichetta = "Impianto"
REGISTRO_GRIGLIE["righe_preventivi"].colonna("impianto_tipologia").etichetta = "Tipologia"
# C19: aggiorna la vista Scadenze includendo le colonne dei preventivi aggiunte sopra.
_g = REGISTRO_GRIGLIE["scadenze"]
_g.viste_predefinite = {"": {"colonne": ["cliente_ragione_sociale", *[
    c.campo for c in _g.colonne if c.visibile and c.campo != "cliente_ragione_sociale"]],
    "raggruppa": "cliente_ragione_sociale"}}
