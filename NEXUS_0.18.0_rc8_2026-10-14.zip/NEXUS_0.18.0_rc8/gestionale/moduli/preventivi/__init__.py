"""Preventivi (fase 4, versione 0.3.0)."""
