"""Regole dei preventivi (D13–D19, D26, D36, D38, D39; documento 09).

Ciclo di vita:
- «creato»: si modifica liberamente (testata, righe, sconti); si elimina solo se mai inviato (revisione 0);
- «inviato» (all'invio email o segnato a mano): per cambiare righe o prezzi si crea una REVISIONE (D16);
  la precedente diventa «sostituito» e resta com'era;
- accettazione per riga: «in attesa», «accettata», «rifiutata», «annullata»; lo stato del preventivo si
  calcola dalle righe (D13). Con almeno una riga accettata il preventivo è FISSATO (D19): righe e prezzi
  non cambiano più; restano modificabili stato delle righe, rif. ordine e note;
- «annullato»: a mano, con motivo; il riesame (D17) si fa dopo l'accettazione.

Documento (0.7.0, D80, stesso metodo dei verbali di VerbalizzAI):
- «Anteprima» prepara e ARCHIVIA Word e PDF con l'impronta dei dati stampati; si controlla e si APPROVA (presa visione);
- si invia (email o «segna come inviato») SOLO il PDF approvato dell'ultima preparazione con i dati attuali;
- ritocchi di sola impaginazione: si ricarica il Word, il programma controlla che testo, numeri e immagini siano
  identici e rifà il PDF (un solo motore, LibreOffice); solo prima dell'invio, dopo si fa una revisione.
"""

from __future__ import annotations

import hashlib
import json
import re
import secrets
from datetime import date
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ...core import posta, word
from ...core.date import formatta_data, iso_locale
from ...core.db import adesso
from ...core.errori import ErroreUtente, NonTrovato, PermessoNegato
from ..anagrafica.modelli import FASCE_GABBIA, TIPOLOGIE_IMPIANTO, Cliente, Commerciale, Impianto, Sede
from ..anagrafica.servizio import _crea, _data, _modificato, _t, controlla_versione
from ..documenti import modelli_servizio as modelli
from ..documenti import servizio as documenti
from ..documenti.modelli import Documento
from ..impostazioni.modelli import Impostazione
from ..registro import servizio as registro
from ..tariffario import servizio as tariffario
from . import copertura
from .modelli import (ESITI_RIESAME, STATI, STATI_RIGA, TIPI_VERIFICA, DocumentoPreventivo, InvioPreventivo, Preventivo, Riesame,
                      RigaPreventivo)

STATI_APERTI = ("creato", "inviato", "accettato_parzialmente", "accettato_totalmente")
TESTI_EMAIL = {
    "oggetto": "Preventivo {numero} – {cliente} – verifiche D.P.R. 462/01",
    "testo": ("Gentile Cliente,\n\n"
              "in allegato trasmettiamo il nostro preventivo n. {numero} del {data} per le verifiche ai sensi del D.P.R. 462/01 "
              "degli impianti indicati, per un importo complessivo di {totale} oltre I.V.A.\n\n"
              "Per accettare l'offerta è sufficiente restituire il preventivo firmato per accettazione oppure inviare il vostro ordine.\n\n"
              "Restiamo a disposizione per qualsiasi chiarimento.\n\nCordiali saluti"),
    "firma": "AD S.r.l. – Organismo abilitato D.P.R. 462/01\nelettrico@adsrl.net · www.adsrl.net",
}
CAMPI_EMAIL = [("numero", "Numero del preventivo (es. P_001_26)"), ("data", "Data del preventivo"), ("cliente", "Ragione sociale"),
               ("totale", "Totale (tariffe applicate)"), ("commerciale", "Commerciale AD")]


# ---------------------------------------------------------------- strumenti


def euro(centesimi: int | None) -> str:
    if centesimi is None:
        return ""
    intero, cent = divmod(abs(int(centesimi)), 100)
    testo = f"{intero:,}".replace(",", ".") + f",{cent:02d}"
    return ("- " if centesimi < 0 else "") + "€ " + testo


def codice(anno: int, numero: int) -> str:
    return f"P_{numero:03d}_{anno % 100:02d}"


def etichetta(p: Preventivo) -> str:
    return p.codice + (f" rev. {p.revisione}" if p.revisione else "")


def preventivo_o_404(s: Session, preventivo_id: int) -> Preventivo:
    p = s.get(Preventivo, preventivo_id)
    if p is None:
        raise NonTrovato("Preventivo non trovato: forse è stato eliminato. Ricarica la pagina.")
    return p


def modificabile(p: Preventivo) -> bool:
    return p.stato == "creato"


def fissato(p: Preventivo) -> bool:
    return any(r.stato == "accettata" for r in p.righe)


def _richiedi_modificabile(p: Preventivo) -> None:
    if p.stato == "creato":
        return
    if p.stato == "inviato":
        raise ErroreUtente(f"Il preventivo {etichetta(p)} è già stato inviato: per cambiare righe o prezzi crea una revisione (D16).")
    raise ErroreUtente(f"Il preventivo {etichetta(p)} è «{STATI[p.stato]}»: righe e prezzi non si cambiano più.")


def _impostazione(s: Session, chiave: str, predefinito: Any) -> Any:
    x = s.get(Impostazione, chiave)
    return json.loads(x.valore) if x else predefinito


def testi_email(s: Session) -> dict:
    return {**TESTI_EMAIL, **_impostazione(s, "preventivi.email", {})}


def salva_testi_email(s: Session, attore: Any, dati: dict) -> dict:
    nuovi = {k: str(dati.get(k) or "")[:5000] for k in TESTI_EMAIL}
    if not nuovi["oggetto"].strip():
        raise ErroreUtente("Scrivi l'oggetto dell'email.")
    x = s.get(Impostazione, "preventivi.email")
    prima = json.loads(x.valore) if x else {}
    if x is None:
        x = Impostazione(chiave="preventivi.email", valore="{}")
        s.add(x)
    x.valore, x.aggiornata_da = json.dumps(nuovi, ensure_ascii=False), getattr(attore, "id", None)
    registro.scrivi(s, utente=attore, azione="impostazioni.email_preventivi", oggetto_tipo="impostazione", oggetto_id="preventivi.email",
                    descrizione="Modificati i testi standard delle email dei preventivi", dettagli={"modifiche": registro.differenze(prima, nuovi)})
    return nuovi


# ---------------------------------------------------------------- righe


def descrizione_impianto(x: Impianto) -> str:
    """Breve descrizione per la colonna «potenza» dell'offerta."""
    if x.tipologia in ("terra_bt", "terra_at"):
        parti = [f"{x.potenza_kw:g} kW".replace(".", ",") if x.potenza_kw is not None else ""]
        if x.cabine_mt_bt:
            parti.append(f"{x.cabine_mt_bt} cabine MT/BT" if x.cabine_mt_bt > 1 else "1 cabina MT/BT")
        return "; ".join(p for p in parti if p)
    if x.tipologia == "scariche":
        parti = []
        if x.asta:
            parti.append(f"{x.numero_aste or 0} aste" if (x.numero_aste or 0) != 1 else "1 asta")
        if x.gabbia:
            parti.append("gabbia " + FASCE_GABBIA.get(x.gabbia_fascia, "").lower())
        return "; ".join(parti)
    return f"zone {x.zone}" if x.zone else ""


def _testo_quantita(voce: Any, quantita: float | None) -> str:
    if voce is None or quantita is None:
        return ""
    if voce.grandezza == "ore":
        return f"{quantita:g} ore".replace(".", ",") if quantita != 1 else "1 ora"
    return ""


def _calcola_riga(s: Session, riga: RigaPreventivo, giorno: date | None = None) -> None:
    """Tariffa standard della riga (D26): voce scelta a mano (a ore, a scelta, fissa), oppure calcolo automatico
    dall'impianto; le righe «a corpo» (senza impianto né voce) hanno l'importo scritto a mano."""
    from ..tariffario.modelli import VoceTariffa

    if riga.asset_id is not None:
        from ..dm.servizio import tariffa
        from ..beni.servizio import leggi
        calcolo = tariffa(s, leggi(s, riga.asset_id), riga.tipo_verifica_dm, riga.tipo_verifica_gvr)
        riga.tariffa_standard = calcolo["totale"]
        riga.dettaglio_tariffa = json.dumps(calcolo, ensure_ascii=False)
        _applica_sconto(riga)
        return
    voce = s.get(VoceTariffa, riga.voce_id) if riga.voce_id else None
    calcolo = None
    if voce is not None:
        calcolo = tariffario.calcola_voce(s, voce.id, riga.quantita, giorno)
        if riga.impianto_id is None:  # riga senza impianto: in stampa nome della voce e scelta / ore
            riga.sede_nome = voce.nome[:300]
            scelta = calcolo["voci"][0]["spiegazione"] if voce.grandezza == "scelta" and calcolo["voci"] else ""
            riga.descrizione = (scelta or _testo_quantita(voce, riga.quantita))[:200]
    elif riga.impianto_id is not None:
        calcolo = tariffario.calcola(s, s.get(Impianto, riga.impianto_id), giorno)
    if riga.impianto_id is not None:
        x = s.get(Impianto, riga.impianto_id)
        riga.descrizione = "; ".join(t for t in (descrizione_impianto(x), _testo_quantita(voce, riga.quantita)) if t)[:200]
    if calcolo is None:  # riga a corpo: importo scritto a mano
        riga.dettaglio_tariffa = json.dumps({"voci": [], "problemi": [], "avvisi": []})
    else:
        riga.tariffa_standard = calcolo["totale"] or 0
        riga.dettaglio_tariffa = json.dumps({"voci": calcolo["voci"], "problemi": calcolo["problemi"], "avvisi": calcolo.get("avvisi", [])},
                                            ensure_ascii=False)
    _applica_sconto(riga)


def _prezzo_riga(s: Session, riga: RigaPreventivo, x: Impianto, giorno: date | None = None) -> None:
    _calcola_riga(s, riga, giorno)


def _applica_sconto(riga: RigaPreventivo) -> None:
    """Tariffa applicata = standard − sconto %, arrotondata al centesimo (D26)."""
    if riga.asset_id is not None:
        # Garda: gi_bcdiv(sconto, 100, 2), quindi gi_bcmul(importo, fattore, 2).
        from decimal import Decimal, ROUND_HALF_UP
        frazione = (Decimal(riga.sconto) / 10000).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        riga.tariffa_applicata = int((Decimal(riga.tariffa_standard) * (1 - frazione)).to_integral_value(rounding=ROUND_HALF_UP))
    else:
        riga.tariffa_applicata = int(round(riga.tariffa_standard * (10000 - riga.sconto) / 10000))


def _copia_impianto(riga: RigaPreventivo, x: Impianto) -> None:
    sede = x.sede
    riga.sede_nome = sede.denominazione[:300]
    riga.sede_indirizzo = sede.indirizzo[:200]
    riga.sede_comune = " ".join(p for p in [sede.cap, sede.comune, f"({sede.provincia})" if sede.provincia else ""] if p)[:160]
    riga.tipologia = TIPOLOGIE_IMPIANTO.get(x.tipologia, x.tipologia)
    riga.descrizione = descrizione_impianto(x)[:200]


def _nuova_riga(s: Session, p: Preventivo, impianto_id: int, tipo_verifica: str = "periodica") -> RigaPreventivo:
    if p.ambito != "DPR":
        raise ErroreUtente("Gli impianti DPR non si aggiungono al preventivo DM.")
    x = s.get(Impianto, int(impianto_id))
    if x is None:
        raise ErroreUtente("Impianto non trovato: ricarica la pagina.")
    if x.sede.cliente_id != p.cliente_id:
        raise ErroreUtente(f"L'impianto n. {x.id} è di un altro cliente ({x.sede.cliente.ragione_sociale}): un preventivo riguarda un solo cliente (D39).")
    if x.dismesso:
        raise ErroreUtente(f"L'impianto n. {x.id} è dismesso: rimettilo in servizio prima di preventivarlo.")
    if any(r.impianto_id == x.id and r.stato != "annullata" for r in p.righe):
        raise ErroreUtente(f"L'impianto n. {x.id} è già in questo preventivo.")
    copertura.controlla(s, x.id, tipo_verifica if tipo_verifica in TIPI_VERIFICA else "periodica", p.id)
    riga = RigaPreventivo(impianto_id=x.id, tipo_verifica=tipo_verifica if tipo_verifica in TIPI_VERIFICA else "periodica",
                          ordine=max([r.ordine for r in p.righe] + [0]) + 1, sconto=0, stato="in_attesa")
    _copia_impianto(riga, x)
    _prezzo_riga(s, riga, x, p.data)
    if not json.loads(riga.dettaglio_tariffa)["voci"]:
        # es. pericolo di esplosione: nessuna voce automatica → si propone la voce a ore della tipologia (O10)
        orarie = tariffario.voci_orarie_per(s, x.tipologia)
        if orarie:
            riga.voce_id = orarie[0].id
            _calcola_riga(s, riga, p.data)
    p.righe.append(riga)
    return riga


def _nuova_riga_voce(s: Session, p: Preventivo, dati: dict) -> RigaPreventivo:
    """Riga senza impianto (0.4.0): voce del tariffario (trasferta, sopralluogo a vuoto, duplicato…) o importo «a corpo»."""
    from ..tariffario.modelli import VoceTariffa
    if p.ambito != "DPR":
        raise ErroreUtente("Le voci del tariffario DPR non appartengono al preventivo DM.")

    riga = RigaPreventivo(impianto_id=None, tipo_verifica="periodica", ordine=max([r.ordine for r in p.righe] + [0]) + 1, sconto=0,
                          stato="in_attesa", note=str(dati.get("note") or "")[:500])
    voce_id = dati.get("voce_id")
    if voce_id not in (None, ""):
        voce = s.get(VoceTariffa, int(voce_id))
        if voce is None or not voce.attiva:
            raise ErroreUtente("Voce del tariffario non trovata o non attiva.")
        riga.voce_id = voce.id
        riga.quantita = _quantita(dati.get("quantita"))
    else:
        riga.sede_nome = str(dati.get("descrizione") or "").strip()[:300]
        if not riga.sede_nome:
            raise ErroreUtente("Riga a corpo: scrivi la descrizione (es. «Rimborso spese di trasferta a corpo»).")
        riga.tariffa_standard = _importo(dati.get("importo"))
    _calcola_riga(s, riga, p.data)
    p.righe.append(riga)
    return riga


def _quantita(valore: Any) -> float | None:
    if valore in (None, ""):
        return None
    try:
        q = float(str(valore).replace(",", "."))
    except ValueError:
        raise ErroreUtente("Quantità non valida: scrivi un numero (es. 2 o 2,5).") from None
    if q < 0 or q > 10000:
        raise ErroreUtente("Quantità fuori misura.")
    return q


def _importo(valore: Any) -> int:
    try:
        n = round(float(str(valore if valore not in (None, "") else "x").replace(".", "").replace(",", ".")) * 100)
    except ValueError:
        raise ErroreUtente("Importo non valido: scrivi un importo in euro (es. 150,00).") from None
    if n < 0:
        raise ErroreUtente("L'importo non può essere negativo.")
    return int(n)


def _totali(p: Preventivo) -> None:
    attive = [r for r in p.righe if r.stato not in ("annullata", "rifiutata")]
    licenza = (p.prezzo_licenza or 0) if p.lic_gest else 0
    p.totale_standard = sum(r.tariffa_standard for r in attive) + licenza
    p.totale = sum(r.tariffa_applicata for r in attive) + licenza


def ricalcola_stato(p: Preventivo) -> None:
    """D13: «accettato totalmente / parzialmente» e «rifiutato» si calcolano dalle righe."""
    if p.stato in ("annullato", "sostituito"):
        return
    attive = [r for r in p.righe if r.stato != "annullata"]
    accettate = [r for r in attive if r.stato == "accettata"]
    if accettate:
        p.stato = "accettato_totalmente" if len(accettate) == len(attive) else "accettato_parzialmente"
    elif attive and all(r.stato == "rifiutata" for r in attive):
        p.stato = "rifiutato"
    else:
        p.stato = "inviato" if p.inviato_il else "creato"


def avvisi_impianti(s: Session, p: Preventivo) -> list[str]:
    """Presenze ulteriori da mostrare: le periodiche non completate sono bloccate dal servizio."""
    ids = [r.impianto_id for r in p.righe if r.stato != "annullata" and r.impianto_id is not None]
    if not ids:
        return []
    q = (select(RigaPreventivo.impianto_id, Preventivo.codice, Preventivo.revisione).join(Preventivo)
         .where(RigaPreventivo.impianto_id.in_(ids), Preventivo.id != p.id, Preventivo.stato.in_(STATI_APERTI),
                RigaPreventivo.stato.in_(("in_attesa", "accettata"))))
    return [f"L'impianto n. {i} è anche nel preventivo {c}{f' rev. {r}' if r else ''}" for i, c, r in s.execute(q)]


# ---------------------------------------------------------------- serializzazione


def verifiche_del_preventivo(s: Session, p: Preventivo) -> list[dict]:
    from ..verifiche.modelli import STATI as STATI_VERIFICA, Verifica
    if p.ambito == "DM":
        from ..dm.modelli import IncaricoDM, STATI_DM
        return [{"id": x.id, "asset_id": x.asset_id, "stato": x.stato, "stato_testo": STATI_DM[x.stato], "codice_verbale": x.codice_verbale, "ambito": "DM"}
                for x in s.scalars(select(IncaricoDM).join(RigaPreventivo).where(RigaPreventivo.preventivo_id == p.id))]

    return [{"id": v.id, "impianto_id": v.impianto_id, "stato": v.stato, "stato_testo": STATI_VERIFICA[v.stato], "codice_verbale": v.codice_verbale}
            for v in s.execute(select(Verifica).where(Verifica.preventivo_id == p.id).order_by(Verifica.id)).scalars()]


def voci_manuali(s: Session) -> list[dict]:
    """Voci del tariffario da scegliere a mano nelle righe (a ore, a scelta, fisse o non automatiche)."""
    from ..tariffario.modelli import VoceTariffa

    oggi = date.today()
    risultato = []
    for v in s.execute(select(VoceTariffa).where(VoceTariffa.attiva.is_(True)).order_by(VoceTariffa.ordine, VoceTariffa.id)).scalars():
        if v.automatica:
            continue
        versione = tariffario.versione_in_vigore(v, oggi)
        risultato.append({"id": v.id, "codice": v.codice, "nome": v.nome, "grandezza": v.grandezza, "criterio": v.criterio,
                          "tipologie": [x for x in v.tipologie.split(",") if x],
                          "opzioni": [{"valore": int(g.fino_a), "testo": f"{g.etichetta} ({euro(g.importo)})"} for g in versione.scaglioni]
                          if versione and v.grandezza == "scelta" else []})
    return risultato


def riga_json(r: RigaPreventivo) -> dict:
    dettaglio = json.loads(r.dettaglio_tariffa or "{}")
    if not isinstance(dettaglio, dict):  # righe vecchie o «a corpo»
        dettaglio = {}
    return {"id": r.id, "ordine": r.ordine, "asset_id": r.asset_id, "tipo_verifica_dm": r.tipo_verifica_dm, "tipo_verifica_gvr": r.tipo_verifica_gvr, "impianto_id": r.impianto_id, "tipo_verifica": r.tipo_verifica, "sede_nome": r.sede_nome,
            "sede_indirizzo": r.sede_indirizzo, "sede_comune": r.sede_comune, "tipologia": r.tipologia, "descrizione": r.descrizione,
            "tariffa_standard": r.tariffa_standard, "sconto": r.sconto / 100, "tariffa_applicata": r.tariffa_applicata,
            "dettaglio": dettaglio.get("voci", []), "problemi_tariffa": dettaglio.get("problemi", []), "avvisi_tariffa": dettaglio.get("avvisi", []),
            "voce_id": r.voce_id, "quantita": r.quantita, "a_corpo": r.impianto_id is None and r.asset_id is None and r.voce_id is None, "stato": r.stato,
            "stato_testo": STATI_RIGA[r.stato], "stato_il": iso_locale(r.stato_il), "stato_da": r.stato_da, "note": r.note}


def dati_preventivo(p: Preventivo) -> dict:
    return {"ambito": p.ambito, "serie": p.serie, "sede_id": p.sede_id, "lic_gest": p.lic_gest, "prezzo_licenza": p.prezzo_licenza, "data": p.data.isoformat(), "cliente_id": p.cliente_id, "commerciale_id": p.commerciale_id, "modalita_pagamento": p.modalita_pagamento,
            "termine_esecuzione": p.termine_esecuzione, "evidenza_accettazione": p.evidenza_accettazione, "rif_ordine": p.rif_ordine,
            "data_ordine": p.data_ordine.isoformat() if p.data_ordine else None, "note": p.note, "stato": p.stato}


def _revoche_json(s: Session, p: Preventivo) -> list[dict]:
    from .modelli import RevocaRiga

    ordine = {r.id: r.ordine for r in p.righe}
    return [{"riga": ordine.get(x.riga_id), "riga_id": x.riga_id, "motivo": x.motivo, "revocata_il": iso_locale(x.revocata_il),
             "revocata_da": x.revocata_da, "verifica_id": x.verifica_id, "incarico_dm_id": x.incarico_dm_id}
            for x in s.scalars(select(RevocaRiga).where(RevocaRiga.preventivo_id == p.id).order_by(RevocaRiga.id.desc()))]


def preventivo_json(s: Session, p: Preventivo) -> dict:
    cliente = s.get(Cliente, p.cliente_id)
    riesame = s.execute(select(Riesame).where(Riesame.preventivo_id == p.id).order_by(Riesame.id.desc())).scalars().first()
    docs = s.execute(select(DocumentoPreventivo).where(DocumentoPreventivo.preventivo_id == p.id).order_by(DocumentoPreventivo.id.desc())).scalars().all()
    invii = s.execute(select(InvioPreventivo).where(InvioPreventivo.preventivo_id == p.id).order_by(InvioPreventivo.id.desc())).scalars().all()
    revisioni = s.execute(select(Preventivo).where(Preventivo.ambito == p.ambito, Preventivo.serie == p.serie, Preventivo.numero == p.numero).order_by(Preventivo.revisione)).scalars().all()
    attuale = documento_corrente(s, p) if p.stato == "creato" else None
    return {
        "id": p.id, **dati_preventivo(p), "codice": p.codice, "etichetta": etichetta(p), "anno": p.anno, "numero": p.numero,
        "revisione": p.revisione, "stato_testo": STATI[p.stato], "inviato_il": iso_locale(p.inviato_il),
        "motivo_annullamento": p.motivo_annullamento, "totale_standard": p.totale_standard, "totale": p.totale,
        "cliente": cliente.ragione_sociale, "cliente_sconti_ammessi": cliente.sconti_ammessi,
        "cliente_email": {"verbali": cliente.email_verbali, "fatture": cliente.email_fatture, "pec": cliente.pec, "referente": cliente.referente_email},
        "modificabile": modificabile(p), "fissato": fissato(p), "versione": p.versione,
        "sede": s.get(Sede, p.sede_id).denominazione if p.sede_id else "",
        "righe": [riga_json(r) for r in p.righe], "avvisi": avvisi_impianti(s, p), "voci_manuali": voci_manuali(s),
        "verifiche": verifiche_del_preventivo(s, p),
        # R138 (0.16): accettazione e ordine del cliente
        "documenti_collegati": json.loads(p.documenti_collegati or "[]"), "allegati": allegati_json(s, p),
        "avvisi_accettazione": avvisi_accettazione(s, p, cliente),
        "riesame": None if riesame is None else {"esito": riesame.esito, "esito_testo": ESITI_RIESAME[riesame.esito], "requisiti_chiari": riesame.requisiti_chiari,
                                                 "competenza_strumenti": riesame.competenza_strumenti, "imparzialita": riesame.imparzialita,
                                                 "tempi": riesame.tempi, "note": riesame.note, "eseguito_il": iso_locale(riesame.eseguito_il),
                                                 "eseguito_da": riesame.eseguito_da},
        # R109 (11/10/2026): storico completo dei riesami del contratto, dal più recente; nessun riesame sovrascrive il precedente.
        "riesami": [{"id": x.id, "esito": x.esito, "esito_testo": ESITI_RIESAME[x.esito], "requisiti_chiari": x.requisiti_chiari,
                     "competenza_strumenti": x.competenza_strumenti, "imparzialita": x.imparzialita, "tempi": x.tempi,
                     "note": x.note, "eseguito_il": iso_locale(x.eseguito_il), "eseguito_da": x.eseguito_da}
                    for x in s.execute(select(Riesame).where(Riesame.preventivo_id == p.id).order_by(Riesame.id.desc())).scalars()],
        "riesame_necessario": riesame_necessario(s, p),  # N5 (0.12.8)
        "revoche": _revoche_json(s, p),  # R124 (0.12.8)
        "documenti": [{"id": d.id, "formato": d.formato, "documento_id": d.documento_id, "nome_file": d.nome_file, "ritoccato": d.ritoccato,
                       "creato_il": iso_locale(d.creato_il), "creato_da": d.creato_da, "approvato_il": iso_locale(d.approvato_il),
                       "approvato_da": d.approvato_da, "attuale": attuale is not None and d.gruppo == attuale.gruppo and bool(d.gruppo)} for d in docs],
        "documento_attuale": None if attuale is None else documento_json(s, p, attuale),
        "invii": [{"destinatari": i.destinatari, "copia": i.copia, "oggetto": i.oggetto, "esito": i.esito, "inviato_il": iso_locale(i.inviato_il),
                   "inviato_da": i.inviato_da} for i in invii],
        "revisioni": [{"id": r.id, "etichetta": etichetta(r), "stato_testo": STATI[r.stato], "data": r.data.isoformat()} for r in revisioni],
        "creato_il": iso_locale(p.creato_il), "creato_da": p.creato_da, "modificato_il": iso_locale(p.modificato_il), "modificato_da": p.modificato_da,
    }


# ---------------------------------------------------------------- creazione e modifica


def numero_successivo(s: Session, anno: int, ambito="DPR", serie=None) -> int:
    return (s.execute(select(func.max(Preventivo.numero)).where(Preventivo.ambito == ambito, Preventivo.serie == str(serie or anno))).scalar() or 0) + 1


def crea(s: Session, attore: Any, dati: dict) -> Preventivo:
    """Nuovo preventivo (anche dallo scadenziario con uno o più impianti, D19/D39)."""
    if dati.get("ambito", "DPR") == "DM":
        from ..dm.servizio import crea as crea_dm
        return crea_dm(s, attore, dati)
    if dati.get("ambito", "DPR") != "DPR":
        raise ErroreUtente("Ambito del preventivo non disponibile.")
    cliente = s.get(Cliente, int(dati.get("cliente_id") or 0))
    impianti = [int(i) for i in (dati.get("impianti") or [])]
    if cliente is None and impianti:
        primo = s.get(Impianto, impianti[0])
        cliente = primo.sede.cliente if primo else None
    if cliente is None:
        raise ErroreUtente("Scegli il cliente del preventivo.")
    if not cliente.attivo:
        raise ErroreUtente(f"Il cliente «{cliente.ragione_sociale}» è disattivato: riattivalo per fare un preventivo.")
    if not cliente.ambito_dpr:  # R114: il preventivo DPR si fa solo a clienti AD_DPR; l'ambito si aggiunge dall'anagrafica
        raise ErroreUtente(f"Il cliente «{cliente.ragione_sociale}» non è AD_DPR. Se deve diventarlo, aggiungi l'ambito AD_DPR "
                           "nella sua scheda (Clienti › Dati generali › Ambiti di lavoro).")
    oggi = _data(dati, "data", "Data") or date.today()
    numero = numero_successivo(s, oggi.year)
    commerciale = s.get(Commerciale, cliente.commerciale_id) if cliente.commerciale_id else None
    p = Preventivo(ambito="DPR", serie=str(oggi.year), anno=oggi.year, numero=numero, revisione=0, codice=codice(oggi.year, numero), data=oggi, cliente_id=cliente.id,
                   commerciale_id=commerciale.id if commerciale and commerciale.attivo else None,
                   modalita_pagamento=cliente.modalita_pagamento.descrizione if cliente.modalita_pagamento else "",
                   termine_esecuzione=cliente.termine_esecuzione, stato="creato", note=_t(dati, "note", 4000))
    p.cliente_id = cliente.id
    s.add(p)
    for i in impianti:
        _nuova_riga(s, p, i, str(dati.get("tipo_verifica") or "periodica"))
    _totali(p)
    _crea(s, p, attore)
    registro.scrivi(s, utente=attore, azione="preventivo.crea", oggetto_tipo="preventivo", oggetto_id=p.id,
                    descrizione=f"Creato il preventivo {p.codice} per «{cliente.ragione_sociale}» ({len(p.righe)} righe)",
                    dettagli={"dopo": dati_preventivo(p), "impianti": impianti})
    return p


def aggiungi_impianti(s: Session, attore: Any, preventivo_id: int, impianti: list, versione: Any = None, tipo_verifica: str = "periodica") -> Preventivo:
    p = preventivo_o_404(s, preventivo_id)
    controlla_versione(p, versione)
    _richiedi_modificabile(p)
    nuovi = [_nuova_riga(s, p, i, tipo_verifica) for i in impianti]
    _totali(p)
    _modificato(p, attore)
    s.flush()
    registro.scrivi(s, utente=attore, azione="preventivo.aggiungi_righe", oggetto_tipo="preventivo", oggetto_id=p.id,
                    descrizione=f"Preventivo {etichetta(p)}: aggiunti gli impianti {', '.join(str(r.impianto_id) for r in nuovi)}")
    return p


def trova_per_numero(s: Session, testo: str, anno_predefinito: int) -> Preventivo | None:
    """«12», «012», «P_012_26», «P_012_26 rev. 1» → ultima revisione di quel preventivo (O12)."""
    t = (testo or "").strip().upper()
    m = re.fullmatch(r"(?:P_?)?0*(\d{1,4})(?:[_/](\d{2}))?(?:\s*REV\.?\s*\d+)?", t)
    if not m:
        raise ErroreUtente("Numero del preventivo non valido: scrivi per esempio 12 oppure P_012_26.")
    numero = int(m.group(1))
    anno = 2000 + int(m.group(2)) if m.group(2) else anno_predefinito
    return s.execute(select(Preventivo).where(Preventivo.ambito == "DPR", Preventivo.anno == anno, Preventivo.numero == numero)
                     .order_by(Preventivo.revisione.desc())).scalars().first()


def da_scadenze(s: Session, attore: Any, dati: dict, puo_revisione: bool) -> Preventivo:
    """Maschera ⚡ dello scadenziario (O12): «Preventivo» vuoto = nuovo con la data indicata; con un numero si aggiunge a quel
    preventivo dello stesso cliente. Se è già inviato (non accettato) si crea prima una revisione (D16); mai su uno accettato."""
    impianti = [int(i) for i in (dati.get("impianti") or [])]
    if not impianti:
        raise ErroreUtente("Seleziona almeno una scadenza.")
    tipo = str(dati.get("tipo_verifica") or "periodica")
    giorno = _data(dati, "data", "Data del preventivo") or date.today()
    numero = str(dati.get("preventivo") or "").strip()
    if not numero:
        return crea(s, attore, {"impianti": impianti, "tipo_verifica": tipo, "data": giorno.isoformat()})
    p = trova_per_numero(s, numero, giorno.year)
    primo = s.get(Impianto, impianti[0])
    if p is None:
        raise ErroreUtente(f"Il preventivo «{numero}» non esiste: lascia vuoto il campo per crearne uno nuovo.")
    if primo is None or p.cliente_id != primo.sede.cliente_id:
        raise ErroreUtente(f"Il preventivo {etichetta(p)} è di un altro cliente: un preventivo riguarda un solo cliente (D39).")
    if p.stato in ("accettato_parzialmente", "accettato_totalmente"):
        raise ErroreUtente(f"Il preventivo {etichetta(p)} è già accettato: non si aggiungono impianti. Fanne uno nuovo.")
    if p.stato in ("annullato", "sostituito"):
        raise ErroreUtente(f"Il preventivo {etichetta(p)} è «{STATI[p.stato]}»: non si aggiungono impianti.")
    if p.stato in ("inviato", "rifiutato"):
        if not puo_revisione:
            raise PermessoNegato(f"Il preventivo {etichetta(p)} è già inviato: serve una revisione e non hai il permesso di crearla.")
        p = crea_revisione(s, attore, p.id, p.versione)
        s.flush()
    return aggiungi_impianti(s, attore, p.id, impianti, p.versione, tipo)


def aggiungi_voce(s: Session, attore: Any, preventivo_id: int, dati: dict) -> Preventivo:
    """Riga senza impianto: voce del tariffario o importo a corpo (0.4.0)."""
    p = preventivo_o_404(s, preventivo_id)
    controlla_versione(p, dati.get("versione"))
    _richiedi_modificabile(p)
    r = _nuova_riga_voce(s, p, dati)
    _totali(p)
    _modificato(p, attore)
    s.flush()
    registro.scrivi(s, utente=attore, azione="preventivo.aggiungi_voce", oggetto_tipo="preventivo", oggetto_id=p.id,
                    descrizione=f"Preventivo {etichetta(p)}: aggiunta la riga «{r.sede_nome}» ({euro(r.tariffa_standard)})")
    return p


def modifica(s: Session, attore: Any, preventivo_id: int, dati: dict, puo_scontare: bool) -> Preventivo:
    """Testata e righe. Se il preventivo non è più «creato» cambiano solo rif. ordine, data ordine e note."""
    p = preventivo_o_404(s, preventivo_id)
    controlla_versione(p, dati.get("versione"))
    if p.stato in ("annullato", "sostituito"):
        raise ErroreUtente(f"Il preventivo {etichetta(p)} è «{STATI[p.stato]}»: non si modifica.")
    prima = dati_preventivo(p) | {"righe": [riga_json(r) for r in p.righe]}
    p.rif_ordine = _t(dati, "rif_ordine", 120)
    p.data_ordine = _data(dati, "data_ordine", "Data dell'ordine")
    p.note = _t(dati, "note", 4000)
    if modificabile(p):
        p.data = _data(dati, "data", "Data del preventivo") or p.data
        if p.data.year != p.anno and not p.revisione:
            raise ErroreUtente(f"La data deve restare nell'anno {p.anno} del numero del preventivo.")
        commerciale = dati.get("commerciale_id")
        p.commerciale_id = int(commerciale) if commerciale not in (None, "") else None
        p.modalita_pagamento = _t(dati, "modalita_pagamento", 200)
        p.termine_esecuzione = _t(dati, "termine_esecuzione", 300)
        cliente = s.get(Cliente, p.cliente_id)
        if p.ambito == "DM":
            if "lic_gest" in dati:
                if type(dati["lic_gest"]) is not bool:
                    raise ErroreUtente("Licenza gestionale: scegli Sì o No.")
                p.lic_gest = dati["lic_gest"]
            if "prezzo_licenza" in dati:
                p.prezzo_licenza = _importo(dati["prezzo_licenza"])
            if p.lic_gest and not p.prezzo_licenza:
                raise ErroreUtente("Indica il prezzo della licenza gestionale.")
        togli = {int(x) for x in (dati.get("righe_da_togliere") or [])}
        for r in list(p.righe):
            if r.id in togli:
                p.righe.remove(r)
        per_id = {r.id: r for r in p.righe}
        for i, rd in enumerate(dati.get("righe") or []):
            r = per_id.get(int(rd.get("id") or 0))
            if r is None:
                continue
            r.ordine = i + 1
            if r.asset_id is not None and ("tipo_verifica_dm" in rd or "tipo_verifica_gvr" in rd):
                r.tipo_verifica_dm = rd.get("tipo_verifica_dm", r.tipo_verifica_dm)
                r.tipo_verifica_gvr = rd.get("tipo_verifica_gvr", r.tipo_verifica_gvr)
                _calcola_riga(s, r, p.data)
            if rd.get("tipo_verifica") in TIPI_VERIFICA:
                r.tipo_verifica = rd["tipo_verifica"]
            r.note = str(rd.get("note") or "")[:500]
            ricalcola = False
            if "voce_id" in rd and r.impianto_id is not None:  # impianto: automatico («») oppure voce a ore
                nuova_voce = int(rd["voce_id"]) if rd["voce_id"] not in (None, "") else None
                if nuova_voce != r.voce_id:
                    r.voce_id, ricalcola = nuova_voce, True
            if "quantita" in rd and r.voce_id is not None:
                q = _quantita(rd.get("quantita"))
                if q != r.quantita:
                    r.quantita, ricalcola = q, True
            if r.impianto_id is None and r.asset_id is None and r.voce_id is None:  # riga a corpo
                if "descrizione" in rd:
                    r.sede_nome = str(rd.get("descrizione") or "").strip()[:300] or r.sede_nome
                if "importo" in rd and _importo(rd.get("importo")) != r.tariffa_standard:
                    r.tariffa_standard, ricalcola = _importo(rd.get("importo")), True
            if ricalcola:
                _calcola_riga(s, r, p.data)
            try:
                sconto = int(round(float(str(rd.get("sconto") or 0).replace(",", ".")) * 100))
            except ValueError:
                raise ErroreUtente("Sconto non valido: scrivi una percentuale (es. 10 o 12,5).") from None
            if not 0 <= sconto <= 10000:
                raise ErroreUtente("Lo sconto va da 0 a 100%.")
            if sconto != r.sconto:
                if sconto and p.ambito == "DPR" and not cliente.sconti_ammessi:
                    raise ErroreUtente(f"Per «{cliente.ragione_sociale}» gli sconti sono bloccati (D38): chi ha il permesso li sblocca nella scheda del cliente.")
                if not puo_scontare:
                    raise PermessoNegato("Non hai il permesso di applicare sconti.")
                r.sconto = sconto
                _applica_sconto(r)
        copertura.controlla_preventivo(s, p)
        _totali(p)
    dopo = dati_preventivo(p) | {"righe": [riga_json(r) for r in p.righe]}
    modifiche = registro.differenze(prima, dopo)
    if modifiche:
        _modificato(p, attore)
        registro.scrivi(s, utente=attore, azione="preventivo.modifica", oggetto_tipo="preventivo", oggetto_id=p.id,
                        descrizione=f"Modificato il preventivo {etichetta(p)}", dettagli={"modifiche": modifiche})
    return p


def ricalcola_tariffe(s: Session, attore: Any, preventivo_id: int, versione: Any) -> Preventivo:
    """Rilegge impianti e tariffario (es. dopo aver corretto la potenza): solo su preventivi «creato»."""
    p = preventivo_o_404(s, preventivo_id)
    controlla_versione(p, versione)
    _richiedi_modificabile(p)
    s.info.pop("tariffario_voci", None)
    for r in p.righe:
        if r.impianto_id is not None:
            _copia_impianto(r, s.get(Impianto, r.impianto_id))
        elif r.asset_id is not None:
            from ..beni.modelli import Asset
            from ..dm.servizio import copia_asset
            copia_asset(s, r, s.get(Asset, r.asset_id))
        _calcola_riga(s, r, p.data)
    _totali(p)
    _modificato(p, attore)
    registro.scrivi(s, utente=attore, azione="preventivo.ricalcola", oggetto_tipo="preventivo", oggetto_id=p.id,
                    descrizione=f"Preventivo {etichetta(p)}: tariffe e dati degli impianti ricalcolati (totale {euro(p.totale)})")
    return p


def segna_inviato(s: Session, attore: Any, preventivo_id: int, versione: Any) -> Preventivo:
    p = preventivo_o_404(s, preventivo_id)
    controlla_versione(p, versione)
    if p.stato != "creato":
        raise ErroreUtente("Solo un preventivo «creato» si segna come inviato.")
    if not p.righe:
        raise ErroreUtente("Il preventivo non ha righe.")
    d = pdf_approvato(s, p)
    if d is None:
        raise ErroreUtente("Prima apri l'«Anteprima», controlla il documento e approvalo: è quello che risulterà inviato al cliente (D80).", 409)
    congela_cliente(s, p)
    p.inviato_il = adesso()
    s.add(InvioPreventivo(preventivo_id=p.id, destinatari="", copia="", oggetto="(inviato fuori dal programma)", testo="",
                          allegati=json.dumps([d.documento_id]), esito="segnato come inviato a mano", inviato_da=getattr(attore, "nome", "")))
    ricalcola_stato(p)
    _modificato(p, attore)
    registro.scrivi(s, utente=attore, azione="preventivo.inviato", oggetto_tipo="preventivo", oggetto_id=p.id,
                    descrizione=f"Preventivo {etichetta(p)} segnato come inviato (senza email dal programma); documento: {d.nome_file}",
                    dettagli={"documento_id": d.documento_id})
    return p


def stato_righe(s: Session, attore: Any, preventivo_id: int, righe: list, stato: str, versione: Any, evidenza_accettazione: str = "") -> Preventivo:
    """Accettazione, rifiuto o annullamento di una o più righe (D13)."""
    p = preventivo_o_404(s, preventivo_id)
    controlla_versione(p, versione)
    if stato not in STATI_RIGA:
        raise ErroreUtente("Stato della riga non valido.")
    if p.stato in ("annullato", "sostituito"):
        raise ErroreUtente(f"Il preventivo {etichetta(p)} è «{STATI[p.stato]}»: lo stato delle righe non si cambia.")
    if not p.righe:
        raise ErroreUtente("Il preventivo non ha righe.")
    scelte = {int(x) for x in righe}
    selezionate = [r for r in p.righe if r.id in scelte]
    if not selezionate:
        raise ErroreUtente("Seleziona le righe con la casella a sinistra.")
    if all(r.stato == stato for r in selezionate):  # N3 (0.12.8): nessuna modifica, e lo si dice
        raise ErroreUtente(f"Le righe selezionate sono già «{STATI_RIGA[stato]}»: nessuna modifica.")
    if stato != "accettata" and any(r.stato == "accettata" for r in selezionate):
        # R124 (0.12.8): un'accettazione non si toglie cambiando stato, ma con la revoca motivata
        raise ErroreUtente("Una riga accettata non torna indietro cambiando stato: usa «Revoca accettazione…» e scrivi il motivo.")
    if stato == "accettata":
        if p.stato == "creato":
            raise ErroreUtente("Prima registra l'invio del preventivo approvato.")
        evidenza = str(evidenza_accettazione or p.evidenza_accettazione or "").strip()[:2000]
        # R138 (0.16): l'evidenza è il file caricato (preventivo controfirmato, ordine, email) oppure, se manca, il testo
        if not evidenza and not _allegati_attivi(s, p):
            raise ErroreUtente("Indica l'evidenza dell'accettazione: carica il file (preventivo controfirmato, ordine, email) nella linguetta "
                               "«Accettazione e ordine» oppure scrivi il riferimento (es. «accettato per telefono il …»).")
        p.evidenza_accettazione = evidenza
    cambiate = []
    if stato != "accettata":
        from ..verifiche import servizio as verifiche

        if p.ambito == "DM":
            from ..dm.modelli import IncaricoDM
            if s.scalar(select(IncaricoDM.id).where(IncaricoDM.riga_id.in_(scelte), IncaricoDM.stato != "annullata")):
                raise ErroreUtente("La riga ha già un incarico DM: non si modifica l’accettazione del lavoro affidato.")
        for r in p.righe:
            if r.id in scelte and r.stato == "accettata" and (v := verifiche.verifica_attiva_della_riga(s, r.id)):
                raise ErroreUtente(f"La riga dell'impianto n. {r.impianto_id} ha già la verifica n. {v.id} ({v.codice_verbale or 'in corso'}): "
                                   "annulla prima la verifica (se non ancora eseguita).")
    for r in p.righe:
        if r.id in scelte and r.stato != stato:
            cambiate.append(f"{r.impianto_id}: {STATI_RIGA[r.stato]} → {STATI_RIGA[stato]}")
            r.stato, r.stato_il, r.stato_da = stato, adesso(), getattr(attore, "nome", "")
    if not cambiate:
        return p
    if stato != "annullata":
        copertura.controlla_preventivo(s, p)
    prima = p.stato
    _totali(p)
    ricalcola_stato(p)
    _modificato(p, attore)
    registro.scrivi(s, utente=attore, azione="preventivo.stato_righe", oggetto_tipo="preventivo", oggetto_id=p.id,
                    descrizione=f"Preventivo {etichetta(p)}: righe «{STATI_RIGA[stato]}» ({len(cambiate)}); stato {STATI[prima]} → {STATI[p.stato]}",
                    dettagli={"righe": cambiate, "evidenza_accettazione": p.evidenza_accettazione})
    if stato == "accettata" and not riesame_necessario(s, p):
        from ..verifiche import servizio as verifiche
        verifiche.crea_da_preventivo(s, attore, p)
    return p


def riesame_necessario(s: Session, p: Preventivo) -> bool:
    """N5 (0.12.8): il riesame del contratto serve se il preventivo è accettato (anche in parte) e non c'è ancora un
    riesame, oppure l'ultimo non è conforme, oppure una riga revocata (R124) è stata riaccettata dopo l'ultimo riesame.
    Altrimenti non si ripete. Come in Garda, le righe accettate in un secondo momento su un preventivo con riesame
    conforme diventano subito verifiche."""
    from .modelli import RevocaRiga

    if p.stato not in ("accettato_parzialmente", "accettato_totalmente"):
        return False
    ultimo = s.scalar(select(Riesame).where(Riesame.preventivo_id == p.id).order_by(Riesame.id.desc()).limit(1))
    if ultimo is None or ultimo.esito != "conforme":
        return True
    revocate = set(s.scalars(select(RevocaRiga.riga_id).where(RevocaRiga.preventivo_id == p.id)))
    return any(r.id in revocate and r.stato == "accettata" and r.stato_il and r.stato_il > ultimo.eseguito_il for r in p.righe)


def revoca_righe(s: Session, attore: Any, preventivo_id: int, righe: list, motivo: Any, versione: Any) -> Preventivo:
    """R124 (0.12.8): revoca dell'accettazione di una o più righe, con motivo obbligatorio. La riga torna «in attesa».
    La verifica (DPR) o l'incarico (DM) ancora «da assegnare» si annullano con lo stesso motivo; se il lavoro è già
    affidato o oltre, la revoca si ferma: prima si annulla la verifica. Il riesame resta valido per le altre righe;
    una riga riaccettata richiede un nuovo riesame (riesame_necessario)."""
    from .modelli import RevocaRiga

    p = preventivo_o_404(s, preventivo_id)
    controlla_versione(p, versione)
    motivo = str(motivo or "").strip()[:2000]
    if not motivo:
        raise ErroreUtente("Scrivi il motivo della revoca dell'accettazione.")
    if p.stato in ("annullato", "sostituito"):
        raise ErroreUtente(f"Il preventivo {etichetta(p)} è «{STATI[p.stato]}»: non si revoca nulla.")
    scelte = {int(x) for x in righe}
    selezionate = [r for r in p.righe if r.id in scelte]
    if not selezionate:
        raise ErroreUtente("Seleziona le righe da revocare.")
    if any(r.stato != "accettata" for r in selezionate):
        raise ErroreUtente("Si revocano solo righe accettate.")
    from ..verifiche import servizio as verifiche
    lavori = {}
    for r in selezionate:
        if p.ambito == "DM":
            from ..dm.modelli import IncaricoDM
            x = s.scalar(select(IncaricoDM).where(IncaricoDM.riga_id == r.id, IncaricoDM.stato != "annullata"))
        else:
            x = verifiche.verifica_attiva_della_riga(s, r.id)
        if x is not None and x.stato != "da_assegnare":
            cosa = f"l'incarico DM n. {x.id}" if p.ambito == "DM" else f"la verifica n. {x.id}"
            raise ErroreUtente(f"Riga {r.ordine}: {cosa} è già «{x.stato.replace('_', ' ')}». Annulla prima il lavoro affidato, "
                               "poi revoca l'accettazione.")
        lavori[r.id] = x
    for r in selezionate:
        x = lavori[r.id]
        if x is not None:
            prima_lavoro = x.stato
            x.stato = "annullata"
            x.motivo_annullamento = f"Revoca dell'accettazione della riga del preventivo: {motivo}"[:500]
            _modificato(x, attore)
            registro.scrivi(s, utente=attore, azione="dm.incarico_annulla" if p.ambito == "DM" else "verifica.annulla",
                            oggetto_tipo="incarico_dm" if p.ambito == "DM" else "verifica", oggetto_id=x.id,
                            descrizione=f"Annullato {'l’incarico DM' if p.ambito == 'DM' else 'la verifica'} n. {x.id} per revoca "
                                        f"dell'accettazione (preventivo {etichetta(p)}): {motivo}",
                            dettagli={"stato_prima": prima_lavoro})
        s.add(RevocaRiga(riga_id=r.id, preventivo_id=p.id, motivo=motivo, stato_prima=r.stato,
                         verifica_id=x.id if x is not None and p.ambito != "DM" else None,
                         incarico_dm_id=x.id if x is not None and p.ambito == "DM" else None, revocata_da=getattr(attore, "nome", "")))
        r.stato, r.stato_il, r.stato_da = "in_attesa", adesso(), getattr(attore, "nome", "")
    prima = p.stato
    _totali(p)
    ricalcola_stato(p)
    _modificato(p, attore)
    registro.scrivi(s, utente=attore, azione="preventivo.revoca_accettazione", oggetto_tipo="preventivo", oggetto_id=p.id,
                    descrizione=f"Preventivo {etichetta(p)}: revocata l'accettazione di {len(selezionate)} righe; stato {STATI[prima]} → {STATI[p.stato]}. "
                                f"Motivo: {motivo}",
                    dettagli={"righe": [r.ordine for r in selezionate], "lavori_annullati": [x.id for x in lavori.values() if x is not None]})
    return p


def crea_revisione(s: Session, attore: Any, preventivo_id: int, versione: Any) -> Preventivo:
    """D16: copia del preventivo inviato con revisione +1; la precedente resta com'era («sostituito»)."""
    p = preventivo_o_404(s, preventivo_id)
    controlla_versione(p, versione)
    if p.stato not in ("inviato", "rifiutato"):
        raise ErroreUtente("La revisione si crea da un preventivo inviato (o rifiutato) e non ancora accettato.")
    # O12: la revisione riguarda l'intero preventivo e ha la sua data (quella del giorno in cui si crea); il numero resta
    copertura.controlla_preventivo(s, p)
    nuovo = Preventivo(ambito=p.ambito, serie=p.serie, sede_id=p.sede_id, lic_gest=p.lic_gest, prezzo_licenza=p.prezzo_licenza, anno=p.anno, numero=p.numero, revisione=p.revisione + 1, codice=p.codice, data=date.today(),
                       cliente_id=p.cliente_id, commerciale_id=p.commerciale_id, modalita_pagamento=p.modalita_pagamento,
                       termine_esecuzione=p.termine_esecuzione, stato="creato", rif_ordine=p.rif_ordine, data_ordine=p.data_ordine,
                       note=p.note, revisione_di_id=p.id)
    for r in p.righe:
        if r.stato == "annullata":
            continue
        nuovo.righe.append(RigaPreventivo(
            ordine=r.ordine, impianto_id=r.impianto_id, asset_id=r.asset_id, tipo_verifica_dm=r.tipo_verifica_dm, tipo_verifica_gvr=r.tipo_verifica_gvr, asset_fotografia=r.asset_fotografia, voce_id=r.voce_id, quantita=r.quantita, tipo_verifica=r.tipo_verifica, sede_nome=r.sede_nome, sede_indirizzo=r.sede_indirizzo,
            sede_comune=r.sede_comune, tipologia=r.tipologia, descrizione=r.descrizione, tariffa_standard=r.tariffa_standard,
            dettaglio_tariffa=r.dettaglio_tariffa, sconto=r.sconto, tariffa_applicata=r.tariffa_applicata, stato="in_attesa", note=r.note))
    _totali(nuovo)
    s.add(nuovo)
    p.stato = "sostituito"
    _modificato(p, attore)
    _crea(s, nuovo, attore)
    registro.scrivi(s, utente=attore, azione="preventivo.revisione", oggetto_tipo="preventivo", oggetto_id=nuovo.id,
                    descrizione=f"Creata la revisione {etichetta(nuovo)}; {etichetta(p)} resta com'era, «sostituito»", dettagli={"da": p.id})
    registro.scrivi(s, utente=attore, azione="preventivo.sostituito", oggetto_tipo="preventivo", oggetto_id=p.id,
                    descrizione=f"Preventivo {etichetta(p)} sostituito dalla revisione {etichetta(nuovo)}")
    return nuovo


def sconto_con_revisione(s: Session, attore: Any, preventivo_id: int, dati: dict) -> Preventivo:
    """O15: sconto chiesto dal cliente su un preventivo già inviato e non ancora accettato. Il prezzo inviato non si
    tocca: si crea da sola la revisione (D16, con la data di oggi) e lo sconto si applica lì; poi si reinvia.
    Dopo l'accettazione il prezzo non cambia più (né sconti né revisioni)."""
    p = preventivo_o_404(s, preventivo_id)
    if p.stato != "inviato":
        raise ErroreUtente("Lo sconto con revisione si applica a un preventivo «inviato» e non ancora accettato: dopo l'accettazione il prezzo non si tocca.")
    cliente = s.get(Cliente, p.cliente_id)
    if not cliente.sconti_ammessi:
        raise ErroreUtente(f"Per «{cliente.ragione_sociale}» gli sconti sono bloccati (D38): chi ha il permesso li sblocca nella scheda del cliente.")
    sconti = {int(k): v for k, v in (dati.get("sconti") or {}).items()}
    if not sconti:
        raise ErroreUtente("Indica lo sconto di almeno una riga.")
    vecchie = {r.id: r.ordine for r in p.righe}
    nuovo = crea_revisione(s, attore, p.id, dati.get("versione"))
    s.flush()
    per_ordine = {r.ordine: r for r in nuovo.righe}
    righe = []
    for r in sorted(nuovo.righe, key=lambda x: x.ordine):
        rd = {"id": r.id, "tipo_verifica": r.tipo_verifica, "note": r.note, "sconto": f"{r.sconto / 100:g}"}
        righe.append(rd)
    for vid, sc in sconti.items():
        r = per_ordine.get(vecchie.get(vid))
        if r is not None:
            next(x for x in righe if x["id"] == r.id)["sconto"] = sc
    return modifica(s, attore, nuovo.id, {**dati_testata(nuovo), "righe": righe}, True)


def dati_testata(p: Preventivo) -> dict:
    return {"data": p.data.isoformat(), "commerciale_id": p.commerciale_id, "modalita_pagamento": p.modalita_pagamento,
            "termine_esecuzione": p.termine_esecuzione, "rif_ordine": p.rif_ordine,
            "data_ordine": p.data_ordine.isoformat() if p.data_ordine else None, "note": p.note}


def annulla(s: Session, attore: Any, preventivo_id: int, motivo: str, versione: Any) -> Preventivo:
    p = preventivo_o_404(s, preventivo_id)
    controlla_versione(p, versione)
    motivo = (motivo or "").strip()[:500]
    if not motivo:
        raise ErroreUtente("Scrivi il motivo dell'annullamento.")
    if p.stato in ("annullato", "sostituito"):
        raise ErroreUtente(f"Il preventivo è già «{STATI[p.stato]}».")
    prima = p.stato
    p.stato, p.motivo_annullamento = "annullato", motivo
    _modificato(p, attore)
    registro.scrivi(s, utente=attore, azione="preventivo.annulla", oggetto_tipo="preventivo", oggetto_id=p.id,
                    descrizione=f"Annullato il preventivo {etichetta(p)} (era «{STATI[prima]}»): {motivo}")
    return p


def elimina(s: Session, attore: Any, preventivo_id: int) -> None:
    p = preventivo_o_404(s, preventivo_id)
    if p.stato != "creato" or p.inviato_il or p.revisione:
        raise ErroreUtente("Si elimina solo un preventivo «creato», mai inviato e non revisione: negli altri casi si annulla con il motivo.")
    if s.execute(select(InvioPreventivo).where(InvioPreventivo.preventivo_id == p.id)).first():
        raise ErroreUtente("Il preventivo è stato inviato per email: si annulla, non si elimina.")
    dati = dati_preventivo(p) | {"codice": p.codice, "righe": [riga_json(r) for r in p.righe]}
    for d in s.execute(select(DocumentoPreventivo).where(DocumentoPreventivo.preventivo_id == p.id)).scalars():
        s.delete(d)  # il file resta nell'archivio documenti
    s.delete(p)
    s.flush()
    registro.scrivi(s, utente=attore, azione="preventivo.elimina", oggetto_tipo="preventivo", oggetto_id=preventivo_id,
                    descrizione=f"Eliminato il preventivo {dati['codice']} (mai inviato)", dettagli={"prima": dati})


def riesame(s: Session, attore: Any, preventivo_id: int, dati: dict) -> Riesame:
    """D17: dopo l'accettazione / ordine; RT o Segreteria (D24)."""
    p = preventivo_o_404(s, preventivo_id)
    if p.stato not in ("accettato_parzialmente", "accettato_totalmente"):
        raise ErroreUtente("Il riesame del contratto si fa dopo l'accettazione (anche parziale) del preventivo.")
    if not riesame_necessario(s, p):  # N5 (0.12.8)
        raise ErroreUtente("Il riesame conforme è già registrato e da allora non è cambiato nulla: non si ripete. "
                           "Serve di nuovo se si accettano altre righe o si riaccetta una riga revocata.")
    esito = str(dati.get("esito") or "")
    if esito not in ESITI_RIESAME:
        raise ErroreUtente("Scegli l'esito del riesame.")
    punti = {k: bool(dati.get(k)) for k in ("requisiti_chiari", "competenza_strumenti", "imparzialita", "tempi")}
    note = str(dati.get("note") or "").strip()[:4000]
    if esito == "conforme" and not all(punti.values()):
        raise ErroreUtente("Per un riesame «conforme» tutti i punti di controllo devono essere verificati; altrimenti scegli «non conforme» e scrivi il motivo.")
    if esito == "non_conforme" and not note:
        raise ErroreUtente("Riesame non conforme: scrivi il motivo e l'azione decisa.")
    x = Riesame(preventivo_id=p.id, esito=esito, note=note, eseguito_da=getattr(attore, "nome", ""), **punti)
    s.add(x)
    s.flush()
    registro.scrivi(s, utente=attore, azione="preventivo.riesame", oggetto_tipo="preventivo", oggetto_id=p.id,
                    descrizione=f"Riesame del contratto del preventivo {etichetta(p)}: {ESITI_RIESAME[esito]}", dettagli={**punti, "note": note})
    if esito == "conforme":  # D61: le righe accettate diventano verifiche «da assegnare»
        from ..verifiche import servizio as verifiche

        verifiche.crea_da_preventivo(s, attore, p)
    return x


# ---------------------------------------------------------------- documento Word / PDF (D14)


def nome_file(p: Preventivo, ragione_sociale: str, estensione: str) -> str:
    if p.ambito == "DM":
        base = f"Preventivo {etichetta(p).replace(chr(47), chr(45))} del {p.data.strftime("%d-%m-%Y")} {ragione_sociale}"
        return re.sub(r"[^a-z0-9_-]+", " ", base, flags=re.I).strip()[:80] + "." + estensione
    base = f"{p.codice}{f' rev.{p.revisione}' if p.revisione else ''} - {ragione_sociale}"
    base = re.sub(r'[\\/:*?"<>|\r\n\t]+', " ", base).strip()[:150]
    return f"{base}.{estensione}"


def valori_documento(s: Session, p: Preventivo) -> tuple[dict, list[dict]]:
    if p.documento_fotografia and p.documento_fotografia != "{}":
        foto = json.loads(p.documento_fotografia)
        return foto["valori"], foto["righe"]
    cliente = cliente_del_preventivo(s, p)
    commerciale = s.get(Commerciale, p.commerciale_id) if p.commerciale_id else None
    righe = [r for r in p.righe if r.stato not in ("annullata", "rifiutata")]
    valori = {
        "cli.rag_soc": cliente.ragione_sociale, "cli.indirizzo": cliente.indirizzo, "cli.cap": cliente.cap, "cli.comune": cliente.comune,
        "cli.provincia": cliente.provincia, "cli.piva": cliente.partita_iva, "cli.cf": cliente.codice_fiscale, "cli.pec": cliente.pec,
        "p.anno_numero_preventivo": etichetta(p), "p.numero": etichetta(p), "p.data_preventivo": formatta_data(p.data),
        "p.totale_dec": euro(p.totale), "p.totale_standard_dec": euro(p.totale_standard), "p.termini_di_pagamento": p.modalita_pagamento,
        "p.modalita_pagamento": p.modalita_pagamento, "p.termine_esecuzione": p.termine_esecuzione, "p.rif_ordine": p.rif_ordine,
        "p.commerciale": commerciale.nome if commerciale else "", "p.note": p.note,
    }
    if p.ambito == "DM":
        sede = s.get(Sede, p.sede_id)
        valori.update({"sede.nome_sede": sede.denominazione, "sede.indirizzo": sede.indirizzo,
                       "sede.cap": sede.cap, "sede.comune": sede.comune, "sede.prov": sede.provincia,
                       "p.prz_lic_gest": euro(p.prezzo_licenza).replace("€ ", ""), "p.lic_gest": p.lic_gest})
        for famiglia, gruppo in (("scsp", ("SC", "SP")), ("gvr", ("GVR",))):
            for tipo, sigla in (("V1", "pvp"), ("V2", "vps")):
                valori[f"p.tot_{famiglia}_{sigla}_dec"] = euro(sum(r.tariffa_standard for r in righe
                    if r.tipologia in gruppo and r.tipo_verifica_dm == tipo))
    elenco = [{
        "n": i + 1, "rpt_nome_sede": r.sede_nome, "rpt_indirizzo": r.sede_indirizzo, "rpt_comune": r.sede_comune, "rpt_tipo_impianto": r.tipologia,
        "rpt_pot_impianto": r.descrizione, "tariffa_standard": euro(r.tariffa_standard), "tariffa_applicata": euro(r.tariffa_applicata),
        "sconto": f"{r.sconto / 100:g}%".replace(".", ",") if r.sconto else "", "tipo_verifica": TIPI_VERIFICA[r.tipo_verifica],
        "impianto": str(r.impianto_id or ""), "asset_fotografia": r.asset_fotografia, "tipo_verifica_dm": r.tipo_verifica_dm, "tipo_verifica_gvr": r.tipo_verifica_gvr,
    } for i, r in enumerate(righe)]
    return valori, elenco


def prepara_documento(s: Session, cfg: Any, preventivo_id: int) -> dict:
    """Legge tutto quello che serve (in lettura): il Word si compila poi fuori dal lucchetto delle scritture."""
    p = preventivo_o_404(s, preventivo_id)
    if not p.righe:
        raise ErroreUtente("Il preventivo non ha righe: aggiungi almeno un impianto.")
    modello = modelli.in_uso(s, "preventivo_dm" if p.ambito == "DM" else "preventivo")
    _doc, contenuto = documenti.leggi(s, cfg.cartella_documenti, modello.documento_id)
    valori, elenco = valori_documento(s, p)
    cliente = s.get(Cliente, p.cliente_id)
    from ..dm.servizio import elenchi_documento
    elenchi_dm = json.loads(p.documento_fotografia).get("elenchi_dm", {}) if p.documento_fotografia != "{}" else elenchi_documento(p) if p.ambito == "DM" else {}
    return {"modello_id": modello.id, "modello": f"{modello.codice} rev. {modello.revisione}", "contenuto_modello": contenuto,
            "valori": valori, "righe": elenco, "ambito": p.ambito, "elenchi_dm": elenchi_dm, "lic_gest": p.lic_gest, "nome_docx": nome_file(p, cliente.ragione_sociale, "docx"),
            "nome_pdf": nome_file(p, cliente.ragione_sociale, "pdf"), "versione": p.versione, "impronta": impronta_dati(valori, elenco)}


def compila_documento(prep: dict, con_pdf: bool, libreoffice: str = "") -> dict:
    from ...core import pdf

    contenuto = prep["contenuto_modello"]
    if prep.get("ambito") == "DM":
        contenuto = word.condizionali(contenuto, {"if_lic_gest": prep["lic_gest"]})
    docx, mancanti = word.compila(contenuto, prep["valori"], {"r": prep["righe"], **prep.get("elenchi_dm", {})})
    risultato = {"docx": docx, "mancanti": mancanti, "pdf": None, "avviso_pdf": ""}
    if con_pdf:
        try:
            risultato["pdf"] = pdf.da_word(docx, libreoffice)
        except ErroreUtente as e:
            risultato["avviso_pdf"] = e.messaggio
    return risultato


def salva_documenti(s: Session, cfg: Any, attore: Any, preventivo_id: int, prep: dict, compilato: dict) -> list[DocumentoPreventivo]:
    p = preventivo_o_404(s, preventivo_id)
    if p.versione != prep["versione"]:
        raise ErroreUtente("Il preventivo è cambiato mentre si preparava il documento: rigenera.", 409)
    salvati = []
    gruppo = secrets.token_hex(8)
    for formato, contenuto, nome, tipo in (("docx", compilato["docx"], prep["nome_docx"], modelli.DOCX),
                                           ("pdf", compilato["pdf"], prep["nome_pdf"], "application/pdf")):
        if not contenuto:
            continue
        doc = documenti.salva(s, cfg.cartella_documenti, contenuto, nome, tipo, getattr(attore, "id", None), f"Preventivo {etichetta(p)}")
        d = DocumentoPreventivo(preventivo_id=p.id, formato=formato, documento_id=doc.id, modello_id=prep["modello_id"], nome_file=nome,
                                versione_preventivo=prep["versione"], creato_da=getattr(attore, "nome", ""), gruppo=gruppo,
                                impronta_dati=prep.get("impronta", ""))
        s.add(d)
        salvati.append(d)
    s.flush()
    registro.scrivi(s, utente=attore, azione="preventivo.documento", oggetto_tipo="preventivo", oggetto_id=p.id,
                    descrizione=f"Preventivo {etichetta(p)}: generato {' e '.join(d.formato.upper() for d in salvati)} con il modello {prep['modello']}",
                    dettagli={"mancanti": compilato["mancanti"], "avviso_pdf": compilato["avviso_pdf"]})
    return salvati


def pdf_da_stampare(s: Session, preventivo_id: int) -> dict | None:
    """Il PDF già pronto da stampare, se c'è (D58):
    - preventivo già inviato → il PDF inviato (la copia su carta coincide con quella spedita);
    - altrimenti → l'ultimo PDF, solo se dopo non è cambiato nulla (stessa versione del preventivo e stesso modello in uso).
    None = va generato adesso."""
    p = preventivo_o_404(s, preventivo_id)
    pdf_del = select(DocumentoPreventivo).where(DocumentoPreventivo.preventivo_id == p.id, DocumentoPreventivo.formato == "pdf")
    if p.inviato_il:
        invio = s.execute(select(InvioPreventivo).where(InvioPreventivo.preventivo_id == p.id)
                          .order_by(InvioPreventivo.inviato_il.desc(), InvioPreventivo.id.desc())).scalars().first()
        for doc_id in (json.loads(invio.allegati or "[]") if invio else []):
            d = s.execute(pdf_del.where(DocumentoPreventivo.documento_id == doc_id)).scalars().first()
            if d:
                return {"documento_id": d.documento_id, "nome_file": d.nome_file, "motivo": "inviato"}
        d = s.execute(pdf_del.where(DocumentoPreventivo.creato_il <= p.inviato_il)
                      .order_by(DocumentoPreventivo.creato_il.desc(), DocumentoPreventivo.id.desc())).scalars().first()
        if d:
            return {"documento_id": d.documento_id, "nome_file": d.nome_file, "motivo": "inviato"}
        # archivi precedenti alla 0.7.0 («segnato come inviato» senza PDF): il PDF ricostruito dopo, sempre lo stesso
        d = s.execute(pdf_del.order_by(DocumentoPreventivo.creato_il.desc(), DocumentoPreventivo.id.desc())).scalars().first()
        if d:
            return {"documento_id": d.documento_id, "nome_file": d.nome_file, "motivo": "ricostruito"}
        return None
    d = anteprima_da_riusare(s, p)  # 0.7.0: l'ultima preparazione con i dati attuali (D80)
    if d is not None:
        motivo = "approvato" if d.approvato_il else "ritoccato" if d.ritoccato else "invariato"
        return {"documento_id": d.documento_id, "nome_file": d.nome_file, "motivo": motivo}
    return None


def impronta_dati(valori: dict, elenco: list) -> str:
    """Impronta dei dati stampati nel documento (testata, cliente, righe, importi): se cambia, il documento non vale più."""
    return hashlib.sha256(json.dumps([valori, elenco], sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")).hexdigest()


def impronta_attuale(s: Session, p: Preventivo) -> str:
    valori, elenco = valori_documento(s, p)
    return impronta_dati(valori, elenco)


def documento_corrente(s: Session, p: Preventivo) -> DocumentoPreventivo | None:
    """PDF dell'ultima preparazione (anteprima o ritocco) fatta con i dati attuali del preventivo."""
    if not p.righe:
        return None
    return s.execute(select(DocumentoPreventivo).where(DocumentoPreventivo.preventivo_id == p.id, DocumentoPreventivo.formato == "pdf",
                                                       DocumentoPreventivo.impronta_dati == impronta_attuale(s, p))
                     .order_by(DocumentoPreventivo.id.desc())).scalars().first()


def anteprima_da_riusare(s: Session, p: Preventivo) -> DocumentoPreventivo | None:
    """Il documento attuale si riusa se è ritoccato o fatto con il modello in uso; altrimenti si prepara di nuovo."""
    d = documento_corrente(s, p)
    if d is None or d.ritoccato:
        return d
    try:
        modello_id = modelli.in_uso(s, "preventivo").id
    except ErroreUtente:
        modello_id = None
    return d if d.modello_id == modello_id else None


def pdf_approvato(s: Session, p: Preventivo) -> DocumentoPreventivo | None:
    """Il PDF da inviare: l'ultima preparazione con i dati attuali, se approvata (presa visione)."""
    d = documento_corrente(s, p)
    return d if d is not None and d.approvato_il is not None else None


def word_del_gruppo(s: Session, d: DocumentoPreventivo) -> DocumentoPreventivo | None:
    if not d.gruppo:
        return None
    return s.execute(select(DocumentoPreventivo).where(DocumentoPreventivo.preventivo_id == d.preventivo_id, DocumentoPreventivo.gruppo == d.gruppo,
                                                       DocumentoPreventivo.formato == "docx")).scalars().first()


def documento_json(s: Session, p: Preventivo, d: DocumentoPreventivo, ufficiale: bool = False) -> dict:
    """Il documento da controllare nella finestra «Controlla il documento»."""
    w = word_del_gruppo(s, d)
    modello = None
    if d.modello_id:
        from ..documenti.modelli import ModelloDocumento
        m = s.get(ModelloDocumento, d.modello_id)
        modello = f"{m.codice} rev. {m.revisione}" if m else None
    return {"pdf_documento_id": d.documento_id, "word_documento_id": w.documento_id if w else None, "nome_file": d.nome_file,
            "nome_word": w.nome_file if w else "", "indirizzo": f"/api/preventivi/{p.id}/documenti/{d.documento_id}?in_linea=true",
            "ritoccato": d.ritoccato, "modello": modello, "creato_il": iso_locale(d.creato_il), "creato_da": d.creato_da,
            "approvato": d.approvato_il is not None, "approvato_il": iso_locale(d.approvato_il), "approvato_da": d.approvato_da,
            "ufficiale": ufficiale, "stato": p.stato, "da_approvare": p.stato == "creato" and d.approvato_il is None}


def approva_documento(s: Session, attore: Any, preventivo_id: int, documento_id: int) -> DocumentoPreventivo:
    """Presa visione: chi approva dichiara di aver controllato il PDF; è quello che si invierà (D80)."""
    p = preventivo_o_404(s, preventivo_id)
    if p.stato != "creato":
        raise ErroreUtente(f"Il documento si approva prima dell'invio: il preventivo è «{STATI[p.stato]}».")
    d = documento_corrente(s, p)
    if d is None or d.documento_id != documento_id:
        raise ErroreUtente("Non è il documento attuale del preventivo (i dati sono cambiati o c'è una versione più recente): apri di nuovo l'anteprima.", 409)
    if d.approvato_il is None:
        d.approvato_il, d.approvato_da = adesso(), getattr(attore, "nome", "")
        registro.scrivi(s, utente=attore, azione="preventivo.documento_approvato", oggetto_tipo="preventivo", oggetto_id=p.id,
                        descrizione=f"Preventivo {etichetta(p)}: documento controllato e approvato per l'invio ({d.nome_file})",
                        dettagli={"documento_id": d.documento_id, "ritoccato": d.ritoccato})
    return d


def prepara_ritocco(s: Session, cfg: Any, preventivo_id: int, docx: bytes, versione: Any) -> dict:
    """Word ritoccato a mano (D80): solo prima dell'invio e solo impaginazione. Il confronto è lo stesso dei verbali
    di VerbalizzAI: testo, caselle, campi e immagini devono restare identici al Word dell'anteprima."""
    from ...terzi.verbalizzai.finalization import content_signature

    p = preventivo_o_404(s, preventivo_id)
    controlla_versione(p, versione)
    if p.stato != "creato":
        raise ErroreUtente("Il ritocco si fa prima dell'invio. Dopo l'invio il documento non cambia più: per correggerlo si crea una revisione.")
    if not docx:
        raise ErroreUtente("Scegli il Word ritoccato (.docx).")
    if len(docx) > 25 * 1024 * 1024:
        raise ErroreUtente("Il Word è troppo grande (massimo 25 MB).")
    base = documento_corrente(s, p)
    base_word = word_del_gruppo(s, base) if base is not None else None
    if base_word is None:
        raise ErroreUtente("Apri prima l'«Anteprima»: il ritocco parte dal Word dell'anteprima con i dati attuali.")
    _doc, originale = documenti.leggi(s, cfg.cartella_documenti, base_word.documento_id)
    try:
        uguale = content_signature(docx) == content_signature(originale)
    except ValueError as e:
        raise ErroreUtente(f"Il Word non si può usare: {e}") from None
    if not uguale:
        raise ErroreUtente("Il Word ritoccato contiene modifiche al testo, ai numeri o alle immagini. Qui sono ammessi solo ritocchi di impaginazione "
                           "(margini, spazi, interruzioni di pagina): i dati si correggono nel gestionale, poi si riapre l'anteprima.")
    return {"impronta": base.impronta_dati, "nome_docx": base_word.nome_file, "nome_pdf": base.nome_file, "modello_id": base.modello_id}


def salva_ritocco(s: Session, cfg: Any, attore: Any, preventivo_id: int, docx: bytes, pdf: bytes, prep: dict) -> DocumentoPreventivo:
    p = preventivo_o_404(s, preventivo_id)
    if p.stato != "creato" or impronta_attuale(s, p) != prep["impronta"]:
        raise ErroreUtente("Il preventivo è cambiato durante il caricamento: riapri l'anteprima e ripeti il ritocco.", 409)
    gruppo, salvati = secrets.token_hex(8), []
    for formato, contenuto, nome, tipo in (("docx", docx, prep["nome_docx"], modelli.DOCX), ("pdf", pdf, prep["nome_pdf"], "application/pdf")):
        doc = documenti.salva(s, cfg.cartella_documenti, contenuto, nome, tipo, getattr(attore, "id", None), f"Preventivo {etichetta(p)} (ritocco di impaginazione)")
        d = DocumentoPreventivo(preventivo_id=p.id, formato=formato, documento_id=doc.id, modello_id=prep["modello_id"], nome_file=nome,
                                versione_preventivo=p.versione, ritoccato=True, creato_da=getattr(attore, "nome", ""), gruppo=gruppo,
                                impronta_dati=prep["impronta"])
        s.add(d)
        salvati.append(d)
    s.flush()
    registro.scrivi(s, utente=attore, azione="preventivo.documento_ritoccato", oggetto_tipo="preventivo", oggetto_id=p.id,
                    descrizione=f"Preventivo {etichetta(p)}: caricato il Word con ritocchi di impaginazione (contenuto controllato, PDF rifatto dal programma); da approvare",
                    dettagli={"word": salvati[0].nome_file})
    return salvati[1]


def documento_preventivo(s: Session, cfg: Any, preventivo_id: int, documento_id: int) -> tuple[Documento, bytes]:
    d = s.execute(select(DocumentoPreventivo).where(DocumentoPreventivo.preventivo_id == preventivo_id,
                                                    DocumentoPreventivo.documento_id == documento_id)).scalar()
    if d is None:
        raise NonTrovato("Documento non trovato per questo preventivo.")
    return documenti.leggi(s, cfg.cartella_documenti, documento_id)


# ---------------------------------------------------------------- invio email (D14)


def valori_email(s: Session, p: Preventivo) -> dict:
    cliente = s.get(Cliente, p.cliente_id)
    commerciale = s.get(Commerciale, p.commerciale_id) if p.commerciale_id else None
    return {"numero": etichetta(p), "data": formatta_data(p.data), "cliente": cliente.ragione_sociale, "totale": euro(p.totale),
            "commerciale": commerciale.nome if commerciale else ""}


def bozza_email(s: Session, preventivo_id: int, copia_ufficio: str) -> dict:
    p = preventivo_o_404(s, preventivo_id)
    cliente = s.get(Cliente, p.cliente_id)
    testi = testi_email(s)
    valori = valori_email(s, p)
    destinatari = cliente.referente_email or cliente.email_fatture or cliente.email_verbali or cliente.pec
    if p.ambito == "DM":
        sede = s.get(Sede, p.sede_id)
        destinatari = sede.referente_email
        testi = {"oggetto": "Preventivo DM {numero} — {cliente}", "testo": "Spett.le {cliente},\n\nin allegato trasmettiamo il preventivo per le attività indicate.\n\nCordiali saluti", "firma": "AD S.r.l."}
    return {"a": destinatari, "cc": copia_ufficio, "oggetto": posta.compila_testo(testi["oggetto"], valori),
            "testo": posta.compila_testo(testi["testo"], valori) + ("\n\n" + testi["firma"] if testi.get("firma") else "")}


def registra_invio(s: Session, attore: Any, preventivo_id: int, versione: int, a: list[str], cc: list[str], oggetto: str, testo: str,
                   allegati: list[int], esito: str) -> Preventivo:
    p = preventivo_o_404(s, preventivo_id)
    s.add(InvioPreventivo(preventivo_id=p.id, destinatari="; ".join(a), copia="; ".join(cc), oggetto=oggetto[:300], testo=testo,
                          allegati=json.dumps(allegati), esito=esito[:300], inviato_da=getattr(attore, "nome", "")))
    if p.stato == "creato":
        congela_cliente(s, p)
        p.inviato_il = adesso()
        ricalcola_stato(p)
    elif p.inviato_il is None:
        p.inviato_il = adesso()
    _modificato(p, attore)
    registro.scrivi(s, utente=attore, azione="preventivo.invio_email", oggetto_tipo="preventivo", oggetto_id=p.id,
                    descrizione=f"Preventivo {etichetta(p)} inviato per email a {', '.join(a)}" + (f" (copia {', '.join(cc)})" if cc else ""),
                    dettagli={"oggetto": oggetto, "allegati": allegati, "esito": esito})
    return p


def congela_cliente(s, p):
    if not p.cliente_fotografia or p.cliente_fotografia == "{}":
        from ..finanza.servizio import CAMPI_CLIENTE
        c = s.get(Cliente, p.cliente_id)
        p.cliente_fotografia = json.dumps({k: getattr(c, k) for k in CAMPI_CLIENTE}, ensure_ascii=False)
        valori, righe = valori_documento(s, p)
        from ..dm.servizio import elenchi_documento
        p.documento_fotografia = json.dumps({"valori": valori, "righe": righe, "elenchi_dm": elenchi_documento(p) if p.ambito == "DM" else {}}, ensure_ascii=False)

def cliente_del_preventivo(s, p):
    from types import SimpleNamespace
    foto = json.loads(p.cliente_fotografia or "{}")
    return SimpleNamespace(**foto) if foto else s.get(Cliente, p.cliente_id)


# ---------------------------------------------------------------- R138 (0.16): accettazione e ordine del cliente

TIPI_ALLEGATO = {"accettazione": "Preventivo controfirmato / accettazione", "ordine": "Ordine del cliente", "email": "Email",
                 "altro": "Altro documento"}
ESTENSIONI_ALLEGATO = {".pdf": "application/pdf", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
                       ".eml": "message/rfc822", ".msg": "application/vnd.ms-outlook"}
MASSIMO_ALLEGATO = 20 * 1024 * 1024


def _allegati_attivi(s: Session, p: Preventivo) -> list:
    from .modelli import AllegatoPreventivo
    return list(s.scalars(select(AllegatoPreventivo).where(AllegatoPreventivo.preventivo_id == p.id, AllegatoPreventivo.rimosso.is_(False))
                          .order_by(AllegatoPreventivo.id)))


def allegati_json(s: Session, p: Preventivo) -> list[dict]:
    from .modelli import AllegatoPreventivo
    return [{"id": a.id, "tipo": a.tipo, "tipo_testo": TIPI_ALLEGATO[a.tipo], "nome_file": a.nome_file, "descrizione": a.descrizione,
             "creato_il": iso_locale(a.creato_il), "creato_da": a.creato_da, "rimosso": a.rimosso, "rimosso_il": iso_locale(a.rimosso_il),
             "rimosso_da": a.rimosso_da}
            for a in s.scalars(select(AllegatoPreventivo).where(AllegatoPreventivo.preventivo_id == p.id).order_by(AllegatoPreventivo.id))]


def avvisi_accettazione(s: Session, p: Preventivo, cliente: Cliente | None = None) -> list[str]:
    """Avvisi che non bloccano: file dell'accettazione mancante; PA senza ordine/contratto con CIG (come nella bozza di fattura)."""
    avvisi = []
    if p.stato in ("accettato_parzialmente", "accettato_totalmente") and not _allegati_attivi(s, p):
        avvisi.append("Manca il file dell'accettazione o dell'ordine: è consigliato caricarlo (evidenza del riesame del contratto).")
    cliente = cliente or s.get(Cliente, p.cliente_id)
    docs = json.loads(p.documenti_collegati or "[]")
    if cliente is not None and cliente.tipo == "pa" and not any(d.get("cig") for d in docs):
        avvisi.append("Pubblica amministrazione: per la fattura elettronica di solito servono ordine o contratto con CIG (e CUP se previsto).")
    return avvisi


def carica_allegato(s: Session, cfg: Any, attore: Any, preventivo_id: int, contenuto: bytes, nome: str, tipo: str, descrizione: str = ""):
    from pathlib import Path

    from .modelli import AllegatoPreventivo
    p = preventivo_o_404(s, preventivo_id)
    if p.stato in ("annullato", "sostituito"):
        raise ErroreUtente(f"Il preventivo {etichetta(p)} è «{STATI[p.stato]}»: non si aggiungono file.")
    if tipo not in TIPI_ALLEGATO:
        raise ErroreUtente("Tipo di file non valido: accettazione, ordine, email o altro.")
    est = Path(nome or "").suffix.lower()
    if est not in ESTENSIONI_ALLEGATO:
        raise ErroreUtente("Formato non ammesso: carica un PDF, un'immagine (PNG, JPG) o un'email (.eml, .msg).")
    if not contenuto:
        raise ErroreUtente("Il file è vuoto.")
    if len(contenuto) > MASSIMO_ALLEGATO:
        raise ErroreUtente("File troppo grande: al massimo 20 MB.")
    if est == ".pdf" and not contenuto.startswith(b"%PDF"):
        raise ErroreUtente("Il file non è un PDF valido.")
    doc = documenti.salva(s, cfg.cartella_documenti, contenuto, nome, ESTENSIONI_ALLEGATO[est], getattr(attore, "id", None),
                          f"Preventivo {etichetta(p)}: {TIPI_ALLEGATO[tipo].lower()}")
    a = AllegatoPreventivo(preventivo_id=p.id, documento_id=doc.id, tipo=tipo, nome_file=Path(nome).name[:255],
                           descrizione=str(descrizione or "").strip()[:300], creato_da=getattr(attore, "nome", ""))
    s.add(a)
    _modificato(p, attore)
    s.flush()
    registro.scrivi(s, utente=attore, azione="preventivo.allegato", oggetto_tipo="preventivo", oggetto_id=p.id,
                    descrizione=f"Preventivo {etichetta(p)}: caricato «{a.nome_file}» ({TIPI_ALLEGATO[tipo].lower()})",
                    dettagli={"allegato_id": a.id, "documento_id": doc.id, "impronta": doc.impronta})
    return p


def togli_allegato(s: Session, attore: Any, preventivo_id: int, allegato_id: int, motivo: str = ""):
    from .modelli import AllegatoPreventivo
    p = preventivo_o_404(s, preventivo_id)
    a = s.get(AllegatoPreventivo, allegato_id)
    if a is None or a.preventivo_id != p.id or a.rimosso:
        raise NonTrovato("File non trovato: ricarica la scheda.")
    a.rimosso, a.rimosso_il, a.rimosso_da = True, adesso(), getattr(attore, "nome", "")
    _modificato(p, attore)
    registro.scrivi(s, utente=attore, azione="preventivo.allegato_tolto", oggetto_tipo="preventivo", oggetto_id=p.id,
                    descrizione=f"Preventivo {etichetta(p)}: tolto «{a.nome_file}»" + (f" · {motivo}" if motivo else "") + " (il file resta in archivio)")
    return p


def file_allegato(s: Session, cfg: Any, preventivo_id: int, allegato_id: int):
    from .modelli import AllegatoPreventivo
    a = s.get(AllegatoPreventivo, allegato_id)
    if a is None or a.preventivo_id != preventivo_id:
        raise NonTrovato("File non trovato.")
    doc, contenuto = documenti.leggi(s, cfg.cartella_documenti, a.documento_id)
    return a, doc, contenuto


def salva_documenti_collegati(s: Session, attore: Any, preventivo_id: int, docs: Any, versione: Any) -> Preventivo:
    """Dati per la fattura elettronica (linguetta «Fattura» di Garda). Si cambiano anche dopo l'invio e l'accettazione,
    come il riferimento all'ordine: non toccano prezzi né righe."""
    from ..finanza.servizio import documenti_validi
    p = preventivo_o_404(s, preventivo_id)
    controlla_versione(p, versione)
    if p.stato in ("annullato", "sostituito"):
        raise ErroreUtente(f"Il preventivo {etichetta(p)} è «{STATI[p.stato]}»: non si modifica.")
    prima = json.loads(p.documenti_collegati or "[]")
    nuovi = documenti_validi(docs or [])
    for d in nuovi:
        if not d["data"]:
            raise ErroreUtente("Documenti per la fattura: numero e data sono obbligatori perché il documento esca in fattura.")
    p.documenti_collegati = json.dumps(nuovi, ensure_ascii=False)
    ordine = next((d for d in nuovi if d["tipo"] == "OrdineAcquisto"), None)
    if ordine and not p.rif_ordine:  # D36: il riferimento all'ordine nel preventivo e nei modelli Word
        p.rif_ordine = f"n. {ordine['numero']}"[:120]
        p.data_ordine = date.fromisoformat(ordine["data"])
    _modificato(p, attore)
    registro.scrivi(s, utente=attore, azione="preventivo.documenti_collegati", oggetto_tipo="preventivo", oggetto_id=p.id,
                    descrizione=f"Preventivo {etichetta(p)}: documenti per la fattura elettronica ({len(nuovi)})",
                    dettagli={"prima": prima, "dopo": nuovi})
    return p
