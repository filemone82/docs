"""Interfaccia JSON dei preventivi, dei modelli Word e delle impostazioni email."""

from __future__ import annotations

from urllib.parse import quote

from fastapi import APIRouter, Body, Depends, File, Form, UploadFile
from fastapi.responses import Response
from sqlalchemy import select

from ...core import pdf, posta
from ...core.db import Archivio
from ...core.errori import ErroreUtente, PermessoNegato
from ...web.dipendenze import archivio, richiede, utente
from ..documenti import modelli_servizio as modelli
from ..documenti import servizio as documenti
from ..documenti.modelli import Documento, ModelloDocumento
from ..utenti.accesso import UtenteCorrente
from . import servizio
from .modelli import ESITI_RIESAME, STATI, STATI_RIGA, TIPI_VERIFICA, DocumentoPreventivo, Preventivo

router = APIRouter(prefix="/api")
VEDERE, MODIFICA = "preventivi.vedere", "preventivi.modifica"


def _file(contenuto: bytes, nome: str, tipo: str, in_linea: bool = False) -> Response:
    """`in_linea`: il PDF si apre nel browser (per stamparlo) invece di essere scaricato."""
    modo = "inline" if in_linea and tipo == "application/pdf" else "attachment"
    return Response(contenuto, media_type=tipo, headers={"Content-Disposition": f"{modo}; filename*=UTF-8''{quote(nome)}"})


def _json(arc: Archivio, preventivo_id: int) -> dict:
    with arc.lettura() as s:
        return servizio.preventivo_json(s, servizio.preventivo_o_404(s, preventivo_id))


@router.get("/preventivi/valori")
def valori(_u: UtenteCorrente = Depends(richiede(VEDERE)), arc: Archivio = Depends(archivio)) -> dict:
    from ..dm.servizio import TIPI, GVR
    return {"tipi_dm": TIPI, "tipi_gvr": GVR, "stati": STATI, "stati_riga": STATI_RIGA, "tipi_verifica": TIPI_VERIFICA, "esiti_riesame": ESITI_RIESAME,
            "pdf_disponibile": pdf.disponibile(arc.cfg.libreoffice), "tipi_allegato": servizio.TIPI_ALLEGATO,
            "tipi_documento": __import__("gestionale.moduli.finanza.servizio", fromlist=["NOMI_DOCUMENTO"]).NOMI_DOCUMENTO}


@router.get("/preventivi/aperti")
def aperti(cliente_id: int, _u: UtenteCorrente = Depends(richiede(VEDERE)), arc: Archivio = Depends(archivio)) -> list[dict]:
    """Preventivi del cliente a cui si possono ancora aggiungere impianti dallo scadenziario (D19, O12):
    «creato» (aggiunta diretta) e «inviato» / «rifiutato» (con una revisione)."""
    with arc.lettura() as s:
        q = (select(Preventivo).where(Preventivo.ambito == "DPR", Preventivo.cliente_id == cliente_id, Preventivo.stato.in_(("creato", "inviato", "rifiutato")))
             .order_by(Preventivo.id.desc()))
        return [{"id": p.id, "codice": p.codice, "etichetta": servizio.etichetta(p), "data": p.data.isoformat(), "righe": len(p.righe),
                 "totale": p.totale, "stato": p.stato, "stato_testo": STATI[p.stato], "versione": p.versione} for p in s.execute(q).scalars()]


@router.get("/preventivi/{preventivo_id}")
def leggi(preventivo_id: int, _u: UtenteCorrente = Depends(richiede(VEDERE)), arc: Archivio = Depends(archivio)) -> dict:
    return _json(arc, preventivo_id)


@router.post("/preventivi")
def crea(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede(MODIFICA)), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        p = servizio.crea(s, u.come_attore(), dati)
        return servizio.preventivo_json(s, p)


@router.post("/preventivi/{preventivo_id}/impianti")
def aggiungi_impianti(preventivo_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede(MODIFICA)),
                      arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        p = servizio.aggiungi_impianti(s, u.come_attore(), preventivo_id, dati.get("impianti") or [], dati.get("versione"),
                                       str(dati.get("tipo_verifica") or "periodica"))
        return servizio.preventivo_json(s, p)


@router.post("/preventivi/da-scadenze")
def da_scadenze(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede(MODIFICA)), arc: Archivio = Depends(archivio)) -> dict:
    """Maschera ⚡ dello scadenziario (O12)."""
    with arc.scrittura() as s:
        p = servizio.da_scadenze(s, u.come_attore(), dati, u.puo("preventivi.revisione"))
        return servizio.preventivo_json(s, p)


@router.post("/preventivi/{preventivo_id}/voci")
def aggiungi_voce(preventivo_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede(MODIFICA)),
                  arc: Archivio = Depends(archivio)) -> dict:
    """Riga senza impianto: voce del tariffario (trasferta, sopralluogo a vuoto…) o importo a corpo (0.4.0)."""
    with arc.scrittura() as s:
        p = servizio.aggiungi_voce(s, u.come_attore(), preventivo_id, dati)
        return servizio.preventivo_json(s, p)


@router.put("/preventivi/{preventivo_id}")
def modifica(preventivo_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede(MODIFICA)), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        p = servizio.modifica(s, u.come_attore(), preventivo_id, dati, u.puo("preventivi.sconti_applica"))
        return servizio.preventivo_json(s, p)


@router.post("/preventivi/{preventivo_id}/ricalcola")
def ricalcola(preventivo_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede(MODIFICA)), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.preventivo_json(s, servizio.ricalcola_tariffe(s, u.come_attore(), preventivo_id, dati.get("versione")))


@router.post("/preventivi/{preventivo_id}/inviato")
def inviato(preventivo_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("preventivi.invia")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.preventivo_json(s, servizio.segna_inviato(s, u.come_attore(), preventivo_id, dati.get("versione")))


@router.post("/preventivi/{preventivo_id}/righe/stato")
def stato_righe(preventivo_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("preventivi.accettazione")),
                arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        p = servizio.stato_righe(s, u.come_attore(), preventivo_id, dati.get("righe") or [], str(dati.get("stato") or ""), dati.get("versione"), str(dati.get("evidenza_accettazione") or ""))
        return servizio.preventivo_json(s, p)


# ---------------------------------------------------------------- R138 (0.16): accettazione e ordine del cliente


@router.post("/preventivi/{preventivo_id}/allegati")
async def carica_allegato(preventivo_id: int, file: UploadFile = File(...), tipo: str = Form("accettazione"), descrizione: str = Form(""),
                          u: UtenteCorrente = Depends(richiede("preventivi.accettazione")), arc: Archivio = Depends(archivio)) -> dict:
    contenuto = await file.read()
    with arc.scrittura() as s:
        p = servizio.carica_allegato(s, arc.cfg, u.come_attore(), preventivo_id, contenuto, file.filename or "file", tipo, descrizione)
        return servizio.preventivo_json(s, p)


@router.get("/preventivi/{preventivo_id}/allegati/{allegato_id}/file")
def scarica_allegato(preventivo_id: int, allegato_id: int, _u: UtenteCorrente = Depends(richiede("preventivi.vedere")),
                     arc: Archivio = Depends(archivio)) -> Response:
    with arc.lettura() as s:
        a, doc, contenuto = servizio.file_allegato(s, arc.cfg, preventivo_id, allegato_id)
        return _file(contenuto, a.nome_file, doc.tipo_mime, in_linea=True)


@router.post("/preventivi/{preventivo_id}/allegati/{allegato_id}/togli")
def togli_allegato(preventivo_id: int, allegato_id: int, dati: dict = Body(default={}), u: UtenteCorrente = Depends(richiede("preventivi.accettazione")),
                   arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        p = servizio.togli_allegato(s, u.come_attore(), preventivo_id, allegato_id, str((dati or {}).get("motivo") or "")[:300])
        return servizio.preventivo_json(s, p)


@router.put("/preventivi/{preventivo_id}/documenti-collegati")
def documenti_collegati(preventivo_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("preventivi.accettazione")),
                        arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        p = servizio.salva_documenti_collegati(s, u.come_attore(), preventivo_id, dati.get("documenti"), dati.get("versione"))
        return servizio.preventivo_json(s, p)


@router.post("/preventivi/{preventivo_id}/righe/revoca")
def revoca_righe(preventivo_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("preventivi.accettazione")),
                 arc: Archivio = Depends(archivio)) -> dict:
    """R124 (0.12.8): revoca motivata dell'accettazione."""
    with arc.scrittura() as s:
        p = servizio.revoca_righe(s, u.come_attore(), preventivo_id, dati.get("righe") or [], dati.get("motivo"), dati.get("versione"))
        return servizio.preventivo_json(s, p)


@router.post("/preventivi/{preventivo_id}/sconto-revisione")
def sconto_revisione(preventivo_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("preventivi.revisione")),
                     arc: Archivio = Depends(archivio)) -> dict:
    if not u.puo("preventivi.sconti_applica"):
        raise PermessoNegato("Non hai il permesso di applicare sconti.")
    with arc.scrittura() as s:
        return servizio.preventivo_json(s, servizio.sconto_con_revisione(s, u.come_attore(), preventivo_id, dati))


@router.post("/preventivi/{preventivo_id}/revisione")
def revisione(preventivo_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("preventivi.revisione")),
              arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.preventivo_json(s, servizio.crea_revisione(s, u.come_attore(), preventivo_id, dati.get("versione")))


@router.post("/preventivi/{preventivo_id}/annulla")
def annulla(preventivo_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("preventivi.annulla")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.preventivo_json(s, servizio.annulla(s, u.come_attore(), preventivo_id, str(dati.get("motivo") or ""), dati.get("versione")))


@router.delete("/preventivi/{preventivo_id}")
def elimina(preventivo_id: int, u: UtenteCorrente = Depends(richiede("preventivi.elimina_bozza")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        servizio.elimina(s, u.come_attore(), preventivo_id)
    return {"ok": True}


@router.post("/preventivi/{preventivo_id}/riesame")
def riesame(preventivo_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("preventivi.riesame")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        if not u.puo("preventivi.riesame", servizio.preventivo_o_404(s, preventivo_id).ambito):   # R132
            raise PermessoNegato("Il riesame di questo contratto spetta al responsabile tecnico dell'altra attività o alla segreteria.")
        servizio.riesame(s, u.come_attore(), preventivo_id, dati)
        return servizio.preventivo_json(s, servizio.preventivo_o_404(s, preventivo_id))


# ---------------------------------------------------------------- documento e invio


@router.post("/preventivi/{preventivo_id}/documenti")
def genera_documenti(preventivo_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("preventivi.documenti")),
                     arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        prep = servizio.prepara_documento(s, arc.cfg, preventivo_id)
    compilato = servizio.compila_documento(prep, bool(dati.get("pdf", True)), arc.cfg.libreoffice)  # fuori dal lucchetto (LibreOffice)
    with arc.scrittura() as s:
        salvati = servizio.salva_documenti(s, arc.cfg, u.come_attore(), preventivo_id, prep, compilato)
        risultato = servizio.preventivo_json(s, servizio.preventivo_o_404(s, preventivo_id))
    risultato["generati"] = [{"documento_id": d.documento_id, "formato": d.formato, "nome_file": d.nome_file} for d in salvati]
    risultato["avviso_pdf"] = compilato["avviso_pdf"]
    risultato["segnaposto_vuoti"] = compilato["mancanti"]
    return risultato


@router.get("/preventivi/{preventivo_id}/documenti/{documento_id}")
def scarica_documento(preventivo_id: int, documento_id: int, in_linea: bool = False, _u: UtenteCorrente = Depends(richiede(VEDERE)),
                      arc: Archivio = Depends(archivio)) -> Response:
    with arc.lettura() as s:
        doc, contenuto = servizio.documento_preventivo(s, arc.cfg, preventivo_id, documento_id)
    return _file(contenuto, doc.nome_originale, doc.tipo_mime, in_linea)


@router.post("/preventivi/{preventivo_id}/documenti/ritoccati")
async def carica_ritoccato(preventivo_id: int, word: UploadFile = File(...), versione: str = Form(""),
                           u: UtenteCorrente = Depends(richiede("preventivi.documenti")), arc: Archivio = Depends(archivio)) -> dict:
    """D80 (come i verbali): Word con ritocchi di sola impaginazione; contenuto controllato, PDF rifatto dal programma, da approvare."""
    docx = await word.read(25 * 1024 * 1024 + 1)
    with arc.lettura() as s:
        prep = servizio.prepara_ritocco(s, arc.cfg, preventivo_id, docx, versione or None)
    contenuto_pdf = pdf.da_word(docx, arc.cfg.libreoffice)  # fuori dal lucchetto (LibreOffice)
    with arc.scrittura() as s:
        d = servizio.salva_ritocco(s, arc.cfg, u.come_attore(), preventivo_id, docx, contenuto_pdf, prep)
        p = servizio.preventivo_o_404(s, preventivo_id)
        return servizio.preventivo_json(s, p) | {"documento": servizio.documento_json(s, p, d)}


@router.post("/preventivi/{preventivo_id}/anteprima")
def anteprima(preventivo_id: int, u: UtenteCorrente = Depends(richiede(VEDERE)), arc: Archivio = Depends(archivio)) -> dict:
    """D80, come i verbali: il documento si prepara e si ARCHIVIA (Word + PDF con l'impronta dei dati) e si controlla qui;
    se i dati non sono cambiati si riapre lo stesso (con la sua approvazione). Preventivo già inviato: il PDF inviato."""
    with arc.lettura() as s:
        p = servizio.preventivo_o_404(s, preventivo_id)
        if not p.righe:
            raise ErroreUtente("Il preventivo non ha righe: aggiungi almeno un impianto.")
        if p.stato == "creato":
            d = servizio.anteprima_da_riusare(s, p)
            if d is not None:
                return {"documento": servizio.documento_json(s, p, d), "generato": False}
        else:
            pronto = servizio.pdf_da_stampare(s, preventivo_id)
            if pronto is not None:
                d = s.execute(select(DocumentoPreventivo).where(DocumentoPreventivo.preventivo_id == p.id,
                                                                DocumentoPreventivo.documento_id == pronto["documento_id"])).scalars().first()
                return {"documento": servizio.documento_json(s, p, d, ufficiale=True), "generato": False}
            if p.stato in ("annullato", "sostituito"):
                raise ErroreUtente(f"Il preventivo è «{STATI[p.stato]}» e non ha un PDF archiviato.")
        if not u.puo("preventivi.documenti"):
            raise ErroreUtente("Il documento aggiornato non c'è ancora e non hai il permesso di prepararlo.", 403)
        prep = servizio.prepara_documento(s, arc.cfg, preventivo_id)
    compilato = servizio.compila_documento(prep, True, arc.cfg.libreoffice)  # fuori dal lucchetto (LibreOffice)
    if not compilato["pdf"]:
        raise ErroreUtente(compilato["avviso_pdf"] or "PDF non disponibile: per l'anteprima serve LibreOffice.")
    with arc.scrittura() as s:
        salvati = servizio.salva_documenti(s, arc.cfg, u.come_attore(), preventivo_id, prep, compilato)
        p = servizio.preventivo_o_404(s, preventivo_id)
        d = next(x for x in salvati if x.formato == "pdf")
        return {"documento": servizio.documento_json(s, p, d, ufficiale=p.stato != "creato"), "generato": True,
                "segnaposto_vuoti": compilato["mancanti"]}


@router.post("/preventivi/{preventivo_id}/documenti/{documento_id}/approva")
def approva(preventivo_id: int, documento_id: int, u: UtenteCorrente = Depends(richiede("preventivi.documenti")),
            arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        d = servizio.approva_documento(s, u.come_attore(), preventivo_id, documento_id)
        p = servizio.preventivo_o_404(s, preventivo_id)
        return servizio.preventivo_json(s, p) | {"documento": servizio.documento_json(s, p, d)}


@router.post("/preventivi/{preventivo_id}/stampa")
def stampa(preventivo_id: int, u: UtenteCorrente = Depends(richiede(VEDERE)), arc: Archivio = Depends(archivio)) -> dict:
    """PDF da stampare (D58): quello già pronto se nulla è cambiato (o quello inviato), altrimenti lo genera e lo archivia."""
    with arc.lettura() as s:
        pronto = servizio.pdf_da_stampare(s, preventivo_id)
        if pronto is None:
            p = servizio.preventivo_o_404(s, preventivo_id)
            if p.stato in ("annullato", "sostituito"):
                raise ErroreUtente(f"Il preventivo è «{STATI[p.stato]}» e non ha un PDF archiviato da stampare.")
            if not u.puo("preventivi.documenti"):
                raise ErroreUtente("Il PDF aggiornato non c'è ancora e non hai il permesso di generarlo.", 403)
            prep = servizio.prepara_documento(s, arc.cfg, preventivo_id)
    if pronto is not None:
        return pronto | {"generato": False}
    compilato = servizio.compila_documento(prep, True, arc.cfg.libreoffice)  # fuori dal lucchetto (LibreOffice)
    if not compilato["pdf"]:
        raise ErroreUtente(compilato["avviso_pdf"] or "PDF non disponibile: installa LibreOffice per stampare.")
    with arc.scrittura() as s:
        salvati = servizio.salva_documenti(s, arc.cfg, u.come_attore(), preventivo_id, prep, compilato)
    d = next(x for x in salvati if x.formato == "pdf")
    return {"documento_id": d.documento_id, "nome_file": d.nome_file, "motivo": "generato", "generato": True,
            "segnaposto_vuoti": compilato["mancanti"]}


@router.get("/preventivi/{preventivo_id}/email")
def bozza_email(preventivo_id: int, _u: UtenteCorrente = Depends(richiede("preventivi.invia")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        p = servizio.preventivo_o_404(s, preventivo_id)
        cfg_posta = posta.ImpostazioniPosta(arc.cfg.cartella_dati, p.ambito)  # C15: la posta dell'attività del preventivo
        bozza = servizio.bozza_email(s, preventivo_id, cfg_posta.leggi().get("copia_ufficio", ""))
        if p.stato == "creato":
            d = servizio.pdf_approvato(s, p)
            allegato = {"nome_file": d.nome_file, "approvato": True, "approvato_da": d.approvato_da} if d else None
        else:
            pronto = servizio.pdf_da_stampare(s, preventivo_id)
            allegato = {"nome_file": pronto["nome_file"], "approvato": True, "inviato": True} if pronto else None
    return bozza | {"posta": cfg_posta.pubbliche(), "pdf_disponibile": pdf.disponibile(arc.cfg.libreoffice), "allegato": allegato,
                    "stato": p.stato}


@router.post("/preventivi/{preventivo_id}/email")
def invia_email(preventivo_id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("preventivi.invia")), arc: Archivio = Depends(archivio)) -> dict:
    """Invia il PDF APPROVATO (D80; già inviato: il PDF dell'invio) e registra l'invio; il preventivo «creato» diventa «inviato»."""
    a, cc = posta.dividi_indirizzi(dati.get("a")), posta.dividi_indirizzi(dati.get("cc"))
    if not a:
        raise ErroreUtente("Scrivi almeno un destinatario.")
    oggetto, testo = str(dati.get("oggetto") or "").strip()[:300], str(dati.get("testo") or "")
    if not oggetto:
        raise ErroreUtente("Scrivi l'oggetto dell'email.")
    with arc.lettura() as s:
        p = servizio.preventivo_o_404(s, preventivo_id)
        cfg_posta = posta.ImpostazioniPosta(arc.cfg.cartella_dati, p.ambito).leggi()  # C15
        if p.stato in ("annullato", "sostituito"):
            raise ErroreUtente(f"Il preventivo è «{STATI[p.stato]}»: non si invia.")
        prep, allegato = None, None
        if p.stato == "creato":  # D80: si invia solo il PDF approvato (presa visione) con i dati attuali
            d = servizio.pdf_approvato(s, p)
            if d is None:
                raise ErroreUtente("Prima di inviare apri l'«Anteprima», controlla il documento e approvalo: si invia solo il PDF approvato.", 409)
            _doc, contenuto = servizio.documento_preventivo(s, arc.cfg, preventivo_id, d.documento_id)
            allegato = (d.nome_file, contenuto, d.documento_id)
        else:  # già inviato: si rimanda il PDF inviato
            pronto = servizio.pdf_da_stampare(s, preventivo_id)
            if pronto is not None:
                _doc, contenuto = servizio.documento_preventivo(s, arc.cfg, preventivo_id, pronto["documento_id"])
                allegato = (pronto["nome_file"], contenuto, pronto["documento_id"])
            else:  # archivi precedenti alla 0.7.0 senza PDF dell'invio
                prep = servizio.prepara_documento(s, arc.cfg, preventivo_id)
        versione_invio = p.versione
    if allegato is None:
        compilato = servizio.compila_documento(prep, True, arc.cfg.libreoffice)
        if not compilato["pdf"]:
            raise ErroreUtente(compilato["avviso_pdf"] or "PDF non disponibile: il preventivo si invia in PDF.")
        allegato = (prep["nome_pdf"], compilato["pdf"], None)
    msg = posta.componi(cfg_posta, a, cc, oggetto, testo, [(allegato[0], allegato[1], "application/pdf")])
    esito = posta.invia(cfg_posta, msg)  # fuori dal lucchetto delle scritture
    with arc.scrittura() as s:
        if allegato[2] is None:
            salvati = servizio.salva_documenti(s, arc.cfg, u.come_attore(), preventivo_id, prep, compilato)
            allegati = [d.documento_id for d in salvati if d.formato == "pdf"]
        else:
            allegati = [allegato[2]]
        p = servizio.registra_invio(s, u.come_attore(), preventivo_id, versione_invio, a, cc, oggetto, testo, allegati, esito)
        return servizio.preventivo_json(s, p) | {"esito": esito}


# ---------------------------------------------------------------- impostazioni email (fuori dal database: posta.json)


@router.get("/impostazioni/posta")
def leggi_posta(attivita: str = "DPR", _u: UtenteCorrente = Depends(richiede("sistema.impostazioni")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        testi = servizio.testi_email(s)
    return {"posta": posta.ImpostazioniPosta(arc.cfg.cartella_dati, attivita).pubbliche(), "testi": testi,
            "campi": [{"campo": c, "descrizione": d} for c, d in servizio.CAMPI_EMAIL],
            "pdf_disponibile": pdf.disponibile(arc.cfg.libreoffice), "libreoffice": pdf.trova(arc.cfg.libreoffice) or ""}


@router.put("/impostazioni/posta")
def salva_posta(dati: dict = Body(...), attivita: str = "DPR", u: UtenteCorrente = Depends(richiede("sistema.impostazioni")),
                arc: Archivio = Depends(archivio)) -> dict:
    pubbliche = posta.ImpostazioniPosta(arc.cfg.cartella_dati, attivita).salva(dati)
    with arc.scrittura() as s:
        from ..registro import servizio as registro

        registro.scrivi(s, utente=u.come_attore(), azione="impostazioni.posta", oggetto_tipo="impostazione", oggetto_id="posta",
                        descrizione=f"Modificate le impostazioni del server di posta {pubbliche['nome_attivita']} ({pubbliche['server']}:{pubbliche['porta']}, mittente {pubbliche['mittente']})"
                                    + (" con nuova password" if dati.get("password") else ""))
    return pubbliche


@router.put("/impostazioni/testi-preventivi")
def salva_testi(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede("sistema.impostazioni")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return servizio.salva_testi_email(s, u.come_attore(), dati)


@router.post("/impostazioni/posta/prova")
def prova_posta(dati: dict = Body(...), attivita: str = "DPR", u: UtenteCorrente = Depends(richiede("sistema.impostazioni")),
                arc: Archivio = Depends(archivio)) -> dict:
    cfg_posta = posta.ImpostazioniPosta(arc.cfg.cartella_dati, attivita).leggi()
    a = posta.dividi_indirizzi(dati.get("a") or cfg_posta.get("copia_ufficio"))
    msg = posta.componi(cfg_posta, a, [], "Prova di invio da NEXUS", f"Email di prova inviata da {u.nome} da NEXUS.", [])
    return {"esito": posta.invia(cfg_posta, msg)}


# ---------------------------------------------------------------- modelli Word


@router.get("/modelli")
def elenco_modelli(u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> list[dict]:
    if not (u.puo("sistema.modelli") or u.puo(VEDERE)):
        raise PermessoNegato()
    with arc.lettura() as s:
        q = select(ModelloDocumento, Documento).join(Documento, ModelloDocumento.documento_id == Documento.id).order_by(
            ModelloDocumento.tipo, ModelloDocumento.in_uso.desc(), ModelloDocumento.id.desc())
        usati = modelli.gia_usati(s)
        return [modelli.modello_json(m, d, usati) for m, d in s.execute(q)]


@router.post("/modelli")
async def carica_modello(file: UploadFile = File(...), tipo: str = Form("preventivo"), codice: str = Form(""), revisione: str = Form(""),
                         descrizione: str = Form(""), in_uso: bool = Form(False), u: UtenteCorrente = Depends(richiede("sistema.modelli")),
                         arc: Archivio = Depends(archivio)) -> dict:
    contenuto = await file.read(25 * 1024 * 1024 + 1)
    with arc.scrittura() as s:
        m = modelli.carica(s, arc.cfg, u.come_attore(), {"tipo": tipo, "codice": codice, "revisione": revisione, "descrizione": descrizione,
                                                         "in_uso": in_uso}, contenuto, file.filename or "modello.docx")
        return modelli.modello_json(m)


@router.post("/modelli/{modello_id}/in-uso")
def modello_in_uso(modello_id: int, u: UtenteCorrente = Depends(richiede("sistema.modelli")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        return modelli.modello_json(modelli.metti_in_uso(s, u.come_attore(), modello_id))


@router.get("/modelli/{modello_id}/file")
def file_modello(modello_id: int, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> Response:
    if not (u.puo("sistema.modelli") or u.puo(VEDERE)):
        raise PermessoNegato()
    with arc.lettura() as s:
        m = s.get(ModelloDocumento, modello_id)
        if m is None:
            raise ErroreUtente("Modello non trovato.", 404)
        doc, contenuto = documenti.leggi(s, arc.cfg.cartella_documenti, m.documento_id)
    return _file(contenuto, doc.nome_originale, doc.tipo_mime)
