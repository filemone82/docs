"""Preventivi (decisioni D13–D19, D26, D36, D38, D39; documento 03 § 2.5; piano documento 09).

- Il preventivo è intestato al CLIENTE; le righe possono riguardare impianti di sedi diverse (D39).
- Numero progressivo per anno, codice P_001_26; ogni revisione (D16) è una riga nuova con lo stesso
  numero e revisione +1; la precedente resta congelata con stato «sostituito».
- La riga copia sede, indirizzo, descrizione e tariffa al momento del preventivo: i cambi successivi di
  anagrafica e tariffario non toccano i preventivi già fatti (D11).
- Importi in centesimi; sconto in centesimi di punto (1050 = 10,50%).
"""

from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import Boolean, CheckConstraint, Date, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ...core.db import Base, adesso
from ...core.modelli_comuni import Centesimi, Tracciato

STATI = {  # D13 + «sostituito» per le revisioni superate (D16)
    "creato": "Creato",
    "inviato": "Inviato",
    "accettato_parzialmente": "Accettato parzialmente",
    "accettato_totalmente": "Accettato totalmente",
    "rifiutato": "Rifiutato",
    "annullato": "Annullato",
    "sostituito": "Sostituito da revisione",
}
STATI_RIGA = {"in_attesa": "In attesa", "accettata": "Accettata", "rifiutata": "Rifiutata", "annullata": "Annullata"}
TIPI_VERIFICA = {"periodica": "Periodica", "straordinaria": "Straordinaria"}
ESITI_RIESAME = {"conforme": "Conforme", "non_conforme": "Non conforme"}


def _in(campo: str, valori) -> str:  # noqa: ANN001
    return f"{campo} IN ({', '.join(repr(v) for v in valori)})"


class Preventivo(Base, Tracciato):
    __tablename__ = "preventivi"
    __table_args__ = (
        UniqueConstraint("ambito", "serie", "numero", "revisione", name="uq_preventivi_serie_numero"),
        CheckConstraint("ambito IN ('DPR','DM')", name="ambito"),
        CheckConstraint(_in("stato", STATI), name="stato"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ambito: Mapped[str] = mapped_column(String(8), default="DPR", server_default="DPR", index=True)
    serie: Mapped[str] = mapped_column(String(40), default=lambda ctx: str(ctx.get_current_parameters()["anno"]))
    sede_id: Mapped[int | None] = mapped_column(ForeignKey("sedi.id", ondelete="RESTRICT"), nullable=True)
    anno: Mapped[int] = mapped_column(Integer, index=True)
    numero: Mapped[int] = mapped_column(Integer)
    revisione: Mapped[int] = mapped_column(Integer, default=0)
    codice: Mapped[str] = mapped_column(String(30), index=True)            # P_001_26 (stesso per tutte le revisioni)
    data: Mapped[date] = mapped_column(Date)
    documento_fotografia: Mapped[str] = mapped_column(Text, default="{}", server_default="{}")
    cliente_fotografia: Mapped[str] = mapped_column(Text, default="{}", server_default="{}")
    cliente_id: Mapped[int] = mapped_column(ForeignKey("clienti.id", ondelete="RESTRICT"), index=True)
    commerciale_id: Mapped[int | None] = mapped_column(ForeignKey("commerciali.id", ondelete="RESTRICT"), nullable=True)
    modalita_pagamento: Mapped[str] = mapped_column(String(200), default="")    # proposta dal cliente, modificabile
    termine_esecuzione: Mapped[str] = mapped_column(String(300), default="")    # proposto dal cliente, modificabile
    stato: Mapped[str] = mapped_column(String(30), default="creato", index=True)
    inviato_il: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    evidenza_accettazione: Mapped[str] = mapped_column(Text, default="", server_default="")
    rif_ordine: Mapped[str] = mapped_column(String(120), default="")           # D36
    # R138 (0.16): dati per la fattura elettronica come la linguetta «Fattura» di Garda (tipo doc., n°, data, CIG, CUP,
    # commessa/convenzione), JSON con lo stesso formato dei documenti collegati della fattura; passano da soli in fattura.
    documenti_collegati: Mapped[str] = mapped_column(Text, default="[]", server_default="[]")
    data_ordine: Mapped[date | None] = mapped_column(Date, nullable=True)
    motivo_annullamento: Mapped[str] = mapped_column(String(500), default="")
    revisione_di_id: Mapped[int | None] = mapped_column(ForeignKey("preventivi.id", ondelete="RESTRICT"), nullable=True)
    note: Mapped[str] = mapped_column(Text, default="")
    lic_gest: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")
    prezzo_licenza: Mapped[int] = mapped_column(Centesimi, default=0, server_default="0")
    totale_standard: Mapped[int] = mapped_column(Centesimi, default=0)
    totale: Mapped[int] = mapped_column(Centesimi, default=0)                    # somma delle tariffe applicate (D26)

    righe: Mapped[list["RigaPreventivo"]] = relationship(back_populates="preventivo", cascade="all, delete-orphan",
                                                         order_by="RigaPreventivo.ordine")


class RigaPreventivo(Base):
    __tablename__ = "preventivi_righe"
    __table_args__ = (
        CheckConstraint(_in("stato", STATI_RIGA), name="stato"),
        CheckConstraint("impianto_id IS NULL OR asset_id IS NULL", name="bene_unico"),
        CheckConstraint(_in("tipo_verifica", TIPI_VERIFICA), name="tipo_verifica"),
        CheckConstraint("sconto >= 0 AND sconto <= 10000", name="sconto"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    preventivo_id: Mapped[int] = mapped_column(ForeignKey("preventivi.id", ondelete="CASCADE"), index=True)
    ordine: Mapped[int] = mapped_column(Integer, default=0)
    # 0.4.0: righe senza impianto (trasferta, sopralluogo a vuoto, duplicato, «a corpo»)
    impianto_id: Mapped[int | None] = mapped_column(ForeignKey("impianti.id", ondelete="RESTRICT"), index=True, nullable=True)
    # 0.4.0: voce del tariffario scelta a mano (a ore, a scelta, fissa); vuota = calcolo automatico dall'impianto
    asset_id: Mapped[int | None] = mapped_column(ForeignKey("asset.id", ondelete="RESTRICT"), nullable=True, index=True)
    tipo_verifica_dm: Mapped[str] = mapped_column(String(2), default="", server_default="")
    tipo_verifica_gvr: Mapped[str] = mapped_column(String(30), default="", server_default="")
    asset_fotografia: Mapped[str] = mapped_column(Text, default="{}", server_default="{}")
    voce_id: Mapped[int | None] = mapped_column(ForeignKey("tariffe_voci.id", ondelete="RESTRICT"), nullable=True)
    quantita: Mapped[float | None] = mapped_column(Float, nullable=True)       # ore, oppure numero della voce scelta
    tipo_verifica: Mapped[str] = mapped_column(String(20), default="periodica")
    # Copie per la stampa (com'erano il giorno del preventivo)
    sede_nome: Mapped[str] = mapped_column(String(300), default="")
    sede_indirizzo: Mapped[str] = mapped_column(String(200), default="")
    sede_comune: Mapped[str] = mapped_column(String(160), default="")
    tipologia: Mapped[str] = mapped_column(String(80), default="")
    descrizione: Mapped[str] = mapped_column(String(200), default="")         # es. «30 kW», «3 aste; gabbia da 101 a 350 m²»
    tariffa_standard: Mapped[int] = mapped_column(Centesimi, default=0)
    dettaglio_tariffa: Mapped[str] = mapped_column(Text, default="[]")         # JSON: voci del tariffario usate
    sconto: Mapped[int] = mapped_column(Integer, default=0)
    tariffa_applicata: Mapped[int] = mapped_column(Centesimi, default=0)
    stato: Mapped[str] = mapped_column(String(20), default="in_attesa", index=True)
    stato_il: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    stato_da: Mapped[str] = mapped_column(String(120), default="")
    note: Mapped[str] = mapped_column(String(500), default="")

    preventivo: Mapped[Preventivo] = relationship(back_populates="righe")


class RevocaRiga(Base):
    """R124 (0.12.8): revoca dell'accettazione di una riga, con motivo. Lo storico non si sovrascrive."""

    __tablename__ = "preventivi_righe_revoche"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    riga_id: Mapped[int] = mapped_column(ForeignKey("preventivi_righe.id", ondelete="CASCADE"), index=True)
    preventivo_id: Mapped[int] = mapped_column(ForeignKey("preventivi.id", ondelete="CASCADE"), index=True)
    motivo: Mapped[str] = mapped_column(Text)
    stato_prima: Mapped[str] = mapped_column(String(20))
    verifica_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    incarico_dm_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    revocata_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    revocata_da: Mapped[str] = mapped_column(String(120), default="")


class Riesame(Base):
    """Riesame del contratto ISO/IEC 17020 (D17, D24): dopo l'accettazione/ordine, prima degli incarichi."""

    __tablename__ = "preventivi_riesami"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    preventivo_id: Mapped[int] = mapped_column(ForeignKey("preventivi.id", ondelete="RESTRICT"), index=True)
    esito: Mapped[str] = mapped_column(String(20))
    requisiti_chiari: Mapped[bool] = mapped_column(Boolean, default=False)
    competenza_strumenti: Mapped[bool] = mapped_column(Boolean, default=False)
    imparzialita: Mapped[bool] = mapped_column(Boolean, default=False)
    tempi: Mapped[bool] = mapped_column(Boolean, default=False)
    note: Mapped[str] = mapped_column(Text, default="")
    eseguito_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    eseguito_da: Mapped[str] = mapped_column(String(120), default="")


class DocumentoPreventivo(Base):
    """Word e PDF generati per un preventivo (con il modello usato)."""

    __tablename__ = "preventivi_documenti"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    preventivo_id: Mapped[int] = mapped_column(ForeignKey("preventivi.id", ondelete="RESTRICT"), index=True)
    formato: Mapped[str] = mapped_column(String(10))                            # docx | pdf
    documento_id: Mapped[int] = mapped_column(ForeignKey("documenti.id", ondelete="RESTRICT"))
    modello_id: Mapped[int | None] = mapped_column(ForeignKey("modelli_documento.id", ondelete="RESTRICT"), nullable=True)
    nome_file: Mapped[str] = mapped_column(String(255))
    versione_preventivo: Mapped[int | None] = mapped_column(Integer, nullable=True)  # per riusarlo in stampa se nulla è cambiato (D58)
    # D60: versione ritoccata a mano in Word e ricaricata (Word + PDF salvato da Word): diventa quella ufficiale
    ritoccato: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")
    creato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    creato_da: Mapped[str] = mapped_column(String(120), default="")
    # 0.7.0 (D80), come i verbali di VerbalizzAI: Word e PDF della stessa preparazione hanno lo stesso «gruppo»;
    # «impronta_dati» = impronta dei dati stampati nel documento (cliente, righe, importi…): se i dati cambiano il documento
    # non vale più; si invia solo il PDF APPROVATO (presa visione) dell'ultima preparazione con i dati attuali.
    gruppo: Mapped[str] = mapped_column(String(32), default="", server_default="", index=True)
    impronta_dati: Mapped[str] = mapped_column(String(64), default="", server_default="")
    approvato_il: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    approvato_da: Mapped[str] = mapped_column(String(120), default="", server_default="")


class InvioPreventivo(Base):
    """Ogni invio email del preventivo, con destinatari, testo e allegati (evidenza dell'invio)."""

    __tablename__ = "preventivi_invii"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    preventivo_id: Mapped[int] = mapped_column(ForeignKey("preventivi.id", ondelete="RESTRICT"), index=True)
    destinatari: Mapped[str] = mapped_column(String(1000))
    copia: Mapped[str] = mapped_column(String(1000), default="")
    oggetto: Mapped[str] = mapped_column(String(300))
    testo: Mapped[str] = mapped_column(Text)
    allegati: Mapped[str] = mapped_column(Text, default="[]")                   # JSON: id dei documenti
    esito: Mapped[str] = mapped_column(String(300), default="")
    inviato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    inviato_da: Mapped[str] = mapped_column(String(120), default="")


class AllegatoPreventivo(Base):
    """R138 (0.16, Federico 12/10/2026, 17:19): file dell'accettazione o dell'ordine del cliente (preventivo controfirmato,
    ordine, email in PDF). Restano nell'archivio documenti con impronta; non si cancellano: si tolgono (restano nello storico)."""

    __tablename__ = "preventivi_allegati"
    __table_args__ = (CheckConstraint("tipo IN ('accettazione','ordine','email','altro')", name="tipo"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    preventivo_id: Mapped[int] = mapped_column(ForeignKey("preventivi.id", ondelete="RESTRICT"), index=True)
    documento_id: Mapped[int] = mapped_column(ForeignKey("documenti.id", ondelete="RESTRICT"))
    tipo: Mapped[str] = mapped_column(String(20), default="accettazione")
    nome_file: Mapped[str] = mapped_column(String(255))
    descrizione: Mapped[str] = mapped_column(String(300), default="")
    rimosso: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")
    rimosso_il: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    rimosso_da: Mapped[str] = mapped_column(String(120), default="", server_default="")
    creato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    creato_da: Mapped[str] = mapped_column(String(120), default="")
