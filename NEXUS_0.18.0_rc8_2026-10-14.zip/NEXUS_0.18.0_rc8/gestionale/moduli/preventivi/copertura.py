"""Una sola prestazione periodica ancora da completare per impianto.

La data del preventivo non identifica il ciclo: può essere retrodatata e può
coincidere con quella della verifica precedente. Conta la verifica collegata.
"""

from sqlalchemy import and_, select

from ...core.errori import ErroreUtente
from ..verifiche.modelli import Verifica
from .modelli import Preventivo, RigaPreventivo


def condizione_copertura(impianto_id):
    completata = (
        select(Verifica.id)
        .where(
            Verifica.riga_id == RigaPreventivo.id,
            Verifica.stato.in_(("eseguita", "riesaminata")),
        )
        .correlate(RigaPreventivo)
        .exists()
    )
    return and_(
        RigaPreventivo.impianto_id == impianto_id,
        RigaPreventivo.tipo_verifica == "periodica",
        Preventivo.stato.notin_(("annullato", "sostituito")),
        RigaPreventivo.stato != "annullata",
        ~completata,
    )


def controlla(s, impianto_id, tipo_verifica, preventivo_id=None):
    if impianto_id is None or tipo_verifica != "periodica":
        return
    q = (
        select(Preventivo)
        .join(RigaPreventivo, RigaPreventivo.preventivo_id == Preventivo.id)
        .where(condizione_copertura(impianto_id))
        .order_by(Preventivo.id)
        .limit(1)
    )
    if preventivo_id is not None:
        q = q.where(Preventivo.id != preventivo_id)
    p = s.scalar(q)
    if p is not None:
        etichetta = p.codice + (f" rev. {p.revisione}" if p.revisione else "")
        raise ErroreUtente(
            f"L'impianto n. {impianto_id} ha già la verifica periodica nel "
            f"preventivo {etichetta}. Apri quel preventivo; per sostituirlo "
            "annulla prima la prestazione o il preventivo. Non viene creata "
            "una seconda attività sulla stessa scadenza.",
            409,
        )


def controlla_preventivo(s, p):
    if p.ambito == "DM":
        from ..dm.servizio import controlla_preventivo as controlla_dm
        return controlla_dm(s, p)
    for r in p.righe:
        if r.stato != "annullata":
            controlla(s, r.impianto_id, r.tipo_verifica, p.id)
