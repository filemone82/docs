"""Destinazioni dei documenti (rc8, punto 5 · Federico, 14/10/2026).

Richiesta: salvataggio dei documenti definitivi in ubicazioni separate e modificabili da Gestione › Configurazione, una per
categoria: verbali DPR, verbali DM, schede tecniche DM, PDF delle fatture di cortesia, XML delle fatture elettroniche.
Decisione D2: «sul server in futuro su spazio condiviso, per il momento mi interessa che crei la funzione in configurazione
per stabilire la destinazione. nexus girerà su vps linux ubuntu».

Quindi:
- ogni destinazione è un percorso **del server** su cui gira NEXUS (o di uno spazio condiviso montato lì), non del PC di chi
  usa il browser: per i PC resta lo scaricamento dal browser;
- i percorsi stanno nel database (impostazione `documenti.destinazioni`), con traccia nel registro; il vecchio
  `cartella_verbali_dm` di config.json resta il valore iniziale dei verbali DM finché non se ne salva uno qui;
- la copia automatica oggi esiste per i verbali e le schede tecniche DM (moduli/dm/documenti.py::salva_in_cartella), che
  ora leggono queste destinazioni: le schede DM vanno nella loro destinazione se impostata, altrimenti con i verbali DM
  (come prima della rc8). Per verbali DPR, PDF e XML delle fatture la destinazione si imposta ma la copia automatica non è
  ancora attiva (nomi dei file da concordare);
- la copia nella cartella è operativa: non sostituisce l'archivio dei documenti del gestionale né il suo backup.
"""

from __future__ import annotations

import json
import os
import uuid
from pathlib import Path, PurePosixPath, PureWindowsPath
from typing import Any

from sqlalchemy.orm import Session

from ...core.errori import ErroreUtente

CHIAVE = "documenti.destinazioni"
CATEGORIE = {
    "verbali_dpr": {"nome": "Verbali DPR", "copia_attiva": False},
    "verbali_dm": {"nome": "Verbali DM", "copia_attiva": True},
    "schede_dm": {"nome": "Schede tecniche DM", "copia_attiva": True},
    "fatture_pdf": {"nome": "PDF delle fatture di cortesia", "copia_attiva": False},
    "fatture_xml": {"nome": "XML delle fatture elettroniche", "copia_attiva": False},
}


def _salvate(s: Session) -> dict:
    from ..impostazioni.modelli import Impostazione
    x = s.get(Impostazione, CHIAVE)
    return json.loads(x.valore) if x else {}


def percorso(s: Session, cfg: Any, categoria: str) -> str:
    """Percorso impostato per la categoria ("" se nessuno). Verbali DM: config.json come valore iniziale (prima della rc8)."""
    valore = str(_salvate(s).get(categoria) or "").strip()
    if not valore and categoria == "verbali_dm":
        valore = str(getattr(cfg, "cartella_verbali_dm", "") or "").strip()
    return valore


def elenco(s: Session, cfg: Any) -> list[dict]:
    salvate = _salvate(s)
    out = []
    for codice, c in CATEGORIE.items():
        da_config = codice == "verbali_dm" and not str(salvate.get(codice) or "").strip() and bool(percorso(s, cfg, codice))
        out.append({"categoria": codice, "nome": c["nome"], "percorso": percorso(s, cfg, codice), "copia_attiva": c["copia_attiva"],
                    "da_config": da_config})
    return out


def _normalizza(testo: Any) -> str:
    t = str(testo or "").strip()
    if not t:
        return ""
    if len(t) > 500:
        raise ErroreUtente("Percorso troppo lungo (massimo 500 caratteri).")
    if "\x00" in t:
        raise ErroreUtente("Percorso non valido.")
    if not (PurePosixPath(t).is_absolute() or PureWindowsPath(t).is_absolute()):
        raise ErroreUtente(f"«{t}»: scrivi un percorso completo del server (per esempio /srv/nexus/documenti/verbali_dpr).")
    return t


def salva(s: Session, attore: Any, dati: dict) -> dict:
    from ..impostazioni.modelli import Impostazione
    from ..registro import servizio as registro

    prima = _salvate(s)
    nuove = dict(prima)
    for codice in CATEGORIE:
        if codice in dati:
            nuove[codice] = _normalizza(dati[codice])
    x = s.get(Impostazione, CHIAVE)
    if x is None:
        s.add(Impostazione(chiave=CHIAVE, valore=json.dumps(nuove, ensure_ascii=False), aggiornata_da=getattr(attore, "id", None)))
    else:
        x.valore, x.aggiornata_da = json.dumps(nuove, ensure_ascii=False), getattr(attore, "id", None)
    registro.scrivi(s, utente=attore, azione="impostazioni.destinazioni_documenti", oggetto_tipo="impostazione", oggetto_id=CHIAVE,
                    descrizione="Modificate le destinazioni dei documenti", dettagli={"modifiche": registro.differenze(prima, nuove)})
    return nuove


def prova(testo: Any) -> dict:
    """Controlla dal server che la cartella esista e che NEXUS possa scriverci (crea e cancella un file di prova)."""
    t = _normalizza(testo)
    if not t:
        raise ErroreUtente("Scrivi il percorso da provare.")
    p = Path(t)
    if not p.exists():
        return {"esito": "manca", "messaggio": f"La cartella {t} non esiste sul server: va creata (o montata) prima di usarla."}
    if not p.is_dir():
        return {"esito": "errore", "messaggio": f"{t} esiste ma non è una cartella."}
    prova_file = p / f".nexus_prova_{uuid.uuid4().hex}"
    try:
        prova_file.write_bytes(b"prova di scrittura NEXUS")
        prova_file.unlink()
    except OSError as e:
        return {"esito": "errore", "messaggio": f"NEXUS non può scrivere in {t}: {e.strerror or e}. Controlla i permessi dell'utente con cui gira il programma."}
    libero = None
    try:
        st = os.statvfs(p)
        libero = st.f_bavail * st.f_frsize
    except (AttributeError, OSError):
        pass
    msg = f"Cartella raggiungibile e scrivibile dal server: {t}."
    if libero is not None:
        msg += f" Spazio libero: {libero / 1024 ** 3:.1f} GB."
    return {"esito": "ok", "messaggio": msg}
