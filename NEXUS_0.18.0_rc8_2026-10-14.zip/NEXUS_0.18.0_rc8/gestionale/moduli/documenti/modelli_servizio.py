"""Modelli Word come documenti controllati: caricamento, «in uso / superato», modello in uso per tipo."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...core import word
from ...core.date import iso_locale
from ...core.errori import ErroreUtente, NonTrovato
from ..registro import servizio as registro
from . import servizio as documenti
from .modelli import Documento, ModelloDocumento

TIPI = {"preventivo": "Preventivo DPR", "preventivo_dm": "Preventivo DM",
        "verbale_dm_gvr": "Verbale DM GVR", "verbale_dm_scsp": "Verbale DM SC/SP",
        "preventivo_iec": "Preventivo I&C"}  # C16 (0.16): modello del preventivo I&C (il modulo I&C arriverà)
# Segnaposto che un modello di preventivo deve contenere per essere utilizzabile
OBBLIGATORI = {"preventivo": ["p.anno_numero_preventivo", "cli.rag_soc", "#r", "/r"], "preventivo_dm": ["p.anno_numero_preventivo", "cli.rag_soc", "sede.nome_sede", "#gvr", "/gvr", "#scsp", "/scsp"]}
for tipo in ('verbale_dm_gvr', 'verbale_dm_scsp'):
    OBBLIGATORI[tipo] = ['v.rp_codice', 'a.matr_informale', 'v.data_rilascio_verbale']
OBBLIGATORI['verbale_dm_gvr'] += ['#c', '/c']
CARTELLA_MODELLI = Path(__file__).resolve().parents[2] / "dati" / "modelli"
DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"


def gia_usati(s: Session) -> set[int]:
    """Modelli che sono stati in uso almeno una volta (dal registro): fuori uso sono «superati», gli altri «da approvare»."""
    from ..registro.modelli import RegistroOperazione
    q = select(RegistroOperazione.oggetto_id).where(RegistroOperazione.azione == "modello.in_uso", RegistroOperazione.oggetto_tipo == "modello")
    usati = {int(x) for x in s.execute(q).scalars() if str(x).isdigit()}
    # quelli caricati prima del modello in uso del loro tipo l'hanno preceduto (anche i modelli iniziali, messi in uso senza registro)
    for tipo, id_in_uso in s.execute(select(ModelloDocumento.tipo, ModelloDocumento.id).where(ModelloDocumento.in_uso.is_(True))):
        usati |= set(s.execute(select(ModelloDocumento.id).where(ModelloDocumento.tipo == tipo, ModelloDocumento.id < id_in_uso)).scalars())
    return usati


def modello_json(m: ModelloDocumento, doc: Documento | None = None, usati: set[int] | None = None) -> dict:
    stato = "in uso" if m.in_uso else ("superato" if usati is None or m.id in usati else "da approvare")
    return {"id": m.id, "tipo": m.tipo, "tipo_testo": TIPI.get(m.tipo, m.tipo), "codice": m.codice, "revisione": m.revisione,
            "descrizione": m.descrizione, "in_uso": m.in_uso, "stato": stato, "documento_id": m.documento_id,
            "nome_file": doc.nome_originale if doc else "", "caricato_il": iso_locale(m.caricato_il), "caricato_da": m.caricato_da}


def carica(s: Session, cfg: Any, attore: Any, dati: dict, contenuto: bytes, nome_file: str) -> ModelloDocumento:
    tipo = str(dati.get("tipo") or "")
    if tipo not in TIPI:
        raise ErroreUtente("Scegli il tipo di modello.")
    codice, revisione = str(dati.get("codice") or "").strip()[:60], str(dati.get("revisione") or "").strip()[:20]
    if not codice or not revisione:
        raise ErroreUtente("Scrivi codice e revisione del modello (es. M01-RG01_dpr, 03).")
    trovati = word.segnaposto(contenuto)
    mancanti = [x for x in OBBLIGATORI.get(tipo, []) if x not in trovati]
    if mancanti:
        raise ErroreUtente("Nel modello mancano i segnaposto: " + ", ".join("{{" + x + "}}" for x in mancanti) + ".")
    if s.execute(select(ModelloDocumento).where(ModelloDocumento.tipo == tipo, ModelloDocumento.codice == codice,
                                                ModelloDocumento.revisione == revisione)).scalar():
        raise ErroreUtente(f"Il modello {codice} rev. {revisione} c'è già: cambia il numero di revisione.")
    doc = documenti.salva(s, cfg.cartella_documenti, contenuto, nome_file, DOCX, getattr(attore, "id", None), f"Modello {codice} rev. {revisione}")
    m = ModelloDocumento(tipo=tipo, codice=codice, revisione=revisione, descrizione=str(dati.get("descrizione") or "")[:2000],
                         documento_id=doc.id, in_uso=False, caricato_da=getattr(attore, "nome", "") or "Sistema")
    s.add(m)
    s.flush()
    registro.scrivi(s, utente=attore, azione="modello.carica", oggetto_tipo="modello", oggetto_id=m.id,
                    descrizione=f"Caricato il modello {codice} rev. {revisione} ({TIPI[tipo]})", dettagli={"segnaposto": trovati, "impronta": doc.impronta})
    if dati.get("in_uso"):
        metti_in_uso(s, attore, m.id)
    return m


def metti_in_uso(s: Session, attore: Any, modello_id: int) -> ModelloDocumento:
    m = s.get(ModelloDocumento, modello_id)
    if m is None:
        raise NonTrovato("Modello non trovato.")
    for altro in s.execute(select(ModelloDocumento).where(ModelloDocumento.tipo == m.tipo, ModelloDocumento.in_uso.is_(True))).scalars():
        altro.in_uso = False
    m.in_uso = True
    s.flush()
    registro.scrivi(s, utente=attore, azione="modello.in_uso", oggetto_tipo="modello", oggetto_id=m.id,
                    descrizione=f"In uso il modello {m.codice} rev. {m.revisione}; i precedenti dello stesso tipo sono superati")
    return m


def in_uso(s: Session, tipo: str) -> ModelloDocumento:
    m = s.execute(select(ModelloDocumento).where(ModelloDocumento.tipo == tipo, ModelloDocumento.in_uso.is_(True))).scalar()
    if m is None:
        raise ErroreUtente(f"Nessun modello Word in uso per «{TIPI.get(tipo, tipo)}»: caricalo in Sistema › Modelli Word.")
    return m


REV04 = "M01-RG01_dpr_Offerta_rev.04.docx"
DESCR_REV04 = ("Offerta per verifica periodica D.P.R. 462/01. Come la rev. 03 con impaginazione sicura per LibreOffice (D60): colonne della "
               "tabella ribilanciate, righe che non si spezzano, riquadro «Si prega di inviare l'accettazione» nella tabella delle firme, "
               "condizioni da pagina nuova, codice e revisione in calce. Da approvare.")


def prepara(s: Session, cfg: Any) -> None:
    """Modello dell'offerta M01-RG01_dpr rev. 04 (0.4.0). Su un archivio nuovo è il modello in uso; su un archivio che usa
    ancora la rev. 03 fornita dal programma (mai approvata) la rev. 04 la sostituisce. I modelli caricati dagli utenti non si toccano."""
    file = CARTELLA_MODELLI / REV04
    esiste = s.execute(select(ModelloDocumento).where(ModelloDocumento.tipo == "preventivo", ModelloDocumento.codice == "M01-RG01_dpr",
                                                      ModelloDocumento.revisione == "04")).scalar()
    if esiste:
        return
    attuale = s.execute(select(ModelloDocumento).where(ModelloDocumento.tipo == "preventivo", ModelloDocumento.in_uso.is_(True))).scalar()
    doc = documenti.salva(s, cfg.cartella_documenti, file.read_bytes(), file.name, DOCX, None, "Modello M01-RG01_dpr rev. 04")
    m = ModelloDocumento(tipo="preventivo", codice="M01-RG01_dpr", revisione="04", documento_id=doc.id, in_uso=False, caricato_da="Sistema",
                         descrizione=DESCR_REV04)
    s.add(m)
    s.flush()
    registro.scrivi(s, utente=None, azione="modello.carica", oggetto_tipo="modello", oggetto_id=m.id,
                    descrizione="Caricato dal programma il modello M01-RG01_dpr rev. 04 (da approvare)", dettagli={"impronta": doc.impronta})
    if attuale is None or (attuale.caricato_da == "Sistema" and attuale.codice == "M01-RG01_dpr" and attuale.revisione in ("03",)):
        metti_in_uso(s, None, m.id)


def prepara_dm(s: Session, cfg: Any) -> None:
    if s.scalar(select(ModelloDocumento.id).where(ModelloDocumento.tipo == "preventivo_dm", ModelloDocumento.codice == "Garda-DM", ModelloDocumento.revisione == "backup-2026-10-07")):
        return
    if s.scalar(select(ModelloDocumento.id).where(ModelloDocumento.tipo == "preventivo_dm", ModelloDocumento.in_uso.is_(True))):
        return
    contenuto = (CARTELLA_MODELLI / "Preventivo_DM_Garda.docx").read_bytes()
    carica(s, cfg, None, {"tipo": "preventivo_dm", "codice": "Garda-DM", "revisione": "backup-2026-10-07", "descrizione": "Modello originale adsrl Garda ricevuto nel backup; da collaudare."}, contenuto, "Preventivo_DM_Garda.docx")
    m = s.scalars(select(ModelloDocumento).where(ModelloDocumento.tipo == "preventivo_dm").order_by(ModelloDocumento.id.desc())).first()
    metti_in_uso(s, None, m.id)


def prepara_verbali_dm(s: Session, cfg: Any) -> None:
    for tipo, nome in (('verbale_dm_gvr', 'verbale-gvr.docx'), ('verbale_dm_scsp', 'verbale-sc-sp.docx')):
        if s.scalar(select(ModelloDocumento.id).where(ModelloDocumento.tipo == tipo)):
            continue
        carica(s, cfg, None, {'tipo': tipo, 'codice': 'Garda-' + tipo, 'revisione': 'backup-2026-10-07',
            'descrizione': 'Modello originale adsrl Garda; contenuto del backup conservato.', 'in_uso': True},
            (CARTELLA_MODELLI / nome).read_bytes(), nome)
    # R136 (0.16): rev. 03 con la grafica di VerbalizzAI (M01–M03); stesso contenuto della rev. 02. Entra «da approvare»
    # (non in uso): si mette in uso da Gestione › Configurazione › Modelli dopo l'approvazione dei PDF di prova.
    for tipo, codice, nome in (('verbale_dm_gvr', 'M14-PO01_dm', 'verbale-gvr_rev03.docx'), ('verbale_dm_scsp', 'M11-PO01_dm', 'verbale-sc-sp_rev03.docx')):
        if s.scalar(select(ModelloDocumento.id).where(ModelloDocumento.tipo == tipo, ModelloDocumento.codice == codice,
                                                      ModelloDocumento.revisione == '03')) or not (CARTELLA_MODELLI / nome).exists():
            continue
        carica(s, cfg, None, {'tipo': tipo, 'codice': codice, 'revisione': '03',
            'descrizione': 'Rev. 03: grafica allineata ai modelli M01–M03 di VerbalizzAI (Calibri, colori AD, sezioni e tabelle), '
                           'contenuto invariato rispetto alla rev. 02. Da approvare prima di metterla in uso (R136).'},
            (CARTELLA_MODELLI / nome).read_bytes(), nome)
