"""Archivio documenti (decisione D32): i file stanno in una cartella, nominati per impronta SHA-256."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ...core.db import Base, adesso


class Documento(Base):
    __tablename__ = "documenti"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    impronta: Mapped[str] = mapped_column(String(64), unique=True)
    nome_originale: Mapped[str] = mapped_column(String(255))
    tipo_mime: Mapped[str] = mapped_column(String(120), default="application/octet-stream")
    dimensione: Mapped[int] = mapped_column(Integer)
    descrizione: Mapped[str] = mapped_column(Text, default="")
    caricato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    caricato_da: Mapped[int | None] = mapped_column(ForeignKey("utenti.id", ondelete="RESTRICT"), nullable=True)


class ModelloDocumento(Base):
    """Modelli Word come documenti controllati (convenzione 03 § 3): codice, revisione, in uso / superato.

    Ogni documento generato registra quale modello ha usato. Un solo modello in uso per tipo."""

    __tablename__ = "modelli_documento"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    tipo: Mapped[str] = mapped_column(String(30), index=True)          # «preventivo» (poi verbale, fattura…)
    codice: Mapped[str] = mapped_column(String(60))                    # es. M01-RG01_dpr
    revisione: Mapped[str] = mapped_column(String(20))                 # es. 03
    descrizione: Mapped[str] = mapped_column(Text, default="")
    documento_id: Mapped[int] = mapped_column(ForeignKey("documenti.id", ondelete="RESTRICT"))
    in_uso: Mapped[bool] = mapped_column(Boolean, default=False)
    caricato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    caricato_da: Mapped[str] = mapped_column(String(120), default="")
