"""Destinazioni dei documenti (rc8, punto 5): lettura, salvataggio e prova dal server. Vedi destinazioni.py."""

from __future__ import annotations

from fastapi import APIRouter, Body, Depends

from ...core.db import Archivio
from ...web.dipendenze import archivio, richiede
from ..utenti.accesso import UtenteCorrente
from . import destinazioni

router = APIRouter(prefix="/api/impostazioni/destinazioni")
PERMESSO = "sistema.impostazioni"


@router.get("")
def leggi(_u: UtenteCorrente = Depends(richiede(PERMESSO)), arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        return {"destinazioni": destinazioni.elenco(s, arc.cfg)}


@router.put("")
def salva(dati: dict = Body(...), u: UtenteCorrente = Depends(richiede(PERMESSO)), arc: Archivio = Depends(archivio)) -> dict:
    with arc.scrittura() as s:
        destinazioni.salva(s, u.come_attore(), dati)
    with arc.lettura() as s:
        return {"destinazioni": destinazioni.elenco(s, arc.cfg)}


@router.post("/prova")
def prova(dati: dict = Body(...), _u: UtenteCorrente = Depends(richiede(PERMESSO))) -> dict:
    return destinazioni.prova(dati.get("percorso"))
