"""Archivio documenti (D32).

Ogni file è salvato in `documenti/ab/cd/<impronta>` dove <impronta> è lo SHA-256 del contenuto:
- lo stesso file caricato due volte occupa spazio una volta sola;
- se un file venisse alterato, il controllo di integrità lo scoprirebbe (l'impronta non torna più);
- i file non si modificano mai: una nuova versione è un nuovo documento.
"""

from __future__ import annotations

import hashlib
import os
import stat
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...core.errori import NonTrovato
from .modelli import Documento


def percorso_file(cartella: Path, impronta: str) -> Path:
    return cartella / impronta[:2] / impronta[2:4] / impronta


def salva(s: Session, cartella: Path, contenuto: bytes, nome: str, tipo_mime: str = "application/octet-stream",
          utente_id: int | None = None, descrizione: str = "") -> Documento:
    impronta = hashlib.sha256(contenuto).hexdigest()
    esistente = s.execute(select(Documento).where(Documento.impronta == impronta)).scalar()
    destinazione = percorso_file(cartella, impronta)
    if not destinazione.exists():
        destinazione.parent.mkdir(parents=True, exist_ok=True)
        provvisorio = destinazione.with_suffix(".tmp")
        provvisorio.write_bytes(contenuto)
        os.replace(provvisorio, destinazione)  # scrittura atomica: mai file a metà
        os.chmod(destinazione, stat.S_IREAD | stat.S_IRGRP | stat.S_IROTH)  # sola lettura
    if esistente:
        return esistente
    doc = Documento(impronta=impronta, nome_originale=Path(nome).name[:255], tipo_mime=tipo_mime,
                    dimensione=len(contenuto), caricato_da=utente_id, descrizione=descrizione)
    s.add(doc)
    s.flush()
    return doc


def leggi(s: Session, cartella: Path, documento_id: int) -> tuple[Documento, bytes]:
    doc = s.get(Documento, documento_id)
    if doc is None:
        raise NonTrovato("Documento non trovato.")
    file = percorso_file(cartella, doc.impronta)
    if not file.exists():
        raise NonTrovato("Il file del documento manca nella cartella documenti: avvisa l'amministratore (controllo di integrità).")
    contenuto = file.read_bytes()
    if hashlib.sha256(contenuto).hexdigest() != doc.impronta:
        raise NonTrovato("Il file del documento risulta alterato: avvisa l'amministratore (controllo di integrità).")
    return doc, contenuto


def verifica_tutti(s: Session, cartella: Path) -> dict:
    mancanti, alterati, controllati = [], [], 0
    for doc in s.execute(select(Documento)).scalars().yield_per(1000):
        controllati += 1
        file = percorso_file(cartella, doc.impronta)
        if not file.exists():
            mancanti.append(doc.nome_originale)
            continue
        h = hashlib.sha256()
        with file.open("rb") as f:
            for blocco in iter(lambda: f.read(1 << 20), b""):
                h.update(blocco)
        if h.hexdigest() != doc.impronta:
            alterati.append(doc.nome_originale)
    return {"controllati": controllati, "mancanti": mancanti, "alterati": alterati, "integri": not mancanti and not alterati}
