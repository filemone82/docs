"""Impostazioni del programma modificabili da menu (chiave → valore JSON)."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ...core.db import Base, adesso


class Impostazione(Base):
    __tablename__ = "impostazioni"

    chiave: Mapped[str] = mapped_column(String(80), primary_key=True)
    valore: Mapped[str] = mapped_column(Text)  # JSON
    aggiornata_il: Mapped[datetime] = mapped_column(DateTime, default=adesso, onupdate=adesso)
    aggiornata_da: Mapped[int | None] = mapped_column(ForeignKey("utenti.id", ondelete="RESTRICT"), nullable=True)
