"""Backup, verifica, ripristino e controllo di integrità (D32, convenzione 03 § 3).

Un backup è un file .zip che contiene:
- `database.sqlite`: copia coerente del database (fatta con il meccanismo di backup di SQLite);
- `documenti/...`: tutti i documenti dell'archivio;
- `manifest.json`: versione del programma e dello schema, data, tipo e impronta SHA-256 di ogni file.

Prima di ogni ripristino il backup viene VERIFICATO (impronte, integrità del database, versione dello
schema) e si crea comunque un backup «pre_ripristino» dello stato attuale: un ripristino sbagliato si
può sempre annullare.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import sqlite3
import stat
import tempfile
import time
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

from sqlalchemy import delete, text

from ... import VERSIONE
from ...core import migrazioni
from ...core.db import Archivio, adesso
from ...core.errori import ErroreUtente, NonTrovato
from ..documenti import servizio as documenti
from ..registro import servizio as registro
from ..utenti import servizio as utenti
from ..utenti.modelli import Sessione, Utente

TIPI = {"automatico": "Automatico", "manuale": "Manuale", "pre_ripristino": "Prima di un ripristino",
        "pre_aggiornamento": "Prima di un aggiornamento", "pre_importazione": "Prima di un'importazione",
        "caricato": "Caricato da file"}
RE_NOME = re.compile(r"^GestionaleAD_backup_\d{8}_\d{6}_[a-z_]+(_\d+)?\.zip$")
_cache_manifest: dict[tuple[str, float], dict] = {}


def _sha256_file(percorso: Path) -> str:
    h = hashlib.sha256()
    with percorso.open("rb") as f:
        for blocco in iter(lambda: f.read(1 << 20), b""):
            h.update(blocco)
    return h.hexdigest()


def _nome_nuovo(cartella: Path, tipo: str) -> Path:
    base = f"GestionaleAD_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{tipo}"
    p, n = cartella / f"{base}.zip", 2
    while p.exists():
        p, n = cartella / f"{base}_{n}.zip", n + 1
    return p


def percorso_sicuro(archivio: Archivio, nome: str) -> Path:
    if not RE_NOME.match(nome or ""):
        raise NonTrovato("Backup non trovato: il nome del file non è valido.")
    p = archivio.cfg.cartella_backup / nome
    if not p.exists():
        raise NonTrovato("Backup non trovato: forse è stato spostato o cancellato dalla cartella.")
    return p


# ---------------------------------------------------------------- creazione


def crea(archivio: Archivio, tipo: str, attore: utenti.Attore | None = None, registra: bool = True) -> dict:
    """Crea un backup completo. Durante la copia le scritture sono sospese (pochi secondi).

    `registra=False` solo prima delle migrazioni all'avvio, quando lo schema non è ancora aggiornato."""
    if archivio.cfg.postgresql:
        from . import postgresql
        return postgresql.crea(archivio, tipo, attore, registra)
    cfg = archivio.cfg
    destinazione = _nome_nuovo(cfg.cartella_backup, tipo)
    with archivio.esclusivo():
        with tempfile.TemporaryDirectory(dir=cfg.cartella_temporanea) as tmp:
            copia_db = Path(tmp) / "database.sqlite"
            # Ogni connessione va chiusa: su Windows un file aperto non si può cancellare
            # (altrimenti la cartella temporanea non si elimina e il backup fallisce).
            sorgente = sqlite3.connect(cfg.percorso_database)
            dest = sqlite3.connect(copia_db)
            try:
                sorgente.backup(dest)
                revisione = dest.execute("SELECT version_num FROM alembic_version").fetchone()
            finally:
                dest.close()
                sorgente.close()
            file_manifest = [{"percorso": "database.sqlite", "sha256": _sha256_file(copia_db), "dimensione": copia_db.stat().st_size}]
            provvisorio = destinazione.with_suffix(".tmp")
            with zipfile.ZipFile(provvisorio, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as z:
                z.write(copia_db, "database.sqlite")
                verbali = getattr(archivio, "verbali", None)  # archivio dei verbali (VerbalizzAI, 0.5.0): copia completa con i documenti
                if verbali is not None:
                    copia_vz = Path(tmp) / "verbali.adbackup.zip"
                    verbali.export_backup(copia_vz, include_documents=True)
                    z.write(copia_vz, "verbali/verbali.adbackup.zip")
                    file_manifest.append({"percorso": "verbali/verbali.adbackup.zip", "sha256": _sha256_file(copia_vz), "dimensione": copia_vz.stat().st_size})
                for f in sorted(cfg.cartella_documenti.rglob("*")):
                    if f.is_file() and not f.name.endswith(".tmp"):
                        rel = "documenti/" + f.relative_to(cfg.cartella_documenti).as_posix()
                        z.write(f, rel)
                        file_manifest.append({"percorso": rel, "sha256": _sha256_file(f), "dimensione": f.stat().st_size})
                manifest = {
                    "programma": "NEXUS",
                    "versione_programma": VERSIONE,
                    "revisione_schema": revisione[0] if revisione else None,
                    "creato_il": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                    "tipo": tipo,
                    "file": file_manifest,
                }
                z.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=1))
            os.replace(provvisorio, destinazione)
        if registra:
            with archivio.scrittura() as s:
                registro.scrivi(s, utente=attore, azione="backup.crea", oggetto_tipo="backup", oggetto_id=destinazione.name,
                                descrizione=f"Creato il backup {destinazione.name} ({TIPI.get(tipo, tipo)})")
    risultato = info(destinazione)
    if tipo == "automatico":
        pulisci_automatici(archivio, tieni=destinazione)
    return risultato


def _automatici(archivio: Archivio) -> list[Path]:
    """Backup automatici dal più vecchio al più recente (per data del file, non per nome)."""
    return sorted(archivio.cfg.cartella_backup.glob("GestionaleAD_backup_*_automatico*.zip"), key=lambda p: (p.stat().st_mtime_ns, p.name))


def pulisci_automatici(archivio: Archivio, tieni: Path | None = None) -> None:
    """Conserva solo gli ultimi N backup automatici; gli altri tipi non vengono mai cancellati dal programma."""
    automatici = [p for p in _automatici(archivio) if p != tieni]
    da_tenere = archivio.cfg.backup_automatici_da_conservare - (1 if tieni else 0)
    for vecchio in automatici[: max(0, len(automatici) - da_tenere)]:
        vecchio.unlink(missing_ok=True)


def ultimo_automatico(archivio: Archivio) -> datetime | None:
    automatici = _automatici(archivio)
    if not automatici:
        return None
    return datetime.fromtimestamp(automatici[-1].stat().st_mtime, tz=timezone.utc).replace(tzinfo=None)


# ---------------------------------------------------------------- elenco


def _leggi_manifest(p: Path) -> dict:
    chiave = (str(p), p.stat().st_mtime)
    if chiave not in _cache_manifest:
        try:
            with zipfile.ZipFile(p) as z:
                _cache_manifest[chiave] = json.loads(z.read("manifest.json"))
        except (zipfile.BadZipFile, KeyError, json.JSONDecodeError):
            _cache_manifest[chiave] = {}
    return _cache_manifest[chiave]


def info(p: Path) -> dict:
    m = _leggi_manifest(p)
    try:
        creato = datetime.fromisoformat(m["creato_il"]).astimezone(timezone.utc).replace(tzinfo=None)
    except (KeyError, ValueError):
        creato = datetime.fromtimestamp(p.stat().st_mtime, tz=timezone.utc).replace(tzinfo=None)
    return {
        "nome": p.name,
        "creato_il": creato,
        "tipo": TIPI.get(m.get("tipo", ""), m.get("tipo", "sconosciuto")),
        "dimensione_mb": round(p.stat().st_size / 1_048_576, 2),
        "versione_programma": m.get("versione_programma", "?"),
        "documenti": max(0, len(m.get("file", [])) - 1),
        "leggibile": bool(m),
    }


def elenco(archivio: Archivio) -> list[dict]:
    return [info(p) for p in sorted(archivio.cfg.cartella_backup.glob("GestionaleAD_backup_*.zip"), reverse=True)]


# ---------------------------------------------------------------- verifica


def verifica_file(archivio: Archivio, p: Path) -> dict:
    """Controlla un backup senza toccare i dati attuali."""
    m = _leggi_manifest(p)
    if m.get("backend") == "postgresql":
        from . import postgresql
        return postgresql.verifica_file(archivio, p)
    if archivio.cfg.postgresql:
        return {"valido": False, "problemi": ["Il backup SQLite richiede la procedura di trasferimento, non il ripristino PostgreSQL."]}
    problemi: list[str] = []
    try:
        with zipfile.ZipFile(p) as z:
            nomi = set(z.namelist())
            if "manifest.json" not in nomi or "database.sqlite" not in nomi:
                return {"valido": False, "problemi": ["Il file non è un backup di NEXUS (Gestionale AD) (manca il manifest o il database)."]}
            m = json.loads(z.read("manifest.json"))
            for voce in m.get("file", []):
                if voce["percorso"] not in nomi:
                    problemi.append(f"Manca il file {voce['percorso']}.")
                    continue
                h = hashlib.sha256()
                with z.open(voce["percorso"]) as f:
                    for blocco in iter(lambda: f.read(1 << 20), b""):
                        h.update(blocco)
                if h.hexdigest() != voce["sha256"]:
                    problemi.append(f"Il file {voce['percorso']} è alterato o danneggiato.")
            with tempfile.TemporaryDirectory(dir=archivio.cfg.cartella_temporanea) as tmp:
                z.extract("database.sqlite", tmp)
                conn = sqlite3.connect(Path(tmp) / "database.sqlite")
                try:
                    esito = conn.execute("PRAGMA integrity_check").fetchone()[0]
                    if esito != "ok":
                        problemi.append(f"Il database nel backup è danneggiato ({esito}).")
                    revisione = conn.execute("SELECT version_num FROM alembic_version").fetchone()
                except sqlite3.DatabaseError as e:  # file così rovinato che SQLite non riesce nemmeno a leggerlo
                    problemi.append(f"Il database nel backup è danneggiato e non si può leggere ({e}).")
                    revisione = None
                finally:
                    conn.close()
    except zipfile.BadZipFile:
        return {"valido": False, "problemi": ["Il file è danneggiato o non è un archivio .zip."]}
    revisione = revisione[0] if revisione else None
    if revisione not in migrazioni.revisioni_note():
        problemi.append("Il backup è stato creato da una versione più recente del programma: aggiorna il programma prima di ripristinarlo.")
    return {"valido": not problemi, "problemi": problemi, "versione_programma": m.get("versione_programma"),
            "revisione_schema": revisione, "file_controllati": len(m.get("file", []))}


def verifica(archivio: Archivio, nome: str, attore: utenti.Attore) -> dict:
    p = percorso_sicuro(archivio, nome)
    esito = verifica_file(archivio, p)
    with archivio.scrittura() as s:
        registro.scrivi(s, utente=attore, azione="backup.verifica", oggetto_tipo="backup", oggetto_id=nome,
                        descrizione=f"Verificato il backup {nome}: {'valido' if esito['valido'] else 'NON valido'}",
                        dettagli={"problemi": esito["problemi"]})
    return esito


def carica(archivio: Archivio, contenuto: bytes, nome_originale: str, attore: utenti.Attore) -> dict:
    destinazione = _nome_nuovo(archivio.cfg.cartella_backup, "caricato")
    provvisorio = destinazione.with_suffix(".tmp")
    provvisorio.write_bytes(contenuto)
    esito = verifica_file(archivio, provvisorio)
    if not esito["valido"]:
        provvisorio.unlink(missing_ok=True)
        raise ErroreUtente("Il file caricato non è un backup valido: " + " ".join(esito["problemi"]))
    os.replace(provvisorio, destinazione)
    with archivio.scrittura() as s:
        registro.scrivi(s, utente=attore, azione="backup.carica", oggetto_tipo="backup", oggetto_id=destinazione.name,
                        descrizione=f"Caricato il backup «{nome_originale}» come {destinazione.name}")
    return info(destinazione)


# ---------------------------------------------------------------- ripristino


def _rimuovi_cartella(p: Path) -> None:
    def _sblocca(funzione, percorso, _eccezione):  # noqa: ANN001
        os.chmod(percorso, stat.S_IWRITE)  # i documenti sono in sola lettura
        funzione(percorso)

    if p.exists():
        shutil.rmtree(p, onexc=_sblocca)


def _sposta(sorgente: Path, destinazione: Path, tentativi: int = 20) -> None:
    """Sposta un file o una cartella; su Windows un file appena chiuso può restare bloccato qualche istante."""
    for n in range(tentativi):
        try:
            os.replace(sorgente, destinazione) if sorgente.is_file() else shutil.move(str(sorgente), destinazione)
            return
        except PermissionError:
            if n == tentativi - 1:
                raise
            time.sleep(0.25)


def ripristina(archivio: Archivio, nome: str, attore: utenti.Attore) -> dict:
    if archivio.cfg.postgresql:
        from . import postgresql
        return postgresql.ripristina(archivio, nome, attore)
    p = percorso_sicuro(archivio, nome)
    esito = verifica_file(archivio, p)
    if not esito["valido"]:
        raise ErroreUtente("Il backup non ha superato la verifica, ripristino annullato: " + " ".join(esito["problemi"]))
    cfg = archivio.cfg
    timbro = datetime.now().strftime("%Y%m%d_%H%M%S")
    db = cfg.percorso_database
    db_sostituito = db.with_name(f"database_sostituito_{timbro}.sqlite")
    doc_sostituiti = cfg.cartella_dati / f"documenti_sostituiti_{timbro}"
    with archivio.esclusivo():
        sicurezza = crea(archivio, "pre_ripristino", attore)
        archivio.motore.dispose()
        with tempfile.TemporaryDirectory(dir=cfg.cartella_temporanea) as tmp:
            with zipfile.ZipFile(p) as z:
                z.extractall(tmp)
            nuovi_doc = Path(tmp) / "documenti"
            nuovi_doc.mkdir(exist_ok=True)
            # Prima si mettono da parte i dati attuali, poi si mettono al loro posto quelli del backup.
            # Se qualcosa va storto si rimette tutto com'era: non si resta mai a metà.
            spostati: list[tuple[Path, Path]] = []
            try:
                for suffisso in ("", "-wal", "-shm"):
                    attuale = Path(str(db) + suffisso)
                    if attuale.exists():
                        _sposta(attuale, Path(str(db_sostituito) + suffisso))
                        spostati.append((Path(str(db_sostituito) + suffisso), attuale))
                if cfg.cartella_documenti.exists():
                    _sposta(cfg.cartella_documenti, doc_sostituiti)
                    spostati.append((doc_sostituiti, cfg.cartella_documenti))
                _sposta(Path(tmp) / "database.sqlite", db)
                _sposta(nuovi_doc, cfg.cartella_documenti)
            except OSError:
                db.unlink(missing_ok=True)
                for da, a in reversed(spostati):
                    _sposta(da, a)
                archivio.riapri()
                raise ErroreUtente("Ripristino non riuscito: il database è in uso (forse da un'altra finestra o da un antivirus). "
                                   "Nulla è stato cambiato: riprova tra qualche istante.") from None
        archivio.riapri()
        migrazioni.aggiorna(archivio.motore)  # se il backup è di una versione precedente
        verbali = getattr(archivio, "verbali", None)
        if verbali is not None:
            with zipfile.ZipFile(p) as z:
                vz = z.read("verbali/verbali.adbackup.zip") if "verbali/verbali.adbackup.zip" in z.namelist() else None
            if vz is not None:  # backup dalla 0.5.0 in poi; quelli precedenti non hanno verbali e lasciano l'archivio dei verbali com'è
                verbali.set_actor(attore.nome)
                verbali.restore(vz)
        with archivio.scrittura() as s:
            utenti.inizializza(s)
            s.execute(delete(Sessione))  # tutti devono accedere di nuovo
            # L'utente che ripristina potrebbe non esistere nel backup: lo si cerca per id e nome.
            presente = s.get(Utente, attore.id) if attore.id else None
            chi = attore if presente is not None and presente.nome == attore.nome else utenti.Attore(id=None, nome=f"{attore.nome} (da prima del ripristino)")
            registro.scrivi(s, utente=chi, azione="backup.ripristino", oggetto_tipo="backup", oggetto_id=nome,
                            descrizione=f"Ripristinato il backup {nome}. Lo stato precedente è salvato in {sicurezza['nome']}.",
                            dettagli={"backup_di_sicurezza": sicurezza["nome"]})
    # I dati sostituiti sono già nel backup di sicurezza: si possono togliere.
    for suffisso in ("", "-wal", "-shm"):
        Path(str(db_sostituito) + suffisso).unlink(missing_ok=True)
    _rimuovi_cartella(doc_sostituiti)
    return {"ripristinato": nome, "backup_di_sicurezza": sicurezza["nome"]}


# ---------------------------------------------------------------- integrità


def controllo_integrita(archivio: Archivio, attore: utenti.Attore | None) -> dict:
    with archivio.lettura() as s:
        if archivio.cfg.postgresql:
            from .postgresql import controllo_logico
            esito_db, chiavi = controllo_logico(s)
        else:
            esito_db = s.execute(text("PRAGMA integrity_check")).scalar()
            chiavi = s.execute(text("PRAGMA foreign_key_check")).fetchall()
        catena = registro.verifica_catena(s)
        docs = documenti.verifica_tutti(s, archivio.cfg.cartella_documenti)
    risultato = {
        "database": {"integro": esito_db == "ok", "dettaglio": esito_db,
                     "ambito_controllo": "logico (non verifica fisica dei file PostgreSQL)" if archivio.cfg.postgresql else "SQLite integrity_check"},
        "collegamenti": {"integri": not chiavi, "problemi": len(chiavi)},
        "registro": catena,
        "documenti": docs,
    }
    risultato["tutto_ok"] = bool(risultato["database"]["integro"] and risultato["collegamenti"]["integri"] and catena["integro"] and docs["integri"])
    with archivio.scrittura() as s:
        registro.scrivi(s, utente=attore, azione="integrita.controllo", oggetto_tipo="sistema",
                        descrizione="Controllo di integrità: " + ("tutto in ordine" if risultato["tutto_ok"] else "PROBLEMI RILEVATI"),
                        dettagli=risultato)
    return risultato


def serve_backup_giornaliero(archivio: Archivio) -> bool:
    ultimo = ultimo_automatico(archivio)
    return ultimo is None or ultimo < adesso() - timedelta(hours=24)

