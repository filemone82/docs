"""Backup e integrità: griglia, crea, scarica, verifica, carica, ripristina, controllo di integrità."""

from __future__ import annotations

from fastapi import APIRouter, Depends, File, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

from ...core.db import Archivio
from ...core.errori import ErroreUtente
from ...core.griglia import Colonna, Griglia, registra
from ...web.dipendenze import archivio, richiede
from ..registro import servizio as registro
from ..utenti.accesso import UtenteCorrente
from . import servizio

router = APIRouter(prefix="/api/backup")
MASSIMA_DIMENSIONE_CARICAMENTO = 4 * 1024 ** 3  # 4 GB

registra(Griglia(
    codice="backup",
    titolo="Backup",
    permesso="sistema.backup",
    chiave="nome",
    righe=lambda arc, _u: servizio.elenco(arc),
    ordine_predefinito=[("creato_il", "desc")],
    colonne=[
        Colonna("creato_il", "Creato il", "dataora", larghezza=150),
        Colonna("tipo", "Tipo", "elenco", larghezza=190, opzioni=tuple(servizio.TIPI.values())),
        Colonna("nome", "File", "testo", larghezza=360),
        Colonna("dimensione_mb", "Dimensione (MB)", "numero", larghezza=130, somma=True),
        Colonna("documenti", "Documenti", "numero", larghezza=110),
        Colonna("versione_programma", "Versione programma", "testo", larghezza=140),
    ],
))


class Conferma(BaseModel):
    conferma: str = ""


@router.post("")
def crea(u: UtenteCorrente = Depends(richiede("sistema.backup")), arc: Archivio = Depends(archivio)) -> dict:
    risultato = servizio.crea(arc, "manuale", u.come_attore())
    return risultato | {"creato_il": risultato["creato_il"].isoformat()}


@router.get("/{nome}/scarica")
def scarica(nome: str, u: UtenteCorrente = Depends(richiede("sistema.backup")), arc: Archivio = Depends(archivio)) -> FileResponse:
    percorso = servizio.percorso_sicuro(arc, nome)
    with arc.scrittura() as s:
        registro.scrivi(s, utente=u.come_attore(), azione="backup.scarica", oggetto_tipo="backup", oggetto_id=nome,
                        descrizione=f"Scaricato il backup {nome}")
    return FileResponse(percorso, filename=nome, media_type="application/zip")


@router.post("/{nome}/verifica")
def verifica(nome: str, u: UtenteCorrente = Depends(richiede("sistema.backup")), arc: Archivio = Depends(archivio)) -> dict:
    return servizio.verifica(arc, nome, u.come_attore())


@router.post("/{nome}/ripristina")
def ripristina(nome: str, dati: Conferma, u: UtenteCorrente = Depends(richiede("sistema.backup")), arc: Archivio = Depends(archivio)) -> dict:
    if dati.conferma.strip().upper() != "RIPRISTINA":
        raise ErroreUtente("Per confermare il ripristino scrivi RIPRISTINA nel campo di conferma.")
    return servizio.ripristina(arc, nome, u.come_attore())


@router.post("/carica")
async def carica(file: UploadFile = File(...), u: UtenteCorrente = Depends(richiede("sistema.backup")), arc: Archivio = Depends(archivio)) -> dict:
    if not (file.filename or "").lower().endswith(".zip"):
        raise ErroreUtente("Scegli un file .zip creato da NEXUS (Gestionale AD).")
    contenuto = await file.read(MASSIMA_DIMENSIONE_CARICAMENTO + 1)
    if len(contenuto) > MASSIMA_DIMENSIONE_CARICAMENTO:
        raise ErroreUtente("Il file è troppo grande (oltre 4 GB).")
    risultato = servizio.carica(arc, contenuto, file.filename or "backup.zip", u.come_attore())
    return risultato | {"creato_il": risultato["creato_il"].isoformat()}


@router.post("/integrita")
def integrita(u: UtenteCorrente = Depends(richiede("sistema.backup")), arc: Archivio = Depends(archivio)) -> dict:
    return servizio.controllo_integrita(arc, u.come_attore())
