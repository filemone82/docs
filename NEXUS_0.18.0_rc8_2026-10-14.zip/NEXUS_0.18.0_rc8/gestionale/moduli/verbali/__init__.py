"""Verbali: VerbalizzAI dentro il gestionale (fase 5, versione 0.5.0; decisione D67)."""
