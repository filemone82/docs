"""Pagine e interfaccia dei verbali (VerbalizzAI dentro il gestionale, D67).

- GET  /verbali                 → la pagina di VerbalizzAI (index.html) con i percorsi spostati sotto /verbali/
- GET  /verbali/static/{file}   → file della pagina (app.js con «/api/» → «/verbali/api/»)
- GET/POST /verbali/api/{...}   → funzioni di VerbalizzAI, tramite il ponte, con l'utente del gestionale
- POST /api/verifiche/{id}/verbale/bozza → crea (o riapre) la bozza del verbale di una verifica registrata
Dopo l'emissione (anteprima → firma ed emissione) e «Annulla verbale» la verifica del gestionale si aggiorna (servizio.dopo_emissione / dopo_annullamento).
"""

from __future__ import annotations

import json
import logging
import mimetypes
import re
from functools import lru_cache
from contextlib import nullcontext
from pathlib import Path

from fastapi import APIRouter, Body, Depends, File, Request, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, Response

from ...core.db import Archivio
from ...core.errori import ErroreUtente, NonAutenticato, PermessoNegato
from ...web.dipendenze import COOKIE_SESSIONE, archivio, controlla_origine, richiede, utente
from ..utenti import accesso
from ..utenti.accesso import UtenteCorrente
from . import importazione, ponte, scheda, servizio

log = logging.getLogger(__name__)
router = APIRouter()
STATICI = Path(__file__).resolve().parents[2] / "terzi" / "verbalizzai" / "static"
NASCOSTI = ("users", "backups")
# Dopo questi percorsi di VerbalizzAI la verifica del gestionale si aggiorna. Dalla 0.3.31 l'emissione normale è
# «review/issue» (anteprima PDF → firma ed emissione); «inspection/issue» resta per compatibilità.
EMISSIONE = ("review/issue", "inspection/issue")
ANNULLAMENTO = ("inspection/annul",)  # voci del menu di VerbalizzAI che nel gestionale stanno in Sistema
# R122 (0.12.7): dopo questi percorsi la scheda tecnica dell'impianto (unica, quella di VerbalizzAI) può essere cambiata:
# la copia del gestionale si riallinea. Dopo ripristini e riletture si riallineano tutte.
SCHEDA = ("plant/state/adopt", "plant/state/save", "inspection/annul", "inspection/annul-restore", "import/commit", "plant/update")
SCHEDA_TUTTE = ("reread", "backup/restore", "backup/restore-local")


def _sposta(testo: str) -> str:
    return testo.replace("/api/", "/verbali/api/").replace("/static/", "/verbali/static/")


@lru_cache(maxsize=1)
def _indice() -> str:
    t = _sposta((STATICI / "index.html").read_text("utf-8"))
    for vista in NASCOSTI:
        t = re.sub(r'<button data-view="' + vista + r'"[^>]*>.*?</button>', "", t, flags=re.S)
    t = t.replace('<div class="sidebar-bottom">',
                  '<div class="sidebar-bottom"><a class="text-button torna-gestionale" href="/verifiche">← Torna al gestionale</a>', 1)
    t = t.replace("</head>", '<link rel="stylesheet" href="/static/css/ponte_verbali.css"></head>', 1)  # anagrafica unica: pulsanti nascosti
    # rc8 (D3): la pagina del verbale fa parte di NEXUS: barra di NEXUS in alto, menu di VerbalizzAI nascosto
    # (ponte_verbali.css), striscia con la verifica di provenienza (ponte_verbali.js). Segnaposto riempiti a ogni richiesta.
    t = t.replace("</head>", '<meta name="csrf" content="__CSRF_NEXUS__"><link rel="stylesheet" href="/static/css/barra.css"></head>', 1)
    t = t.replace('<body><div class="shell">',
                  '<body class="in-nexus"><!--BARRA-NEXUS--><div id="nexus-contesto" class="nexus-contesto" hidden></div><div class="shell">', 1)
    # ponte.js prima di app.js: apre il verbale indicato nell'indirizzo (?apri=…)
    return t.replace('<script src="/verbali/static/app.js" defer></script>',
                     '<script src="/static/js/barra.js"></script><script src="/static/js/ponte_verbali.js"></script>'
                     '<script src="/verbali/static/app.js" defer></script>', 1)


@lru_cache(maxsize=1)
def _app_js() -> bytes:
    t = _sposta((STATICI / "app.js").read_text("utf-8"))
    # Password e uscita sono quelle del gestionale
    t = t.replace('<button class="text-button" data-action="password">Cambia password</button> · ', "")
    t = t.replace(' · <button class="text-button" data-action="logout">Esci</button>', "")
    return t.encode("utf-8")


def _verbali(request: Request):  # noqa: ANN202
    return request.app.state.verbali


@router.get("/verbali", response_class=HTMLResponse)
def pagina(request: Request):  # noqa: ANN201
    arc = request.app.state.archivio
    try:
        u = accesso.leggi_sessione(arc, request.cookies.get(COOKIE_SESSIONE))
    except NonAutenticato:
        return RedirectResponse("/accesso", status_code=303)
    if u.cambio_password_richiesto:
        return RedirectResponse("/profilo", status_code=303)
    if not u.puo("verifiche.vedere_proprie", "DPR"):
        return HTMLResponse("Permesso negato.", status_code=403)
    from html import escape
    from ...web.pagine import barra_html
    pagina_html = _indice().replace("<!--BARRA-NEXUS-->", barra_html(u), 1).replace("__CSRF_NEXUS__", escape(u.csrf, quote=True), 1)
    return HTMLResponse(pagina_html, headers={"Cache-Control": "no-store"})


@router.get("/verbali/static/{nome}")
def statico(nome: str) -> Response:
    if nome == "app.js":
        return Response(_app_js(), media_type="text/javascript; charset=utf-8", headers={"Cache-Control": "no-cache"})
    f = (STATICI / nome).resolve()
    if not f.is_relative_to(STATICI) or not f.is_file():
        raise ErroreUtente("File non trovato.", 404)
    return Response(f.read_bytes(), media_type=mimetypes.guess_type(f.name)[0] or "application/octet-stream")


def _utente_verbali(request: Request) -> UtenteCorrente:
    """Utente del gestionale; il codice anti-contraffazione lo controlla il ponte (VerbalizzAI lo manda come X-AD-Token)."""
    u = accesso.leggi_sessione(request.app.state.archivio, request.cookies.get(COOKIE_SESSIONE))
    if request.method != "GET":
        controlla_origine(request)
    if u.cambio_password_richiesto:
        raise ErroreUtente("Devi cambiare la password provvisoria prima di continuare (pagina «Il mio profilo»).", 403)
    if not u.puo("verifiche.vedere_proprie", "DPR"):
        raise PermessoNegato()
    return u


@router.api_route("/verbali/api/{percorso:path}", methods=["GET", "POST"])
async def api_verbali(percorso: str, request: Request) -> Response:
    try:
        u = _utente_verbali(request)
    except NonAutenticato:
        return Response(json.dumps({"error": "Sessione scaduta: accedere di nuovo dal gestionale."}), 401, media_type="application/json")
    corpo = await request.body() if request.method == "POST" else b""
    return await _in_thread(_api_verbali_coordinata, percorso, request, u, corpo)


def _api_verbali_coordinata(percorso, request, u, corpo):
    # Un solo thread e lo stesso gate durante operazione VerbalizzAI e callback.
    # Il backup non può inserirsi fra i due archivi. Resta il recupero esplicito
    # già previsto quando la callback fallisce dopo un'emissione riuscita.
    arc = request.app.state.archivio
    with arc.esclusivo() if request.method == "POST" else nullcontext():
        return _api_verbali_sincrona(percorso, request, u, corpo)


def _api_verbali_sincrona(percorso, request, u, corpo):
    app = request.app
    vz = "/api/" + percorso + (("?" + request.url.query) if request.url.query else "")
    if request.method == "POST" and (percorso in EMISSIONE or percorso == "inspection/send"):
        iid = json.loads(corpo).get("id")
        from ..verifiche.modelli import Verifica
        from sqlalchemy import select
        with app.state.archivio.lettura() as s:
            v = s.scalar(select(Verifica).where(Verifica.verbale_id == iid))
            if v is None:
                raise ErroreUtente("Verbale non collegato a un incarico DPR.")
            if percorso in EMISSIONE and (v.stato != "registrata" or not v.indipendenza):
                raise ErroreUtente("Emissione consentita su incarico registrato con indipendenza del tecnico.")
            if percorso == "inspection/send" and (v.stato != "riesaminata" or v.riesame_esito != "conforme"):
                raise ErroreUtente("Invio differito: occorre prima il riesame conforme del verbale corrente.")
            if percorso == "inspection/send":
                from ..verifiche.modelli import DocumentoVerifica
                from ..documenti.modelli import Documento
                pdf_sha = s.scalar(select(Documento.impronta).join(DocumentoVerifica).where(
                    DocumentoVerifica.verifica_id == v.id, DocumentoVerifica.in_uso.is_(True), DocumentoVerifica.formato == "pdf"))
                item = app.state.verbali.get(iid)
                exp = app.state.verbali.get(item["data"].get("issued_export_id")) if item else None
                if not exp or exp["data"].get("pdf_sha") != pdf_sha:
                    raise ErroreUtente("Il PDF è cambiato dopo il riesame: acquisisci il documento aggiornato e ripeti il riesame.")
    if request.method == "POST" and percorso == "draft/save":
        # B2 (rc8): il numero del verbale lo assegna NEXUS e segue la data/il tipo del verbale (cambio d'anno → nuovo numero)
        corpo = servizio.allinea_bozza_in_salvataggio(app.state.archivio, u, corpo)
    if request.method == "POST" and (percorso in EMISSIONE or percorso == "review/preview"):
        iid = json.loads(corpo or b"{}").get("id")
        if iid:
            servizio.controlla_numero_prima_di_emettere(app.state.verbali, app.state.archivio, u, iid)
    srv = ponte.server(app.state.verbali, app.state.posta_verbali)
    intestazioni = {k: v for k, v in request.headers.items() if k.lower() in ("x-ad-token", "content-type")}
    stato, uscita, dati = ponte.esegui(srv, u, u.csrf, request.method, vz, corpo, intestazioni)
    if stato == 200 and request.method == "POST" and percorso in EMISSIONE + ANNULLAMENTO:
        try:
            iid = json.loads(corpo)["id"]
            if percorso in EMISSIONE:
                esito = servizio.dopo_emissione(app.state.verbali, app.state.archivio, u, iid)
                if esito:
                    risposta = json.loads(dati)
                    risposta.setdefault("notes", []).append(f"Verifica n. {esito['verifica_id']} del gestionale: «{esito['stato']}».")
                    dati = json.dumps(risposta, ensure_ascii=False).encode()
            else:
                servizio.dopo_annullamento(app.state.verbali, app.state.archivio, u, iid)
        except ErroreUtente as e:  # il verbale è emesso; la verifica resta da aggiornare a mano (caricando il verbale)
            risposta = json.loads(dati)
            risposta.setdefault("notes", []).append("Verifica del gestionale non aggiornata: " + e.messaggio)
            dati = json.dumps(risposta, ensure_ascii=False).encode()
        except Exception:
            log.exception("Aggiornamento della verifica dopo il verbale non riuscito")
            risposta = json.loads(dati)
            risposta.setdefault("notes", []).append("Verifica del gestionale non aggiornata (errore imprevisto, vedi file di log): caricare il verbale dalla verifica.")
            dati = json.dumps(risposta, ensure_ascii=False).encode()
    if stato == 200 and request.method == "POST" and (percorso in SCHEDA or percorso in SCHEDA_TUTTE):
        try:
            _riallinea_schede(app, u, percorso, corpo, dati)
        except Exception:  # l'operazione di VerbalizzAI è fatta; la copia si riallinea all'apertura dell'impianto
            log.exception("Riallineamento della scheda tecnica dopo %s non riuscito", percorso)
    h = {}
    for k, v in uscita:
        if k.lower() in ("content-type", "content-disposition", "cache-control"):
            h[k] = v
    tipo = h.pop("Content-Type", None) or h.pop("content-type", "application/json")
    return Response(dati, stato, headers=h, media_type=tipo)


def _riallinea_schede(app, u, percorso: str, corpo: bytes, dati: bytes) -> None:
    if percorso in SCHEDA_TUTTE:
        scheda.sincronizza_tutte(app.state.verbali, app.state.archivio, u)
        return

    def leggi(b: bytes) -> object:
        try:
            return json.loads(b or b"{}")
        except ValueError:
            return {}

    for plant_id in scheda.plant_coinvolti(app.state.verbali, leggi(corpo), leggi(dati)):
        scheda.sincronizza_plant(app.state.verbali, app.state.archivio, u, plant_id)


async def _in_thread(f, *a):  # noqa: ANN001, ANN002, ANN202
    from starlette.concurrency import run_in_threadpool

    return await run_in_threadpool(f, *a)


PROSSIMO_PASSO = {"registrata": "anteprima, firma ed emissione del verbale",
                  "eseguita": "riesame del verbale (RT)",
                  "riesaminata": "invio al cliente e fatturazione",
                  "annullata": ""}


@router.get("/api/verbali/{verbale_id}/verifica")
def verifica_del_verbale(verbale_id: str, request: Request, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    """rc8 (D3): la verifica di provenienza di un verbale, per la striscia in alto nella pagina del verbale."""
    from ..verifiche import servizio as verifiche
    from ..verifiche.modelli import STATI

    with arc.lettura() as s:
        try:
            v = servizio._verifica_del_verbale(s, request.app.state.verbali, verbale_id)
        except (KeyError, ValueError):
            v = None
        if v is None or not verifiche.puo_vedere(u, v):
            return {"verifica": None}
        dati = verifiche.verifica_json(s, v)
        return {"verifica": {"id": v.id, "codice_verbale": v.codice_verbale, "stato": v.stato, "stato_testo": STATI.get(v.stato, v.stato),
                             "cliente": dati.get("cliente", ""), "sede": dati.get("sede", ""), "corrente": v.verbale_id == verbale_id,
                             "prossimo": PROSSIMO_PASSO.get(v.stato, ""), "url": f"/verifiche?apri={v.id}"}}


# ---------------------------------------------------------------- rc8 (punto 3): firma DPR nella scheda del tecnico
# Federico, 12/10/2026: «ogni utente abbia una firma dpr e una firma dm, il gestionale utilizza quella corretta».
# Una sola esperienza NEXUS: nella scheda del tecnico (profilo, Gestione › Firme dei verificatori) «Firma DPR» accanto
# a «Firma DM». La firma DPR resta nell'archivio dei verbali, dove la cerca il motore all'emissione: si usano le sue
# funzioni (set_signature, remove_signature, signature_image), senza modificarlo (R111). I verbali già emessi conservano
# la firma che contengono: una firma nuova vale per le emissioni successive.
def _utente_firma(s, u: UtenteCorrente, utente_id: int, gestire: bool):
    from ...core.errori import NonTrovato
    from ..utenti.modelli import Utente
    from ..verifiche import servizio as verifiche

    x = s.get(Utente, utente_id)
    if x is None:
        raise NonTrovato("Utente non trovato.")
    proprio = u.id == utente_id
    permesso = "firme.gestire" if gestire else "firme.vedere"
    if not proprio and not (u.puo(permesso, "DPR") or u.puo("sistema.utenti")):
        raise PermessoNegato("Puoi " + ("aggiornare" if gestire else "vedere") + " soltanto la tua firma DPR.")
    tecnico_dpr = any(v["id"] == x.id for v in verifiche.verificatori(s, "DPR"))
    return x, tecnico_dpr


@router.get("/api/firme/dpr/{utente_id}")
def firma_dpr_stato(utente_id: int, request: Request, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        x, tecnico_dpr = _utente_firma(s, u, utente_id, gestire=False)
    r = request.app.state.verbali.signature_record(x.username)
    presente = bool(r and r["data"].get("sha"))
    return {"utente_id": utente_id, "tecnico_dpr": tecnico_dpr, "presente": presente,
            "aggiornata_il": r["data"].get("updated_at", "") if presente else ""}


@router.get("/api/firme/dpr/{utente_id}/immagine")
def firma_dpr_immagine(utente_id: int, request: Request, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> Response:
    from ...core.errori import NonTrovato
    with arc.lettura() as s:
        x, _ = _utente_firma(s, u, utente_id, gestire=False)
    raw = request.app.state.verbali.signature_image(x.username)
    if not raw:
        raise NonTrovato("Firma DPR non caricata.")
    return Response(raw, media_type="image/png" if raw[:4] == b"\x89PNG" else "image/jpeg", headers={"Cache-Control": "no-store"})


@router.post("/api/firme/dpr/{utente_id}")
async def carica_firma_dpr(utente_id: int, request: Request, file: UploadFile = File(...), u: UtenteCorrente = Depends(utente),
                           arc: Archivio = Depends(archivio)) -> dict:
    raw = await file.read()
    return await _in_thread(_salva_firma_dpr, request, u, arc, utente_id, raw, file.filename or "firma.png")


def _salva_firma_dpr(request, u, arc, utente_id, raw, nome):
    from ..registro import servizio as registro
    vz = request.app.state.verbali
    with arc.esclusivo():
        with arc.lettura() as s:
            x, _ = _utente_firma(s, u, utente_id, gestire=True)
        vz.set_actor(u.username)
        try:
            vz.set_signature(x.username, raw, nome)
        except ValueError as e:
            raise ErroreUtente(str(e)) from None
        with arc.scrittura() as s:
            registro.scrivi(s, utente=u.come_attore(), azione="utente.firma_dpr", oggetto_tipo="utente", oggetto_id=utente_id,
                            descrizione="Caricata la firma grafica per i verbali DPR (vale per le emissioni successive)")
    return {"utente_id": utente_id, "presente": True}


@router.delete("/api/firme/dpr/{utente_id}")
def togli_firma_dpr(utente_id: int, request: Request, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    from ..registro import servizio as registro
    vz = request.app.state.verbali
    with arc.esclusivo():
        with arc.lettura() as s:
            x, _ = _utente_firma(s, u, utente_id, gestire=True)
        vz.set_actor(u.username)
        vz.remove_signature(x.username)
        with arc.scrittura() as s:
            registro.scrivi(s, utente=u.come_attore(), azione="utente.firma_dpr", oggetto_tipo="utente", oggetto_id=utente_id,
                            descrizione="Tolta la firma grafica per i verbali DPR")
    return {"utente_id": utente_id, "presente": False}


@router.post("/api/verifiche/{verifica_id}/verbale/bozza")
def bozza(verifica_id: int, request: Request, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    vid = servizio.crea_bozza(request.app.state.verbali, arc, u, verifica_id)
    return {"verbale_id": vid, "url": "/verbali?apri=" + vid}


@router.get("/api/verifiche/{verifica_id}/verbale/precedente")
def verbale_precedente(verifica_id: int, request: Request, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    return {"precedente": servizio.precedente(request.app.state.verbali, arc, u, verifica_id)}


@router.post("/api/verifiche/{verifica_id}/verbale/precedente")
async def carica_verbale_precedente(verifica_id: int, request: Request, file: UploadFile = File(...), u: UtenteCorrente = Depends(utente),
                                    arc: Archivio = Depends(archivio)) -> dict:
    contenuto = await file.read()
    return await _in_thread(servizio.carica_precedente, request.app.state.verbali, arc, u, verifica_id, contenuto, file.filename or "verbale.docx")


# ---------------------------------------------------------------- importazione dell'archivio di VerbalizzAI e collegamenti
IMPORTA = "anagrafica.importa"


@router.post("/api/verbali/importa")
async def importa(request: Request, file: UploadFile = File(...), u: UtenteCorrente = Depends(richiede(IMPORTA)),
                  arc: Archivio = Depends(archivio)) -> dict:
    contenuto = await file.read(2 * 1024 ** 3 + 1)
    if len(contenuto) > 2 * 1024 ** 3:
        raise ErroreUtente("File troppo grande (massimo 2 GB).")
    return await _in_thread(importazione.importa_backup, request.app.state.verbali, arc, u.come_attore(), contenuto)


@router.get("/api/verbali/collegamenti")
def collegamenti(request: Request, _u: UtenteCorrente = Depends(richiede(IMPORTA)), arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        return importazione.proposte(request.app.state.verbali, s)


@router.post("/api/verbali/collegamenti/proposte")
def collega_proposte(request: Request, u: UtenteCorrente = Depends(richiede(IMPORTA)), arc: Archivio = Depends(archivio)) -> dict:
    return importazione.collega_proposte(request.app.state.verbali, arc, u.come_attore())


@router.post("/api/verbali/collegamenti/{plant_id}")
def collega(plant_id: str, request: Request, dati: dict = Body(...), u: UtenteCorrente = Depends(richiede(IMPORTA)),
            arc: Archivio = Depends(archivio)) -> dict:
    if not dati.get("sede_id"):
        raise ErroreUtente("Scegli la sede del gestionale.")
    return importazione.collega(request.app.state.verbali, arc, u.come_attore(), plant_id, int(dati["sede_id"]))


@router.delete("/api/verbali/collegamenti/{plant_id}")
def scollega(plant_id: str, request: Request, u: UtenteCorrente = Depends(richiede(IMPORTA)), arc: Archivio = Depends(archivio)) -> dict:
    importazione.scollega(request.app.state.verbali, arc, u.come_attore(), plant_id)
    return {"ok": True}


@router.get("/verbali-importa", response_class=HTMLResponse)
def pagina_importa(request: Request):  # noqa: ANN201
    from ...web.pagine import _pagina

    return _pagina(request, "verbali_importa.html", "Verbali di VerbalizzAI: importazione e collegamenti", IMPORTA, "verbali_importa.js", "SISTEMA")


@router.post("/api/verbali/riallinea")
def riallinea(u: UtenteCorrente = Depends(richiede("verifiche.riesame", "DPR")), arc: Archivio = Depends(archivio)) -> dict:
    esito = servizio.riallinea_emissioni(arc.verbali, arc, u)
    esito["schede"] = scheda.sincronizza_tutte(arc.verbali, arc, u)  # R122
    return esito


# ---------------------------------------------------------------- R122: scheda tecnica unica dell'impianto


@router.get("/api/impianti/{impianto_id}/scheda-tecnica")
def scheda_tecnica(impianto_id: int, u: UtenteCorrente = Depends(richiede("anagrafica.vedere")), arc: Archivio = Depends(archivio)) -> dict:
    """La scheda tecnica dell'impianto: quella di VerbalizzAI (l'unica), da cui riparte il verbale successivo."""
    return scheda.stato_impianto(arc.verbali, arc, u, impianto_id)


@router.post("/api/impianti/{impianto_id}/scheda-tecnica/apri")
def apri_scheda_tecnica(impianto_id: int, request: Request, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    """Indirizzo della «Scheda impianto» di VerbalizzAI per questo impianto (la collega se manca)."""
    from ..anagrafica.modelli import Impianto
    from ..verifiche.modelli import MODULO_PER_TIPOLOGIA

    controlla_origine(request)
    if not u.puo("verifiche.vedere_proprie", "DPR"):
        raise PermessoNegato()
    with arc.lettura() as s:
        x = s.get(Impianto, impianto_id)
        if x is None:
            raise ErroreUtente("Impianto non trovato.", 404)
        modulo = MODULO_PER_TIPOLOGIA.get(x.tipologia, "M01")
        arc.verbali.set_actor(u.username)
        plant_id = servizio.assicura_plant(arc.verbali, s, impianto_id)
    return {"url": f"/verbali?scheda={plant_id}&modulo={modulo}", "plant_id": plant_id, "modulo": modulo,
            "modifica": u.puo("impianti.stato_tecnico", "DPR")}
