"""Importazione dell'archivio di VerbalizzAI nel gestionale (0.5.0, D67) e collegamento degli impianti.

1. `importa_backup`: il backup completo di VerbalizzAI (.adbackup.zip) diventa l'archivio dei verbali del gestionale
   (solo se questo non ha ancora verbali: l'importazione si fa una volta, al passaggio).
2. `proposte`: per ogni impianto di VerbalizzAI («plant», un indirizzo di un cliente) propone la sede del gestionale:
   - «POD»: il POD scritto nei verbali è quello di un impianto del gestionale;
   - «cliente e indirizzo»: stessa ragione sociale e stesso indirizzo;
   - «probabile»: stesso cliente e stesso comune, oppure ragione sociale molto simile;
   - «da scegliere»: il cliente c'è ma ha più sedi; nessuna proposta: va scelta a mano (o creato prima il cliente).
3. `collega`: plant → sede; per ogni modulo (M01, M02, M03) l'impianto del gestionale (trovato, o creato per la messa a
   terra quando il verbale ha la potenza); l'impianto si aggiorna con l'ultimo verbale (come il verbale caricato, D63).
"""

from __future__ import annotations

import difflib
import re
import unicodedata
from collections import Counter
from datetime import date, datetime
from typing import Any

from sqlalchemy import select

from ...core.errori import ErroreUtente
from ..anagrafica.modelli import Cliente, Impianto, ImpiantoPod, Sede
from ..registro import servizio as registro
from ..verifiche import lettura_verbale
from ..verifiche.modelli import MODULO_PER_TIPOLOGIA

VALIDI = ("historical", "issued")  # verbali che contano (non bozze, scartati o annullati)
FORME = {"srl", "srls", "spa", "snc", "sas", "sapa", "scarl", "scrl", "soc", "societa", "coop", "cooperativa", "consortile", "di", "e", "c", "ditta"}
ABBREVIAZIONI = {"c so": "corso", "cso": "corso", "p za": "piazza", "pza": "piazza", "p zza": "piazza", "v le": "viale", "str": "strada", "fraz": "frazione",
                 "loc": "localita", "reg": "regione"}


def _base(t: Any) -> str:
    t = unicodedata.normalize("NFKD", str(t or "")).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", t).strip()


def norma_nome(t: Any) -> str:
    parole = [p for p in _base(t).split() if p not in FORME and len(p) > 1]
    return " ".join(parole)


def norma_indirizzo(t: Any) -> str:
    b = " " + _base(t) + " "
    for k, v in ABBREVIAZIONI.items():
        b = b.replace(" " + k + " ", " " + v + " ")
    return " ".join(p for p in b.split() if p not in ("n", "nr", "civ"))


def _pod(t: Any) -> str:
    return re.sub(r"\s+", "", str(t or "")).upper()


def _data(t: str) -> date | None:
    try:
        return datetime.strptime(str(t or "").strip(), "%d/%m/%Y").date()
    except ValueError:
        return None


def verbali_del_plant(archivio: Any, plant_id: str, tutti: list | None = None) -> list[dict]:
    """Verbali validi di un impianto di VerbalizzAI, dal più recente."""
    sorgente = [x for x in tutti if x["data"].get("plant_id") == plant_id] if tutti is not None else archivio.where("inspection", "plant_id", plant_id)
    righe = [x for x in sorgente if x["data"].get("status") in VALIDI]
    return sorted(righe, key=lambda x: (_data(x["data"]["header"].get("report_date")) or date.min, x["data"]["header"].get("number", "")), reverse=True)


# ---------------------------------------------------------------- 1. importazione del backup


def _controlla_che_sia_un_backup(contenuto: bytes) -> None:
    """0.12.8: uno ZIP qualsiasi (es. una cartella di verbali Word e PDF compressa) non è un backup di VerbalizzAI.
    Prima finiva in «Errore imprevisto»; ora il messaggio dice cos'è e dove si caricano i Word."""
    import io
    import zipfile

    try:
        nomi = zipfile.ZipFile(io.BytesIO(contenuto)).namelist()
    except zipfile.BadZipFile:
        raise ErroreUtente("Il file non è uno ZIP: serve il «Backup completo» di VerbalizzAI (file …adbackup.zip).") from None
    if "manifest.json" in nomi:
        return
    word = [n for n in nomi if n.lower().endswith(".docx")]
    pdf = [n for n in nomi if n.lower().endswith(".pdf")]
    if word or pdf:
        raise ErroreUtente(
            f"Questo ZIP contiene {len(word)} Word e {len(pdf)} PDF, ma non è un backup di VerbalizzAI: qui si carica solo il «Backup completo» "
            "(file …adbackup.zip, da VerbalizzAI › Backup e ripristino). I verbali Word si caricano dalla pagina Verbali con «+ Importa Word storici» "
            "(estrai prima i .docx dallo ZIP), oppure, per una verifica, dal riquadro «Verbale precedente» della verifica.")
    raise ErroreUtente("Questo ZIP non è un backup di VerbalizzAI (manca manifest.json): serve il «Backup completo» (file …adbackup.zip).")


def importa_backup(archivio: Any, arc: Any, attore: Any, contenuto: bytes) -> dict:
    if any(True for _ in archivio.all("inspection")):
        raise ErroreUtente("L'archivio dei verbali del gestionale contiene già dei verbali: l'importazione da VerbalizzAI si fa una volta sola, "
                           "al passaggio. Se serve rifarla, ripristina prima un backup del gestionale precedente all'importazione.")
    _controlla_che_sia_un_backup(contenuto)
    try:
        archivio.verify_backup(contenuto, archivio.docstore)
    except ValueError as e:
        raise ErroreUtente(f"Il file non è un backup completo di VerbalizzAI valido: {e}") from None
    except Exception as e:  # noqa: BLE001 — qualunque altro difetto del file è un file sbagliato, non un errore del programma
        raise ErroreUtente(f"Il file non è un backup completo di VerbalizzAI valido ({type(e).__name__}).") from None
    archivio.set_actor(getattr(attore, "nome", ""))
    info = archivio.restore(contenuto)
    with arc.scrittura() as s:
        registro.scrivi(s, utente=attore, azione="verbali.importa", oggetto_tipo="verbali", oggetto_id="archivio",
                        descrizione=f"Importato l'archivio di VerbalizzAI: {info['objects']} oggetti, {info['documents']} documenti",
                        dettagli={k: v for k, v in info.items() if k != "recovery_copy"})
    return {"oggetti": info["objects"], "documenti": info["documents"]}


# ---------------------------------------------------------------- 2. proposte di collegamento


class _Anagrafica:
    def __init__(self, s: Any) -> None:
        self.clienti = {c.id: c for c in s.execute(select(Cliente)).scalars()}
        self.sedi = {x.id: x for x in s.execute(select(Sede)).scalars()}
        self.per_nome: dict[str, list[int]] = {}
        for c in self.clienti.values():
            self.per_nome.setdefault(norma_nome(c.ragione_sociale), []).append(c.id)
        self.sedi_cliente: dict[int, list[Sede]] = {}
        for x in self.sedi.values():
            self.sedi_cliente.setdefault(x.cliente_id, []).append(x)
        self.pod: dict[str, tuple[int, int]] = {}  # pod → (impianto, sede)
        for pod, imp, sede in s.execute(select(ImpiantoPod.pod, Impianto.id, Impianto.sede_id).join(Impianto, ImpiantoPod.impianto_id == Impianto.id)):
            self.pod[pod] = (imp, sede)
        self.nomi = list(self.per_nome)

    def sede_json(self, x: Sede) -> dict:
        c = self.clienti[x.cliente_id]
        return {"id": x.id, "cliente": c.ragione_sociale, "cliente_id": c.id, "denominazione": x.denominazione,
                "indirizzo": " ".join(t for t in (x.indirizzo, x.cap, x.comune, f"({x.provincia})" if x.provincia else "") if t)}

    def indirizzo_uguale(self, x: Sede, indirizzo: str) -> bool:
        via, comune = norma_indirizzo(x.indirizzo), norma_indirizzo(x.comune)
        return bool(via and comune and f" {via} " in f" {indirizzo} " and f" {comune} " in f" {indirizzo} ")

    def comune_uguale(self, x: Sede, indirizzo: str) -> bool:
        comune = norma_indirizzo(x.comune)
        return bool(comune) and f" {comune} " in f" {indirizzo} "


def _proponi(an: _Anagrafica, nome: str, indirizzo: str, pods: set[str]) -> tuple[str, int | None, list[int]]:
    """(motivo, sede proposta, sedi alternative)."""
    trovati = [an.pod[p][1] for p in pods if p in an.pod]
    if trovati:
        return "POD", Counter(trovati).most_common(1)[0][0], []
    ind = norma_indirizzo(indirizzo)
    nn = norma_nome(nome)
    prima = norma_nome(re.split(r"\s[–-]\s|,|\(", nome or "")[0])  # «BANCA SELLA S.p.A. – Succursale …» → «banca sella»
    esatti = an.per_nome.get(nn, []) or (an.per_nome.get(prima, []) if prima != nn else [])
    simili = [c for k in difflib.get_close_matches(nn, an.nomi, n=3, cutoff=0.88) for c in an.per_nome[k]] if nn else []
    if not simili and prima and prima != nn:
        simili = [c for k in difflib.get_close_matches(prima, an.nomi, n=3, cutoff=0.88) for c in an.per_nome[k]]
    if not simili and len(prima) >= 8:  # «la canavesana» → «la canavesana sopetti luigi»
        iniziano = [k for k in an.nomi if k.startswith(prima + " ")]
        if len(iniziano) == 1:
            simili = an.per_nome[iniziano[0]]
    for vicini, simile in ((esatti, False), (simili, True)):
        sedi = [x for c in vicini for x in an.sedi_cliente.get(c, [])]
        if not sedi:
            continue
        stessa = [x for x in sedi if an.indirizzo_uguale(x, ind)]
        if len(stessa) == 1:
            return ("probabile" if simile else "cliente e indirizzo"), stessa[0].id, []
        comune = [x for x in sedi if an.comune_uguale(x, ind)]
        if len(comune) == 1 or len(sedi) == 1:
            return "probabile", (comune or sedi)[0].id, []
        return "da scegliere", None, [x.id for x in (stessa or comune or sedi)][:30]
    # stesso indirizzo, altro nome (es. cambio di ragione sociale)
    stessa = [x for x in an.sedi.values() if an.indirizzo_uguale(x, ind)] if ind else []
    if len(stessa) == 1:
        return "probabile", stessa[0].id, []
    if stessa:
        return "da scegliere", None, [x.id for x in stessa][:30]
    return "", None, []


def proposte(archivio: Any, s: Any) -> dict:
    an = _Anagrafica(s)
    righe = []
    per_plant: dict[str, list] = {}
    for x in archivio.all("inspection"):
        per_plant.setdefault(x["data"].get("plant_id"), []).append(x)
    for p in archivio.all("plant"):
        d = p["data"]
        verbali = verbali_del_plant(archivio, p["id"], per_plant.get(p["id"], []))
        moduli = sorted({v["data"].get("module") or "M01" for v in verbali})
        pods = {_pod(v["data"].get("plant", {}).get("pod")) for v in verbali} - {"", "/"}
        ultimo = verbali[0]["data"]["header"] if verbali else {}
        riga = {"id": p["id"], "cliente": d.get("client_name", ""), "sede": d.get("site_name", ""), "indirizzo": d.get("address", ""),
                "verbali": len(verbali), "moduli": moduli, "pod": sorted(pods), "ultimo": ultimo.get("number", ""), "ultimo_data": ultimo.get("report_date", ""),
                "collegata": None, "motivo": "", "proposta": None, "alternative": []}
        if d.get("sede_id") and d["sede_id"] in an.sedi:
            riga["collegata"] = an.sede_json(an.sedi[d["sede_id"]])
            riga["impianti"] = d.get("impianti") or {}
        else:
            motivo, sede, alternative = _proponi(an, d.get("client_name", ""), d.get("address", ""), pods)
            riga["motivo"] = motivo
            riga["proposta"] = an.sede_json(an.sedi[sede]) if sede else None
            riga["alternative"] = [an.sede_json(an.sedi[x]) for x in alternative]
        righe.append(riga)
    righe.sort(key=lambda r: (r["collegata"] is not None, ["POD", "cliente e indirizzo", "probabile", "da scegliere", ""].index(r["motivo"]), r["cliente"].lower()))
    conta = Counter("collegata" if r["collegata"] else (r["motivo"] or "nessuna") for r in righe)
    return {"impianti": righe, "riepilogo": dict(conta), "verbali": sum(r["verbali"] for r in righe)}


# ---------------------------------------------------------------- 3. collegamento


def _potenza(t: Any) -> str:
    m = re.search(r"\d+(?:[.,]\d+)?", str(t or "").replace(".", "") if re.search(r"\d\.\d{3}", str(t or "")) else str(t or ""))
    return m.group(0).replace(".", ",") if m else ""


def _nuovo_impianto_terra(s: Any, attore: Any, sede: Sede, dati: dict, letto: dict) -> Impianto | None:
    """Messa a terra non ancora in anagrafica: si crea con potenza, POD e periodicità del verbale (se leggibili)."""
    from ..anagrafica import servizio as anagrafica

    impianto = dati.get("plant") or {}
    potenza = _potenza(impianto.get("power"))
    if not potenza:
        return None
    cabine = str(impianto.get("cabins") or "").strip()
    at = bool(re.search(r"[1-9]", cabine))
    pod = _pod(impianto.get("pod"))
    try:
        return anagrafica.crea_impianto(s, attore, {
            "sede_id": sede.id, "tipologia": "terra_at" if at else "terra_bt", "potenza_kw": potenza,
            "cabine_mt_bt": re.search(r"\d+", cabine).group(0) if at else None, "pod": [pod] if re.fullmatch(r"IT\d{3}E\d{8}", pod) else [],
            "periodicita_anni": letto["periodicita"] if letto["periodicita"] in (2, 5) else 5,
            "note": "Creato dall'importazione dell'archivio di VerbalizzAI: controllare i dati."})
    except ErroreUtente:
        return None


def collega(archivio: Any, arc: Any, attore: Any, plant_id: str, sede_id: int, aggiorna: bool = True) -> dict:
    from ..verifiche import servizio as verifiche
    from .servizio import dati_plant

    p = archivio.get(plant_id)
    if p["kind"] != "plant":
        raise ErroreUtente("Impianto di VerbalizzAI non trovato: ricarica la pagina.")
    verbali = verbali_del_plant(archivio, plant_id)
    note, mappa = [], dict(p["data"].get("impianti") or {})
    with arc.scrittura() as s:
        sede = s.get(Sede, int(sede_id))
        if sede is None:
            raise ErroreUtente("Sede non trovata: ricarica la pagina.")
        for modulo in sorted({v["data"].get("module") or "M01" for v in verbali}):
            ultimo = next(v for v in verbali if (v["data"].get("module") or "M01") == modulo)
            d = ultimo["data"]
            letto = lettura_verbale.da_dati(d)
            candidati = [x for x in s.execute(select(Impianto).where(Impianto.sede_id == sede.id, Impianto.dismesso.is_(False))).scalars()
                         if MODULO_PER_TIPOLOGIA.get(x.tipologia) == modulo]
            pod = _pod(d.get("plant", {}).get("pod"))
            con_pod = [x for x in candidati if pod and pod in {q.pod for q in x.pod}]
            x = (con_pod or candidati or [None])[0]
            if x is not None and mappa.get(modulo) in {c.id for c in candidati}:
                x = s.get(Impianto, mappa[modulo])
            if len(candidati) > 1 and not con_pod:
                note.append(f"{modulo}: la sede ha {len(candidati)} impianti di questo tipo; collegato il n. {x.id} (cambialo se non è quello giusto).")
            if x is None and modulo == "M01":
                x = _nuovo_impianto_terra(s, attore, sede, d, letto)
                if x is not None:
                    note.append(f"M01: creato l'impianto n. {x.id} (messa a terra) con i dati del verbale {d['header'].get('number', '')}: controllalo.")
            if x is None:
                note.append(f"{modulo}: nella sede non c'è un impianto di questo tipo. Crealo nella scheda della sede, poi collega di nuovo.")
                continue
            mappa[modulo] = x.id
            ultima = letto["data"] or _data(d["header"].get("start_date"))
            if aggiorna and ultima:
                prossima = letto["prossima"]
                if prossima is None:
                    from ..anagrafica.servizio import scadenza

                    anni = 2 if x.tipologia == "esplosione" else (letto["periodicita"] or x.periodicita_anni)
                    prossima = scadenza(ultima, anni) if anni else None
                note += [f"{modulo}: {a}" for a in verifiche.aggiorna_impianto(s, attore, x.id, letto, ultima, letto["numero"], prossima, scheda=False)]
        pd = dict(p["data"])
        pd.update({k: v for k, v in dati_plant(s, sede_o_impianto(s, sede, mappa)).items() if k not in ("email_to", "email_cc") or not pd.get(k)})
        pd["sede_id"], pd["impianti"] = sede.id, mappa
        pd["label"] = pd.get("address") or pd.get("label") or "Impianto"
        registro.scrivi(s, utente=attore, azione="verbali.collega", oggetto_tipo="sede", oggetto_id=sede.id,
                        descrizione=f"Impianto di VerbalizzAI «{p['data'].get('client_name', '')} – {p['data'].get('address', '')}» collegato alla sede n. {sede.id}"
                                    f" ({len(verbali)} verbali)", dettagli={"impianti": mappa, "note": note})
    archivio.set_actor(getattr(attore, "nome", ""))
    archivio.mutate(lambda c: archivio._put(c, "plant", pd, plant_id, action="plant_link"))
    if aggiorna:  # R122: la scheda tecnica dell'impianto è quella di VerbalizzAI (con lo storico appena collegato)
        from . import scheda

        scheda.sincronizza_plant(archivio, arc, attore, plant_id)
    return {"impianti": mappa, "note": note}


def sede_o_impianto(s: Any, sede: Sede, mappa: dict) -> Impianto:
    """Per i dati anagrafici del plant serve un impianto della sede (quello collegato, o uno qualsiasi, o uno «finto»)."""
    for i in mappa.values():
        x = s.get(Impianto, i)
        if x is not None:
            return x
    return Impianto(sede_id=sede.id, denominazione="")


def scollega(archivio: Any, arc: Any, attore: Any, plant_id: str) -> None:
    p = archivio.get(plant_id)
    pd = {k: v for k, v in p["data"].items() if k not in ("sede_id", "impianti")}
    archivio.set_actor(getattr(attore, "nome", ""))
    archivio.mutate(lambda c: archivio._put(c, "plant", pd, plant_id, action="plant_unlink"))
    with arc.scrittura() as s:
        registro.scrivi(s, utente=attore, azione="verbali.scollega", oggetto_tipo="sede", oggetto_id=p["data"].get("sede_id") or 0,
                        descrizione=f"Impianto di VerbalizzAI «{p['data'].get('client_name', '')} – {p['data'].get('address', '')}» scollegato dalla sede")


def collega_proposte(archivio: Any, arc: Any, attore: Any, motivi: tuple[str, ...] = ("POD", "cliente e indirizzo")) -> dict:
    """Collega in una volta le proposte sicure (POD, cliente e indirizzo)."""
    with arc.lettura() as s:
        elenco = proposte(archivio, s)["impianti"]
    fatte, note = 0, []
    for r in elenco:
        if r["collegata"] is None and r["motivo"] in motivi and r["proposta"]:
            esito = collega(archivio, arc, attore, r["id"], r["proposta"]["id"])
            fatte += 1
            note += [f"{r['cliente']}: {n}" for n in esito["note"]]
    return {"collegati": fatte, "note": note}
