"""Persistenza PostgreSQL dei verbali DPR, nello schema `verbali` di NEXUS.

La logica applicativa e il formato dei backup restano quelli di Archive;
questo adattatore limita al solo deposito le differenze dei due database.
"""
from __future__ import annotations

import re
import threading
import time
from pathlib import Path

import psycopg
from psycopg.pq import TransactionStatus

from ...terzi.verbalizzai.storage import FORMAT_VERSION, Archive, uid


class _Riga(dict):
    """Come sqlite3.Row: sia indici numerici sia chiavi; dict(r) conserva i nomi."""

    def __getitem__(self, key):
        if isinstance(key, int):
            return tuple(self.values())[key]
        return super().__getitem__(key)


def _righe(cursor):
    # BEGIN, COMMIT e gli INSERT non restituiscono colonne: psycopg invoca
    # comunque la factory, con cursor.description=None.
    colonne = [col.name for col in (cursor.description or ())]
    return lambda valori: _Riga(zip(colonne, valori))


_JSON = re.compile(r"json_extract\(data,'\$\.([a-zA-Z_][a-zA-Z_0-9]*)'\)")


class _Connessione:
    def __init__(self, url: str):
        self.raw = psycopg.connect(url, autocommit=True, row_factory=_righe,
                                   options="-c search_path=verbali,public", connect_timeout=15,
                                   prepare_threshold=None)

    def execute(self, query, params=()):
        # In Archive i '?' sono esclusivamente segnaposto SQL, mai dati: i
        # valori restano parametri del driver, senza interpolazioni testuali.
        if query == "BEGIN":
            query = "BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY"
        elif query == "BEGIN IMMEDIATE":
            query = "BEGIN"
        elif query.startswith("INSERT OR REPLACE INTO objects("):
            query = query.replace("INSERT OR REPLACE", "INSERT", 1)
            query += (" ON CONFLICT (id) DO UPDATE SET kind=EXCLUDED.kind, data=EXCLUDED.data, "
                      "revision=EXCLUDED.revision, updated_at=EXCLUDED.updated_at, updated_by=EXCLUDED.updated_by")
        elif query.startswith("INSERT OR REPLACE INTO meta VALUES"):
            query = query.replace("INSERT OR REPLACE", "INSERT", 1)
            query += " ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value"
        elif query.startswith("INSERT OR IGNORE INTO documents"):
            query = query.replace("INSERT OR IGNORE", "INSERT", 1) + " ON CONFLICT (sha) DO NOTHING"
        query = query.replace(",user)", ',"user")').replace(",user FROM", ',"user" FROM')
        query = query.replace(" e.user=", ' e."user"=').replace(" WHERE user=", ' WHERE "user"=')
        query = _JSON.sub(lambda m: f"(data::jsonb ->> '{m.group(1)}')", query)
        return self.raw.execute(query.replace("?", "%s"), params)

    @property
    def in_transaction(self):
        return self.raw.info.transaction_status == TransactionStatus.INTRANS

    def close(self):
        self.raw.close()

    def __enter__(self):
        return self

    def __exit__(self, typ, value, traceback):
        if self.in_transaction:
            self.execute("ROLLBACK" if typ else "COMMIT")
        self.close()


class ArchivioPostgresql(Archive):
    """Usa le tabelle del DB NEXUS, preservando tutte le API di VerbalizzAI."""

    def __init__(self, directory: Path, url: str):
        self.url = url.replace("postgresql+psycopg://", "postgresql://", 1)
        self.directory = Path(directory).resolve()
        self.directory.mkdir(parents=True, exist_ok=True)
        self.backups = self.directory / "backups"
        self.backups.mkdir(parents=True, exist_ok=True)
        self.docstore = self.backups / "documenti"
        self.docstore.mkdir(exist_ok=True)
        self.path = None  # nessun file SQLite nell'istanza PostgreSQL
        self.lock = threading.RLock()
        self.backup_error = ""
        self._local = threading.local()
        self._last_backup = time.monotonic()
        self._initialize_pg()
        self._sync_docstore_pg()
        self._migrate_plant_state()

    def connect(self):
        return _Connessione(self.url)

    def _initialize_pg(self):
        c = self.connect()
        try:
            c.execute("BEGIN IMMEDIATE")
            c.execute("SELECT pg_advisory_xact_lock(462810181)")
            c.execute("INSERT INTO meta(key,value) VALUES(%s,%s) ON CONFLICT (key) DO NOTHING",
                      ("format_version", str(FORMAT_VERSION)))
            c.execute("INSERT INTO meta(key,value) VALUES(%s,%s) ON CONFLICT (key) DO NOTHING",
                      ("archive_id", uid()))
            version = c.execute("SELECT value FROM meta WHERE key='format_version'").fetchone()[0]
            if int(version) not in (1, FORMAT_VERSION):
                raise ValueError("Versione archivio verbali non supportata.")
            c.execute("COMMIT")
        except BaseException:
            if c.in_transaction:
                c.execute("ROLLBACK")
            raise
        finally:
            c.close()

    def _sync_docstore_pg(self):
        c = self.connect()
        try:
            for r in c.execute("SELECT sha FROM documents"):
                digest = r["sha"]
                if not (self.docstore / (digest + ".bin")).exists():
                    blob = c.execute("SELECT data FROM documents WHERE sha=?", (digest,)).fetchone()[0]
                    self._store_file(digest, bytes(blob))
        finally:
            c.close()

    def mutate(self, callback, force_backup=False):
        with self.lock:
            c = self.connect()
            try:
                c.execute("BEGIN IMMEDIATE")
                c.execute("SELECT pg_advisory_xact_lock(462810181)")
                result = callback(c)
                c.execute("COMMIT")
            except BaseException:
                if c.in_transaction:
                    c.execute("ROLLBACK")
                raise
            finally:
                c.close()
        if force_backup:
            try:
                self.auto_backup()
            except Exception as exc:  # noqa: BLE001 - un backup periodico non annulla la scrittura confermata
                self.backup_error = str(exc)
        elif time.monotonic() - self._last_backup >= 300:
            self._last_backup = time.monotonic()
            threading.Thread(target=self._background_backup, daemon=True).start()
        return result

    def _json_rows(self, c, kind, field, value):
        if field not in ("plant_id", "source_sha", "inspection_id", "revision_of", "sede_id"):
            raise ValueError("Campo non indicizzato nel registro dei verbali.")
        return c.execute(f"SELECT * FROM objects WHERE kind=? AND (data::jsonb ->> '{field}')=?",
                         (kind, str(value))).fetchall()

    def light_inspections(self):
        out = []
        for item in self.all("inspection"):
            d = item["data"]
            def get(path, d=d):
                cur = d
                for key in path.removeprefix("$.").split("."):
                    cur = cur.get(key) if isinstance(cur, dict) else None
                return cur
            x = {k: get(path) for k, path in self.LIGHT.items()}
            x.update(id=item["id"], updated_at=item["updated_at"], updated_by=item["updated_by"])
            x["annul_log"] = x["annul_log"] or []
            x["historical"] = bool(x["historical"])
            x["status"] = x["status"] or ""
            x["module"] = x["module"] or "M01"
            x["number"] = x["number"] or ""
            x["date"] = x["date"] or ""
            x["rev_index"] = x["rev_index"] or 0
            x["client"] = x["client"] or ""
            x["inspectors"] = x["inspectors"] or ""
            x["locked"] = x["historical"] or x["status"] in ("issued", "discarded", "annulled")
            out.append(x)
        return out

    def asset_counts(self):
        counts = {}
        for item in self.all("asset"):
            d = item["data"]
            if d.get("active", True) and not d.get("pending_inspection"):
                counts[d["plant_id"]] = counts.get(d["plant_id"], 0) + 1
        return counts

    def template_usage(self):
        use = {}
        def empty():
            return {"drafts": 0, "issued": 0, "other": 0, "exports": 0}
        for item in self.light_inspections():
            tid = item["template_id"]
            if not tid:
                continue
            x = use.setdefault(tid, empty())
            if item["status"] == "issued":
                x["issued"] += 1
            elif item["status"] in ("annulled", "discarded") or item["historical"]:
                x["other"] += 1
            else:
                x["drafts"] += 1
        for item in self.all("export"):
            tid = item["data"].get("template_id")
            if tid:
                use.setdefault(tid, empty())["exports"] += 1
        return use
