"""Collegamento tra verifiche del gestionale e verbali di VerbalizzAI (versione 0.5.0, decisione D67).

- `prepara`: all'avvio carica nell'archivio dei verbali i modelli M01, M02, M03 rev. 02 di VerbalizzAI (se mancano).
- `assicura_plant`: l'«impianto» di VerbalizzAI per un impianto del gestionale (una sede + un impianto per modulo),
  con ragione sociale, sede e indirizzo sempre presi dal gestionale.
- `crea_bozza`: dalla verifica registrata nasce la bozza del verbale, già con numero, data e verificatore.
- `dopo_emissione`: il verbale emesso chiude la verifica (stessa lettura del Word caricato a mano, D63).
"""

from __future__ import annotations

import json
from datetime import date
from typing import Any

from sqlalchemy import select

from ...core.errori import ErroreUtente, PermessoNegato
from ...terzi.verbalizzai import templates as vz_templates
from ..anagrafica.modelli import Cliente, Impianto, Sede
from ..utenti.modelli import Utente
from ..verifiche import lettura_verbale
from ..verifiche.modelli import MODULO_PER_TIPOLOGIA, Verifica
from . import scheda

CARTELLA_MODELLI = __import__("pathlib").Path(__file__).resolve().parents[2] / "terzi" / "verbalizzai" / "modelli"


def prepara(archivio: Any) -> None:
    """Modelli dei verbali M01, M02, M03 rev. 02 (quelli della versione di VerbalizzAI incorporata), se l'archivio non ne ha per un modulo."""
    for file in sorted(CARTELLA_MODELLI.glob("M0?-PO01_dpr_rev02.docx")):
        modulo = file.name[:3]
        if archivio.templates_for(modulo):
            continue
        raw = file.read_bytes()
        adattato, info = vz_templates.adapt_template(raw, file.name)
        archivio.set_actor("sistema")
        archivio.add_template(raw, file.name, adattato, info)


def _indirizzo(sede: Sede) -> str:
    comune = " ".join(t for t in (sede.cap, sede.comune, f"({sede.provincia})" if sede.provincia else "") if t)
    return ", ".join(t for t in (sede.indirizzo, comune) if t)


def dati_plant(s: Any, x: Impianto) -> dict:
    sede = s.get(Sede, x.sede_id)
    cliente = s.get(Cliente, sede.cliente_id)
    nome_sede = sede.denominazione if sede.denominazione and sede.denominazione.casefold() != cliente.ragione_sociale.casefold() else ""
    if x.denominazione:
        nome_sede = " – ".join(t for t in (nome_sede, x.denominazione) if t)
    return {"client_name": cliente.ragione_sociale, "site_name": nome_sede, "address": _indirizzo(sede), "sede_id": sede.id,
            "email_to": sede.email_verbali or cliente.email_verbali or "", "email_cc": ""}


def assicura_plant(archivio: Any, s: Any, impianto_id: int) -> str:
    """Id dell'impianto di VerbalizzAI per questo impianto: lo cerca (sede + modulo) o lo crea."""
    x = s.get(Impianto, impianto_id)
    modulo = MODULO_PER_TIPOLOGIA.get(x.tipologia, "M01")
    dati = dati_plant(s, x)
    scelto = None
    collegati = []
    for p in archivio.where("plant", "sede_id", dati["sede_id"]):
        mappa = p["data"].get("impianti") or {}
        if mappa.get(modulo) == x.id:
            collegati.append(p)
        if scelto is None and modulo not in mappa:
            scelto = p
    if collegati:
        # AD-REV-002 (0.12.8): se più impianti di VerbalizzAI puntano allo stesso impianto, vale quello con il verbale più recente
        scelto = scheda.principale(archivio, collegati, modulo)
    if scelto is None:
        for p in archivio.all("plant"):  # impianto già collegato a mano (es. dopo l'importazione)
            if (p["data"].get("impianti") or {}).get(modulo) == x.id:
                scelto = p
                break
    if scelto is None:
        nuovo = {**dati, "label": dati["address"] or "Impianto", "complete_inventory": False, "impianti": {modulo: x.id}}
        return archivio.mutate(lambda c: archivio._put(c, "plant", nuovo, action="plant_link"))
    pd = dict(scelto["data"])
    pd.update({k: v for k, v in dati.items() if k not in ("email_to", "email_cc") or not pd.get(k)})
    pd["label"] = pd.get("address") or pd.get("label") or "Impianto"
    pd["impianti"] = {**(pd.get("impianti") or {}), modulo: x.id}
    if pd != scelto["data"]:
        archivio.mutate(lambda c: archivio._put(c, "plant", pd, scelto["id"], action="plant_link"))
    return scelto["id"]


def _revisione_dopo_riesame(archivio: Any, arc: Any, utente: Any, verifica_id: int) -> None:
    """Riesame non conforme: la verifica torna «registrata» con il verbale già emesso. Il verbale si corregge con una
    REVISIONE di quello emesso (stesso numero, rev. successiva, come in VerbalizzAI), non con un verbale nuovo."""
    from ..verifiche import servizio as verifiche

    with arc.lettura() as s:
        v = verifiche.verifica_o_404(s, verifica_id)
        verifiche._richiedi_esecutore(utente, v)
        if v.stato != "registrata" or not v.verbale_id:
            return
        emesso_id = v.verbale_id
    try:
        emesso = archivio.get(emesso_id)
    except (KeyError, ValueError):
        return
    if emesso["data"].get("status") != "issued":
        return
    aperta = next((x for x in archivio.where("inspection", "revision_of", emesso_id) if x["data"].get("status") == "draft"), None)
    if aperta is None:
        archivio.set_actor(utente.username)
        aperta = archivio.create_revision(emesso_id)
    with arc.scrittura() as s:
        verifiche.verifica_o_404(s, verifica_id).verbale_id = aperta["id"]


def _data_bozza(d: dict) -> date | None:
    """Data del verbale scritta nella bozza (gg/mm/aaaa); None se assente o incompleta."""
    testo = str((d.get("header") or {}).get("report_date") or "").strip()
    try:
        g, m, a = (int(x) for x in testo.split("/"))
        return date(a, m, g)
    except ValueError:
        return None


def _straordinaria_bozza(d: dict) -> bool | None:
    tipo = (d.get("flags") or {}).get("check_type") or {}
    if bool(tipo.get("extra")) == bool(tipo.get("periodic")):
        return None  # nessuna scelta (o entrambe): il tipo resta quello della verifica
    return bool(tipo.get("extra"))


def numero_nella_bozza(s: Any, utente: Any, v: Any, d: dict, *, rigido: bool = False) -> bool:
    """B2 (rc8): il numero del verbale è quello della verifica, assegnato da NEXUS. Prima si allinea la verifica alla data
    e al tipo scritti nella bozza (cambio d'anno → primo numero libero dell'anno), poi si scrive il numero nella bozza.
    Le revisioni di un verbale emesso conservano sempre il numero. Con `rigido` un anno non ammesso è un errore
    (prima dell'emissione); altrimenti (salvataggio automatico) il numero resta quello registrato.
    Restituisce True se la bozza `d` è stata modificata."""
    from ..verifiche import servizio as verifiche

    if not v.codice_verbale:
        return False
    if not d.get("revision_of"):
        try:
            verifiche.allinea_numero(s, utente, v, _data_bozza(d), _straordinaria_bozza(d))
        except ErroreUtente:
            if rigido:
                raise
    h = d.setdefault("header", {})
    atteso = {"number": v.codice_verbale, "number_seq": str(v.numero) if v.numero is not None else h.get("number_seq")}
    if all(h.get(k) == x for k, x in atteso.items()):
        return False
    h.update(atteso)
    return True


def allinea_bozza_in_salvataggio(arc: Any, utente: Any, corpo: bytes) -> bytes:
    """Salvataggio di una bozza da /verbali (ponte): numero sempre quello della verifica, ricalcolato se cambia l'anno."""
    from ..verifiche.modelli import Verifica

    try:
        richiesta = json.loads(corpo or b"{}")
    except ValueError:
        return corpo
    d, iid = richiesta.get("data"), richiesta.get("id")
    if not isinstance(d, dict) or not iid:
        return corpo
    with arc.scrittura() as s:
        v = s.scalar(select(Verifica).where(Verifica.verbale_id == iid))
        if v is None or not numero_nella_bozza(s, utente, v, d):
            return corpo
    return json.dumps(richiesta, ensure_ascii=False).encode()


def controlla_numero_prima_di_emettere(archivio: Any, arc: Any, utente: Any, verbale_id: str) -> None:
    """Nessun verbale si emette con un numero diverso da quello della verifica (resterebbe emesso e scollegato)."""
    from ..verifiche.modelli import Verifica

    d = archivio.get(verbale_id)["data"]
    with arc.lettura() as s:
        v = s.scalar(select(Verifica).where(Verifica.verbale_id == verbale_id))
        if v is None:
            return
        giorno = _data_bozza(d)
        if giorno is not None and not d.get("revision_of"):
            from ..verifiche import servizio as verifiche
            verifiche.anno_ammesso(giorno, "Data del verbale")
        numero = (d.get("header") or {}).get("number", "")
        if numero != v.codice_verbale:
            raise ErroreUtente(f"Il numero nel verbale ({numero or 'assente'}) non è quello della verifica ({v.codice_verbale}): "
                               "ricarica la pagina (F5) per riallinearlo, poi rifai l'anteprima.")


def attributi_nexus(x: Impianto, modulo: str) -> dict:
    """rc8 (punto 4, D1 · Federico 14/10/2026: «potenza è attributo dell'impianto, e determina la tariffa applicabile a
    preventivo e quindi a fattura, oltre che verbale»). Valori dell'impianto NEXUS che la bozza nuova riprende nei campi
    del verbale M01. Solo quelli presenti: un campo vuoto in NEXUS lascia il valore del motore (scheda o ultimo verbale).
    Non tocca i verbali già emessi né le loro revisioni (fotografie)."""
    if modulo != "M01" or x.tipologia not in ("terra_bt", "terra_at"):
        return {}
    out = {}
    if x.potenza_kw is not None:
        out["power"] = f"{x.potenza_kw:g} kW".replace(".", ",")
    pod = [p.pod for p in x.pod]
    if pod:
        out["pod"] = ", ".join(pod)
    if x.tipologia == "terra_at":
        if x.cabine_mt_bt is not None:
            out["cabins"] = str(x.cabine_mt_bt)
        if x.sottostazioni_at_mt is not None:
            out["stations"] = str(x.sottostazioni_at_mt)
    return out


def crea_bozza(archivio: Any, arc: Any, utente: Any, verifica_id: int) -> str:
    """Bozza del verbale per una verifica registrata (o quella già aperta). Restituisce l'id del verbale."""
    from ..verifiche import servizio as verifiche

    _revisione_dopo_riesame(archivio, arc, utente, verifica_id)
    riaperta = None
    with arc.lettura() as s:
        v = verifiche.verifica_o_404(s, verifica_id)
        verifiche._richiedi_esecutore(utente, v)
        if v.stato != "registrata":
            raise ErroreUtente("Il verbale si compila su una verifica registrata (con il numero del verbale).")
        if v.verbale_id:
            try:
                attuale = archivio.get(v.verbale_id)
            except (KeyError, ValueError):
                attuale = None
            if attuale and attuale["data"].get("status") == "draft":
                # anagrafica unica (0.6.0): riaprendo la bozza, ragione sociale, sede e indirizzo tornano quelli del gestionale
                assicura_plant(archivio, s, v.impianto_id)
                anagrafica = dati_plant(s, s.get(Impianto, v.impianto_id))
                d = attuale["data"]
                nuovi = {k: anagrafica[k] for k in ("client_name", "site_name", "address")}
                h = d.setdefault("header", {})
                data_vuota = bool(h.get("report_date")) and not h.get("issued_date")
                if data_vuota:  # bozze nate prima della 0.12.6: data di emissione mancante
                    h["issued_date"] = h["report_date"]
                    d.setdefault("date_auto", {}).setdefault("issued_date", h["report_date"])
                cambia = data_vuota or any((d.get("plant") or {}).get(k) != x for k, x in nuovi.items())
                d.setdefault("plant", {}).update(nuovi)
                riaperta = (attuale, cambia)
        if riaperta is None:
            plant_id = assicura_plant(archivio, s, v.impianto_id)
            verificatore = s.get(Utente, v.verificatore_id).nome if v.verificatore_id else utente.nome
            x = s.get(Impianto, v.impianto_id)
            modulo = MODULO_PER_TIPOLOGIA.get(x.tipologia, "M01")
            codice, numero, giorno, tipo = v.codice_verbale, v.numero, v.data_esecuzione.strftime("%d/%m/%Y"), v.tipo_verifica
            anagrafica = dati_plant(s, x)
            attributi = attributi_nexus(x, modulo)
    if riaperta is not None:
        attuale, cambia = riaperta
        # B2 (rc8): fuori dalla lettura, perché può aggiornare la verifica (numero riallineato alla data del verbale)
        if _numero_da_allineare(arc, utente, verifica_id, attuale["data"]) or cambia:
            archivio.set_actor(utente.username)
            archivio.save(attuale["id"], attuale["data"], attuale["revision"])
        return attuale["id"]
    archivio.set_actor(utente.username)
    bozza = archivio.create_draft(plant_id, None, verificatore, modulo)
    d = bozza["data"]
    d["header"].update(number=codice, number_seq=str(numero), report_date=giorno, start_date=giorno, end_date=giorno, issued_date=giorno)
    # 0.12.6: come in VerbalizzAI, inizio verifica e data di emissione seguono la data del verbale finché non si cambiano a mano
    d["date_auto"] = {"start_date": giorno, "issued_date": giorno}
    if "check_type" in d.get("flags", {}):
        d["flags"]["check_type"] = {"periodic": tipo != "straordinaria", "extra": tipo == "straordinaria"}
    # ragione sociale, sede e indirizzo: sempre quelli del gestionale (anche se il verbale precedente diceva altro)
    d.setdefault("plant", {}).update(client_name=anagrafica["client_name"], site_name=anagrafica["site_name"], address=anagrafica["address"])
    # rc8 (punto 4, D1): potenza, POD, cabine e sottostazioni sono attributi dell'impianto NEXUS (la potenza decide anche la
    # tariffa): la bozza nuova li prende da lì, come l'anagrafica. Il resto della scheda arriva come prima dal motore.
    d["plant"].update(attributi)
    d["verifica_id"] = verifica_id
    archivio.save(bozza["id"], d, bozza["revision"])
    with arc.scrittura() as s:
        v = verifiche.verifica_o_404(s, verifica_id)
        v.verbale_id = bozza["id"]
    return bozza["id"]


def _numero_da_allineare(arc: Any, utente: Any, verifica_id: int, d: dict) -> bool:
    """B2: riaprendo la bozza il numero torna quello della verifica (anche se cancellato a mano)."""
    from ..verifiche import servizio as verifiche

    with arc.scrittura() as s:
        return numero_nella_bozza(s, utente, verifiche.verifica_o_404(s, verifica_id), d)


def _verifica_del_verbale(s: Any, archivio: Any, verbale_id: str) -> Verifica | None:
    d = archivio.get(verbale_id)["data"]
    if d.get("verifica_id"):
        v = s.get(Verifica, int(d["verifica_id"]))
        if v is not None:
            return v
    return s.execute(select(Verifica).where(Verifica.verbale_id == verbale_id)).scalar()


def dopo_emissione(archivio: Any, arc: Any, utente: Any, verbale_id: str) -> dict | None:
    """Verbale emesso nel gestionale → la verifica diventa «eseguita» e l'impianto si aggiorna (come il Word caricato a mano)."""
    from ..verifiche import servizio as verifiche

    item = archivio.get(verbale_id)
    d = item["data"]
    if d.get("status") != "issued" or not d.get("issued_export_id"):
        return None
    esportazione = archivio.get(d["issued_export_id"])["data"]
    nome_word, word = archivio.document(esportazione["sha"])
    nome_pdf, pdf = archivio.document(esportazione["pdf_sha"]) if esportazione.get("pdf_sha") else ("", None)
    with arc.scrittura() as s:
        v = _verifica_del_verbale(s, archivio, verbale_id)
        if v is None:
            return None
        # Idempotenza: l'export è già stato acquisito. Un riavvio/riallineamento non cancella il riesame.
        from ..verifiche.modelli import DocumentoVerifica
        from ..documenti.modelli import Documento
        acquisito = s.scalar(select(Documento.impronta).join(DocumentoVerifica).where(
            DocumentoVerifica.verifica_id == v.id, DocumentoVerifica.in_uso.is_(True), DocumentoVerifica.formato == "pdf"))
        if v.verbale_id == verbale_id and acquisito and acquisito == esportazione.get("pdf_sha"):
            return {"verifica_id": v.id, "stato": v.stato}
        if v.stato in ("eseguita", "riesaminata"):  # revisione del verbale: si ricarica sulla verifica
            v.stato = "registrata"
        v.verbale_id = verbale_id
        try:
            # i dati del verbale compilato (esatti), non la rilettura del Word emesso
            # R122: date dal verbale; la scheda tecnica da quella di VerbalizzAI (aggiornata o conservata all'emissione)
            verifiche.carica_verbale(s, arc.cfg, utente, v.id, word, nome_word, pdf, nome_pdf, v.versione, letto=lettura_verbale.da_dati(d),
                                     scheda=False)
        except PermessoNegato:
            raise
        esito = {"verifica_id": v.id, "stato": v.stato}
    if d.get("plant_id"):
        scheda.sincronizza_plant(archivio, arc, utente, d["plant_id"])
    return esito


def dopo_annullamento(archivio: Any, arc: Any, utente: Any, verbale_id: str) -> None:
    """Verbale emesso annullato in VerbalizzAI → la verifica torna «registrata» (per un nuovo verbale), con nota nel registro."""
    from ..registro import servizio as registro

    with arc.scrittura() as s:
        v = _verifica_del_verbale(s, archivio, verbale_id)
        if v is None or v.stato not in ("eseguita", "riesaminata") or v.verbale_id != verbale_id:
            return
        v.stato = "registrata"
        registro.scrivi(s, utente=utente, azione="verifica.verbale_annullato", oggetto_tipo="verifica", oggetto_id=v.id,
                        descrizione=f"Verbale {v.codice_verbale} annullato: la verifica n. {v.id} torna «registrata»")


def riallinea_emissioni(archivio, arc, utente):
    """Riprende emissioni persistite in VA se l'acquisizione tecnica è stata interrotta.
    L'export emesso è l'evidenza durevole; lo stesso SHA non viene acquisito due volte.
    Nessun invio email, numero nuovo o mutazione del documento emesso.
    """
    riusciti, errori = [], []
    with arc.lettura() as s:
        collegate = dict(s.execute(select(Verifica.id, Verifica.verbale_id)).all())
    ids = {iid for iid in collegate.values() if iid}
    # Una caduta tra il salvataggio della bozza in VerbalizzAI e il commit
    # della verifica può lasciare vuoto Verifica.verbale_id. L'identificativo
    # della verifica scritto nel verbale permette di recuperare anche il caso
    # in cui l'emissione sia proseguita dopo quella interruzione.
    for item in archivio.all("inspection"):
        dati = item["data"]
        if dati.get("status") != "issued" or not dati.get("verifica_id"):
            continue
        try:
            verifica_id = int(dati["verifica_id"])
        except (TypeError, ValueError):
            continue
        if collegate.get(verifica_id) in ("", item["id"]):
            ids.add(item["id"])
    for iid in sorted(ids):
        try:
            item = archivio.get(iid)
            if item and item["data"].get("status") == "issued":
                esito = dopo_emissione(archivio, arc, utente, iid)
                if esito: riusciti.append(esito)
        except Exception as e:
            errori.append({"verbale_id": iid, "errore": str(e)})
    return {"allineati": riusciti, "errori": errori}


def precedente(archivio: Any, arc: Any, utente: Any, verifica_id: int) -> dict | None:
    """L'ultimo verbale valido (emesso o storico importato) dell'impianto, da cui partirà la bozza; None se non c'è."""
    from ..verifiche import servizio as verifiche

    with arc.lettura() as s:
        v = verifiche.verifica_o_404(s, verifica_id)
        x = s.get(Impianto, v.impianto_id)
        modulo = MODULO_PER_TIPOLOGIA.get(x.tipologia, "M01")
        dati = dati_plant(s, x)
    # AD-REV-002 (0.12.8): lo stesso impianto di VerbalizzAI e lo stesso verbale che userà la bozza (criterio di VerbalizzAI)
    p = scheda.principale(archivio, scheda.plant_collegati(archivio, dati["sede_id"], modulo, x.id), modulo)
    if p is None:
        return None
    w = scheda.verbale_piu_recente(archivio, p["id"], modulo)
    if w is None or w["id"] == v.verbale_id:
        return None
    h = w["data"].get("header") or {}
    return {"id": w["id"], "numero": h.get("number", ""), "data": h.get("report_date", ""), "storico": bool(w["data"].get("historical")),
            "file": (w["data"].get("source_meta") or {}).get("filename", ""), "plant_id": p["id"]}


def carica_precedente(archivio: Any, arc: Any, utente: Any, verifica_id: int, contenuto: bytes, nome: str) -> dict:
    """0.12.6: il Word dell'ultimo verbale caricato DALLA VERIFICA finisce sull'impianto giusto di VerbalizzAI, così la
    bozza riparte dal suo contenuto (come «Nuova verifica» in VerbalizzAI dopo l'importazione dello storico).
    - Se lo stesso Word era già stato importato dalla pagina dei verbali su un impianto di VerbalizzAI non collegato,
      quell'impianto si collega a questo (con lo storico) invece di importarlo due volte.
    - Se la bozza di questa verifica è già aperta, si rifà partendo dal verbale precedente (chi carica lo conferma)."""
    from ...terzi.verbalizzai.wordio import parse_word
    from ..registro import servizio as registro
    from ..verifiche import servizio as verifiche
    from . import importazione

    if not nome.lower().endswith(".docx"):
        raise ErroreUtente("Carica il Word (.docx) dell'ultimo verbale.")
    with arc.lettura() as s:
        v = verifiche.verifica_o_404(s, verifica_id)
        verifiche._richiedi_esecutore(utente, v)
        if v.stato not in ("assegnata", "programmata", "registrata"):
            raise ErroreUtente("Il verbale precedente si carica prima di compilare il nuovo (verifica assegnata, programmata o registrata).")
        x = s.get(Impianto, v.impianto_id)
        modulo = MODULO_PER_TIPOLOGIA.get(x.tipologia, "M01")
        plant_id = assicura_plant(archivio, s, x.id)
        anagrafica = dati_plant(s, x)
        sede_id, bozza_id, impianto_id = x.sede_id, v.verbale_id, x.id
    try:
        letto = parse_word(contenuto, nome)
    except Exception as e:  # noqa: BLE001
        raise ErroreUtente(f"Il Word non si legge come verbale di VerbalizzAI: {e}") from None
    if (letto.get("module") or "M01") != modulo:
        raise ErroreUtente(f"Il Word è un verbale {letto.get('module') or 'M01'}, ma questo impianto usa il modulo {modulo}.")
    pl = letto.setdefault("plant", {})
    for k in ("client_name", "address", "site_name"):
        pl[k] = pl.get(k) or anagrafica[k]
    archivio.set_actor(utente.username)
    esito = archivio.import_word(contenuto, nome, letto, plant_id)
    note = []
    if esito.get("duplicate") and esito.get("plant_id") != plant_id:
        altro = archivio.get(esito["plant_id"])
        sede_altro = altro["data"].get("sede_id")
        if sede_altro and sede_altro != sede_id:
            raise ErroreUtente("Questo Word è già nell'archivio dei verbali, collegato a un'altra sede: controlla in Gestione › Verbali di VerbalizzAI.")
        gia = (altro["data"].get("impianti") or {}).get(modulo)
        if gia and gia != impianto_id:  # AD-REV-003 (0.12.8): mai spostare in silenzio lo storico di un altro impianto
            raise ErroreUtente(f"Questo Word è già nell'archivio dei verbali ed è collegato all'impianto n. {gia} della stessa sede, "
                               "non a questo. Se è davvero il verbale di questo impianto, correggi prima il collegamento in "
                               "Gestione › Configurazione › Verbali di VerbalizzAI (Collegamenti); altrimenti carica il Word giusto.")
        pd = dict(altro["data"])
        pd.update({k: v for k, v in anagrafica.items() if k not in ("email_to", "email_cc") or not pd.get(k)})
        pd["sede_id"], pd["impianti"] = sede_id, {**(pd.get("impianti") or {}), modulo: impianto_id}
        pd["label"] = pd.get("address") or pd.get("label") or "Impianto"
        archivio.mutate(lambda c: archivio._put(c, "plant", pd, esito["plant_id"], action="plant_link"))
        with arc.scrittura() as s:
            registro.scrivi(s, utente=utente, azione="verbali.collega", oggetto_tipo="impianto", oggetto_id=impianto_id,
                            descrizione=f"Verbale precedente «{nome}» già importato in VerbalizzAI: impianto di VerbalizzAI collegato all'impianto n. {impianto_id}")
        note.append("Il Word era già stato importato dalla pagina dei verbali: quell'impianto ora è collegato a questo, con il suo storico.")
    elif esito.get("duplicate"):
        note.append("Questo Word era già stato caricato: si usa quello.")
    # La scheda dell'impianto del gestionale (date, periodicità, potenza, caratteristiche, elementi) si aggiorna con lo
    # stesso criterio del verbale caricato sulla verifica: mai all'indietro (un verbale più vecchio non sostituisce uno
    # stato più recente; una straordinaria non sposta le date). Il verbale resta com'è: è la fotografia di quel giorno.
    try:
        storico = archivio.get(esito["inspection_id"])["data"]
        letto_g = lettura_verbale.da_dati(storico)
        ultima = letto_g["data"] or importazione._data(storico.get("header", {}).get("start_date"))
        if ultima:
            prossima = letto_g["prossima"]
            with arc.scrittura() as s:
                x = s.get(Impianto, impianto_id)
                if prossima is None:
                    from ..anagrafica.servizio import scadenza

                    anni = 2 if x.tipologia == "esplosione" else (letto_g["periodicita"] or x.periodicita_anni)
                    prossima = scadenza(ultima, anni) if anni else None
                note += verifiche.aggiorna_impianto(s, utente, impianto_id, letto_g, ultima, letto_g["numero"], prossima, scheda=False)
        # R122: la scheda tecnica è quella di VerbalizzAI. Il verbale precedente la aggiorna se è più recente di quella;
        # la copia del gestionale si riallinea.
        destinazione = esito.get("plant_id") or plant_id   # con il doppione, l'impianto di VerbalizzAI appena collegato
        prima = (archivio.get(destinazione)["data"].get("profiles") or {}).get(modulo) or {}
        nota = scheda.adotta(archivio, destinazione, modulo, esito["inspection_id"], solo_se_piu_recente=True)
        if nota:
            note.append(nota)
        dopo = (archivio.get(destinazione)["data"].get("profiles") or {}).get(modulo) or {}
        # AD-REV-001 (0.12.8): le differenze fra il Word e la scheda tecnica si dicono, con l'esito
        diff = scheda.etichette_differenze(modulo, (esito.get("state_proposal") or {}).get("differences") or [])
        if dopo.get("source_id") == esito["inspection_id"] and prima.get("source_id") != esito["inspection_id"]:
            note.append("Scheda tecnica dell'impianto aggiornata con i dati di questo verbale" + (f" (cambiano: {diff})" if diff and prima else "")
                        + (": è il primo verbale dell'impianto, da confermare nella scheda." if not prima else "."))
        elif diff and prima:
            note.append(f"Il Word è precedente alla scheda tecnica dell'impianto (aggiornata al {prima.get('observed_date', '')}): la scheda non "
                        f"cambia e la bozza riparte da quella. Dati diversi nel Word: {diff}.")
        scheda.sincronizza_plant(archivio, arc, utente, destinazione)
    except ErroreUtente:
        raise
    except Exception:  # noqa: BLE001 — il Word è comunque archiviato come precedente; la scheda si aggiorna all'emissione
        note.append("Scheda dell'impianto del gestionale non aggiornata da questo Word (lettura incompleta): si aggiornerà all'emissione del nuovo verbale.")
    rifatta = False
    if bozza_id:
        try:
            attuale = archivio.get(bozza_id)
        except (KeyError, ValueError):
            attuale = None
        if attuale and attuale["data"].get("status") == "draft":
            archivio.delete_draft(bozza_id)
            rifatta = True
        with arc.scrittura() as s:
            verifiche.verifica_o_404(s, verifica_id).verbale_id = ""
    return {"precedente": precedente(archivio, arc, utente, verifica_id), "bozza_rifatta": rifatta, "note": note}
