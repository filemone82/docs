"""Scheda tecnica unica dell'impianto (R122, 0.12.7).

Decisione di Federico (11/10/2026): «una sola scheda tecnica per l'impianto». Tutti i campi del verbale sono attributi
dell'impianto, tranne esito, durata della verifica, persona presente e resistenza di terra (e, ovviamente, ciò che
cambia a ogni verifica: numero, date, motivo, strumenti, note, non conformità, valori misurati sugli elementi).
Il verbale precompilato ripropone l'ultimo aggiornamento.

VerbalizzAI fa già così: il verbale è la fotografia, la «Scheda impianto» (profilo dell'impianto per modulo) è lo stato
aggiornato da cui riparte la bozza successiva. Quindi:
- fa fede la scheda di VerbalizzAI; il gestionale non ne tiene una seconda versione;
- `Impianto.caratteristiche`, `potenza_kw` ed `ElementoImpianto` sono una copia di lettura (offerte, ricerche, elenchi)
  che si riallinea da sola dopo ogni operazione che può cambiare la scheda (`sincronizza_plant`);
- un Word caricato a mano su una verifica entra nell'archivio dei verbali e aggiorna la scheda come un'emissione
  (`adotta_word`), mai all'indietro (lo controlla VerbalizzAI).
VerbalizzAI non è modificato (R111): si usano solo le sue funzioni.
"""

from __future__ import annotations

import json
import logging
import re
from decimal import Decimal, InvalidOperation
from typing import Any

from sqlalchemy import select

from ...core.db import adesso
from ..anagrafica.modelli import Impianto
from ..verifiche import lettura_verbale
from ..verifiche.modelli import MODULO_PER_TIPOLOGIA, TIPI_ELEMENTO, ElementoImpianto

log = logging.getLogger(__name__)

TITOLI_M01 = {**dict(lettura_verbale.GRUPPI_M01), "ul": "Tensione limite di contatto (Ul)", "special": "Prescrizioni particolari",
              "at_app": "Guasti in alta tensione", "contact_app": "Tensioni di contatto"}
DESCRIZIONI = {"risk_note": "Valutazione del rischio: note", "lps_description": "Descrizione dell'LPS",
               "lps_int_note": "LPS interno: note", "spm_note": "SPM: note"}
ORIGINI = {"issued": "verbale emesso", "adopted": "adottata da un verbale", "rollback": "ripristinata dopo un annullamento",
           "manual_correction": "dati inseriti a mano", "import_proposal": "recuperata dallo storico importato",
           "migration": "recuperata dallo storico", "ultimo_verbale": "dall'ultimo verbale, scheda non ancora confermata"}


# ---------------------------------------------------------------- lettura


def voci(modulo: str, stato: dict) -> list[dict]:
    """Le voci leggibili della scheda (stesse etichette della scheda dell'impianto del gestionale)."""
    from ...terzi.verbalizzai import plantstate, wordio

    impianto, flags, prove = stato.get("plant") or {}, stato.get("flags") or {}, stato.get("tests") or {}
    out: list[dict] = []

    def aggiungi(etichetta: str, valore: Any) -> None:
        testo = str(valore or "").strip()
        if testo and testo != "/":
            out.append({"etichetta": etichetta, "valore": testo})

    if modulo == "M01":
        for chiave, etichetta in lettura_verbale.CAMPI_M01:
            valore = str(impianto.get(chiave) or "").strip()
            if chiave == "if_value" and valore and valore != "/":
                valore += " " + (impianto.get("if_unit") or "A")
            aggiungi(etichetta, valore)
        for gruppo in plantstate.groups("M01"):
            aggiungi(TITOLI_M01.get(gruppo, gruppo),
                     lettura_verbale._scelte(flags, gruppo, wordio.GROUPS.get(gruppo, []), wordio.LABELS.get(gruppo, [])))
    else:
        schema = plantstate.schema(modulo)
        for chiave in schema["plant_fields"]:
            aggiungi(lettura_verbale.CAMPI_ALTRI.get(chiave, chiave), impianto.get(chiave))
        for gruppo, spec in schema["groups"].items():
            aggiungi(lettura_verbale.etichette_gruppo(modulo, gruppo) if gruppo != "environment" else "Ambiente",
                     lettura_verbale._scelte(flags, gruppo, spec["options"], spec["labels"]))
        for chiave in schema["test_fields"]:
            aggiungi(DESCRIZIONI.get(chiave, chiave), prove.get(chiave))
    return out


def etichette_differenze(modulo: str, chiavi: list[str]) -> str:
    """Le differenze segnalate da VerbalizzAI («plant.power», «flags.systems», «samples»…) con le etichette della scheda."""
    campi = dict(lettura_verbale.CAMPI_M01) | lettura_verbale.CAMPI_ALTRI
    out = []
    for k in chiavi:
        parte, _, nome = k.partition(".")
        if parte == "plant":
            out.append(campi.get(nome, nome))
        elif parte == "flags":
            out.append(TITOLI_M01.get(nome) if modulo == "M01" else lettura_verbale.etichette_gruppo(modulo, nome))
        elif parte == "tests":
            out.append(DESCRIZIONI.get(nome, nome))
        elif k == "samples":
            out.append("elementi dell'impianto")
    return ", ".join(dict.fromkeys(x for x in out if x))


def elementi(stato: dict) -> list[dict]:
    return [{"tipo": s.get("kind", ""), "quadro": (s.get("board") or "")[:200], "nome": (s.get("name") or "")[:300],
             "occorrenza": int(s.get("occurrence") or 1), "attributi": s.get("attributes") or {}}
            for s in stato.get("samples") or [] if s.get("kind")]


def _numero_origine(archivio: Any, profilo: dict) -> str:
    sid = profilo.get("source_id")
    if not sid:
        return ""
    try:
        h = archivio.get(sid)["data"].get("header") or {}
    except (KeyError, ValueError):
        return ""
    return lettura_verbale.numero_normalizzato(h.get("number") or "")


def profilo_di(archivio: Any, p: dict, modulo: str) -> dict | None:
    """La scheda di VerbalizzAI per quel modulo. Un impianto con verbali ma senza scheda (archivi creati fuori dal
    flusso normale) usa l'ultimo verbale valido, che è anche ciò da cui VerbalizzAI farebbe ripartire la bozza."""
    profilo = (p["data"].get("profiles") or {}).get(modulo)
    if profilo:
        return profilo
    from ...terzi.verbalizzai import plantstate
    from .importazione import verbali_del_plant

    for w in verbali_del_plant(archivio, p["id"]):
        if (w["data"].get("module") or "M01") == modulo:
            return {"state": plantstate.extract(w["data"]), "revision": 0, "source_id": w["id"],
                    "observed_date": archivio._state_date(w["data"]), "confirmed": False, "origin": "ultimo_verbale"}
    return None


def plant_collegati(archivio: Any, sede_id: int, modulo: str, impianto_id: int) -> list[dict]:
    return [p for p in archivio.where("plant", "sede_id", sede_id)
            if (p["data"].get("impianti") or {}).get(modulo) == impianto_id and not p["data"].get("deleted")]


def verbali_validi(archivio: Any, plant_id: str, modulo: str) -> list[dict]:
    """Verbali storici o emessi, non annullati, di quel modulo: gli stessi che VerbalizzAI considera in `create_draft`."""
    return [x for x in archivio.where("inspection", "plant_id", plant_id)
            if archivio.module_of(x["data"]) == modulo and x["data"].get("status") != "annulled"
            and (x["data"].get("historical") or x["data"].get("status") == "issued")]


def _chiave_verbale(archivio: Any, x: dict) -> tuple:
    """Il criterio di VerbalizzAI (`create_draft`) per il verbale di riferimento: data della verifica (fine o verbale),
    poi aggiornamento, poi id."""
    return (archivio._state_date(x["data"]), x.get("updated_at") or "", x["id"])


def verbale_piu_recente(archivio: Any, plant_id: str, modulo: str) -> dict | None:
    """AD-REV-002 (0.12.8): il verbale da cui partirà la bozza. Il riquadro «Verbale precedente» usa lo stesso criterio,
    così mostra ciò che la bozza userà."""
    validi = verbali_validi(archivio, plant_id, modulo)
    return max(validi, key=lambda x: _chiave_verbale(archivio, x)) if validi else None


def principale(archivio: Any, collegati: list[dict], modulo: str) -> dict | None:
    """AD-REV-002 (0.12.8, completata nella 0.12.9): se più impianti di VerbalizzAI puntano allo stesso impianto, vale
    quello che contiene il verbale valido più recente secondo la stessa chiave completa di VerbalizzAI (data, poi
    aggiornamento, poi id) — anche a parità di data e con revisioni nello stesso giorno. Il numero dei verbali non conta;
    senza verbali vale l'impianto aggiornato per ultimo."""
    if not collegati:
        return None
    if len(collegati) == 1:
        return collegati[0]

    def chiave(p: dict) -> tuple:
        ultimo = verbale_piu_recente(archivio, p["id"], modulo)
        return (1, _chiave_verbale(archivio, ultimo)) if ultimo else (0, ("", p.get("updated_at") or "", p["id"]))

    return max(collegati, key=chiave)


def plant_di(archivio: Any, x: Impianto) -> dict | None:
    """L'impianto di VerbalizzAI collegato (senza crearlo)."""
    modulo = MODULO_PER_TIPOLOGIA.get(x.tipologia, "M01")
    return principale(archivio, plant_collegati(archivio, x.sede_id, modulo, x.id), modulo)


def stato_impianto(archivio: Any, arc: Any, utente: Any, impianto_id: int) -> dict:
    """La scheda tecnica da mostrare: quella di VerbalizzAI se l'impianto è collegato, altrimenti la copia del gestionale
    (impianti mai verificati con il gestionale, o dati di versioni precedenti)."""
    from ..verifiche import servizio as verifiche

    with arc.lettura() as s:
        x = s.get(Impianto, impianto_id)
        if x is None:
            from ...core.errori import ErroreUtente

            raise ErroreUtente("Impianto non trovato.", 404)
        modulo = MODULO_PER_TIPOLOGIA.get(x.tipologia, "M01")
        p = plant_di(archivio, x)
        cache = json.loads(x.caratteristiche or "{}")
        el_gestionale = verifiche.elementi_impianto(s, impianto_id)
    profilo = profilo_di(archivio, p, modulo) if p else None
    if p and profilo:
        if cache.get("plant_id") != p["id"] or cache.get("revisione") != profilo.get("revision"):
            try:  # la copia del gestionale è indietro (es. scheda cambiata da un ripristino): si riallinea
                sincronizza_plant(archivio, arc, utente, p["id"])
            except Exception:  # la scheda si mostra comunque, dalla fonte
                log.exception("Riallineamento della scheda tecnica non riuscito")
        st = profilo.get("state") or {}
        return {"fonte": "verbalizzai", "plant_id": p["id"], "modulo": modulo, "revisione": profilo.get("revision"),
                "data": profilo.get("observed_date", ""), "verbale": _numero_origine(archivio, profilo),
                "origine": ORIGINI.get(profilo.get("origin", ""), profilo.get("origin", "")),
                "confermata": bool(profilo.get("confirmed")), "da_riesaminare": bool(profilo.get("review_required")),
                "voci": voci(modulo, st),
                "elementi": [{**e, "tipo_testo": _tipo_testo(e["tipo"])} for e in elementi(st)]}
    return {"fonte": "gestionale" if cache else "", "plant_id": p["id"] if p else None, "modulo": modulo,
            "data": cache.get("data", ""), "verbale": cache.get("verbale", ""), "origine": "dall'ultimo verbale caricato" if cache else "",
            "confermata": bool(cache), "da_riesaminare": False, "voci": cache.get("voci") or [],
            "elementi": [e for e in el_gestionale if e["attivo"]]}


def _tipo_testo(tipo: str) -> str:
    return TIPI_ELEMENTO.get(tipo, tipo)


# ---------------------------------------------------------------- riallineamento della copia del gestionale


def _potenza(stato: dict) -> float | None:
    """Potenza in kW per le offerte: VerbalizzAI la scrive come «250 kW» (o «250 kVA», che non si converte)."""
    testo = str((stato.get("plant") or {}).get("power", "")).strip()
    m = re.fullmatch(r"(\d+(?:[.,]\d+)?)\s*(kW)?", testo, re.IGNORECASE)
    if not m:
        return None
    try:
        valore = Decimal(m.group(1).replace(",", "."))
    except InvalidOperation:
        return None
    return float(valore) if valore.is_finite() and valore >= 0 else None


def _altri_attributi(s: Any, x: Impianto, stato: dict) -> bool:
    """Cabine MT/BT e sottostazioni AT/MT (solo impianti oltre 1.000 V) se il valore è un numero intero; POD solo se
    l'impianto NEXUS non ne ha e il POD del verbale è valido e non appartiene già a un altro impianto (vincolo di
    unicità): un POD diverso da quelli registrati non sostituisce l'anagrafica, resta nel verbale."""
    from ..anagrafica.modelli import ImpiantoPod

    impianto = stato.get("plant") or {}
    cambiate = False
    if x.tipologia == "terra_at":
        for campo, attributo in (("cabins", "cabine_mt_bt"), ("stations", "sottostazioni_at_mt")):
            m = re.fullmatch(r"\s*(\d+)\s*", str(impianto.get(campo) or ""))
            if m and int(m.group(1)) != getattr(x, attributo):
                setattr(x, attributo, int(m.group(1)))
                cambiate = True
    if not x.pod:
        pod = re.sub(r"\s+", "", str(impianto.get("pod") or "")).upper()
        if re.fullmatch(r"IT\d{3}E\d{8}", pod) and s.scalar(select(ImpiantoPod.id).where(ImpiantoPod.pod == pod)) is None:
            x.pod.append(ImpiantoPod(pod=pod, ordine=0))
            cambiate = True
    return cambiate


def _scrivi(s: Any, archivio: Any, utente: Any, x: Impianto, plant_id: str, modulo: str, profilo: dict) -> bool:
    from ..anagrafica import servizio as anagrafica
    from ..registro import servizio as registro

    stato = profilo.get("state") or {}
    nuove = voci(modulo, stato)
    numero = _numero_origine(archivio, profilo)
    corrente = json.loads(x.caratteristiche or "{}")
    cache = {"fonte": "verbalizzai", "plant_id": plant_id, "revisione": profilo.get("revision"), "stato_tecnico": stato, "modulo": modulo,
             "verbale": numero, "data": profilo.get("observed_date", ""), "confermata": bool(profilo.get("confirmed")),
             "da_riesaminare": bool(profilo.get("review_required")), "origine": profilo.get("origin", ""), "voci": nuove}
    prima = anagrafica.dati_impianto(x)
    cambiate = corrente.get("voci") != nuove or corrente.get("stato_tecnico") != stato
    x.caratteristiche = json.dumps(cache, ensure_ascii=False)
    if x.tipologia in ("terra_bt", "terra_at"):
        kw = _potenza(stato)
        if kw is not None and kw != x.potenza_kw:
            x.potenza_kw, cambiate = kw, True
        # rc8 (punto 4, D1): anche cabine, sottostazioni e POD tornano all'impianto NEXUS dalla scheda aggiornata
        cambiate = _altri_attributi(s, x, stato) or cambiate
    # elementi: la scheda è il censimento completo (non un campione): quelli che non ci sono più restano «non attivi»
    esistenti = {(e.tipo, e.quadro, e.nome, e.occorrenza): e for e in
                 s.execute(select(ElementoImpianto).where(ElementoImpianto.impianto_id == x.id)).scalars()}
    visti = set()
    for el in elementi(stato) if modulo == "M01" else []:
        chiave = (el["tipo"], el["quadro"], el["nome"], el["occorrenza"])
        if chiave in visti:
            continue
        visti.add(chiave)
        attributi = json.dumps(el["attributi"], ensure_ascii=False)
        e = esistenti.get(chiave)
        if e is None:
            e = ElementoImpianto(impianto_id=x.id, tipo=el["tipo"], quadro=el["quadro"], nome=el["nome"], occorrenza=el["occorrenza"])
            s.add(e)
            cambiate = True
        elif e.attributi != attributi or not e.attivo:
            cambiate = True
        e.attributi, e.attivo, e.dal_verbale, e.aggiornato_il = attributi, True, numero or e.dal_verbale or "", adesso()
    if modulo == "M01":
        for chiave, e in esistenti.items():
            if chiave not in visti and e.attivo:
                e.attivo, cambiate = False, True
    if cambiate:
        anagrafica._modificato(x, utente)
        registro.scrivi(s, utente=utente, azione="impianto.scheda_tecnica", oggetto_tipo="impianto", oggetto_id=x.id,
                        descrizione=f"Impianto n. {x.id}: scheda tecnica riallineata a quella di VerbalizzAI"
                                    f" ({ORIGINI.get(profilo.get('origin', ''), 'aggiornata')}{', ' + numero if numero else ''})",
                        dettagli={"modifiche": registro.differenze(prima, anagrafica.dati_impianto(x)), "elementi": len(visti)})
    return cambiate


def sincronizza_plant(archivio: Any, arc: Any, utente: Any, plant_id: str) -> list[int]:
    """Riporta nel gestionale la scheda di un impianto di VerbalizzAI (per ogni modulo collegato). Idempotente."""
    try:
        p = archivio.get(plant_id)
    except (KeyError, ValueError):
        return []
    if p["kind"] != "plant" or p["data"].get("deleted"):
        return []
    mappa = p["data"].get("impianti") or {}
    aggiornati = []
    with arc.scrittura() as s:
        for modulo, impianto_id in mappa.items():
            x = s.get(Impianto, impianto_id) if isinstance(impianto_id, int) else None
            profilo = profilo_di(archivio, p, modulo) if x is not None else None
            if x is None or not profilo or MODULO_PER_TIPOLOGIA.get(x.tipologia, "M01") != modulo:
                continue
            scelto = principale(archivio, plant_collegati(archivio, x.sede_id, modulo, x.id), modulo)
            if scelto is not None and scelto["id"] != plant_id:
                continue
            if _scrivi(s, archivio, utente, x, plant_id, modulo, profilo):
                aggiornati.append(x.id)
    return aggiornati


def sincronizza_tutte(archivio: Any, arc: Any, utente: Any) -> dict:
    """Riallinea la copia di tutti gli impianti collegati (dopo un ripristino o un aggiornamento di versione)."""
    aggiornati, errori = [], []
    for p in archivio.all("plant"):
        if not p["data"].get("impianti"):
            continue
        try:
            aggiornati += sincronizza_plant(archivio, arc, utente, p["id"])
        except Exception as e:  # noqa: BLE001
            errori.append({"plant_id": p["id"], "errore": str(e)})
    return {"aggiornati": aggiornati, "errori": errori}


def plant_coinvolti(archivio: Any, richiesta: Any, risposta: Any) -> set[str]:
    """Impianti di VerbalizzAI toccati da un'operazione: dal corpo della richiesta e dalla risposta."""
    ids: set[str] = set()
    for d in (richiesta, risposta):
        if not isinstance(d, dict):
            continue
        for k in ("plant_id",):
            if isinstance(d.get(k), str):
                ids.add(d[k])
        for k in ("id", "inspection_id"):
            if isinstance(d.get(k), str):
                try:
                    o = archivio.get(d[k])
                except (KeyError, ValueError):
                    continue
                if o["kind"] == "plant":
                    ids.add(o["id"])
                elif isinstance(o["data"].get("plant_id"), str):
                    ids.add(o["data"]["plant_id"])
        piante = d.get("plant")
        if isinstance(piante, dict) and isinstance(piante.get("id"), str):
            ids.add(piante["id"])
        oggetto = d.get("item")
        if isinstance(oggetto, dict) and isinstance((oggetto.get("data") or {}).get("plant_id"), str):
            ids.add(oggetto["data"]["plant_id"])
    return ids


# ---------------------------------------------------------------- Word caricato a mano


def adotta(archivio: Any, plant_id: str, modulo: str, inspection_id: str, solo_se_piu_recente: bool = False) -> str:
    """Adotta come scheda dell'impianto lo stato del verbale indicato (funzione di VerbalizzAI: controlla date e concorrenza).
    Restituisce una nota per l'utente ('' se la scheda è aggiornata o lo era già)."""
    st = archivio.plant_state(plant_id, modulo)
    profilo = st.get("profile") or {}
    if profilo.get("source_id") == inspection_id and (profilo.get("confirmed") or solo_se_piu_recente):
        return ""  # già la scheda (uno storico importato resta «da confermare», come in VerbalizzAI)
    if solo_se_piu_recente and profilo:
        d = archivio.get(inspection_id)["data"]
        if archivio._state_date(d) <= (profilo.get("observed_date") or "") and profilo.get("source_id") != inspection_id:
            return ""
    try:
        archivio.adopt_plant_state(plant_id, inspection_id, st["stamp"], confirmed=True)
    except ValueError as e:  # verbale precedente allo stato della scheda, o revisione: la scheda resta com'è
        return f"Scheda tecnica dell'impianto non cambiata: {e}"
    return ""


def adotta_word(archivio: Any, arc: Any, utente: Any, impianto_id: int, contenuto: bytes, nome: str) -> list[str]:
    """Word del verbale caricato a mano su una verifica (es. fatto con il VerbalizzAI esterno): entra nell'archivio dei
    verbali sull'impianto collegato e aggiorna la scheda come un'emissione; poi la copia del gestionale si riallinea."""
    from ...terzi.verbalizzai.wordio import parse_word
    from .servizio import assicura_plant, dati_plant

    with arc.lettura() as s:
        x = s.get(Impianto, impianto_id)
        modulo = MODULO_PER_TIPOLOGIA.get(x.tipologia, "M01")
        archivio.set_actor(getattr(utente, "username", "") or getattr(utente, "nome", ""))
        plant_id = assicura_plant(archivio, s, impianto_id)
        anagrafica = dati_plant(s, x)
    letto = parse_word(contenuto, nome or "verbale.docx")
    if (letto.get("module") or "M01") != modulo:
        return []
    pl = letto.setdefault("plant", {})
    for k in ("client_name", "address", "site_name"):
        pl[k] = pl.get(k) or anagrafica[k]
    esito = archivio.import_word(contenuto, nome or "verbale.docx", letto, plant_id)
    note = []
    if esito.get("duplicate") and esito.get("plant_id") != plant_id:
        note.append("Il Word è già nell'archivio dei verbali su un altro impianto di VerbalizzAI: scheda tecnica non aggiornata da questo caricamento.")
    else:
        nota = adotta(archivio, plant_id, modulo, esito["inspection_id"])
        if nota:
            note.append(nota)
    sincronizza_plant(archivio, arc, utente, plant_id)
    return note
