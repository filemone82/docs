"""Registro delle operazioni: griglia, dettaglio, verifica della catena."""

from __future__ import annotations

import json

from fastapi import APIRouter, Depends

from ...core.date import iso_locale
from ...core.db import Archivio
from ...core.errori import NonTrovato
from ...core.griglia import Colonna, Griglia, registra
from ...web.dipendenze import archivio, richiede
from ..utenti.accesso import UtenteCorrente
from . import servizio
from .modelli import RegistroOperazione as R

router = APIRouter(prefix="/api/registro")

registra(Griglia(
    codice="registro",
    titolo="Registro operazioni",
    permesso="sistema.registro",
    da=lambda: R.__table__,
    ordine_predefinito=[("quando", "desc")],
    colonne=[
        Colonna("id", "N.", "numero", R.id, larghezza=80),
        Colonna("quando", "Data e ora", "dataora", R.quando, larghezza=150),
        Colonna("utente_nome", "Utente", "testo", R.utente_nome, larghezza=170),
        Colonna("azione", "Azione", "testo", R.azione, larghezza=170, descrizione="Codice dell'operazione, es. utente.crea"),
        Colonna("descrizione", "Descrizione", "testo", R.descrizione, larghezza=520),
        Colonna("oggetto_tipo", "Tipo di oggetto", "testo", R.oggetto_tipo, visibile=False, larghezza=120),
        Colonna("oggetto_id", "Oggetto", "testo", R.oggetto_id, visibile=False, larghezza=140),
    ],
))


@router.get("/{riga_id}")
def dettaglio(riga_id: int, _u: UtenteCorrente = Depends(richiede("sistema.registro")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        r = s.get(R, riga_id)
        if r is None:
            raise NonTrovato("Riga del registro non trovata.")
        return {"id": r.id, "quando": iso_locale(r.quando), "utente": r.utente_nome, "azione": r.azione,
                "oggetto_tipo": r.oggetto_tipo, "oggetto_id": r.oggetto_id, "descrizione": r.descrizione,
                "dettagli": json.loads(r.dettagli or "{}"), "impronta": r.impronta}


@router.post("/verifica")
def verifica(_u: UtenteCorrente = Depends(richiede("sistema.backup")), arc: Archivio = Depends(archivio)) -> dict:
    with arc.lettura() as s:
        return servizio.verifica_catena(s)
