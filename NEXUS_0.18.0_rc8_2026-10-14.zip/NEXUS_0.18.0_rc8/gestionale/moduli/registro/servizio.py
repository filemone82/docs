"""Scrittura e verifica del registro delle operazioni (a catena di impronte)."""

from __future__ import annotations

import hashlib
import json
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...core.db import adesso
from .modelli import RegistroOperazione

IMPRONTA_INIZIALE = "0" * 64


def _impronta(precedente: str, riga: RegistroOperazione) -> str:
    contenuto = json.dumps(
        [
            precedente,
            riga.quando.isoformat(timespec="microseconds"),
            riga.utente_id,
            riga.utente_nome,
            riga.azione,
            riga.oggetto_tipo,
            riga.oggetto_id,
            riga.descrizione,
            riga.dettagli,
        ],
        ensure_ascii=False,
        separators=(",", ":"),
    )
    return hashlib.sha256(contenuto.encode("utf-8")).hexdigest()


def scrivi(
    s: Session,
    *,
    utente: Any | None,
    azione: str,
    descrizione: str,
    oggetto_tipo: str = "",
    oggetto_id: Any = "",
    dettagli: dict | None = None,
) -> RegistroOperazione:
    """Aggiunge una riga al registro. Va chiamata dentro `Archivio.scrittura()` (un solo scrittore)."""
    ultima = s.execute(select(RegistroOperazione.impronta).order_by(RegistroOperazione.id.desc()).limit(1)).scalar()
    precedente = ultima or IMPRONTA_INIZIALE
    riga = RegistroOperazione(
        quando=adesso(),
        utente_id=getattr(utente, "id", None),
        utente_nome=getattr(utente, "nome", "") or ("Sistema" if utente is None else ""),
        azione=azione,
        oggetto_tipo=oggetto_tipo,
        oggetto_id=str(oggetto_id or ""),
        descrizione=descrizione,
        dettagli=json.dumps(dettagli or {}, ensure_ascii=False, default=str, sort_keys=True),
        impronta_precedente=precedente,
    )
    riga.impronta = _impronta(precedente, riga)
    s.add(riga)
    s.flush()
    return riga


def verifica_catena(s: Session) -> dict:
    """Ricalcola tutte le impronte. Restituisce l'esito e, se rotto, il primo punto di rottura."""
    precedente = IMPRONTA_INIZIALE
    controllate = 0
    for riga in s.execute(select(RegistroOperazione).order_by(RegistroOperazione.id)).scalars().yield_per(5000):
        if riga.impronta_precedente != precedente or _impronta(precedente, riga) != riga.impronta:
            return {"integro": False, "righe_controllate": controllate, "prima_riga_alterata": riga.id}
        precedente = riga.impronta
        controllate += 1
    return {"integro": True, "righe_controllate": controllate, "prima_riga_alterata": None}


def differenze(prima: dict, dopo: dict) -> dict:
    """Solo i campi cambiati, nella forma {campo: [prima, dopo]}."""
    return {k: [prima.get(k), dopo.get(k)] for k in sorted(set(prima) | set(dopo)) if prima.get(k) != dopo.get(k)}
