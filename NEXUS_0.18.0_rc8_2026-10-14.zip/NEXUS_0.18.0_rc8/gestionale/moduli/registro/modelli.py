"""Registro delle operazioni: solo in aggiunta, a catena di impronte (convenzione 03 § 3).

Ogni riga contiene l'impronta SHA-256 della riga precedente: se qualcuno modificasse il database
dall'esterno, la verifica della catena lo scoprirebbe. Il database stesso rifiuta modifiche e
cancellazioni (trigger creati dalla migrazione iniziale).
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ...core.db import Base, adesso


class RegistroOperazione(Base):
    __tablename__ = "registro_operazioni"
    __table_args__ = (Index("ix_registro_operazioni_oggetto", "oggetto_tipo", "oggetto_id"),)  # storico di una scheda

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    quando: Mapped[datetime] = mapped_column(DateTime, default=adesso, index=True)
    utente_id: Mapped[int | None] = mapped_column(ForeignKey("utenti.id", ondelete="RESTRICT"), nullable=True, index=True)
    utente_nome: Mapped[str] = mapped_column(String(120), default="")  # come si chiamava l'utente in quel momento
    azione: Mapped[str] = mapped_column(String(60), index=True)
    oggetto_tipo: Mapped[str] = mapped_column(String(40), default="")
    oggetto_id: Mapped[str] = mapped_column(String(60), default="")
    descrizione: Mapped[str] = mapped_column(Text)
    dettagli: Mapped[str] = mapped_column(Text, default="{}")  # JSON: prima/dopo, filtri, ecc.
    impronta_precedente: Mapped[str] = mapped_column(String(64))
    impronta: Mapped[str] = mapped_column(String(64))
