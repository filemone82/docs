"""Importazione dal database del gestionale di Garda (AD_dpr, database «ingecert») — 0.7.1, richiesta di Federico del 08/10/2026.

Si parte dal dump completo (struttura e dati) e si popola un archivio NUOVO del Gestionale AD:
- utenti (DISATTIVATI: le password di Garda non si possono riusare; l'amministratore li riattiva con una password provvisoria),
  commerciali, modalità di pagamento e aliquote IVA;
- clienti, sedi operative, impianti (con POD), tutti con il codice di Garda («Riferimento nel gestionale attuale»);
- preventivi e righe (stessi numeri, stati, tariffe e sconti; contributo INAIL 5% e indennità di trasferta come righe «a corpo»,
  così il totale coincide con quello di Garda), riesame del contratto;
- verifiche (stessi numeri di verbale VP/VS, stati, verificatore, esito, date, riesame del verbale). I PDF dei verbali restano
  nell'archivio di Garda (S3): qui c'è il nome del file. Le fatture arriveranno con la fase 6: le verifiche già fatturate in
  Garda lo dicono nelle note.

I collegamenti si fanno con i CODICI INTERNI di Garda (non per nome). I dati dubbi non fermano nulla: finiscono in
«Da controllare» (come l'importazione da Excel, D46). Le numerazioni proseguono da sole dall'ultimo numero importato (D76).
Nessun dato viene modificato nel database di Garda: si legge solo il dump.
"""

from __future__ import annotations

import json
import re
import secrets
from collections import Counter, defaultdict
from datetime import date, datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ...core import validazioni as v
from ...core.sicurezza import hash_password
from ..anagrafica import origini
from ..anagrafica.importazione import Piano, _indirizzo, _testo
from ..anagrafica.modelli import Cliente, Commerciale, ElencoValore, Impianto, ImpiantoPod, Sede
from ..preventivi.modelli import Preventivo, RigaPreventivo, Riesame
from ..registro import servizio as registro
from ..utenti.modelli import Ruolo, Utente
from ..verifiche import lettura_verbale
from ..verifiche.modelli import MODULO_PER_TIPOLOGIA, Verifica

TABELLE = {"clienti", "clienti_sedi_operative", "impianti", "preventivi", "preventivi_righe", "verifiche", "verifiche_verbale",
           "utenti", "ruoli", "tipi_pagamento", "tipi_pagamento_scadenze", "iva", "nazioni", "gi_numerators"}
TIPOLOGIE = {"area 1": "scariche", "area 2": "terra_bt", "area 3": "terra_at", "area 4": "esplosione"}
TIPOLOGIE_TESTO = {"scariche": "Scariche atmosferiche", "terra_bt": "Messa a terra fino a 1.000 V", "terra_at": "Messa a terra oltre 1.000 V",
                   "esplosione": "Luoghi con pericolo di esplosione"}
GABBIA = {"si100": "fino_100", "si350": "da_101_a_350", "sioltre350": "oltre_350"}
STATI_PREVENTIVO = {"creato": "creato", "inviato": "inviato", "accettato": "accettato_totalmente",
                    "accettato_parzialmente": "accettato_parzialmente", "rifiutato": "rifiutato", "annullato": "annullato"}
STATI_RIGA = {"da_accettare": "in_attesa", "accettata": "accettata", "rifiutata": "rifiutata"}
RUOLI = {"amministratore": "amministratore", "responsabile tecnico": "responsabile_tecnico", "sostituto responsabile tecnico": "responsabile_tecnico",
         "tecnico": "tecnico", "referente commerciale": "segreteria"}
NOME_IMPORTAZIONE = "Importazione da Garda"


# ---------------------------------------------------------------- strumenti


def _b(x: Any) -> bool:
    return str(x or "").upper() in ("T", "1", "TRUE", "S", "SI")


def _data(x: Any) -> date | None:
    t = str(x or "")[:10]
    try:
        return date.fromisoformat(t) if t and not t.startswith("0000") else None
    except ValueError:
        return None


def _dataora(x: Any) -> datetime | None:
    t = str(x or "")
    try:
        return datetime.fromisoformat(t) if t and not t.startswith("0000") else None
    except ValueError:
        d = _data(t)
        return datetime(d.year, d.month, d.day) if d else None


def _centesimi(x: Any) -> int:
    try:
        return int(round(float(x or 0) * 100))
    except (TypeError, ValueError):
        return 0


def _numero(x: Any) -> int | None:
    try:
        return int(x) if x not in (None, "") else None
    except (TypeError, ValueError):
        return None


def _avvisi(d: dict) -> str:
    return "\n".join(f"Importazione da Garda: {a}" for a in d.get("avvisi", []))


def _nome_utente(u: dict) -> str:
    return " ".join(x for x in (_testo(u.get("cognome"), 60), _testo(u.get("nome"), 60)) if x) or _testo(u.get("utente"), 120)


# ---------------------------------------------------------------- importazione


class Importazione:
    def __init__(self, s: Session, dati: dict[str, list[dict]]) -> None:
        self.s, self.d = s, dati
        self.piano = Piano()               # raccoglie le segnalazioni «da controllare»
        self.cache: dict = {}
        self.conta: Counter = Counter()
        self.quadratura: list[str] = []
        self.utenti: dict[int, Utente] = {}
        self.commerciali: dict[int, Commerciale] = {}
        self.clienti: dict[int, Cliente] = {}
        self.sedi: dict[int, Sede] = {}
        self.impianti: dict[int, Impianto] = {}
        self.preventivi: dict[int, Preventivo] = {}
        self.righe: dict[int, RigaPreventivo] = {}
        self.verifiche: dict[int, Verifica] = {}
        self.pagamenti = {r["id"]: _testo(r.get("nome_pagamento"), 200) for r in dati.get("tipi_pagamento", [])}
        # 0.14: regole delle modalità (codice MP, rate, fine mese, spostamento, salda subito, predefinita)
        rate: dict[Any, list] = {}
        for q in sorted(dati.get("tipi_pagamento_scadenze", []), key=lambda q: (_numero(q.get("giorni")) or 0, q.get("id") or 0)):
            rate.setdefault(q.get("tipo_pagamento"), []).append(
                {"giorni": _numero(q.get("giorni")) or 0, "percentuale": str(q.get("perc_totale") or "100"), "fine_mese": _b(q.get("fine_mese"))})
        self.regole_pagamento = {r["id"]: {"mp": str(r.get("modalita") or "MP05"), "rate": rate.get(r["id"]) or
                                           [{"giorni": 0, "percentuale": "100", "fine_mese": False}],
                                           "fm_paga_dopo": _numero(r.get("fm_paga_dopo")) or None,
                                           "sposta_scadenze": _b(r.get("sposta_scadenze")), "salda_subito": _b(r.get("salda_subito")),
                                           "predefinito": _b(r.get("predefinito"))}
                                 for r in dati.get("tipi_pagamento", [])}
        self.nazioni = {r["id"]: (r.get("codice_iso_alpha2") or "IT")[:2].upper() for r in dati.get("nazioni", [])}
        self.iva = {r["id"]: r for r in dati.get("iva", [])}
        self.utenti_garda = {r["id"]: r for r in dati.get("utenti", [])}

    def avviso(self, d: dict, entita: str, nome: str, testo: str) -> None:
        self.piano.avviso(d, entita, nome, testo)

    # ---- utenti, commerciali, elenchi
    def importa_utenti(self) -> None:
        ruoli_garda = {r["id"]: str(r.get("ruolo") or "").strip().lower() for r in self.d.get("ruoli", [])}
        ruoli = {r.codice: r for r in self.s.execute(select(Ruolo)).scalars()}
        usati = {u.username for u in self.s.execute(select(Utente)).scalars()}
        for u in self.d.get("utenti", []):
            email = _testo(u.get("utente"), 200)
            if email.lower().endswith("@gardainformatica.it"):
                self.conta["utenti di Garda Informatica non importati"] += 1
                continue
            base = re.sub(r"[^a-z0-9.-]", "", email.split("@")[0].lower())[:50] or f"utente{u['id']}"
            base = base if len(base) >= 3 else f"{base}{u['id']}"
            nome_utente, n = base, 2
            while nome_utente in usati:
                nome_utente, n = f"{base}{n}", n + 1
            usati.add(nome_utente)
            codice = RUOLI.get(ruoli_garda.get(u.get("ruolo"), ""), "segreteria")
            x = Utente(username=nome_utente, nome=_nome_utente(u)[:120], email=email if "@" in email else "", ruolo_id=ruoli[codice].id,
                       attivo=False, password_hash=hash_password(secrets.token_urlsafe(24), 1000), cambio_password_richiesto=True)
            self.s.add(x)
            self.s.flush()
            self.utenti[u["id"]] = x
            self.conta["utenti (disattivati)"] += 1

    def commerciale(self, utente_garda: Any) -> Commerciale | None:
        uid = _numero(utente_garda)
        if uid is None or uid not in self.utenti_garda:
            return None
        if uid not in self.commerciali:
            g = self.utenti_garda[uid]
            nome = _nome_utente(g)[:120]
            esistente = self.s.execute(select(Commerciale).where(Commerciale.nome == nome)).scalar()
            if esistente is None:
                esistente = Commerciale(nome=nome, email=_testo(g.get("utente"), 200) if "@" in str(g.get("utente")) else "",
                                        utente_id=self.utenti[uid].id if uid in self.utenti else None, note="Importato da Garda",
                                        ambito_dpr=True)  # C16: i commerciali di ingecert sono AD_DPR
                self.s.add(esistente)
                self.s.flush()
                self.conta["commerciali"] += 1
            self.commerciali[uid] = esistente
        return self.commerciali[uid]

    def _elenco(self, elenco: str, descrizione: str, codice: str = "", percentuale: int | None = None) -> int | None:
        if not descrizione:
            return None
        x = self.s.execute(select(ElencoValore).where(ElencoValore.elenco == elenco, ElencoValore.descrizione == descrizione[:200])).scalar()
        if x is None:
            ordine = 100 + self.conta[f"nuove voci {elenco}"]
            x = ElencoValore(elenco=elenco, descrizione=descrizione[:200], codice=codice[:20], percentuale=percentuale, ordine=ordine,
                             creato_da=NOME_IMPORTAZIONE, modificato_da=NOME_IMPORTAZIONE)
            self.s.add(x)
            self.s.flush()
            self.conta[f"nuove voci {elenco}"] += 1
        return x.id

    def _nome_modalita(self, garda_id: Any) -> str:
        if garda_id:
            self._modalita(garda_id)
        return self.pagamenti.get(garda_id, "")

    def _modalita(self, garda_id: Any) -> int | None:
        """Modalità di pagamento con le regole di Garda (0.14), solo se la voce non ne ha già."""
        import json

        from ..finanza import pagamenti
        id_ = self._elenco("modalita_pagamento", self.pagamenti.get(garda_id, ""))
        regole = self.regole_pagamento.get(garda_id)
        if id_ and regole:
            x = self.s.get(ElencoValore, id_)
            if not json.loads(x.regole_json or "{}"):
                try:
                    x.regole_json = json.dumps(pagamenti.valida(regole))
                except Exception as e:  # noqa: BLE001 - regola di Garda incoerente: si segnala e resta quella dal nome
                    self.conta["modalità di pagamento con regole da controllare"] += 1
                    self.note_modalita = getattr(self, "note_modalita", []) + [f"{x.descrizione}: {e}"]
        return id_

    # ---- clienti
    def importa_clienti(self) -> None:
        piva_viste: dict[str, int] = {}
        for r in self.d.get("clienti", []):
            nome = _testo(r.get("rag_soc"), 250) or f"Cliente {r['id']} (senza nome in Garda)"
            d: dict[str, Any] = {"avvisi": []}
            _indirizzo(self.s, self.piano, self.cache, d,
                       {"indirizzo": r.get("indirizzo"), "comune": r.get("comune"), "provincia": r.get("prov"), "cap": r.get("cap"),
                        "regione": r.get("regione")}, "Cliente", nome)
            piva = v.recupera_numero(r.get("p_iva")) if _testo(r.get("p_iva")) else ""
            cf = v.recupera_numero(r.get("cod_fis")) if _testo(r.get("cod_fis")) else ""
            cf = cf.upper()
            if piva and not v.partita_iva_valida(piva):
                self.avviso(d, "Cliente", nome, f"partita IVA «{piva}» non valida")
            if cf and not v.codice_fiscale_valido(cf):
                self.avviso(d, "Cliente", nome, f"codice fiscale «{cf}» non valido")
            if not cf:
                self.avviso(d, "Cliente", nome, "manca il codice fiscale (obbligatorio)" + (": spesso coincide con la partita IVA" if piva else ""))
            sdi_grezzo = re.sub(r"\s", "", _testo(r.get("sdi_pec"), 200))
            for numero in {piva, cf} - {""}:
                if numero in piva_viste and piva_viste[numero] != r["id"]:
                    self.avviso(d, "Cliente", nome, f"stessa P.IVA/CF {numero} di un altro cliente (codice Garda {piva_viste[numero]}): "
                                                    "doppione o ufficio diverso dello stesso ente")
                piva_viste.setdefault(numero, r["id"])
            email = "; ".join(v.dividi_email(r.get("email")))
            if email and not v.email_valide(email):
                self.avviso(d, "Cliente", nome, f"email «{email}» non valida")
            pec, sdi = _testo(r.get("pec"), 200), sdi_grezzo.upper()
            if "@" in sdi_grezzo:
                pec, sdi = pec or sdi_grezzo.lower(), ""
            if sdi in ("0", "000", "NAN", "NONE"):  # «nan»: residuo di una vecchia importazione in Garda
                sdi = ""
            # «0000000» scritto in Garda è voluto (fattura nel cassetto fiscale del cliente): si conserva
            if sdi and not re.fullmatch(r"[A-Z0-9]{6,7}", sdi):
                self.avviso(d, "Cliente", nome, f"codice SDI «{sdi}» non valido")
                sdi = ""
            if pec and not v.email_valide(pec):
                self.avviso(d, "Cliente", nome, f"PEC «{pec}» non valida")
            if not sdi and not pec:
                self.avviso(d, "Cliente", nome, "codice SDI vuoto in Garda e nessuna PEC: per la fattura elettronica scrivi il codice SDI, la PEC o 0000000")
            iva = self.iva.get(r.get("iva")) or {}
            aliquota = _testo(iva.get("descrizione"), 200)
            aliquota_id = self._elenco("aliquota_iva", aliquota, _testo(iva.get("codice"), 20),
                                       _centesimi(iva.get("perc_iva")) if iva.get("perc_iva") is not None else None) if aliquota else None
            pagamento_id = self._modalita(r.get("pagamento")) if r.get("pagamento") else None
            rit = _testo(r.get("rit_acc_str"), 30)
            ritenuta = {"4%": 400, "20%": 2000}.get(rit)
            note = _testo(r.get("note"), 4000)
            if rit and ritenuta is None:
                note = (note + "\n" if note else "") + f"Ritenuta d'acconto in Garda: {rit}"
                self.avviso(d, "Cliente", nome, f"ritenuta d'acconto «{rit}» da controllare")
            classe = str(iva.get("classe_iva") or "").lower() + " " + aliquota.lower()
            if "scission" in classe or "split" in classe or len(sdi) == 6:
                tipo = "pa"
            elif "condomin" in nome.lower():
                tipo = "condominio"
            elif len(cf) == 16 and not piva:
                tipo = "persona_fisica"
            else:
                tipo = "privato"
            comm = self.commerciale(r.get("referente_commerciale"))
            c = Cliente(ragione_sociale=nome, tipo=tipo, nazione=self.nazioni.get(r.get("nazione"), "IT"),
                        indirizzo=d["indirizzo"], comune=d["comune"], cap=d["cap"], provincia=d["provincia"], regione=d["regione"],
                        comune_istat=d.get("comune_istat"), partita_iva=piva, codice_fiscale=cf, email_verbali=email[:500], email_fatture=email[:500],
                        pec=pec, codice_sdi=sdi, riferimento_amministrazione=_testo(r.get("rif_amministrazione"), 20),
                        commerciale_id=comm.id if comm else None, referente_nome=_testo(r.get("nome_referente"), 120),
                        referente_email="; ".join(v.dividi_email(r.get("email_ref")))[:200],
                        referente_telefono=v.normalizza_telefono(r.get("tel_ref")), banca=_testo(r.get("istituto_finanziario"), 120),
                        iban=re.sub(r"\s", "", _testo(r.get("iban"), 60)).upper()[:34], dichiarazione_intento=_b(r.get("dich_intento")),
                        dichiarazione_numero=_testo(r.get("dich_intento_n"), 60), dichiarazione_data=_data(r.get("dich_intento_data")),
                        ritenuta_percentuale=ritenuta, modalita_pagamento_id=pagamento_id, aliquota_iva_id=aliquota_id, note=note,
                        avvisi=_avvisi(d), codice_esterno=str(r["id"]), creato_da=NOME_IMPORTAZIONE, modificato_da=NOME_IMPORTAZIONE)
            self.s.add(c)
            self.clienti[r["id"]] = c
        self.s.flush()
        self.conta["clienti"] = len(self.clienti)

    # ---- sedi
    def importa_sedi(self) -> None:
        for r in self.d.get("clienti_sedi_operative", []):
            c = self.clienti.get(r.get("cliente"))
            nome = _testo(r.get("nome_sede"), 300)
            d: dict[str, Any] = {"avvisi": []}
            if c is None:
                self.piano.problemi.append(_problema("Sede", nome or str(r["id"]), "cliente inesistente in Garda: non importata"))
                continue
            if not nome:
                nome = _testo(r.get("indirizzo"), 300) or f"Sede {r['id']}"
                self.avviso(d, "Sede", nome, "sede senza denominazione in Garda: usato l'indirizzo")
            _indirizzo(self.s, self.piano, self.cache, d,
                       {"indirizzo": r.get("indirizzo"), "comune": r.get("comune"), "provincia": r.get("prov"), "cap": r.get("cap"),
                        "regione": r.get("regione")}, "Sede", nome)
            x = Sede(cliente_id=c.id, denominazione=nome, indirizzo=d["indirizzo"], comune=d["comune"], cap=d["cap"], provincia=d["provincia"],
                     regione=d["regione"], comune_istat=d.get("comune_istat"), referente_nome=_testo(r.get("nome_referente"), 120),
                     referente_email="; ".join(v.dividi_email(r.get("email_ref")))[:200], referente_telefono=v.normalizza_telefono(r.get("tel_ref")),
                     note=_testo(r.get("note"), 4000), avvisi=_avvisi(d), codice_esterno=str(r["id"]),
                     creato_da=NOME_IMPORTAZIONE, modificato_da=NOME_IMPORTAZIONE)
            self.s.add(x)
            self.sedi[r["id"]] = x
        self.s.flush()
        self.conta["sedi"] = len(self.sedi)

    # ---- impianti
    def importa_impianti(self) -> None:
        verbali = {r["id"]: r for r in self.d.get("verifiche", [])}
        pod_visti: dict[str, str] = {}
        for r in self.d.get("impianti", []):
            nome = f"impianto {r['id']}"
            sede = self.sedi.get(r.get("sede_operativa"))
            tip = TIPOLOGIE.get(str(r.get("tipo_impianto") or ""))
            if sede is None or tip is None:
                self.piano.problemi.append(_problema("Impianto", nome, "senza sede valida in Garda: non importato" if sede is None
                                                     else f"tipologia «{r.get('tipo_impianto')}» sconosciuta: non importato"))
                continue
            d: dict[str, Any] = {"avvisi": []}
            terra = tip in ("terra_bt", "terra_at")
            potenza = r.get("pot_impianto")
            potenza = float(potenza) if potenza not in (None, "") else None
            if terra and not potenza:
                self.avviso(d, "Impianto", nome, "potenza mancante o zero (serve per la tariffa)")
            cabine, sottost = _numero(r.get("n_cab_trasf_mt_bt")) or None, _numero(r.get("n_sott_at_mt")) or None
            if tip == "terra_bt" and (cabine or sottost):
                self.avviso(d, "Impianto", nome, f"fino a 1.000 V ma con cabine MT/BT ({cabine or 0}) o sottostazioni ({sottost or 0}): tipologia da controllare")
                cabine = sottost = None
            pod, resto = v.estrai_pod(r.get("codice_pod")) if terra else ([], "")
            pod = list(dict.fromkeys(pod))
            if resto:
                self.avviso(d, "Impianto", nome, "nel campo POD c'è altro testo (spostato in «Note POD»)")
            for p in pod:
                if p in pod_visti:
                    self.avviso(d, "Impianto", nome, f"POD {p} anche sull'{pod_visti[p]}")
                pod_visti.setdefault(p, nome)
            aste = _numero(r.get("num_par_ad_asta")) or None
            asta = _b(r.get("par_ad_asta")) or bool(aste)
            fascia = GABBIA.get(str(r.get("par_gabbia") or ""), "")
            if tip == "scariche" and not (asta or fascia):
                self.avviso(d, "Impianto", nome, "scariche atmosferiche senza aste né gabbia indicate")
            zone = [z for z in ("0", "1", "2", "20", "21", "22") if _b(r.get(f"zona_{z}"))]
            if tip == "esplosione" and not zone:
                self.avviso(d, "Impianto", nome, "pericolo di esplosione senza zone indicate")
            per = _numero(r.get("periodicita_verifiche"))
            per = per if per in (2, 5) else None
            if per is None:
                self.avviso(d, "Impianto", nome, "periodicità mancante")
            elif tip == "esplosione" and per != 2:
                self.avviso(d, "Impianto", nome, f"pericolo di esplosione con periodicità {per} anni: per legge è 2 anni")
            ultima = verbali.get(r.get("ultima_verifica")) or {}
            prossima = _data(r.get("data_prox_verifica"))
            if not prossima and not _b(r.get("dismessa")):
                self.avviso(d, "Impianto", nome, "prossima verifica non indicata in Garda (non compare nello scadenziario)")
            x = Impianto(sede_id=sede.id, tipologia=tip, denominazione=_testo(r.get("den_impianto"), 300), dismesso=_b(r.get("dismessa")),
                         matricola_anno=_testo(r.get("anno_matricola"), 4), matricola_attivita=_testo(r.get("cod_att_matricola"), 10),
                         matricola_numero=_testo(r.get("num_matricola"), 20), matricola_provincia=_testo(r.get("prov_immatr"), 2).upper(),
                         potenza_kw=potenza, cabine_mt_bt=cabine, sottostazioni_at_mt=sottost, pod_note=resto[:2000], asta=asta, numero_aste=aste,
                         gabbia=bool(fascia), gabbia_fascia=fascia, gas=any(z in ("0", "1", "2") for z in zone),
                         polveri=any(z in ("20", "21", "22") for z in zone), zone=", ".join(zone), periodicita_anni=per,
                         ultima_verifica_data=_data(r.get("data_ult_verifica")), ultima_verifica_numero=_testo(ultima.get("codice_verifica"), 40),
                         prossima_verifica=prossima, prossima_calcolata=False, avvisi=_avvisi(d), codice_esterno=str(r["id"]),
                         creato_da=NOME_IMPORTAZIONE, modificato_da=NOME_IMPORTAZIONE)
            x.pod = [ImpiantoPod(pod=p, ordine=i) for i, p in enumerate(pod)]
            self.s.add(x)
            self.impianti[r["id"]] = x
        self.s.flush()
        self.conta["impianti"] = len(self.impianti)

    # ---- preventivi e righe
    def importa_preventivi(self) -> None:
        righe = defaultdict(list)
        for r in self.d.get("preventivi_righe", []):
            righe[r["preventivo"]].append(r)
        usati: set[tuple[int, int, int]] = set()
        # prima i preventivi «normali», così un doppione di numero (serie «…_annullato») diventa la revisione successiva
        ordine = sorted(self.d.get("preventivi", []), key=lambda p: ("annull" in str(p.get("serie_preventivo") or ""), p["id"]))
        for p in ordine:
            giorno = _data(p.get("data_preventivo")) or date(2025, 1, 1)
            numero = _numero(p.get("numero_preventivo")) or 0
            anno = giorno.year
            serie = _testo(p.get("serie_preventivo"), 40)
            if serie[:4].isdigit() and int(serie[:4]) != anno:
                anno = int(serie[:4])
            nome = f"preventivo {numero}/{anno} (Garda {p['id']})"
            cliente = self.clienti.get(p.get("cliente"))
            if cliente is None or not numero:
                self.piano.problemi.append(_problema("Preventivo", nome, "senza cliente o senza numero in Garda: non importato"))
                continue
            revisione = 0
            while (anno, numero, revisione) in usati:
                revisione += 1
            usati.add((anno, numero, revisione))
            note = [_testo(p.get("note_interne"), 4000)] if _testo(p.get("note_interne")) else []
            if revisione:
                note.append(f"In Garda stesso numero di un altro preventivo (serie «{serie}»): importato come rev. {revisione}.")
            extra = [(k, _testo(p.get(c), 200)) for k, c in (("Tipo documento", "tipo_documento"), ("N° documento", "n_documento"), ("CIG", "cig"),
                                                           ("CUP", "cup"), ("Commessa/convenzione", "commessa_convenzione"),
                                                           ("Fatturato in Garda", "fatt_preventivo")) if _testo(p.get(c))]
            if extra:
                note.append("Da Garda: " + "; ".join(f"{k} {x}" for k, x in extra))
            stato = STATI_PREVENTIVO.get(str(p.get("stato_preventivo")), "creato")
            comm = self.commerciale(p.get("referente_commerciale"))
            x = Preventivo(anno=anno, numero=numero, revisione=revisione, codice=f"P_{numero:03d}_{anno % 100:02d}", data=giorno,
                           cliente_id=cliente.id, commerciale_id=comm.id if comm else None,
                           modalita_pagamento=self._nome_modalita(p.get("termini_di_pagamento")), termine_esecuzione=_testo(p.get("termine_esecuzione"), 300),
                           stato=stato, inviato_il=datetime(giorno.year, giorno.month, giorno.day, 12) if stato != "creato" else None,
                           rif_ordine=_testo(p.get("rif_ord_cli"), 120) or (_testo(p.get("n_documento"), 120) if p.get("tipo_documento") == "OrdineAcquisto" else ""),
                           data_ordine=_data(p.get("data_documento")) if p.get("tipo_documento") == "OrdineAcquisto" else None,
                           motivo_annullamento="Annullato nel gestionale di Garda" if stato == "annullato" else "", note="\n".join(note),
                           creato_da=NOME_IMPORTAZIONE, modificato_da=NOME_IMPORTAZIONE,
                           creato_il=datetime(giorno.year, giorno.month, giorno.day, 9), modificato_il=_dataora(p.get("last_update_ts")) or datetime.now(),
                           documenti_collegati=json.dumps(_documento_fattura(p), ensure_ascii=False))
            self.s.add(x)
            stati_righe = set()
            for i, r in enumerate(sorted(righe[p["id"]], key=lambda r: (r.get("n_riga") or 0, r["id"]))):
                imp = self.impianti.get(r.get("impianto"))
                if imp is None:
                    self.piano.problemi.append(_problema("Riga di preventivo", nome, f"impianto Garda {r.get('impianto')} non importato: riga saltata"))
                    continue
                sede = self.s.get(Sede, imp.sede_id)
                sr = STATI_RIGA.get(str(r.get("stato_riga")), "in_attesa")
                stati_righe.add(sr)
                riga = RigaPreventivo(ordine=i + 1, impianto_id=imp.id, tipo_verifica="straordinaria" if r.get("tipo_verifica") == "VS" else "periodica",
                                      sede_nome=sede.denominazione, sede_indirizzo=sede.indirizzo,
                                      sede_comune=" ".join(t for t in (sede.cap, sede.comune, f"({sede.provincia})" if sede.provincia else "") if t),
                                      tipologia=TIPOLOGIE_TESTO[imp.tipologia], descrizione=_descrizione(imp),
                                      tariffa_standard=_centesimi(r.get("tariffa_standard")), sconto=_centesimi(r.get("sconto")),
                                      tariffa_applicata=_centesimi(r.get("tariffa_applicata")), stato=sr, stato_da=NOME_IMPORTAZIONE,
                                      note=f"Riga Garda {r['id']}")
                x.righe.append(riga)
                self.righe[r["id"]] = riga
            # contributo INAIL 5% e indennità di trasferta: righe «a corpo», come le stampava Garda (totale = righe × 1,05 + trasferta)
            stato_extra = "accettata" if stato.startswith("accettato") else "rifiutata" if stato == "rifiutato" else "in_attesa"
            base = sum(r.tariffa_applicata for r in x.righe if r.stato not in ("rifiutata", "annullata"))
            if _b(p.get("contr_inail")) and base:
                importo = int(round(base * 0.05))
                x.righe.append(RigaPreventivo(ordine=len(x.righe) + 1, sede_nome="Contributo INAIL 5%", tariffa_standard=importo, tariffa_applicata=importo,
                                              stato=stato_extra, stato_da=NOME_IMPORTAZIONE, note="Da Garda (contributo INAIL 5%)"))
            trasferta = _centesimi(p.get("ind_trasferta"))
            if trasferta:
                x.righe.append(RigaPreventivo(ordine=len(x.righe) + 1, sede_nome="Indennità di trasferta (Tariffario ISPESL 07.07.2005)",
                                              tariffa_standard=trasferta, tariffa_applicata=trasferta, stato=stato_extra, stato_da=NOME_IMPORTAZIONE,
                                              note="Da Garda (indennità di trasferta)"))
            attive = [r for r in x.righe if r.stato not in ("annullata", "rifiutata")]
            x.totale_standard = sum(r.tariffa_standard for r in attive)
            x.totale = sum(r.tariffa_applicata for r in attive)
            garda = _centesimi(p.get("totale_scontato"))
            if attive and abs(x.totale - garda) > 2:
                self.quadratura.append(f"{x.codice}{f' rev.{revisione}' if revisione else ''}: totale {x.totale / 100:.2f} € (Garda {garda / 100:.2f} €, "
                                       f"stato «{p.get('stato_preventivo')}»)")
            # riesame del contratto
            if _b(p.get("riesame_fatto")) or p.get("riesame_esito"):
                conforme = p.get("riesame_esito") == "C"
                chi = self.utenti_garda.get(p.get("ult_riesame_utente"))
                quando = _dataora(p.get("ult_riesame_data")) or datetime(giorno.year, giorno.month, giorno.day, 12)
                self.s.flush()
                self.s.add(Riesame(preventivo_id=x.id, esito="conforme" if conforme else "non_conforme", requisiti_chiari=conforme,
                                   competenza_strumenti=conforme, imparzialita=conforme, tempi=conforme,
                                   note=("Importato da Garda: esito conforme (nel gestionale precedente non si registravano i singoli punti)."
                                         if conforme else "Importato da Garda: esito non conforme.") + (f"\n{_testo(p.get('riesame_nota'), 2000)}" if p.get("riesame_nota") else ""),
                                   eseguito_il=quando, eseguito_da=_nome_utente(chi)[:120] if chi else NOME_IMPORTAZIONE))
            self.preventivi[p["id"]] = x
            self.conta["preventivi"] += 1
        self.s.flush()
        self.conta["righe di preventivo"] = len(self.righe)

    # ---- verifiche
    def importa_verifiche(self) -> None:
        file_verbali = defaultdict(list)
        for f in self.d.get("verifiche_verbale", []):
            file_verbali[f["parent_id"]].append(_testo(f.get("file_name"), 200))
        numeri: set[tuple[int, int]] = set()
        for r in self.d.get("verifiche", []):
            nome = f"verifica Garda {r['id']} ({r.get('codice_verifica') or 'senza numero'})"
            riga = self.righe.get(r.get("preventivo_riga"))
            if riga is None:
                self.piano.problemi.append(_problema("Verifica", nome, "riga di preventivo non importata: verifica saltata"))
                continue
            stato_g = str(r.get("stato_verifica") or "")
            riesame = r.get("riesame_esito")
            stato = {"assegnata": "assegnata", "programmata": "programmata", "registrata": "registrata", "annullata": "annullata"}.get(stato_g)
            if stato_g == "effettuata":
                stato = "riesaminata" if riesame == "C" else "eseguita"
            if stato is None:
                self.piano.problemi.append(_problema("Verifica", nome, f"stato «{stato_g}» sconosciuto: verifica saltata"))
                continue
            anno, numero = _numero(r.get("anno_verifica")), _numero(r.get("numero_verifica"))
            codice = lettura_verbale.numero_normalizzato(_testo(r.get("codice_verifica"), 20)) if r.get("codice_verifica") else ""
            avvisi = []
            if anno and numero:
                if (anno, numero) in numeri:
                    avvisi.append(f"numero {codice} già usato da un'altra verifica in Garda")
                    anno = numero = None
                else:
                    numeri.add((anno, numero))
            tecnico = self.utenti.get(r.get("tecnico"))
            aff = self.utenti_garda.get(r.get("tecnico_aff"))
            chi_riesame = self.utenti_garda.get(r.get("ult_riesame_utente"))
            imp = self.s.get(Impianto, riga.impianto_id)
            note = []
            if aff:
                note.append(f"Tecnico in affiancamento: {_nome_utente(aff)}")
            note.append("Dichiarazione di assenza di conflitti del verificatore: " + ("sì" if _b(r.get("dichiaro_che")) else "non spuntata in Garda"))
            if r.get("motivazione_sospensione"):
                note.append(f"Motivazione sospensione: {_testo(r.get('motivazione_sospensione'), 1000)}")
            if r.get("fattura") or r.get("fattura_cliente"):
                note.append("FATTURATA in Garda (" + ", ".join(x for x in (f"fattura vecchia {r['fattura']}" if r.get("fattura") else "",
                                                                         f"fattura elettronica {r['fattura_cliente']}" if r.get("fattura_cliente") else "") if x) + ")")
            if r.get("tariffa_effettiva") is not None:
                note.append(f"Tariffa effettiva in Garda: {float(r['tariffa_effettiva'] or 0):.2f} €")
            if file_verbali.get(r["id"]):
                avvisi.append("verbale PDF nell'archivio di Garda: " + ", ".join(file_verbali[r["id"]]))
            esito = {"Positivo": "positivo", "Negativo": "negativo", "Sospeso": "sospeso", "A vuoto": "a_vuoto"}.get(str(r.get("esito_verifica") or ""), "")
            rilascio = _data(r.get("data_rilascio_verbale"))
            x = Verifica(riga_id=riga.id, preventivo_id=riga.preventivo_id, impianto_id=riga.impianto_id, tipo_verifica=riga.tipo_verifica, stato=stato,
                         verificatore_id=tecnico.id if tecnico else None, assegnata_da=NOME_IMPORTAZIONE if tecnico else "",
                         data_programmata=_data(r.get("data_progr")), anno=anno, numero=numero, codice_verbale=codice,
                         data_esecuzione=rilascio or (_data(r.get("data_progr")) if stato in ("registrata",) else None),
                         registrata_da=NOME_IMPORTAZIONE if codice else "", modulo=MODULO_PER_TIPOLOGIA.get(imp.tipologia, "") if stato in ("eseguita", "riesaminata") else "",
                         esito=esito, prossima_verifica=_data(r.get("data_prox_verifica")),
                         avvisi_verbale=json.dumps([f"Importazione da Garda: {a}" for a in avvisi], ensure_ascii=False) if avvisi else "",
                         eseguita_il=datetime(rilascio.year, rilascio.month, rilascio.day, 12) if rilascio and stato in ("eseguita", "riesaminata") else None,
                         caricata_da=NOME_IMPORTAZIONE if stato in ("eseguita", "riesaminata") else "",
                         riesame_esito={"C": "conforme", "N": "non_conforme"}.get(str(riesame or ""), ""), riesame_note=_testo(r.get("riesame_nota"), 2000),
                         riesame_il=_dataora(r.get("ult_riesame_data")) if riesame else None,
                         riesame_da=(_nome_utente(chi_riesame)[:120] if chi_riesame else NOME_IMPORTAZIONE) if riesame else "",
                         motivo_annullamento="Annullata nel gestionale di Garda" if stato == "annullata" else "", note="\n".join(note),
                         creato_da=NOME_IMPORTAZIONE, modificato_da=NOME_IMPORTAZIONE, modificato_il=_dataora(r.get("last_update_ts")) or datetime.now())
            self.s.add(x)
            self.verifiche[r["id"]] = x
            self.conta["verifiche"] += 1
        self.s.flush()

    def esegui(self) -> dict:
        self.importa_utenti()
        self.importa_clienti()
        self.importa_sedi()
        self.importa_impianti()
        self.importa_preventivi()
        self.importa_verifiche()
        return self.rapporto()

    def rapporto(self) -> dict:
        r = self.piano.riepilogo()
        numeratori = {str(x.get("numerator_key")): x.get("last_number") for x in self.d.get("gi_numerators", [])}
        return {"importati": dict(self.conta), "tipi_di_problema": r["tipi_di_problema"], "problemi": r["problemi"],
                "quadratura_totali": self.quadratura, "numeratori_garda": numeratori}


TIPI_DOC_GARDA = ("OrdineAcquisto", "Contratto", "Convenzione", "Ricezione", "FattureCollegate", "DDT", "FatturaPrincipale")


def _documento_fattura(p: dict) -> list[dict]:
    """R138 (0.16): linguetta «Fattura» del preventivo di Garda (tipo_documento, n_documento, data_documento, cig, cup,
    commessa_convenzione) → documenti collegati del preventivo, che passano poi da soli in fattura."""
    tipo = p.get("tipo_documento")
    numero = _testo(p.get("n_documento"), 20)
    if tipo not in TIPI_DOC_GARDA or not numero:
        return []
    giorno = _data(p.get("data_documento"))
    return [{"tipo": tipo, "numero": numero, "data": giorno.isoformat() if giorno else "",
             "cig": _testo(p.get("cig"), 15).upper(), "cup": _testo(p.get("cup"), 15).upper(),
             "commessa": _testo(p.get("commessa_convenzione"), 100)}]


def _problema(entita: str, nome: str, testo: str):  # noqa: ANN202
    from ..anagrafica.importazione import Problema

    return Problema(entita, nome, testo)


def _descrizione(imp: Impianto) -> str:
    if imp.tipologia in ("terra_bt", "terra_at"):
        parti = [f"{imp.potenza_kw:g} kW" if imp.potenza_kw else ""]
        if imp.cabine_mt_bt:
            parti.append(f"{imp.cabine_mt_bt} cabine MT/BT")
        return "; ".join(p for p in parti if p)
    if imp.tipologia == "scariche":
        parti = [f"{imp.numero_aste} aste" if imp.numero_aste else ("asta" if imp.asta else "")]
        if imp.gabbia:
            parti.append({"fino_100": "gabbia fino a 100 m²", "da_101_a_350": "gabbia da 101 a 350 m²", "oltre_350": "gabbia oltre 350 m²"}.get(imp.gabbia_fascia, "gabbia"))
        return "; ".join(p for p in parti if p)
    return f"zone {imp.zone}" if imp.zone else ""


def importa(s: Session, attore: Any, dati: dict[str, list[dict]], nome_file: str = "") -> dict:
    """Importa tutto in una sola transazione (chi chiama apre la scrittura): o entra tutto o niente."""
    for t in ("clienti", "clienti_sedi_operative", "impianti"):
        if not dati.get(t):
            raise ValueError(f"Nel dump manca la tabella «{t}» (o è vuota): è il database di AD_dpr (ingecert)?")
    if s.execute(select(Cliente).limit(1)).scalar() is not None:
        raise ValueError("L'archivio contiene già dei clienti: l'importazione da Garda si fa su un archivio nuovo.")
    imp = Importazione(s, dati)
    esito = imp.esegui()
    for x in [*imp.clienti.values(), *imp.sedi.values()]:  # R114: tutto ingecert è AD_DPR, anche chi è senza impianti
        x.ambito_dpr = True
    # R120: corrispondenze strutturate id di Garda → oggetto del gestionale (per i riallineamenti e la migrazione)
    s.flush()
    righe = [(t, gid, e, x.id) for t, e, mappa in (("clienti", "cliente", imp.clienti), ("clienti_sedi_operative", "sede", imp.sedi),
                                                    ("impianti", "impianto", imp.impianti), ("preventivi", "preventivo", imp.preventivi),
                                                    ("preventivi_righe", "riga_preventivo", imp.righe), ("verifiche", "verifica", imp.verifiche))
             for gid, x in mappa.items()]
    esito["importati"]["corrispondenze con Garda registrate"] = origini.registra_molte(s, origini.INGECERT, righe, f"importazione {nome_file}")
    registro.scrivi(s, utente=attore, azione="garda.importa", oggetto_tipo="importazione", oggetto_id="garda",
                    descrizione=f"Importazione dal database di Garda ({nome_file or 'dump'}): " +
                                ", ".join(f"{n} {k}" for k, n in esito["importati"].items()) + f"; {len(esito['problemi'])} segnalazioni da controllare",
                    dettagli={"importati": esito["importati"], "file": nome_file, "quadratura": esito["quadratura_totali"][:200]})
    return esito
