"""Importazione dal database di Garda AD_dm («adsrl») in un archivio già popolato da ingecert — 0.12.4.

Richiesta di Federico dell'11/10/2026: poter provare il gestionale anche con i dati veri di AD_dm. È il primo pezzo della
migrazione a secco del passo B (documento 18 § 7). Si importano:
- clienti: FUSI con quelli già presenti (stessa partita IVA o stesso codice fiscale), altrimenti nuovi (codice «dm:<id>»);
- sedi operative di adsrl, sotto il cliente giusto (non si fondono con le sedi DPR: si segnalano i possibili doppioni);
- attrezzature SC, SP, GVR con matricole, classificazione (cataloghi Garda con gli stessi ID), dati tecnici, camere GVR
  e date ultima/prossima per componente come date INIZIALI DICHIARATE (nessun verbale viene fabbricato);
- accessori (valvole di sicurezza, dischi di rottura, valvole di intercettazione), loro tarature e collegamenti.
Preventivi, verifiche, fatture DM e iec restano fuori da questa versione (passo D ed E). Il dump non viene mai eseguito:
si leggono solo i valori. Tutto in una transazione: o entra tutto o niente. Ogni bene conserva il riferimento all'origine
(asset_origini: sistema «garda_adsrl», tabella, id) per i riallineamenti futuri.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ...core import validazioni as v
from ..anagrafica import doppioni, origini
from ..anagrafica.modelli import Cliente, Sede
from ..beni import scheda_dm
from ..beni.modelli import (
    Asset,
    AssetOrigine,
    AssetRelazione,
    CameraGvr,
    FamigliaGvr,
    IdSpecifica,
    ScadenzaTecnica,
    TipoAttrezzatura,
)
from ..registro import servizio as registro
from .importa import NOME_IMPORTAZIONE, Importazione, _b, _data, _testo

SISTEMA = "garda_adsrl"


def _sconto(r: dict) -> int:
    """Sconto predefinito del cliente in Garda adsrl (`sconto_def`, percentuale) in centesimi di punto (AD-13)."""
    try:
        n = int(round(float(r.get("sconto_def") or 0) * 100))
    except (TypeError, ValueError):
        return 0
    return min(10000, max(0, n))
TABELLE_DM = {"clienti", "clienti_sedi_operative", "attrezzature", "valvole_sicurezza", "attrezzature_vds",
              "verifiche", "tipi_pagamento", "nazioni", "iva", "utenti"}
NOTA = "Data iniziale da Garda AD_dm (adsrl)"
# Garda: componente → (campo ultima, campo prossima, campo «ultima verifica» con l'id del verbale)
DATE = {
    "GVR": {"funzionamento": ("data_ult_funz", "data_prox_funz", "ultima_funz"),
            "integrita": ("data_ult_integrita", "data_prox_integrita", "ultima_integrita"),
            "interna": ("data_ult_interna", "data_prox_interna", "ultima_interna"),
            "cnd": ("data_ult_cnd", "data_prox_cnd", None)},
    "SC": {"scsp": ("data_ult_scsp", "data_prox_scsp", "ultima_scsp"),
           "supplementare": ("data_ult_suppl", "data_prox_suppl", None)},
}
DATE["SP"] = DATE["SC"]
ATTRIBUTI = {  # campo Garda → chiave della scheda DM (stessi nomi di adsrl/cust/meta/attrezzature.js)
    "tipo_attr_verbale": "tipo_attr_verbale", "cf_costr": "cf_costr", "descr_attr": "descr_attr", "reparto": "reparto",
    "rif_interno": "rif_interno", "esente_verifiche": "esente_verifiche", "tipo_prox_verifica": "tipo_prox_verifica",
    "ps_attr_gvr": "ps_attr_gvr", "volume_attr_gvr": "volume_attr_gvr", "ts_attr_gvr": "ts_attr_gvr",
    "sup_risc_attr_gvr": "sup_risc_attr_gvr", "prod_attr_gvr": "prod_attr_gvr", "gruppo_fluido": "gruppo_fluido",
    "cat_ped": "cat_ped", "matr_insieme": "matr_insieme", "id_pacco_bombola": "id_pacco_bombola",
    "gvr_breve_descr_funz": "gvr_breve_descr_funz", "portata_attr_sc_sp": "portata_attr_sc_sp",
    "n_panieri_idroestr": "n_panieri_idroestr",
}


def _decimi(testo: Any) -> int | None:
    """Volume o DN scritto in Garda («4000», «3.000,0», «191.7») in decimi; None se non è un numero."""
    t = str(testo or "").strip().replace(" ", "")
    if not t or not re.search(r"\d", t):
        return None
    if "," in t:
        t = t.replace(".", "").replace(",", ".")
    elif re.fullmatch(r"\d{1,3}(\.\d{3})+", t):
        t = t.replace(".", "")
    try:
        d = Decimal(t)
    except InvalidOperation:
        return None
    if not d.is_finite() or d < 0:
        return None
    return int((d * 10).quantize(Decimal(1), rounding=ROUND_HALF_UP))


class ImportazioneDM:
    def __init__(self, s: Session, dati: dict[str, list[dict]]) -> None:
        self.s, self.d = s, dati
        self.base = Importazione(s, {**dati, "clienti": []})   # stessi controlli e stesse regole dell'importazione DPR
        self.piano = self.base.piano
        self.conta: Counter = Counter()
        self.clienti: dict[int, Cliente] = {}
        self.sedi: dict[int, Sede] = {}
        self.beni: dict[int, Asset] = {}
        self.accessori: dict[int, Asset] = {}
        self.matricole: set[tuple[int, str]] = set()
        self._sede_di: dict[int, int] = {}
        self._sede_di_acc: dict[int, int] = {}
        self.verbali = {r["id"]: _testo(r.get("codice_verifica"), 40) for r in dati.get("verifiche", [])}
        self.tipi = {x.id: x for x in s.scalars(select(TipoAttrezzatura))}
        self.famiglie = {x.id: x for x in s.scalars(select(FamigliaGvr))}
        self.specifiche = set(s.scalars(select(IdSpecifica.id)))

    def avviso(self, d: dict, entita: str, nome: str, testo: str) -> None:
        self.piano.avviso(d, entita, nome, testo)

    # ---- clienti: fusione per partita IVA / codice fiscale
    def importa_clienti(self) -> None:
        """Fusione con i clienti già presenti SOLO se la corrispondenza è certa (revisione dell'11/10/2026):
        - un solo cliente ha la stessa partita IVA o lo stesso codice fiscale, e
        - i numeri presenti in entrambi coincidono (niente P.IVA uguale con codice fiscale diverso).
        Più clienti corrispondenti, o numeri che rimandano a clienti diversi: nessuna scelta silenziosa. Il cliente di
        adsrl entra come nuovo, con l'avviso, e la coppia compare in Clienti › «Possibili doppioni» da confermare."""
        indice: dict[str, set[int]] = {}
        per_id: dict[int, Cliente] = {}
        for c in self.s.scalars(select(Cliente)):
            per_id[c.id] = c
            for numero in doppioni.numeri(c):
                indice.setdefault(numero, set()).add(c.id)
        nuovi, dubbi = [], {}
        for r in self.d.get("clienti", []):
            piva = (v.recupera_numero(r.get("p_iva")) if _testo(r.get("p_iva")) else "").upper()
            cf = (v.recupera_numero(r.get("cod_fis")) if _testo(r.get("cod_fis")) else "").upper()
            trovati = set()
            for numero in (piva, cf):
                if numero:
                    trovati |= indice.get(numero, set())
            if not trovati:
                nuovi.append(r)
                continue
            c = per_id[next(iter(trovati))] if len(trovati) == 1 else None
            if c is not None and ((piva and c.partita_iva and piva != c.partita_iva.upper()) or
                                  (cf and c.codice_fiscale and cf != c.codice_fiscale.upper())):
                c = None  # stesso numero ma l'altro diverso: potrebbe essere un altro soggetto
            if c is None:
                nomi = ", ".join(f"«{per_id[x].ragione_sociale}» (n. {x})" for x in sorted(trovati))
                dubbi[r["id"]] = f"stessa partita IVA o codice fiscale di {nomi}, ma la corrispondenza non è certa: entrato come nuovo, da confermare in Clienti › Possibili doppioni"
                nuovi.append(r)
                continue
            self.clienti[r["id"]] = c
            c.ambito_dm = True  # R114: anagrafica unica, ora anche AD_DM
            self._riconcilia_recapiti(c, r)  # AD-REV-004 (0.12.8)
            c.sconto_dm = _sconto(r)  # AD-13 (0.12.8): lo sconto predefinito c'è solo in AD_dm
            nome = _testo(r.get("rag_soc"), 250)
            nota = f"Anche cliente AD_dm in Garda (adsrl codice {r['id']}" + (f", «{nome}»" if nome and nome.lower() != c.ragione_sociale.lower() else "") + ")."
            c.note = (c.note + "\n" if c.note else "") + nota
            self.conta["clienti già presenti, fusi con AD_dm"] += 1
        self.base.d = {**self.d, "clienti": nuovi}
        self.base.importa_clienti()
        righe = {r["id"]: r for r in nuovi}
        for gid, c in self.base.clienti.items():
            c.codice_esterno = f"dm:{gid}"
            c.ambito_dm = True
            c.sconto_dm = _sconto(righe.get(gid, {}))
            self.clienti[gid] = c
            if gid in dubbi:
                c.avvisi = (c.avvisi + "\n" if c.avvisi else "") + "Importazione da Garda AD_dm: " + dubbi[gid]
                self.piano.avviso({}, "Cliente", c.ragione_sociale, dubbi[gid])
                self.conta["clienti AD_dm non fusi perché la corrispondenza non è certa (da confermare)"] += 1
        self.conta["clienti nuovi da AD_dm"] = len(self.base.clienti)

    def _riconcilia_recapiti(self, c: Cliente, r: dict) -> None:
        """AD-REV-004 (0.12.8): nella fusione con un cliente già presente i recapiti di AD_dm non si perdono.
        - Campo vuoto nel cliente e compilato in AD_dm: si compila, con nota.
        - Valori diversi: resta quello già presente (stesso cliente: di norma referenti e pagamenti sono comuni, le
          eccezioni si gestiscono nel preventivo) e la differenza diventa un avviso visibile nella scheda del cliente e
          nel rapporto, da confermare a mano. Nessuna precedenza generale silenziosa."""
        email = "; ".join(v.dividi_email(r.get("email")))[:500]
        sdi_grezzo = re.sub(r"\s", "", _testo(r.get("sdi_pec"), 200))
        pec, sdi = _testo(r.get("pec"), 200), sdi_grezzo.upper()
        if "@" in sdi_grezzo:
            pec, sdi = pec or sdi_grezzo.lower(), ""
        if sdi in ("0", "000", "NAN", "NONE") or (sdi and not re.fullmatch(r"[A-Z0-9]{6,7}", sdi)):
            sdi = ""
        dm = {"email_verbali": email, "email_fatture": email, "pec": pec, "codice_sdi": sdi,
              "riferimento_amministrazione": _testo(r.get("rif_amministrazione"), 20),
              "referente_nome": _testo(r.get("nome_referente"), 120),
              "referente_email": "; ".join(v.dividi_email(r.get("email_ref")))[:200],
              "referente_telefono": v.normalizza_telefono(r.get("tel_ref")),
              "banca": _testo(r.get("istituto_finanziario"), 120),
              "iban": re.sub(r"\s", "", _testo(r.get("iban"), 60)).upper()[:34]}
        nomi = {"email_verbali": "email dei verbali", "email_fatture": "email delle fatture", "pec": "PEC", "codice_sdi": "codice SDI",
                "riferimento_amministrazione": "riferimento amministrazione", "referente_nome": "referente",
                "referente_email": "email del referente", "referente_telefono": "telefono del referente", "banca": "banca", "iban": "IBAN"}
        completati, diversi = [], []
        for campo, valore in dm.items():
            attuale = getattr(c, campo) or ""
            if not valore or valore.casefold() == attuale.casefold():
                continue
            if not attuale:
                setattr(c, campo, valore)
                completati.append(nomi[campo])
            else:
                diversi.append(f"{nomi[campo]} «{valore}» (qui «{attuale}»)")
        if completati:
            c.note = (c.note + "\n" if c.note else "") + "Completati da Garda AD_dm: " + ", ".join(completati) + "."
            self.conta["clienti fusi: recapiti completati da AD_dm"] += 1
        if diversi:
            testo = (f"Recapiti diversi in Garda AD_dm (adsrl codice {r['id']}): " + "; ".join(diversi)
                     + ". Conservati quelli già presenti: controlla.")
            c.avvisi = (c.avvisi + "\n" if c.avvisi else "") + testo
            self.piano.avviso({}, "Cliente", c.ragione_sociale, testo)
            self.conta["clienti fusi: recapiti diversi da confermare"] += 1

    # ---- sedi: sotto il cliente giusto; i possibili doppioni con le sedi DPR si segnalano, non si fondono
    def importa_sedi(self) -> None:
        """Sedi di adsrl sotto il cliente giusto. R116: se il cliente ha già una sede (DPR) con lo stesso indirizzo e
        comune, è lo stesso stabilimento: la sede di adsrl si unisce a quella (un solo referente, i dati diversi
        nelle note). Le sedi nello stesso comune con l'indirizzo scritto diversamente restano separate e si
        propongono in «Sedi operative › Possibili doppioni» per la conferma."""
        esistenti: dict[int, list[Sede]] = {}
        for sd in self.s.scalars(select(Sede)):
            esistenti.setdefault(sd.cliente_id, []).append(sd)
        self.sedi_prima = sum(len(x) for x in esistenti.values())
        self.base.clienti = dict(self.clienti)
        self.base.sedi = {}
        self.base.d = self.d
        self.base.importa_sedi()
        inattive = {r["id"]: _b(r.get("inattiva")) for r in self.d.get("clienti_sedi_operative", [])}
        for gid, sd in list(self.base.sedi.items()):
            sd.codice_esterno = f"dm:{gid}"
            sd.attiva = not inattive.get(gid, False)
            sd.ambito_dm = True
            if not sd.attiva:
                self.conta["sedi da AD_dm chiuse (inattive in Garda)"] += 1
            gemelle = doppioni.gemelle(self.s, sd, esistenti.get(sd.cliente_id, []))
            if len(gemelle) == 1:
                sd = doppioni.unisci(self.s, None, sd.id, gemelle[0].id, motivo=f"stesso indirizzo, sede AD_dm adsrl {gid}",
                                     registra=False)
                self.conta["sedi AD_dm unite alla sede DPR con lo stesso indirizzo (R116)"] += 1
            elif len(gemelle) > 1:
                testo = f"stesso indirizzo di {len(gemelle)} sedi già presenti: non unita, scegli tu in «Possibili doppioni»"
                sd.avvisi = (sd.avvisi + "\n" if sd.avvisi else "") + f"Importazione da Garda: {testo}"
                self.piano.avviso({}, "Sede", sd.denominazione, testo)
            elif any(doppioni.chiave(x.comune) == doppioni.chiave(sd.comune) for x in esistenti.get(sd.cliente_id, [])):
                self.conta["sedi AD_dm nello stesso comune di una sede DPR del cliente (da confermare in «Possibili doppioni»)"] += 1
            self.sedi[gid] = sd
        self.conta["sedi da AD_dm"] = len(self.sedi)

    # ---- attrezzature SC / SP / GVR
    def _testo_asset(self, a: Asset, d: dict, nome: str, campo: str, valore: Any, massimo: int) -> None:
        t = _testo(valore, 100000)
        if len(t) > massimo:
            self.avviso(d, "Attrezzatura", nome, f"{campo} più lungo di {massimo} caratteri: troncato")
            t = t[:massimo]
        setattr(a, campo, t)

    def _origine(self, a: Asset, tabella: str, r: dict, avvisi: list[str]) -> None:
        a.origini.append(AssetOrigine(sistema=SISTEMA, tabella=tabella, id_origine=str(r["id"]),
                                      dati_origine_json=json.dumps({"avvisi": avvisi}, ensure_ascii=False)))

    def _scadenza(self, a: Asset, componente: str, ultima: Any, prossima: Any, nota: str = NOTA, report: str = "") -> bool:
        du, dp = _data(ultima), _data(prossima)
        if not du and not dp:
            return False
        a.scadenze.append(ScadenzaTecnica(componente=componente, data_ultima=du, data_prossima=dp, numero_report=report[:100],
                                          fonte="dichiarata", nota=nota, dati_iniziali_json="{}", versione=1,
                                          creato_da=NOME_IMPORTAZIONE, modificato_da=NOME_IMPORTAZIONE))
        self.conta[f"date iniziali · {componente}"] += 1
        return True

    def importa_attrezzature(self) -> None:
        for r in self.d.get("attrezzature", []):
            gruppo = _testo(r.get("gruppo_attr"), 8).upper()
            matr = _testo(r.get("matr_informale"), 100)
            nome = f"{gruppo} {matr or r['id']}"
            sede = self.sedi.get(r.get("sede_operativa"))
            if gruppo not in ("GVR", "SC", "SP") or sede is None:
                self.piano.problemi.append(_problema("Attrezzatura", nome, "gruppo sconosciuto: non importata" if sede is not None
                                                     else "senza sede operativa valida in Garda: non importata"))
                continue
            d: dict[str, Any] = {"avvisi": []}
            a = Asset(gruppo=gruppo, classe_identita="attrezzatura", sede_id=sede.id, versione=1, dismesso=_b(r.get("dismessa")),
                      creato_da=NOME_IMPORTAZIONE, modificato_da=NOME_IMPORTAZIONE, attributi_json="{}")
            if not matr:
                matr = f"senza matricola {r['id']}"
                self.avviso(d, "Attrezzatura", nome, "matricola informale vuota in Garda")
            if (sede.id, matr) in self.matricole:
                self.avviso(d, "Attrezzatura", nome, "stessa matricola informale di un'altra attrezzatura della sede (differiva solo per spazi o maiuscole): aggiunto l'id di Garda")
                matr = f"{matr} ({r['id']})"
            self.matricole.add((sede.id, matr))
            a.matr_informale = matr
            for campo, garda, massimo in (("anno_matricola", "anno_matricola", 4), ("cod_att_matricola", "cod_att_matricola", 10),
                                          ("num_matricola", "num_matricola", 30), ("prov_immatr", "prov_immatr", 2),
                                          ("num_fabbrica", "num_fabbrica", 100), ("costruttore", "rag_soc_costr", 250),
                                          ("modello", "modello", 150), ("denominazione", "descr", 300)):
                self._testo_asset(a, d, nome, campo, r.get(garda), massimo)
            a.prov_immatr = a.prov_immatr.upper()
            a.note = _testo(r.get("note_attr"), 8000)
            anno = r.get("anno_costr")
            a.anno_costruzione = int(anno) if str(anno or "").isdigit() and 1000 <= int(anno) <= 9999 else None
            if anno not in (None, "", 0) and a.anno_costruzione is None:
                self.avviso(d, "Attrezzatura", nome, f"anno di costruzione «{anno}» non valido")
            tipo = self.tipi.get(r.get("tipo_attr")) if r.get("tipo_attr") else None
            if tipo is not None and tipo.gruppo == gruppo:
                a.tipo_attr_id = tipo.id
                if gruppo == "GVR":
                    a.tipo_attr_gvr_id = tipo.famiglia_gvr_id
            else:
                self.avviso(d, "Attrezzatura", nome, "Apparecchi all. 7 mancante o non coerente con il gruppo: da classificare")
            if r.get("id_spec") in self.specifiche:
                a.id_spec_id = r["id_spec"]
            else:
                self.avviso(d, "Attrezzatura", nome, "ID specifica mancante: da classificare")
            if gruppo == "GVR":
                a.soggetto_messa_servizio = _b(r.get("sogg_messa_servizio_gvr"))
            attrs: dict[str, Any] = {"marcatura_ce": _b(r.get("marcatura_ce"))}
            catalogo = scheda_dm.campi(gruppo)
            for garda, chiave in ATTRIBUTI.items():
                if chiave not in catalogo:
                    continue
                val = r.get(garda)
                if chiave == "n_panieri_idroestr":
                    attrs[chiave] = int(val) if str(val or "").isdigit() else None
                    continue
                t = _testo(val, 100000)
                if t:
                    try:
                        scheda_dm.valida({chiave: t}, catalogo)
                    except Exception as e:  # noqa: BLE001 — si conserva il valore storico e si segnala
                        self.avviso(d, "Attrezzatura", nome, f"{catalogo[chiave][0]}: «{t[:60]}» da controllare ({e})")
                    attrs[chiave] = t
            if not attrs.get("esente_verifiche"):
                attrs["esente_verifiche"] = "F"
            a.attributi_json = json.dumps(attrs, ensure_ascii=False)
            self._camere(a, d, nome, r)
            famiglia = self.famiglie.get(a.tipo_attr_gvr_id) if a.tipo_attr_gvr_id else None
            for comp, (cu, cp, cv) in DATE[gruppo].items():
                codice = self.verbali.get(r.get(cv), "") if cv else ""
                creata = self._scadenza(a, comp, r.get(cu), r.get(cp), NOTA + (f" · ultimo verbale in Garda {codice}" if codice else ""))
                if creata and comp == "interna" and (famiglia is None or famiglia.codice not in ("a2", "a3")):
                    self.avviso(d, "Attrezzatura", nome, "date di visita interna su una famiglia che non la prevede (solo GV/INS GV): da controllare")
            self._origine(a, "attrezzature", r, d["avvisi"])
            self.s.add(a)
            self.beni[r["id"]] = a
            self._sede_di[r["id"]] = r.get("sede_operativa")
            self.conta[f"attrezzature {gruppo}"] += 1
            if a.dismesso:
                self.conta["attrezzature dismesse (importate come dismesse)"] += 1
        self.s.flush()

    def _camere(self, a: Asset, d: dict, nome: str, r: dict) -> None:
        if a.gruppo != "GVR" or not r.get("gvr_conf_dati_tecnici"):
            return
        righe = _camere_garda(r)
        if righe is None:
            self.avviso(d, "Attrezzatura", nome, "configurazione delle camere illeggibile in Garda: non importata")
            return
        chiavi = set()
        for i, x in enumerate(righe, 1):
            if not isinstance(x, dict):
                continue
            base = _testo(x.get("gvr_att"), 140) or f"Camera {i}"
            nf = _testo(x.get("gvr_nf"), 100)
            ident, n = base, 2
            while (ident.lower() + "|" + nf.lower()) in chiavi:  # stessa camera scritta due volte: si distingue
                ident, n = f"{base} ({n})", n + 1
            chiave = ident.lower() + "|" + nf.lower()
            chiavi.add(chiave)
            vol, dn = _decimi(x.get("gvr_vol")), _decimi(x.get("gvr_dn"))
            unita, valore = ("L", vol) if vol is not None else ("DN", dn) if dn is not None else ("L", 0)
            if vol is None and dn is None:
                self.avviso(d, "Attrezzatura", nome, f"camera «{ident}» senza volume né DN leggibili: volume 0, da controllare")
            attrs = {k: _testo(x.get(k), 200) for k in ("gvr_ps", "gvr_ts", "gvr_nat", "gvr_stt", "gvr_grp") if _testo(x.get(k), 200)}
            a.camere.append(CameraGvr(identificazione=ident, num_fabbrica=nf, chiave=chiave, unita=unita, valore_decimi=valore,
                                      attributi_json=json.dumps(attrs, ensure_ascii=False), versione=1,
                                      creato_da=NOME_IMPORTAZIONE, modificato_da=NOME_IMPORTAZIONE))
            self.conta["camere GVR"] += 1

    # ---- accessori e collegamenti
    def importa_accessori(self) -> None:
        visti: set[tuple[int, str]] = set()
        for r in self.d.get("valvole_sicurezza", []):
            sede = self.sedi.get(r.get("sede_operativa"))
            matr = _testo(r.get("matricola"), 100)
            nome = f"accessorio {matr or r['id']}"
            if sede is None:
                self.piano.problemi.append(_problema("Accessorio", nome, "senza sede operativa valida in Garda: non importato"))
                continue
            d: dict[str, Any] = {"avvisi": []}
            if not matr:
                matr = f"senza matricola {r['id']}"
                self.avviso(d, "Accessorio", nome, "matricola (seriale) vuota in Garda")
            if (sede.id, matr) in visti:
                matr = f"{matr} ({r['id']})"
                self.avviso(d, "Accessorio", nome, "stessa matricola di un altro accessorio della sede: aggiunto l'id di Garda")
            visti.add((sede.id, matr))
            a = Asset(gruppo="PSV", classe_identita="accessorio", sede_id=sede.id, matr_informale=matr, versione=1,
                      dismesso=_b(r.get("dismessa")), creato_da=NOME_IMPORTAZIONE, modificato_da=NOME_IMPORTAZIONE,
                      denominazione=_testo(r.get("tip_accessorio"), 300) or "accessorio",
                      costruttore=_testo(r.get("fabbr"), 250), modello=_testo(r.get("modello"), 150), note="")
            tip = _testo(r.get("tip_accessorio"), 100)
            if not tip:
                self.avviso(d, "Accessorio", nome, "tipologia dell'accessorio non indicata in Garda")
            a.attributi_json = json.dumps({k: val for k, val in {"tip_accessorio": tip, "dn": _testo(r.get("dn"), 50),
                                           "diametro": _testo(r.get("diametro"), 50), "area": _testo(r.get("area"), 50),
                                           "ptar": _testo(r.get("ptar"), 50)}.items() if val}, ensure_ascii=False)
            self._scadenza(a, "taratura", r.get("ultima_tar"), r.get("prossima_tar"), "Taratura da Garda AD_dm (adsrl)")
            self._origine(a, "valvole_sicurezza", r, d["avvisi"])
            self.s.add(a)
            self.accessori[r["id"]] = a
            self._sede_di_acc[r["id"]] = r.get("sede_operativa")
            self.conta["accessori"] += 1
        self.s.flush()
        coppie = set()
        for r in self.d.get("attrezzature_vds", []):
            a, p = self.beni.get(r.get("attrezzatura")), self.accessori.get(r.get("valvola_sicurezza"))
            if a is None or p is None or (a.id, p.id) in coppie:
                self.conta["collegamenti attrezzatura-accessorio non importati (riferimento mancante o doppio)"] += 1
                continue
            if a.sede_id != p.sede_id:
                self.piano.problemi.append(_problema("Accessorio", p.matr_informale, f"collegato a {a.matr_informale} di un'altra sede: da controllare"))
            coppie.add((a.id, p.id))
            self.s.add(AssetRelazione(asset_id=a.id, accessorio_id=p.id, versione=1, creato_da=NOME_IMPORTAZIONE, modificato_da=NOME_IMPORTAZIONE))
            self.conta["collegamenti attrezzatura-accessorio"] += 1
        self.s.flush()

    def quadratura(self) -> list[str]:
        """Confronto fra righe lette nel dump e righe entrate nell'archivio, tabella per tabella."""
        out = []
        for tabella, entrate in (("clienti", len(self.clienti)), ("clienti_sedi_operative", len(self.sedi)),
                                 ("attrezzature", len(self.beni)), ("valvole_sicurezza", len(self.accessori))):
            lette = len(self.d.get(tabella, []))
            unite = self.conta.get("sedi AD_dm unite alla sede DPR con lo stesso indirizzo (R116)", 0) if tabella == "clienti_sedi_operative" else 0
            out.append(f"{tabella}: lette {lette}, importate {entrate}" + (f" (di cui {unite} unite a una sede DPR)" if unite else "")
                       + ("" if lette == entrate else f" · DIFFERENZA {lette - entrate}"))
        # accoppiamenti (R118): niente righe perse, doppie o attaccate al posto sbagliato
        unite = self.conta.get("sedi AD_dm unite alla sede DPR con lo stesso indirizzo (R116)", 0)
        attese = getattr(self, "sedi_prima", 0) + len(self.sedi) - unite
        nell_archivio = self.s.scalar(select(func.count(Sede.id))) or 0
        out.append(f"sedi nell'archivio: attese {attese} (prima {getattr(self, 'sedi_prima', 0)} + {len(self.sedi)} adsrl − {unite} unite), "
                   f"presenti {nell_archivio}" + ("" if attese == nell_archivio else " · DIFFERENZA"))
        sbagliate = [gid for gid, a in self.beni.items() if a.sede_id != self.sedi[self._sede_di[gid]].id]
        sbagliate += [gid for gid, a in self.accessori.items() if a.sede_id != self.sedi[self._sede_di_acc[gid]].id]
        out.append(f"attrezzature e accessori nella sede giusta: {len(self.beni) + len(self.accessori) - len(sbagliate)} su "
                   f"{len(self.beni) + len(self.accessori)}" + (f" · {len(sbagliate)} NELLA SEDE SBAGLIATA" if sbagliate else ""))
        coll = self.conta.get("collegamenti attrezzatura-accessorio", 0)
        scart = self.conta.get("collegamenti attrezzatura-accessorio non importati (riferimento mancante o doppio)", 0)
        lette = len(self.d.get("attrezzature_vds", []))
        out.append(f"attrezzature_vds: lette {lette}, importate {coll}, scartate con motivo {scart}" + ("" if lette == coll + scart else " · DIFFERENZA"))
        vol_garda = sum(_decimi(x.get("gvr_vol")) or 0 for r in self.d.get("attrezzature", []) if r["id"] in self.beni
                        for x in (_camere_garda(r) or []) if isinstance(x, dict))
        vol_arch = sum(c.valore_decimi for a in self.beni.values() for c in a.camere if c.unita == "L")
        out.append(f"volume totale delle camere (litri): Garda {Decimal(vol_garda) / 10}, archivio {Decimal(vol_arch) / 10}" +
                   ("" if vol_garda == vol_arch else " · DIFFERENZA"))
        return out

    def esegui(self) -> dict:
        self.importa_clienti()
        self.importa_sedi()
        self.importa_attrezzature()
        self.importa_accessori()
        # R120: corrispondenze strutturate (le attrezzature e gli accessori sono in asset_origini)
        self.s.flush()
        righe = [("clienti", gid, "cliente", c.id) for gid, c in self.clienti.items()]
        righe += [("clienti_sedi_operative", gid, "sede", sd.id) for gid, sd in self.sedi.items()]
        self.conta["corrispondenze con Garda registrate"] = origini.registra_molte(self.s, origini.ADSRL, righe, "importazione adsrl")
        r = self.piano.riepilogo()
        importati = dict(self.conta)
        for k in ("clienti", "sedi"):
            importati.pop(k, None)
        for k, n in self.base.conta.items():
            if k.startswith("nuove voci") or k == "commerciali":
                importati[f"{k} (da AD_dm)"] = n
        return {"importati": importati, "tipi_di_problema": r["tipi_di_problema"], "problemi": r["problemi"],
                "quadratura": self.quadratura()}


def _camere_garda(r: dict) -> list | None:
    """Le camere scritte da Garda nel campo JSON gvr_conf_dati_tecnici; None se il testo non è leggibile."""
    try:
        righe = json.loads(r.get("gvr_conf_dati_tecnici") or "[]")
    except ValueError:
        return None
    return righe if isinstance(righe, list) else None


def _problema(entita: str, nome: str, testo: str):
    from ..anagrafica.importazione import Problema

    return Problema(entita, nome, testo)


def importa(s: Session, attore: Any, dati: dict[str, list[dict]], nome_file: str = "") -> dict:
    """Aggiunge AD_dm a un archivio già importato da ingecert. Chi chiama apre la scrittura: o tutto o niente."""
    for t in ("clienti", "clienti_sedi_operative", "attrezzature"):
        if not dati.get(t):
            raise ValueError(f"Nel dump manca la tabella «{t}» (o è vuota): è il database di AD_dm (adsrl)?")
    if s.scalar(select(AssetOrigine.id).where(AssetOrigine.sistema == SISTEMA).limit(1)) is not None:
        raise ValueError("In questo archivio AD_dm è già stato importato: si importa una volta sola, su un archivio di prova.")
    if s.scalar(select(Cliente.id).limit(1)) is None:
        raise ValueError("Importa prima il database di AD_dpr (ingecert): i clienti comuni si fondono con quelli.")
    esito = ImportazioneDM(s, dati).esegui()
    registro.scrivi(s, utente=attore, azione="garda.importa_dm", oggetto_tipo="importazione", oggetto_id="garda_adsrl",
                    descrizione=f"Importazione AD_dm da Garda ({nome_file or 'dump'}): " +
                                ", ".join(f"{n} {k}" for k, n in esito["importati"].items()) + f"; {len(esito['problemi'])} segnalazioni",
                    dettagli={"importati": esito["importati"], "file": nome_file, "quadratura": esito["quadratura"]})
    return esito
