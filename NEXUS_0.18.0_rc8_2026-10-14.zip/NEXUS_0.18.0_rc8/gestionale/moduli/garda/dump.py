"""Lettura di un dump MySQL/MariaDB (es. esportazione SQL di HeidiSQL o mysqldump) senza un server MySQL.

Legge solo le tabelle richieste: `CREATE TABLE` (per l'ordine delle colonne) e `INSERT INTO … VALUES (…),(…);`.
Viste, procedure e il resto si ignorano. Il file può essere .sql, .sql.gz o .zip (con un solo .sql dentro).
Nessuna istruzione del file viene eseguita: si leggono soltanto i valori.
"""

from __future__ import annotations

import gzip
import io
import re
import zipfile
from pathlib import Path

ESCAPE = {"0": "\0", "b": "\b", "n": "\n", "r": "\r", "t": "\t", "Z": "\x1a", "\\": "\\", "'": "'", '"': '"', "%": "\\%", "_": "\\_"}
_CREATE = re.compile(r"CREATE TABLE\s+(?:IF NOT EXISTS\s+)?`([^`]+)`\s*\((.*?)\)\s*(?:ENGINE|TYPE|COLLATE|DEFAULT|;)", re.S | re.I)
_COLONNA = re.compile(r"^\s*`([^`]+)`\s", re.M)
_INSERT = re.compile(r"INSERT\s+(?:IGNORE\s+)?INTO\s+`([^`]+)`\s*(\(([^)]*)\))?\s*VALUES\s*", re.I)


class DumpNonValido(ValueError):
    pass


def testo_del_dump(sorgente: Path | bytes, nome: str = "") -> str:
    """Contenuto testuale del dump (scompatta .gz e .zip)."""
    dati = sorgente.read_bytes() if isinstance(sorgente, Path) else sorgente
    nome = (nome or (sorgente.name if isinstance(sorgente, Path) else "")).lower()
    if dati[:2] == b"\x1f\x8b" or nome.endswith(".gz"):
        dati = gzip.decompress(dati)
    elif dati[:4] == b"PK\x03\x04":
        z = zipfile.ZipFile(io.BytesIO(dati))
        sql = [n for n in z.namelist() if n.lower().endswith(".sql") and not n.startswith("__MACOSX")]
        if len(sql) != 1:
            raise DumpNonValido("Nello zip deve esserci un solo file .sql.")
        dati = z.read(sql[0])
    for codifica in ("utf-8-sig", "cp1252"):
        try:
            return dati.decode(codifica)
        except UnicodeDecodeError:
            continue
    raise DumpNonValido("Il file non è testo leggibile (utf-8 o Windows-1252).")


def _valore(testo: str, i: int) -> tuple[object, int]:
    """Legge un valore SQL da testo[i]; restituisce (valore, posizione dopo il valore)."""
    c = testo[i]
    if c == "'" or c == '"':
        chiusura, parti, j = c, [], i + 1
        inizio = j
        while True:
            k = testo.find(chiusura, j)
            b = testo.find("\\", j)
            if k < 0:
                raise DumpNonValido("Stringa non chiusa nel dump.")
            if 0 <= b < k:  # sequenza di escape prima della chiusura
                parti.append(testo[inizio:b])
                parti.append(ESCAPE.get(testo[b + 1], testo[b + 1]))
                j = inizio = b + 2
                continue
            if k + 1 < len(testo) and testo[k + 1] == chiusura:  # '' = apice
                parti.append(testo[inizio:k + 1])
                j = inizio = k + 2
                continue
            parti.append(testo[inizio:k])
            return "".join(parti), k + 1
    m = re.compile(r"NULL|_binary\s*'|0x[0-9A-Fa-f]*|[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?|b'[01]*'", re.I).match(testo, i)
    if not m:
        raise DumpNonValido(f"Valore non riconosciuto nel dump vicino a «{testo[i:i + 30]}».")
    t = m.group(0)
    if t.upper() == "NULL":
        return None, m.end()
    if t.lower().startswith("_binary"):
        return _valore(testo, m.end() - 1)
    if t.lower().startswith("0x"):
        return bytes.fromhex(t[2:]), m.end()
    if t.lower().startswith("b'"):
        return int(t[2:-1] or "0", 2), m.end()
    return (float(t) if any(x in t for x in ".eE") else int(t)), m.end()


def _tuple(testo: str, i: int) -> tuple[list[list], int]:
    """Legge (…),(…),… fino al punto e virgola."""
    righe = []
    n = len(testo)
    while i < n:
        while testo[i] in " \t\r\n,":
            i += 1
        if testo[i] == ";":
            return righe, i + 1
        if testo[i] != "(":
            raise DumpNonValido(f"Atteso «(» nel dump vicino a «{testo[i:i + 30]}».")
        i += 1
        riga = []
        while True:
            while testo[i] in " \t\r\n":
                i += 1
            valore, i = _valore(testo, i)
            riga.append(valore)
            while testo[i] in " \t\r\n":
                i += 1
            if testo[i] == ",":
                i += 1
                continue
            if testo[i] == ")":
                i += 1
                break
            raise DumpNonValido(f"Atteso «,» o «)» nel dump vicino a «{testo[i:i + 30]}».")
        righe.append(riga)
    raise DumpNonValido("Dump troncato: manca il punto e virgola finale di un INSERT.")


def leggi(testo: str, tabelle: set[str] | None = None) -> dict[str, list[dict]]:
    """{tabella: [ {colonna: valore} ]} per le tabelle richieste (tutte se None)."""
    colonne: dict[str, list[str]] = {}
    for m in _CREATE.finditer(testo):
        colonne[m.group(1)] = _COLONNA.findall(m.group(2))
    risultato: dict[str, list[dict]] = {}
    pos = 0
    while True:
        m = _INSERT.search(testo, pos)
        if not m:
            break
        tabella = m.group(1)
        if tabelle is not None and tabella not in tabelle:
            # salta l'INSERT senza interpretarlo: cerca la fine leggendo le tuple (le stringhe possono contenere «;»)
            _, pos = _tuple(testo, m.end())
            continue
        nomi = [x.strip().strip("`") for x in m.group(3).split(",")] if m.group(3) else colonne.get(tabella)
        if not nomi:
            raise DumpNonValido(f"Nel dump mancano le colonne della tabella «{tabella}».")
        righe, pos = _tuple(testo, m.end())
        for r in righe:
            if len(r) != len(nomi):
                raise DumpNonValido(f"Tabella «{tabella}»: una riga ha {len(r)} valori invece di {len(nomi)}.")
        risultato.setdefault(tabella, []).extend(dict(zip(nomi, r)) for r in righe)
    for t in colonne:
        if tabelle is None or t in tabelle:
            risultato.setdefault(t, [])
    return risultato
