"""Identità completa dei documenti commerciali e fotografia dei riferimenti del preventivo."""
import json

CAMPI_DOCUMENTO = ('tipo', 'numero', 'data', 'cig', 'cup', 'commessa')


def chiave_documento(d):
    """Stesso numero non significa stesso documento se CIG, CUP o commessa sono diversi."""
    return tuple(str(d.get(k) or '').strip() for k in CAMPI_DOCUMENTO)


def documenti_del_preventivo(p):
    docs = [dict(x) for x in json.loads(getattr(p, 'documenti_collegati', '') or '[]')]
    ordine = getattr(p, 'rif_ordine', '') or ''
    if ordine and not any(x.get('tipo') == 'OrdineAcquisto' for x in docs):
        data = getattr(p, 'data_ordine', None)
        docs.insert(0, {'tipo': 'OrdineAcquisto', 'numero': ordine,
                        'data': data.isoformat() if data else '', 'cig': '', 'cup': '', 'commessa': ''})
    return docs
