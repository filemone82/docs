"""API autorizzata del nucleo economico: sessione e CSRF del gestionale."""

import json
from typing import Annotated

import io
import zipfile

from fastapi import APIRouter, Body, Depends, File, UploadFile
from fastapi.responses import Response
from sqlalchemy import select

from ...core.date import oggi_italia
from ...core.db import Archivio
from ...core.errori import ErroreUtente
from ...web.dipendenze import archivio, richiede
from ..anagrafica.modelli import Cliente, ElencoValore
from ..utenti.accesso import UtenteCorrente
from . import esiti_sdi
from . import pagamenti as P
from . import servizio as S
from .modelli import EsportazioneFattura, Fattura, Incasso, Societa

router = APIRouter(prefix="/api")


def risultato(arc, id):
    with arc.lettura() as s:
        return S.fattura_json(s, S.get(s, Fattura, id))


@router.get("/finanza/valori")
def valori(
    *,
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.vedere"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    with arc.lettura() as s:
        return {
            "societa": [
                S.societa_json(x)
                for x in s.scalars(select(Societa).order_by(Societa.id))
            ],
            "clienti": [
                {"id": c.id, "ragione_sociale": c.ragione_sociale}
                for c in s.scalars(select(Cliente).order_by(Cliente.ragione_sociale))
            ],
            "aliquote": [
                {
                    "aliquota": (x.percentuale or 0) / 100,
                    "natura": x.natura,
                    "esigibilita": "S" if x.scissione_pagamenti else "I",
                    "descrizione": x.descrizione,
                }
                for x in s.scalars(
                    select(ElencoValore).where(
                        ElencoValore.elenco == "aliquota_iva",
                        ElencoValore.attivo.is_(True),
                    )
                )
            ],
            # 0.14: modalità di pagamento con le regole di Garda (codice MP, rate…)
            "modalita": [
                {"id": x.id, "descrizione": x.descrizione, "attivo": x.attivo, "versione": x.versione,
                 "regole": P.regole(x)}
                for x in s.scalars(select(ElencoValore).where(ElencoValore.elenco == "modalita_pagamento")
                                   .order_by(ElencoValore.ordine, ElencoValore.id))
            ],
            "tipi_documento": list(S.TIPI_DOCUMENTO),
            "permessi": {
                p: u.puo(p)
                for p in (
                    "fatture.genera",
                    "fatture.esiti",
                    "incassi.gestire",
                    "incassi.vedere",
                    "sistema.impostazioni",
                )
            },
            "tipi": S.TIPI,
        }


@router.put("/societa/{id}")
def societa(
    *,
    id: int,
    d: Annotated[dict, Body(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("sistema.impostazioni"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    with arc.scrittura() as s:
        return S.aggiorna_societa(s, u, id, d)


@router.get("/fatture")
def elenco(
    *,
    q: str = "",
    scadute: bool = False,
    ambito: str = 'DPR',
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.vedere"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    with arc.lettura() as s:
        rows = [
            S.fattura_json(s, f)
            for f in s.scalars(select(Fattura).where(Fattura.ambito == ambito).order_by(Fattura.id.desc()))
        ]
        if q:
            rows = [
                r
                for r in rows
                if q.casefold() in (r["codice"] + " " + r["cliente"]).casefold()
            ]
        if scadute:
            rows = [
                r
                for r in rows
                if r["residuo"]
                and r["stato"] not in ("bozza", "scartata")
                and any(x["data"] < oggi_italia().isoformat() for x in r["scadenze"])
            ]
        return rows


@router.get("/fatture/fatturabili")
def fatturabili(
    *,
    ambito: str = 'DPR',
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.genera"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    with arc.lettura() as s:
        return S.fatturabili(s, ambito)


@router.get("/fatture/{id}")
def leggi(
    *,
    id: int,
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.vedere"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    return risultato(arc, id)


@router.post("/fatture")
def crea(
    *,
    d: Annotated[dict, Body(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.genera"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    for k in ("societa_id", "cliente_id"):
        if k not in d:
            raise ErroreUtente("Scegli società e intestatario.")
    with arc.scrittura() as s:
        f = S.crea(s, u, d)
        id = f.id
    return risultato(arc, id)


@router.post("/fatture/da-righe")
def da_righe(
    *,
    d: Annotated[dict, Body(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.genera"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    """N7 / R125 (0.12.8): bozza di fattura dalle righe dei preventivi selezionate."""
    with arc.scrittura() as s:
        f = S.da_righe(s, u, d)
        id = f.id
    return risultato(arc, id)


@router.post("/fatture/righe-da-lavori")
def righe_da_lavori(
    *,
    d: Annotated[dict, Body(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.genera"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    """R139 (0.16): righe di preventivo da fatturare a partire da verifiche DPR e incarichi DM."""
    with arc.lettura() as s:
        return S.righe_da_lavori(s, d)


@router.get("/bozze-fatture")
def bozze(
    *,
    cliente_id: int,
    ambito: str = "DPR",
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.genera"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    """Bozze TD01 di un intestatario, per «aggiungi a una bozza esistente»."""
    with arc.lettura() as s:
        return [{"id": f.id, "data": f.data.isoformat(), "testo": f"Bozza n. interno {f.id} del {f.data.strftime('%d/%m/%Y')}"}
                for f in s.scalars(select(Fattura).where(Fattura.cliente_id == cliente_id, Fattura.ambito == ambito,
                                                         Fattura.tipo == "TD01", Fattura.stato == "bozza").order_by(Fattura.id.desc()))]


@router.put("/fatture/{id}")
def modifica(
    *,
    id: int,
    d: Annotated[dict, Body(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.genera"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    with arc.scrittura() as s:
        S.modifica(s, u, S.get(s, Fattura, id), d)
    return risultato(arc, id)


@router.post("/fatture/{id}/righe")
def aggiungi(
    *,
    id: int,
    d: Annotated[dict, Body(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.genera"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    with arc.scrittura() as s:
        S.aggiungi_riga(s, u, S.get(s, Fattura, id), d)
    return risultato(arc, id)


@router.post("/fatture/{id}/righe/{riga_id}/elimina")
def elimina(
    *,
    id: int,
    riga_id: int,
    d: Annotated[dict, Body(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.genera"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    with arc.scrittura() as s:
        S.elimina_riga(s, u, S.get(s, Fattura, id), riga_id, d)
    return risultato(arc, id)


@router.put("/fatture/{id}/scadenze")
def scadenze(
    *,
    id: int,
    d: Annotated[dict, Body(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.genera"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    with arc.scrittura() as s:
        S.pagamenti_previsti(s, u, S.get(s, Fattura, id), d)
    return risultato(arc, id)


@router.post("/fatture/{id}/scadenze/calcola")
def calcola_scadenze(
    *,
    id: int,
    d: Annotated[dict, Body(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.genera"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    """0.14: scadenze dalla modalità di pagamento (preventivo → cliente → predefinita, o quella scelta)."""
    with arc.scrittura() as s:
        S.calcola_scadenze(s, u, S.get(s, Fattura, id), d)
    return risultato(arc, id)


@router.put("/finanza/modalita/{id}/regole")
def regole_modalita(
    *,
    id: int,
    d: Annotated[dict, Body(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("sistema.impostazioni"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    """0.14: codice MP, rate, fine mese, spostamento, «salda subito», predefinita (Garda tipi_pagamento)."""
    from ..registro import servizio as registro
    with arc.scrittura() as s:
        x = s.get(ElencoValore, id)
        if x is None or x.elenco != "modalita_pagamento":
            raise ErroreUtente("Modalità di pagamento non trovata.", 404)
        S.controlla_versione(x, d.get("versione"))
        nuove = P.valida(d.get("regole") or {})
        prima = P.regole(x)
        if nuove["predefinito"]:   # una sola predefinita
            for y in s.scalars(select(ElencoValore).where(ElencoValore.elenco == "modalita_pagamento", ElencoValore.id != id)):
                r = P.regole(y)
                if r.get("predefinito"):
                    y.regole_json = json.dumps({**r, "predefinito": False})
        x.regole_json = json.dumps(nuove)
        x.versione += 1
        registro.scrivi(s, utente=u.come_attore(), azione="modalita_pagamento.regole", oggetto_tipo="elenco_valore",
                        oggetto_id=x.id, descrizione=f"Regole della modalità di pagamento «{x.descrizione}»",
                        dettagli={"prima": prima, "dopo": nuove})
        return {"id": x.id, "descrizione": x.descrizione, "versione": x.versione, "regole": P.regole(x)}


@router.post("/fatture/esiti/importa")
async def importa_esiti(
    *,
    file: Annotated[list[UploadFile], File(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.esiti"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    """0.14: ricevute dello SdI scaricate da Aruba (XML o ZIP): ognuna aggiorna lo stato della sua fattura."""
    files = [(f.filename or "ricevuta.xml", await f.read(esiti_sdi.MASSIMO + 1)) for f in file[:200]]
    with arc.scrittura() as s:
        return {"risultati": esiti_sdi.importa(s, u, files)}


@router.post("/fatture/xml-zip")
def xml_zip(
    *,
    d: Annotated[dict, Body(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.vedere"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    """0.14 (Garda «genera XML» in blocco): un solo ZIP con l'ultimo XML di ogni fattura scelta, da caricare su Aruba."""
    ids = d.get("ids") or []
    if not isinstance(ids, list) or not ids or len(ids) > 500:
        raise ErroreUtente("Scegli da 1 a 500 fatture.")
    buf, saltate = io.BytesIO(), []
    with arc.lettura() as s, zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for i in sorted({int(x) for x in ids}):
            f = S.get(s, Fattura, i)
            e = s.scalar(select(EsportazioneFattura).where(EsportazioneFattura.fattura_id == f.id,
                                                            EsportazioneFattura.revisione == f.revisione_xml))
            if f.stato == "bozza" or e is None:
                saltate.append(f.codice or f"bozza n. {f.id}")
                continue
            z.writestr(nome_xml(e), e.xml.encode())
        if saltate:
            z.writestr("LEGGIMI.txt", "Non inclusi (bozze o senza XML): " + ", ".join(saltate) + "\n")
    oggi = oggi_italia().strftime("%Y%m%d")
    return Response(buf.getvalue(), media_type="application/zip",
                    headers={"Content-Disposition": f'attachment; filename="fatture_xml_{oggi}.zip"'})


def nome_xml(e):
    if e.nome_file:
        return e.nome_file
    piva = json.loads(e.fotografia)["societa"]["partita_iva"]
    return f"IT{piva}_{e.fattura_id:X}{e.revisione:02X}.xml"


@router.post("/fatture/{id}/emetti")
def emetti(
    *,
    id: int,
    d: Annotated[dict, Body(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.genera"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    with arc.scrittura() as s:
        f = S.get(s, Fattura, id)
        if f.numero:
            S.riemetti(s, u, f, d)
        else:
            S.emetti(s, u, f, d)
    return risultato(arc, id)


@router.post("/fatture/{id}/correggi-scarto")
def correggi(
    *,
    id: int,
    d: Annotated[dict, Body(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.genera"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    with arc.scrittura() as s:
        S.prepara_correzione(s, u, S.get(s, Fattura, id), d)
    return risultato(arc, id)


@router.post("/fatture/esportazioni/{id}/esito")
def esito(
    *,
    id: int,
    d: Annotated[dict, Body(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.esiti"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    with arc.scrittura() as s:
        f = S.esito(s, u, id, d)
        fid = f.id
    return risultato(arc, fid)


@router.get("/fatture/{id}/xml/{revisione}")
def xml(
    *,
    id: int,
    revisione: int,
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.vedere"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    with arc.lettura() as s:
        S.get(s, Fattura, id)
        e = s.scalar(
            select(EsportazioneFattura).where(
                EsportazioneFattura.fattura_id == id,
                EsportazioneFattura.revisione == revisione,
            )
        )
        if not e:
            raise ErroreUtente("Esportazione non trovata.", 404)
        nome = nome_xml(e)
        return Response(
            e.xml.encode(),
            media_type="application/xml",
            headers={"Content-Disposition": f'attachment; filename="{nome}"'},
        )


@router.get("/fatture/{id}/pdf")
def pdf(
    *,
    id: int,
    u: Annotated[UtenteCorrente, Depends(richiede("fatture.vedere"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    from urllib.parse import quote

    from .stampa import nome_pdf, pdf_fattura
    from .documenti import corrente
    from ..documenti import servizio as archivio_documenti

    with arc.lettura() as s:
        f = S.get(s, Fattura, id)
        doc = corrente(s, f)
        foto = json.loads(f.fotografia) if f.stato != "bozza" else S.fotografia(s, f)
        nome = nome_pdf(foto)  # R140 (0.16): nome come i PDF di Garda
        if doc:
            _, raw = archivio_documenti.leggi(s, arc.cfg.cartella_documenti, doc.documento_id)
            return Response(raw, media_type="application/pdf", headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(nome)}"})
    return Response(
        pdf_fattura(foto, arc.cfg.libreoffice),
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quote(nome)}"},
    )


@router.get("/incassi")
def incassi(
    *,
    u: Annotated[UtenteCorrente, Depends(richiede("incassi.vedere"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    with arc.lettura() as s:
        return [
            S.incasso_json(s, x)
            for x in s.scalars(select(Incasso).order_by(Incasso.id.desc()))
        ]


@router.post("/incassi")
def incasso(
    *,
    d: Annotated[dict, Body(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("incassi.gestire"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    for k in ("societa_id", "cliente_id", "data", "importo"):
        if k not in d:
            raise ErroreUtente("Completa società, pagatore, data e importo.")
    with arc.scrittura() as s:
        x = S.registra_incasso(s, u, d)
        return S.incasso_json(s, x)


@router.put("/incassi/{id}/allocazioni")
def ripartisci(
    *,
    id: int,
    d: Annotated[dict, Body(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("incassi.gestire"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    with arc.scrittura() as s:
        x = S.ripartisci(s, u, S.get(s, Incasso, id), d)
        return S.incasso_json(s, x)


@router.post("/incassi/{id}/storna")
def storna(
    *,
    id: int,
    d: Annotated[dict, Body(...)],
    u: Annotated[UtenteCorrente, Depends(richiede("incassi.gestire"))],
    arc: Annotated[Archivio, Depends(archivio)],
):
    with arc.scrittura() as s:
        x = S.storna(s, u, S.get(s, Incasso, id), d)
        return S.incasso_json(s, x)
