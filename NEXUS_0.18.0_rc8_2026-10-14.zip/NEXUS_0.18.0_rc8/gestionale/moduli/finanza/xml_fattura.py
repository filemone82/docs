"""Generatore FatturaPA FPR12/FPA12. Nessuna trasmissione automatica."""

import re
from decimal import Decimal
from functools import lru_cache
from pathlib import Path

from lxml import etree as E

from ...core.errori import ErroreUtente

NS = "http://ivaservizi.agenziaentrate.gov.it/docs/xsd/fatture/v1.2"


def money(v):
    return f"{Decimal(v) / 100:.2f}"


def add(p, tag, text=None):
    n = E.SubElement(p, tag)
    if text is not None:
        n.text = str(text)
    return n


def anagrafica(p, d, cedente=False):
    a = add(p, "DatiAnagrafici")
    if d.get("partita_iva"):
        i = add(a, "IdFiscaleIVA")
        add(i, "IdPaese", d.get("nazione") or "IT")
        add(i, "IdCodice", d["partita_iva"])
    if d.get("codice_fiscale"):
        add(a, "CodiceFiscale", d["codice_fiscale"])
    n = add(a, "Anagrafica")
    add(n, "Denominazione", d["ragione_sociale"])
    if cedente:
        add(a, "RegimeFiscale", d.get("regime_fiscale") or "RF01")
    n = add(p, "Sede")
    for tag, k in [("Indirizzo", "indirizzo"), ("CAP", "cap"), ("Comune", "comune")]:
        add(n, tag, d[k])
    if d.get("provincia"):
        add(n, "Provincia", d["provincia"])
    add(n, "Nazione", d.get("nazione") or "IT")
    if cedente:
        cedente_extra(p, d)


def cedente_extra(p, d):
    """0.14 (FIN-04, Garda «configurazioni»): iscrizione al REA, contatti e riferimento amministrazione del cedente."""
    if d.get("rea_ufficio") and d.get("rea_numero"):
        r = add(p, "IscrizioneREA")
        add(r, "Ufficio", d["rea_ufficio"].upper()[:2])
        add(r, "NumeroREA", d["rea_numero"][:20])
        if d.get("capitale_sociale"):
            add(r, "CapitaleSociale", f"{Decimal(d['capitale_sociale'].replace('.', '').replace(',', '.')):.2f}")
        if d.get("socio_unico") in ("SU", "SM"):
            add(r, "SocioUnico", d["socio_unico"])
        add(r, "StatoLiquidazione", d.get("stato_liquidazione") if d.get("stato_liquidazione") in ("LS", "LN") else "LN")
    contatti = [(tag, d.get(k)) for tag, k in (("Telefono", "telefono"), ("Fax", "fax"), ("Email", "email")) if d.get(k)]
    if contatti:
        c = add(p, "Contatti")
        for tag, v in contatti:
            add(c, tag, v)
    if d.get("riferimento_amministrazione"):
        add(p, "RiferimentoAmministrazione", d["riferimento_amministrazione"][:20])


# Documenti collegati di Garda (fatture_clienti_doc_collegati) → blocchi FatturaPA, nell'ordine dello schema
DOCUMENTI = {"OrdineAcquisto": "DatiOrdineAcquisto", "Contratto": "DatiContratto", "Convenzione": "DatiConvenzione",
             "Ricezione": "DatiRicezione", "FattureCollegate": "DatiFattureCollegate"}


def documenti_collegati(f):
    """Elenco unico dei documenti collegati: quelli indicati nella fattura, più l'ordine «semplice» delle versioni
    precedenti (ordine/CIG/CUP) e, per la nota di credito, la fattura originaria."""
    o = f["opzioni"]
    docs = [dict(x) for x in o.get("documenti") or []]
    if o.get("ordine") or o.get("cig") or o.get("cup"):
        docs.insert(0, {"tipo": "OrdineAcquisto", "numero": o.get("ordine") or "ORDINE", "data": o.get("data_ordine", ""),
                        "cig": o.get("cig", ""), "cup": o.get("cup", "")})
    if f.get("originale") and not any(d.get("tipo") == "FattureCollegate" and d.get("numero") == f["originale"]["codice"] for d in docs):
        docs.append({"tipo": "FattureCollegate", "numero": f["originale"]["codice"], "data": f["originale"]["data"]})
    return docs


def genera(f, id, rev, progressivo=None):
    c = f["cliente"]
    so = f["societa"]
    o = f["opzioni"]
    pa = c["tipo"] == "pa"
    formato = "FPA12" if pa else "FPR12"
    for d, label in [(c, "Intestatario"), (so, "Società")]:
        for k in ("ragione_sociale", "indirizzo", "cap", "comune"):
            if not d.get(k):
                raise ErroreUtente(f"{label}: manca {k.replace('_', ' ')}.")
        if not re.fullmatch(r"\d{5}", d["cap"]):
            raise ErroreUtente(f"{label}: CAP non valido.")
        if not d.get("partita_iva") and not d.get("codice_fiscale"):
            raise ErroreUtente(f"{label}: manca identificativo fiscale.")
        if (
            d.get("nazione", "IT") == "IT"
            and d.get("partita_iva")
            and not re.fullmatch(r"\d{11}", d["partita_iva"])
        ):
            raise ErroreUtente(f"{label}: partita IVA non valida.")
    if not so.get("partita_iva"):
        raise ErroreUtente("Società: partita IVA obbligatoria.")
    sdi = c.get("codice_sdi") or (
        "XXXXXXX" if c.get("nazione", "IT") != "IT" else "0000000"
    )
    if not re.fullmatch(r"[A-Z0-9]{6}" if pa else r"[A-Z0-9]{7}", sdi):
        raise ErroreUtente(
            "Codice destinatario non valido per il tipo di intestatario."
        )
    root = E.Element(
        "{" + NS + "}FatturaElettronica", nsmap={"p": NS}, versione=formato
    )
    h = add(root, "FatturaElettronicaHeader")
    t = add(h, "DatiTrasmissione")
    i = add(t, "IdTrasmittente")
    add(i, "IdPaese", "IT")
    add(
        i,
        "IdCodice",
        so.get("id_trasmittente") or so.get("codice_fiscale") or so["partita_iva"],
    )
    add(t, "ProgressivoInvio", progressivo or f"{id:X}{rev:02X}")
    add(t, "FormatoTrasmissione", formato)
    add(t, "CodiceDestinatario", sdi)
    if c.get("pec") and sdi == "0000000":
        add(t, "PECDestinatario", c["pec"])
    # Riferimento amministrazione: in Garda è un dato del cliente (cli_rif_amministrazione), nell'XML sta nel cedente
    anagrafica(add(h, "CedentePrestatore"), {**so, "riferimento_amministrazione": c.get("riferimento_amministrazione") or ""}, True)
    anagrafica(add(h, "CessionarioCommittente"), c)
    b = add(root, "FatturaElettronicaBody")
    g = add(b, "DatiGenerali")
    dg = add(g, "DatiGeneraliDocumento")
    for tag, val in [
        ("TipoDocumento", f["tipo"]),
        ("Divisa", "EUR"),
        ("Data", f["data"]),
        ("Numero", f["codice"]),
    ]:
        add(dg, tag, val)
    if f["ritenuta"]:
        n = add(dg, "DatiRitenuta")
        for tag, val in [
            ("TipoRitenuta", o.get("ritenuta_tipo", "RT02")),
            ("ImportoRitenuta", money(f["ritenuta"])),
            ("AliquotaRitenuta", f"{Decimal(o['ritenuta_percentuale']):.2f}"),
            ("CausalePagamento", o.get("ritenuta_causale", "A")),
        ]:
            add(n, tag, val)
    if f["bollo"]:
        n = add(dg, "DatiBollo")
        add(n, "BolloVirtuale", "SI")
        add(n, "ImportoBollo", money(f["bollo"]))
    add(dg, "ImportoTotaleDocumento", money(f["totale"]))
    if o.get("causale"):
        add(dg, "Causale", o["causale"][:200])
    docs = documenti_collegati(f)
    for tipo, tag in DOCUMENTI.items():
        for d in (x for x in docs if x.get("tipo") == tipo):
            n = add(g, tag)
            add(n, "IdDocumento", str(d.get("numero") or "")[:20])
            if d.get("data"):
                add(n, "Data", d["data"])
            for etichetta, k, lun in (("CodiceCommessaConvenzione", "commessa", 100), ("CodiceCUP", "cup", 15), ("CodiceCIG", "cig", 15)):
                if d.get(k):
                    add(n, etichetta, str(d[k])[:lun])
    # R138 (0.16): gli ultimi due tipi della linguetta «Fattura» di Garda, nell'ordine dello schema FatturaPA 1.2
    for d in (x for x in docs if x.get("tipo") == "DDT"):
        if not d.get("data"):
            raise ErroreUtente("Documento di trasporto: la data è obbligatoria.")
        n = add(g, "DatiDDT")
        add(n, "NumeroDDT", str(d.get("numero") or "")[:20])
        add(n, "DataDDT", d["data"])
    principali = [x for x in docs if x.get("tipo") == "FatturaPrincipale"]
    if len(principali) > 1:
        raise ErroreUtente("Fattura principale: se ne indica una sola.")
    for d in principali:
        if not d.get("data"):
            raise ErroreUtente("Fattura principale: la data è obbligatoria.")
        n = add(g, "FatturaPrincipale")
        add(n, "NumeroFatturaPrincipale", str(d.get("numero") or "")[:20])
        add(n, "DataFatturaPrincipale", d["data"])
    beni = add(b, "DatiBeniServizi")
    for i, r in enumerate(f["righe"], 1):
        n = add(beni, "DettaglioLinee")
        add(n, "NumeroLinea", i)
        add(n, "Descrizione", r["descrizione"])
        add(n, "Quantita", r["quantita"])
        add(n, "PrezzoUnitario", r["prezzo"])
        add(n, "PrezzoTotale", money(r["importo"]))
        add(n, "AliquotaIVA", money(r["aliquota"]))
        if f["ritenuta"]:
            add(n, "Ritenuta", "SI")
        if r["natura"]:
            add(n, "Natura", r["natura"])
        refs = r.get("riferimenti", {})
        for tag, k in [("PREVENTIVO", "preventivo"), ("VERBALE", "verbale")]:
            if refs.get(k):
                a = add(n, "AltriDatiGestionali")
                add(a, "TipoDato", tag)
                add(a, "RiferimentoTesto", refs[k])
        if r["natura"] == "N3.5":
            if not o.get("dichiarazione_protocollo") or not o.get("dichiarazione_data"):
                raise ErroreUtente(
                    "Non imponibilità N3.5: indica protocollo e data della dichiarazione di intento."
                )
            a = add(n, "AltriDatiGestionali")
            add(a, "TipoDato", "INTENTO")
            add(a, "RiferimentoTesto", o["dichiarazione_protocollo"])
            add(a, "RiferimentoData", o["dichiarazione_data"])
    for r in f["riepiloghi"]:
        n = add(beni, "DatiRiepilogo")
        add(n, "AliquotaIVA", money(r["aliquota"]))
        if r["natura"]:
            add(n, "Natura", r["natura"])
        add(n, "ImponibileImporto", money(r["imponibile"]))
        add(n, "Imposta", money(r["iva"]))
        add(n, "EsigibilitaIVA", r["esigibilita"])
        if r["riferimento_normativo"]:
            add(n, "RiferimentoNormativo", r["riferimento_normativo"])
    if f["scadenze"]:   # 0.14 (FIN-04): anche la nota di credito, quando ha i suoi pagamenti
        n = add(b, "DatiPagamento")
        add(
            n,
            "CondizioniPagamento",
            o.get("condizioni", "TP01" if len(f["scadenze"]) > 1 else "TP02"),
        )
        for q in f["scadenze"]:
            a = add(n, "DettaglioPagamento")
            add(a, "ModalitaPagamento", q["modalita"])
            add(a, "DataScadenzaPagamento", q["data"])
            add(a, "ImportoPagamento", money(q["importo"]))
            if so.get("banca"):
                add(a, "IstitutoFinanziario", so["banca"])
            iban = o.get("iban") or so.get("iban")
            if iban:
                add(a, "IBAN", iban)
    return E.tostring(root, xml_declaration=True, encoding="UTF-8", pretty_print=True)


@lru_cache(maxsize=1)
def schema():
    p = Path(__file__).parent / "schemi" / "Schema_VFPR12.xsd"
    return E.XMLSchema(
        E.parse(str(p), E.XMLParser(resolve_entities=False, no_network=True))
    )


def valida(xml):
    root = E.fromstring(xml, E.XMLParser(resolve_entities=False, no_network=True))
    if not schema().validate(root):
        msg = str(schema().error_log.last_error)
        raise ErroreUtente("XML non valido rispetto allo schema FatturaPA: " + msg)
