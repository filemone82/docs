"""Nucleo economico comune. Primo ambito operativo: AD DPR."""
