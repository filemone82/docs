# Schemi XML usati nel collaudo 0.8.0

`Schema_VFPR12.xsd` dichiara **versione 1.2.2**; comprende FPR12 e FPA12 e importa lo schema di firma dalla copia locale. I file provengono dai sorgenti del backup ingecert fornito per l'analisi. Sono usati senza accesso alla rete dal parser e non contengono credenziali o dati di fatture.

Questa versione storica consente una prima regressione del generatore, ma **non attesta la conformità alle specifiche applicabili oggi**. Prima dell'uso fiscale sostituire o integrare la risorsa con lo schema e le regole ufficiali pertinenti, verificare le differenze e ripetere i test, compresi i controlli extra-XSD e il percorso Aruba. Il tentativo di recuperare lo schema ufficiale durante il lavoro è stato respinto dal server; non viene dichiarata una validazione corrente mai eseguita.

Riferimento ufficiale da consultare: https://www.fatturapa.gov.it/it/norme-e-regole/documentazione-fatturapa/

## Impronte delle copie incluse

- `Schema_VFPR12.xsd` — SHA256 `9dfb0a145698a3370bf90f954d2b308e3b5c9d58e83cf8660311fe97cb2ddcd6`
- `xmldsig-core-schema.xsd` — SHA256 `a85a9a5d0553e26da176dca42d8b58b27874f3753dedd995ce84f1bb8479ae2f`
