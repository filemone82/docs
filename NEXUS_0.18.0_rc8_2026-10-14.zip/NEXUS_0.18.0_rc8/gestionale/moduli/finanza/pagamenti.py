"""Modalità di pagamento con le regole di Garda (`tipi_pagamento` + `tipi_pagamento_scadenze`), 0.14.

Ogni modalità (elenco «modalita_pagamento») ha, oltre alla descrizione:
- `mp`: codice FatturaPA MP01…MP23 (Garda: `modalita`);
- `rate`: [{giorni, percentuale, fine_mese}] (Garda: `tipi_pagamento_scadenze`);
- `fm_paga_dopo`: con «fine mese», paga il giorno indicato del mese dopo (Garda: `fm_paga_dopo`);
- `sposta_scadenze`: scadenze al 31/8 o al 31/12 spostate al 10 del mese dopo (Garda: `sposta_scadenze`);
- `salda_subito`: il documento si considera incassato all'emissione (Garda: `salda_subito`);
- `predefinito`: la modalità usata quando né il preventivo né il cliente ne indicano una (Garda: `predefinito`).

La modalità della fattura viene, come in Garda: dal preventivo, poi dal cliente, poi dalla predefinita.
"""

from __future__ import annotations

import calendar
import json
import re
from datetime import date, timedelta
from decimal import ROUND_HALF_UP, Decimal

from sqlalchemy import select

from ...core.errori import ErroreUtente

RE_MP = re.compile(r"MP(0[1-9]|1[0-9]|2[0-3])")
VUOTE = {"mp": "MP05", "rate": [{"giorni": 0, "percentuale": "100", "fine_mese": False}], "fm_paga_dopo": None,
         "sposta_scadenze": False, "salda_subito": False, "predefinito": False}


def proposta_da_descrizione(descrizione: str) -> dict:
    """Regole ricavate dal nome, per le modalità nate prima della 0.14 (es. «Bonifico 60 gg F.M.», «Ri.Ba. 30 gg F.M.»,
    «Rimessa diretta»). Si controllano e si correggono in Configurazione."""
    d = (descrizione or "").lower()
    mp = "MP12" if "ri.ba" in d or "riba" in d else "MP01" if "contant" in d else "MP08" if "carta" in d else (
        "MP02" if "assegno" in d else "MP19" if "sepa" in d or "sdd" in d else "MP05")
    giorni = [int(x) for x in re.findall(r"(\d+)\s*(?:gg|giorni)", d)] or [0]
    fm = bool(re.search(r"f\.?\s?m\.?|fine mese", d))
    n = len(giorni)
    quote = [str((Decimal(100) / n).quantize(Decimal("0.01"))) for _ in giorni]
    quote[-1] = str(Decimal(100) - sum(Decimal(q) for q in quote[:-1]))
    return {**VUOTE, "mp": mp, "rate": [{"giorni": g, "percentuale": q, "fine_mese": fm} for g, q in zip(giorni, quote)]}


def regole(x) -> dict:
    """Regole di una modalità (ElencoValore); senza regole salvate, quelle ricavate dal nome."""
    salvate = json.loads(getattr(x, "regole_json", "") or "{}") if x is not None else {}
    if not salvate:
        return proposta_da_descrizione(x.descrizione if x is not None else "")
    return {**VUOTE, **salvate}


def valida(r: dict) -> dict:
    """Controllo delle regole inviate dalla configurazione."""
    if not isinstance(r, dict):
        raise ErroreUtente("Regole di pagamento non valide.")
    mp = str(r.get("mp") or "MP05")
    if not RE_MP.fullmatch(mp):
        raise ErroreUtente("Modalità FatturaPA: scegli un codice da MP01 a MP23.")
    rate = r.get("rate") or [{"giorni": 0, "percentuale": "100", "fine_mese": False}]
    if not isinstance(rate, list) or not 1 <= len(rate) <= 12:
        raise ErroreUtente("Da 1 a 12 rate.")
    pulite, totale = [], Decimal(0)
    for q in rate:
        try:
            g, p = int(q.get("giorni", 0)), Decimal(str(q.get("percentuale", "0")).replace(",", "."))
        except Exception:  # noqa: BLE001
            raise ErroreUtente("Rata non valida: giorni e percentuale numerici.") from None
        if not 0 <= g <= 720 or p <= 0:
            raise ErroreUtente("Rata non valida: giorni da 0 a 720, percentuale positiva.")
        pulite.append({"giorni": g, "percentuale": str(p), "fine_mese": bool(q.get("fine_mese"))})
        totale += p
    if totale != 100:
        raise ErroreUtente(f"Le percentuali delle rate devono fare 100 (ora {totale}).")
    fm = r.get("fm_paga_dopo")
    fm = int(fm) if fm not in (None, "", 0, "0") else None
    if fm is not None and not 1 <= fm <= 28:
        raise ErroreUtente("«Paga il giorno del mese dopo»: da 1 a 28.")
    return {"mp": mp, "rate": pulite, "fm_paga_dopo": fm, "sposta_scadenze": bool(r.get("sposta_scadenze")),
            "salda_subito": bool(r.get("salda_subito")), "predefinito": bool(r.get("predefinito"))}


def _fine_mese(d: date) -> date:
    return d.replace(day=calendar.monthrange(d.year, d.month)[1])


def _mese_dopo(d: date, giorno: int) -> date:
    return (d.replace(day=1) + timedelta(days=32)).replace(day=giorno)


def calcola(data_documento: date, dovuto: int, r: dict) -> list[dict]:
    """Scadenze come Garda: data + giorni; «fine mese» → ultimo del mese (o il giorno indicato del mese dopo);
    scadenze al 31/8 e 31/12 → 10 del mese dopo se richiesto. Importi in centesimi, il resto sull'ultima rata."""
    if dovuto <= 0:
        return []
    out, assegnato = [], 0
    for i, q in enumerate(r["rate"]):
        d = data_documento + timedelta(days=int(q["giorni"]))
        if q.get("fine_mese"):
            d = _mese_dopo(d, r["fm_paga_dopo"]) if r.get("fm_paga_dopo") else _fine_mese(d)
        if r.get("sposta_scadenze") and (d.month, d.day) in ((8, 31), (12, 31)):
            d = _mese_dopo(d, 10)
        if i == len(r["rate"]) - 1:
            importo = dovuto - assegnato
        else:
            importo = int((Decimal(dovuto) * Decimal(q["percentuale"]) / 100).quantize(Decimal(1), rounding=ROUND_HALF_UP))
        assegnato += importo
        if importo > 0:
            out.append({"data": d, "importo": importo, "modalita": r["mp"]})
    return out


def modalita_della_fattura(s, f) -> tuple:
    """(ElencoValore o None, provenienza). Garda: preventivo → cliente → predefinita."""
    from ..anagrafica.modelli import Cliente, ElencoValore
    from ..preventivi.modelli import Preventivo, RigaPreventivo
    from .modelli import RigaFattura

    o = json.loads(f.opzioni or "{}")
    if o.get("modalita_pagamento_id"):
        x = s.get(ElencoValore, int(o["modalita_pagamento_id"]))
        if x is not None and x.elenco == "modalita_pagamento":
            return x, "scelta nella fattura"
    attive = list(s.scalars(select(ElencoValore).where(ElencoValore.elenco == "modalita_pagamento")
                            .order_by(ElencoValore.ordine, ElencoValore.id)))
    per_nome = {x.descrizione.strip().lower(): x for x in attive}
    preventivi = {s.get(RigaPreventivo, r).preventivo_id for r in s.scalars(
        select(RigaFattura.riga_preventivo_id).where(RigaFattura.fattura_id == f.id, RigaFattura.riga_preventivo_id.is_not(None)))}
    if len(preventivi) == 1:
        p = s.get(Preventivo, preventivi.pop())
        x = per_nome.get((p.modalita_pagamento or "").strip().lower())
        if x is not None:
            return x, f"dal preventivo {p.codice}"
    c = s.get(Cliente, f.cliente_id)
    if c is not None and c.modalita_pagamento_id:
        return s.get(ElencoValore, c.modalita_pagamento_id), "dal cliente"
    predefinita = next((x for x in attive if x.attivo and regole(x).get("predefinito")), None)
    if predefinita is not None:
        return predefinita, "predefinita"
    return None, "nessuna (rimessa diretta alla data del documento)"
