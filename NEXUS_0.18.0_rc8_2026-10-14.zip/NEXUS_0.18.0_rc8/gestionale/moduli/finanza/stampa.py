"""Copia di cortesia della fattura (R140, 0.16): stessa impaginazione dei PDF di cortesia di Garda.

Federico, 12/10/2026, 17:36: «deve sempre riportare in alto l'intestazione di AD, ovviamente il cliente, ovviamente le
singole righe, nonché il riferimento al preventivo e all'ordine (se uguali per ogni riga unico in fondo)» e «manca numero
e data». Si costruisce un Word dalla fotografia fiscale (gli stessi dati dell'XML) e LibreOffice lo converte in PDF.

Impaginazione (dai PDF di Garda):
- intestazione: logo a sinistra, «AD S.r.l.» e i suoi dati a destra;
- «TD01: fattura», «Fattura Nr. 390/2026/DPR del 19/09/2026» (bozza: «BOZZA», non valida ai fini fiscali);
- riquadro grigio «Cliente»;
- righe: Cod. Articolo, Descrizione, Qtà, Prezzo, Importo, IVA; in fondo i riferimenti comuni (preventivo, ordine) e
  «Copia della fattura elettronica disponibile nella Sua area riservata dell'Agenzia delle Entrate»;
- riepilogo IVA e totali; pagamento (modalità, banca, IBAN), scadenze, Tot. dovuto; «Pag. X/Y».
"""

from __future__ import annotations

import io
import re
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

from ...core import pdf
from .riferimenti import chiave_documento

LOGO = Path(__file__).resolve().parents[2] / "static" / "img" / "ad-logo.png"
TIPI = {"TD01": "fattura", "TD02": "acconto/anticipo su fattura", "TD04": "nota di credito"}
TITOLI = {"TD01": "Fattura", "TD02": "Fattura di acconto", "TD04": "Nota di credito"}
NOMI_DOC = {"OrdineAcquisto": "Ordine d'acquisto", "Contratto": "Contratto", "Convenzione": "Convenzione", "Ricezione": "Ricezione",
            "FattureCollegate": "Fattura collegata", "DDT": "Documento di trasporto", "FatturaPrincipale": "Fattura principale"}
NATURE = {"N1": "Escluse ex art. 15", "N2.1": "Non soggette art. 7-7septies", "N2.2": "Non soggette, altri casi",
          "N3.1": "Non imponibili, esportazioni", "N3.2": "Non imponibili, cessioni intracomunitarie", "N3.5": "Non imponibili, dichiarazione d'intento",
          "N4": "Esenti", "N5": "Regime del margine", "N6.1": "Inversione contabile", "N7": "IVA assolta in altro Stato UE"}
GRIGIO = "EDEDED"
LINEA = "BFBFBF"


def data_it(iso: str | None) -> str:
    if not iso:
        return ""
    a, m, g = str(iso)[:10].split("-")
    return f"{g}/{m}/{a}"


def importo(cent: int | None) -> str:
    """€ 1.234,50 come nei PDF di Garda."""
    n = int(cent or 0)
    segno, n = ("-" if n < 0 else ""), abs(n)
    return f"€ {segno}{n // 100:,}".replace(",", ".") + f",{n % 100:02d}"


def aliquota_testo(cent: int) -> str:
    n = int(cent)
    return str(n // 100) if n % 100 == 0 else f"{n / 100:.2f}".replace(".", ",")


# ---------------------------------------------------------------- mattoni WordprocessingML


def _r(testo: str, b: bool = False, size: int = 18, colore: str = "", corsivo: bool = False) -> str:
    colore_xml = '<w:color w:val="%s"/>' % colore if colore else ""
    pr = (f'<w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/>{"<w:b/>" if b else ""}{"<w:i/>" if corsivo else ""}'
          f'{colore_xml}<w:sz w:val="{size}"/><w:szCs w:val="{size}"/>')
    parti = str(testo).split("\n")
    corpo = "<w:br/>".join(f'<w:t xml:space="preserve">{escape(x)}</w:t>' for x in parti)
    return f"<w:r><w:rPr>{pr}</w:rPr>{corpo}</w:r>"


def _p(*runs: str, allinea: str = "left", dopo: int = 0, prima: int = 0) -> str:
    return (f'<w:p><w:pPr><w:spacing w:before="{prima}" w:after="{dopo}" w:line="240" w:lineRule="auto"/>'
            f'<w:jc w:val="{allinea}"/></w:pPr>{"".join(runs)}</w:p>')


def _bordi(tutti: bool = True, colore: str = LINEA) -> str:
    if not tutti:
        return "<w:tcBorders><w:top w:val=\"nil\"/><w:left w:val=\"nil\"/><w:bottom w:val=\"nil\"/><w:right w:val=\"nil\"/></w:tcBorders>"
    return "".join(["<w:tcBorders>", *(f'<w:{x} w:val="single" w:sz="4" w:color="{colore}"/>' for x in ("top", "left", "bottom", "right")),
                    "</w:tcBorders>"])


def _cella(contenuto: str, larghezza: int, sfondo: str = "", bordi: bool = True, span: int = 1, valign: str = "top") -> str:
    if contenuto.endswith("</w:tbl>"):  # una cella deve finire con un paragrafo (tabelle annidate)
        contenuto += '<w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="20" w:lineRule="exact"/></w:pPr></w:p>'
    span_xml = '<w:gridSpan w:val="%d"/>' % span if span > 1 else ""
    sfondo_xml = '<w:shd w:val="clear" w:color="auto" w:fill="%s"/>' % sfondo if sfondo else ""
    return (f'<w:tc><w:tcPr><w:tcW w:w="{larghezza}" w:type="dxa"/>{span_xml}'
            f'{_bordi(bordi)}{sfondo_xml}'
            f'<w:tcMar><w:top w:w="40" w:type="dxa"/><w:left w:w="80" w:type="dxa"/><w:bottom w:w="40" w:type="dxa"/><w:right w:w="80" w:type="dxa"/></w:tcMar>'
            f'<w:vAlign w:val="{valign}"/></w:tcPr>{contenuto or _p("")}</w:tc>')


def _tabella(larghezze: list[int], righe: list[str], bordo_esterno: bool = False) -> str:
    griglia = "".join(f'<w:gridCol w:w="{x}"/>' for x in larghezze)
    return (f'<w:tbl><w:tblPr><w:tblW w:w="{sum(larghezze)}" w:type="dxa"/><w:tblLayout w:type="fixed"/>'
            f'<w:tblCellMar><w:left w:w="0" w:type="dxa"/><w:right w:w="0" w:type="dxa"/></w:tblCellMar></w:tblPr>'
            f'<w:tblGrid>{griglia}</w:tblGrid>{"".join(righe)}</w:tbl>')


def _riga(*celle: str, intestazione: bool = False, altezza: int = 0) -> str:
    pr = ("<w:tblHeader/>" if intestazione else "") + "<w:cantSplit/>" + (f'<w:trHeight w:val="{altezza}"/>' if altezza else "")
    return f"<w:tr><w:trPr>{pr}</w:trPr>{''.join(celle)}</w:tr>"


def _immagine(rid: str, cx: int, cy: int) -> str:
    return (f'<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="{cx}" cy="{cy}"/>'
            f'<wp:docPr id="1" name="Logo AD"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
            f'<a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">'
            f'<pic:nvPicPr><pic:cNvPr id="1" name="logo.png"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="{rid}"/>'
            f'<a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm>'
            f'<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>')


# ---------------------------------------------------------------- contenuto


def _pulisci_descrizione(testo: str) -> str:
    """Nelle righe DM la descrizione dell'XML porta anche «preventivo …» e «rif. ordine cliente …»: nella copia di
    cortesia questi riferimenti vanno una volta sola in fondo quando sono uguali per tutte le righe."""
    t = re.sub(r",\s*rif\. ordine cliente [^,]*$", "", testo)
    return re.sub(r",\s*preventivo [^,]*$", "", t)


def _testo_documento(d: dict) -> str:
    extra = [f"CIG {d['cig']}" if d.get("cig") else "", f"CUP {d['cup']}" if d.get("cup") else "",
             f"commessa {d['commessa']}" if d.get("commessa") else ""]
    return (f"Rif. {NOMI_DOC.get(d.get('tipo'), d.get('tipo'))} n. {d.get('numero')}"
            + (f" del {data_it(d['data'])}" if d.get("data") else "")
            + "".join(f", {x}" for x in extra if x))


def righe_stampa(f: dict) -> tuple[list[dict], list[str]]:
    """R140: documenti comuni in fondo; diversi nella riga che ne conserva la fotografia.

    I vecchi documenti senza fotografia per riga restano note generali: non si ricostruiscono
    dai preventivi correnti i riferimenti di una fattura già emessa.
    """
    righe = f.get("righe") or []
    preventivi = {(r.get("riferimenti") or {}).get("preventivo") for r in righe if (r.get("riferimenti") or {}).get("preventivo")}
    comune = len(preventivi) == 1 and all((r.get("riferimenti") or {}).get("preventivo") for r in righe)
    per_riga = [{chiave_documento(d): d for d in (r.get("riferimenti") or {}).get("documenti_collegati") or []}
                for r in righe]
    comuni = set.intersection(*(set(d) for d in per_riga)) if per_riga else set()
    assegnati = set().union(*(set(d) for d in per_riga))
    out = []
    for r, documenti in zip(righe, per_riga):
        ref = r.get("riferimenti") or {}
        strutturati_dm = ref.get('ambito') == 'DM' and 'documenti_collegati' in ref and ref.get('preventivo')
        testo = _pulisci_descrizione(r["descrizione"]) if comune or strutturati_dm else r["descrizione"]
        if ref.get("verbale") and ref["verbale"] not in testo:
            testo += f" - verbale {ref['verbale']}"
        if not comune and ref.get("preventivo") and ref["preventivo"] not in testo:
            testo += f" - rif. preventivo {ref['preventivo']}"
        for chiave, d in documenti.items():
            if chiave not in comuni:
                testo += ' - ' + _testo_documento(d)
        aliquota = r.get("natura") or aliquota_testo(r["aliquota"])
        out.append({"codice": "", "descrizione": testo, "quantita": str(r.get("quantita") or "1").replace(".", ","),
                    "prezzo": importo(_cent(r.get("prezzo"))), "importo": importo(r["importo"]), "iva": aliquota})
    note = []
    if comune:
        note.append(f"Rif. preventivo {next(iter(preventivi))}")
    if per_riga:
        note.extend('(' + _testo_documento(d) + ')' for k, d in per_riga[0].items() if k in comuni)
    o = f.get("opzioni") or {}
    docs = list(o.get("documenti") or [])
    if o.get("ordine"):
        d = {"tipo": "OrdineAcquisto", "numero": o["ordine"], "data": o.get("data_ordine", ""),
             "cig": o.get("cig", ""), "cup": o.get("cup", "")}
        if not any(chiave_documento(x) == chiave_documento(d) for x in docs):
            docs.insert(0, d)
    aggiunti = set(assegnati)
    for d in docs:
        k = chiave_documento(d)
        if k not in aggiunti:
            note.append('(' + _testo_documento(d) + ')')
            aggiunti.add(k)
    if f.get("originale"):
        note.append(f"Rettifica della fattura {f['originale']['codice']} del {data_it(f['originale']['data'])}")
    if o.get("causale"):
        note.append(o["causale"])
    return out, note


def _cent(prezzo) -> int:  # noqa: ANN001
    try:
        from decimal import Decimal
        return int((Decimal(str(prezzo).replace(",", ".")) * 100).to_integral_value())
    except Exception:  # noqa: BLE001
        return 0


def word_fattura(f: dict, bozza: bool | None = None) -> bytes:
    so, c = f["societa"], f["cliente"]
    bozza = (not f.get("codice")) if bozza is None else bozza
    W = 10466  # area utile A4 con margini di 1,5 cm (twip)
    corpo = []

    # intestazione: logo e dati di AD
    dati_ad = [so.get("indirizzo", ""), " ".join(x for x in (so.get("cap", ""), so.get("comune", ""),
                                                            f"({so['provincia']})" if so.get("provincia") else "") if x)]
    contatti = " ".join(x for x in (f"tel. {so['telefono']}" if so.get("telefono") else "", f"e-mail {so['email']}" if so.get("email") else "") if x)
    fiscali = " ".join(x for x in (f"C.F. {so['codice_fiscale']}" if so.get("codice_fiscale") else "",
                                   f"P.IVA {so['partita_iva']}" if so.get("partita_iva") else "") if x)
    destra = (_p(_r(so.get("ragione_sociale", "AD S.r.l."), size=40), allinea="right", dopo=40)
              + _p(_r(" - ".join(x for x in dati_ad if x), size=16), allinea="right")
              + (_p(_r(contatti, size=16), allinea="right") if contatti else "")
              + _p(_r(fiscali, size=16), allinea="right"))
    logo = _p(_immagine("rIdLogo", 1260000, 1260000)) if LOGO.exists() else _p("")
    corpo.append(_tabella([3200, W - 3200], [_riga(_cella(logo, 3200, bordi=False), _cella(destra, W - 3200, bordi=False, valign="center"))]))

    # tipo, numero e data
    titolo = TITOLI.get(f["tipo"], "Fattura")
    numero = "BOZZA" if bozza else f["codice"]
    corpo.append(_p(_r(f"{f['tipo']}: {TIPI.get(f['tipo'], '')}", b=True), prima=160))
    corpo.append(_p(_r(f"{titolo} Nr. "), _r(numero, b=True), _r(" del "), _r(data_it(f["data"]), b=True), dopo=80))
    if bozza:
        corpo.append(_p(_r("BOZZA – non valida ai fini fiscali: il numero si assegna all'emissione", b=True, size=20, colore="C00000"), dopo=80))

    # riquadro cliente
    ind = " ".join(x for x in (c.get("cap", ""), c.get("comune", ""), f"({c['provincia']})" if c.get("provincia") else "") if x)
    cliente = (_p(_r("Cliente", b=True), dopo=120) + _p(_r(c.get("ragione_sociale", ""))) + _p(_r(c.get("indirizzo", "")))
               + _p(_r(ind), dopo=120)
               + (_p(_r(f"C.F. {c['codice_fiscale']}")) if c.get("codice_fiscale") else "")
               + (_p(_r(f"P.IVA {c['partita_iva']}")) if c.get("partita_iva") else ""))
    corpo.append(_tabella([4600, W - 4600], [_riga(_cella(cliente, 4600, sfondo=GRIGIO, bordi=False), _cella("", W - 4600, bordi=False))]))
    corpo.append(_p("", dopo=200))

    # righe
    larg = [900, 5266, 700, 1200, 1500, 900]
    intest = ["Cod.\nArticolo", "Descrizione", "Qtà", "Prezzo", "Importo", "IVA"]
    allinea = ["left", "left", "right", "right", "right", "center"]
    tr = [_riga(*(_cella(_p(_r(t, b=True, size=16), allinea=a), w) for t, w, a in zip(intest, larg, allinea)), intestazione=True)]
    righe, note = righe_stampa(f)
    for r in righe:
        valori = [r["codice"], r["descrizione"], r["quantita"], r["prezzo"], r["importo"], r["iva"]]
        tr.append(_riga(*(_cella(_p(_r(v, size=16), allinea=a), w) for v, w, a in zip(valori, larg, allinea))))
    tr.append(_riga(*(_cella("", w) for w in larg), altezza=200))
    for n in note + ["Copia della fattura elettronica disponibile nella Sua area riservata dell'Agenzia delle Entrate"]:
        tr.append(_riga(_cella("", larg[0]), _cella(_p(_r(n, size=16)), larg[1]), *(_cella("", w) for w in larg[2:])))
    vuote = max(0, 8 - len(righe) - len(note))
    for _ in range(vuote):
        tr.append(_riga(*(_cella("", w) for w in larg), altezza=280))
    corpo.append(_tabella(larg, tr))
    corpo.append(_p("", dopo=200))

    # riepilogo IVA e totali
    rie = [_riga(_cella(_p(_r("Riepilogo IVA", b=True, size=16)), 3000, bordi=False), _cella(_p(_r("Imponibile", b=True, size=16), allinea="right"), 1500, bordi=False),
                 _cella(_p(_r("Imposta", b=True, size=16), allinea="right"), 1200, bordi=False))]
    for g in f.get("riepiloghi") or []:
        etich = f"{g['natura']} - {NATURE.get(g['natura'], 'Non imponibile')}" if g.get("natura") else \
            f"{aliquota_testo(g['aliquota'])} - Imponibile {aliquota_testo(g['aliquota'])}%"
        if g.get("esigibilita") == "S":
            etich += " (scissione dei pagamenti)"
        rie.append(_riga(_cella(_p(_r(etich, size=16)), 3000, bordi=False), _cella(_p(_r(importo(g["imponibile"]), size=16), allinea="right"), 1500, bordi=False),
                         _cella(_p(_r(importo(g["iva"]), size=16), allinea="right"), 1200, bordi=False)))
    tot = [("Tot. imponibile", f["imponibile"]), ("Tot. IVA", f["iva"])]
    if f.get("bollo"):
        tot.append(("Bollo", f["bollo"]))
    totali_tab = _tabella([2800, 1966], [_riga(_cella("".join(_p(_r(t, size=16)) for t, _ in tot) + _p(_r("Tot. documento", b=True, size=16), prima=120), 2800, sfondo=GRIGIO, bordi=False),
                                                _cella("".join(_p(_r(importo(v), size=16), allinea="right") for _, v in tot)
                                                       + _p(_r(importo(f["totale"]), b=True, size=16), allinea="right", prima=120), 1966, sfondo=GRIGIO, bordi=False))])
    corpo.append(_tabella([5700, W - 5700], [_riga(_cella(_tabella([3000, 1500, 1200], rie), 5700, bordi=False), _cella(totali_tab, W - 5700, bordi=False))]))
    corpo.append(_p("", dopo=200))

    # pagamento, scadenze, totale dovuto
    o = f.get("opzioni") or {}
    modalita = (f.get("scadenze") or [{}])[0].get("modalita") if f.get("scadenze") else o.get("modalita", "")
    pag = _p(_r("Pagamento", b=True, size=16)) + _p(_r(modalita or "", size=16)) + _p(_r(so.get("banca", ""), size=16)) \
        + _p(_r(o.get("iban") or so.get("iban", ""), size=16))
    sca = [_riga(_cella(_p(_r("Data scadenza", b=True, size=16)), 1500, bordi=False), _cella(_p(_r("Importo", b=True, size=16), allinea="right"), 1300, bordi=False))]
    for q in f.get("scadenze") or []:
        sca.append(_riga(_cella(_p(_r(data_it(q["data"]), size=16)), 1500, bordi=False), _cella(_p(_r(importo(q["importo"]), size=16), allinea="right"), 1300, bordi=False)))
    dovuto = _tabella([2800, 1966], [_riga(_cella(_p(_r("Tot. dovuto", b=True, size=18)), 2800, sfondo=GRIGIO, bordi=False),
                                           _cella(_p(_r(importo(f["dovuto"]), b=True, size=18), allinea="right"), 1966, sfondo=GRIGIO, bordi=False))])
    corpo.append(_tabella([2900, 2800, W - 5700], [_riga(_cella(pag, 2900, bordi=False), _cella(_tabella([1500, 1300], sca), 2800, bordi=False),
                                                         _cella(dovuto, W - 5700, bordi=False, valign="bottom"))]))
    if f.get("ritenuta"):
        corpo.append(_p(_r(f"Ritenuta d'acconto: {importo(f['ritenuta'])}", size=16), prima=120))

    campo = ('<w:fldSimple w:instr=" %s "><w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/><w:sz w:val="16"/></w:rPr>'
             '<w:t>1</w:t></w:r></w:fldSimple>')
    piede = ('<w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:p><w:pPr><w:jc w:val="left"/></w:pPr>'
             + _r("Pag.", size=16) + campo % "PAGE" + _r("/", size=16) + campo % "NUMPAGES" + "</w:p></w:ftr>")
    ns = ('xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
          'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
          'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"')
    documento = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document {ns}><w:body>{"".join(corpo)}'
                 '<w:sectPr><w:footerReference w:type="default" r:id="rIdPiede"/><w:pgSz w:w="11906" w:h="16838"/>'
                 '<w:pgMar w:top="850" w:right="720" w:bottom="850" w:left="720" w:header="400" w:footer="400" w:gutter="0"/></w:sectPr>'
                 "</w:body></w:document>")
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml",
                   '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                   '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                   '<Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/>'
                   '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
                   '<Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>')
        z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
        z.writestr("word/_rels/document.xml.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rIdLogo" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/logo.png"/>'
                   '<Relationship Id="rIdPiede" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer" Target="footer1.xml"/></Relationships>')
        z.writestr("word/document.xml", documento)
        z.writestr("word/footer1.xml", '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' + piede)
        if LOGO.exists():
            z.writestr("word/media/logo.png", LOGO.read_bytes())
    return b.getvalue()


def nome_pdf(f: dict) -> str:
    """Nome come i PDF di Garda: «Fattura_390-2026-DPR_del_19-09-2026_<cliente>.pdf» (bozza: «Bozza_fattura_…»)."""
    cliente = re.sub(r"[^A-Za-z0-9]+", "_", f["cliente"].get("ragione_sociale", "")).strip("_")[:60]
    data = data_it(f["data"]).replace("/", "-")
    if not f.get("codice"):
        return f"Bozza_fattura_del_{data}_{cliente}.pdf"
    titolo = "Nota_di_credito" if f["tipo"] == "TD04" else "Fattura"
    return f"{titolo}_{f['codice'].replace('/', '-')}_del_{data}_{cliente}.pdf"


def pdf_fattura(f, libreoffice=""):
    return pdf.da_word(word_fattura(f), libreoffice)
