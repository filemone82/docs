"""Documenti fiscali, tentativi XML, scadenze e movimenti: importi in centesimi."""

from datetime import date, datetime

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    Date,
    DateTime,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from ...core.db import Base, adesso
from ...core.modelli_comuni import Centesimi, Tracciato


class Societa(Base, Tracciato):
    __tablename__ = "societa"
    id: Mapped[int] = mapped_column(primary_key=True)
    codice: Mapped[str] = mapped_column(String(12), unique=True)
    dati: Mapped[str] = mapped_column(Text, default="{}")


class Fattura(Base, Tracciato):
    __tablename__ = "fatture"
    __table_args__ = (
        UniqueConstraint("societa_id", "ambito", "tipo", "anno", "numero"),
        CheckConstraint(
            "stato IN ('bozza','emessa','scartata','consegnata','mancata_consegna','accettata_pa','rifiutata_pa')",
            name="stato",
        ),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    societa_id: Mapped[int] = mapped_column(
        ForeignKey("societa.id", ondelete="RESTRICT")
    )
    ambito: Mapped[str] = mapped_column(String(12), default="DPR", index=True)
    tipo: Mapped[str] = mapped_column(String(4), default="TD01")
    anno: Mapped[int] = mapped_column(Integer)
    numero: Mapped[int | None] = mapped_column(Integer, nullable=True)
    codice: Mapped[str] = mapped_column(String(40), default="")
    stato: Mapped[str] = mapped_column(String(24), default="bozza", index=True)
    data: Mapped[date] = mapped_column(Date)
    cliente_id: Mapped[int] = mapped_column(
        ForeignKey("clienti.id", ondelete="RESTRICT"), index=True
    )
    originale_id: Mapped[int | None] = mapped_column(
        ForeignKey("fatture.id", ondelete="RESTRICT"), nullable=True
    )
    opzioni: Mapped[str] = mapped_column(Text, default="{}")
    fotografia: Mapped[str] = mapped_column(Text, default="{}")
    imponibile: Mapped[int] = mapped_column(Centesimi, default=0)
    iva: Mapped[int] = mapped_column(Centesimi, default=0)
    totale: Mapped[int] = mapped_column(Centesimi, default=0)
    dovuto: Mapped[int] = mapped_column(Centesimi, default=0)
    revisione_xml: Mapped[int] = mapped_column(Integer, default=0)


class RigaFattura(Base):
    __tablename__ = "fatture_righe"
    __table_args__ = (CheckConstraint("importo >= 0", name="importo"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    fattura_id: Mapped[int] = mapped_column(
        ForeignKey("fatture.id", ondelete="CASCADE"), index=True
    )
    riga_preventivo_id: Mapped[int | None] = mapped_column(
        ForeignKey("preventivi_righe.id", ondelete="RESTRICT"),
        nullable=True,
        index=True,
    )
    # Una prestazione può essere fatturata in acconto e a saldo: allocazioni distinte.
    origine_credito_id: Mapped[int | None] = mapped_column(
        ForeignKey("fatture_righe.id", ondelete="RESTRICT"), nullable=True
    )
    descrizione: Mapped[str] = mapped_column(String(1000))
    quantita: Mapped[str] = mapped_column(String(30), default="1")
    prezzo: Mapped[str] = mapped_column(String(30))  # decimale esatto, non Float
    importo: Mapped[int] = mapped_column(Centesimi)
    aliquota: Mapped[int] = mapped_column(Integer, default=2200)
    natura: Mapped[str] = mapped_column(String(8), default="")
    esigibilita: Mapped[str] = mapped_column(String(1), default="I")
    riferimento_normativo: Mapped[str] = mapped_column(String(200), default="")
    riferimenti: Mapped[str] = mapped_column(Text, default="{}")
    # Garda DM: la prestazione resta interamente fatturata anche con prezzo manuale.
    prestazione_intera: Mapped[bool] = mapped_column(Boolean, default=False, server_default="0")


class ScadenzaFattura(Base):
    __tablename__ = "fatture_scadenze"
    __table_args__ = (CheckConstraint("importo > 0", name="importo"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    fattura_id: Mapped[int] = mapped_column(
        ForeignKey("fatture.id", ondelete="CASCADE"), index=True
    )
    data: Mapped[date] = mapped_column(Date)
    importo: Mapped[int] = mapped_column(Centesimi)
    modalita: Mapped[str] = mapped_column(String(4), default="MP05")


class EsportazioneFattura(Base):
    __tablename__ = "fatture_esportazioni"
    __table_args__ = (UniqueConstraint("fattura_id", "revisione"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    fattura_id: Mapped[int] = mapped_column(
        ForeignKey("fatture.id", ondelete="RESTRICT"), index=True
    )
    revisione: Mapped[int] = mapped_column(Integer)
    # 0.14: nome del file per lo SdI (IT<trasmittente>_<progressivo di 5 caratteri>.xml), unico; vuoto nelle esportazioni
    # precedenti, che conservano il nome di allora
    nome_file: Mapped[str] = mapped_column(String(60), default="", server_default="", index=True)
    xml: Mapped[str] = mapped_column(Text)
    sha256: Mapped[str] = mapped_column(String(64))
    fotografia: Mapped[str] = mapped_column(Text)
    creato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    creato_da: Mapped[str] = mapped_column(String(120), default="")


class EsitoFattura(Base):
    __tablename__ = "fatture_esiti"
    __table_args__ = (UniqueConstraint("identificativo_origine"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    esportazione_id: Mapped[int] = mapped_column(
        ForeignKey("fatture_esportazioni.id", ondelete="RESTRICT"), index=True
    )
    esito: Mapped[str] = mapped_column(String(24))
    messaggio: Mapped[str] = mapped_column(Text, default="")
    identificativo_origine: Mapped[str] = mapped_column(String(120))
    registrato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    registrato_da: Mapped[str] = mapped_column(String(120), default="")


class DocumentoFattura(Base):
    """Versioni PDF archiviate: i pacchetti INAIL usano questi stessi byte."""
    __tablename__ = "fatture_documenti"
    __table_args__ = (UniqueConstraint("fattura_id", "revisione"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    fattura_id: Mapped[int] = mapped_column(ForeignKey("fatture.id", ondelete="RESTRICT"), index=True)
    documento_id: Mapped[int] = mapped_column(ForeignKey("documenti.id", ondelete="RESTRICT"))
    revisione: Mapped[int] = mapped_column(Integer)
    revisione_xml: Mapped[int] = mapped_column(Integer)
    fotografia_sha256: Mapped[str] = mapped_column(String(64))
    nome_file: Mapped[str] = mapped_column(String(255))
    origine: Mapped[str] = mapped_column(String(30))
    creato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    creato_da: Mapped[str] = mapped_column(String(120))


class Incasso(Base, Tracciato):
    __tablename__ = "incassi"
    __table_args__ = (CheckConstraint("importo > 0", name="importo"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    societa_id: Mapped[int] = mapped_column(
        ForeignKey("societa.id", ondelete="RESTRICT"), index=True
    )
    cliente_id: Mapped[int] = mapped_column(
        ForeignKey("clienti.id", ondelete="RESTRICT"), index=True
    )
    data: Mapped[date] = mapped_column(Date)
    importo: Mapped[int] = mapped_column(Centesimi)
    causale: Mapped[str] = mapped_column(String(500), default="")
    metodo: Mapped[str] = mapped_column(String(60), default="bonifico")
    stornato: Mapped[bool] = mapped_column(Boolean, default=False)
    motivo_storno: Mapped[str] = mapped_column(String(500), default="")


class AllocazioneIncasso(Base):
    __tablename__ = "incassi_allocazioni"
    __table_args__ = (
        UniqueConstraint("incasso_id", "fattura_id"),
        CheckConstraint("importo > 0", name="importo"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    incasso_id: Mapped[int] = mapped_column(
        ForeignKey("incassi.id", ondelete="CASCADE"), index=True
    )
    fattura_id: Mapped[int] = mapped_column(
        ForeignKey("fatture.id", ondelete="RESTRICT"), index=True
    )
    importo: Mapped[int] = mapped_column(Centesimi)
