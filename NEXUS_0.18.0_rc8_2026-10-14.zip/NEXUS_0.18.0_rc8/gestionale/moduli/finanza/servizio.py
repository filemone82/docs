"""Contabilità clienti indipendente dal modulo tecnico. Ogni mutazione è transazionale.

Documento emesso e tentativi XML conservano fotografie immutabili. Incasso è un movimento
reale con ripartizioni; nota di credito rettifica il credito senza inventare incassi.
"""

import hashlib
import json
import re
from datetime import date
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

from sqlalchemy import func, select

from ...core.date import oggi_italia
from ...core.db import adesso
from ...core.errori import Conflitto, ErroreUtente, NonTrovato
from ..anagrafica.modelli import Cliente
from ..anagrafica.servizio import controlla_versione as _controlla_versione
from ..preventivi.modelli import Preventivo, Riesame, RigaPreventivo
from ..registro import servizio as registro
from ..verifiche.modelli import Verifica
from .modelli import (
    AllocazioneIncasso,
    EsitoFattura,
    EsportazioneFattura,
    Fattura,
    Incasso,
    RigaFattura,
    ScadenzaFattura,
    Societa,
)
from . import prestazioni
from .riferimenti import chiave_documento

TIPI = {"TD01": "Fattura", "TD02": "Fattura di acconto", "TD04": "Nota di credito"}
ESITI = {"scartata", "consegnata", "mancata_consegna", "accettata_pa", "rifiutata_pa"}
CAMPI_CLIENTE = (
    "ragione_sociale",
    "tipo",
    "nazione",
    "partita_iva",
    "codice_fiscale",
    "indirizzo",
    "cap",
    "comune",
    "provincia",
    "pec",
    "codice_sdi",
    "email_fatture",
    "riferimento_amministrazione",
)


def dumps(x):
    return json.dumps(x, ensure_ascii=False, sort_keys=True)


def controlla_versione(x, v):
    if v is None or isinstance(v, bool):
        raise ErroreUtente("Versione mancante: ricarica il documento.")
    try:
        v = int(v)
    except (ValueError, TypeError):
        raise ErroreUtente("Versione non valida.") from None
    _controlla_versione(x, v)


def ident(v):
    try:
        if isinstance(v, bool):
            raise TypeError
        n = int(v)
        if n <= 0 or str(v) != str(n):
            raise ValueError
        return n
    except (ValueError, TypeError):
        raise ErroreUtente("Identificativo non valido.") from None


def dec(v, nome="Importo"):
    try:
        d = Decimal(str(v).replace(",", "."))
        if not d.is_finite() or abs(d) > Decimal(1000000000):
            raise InvalidOperation
        return d
    except (InvalidOperation, ValueError, TypeError):
        raise ErroreUtente(f"{nome}: scrivi un numero valido.") from None


def cent(v):
    return int((dec(v) * 100).quantize(Decimal(1), rounding=ROUND_HALF_UP))


def euro(v):
    return f"{Decimal(v) / 100:.2f}"


def giorno(v):
    try:
        return date.fromisoformat(str(v))
    except ValueError:
        raise ErroreUtente("Data non valida (aaaa-mm-gg).") from None


def get(s, model, id):
    x = s.get(model, id)
    if x is None:
        raise NonTrovato("Elemento non trovato.")
    return x


def evento(s, u, x, azione, dettagli=None):
    x.modificato_il, x.modificato_da = adesso(), u.nome
    x.versione = (x.versione or 0) + 1
    s.flush()
    registro.scrivi(
        s,
        utente=u,
        azione="economia." + azione,
        oggetto_tipo=x.__tablename__,
        oggetto_id=x.id,
        descrizione=azione.replace("_", " "),
        dettagli=dettagli or {},
    )


def inizializza(s):
    for codice in ("AD", "IEC"):
        if not s.scalar(select(Societa).where(Societa.codice == codice)):
            s.add(Societa(codice=codice, dati="{}"))


def societa_json(x):
    return {
        "id": x.id,
        "codice": x.codice,
        "dati": json.loads(x.dati),
        "versione": x.versione,
    }


def aggiorna_societa(s, u, id, d):
    x = get(s, Societa, id)
    controlla_versione(x, d.get("versione"))
    valori = d.get("dati", {})
    if not isinstance(valori, dict):
        raise ErroreUtente("Dati societari non validi.")
    ammessi = {
        "ragione_sociale",
        "partita_iva",
        "codice_fiscale",
        "indirizzo",
        "cap",
        "comune",
        "provincia",
        "nazione",
        "regime_fiscale",
        "iban",
        "banca",
        "id_trasmittente",
        # 0.14 (FIN-04, Garda «configurazioni»): REA, capitale, socio unico, liquidazione, contatti
        "rea_ufficio",
        "rea_numero",
        "capitale_sociale",
        "socio_unico",
        "stato_liquidazione",
        "telefono",
        "fax",
        "email",
    }
    if set(valori) - ammessi or any(
        not isinstance(v, str) or len(v) > 250 for v in valori.values()
    ):
        raise ErroreUtente("Campi societari non validi.")
    prima = json.loads(x.dati)
    x.dati = dumps({**prima, **valori})
    evento(s, u, x, "societa_modifica", {"prima": prima, "dopo": json.loads(x.dati)})
    return societa_json(x)


def righe(s, f):
    return list(
        s.scalars(
            select(RigaFattura)
            .where(RigaFattura.fattura_id == f.id)
            .order_by(RigaFattura.id)
        )
    )


def scadenze(s, f):
    return list(
        s.scalars(
            select(ScadenzaFattura)
            .where(ScadenzaFattura.fattura_id == f.id)
            .order_by(ScadenzaFattura.data, ScadenzaFattura.id)
        )
    )


def riga_json(r):
    return {
        "id": r.id,
        "riga_preventivo_id": r.riga_preventivo_id,
        "origine_credito_id": r.origine_credito_id,
        "descrizione": r.descrizione,
        "quantita": r.quantita,
        "prezzo": r.prezzo,
        "importo": r.importo,
        "aliquota": r.aliquota,
        "natura": r.natura,
        "esigibilita": r.esigibilita,
        "riferimento_normativo": r.riferimento_normativo,
        "riferimenti": json.loads(r.riferimenti),
        "prestazione_intera": r.prestazione_intera,
    }


def somme(rs, opzioni):
    gruppi = {}
    for r in rs:
        k = (r.aliquota, r.natura, r.esigibilita, r.riferimento_normativo)
        gruppi[k] = gruppi.get(k, 0) + r.importo
    riepiloghi = [
        {
            "aliquota": k[0],
            "natura": k[1],
            "esigibilita": k[2],
            "riferimento_normativo": k[3],
            "imponibile": v,
            "iva": int(
                (Decimal(v) * k[0] / 10000).quantize(Decimal(1), rounding=ROUND_HALF_UP)
            ),
        }
        for k, v in sorted(gruppi.items())
    ]
    base = sum(r.importo for r in rs)
    iva = sum(g["iva"] for g in riepiloghi)
    split = sum(g["iva"] for g in riepiloghi if g["esigibilita"] == "S")
    percentuale = dec(opzioni.get("ritenuta_percentuale", "0"))
    if percentuale < 0 or percentuale > 100:
        raise ErroreUtente("Ritenuta non valida.")
    ritenuta = cent(Decimal(base) / 100 * percentuale / 100)
    bollo = cent(opzioni.get("bollo", "0"))
    if bollo < 0:
        raise ErroreUtente("Bollo non negativo obbligatorio.")
    totale = base + iva + bollo
    return {
        "imponibile": base,
        "iva": iva,
        "totale": totale,
        "dovuto": totale - split - ritenuta,
        "ritenuta": ritenuta,
        "bollo": bollo,
        "riepiloghi": riepiloghi,
    }


def saldo(s, f):
    pagato = (
        s.scalar(
            select(func.coalesce(func.sum(AllocazioneIncasso.importo), 0))
            .join(Incasso)
            .where(AllocazioneIncasso.fattura_id == f.id, Incasso.stornato.is_(False))
        )
        or 0
    )
    crediti = (
        s.scalar(
            select(func.coalesce(func.sum(Fattura.dovuto), 0)).where(
                Fattura.originale_id == f.id,
                Fattura.tipo == "TD04",
                Fattura.stato.not_in(("bozza", "scartata")),
            )
        )
        or 0
    )
    return {
        "pagato": pagato,
        "rettifiche": crediti,
        "residuo": max(0, f.dovuto - pagato - crediti),
    }


def fattura_json(s, f):
    from .documenti import elenco as elenco_documenti
    rs = righe(s, f)
    totals = (
        somme(rs, json.loads(f.opzioni))
        if f.stato == "bozza"
        else {k: getattr(f, k) for k in ("imponibile", "iva", "totale", "dovuto")}
    )
    foto = json.loads(f.fotografia)
    c = get(s, Cliente, f.cliente_id)
    cliente = foto.get("cliente", {}).get("ragione_sociale", c.ragione_sociale)
    sc = scadenze(s, f)
    exports = list(
        s.scalars(
            select(EsportazioneFattura)
            .where(EsportazioneFattura.fattura_id == f.id)
            .order_by(EsportazioneFattura.revisione)
        )
    )
    return {
        "id": f.id,
        "societa_id": f.societa_id,
        "ambito": f.ambito,
        "tipo": f.tipo,
        "stato": f.stato,
        "codice": f.codice,
        "data": f.data.isoformat(),
        "cliente_id": f.cliente_id,
        "cliente": cliente,
        "originale_id": f.originale_id,
        "opzioni": json.loads(f.opzioni),
        "fotografia": foto,
        "versione": f.versione,
        "righe": [riga_json(r) for r in rs],
        "documenti": elenco_documenti(s, f),
        "scadenze": [
            {
                "id": q.id,
                "data": q.data.isoformat(),
                "importo": q.importo,
                "modalita": q.modalita,
            }
            for q in sc
        ],
        **totals,
        **saldo(s, f),
        **(info_bozza(s, f, rs) if f.stato == "bozza" else {}),
        "esportazioni": [
            {
                "id": e.id,
                "revisione": e.revisione,
                "sha256": e.sha256,
                "creato_il": e.creato_il.isoformat(),
                "creato_da": e.creato_da,
                "nome_file": e.nome_file,
                "esiti": [
                    {
                        "esito": x.esito,
                        "messaggio": x.messaggio,
                        "registrato_il": x.registrato_il.isoformat(),
                    }
                    for x in s.scalars(
                        select(EsitoFattura).where(EsitoFattura.esportazione_id == e.id)
                    )
                ],
            }
            for e in exports
        ],
    }


NATURE_BOLLO = ("N1", "N2", "N3", "N4")   # escluse, non soggette, non imponibili, esenti
SOGLIA_BOLLO = 7747                       # 77,47 € (art. 6 tabella allegato B DPR 642/72)


def mancanti_dettaglio(s, f):
    """C6 (0.16): dati senza i quali la fattura non si può emettere, detti prima, invece di un «errore imprevisto»
    (su un archivio nuovo i Dati fiscali AD sono vuoti).
    rc8 (punto 6, decisione del 14/10/2026): l'avviso dice chiaramente se mancano dati della **società emittente** o del
    **cliente** e porta alla sezione giusta (dati della società: Gestione › Configurazione; cliente: la sua scheda), con
    ritorno alla stessa bozza. Il nome della società viene dalla società della fattura (AD oggi, I&C domani)."""
    so = get(s, Societa, f.societa_id)
    d = json.loads(so.dati or "{}")
    out = []
    nomi = {"ragione_sociale": "ragione sociale", "partita_iva": "partita IVA", "indirizzo": "indirizzo", "cap": "CAP",
            "comune": "comune", "provincia": "provincia", "regime_fiscale": "regime fiscale"}
    vuoti = [n for k, n in nomi.items() if not str(d.get(k) or "").strip()]
    if vuoti:
        out.append({"chi": "emittente", "url": f"/dati-societari?ritorno=/fatture?apri={f.id}",
                    "testo": f"Società emittente {so.codice}, dati fiscali (Gestione › Configurazione › Dati della società e pagamenti): "
                             + ", ".join(vuoti)})
    c = s.get(Cliente, f.cliente_id)
    if c is not None:
        vc = [n for k, n in (("indirizzo", "indirizzo"), ("cap", "CAP"), ("comune", "comune")) if not str(getattr(c, k) or "").strip()]
        if not (c.partita_iva or c.codice_fiscale):
            vc.append("partita IVA o codice fiscale")
        if vc:
            out.append({"chi": "cliente", "url": f"/clienti?apri={c.id}",
                        "testo": f"Cliente «{c.ragione_sociale}», scheda del cliente: " + ", ".join(vc)})
    if not righe(s, f):
        out.append({"chi": "documento", "url": "", "testo": "almeno una riga"})
    return out


def mancanti(s, f):
    return [x["testo"] for x in mancanti_dettaglio(s, f)]


def info_bozza(s, f, rs):
    """Per la bozza: modalità di pagamento che si userà e avvisi da controllare prima dell'emissione."""
    from . import pagamenti
    x, provenienza = pagamenti.modalita_della_fattura(s, f)
    avvisi = []
    o = json.loads(f.opzioni)
    esente = sum(r.importo for r in rs if r.natura[:2] in NATURE_BOLLO)
    if esente > SOGLIA_BOLLO and not cent(o.get("bollo", "0") or "0"):
        avvisi.append(f"Righe senza IVA per {euro(esente)} €: oltre 77,47 € serve il bollo virtuale di 2,00 € "
                      "(«Dati documento» › Bollo), salvo i casi di esenzione.")
    c = s.get(Cliente, f.cliente_id)
    if c is not None and c.tipo == "pa" and not (o.get("documenti") or o.get("ordine") or o.get("cig")):
        avvisi.append("Pubblica amministrazione: di solito servono ordine o contratto con CIG (e CUP se previsto).")
    return {"modalita_pagamento": {"id": x.id if x else None, "descrizione": x.descrizione if x else "",
                                   "provenienza": provenienza}, "avvisi": avvisi, "mancanti": mancanti(s, f),
            "mancanti_dettaglio": mancanti_dettaglio(s, f)}


def modifica(s, u, f, d):
    if f.stato != "bozza":
        raise ErroreUtente(
            "Il documento emesso è immutabile. Usa una nota di credito; per uno scarto prepara un nuovo tentativo."
        )
    controlla_versione(f, d.get("versione"))
    if "cliente_id" in d:
        nuovo = get(s, Cliente, ident(d["cliente_id"])).id
        if f.originale_id and nuovo != get(s, Fattura, f.originale_id).cliente_id:
            raise ErroreUtente(
                "La nota di credito conserva l’intestatario della fattura originaria."
            )
        f.cliente_id = nuovo
    if "data" in d:
        nuova = giorno(d["data"])
        if f.numero and nuova.year != f.anno:
            raise ErroreUtente(
                "Il numero riservato appartiene al suo anno: non cambiare anno."
            )
        f.data = nuova
        f.anno = f.data.year
    if "opzioni" in d:
        o = d["opzioni"]
        if not isinstance(o, dict) or set(o) - {
            "causale",
            "cig",
            "cup",
            "ordine",
            "data_ordine",
            "iban",
            "bollo",
            "ritenuta_percentuale",
            "ritenuta_tipo",
            "ritenuta_causale",
            "condizioni",
            "dichiarazione_protocollo",
            "dichiarazione_data",
            "documenti",
            "modalita_pagamento_id",
        }:
            raise ErroreUtente("Opzioni del documento non valide.")
        if any(not isinstance(v, str) or len(v) > 500 for k, v in o.items() if k != "documenti"):
            raise ErroreUtente("Opzioni: usa testi non superiori a 500 caratteri.")
        if "documenti" in o:
            o["documenti"] = documenti_validi(o["documenti"])
        f.opzioni = dumps(o)
    evento(s, u, f, "fattura_modifica")
    return f


TIPI_DOCUMENTO = ("OrdineAcquisto", "Contratto", "Convenzione", "Ricezione", "FattureCollegate", "DDT", "FatturaPrincipale")
NOMI_DOCUMENTO = {"OrdineAcquisto": "Ordine d'acquisto", "Contratto": "Contratto", "Convenzione": "Convenzione", "Ricezione": "Ricezione",
                  "FattureCollegate": "Fattura collegata", "DDT": "Doc. di trasporto", "FatturaPrincipale": "Fattura principale"}


def documenti_validi(docs):
    """Documenti collegati di Garda (fatture_clienti_doc_collegati): tipo, numero, data, CIG, CUP, commessa."""
    if not isinstance(docs, list) or len(docs) > 20:
        raise ErroreUtente("Documenti collegati non validi (al massimo 20).")
    out = []
    for d in docs:
        if not isinstance(d, dict) or d.get("tipo") not in TIPI_DOCUMENTO:
            raise ErroreUtente("Documento collegato: scegli il tipo (ordine, contratto, convenzione, ricezione, fattura collegata, "
                               "documento di trasporto, fattura principale).")
        numero = str(d.get("numero") or "").strip()
        if not numero or len(numero) > 20:
            raise ErroreUtente("Documento collegato: numero obbligatorio, al massimo 20 caratteri.")
        data = str(d.get("data") or "").strip()
        if data:
            data = giorno(data).isoformat()
        cig, cup = str(d.get("cig") or "").strip().upper(), str(d.get("cup") or "").strip().upper()
        if len(cig) > 15 or len(cup) > 15:
            raise ErroreUtente("CIG e CUP: al massimo 15 caratteri.")
        out.append({"tipo": d["tipo"], "numero": numero, "data": data, "cig": cig, "cup": cup,
                    "commessa": str(d.get("commessa") or "").strip()[:100]})
    return out


def crea(s, u, d):
    tipo = d.get("tipo", "TD01")
    if tipo not in TIPI:
        raise ErroreUtente("Tipo documento non previsto.")
    ambito = d.get("ambito", "DPR")
    if ambito not in ('DPR', 'DM', 'EX', 'IEC'):
        raise ErroreUtente('Ambito fiscale non valido.')
    so = get(s, Societa, ident(d["societa_id"]))
    if so.codice != ('IEC' if ambito == 'IEC' else 'AD'):
        raise ErroreUtente('Società emittente incompatibile con l’ambito della fattura.')
    c = get(s, Cliente, ident(d["cliente_id"]))
    dt = giorno(d.get("data", oggi_italia().isoformat()))
    f = Fattura(
        societa_id=so.id,
        cliente_id=c.id,
        ambito=ambito,
        tipo=tipo,
        data=dt,
        anno=dt.year,
        stato="bozza",
        creato_da=u.nome,
    )
    s.add(f)
    s.flush()
    modifica(s, u, f, {"versione": f.versione, "opzioni": d.get("opzioni", {})})
    if d.get("originale_id"):
        orig = get(s, Fattura, ident(d["originale_id"]))
        if (
            tipo != "TD04"
            or orig.tipo == "TD04"
            or orig.stato in ("bozza", "scartata")
            or (orig.societa_id, orig.cliente_id, orig.ambito) != (f.societa_id, f.cliente_id, f.ambito)
        ):
            raise ErroreUtente(
                "Nota di credito: scegli una fattura emessa della stessa società e dello stesso intestatario."
            )
        f.originale_id = orig.id
    return f


def disponibile_riga(s, riga_id, esclusa=None):
    r = get(s, RigaPreventivo, riga_id)
    fatturato = 0
    intera = False
    for rf, f in s.execute(
        select(RigaFattura, Fattura)
        .join(Fattura)
        .where(RigaFattura.riga_preventivo_id == riga_id)
    ):
        if f.id == esclusa or f.stato == "scartata":
            continue
        if f.tipo == "TD04" and f.stato == "bozza":
            continue
        if rf.prestazione_intera and f.tipo != 'TD04':
            intera = True
        fatturato += -rf.importo if f.tipo == "TD04" else rf.importo
    # DM (IE-38): la riga si fattura per intero; 0.12.8: una nota di credito che la storna tutta la riapre
    if intera:
        return 0 if fatturato > 0 else r.tariffa_applicata
    return max(0, r.tariffa_applicata - fatturato)


def fatturabili(s, ambito='DPR'):
    result = []
    for r, p in s.execute(
        select(RigaPreventivo, Preventivo)
        .join(Preventivo)
        .where(RigaPreventivo.stato == "accettata", Preventivo.ambito == ambito)
    ):
        rc = s.scalar(
            select(Riesame)
            .where(Riesame.preventivo_id == p.id)
            .order_by(Riesame.id.desc())
            .limit(1)
        )
        if not rc or rc.esito != "conforme":
            continue
        v = prestazioni.tecnico(s, r)
        saldo_ok = prestazioni.pronto(s, r)
        disponibile = disponibile_riga(s, r.id)
        if disponibile:
            result.append(
                {
                    "id": r.id,
                    "ambito": p.ambito,
                    "cliente_id": p.cliente_id,
                    "cliente": get(s, Cliente, p.cliente_id).ragione_sociale,
                    "preventivo": p.codice,
                    "descrizione": prestazioni.descrizione(s, r),
                    "verbale": v.codice_verbale if v else "",
                    "saldo_consentito": bool(saldo_ok),
                    "disponibile": disponibile,
                }
            )
    return result


def aggiungi_riga(s, u, f, d):
    if f.stato != "bozza":
        raise ErroreUtente("Documento emesso: le righe non si modificano.")
    controlla_versione(f, d.get("versione"))
    rp = None
    ref = {}
    importo_origine = None
    if d.get("riga_preventivo_id"):
        rp = get(s, RigaPreventivo, ident(d["riga_preventivo_id"]))
        p, v = prestazioni.controlla(s, rp, f)
        ref = prestazioni.riferimenti(s, rp, p, v)
        importo_origine = disponibile_riga(s, rp.id)
        if importo_origine <= 0:
            raise ErroreUtente('Prestazione già collegata a una fattura.')
    origine = None
    if d.get("origine_credito_id"):
        origine = get(s, RigaFattura, ident(d["origine_credito_id"]))
        if f.tipo != "TD04" or origine.fattura_id != f.originale_id:
            raise ErroreUtente("Riga della fattura originaria non valida.")
        rp = (
            get(s, RigaPreventivo, origine.riga_preventivo_id)
            if origine.riga_preventivo_id
            else None
        )
        gia = (
            s.scalar(
                select(func.coalesce(func.sum(RigaFattura.importo), 0))
                .join(Fattura)
                .where(
                    RigaFattura.origine_credito_id == origine.id,
                    Fattura.stato != "scartata",
                )
            )
            or 0
        )
        importo_origine = origine.importo - gia
        ref = json.loads(origine.riferimenti)
    q = dec(d.get("quantita", "1"), "Quantità")
    pr = dec(
        d.get("prezzo", euro(importo_origine) if importo_origine is not None else "0")
    )
    if (
        q <= 0
        or pr < 0
        or q != q.quantize(Decimal("0.000001"))
        or pr != pr.quantize(Decimal("0.000001"))
    ):
        raise ErroreUtente(
            "Quantità positiva e prezzo non negativo, massimo sei decimali."
        )
    imp = int((q * pr * 100).quantize(Decimal(1), rounding=ROUND_HALF_UP))
    if imp > 1000000000000:
        raise ErroreUtente("Importo eccessivo.")
    intera = bool(rp and f.ambito == 'DM' and f.tipo == 'TD01')
    if importo_origine is not None and imp > importo_origine and not intera:
        raise ErroreUtente(
            "Importo superiore al residuo della prestazione o della riga da accreditare."
        )
    if f.tipo == "TD04" and rp and not origine:
        raise ErroreUtente(
            "Per accreditare una prestazione scegli la riga della fattura originaria."
        )
    aliquota = dec(d.get("aliquota", "22"), "Aliquota IVA")
    if aliquota < 0 or aliquota > 100 or aliquota != aliquota.quantize(Decimal("0.01")):
        raise ErroreUtente("Aliquota IVA non valida.")
    natura = str(d.get("natura", ""))
    if (
        (aliquota == 0) != bool(natura)
        or natura
        and not re.fullmatch(r"N[1-7](\.[1-9])?", natura)
    ):
        raise ErroreUtente("Indica una natura IVA valida solo per aliquota zero.")
    esig = d.get("esigibilita", "I")
    if esig not in ("I", "D", "S") or esig == "S" and aliquota == 0:
        raise ErroreUtente("Esigibilità IVA non valida.")
    if origine and (int(aliquota * 100), natura, esig) != (
        origine.aliquota,
        origine.natura,
        origine.esigibilita,
    ):
        raise ErroreUtente(
            "La riga di nota di credito conserva il trattamento IVA della riga originaria."
        )
    descrizione = str(
        d.get("descrizione")
        or (origine.descrizione if origine else prestazioni.descrizione(s, rp) if rp else "")
    ).strip()
    if not descrizione or len(descrizione) > 1000:
        raise ErroreUtente("Descrizione obbligatoria (massimo 1000 caratteri).")
    r = RigaFattura(
        fattura_id=f.id,
        riga_preventivo_id=rp.id if rp else None,
        origine_credito_id=origine.id if origine else None,
        descrizione=descrizione,
        quantita=f"{q:.6f}",
        prezzo=f"{pr:.6f}",
        importo=imp,
        aliquota=int(aliquota * 100),
        natura=natura,
        esigibilita=esig,
        riferimento_normativo=str(d.get("riferimento_normativo", ""))[:200],
        riferimenti=dumps(ref),
        prestazione_intera=intera,
    )
    s.add(r)
    evento(s, u, f, "riga_aggiunta", {"descrizione": descrizione, "importo": imp})
    return f


def elimina_riga(s, u, f, id, d):
    controlla_versione(f, d.get("versione"))
    r = get(s, RigaFattura, id)
    if r.fattura_id != f.id or f.stato != "bozza":
        raise ErroreUtente("Riga non modificabile.")
    s.delete(r)
    evento(s, u, f, "riga_eliminata", {"riga_id": id})


def pagamenti_previsti(s, u, f, d):
    controlla_versione(f, d.get("versione"))
    if f.stato != "bozza":
        raise ErroreUtente("Documento emesso: scadenze immutabili.")
    entries = d.get("scadenze", [])
    if not isinstance(entries, list) or len(entries) > 50:
        raise ErroreUtente("Scadenze non valide.")
    nuove = []
    for e in entries:
        if not isinstance(e, dict) or "data" not in e:
            raise ErroreUtente("Scadenza non valida.")
        imp = cent(e.get("importo", "0"))
        mod = e.get("modalita", "MP05")
        if imp <= 0 or not re.fullmatch(r"MP(0[1-9]|1[0-9]|2[0-3])", mod):
            raise ErroreUtente("Importo o modalità pagamento non validi.")
        nuove.append(
            ScadenzaFattura(
                fattura_id=f.id, data=giorno(e["data"]), importo=imp, modalita=mod
            )
        )
    for q in scadenze(s, f):
        s.delete(q)
    s.add_all(nuove)
    evento(s, u, f, "scadenze_modifica")


def fotografia(s, f):
    c = get(s, Cliente, f.cliente_id)
    so = get(s, Societa, f.societa_id)
    rs = righe(s, f)
    o = json.loads(f.opzioni)
    foto = {
        "societa": json.loads(so.dati),
        "societa_codice": so.codice,
        "cliente": {k: getattr(c, k) for k in CAMPI_CLIENTE},
        "codice": f.codice,
        "tipo": f.tipo,
        "data": f.data.isoformat(),
        "opzioni": o,
        "righe": [riga_json(r) for r in rs],
        **somme(rs, o),
        "scadenze": [
            {"data": q.data.isoformat(), "importo": q.importo, "modalita": q.modalita}
            for q in scadenze(s, f)
        ],
    }
    if f.originale_id:
        orig = get(s, Fattura, f.originale_id)
        foto["originale"] = {
            "id": orig.id,
            "codice": orig.codice,
            "data": orig.data.isoformat(),
        }
    return foto


def emetti(s, u, f, d):

    controlla_versione(f, d.get("versione"))
    if f.stato != "bozza" or f.numero:
        raise ErroreUtente(
            "Documento già emesso: scarica il suo XML o riemetti il tentativo scartato."
        )
    manca = mancanti(s, f)
    if manca:
        raise ErroreUtente("Prima di emettere manca: " + "; ".join(manca) + ".")
    rs = righe(s, f)
    controlla_prestazioni(s, f)
    if not rs:
        raise ErroreUtente("Aggiungi almeno una riga.")
    # Ricontrollo al commit: due bozze non possono fatturare la stessa prestazione.
    for r in rs:
        if (
            r.riga_preventivo_id
            and f.tipo != "TD04"
            and not r.prestazione_intera
            and r.importo > disponibile_riga(s, r.riga_preventivo_id, esclusa=f.id)
        ):
            raise Conflitto("Prestazione già fatturata su un altro documento.")
        if r.riga_preventivo_id and f.tipo == "TD01":
            rp = get(s, RigaPreventivo, r.riga_preventivo_id)
            v = s.scalar(select(Verifica).where(Verifica.riga_id == rp.id, Verifica.stato != "annullata"))
            if rp.impianto_id and (
                not v or v.stato != "riesaminata" or v.riesame_esito != "conforme"
            ):
                raise ErroreUtente(
                    "Il verbale della prestazione richiede un riesame conforme."
                )
    o = json.loads(f.opzioni)
    sums = somme(rs, o)
    if sums["dovuto"] < 0 or sums["totale"] <= 0:
        raise ErroreUtente("Totale documento non valido.")
    if f.tipo == "TD04" and f.originale_id:
        orig = get(s, Fattura, f.originale_id)
        altri = sum(
            x.dovuto
            for x in s.scalars(
                select(Fattura).where(
                    Fattura.originale_id == orig.id,
                    Fattura.id != f.id,
                    Fattura.stato != "scartata",
                    Fattura.stato != "bozza",
                )
            )
        )
        if (
            sums["dovuto"] + altri > orig.dovuto
            or sums["dovuto"] > saldo(s, orig)["residuo"]
        ):
            raise ErroreUtente(
                "Nota superiore al credito non incassato. Il rimborso di somme incassate richiede una procedura successiva."
            )
    for k in ("imponibile", "iva", "totale", "dovuto"):
        setattr(f, k, sums[k])
    qs = scadenze(s, f)
    if f.tipo != "TD04" and not qs:
        # 0.14: come Garda, dalla modalità di pagamento (preventivo → cliente → predefinita) con le sue rate
        for q in proponi_scadenze(s, f, f.dovuto):
            s.add(ScadenzaFattura(fattura_id=f.id, data=q["data"], importo=q["importo"], modalita=q["modalita"]))
        s.flush()
    elif qs and sum(q.importo for q in qs) != f.dovuto:
        raise ErroreUtente(
            "La somma delle scadenze deve coincidere con il netto da pagare."
        )
    f.numero = (
        s.scalar(
            select(func.max(Fattura.numero)).where(
                Fattura.societa_id == f.societa_id,
                Fattura.ambito == f.ambito,
                ((Fattura.tipo == 'TD04') if f.tipo == 'TD04' else (Fattura.tipo != 'TD04'))
                if f.ambito == 'DPR' else True,
                Fattura.anno == f.anno,
            )
        )
        or 0
    ) + 1
    # R140 (0.16): numero nel formato di Garda «390/2026/DPR» (prima «DPR/390/2026»); la nota di credito DPR, che ha
    # la sua numerazione, «5/2026/DPR-NC». Le fatture già emesse conservano il numero di allora.
    f.codice = (f"{f.numero}/{f.anno}/DPR{'-NC' if f.tipo == 'TD04' else ''}"
                if f.ambito == 'DPR' else f'{f.numero}/{f.anno}' + ('' if f.ambito == 'IEC' else '/' + f.ambito))
    f.revisione_xml = 1
    foto = fotografia(s, f)
    esporta(s, u, f, foto, 1)
    f.fotografia = dumps(foto)
    f.stato = "emessa"
    evento(s, u, f, "fattura_emessa", {"codice": f.codice, "totale": f.totale})
    salda_subito(s, u, f)
    return f


def proponi_scadenze(s, f, dovuto):
    from . import pagamenti
    x, _provenienza = pagamenti.modalita_della_fattura(s, f)
    regole = pagamenti.regole(x) if x is not None else pagamenti.VUOTE
    return pagamenti.calcola(f.data, dovuto, regole)


def calcola_scadenze(s, u, f, d):
    """«Calcola dalla modalità»: sostituisce le scadenze della bozza con quelle della modalità di pagamento."""
    controlla_versione(f, d.get("versione"))
    if f.stato != "bozza" or f.tipo == "TD04":
        raise ErroreUtente("Le scadenze si calcolano sulle bozze di fattura.")
    if "modalita_pagamento_id" in d:
        o = json.loads(f.opzioni)
        o["modalita_pagamento_id"] = str(d["modalita_pagamento_id"] or "")
        f.opzioni = dumps(o)
    dovuto = somme(righe(s, f), json.loads(f.opzioni))["dovuto"]
    for q in scadenze(s, f):
        s.delete(q)
    s.flush()
    for q in proponi_scadenze(s, f, dovuto):
        s.add(ScadenzaFattura(fattura_id=f.id, data=q["data"], importo=q["importo"], modalita=q["modalita"]))
    evento(s, u, f, "scadenze_calcolate")
    return f


def salda_subito(s, u, f):
    """Garda «salda subito»: con questa modalità il documento risulta incassato all'emissione (es. contanti, carta)."""
    from . import pagamenti
    x, _ = pagamenti.modalita_della_fattura(s, f)
    if f.tipo == "TD04" or x is None or not pagamenti.regole(x).get("salda_subito") or f.dovuto <= 0:
        return
    inc = Incasso(societa_id=f.societa_id, cliente_id=f.cliente_id, data=f.data, importo=f.dovuto,
                  causale=f"Saldato all'emissione ({x.descrizione})", metodo=x.descrizione[:60], creato_da=u.nome)
    s.add(inc)
    s.flush()
    s.add(AllocazioneIncasso(incasso_id=inc.id, fattura_id=f.id, importo=f.dovuto))
    evento(s, u, f, "saldata_all_emissione", {"incasso_id": inc.id})


BASE36 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def progressivo(n: int) -> str:
    """Progressivo di 5 caratteri alfanumerici per il nome del file SdI (fino a 60 milioni di invii)."""
    out = ""
    for _ in range(5):
        n, r = divmod(n, 36)
        out = BASE36[r] + out
    return out


def nome_file(foto, esportazione_id):
    so = foto["societa"]
    trasmittente = so.get("id_trasmittente") or so.get("codice_fiscale") or so.get("partita_iva", "")
    return f"IT{trasmittente}_{progressivo(esportazione_id)}.xml"


def esporta(s, u, f, foto, rev):
    """0.14: ogni tentativo XML ha un nome file SdI unico, con progressivo di 5 caratteri (lo SdI scarta nomi più
    lunghi), uguale al ProgressivoInvio dell'XML."""
    from .xml_fattura import genera, valida
    e = EsportazioneFattura(fattura_id=f.id, revisione=rev, xml="", sha256="", fotografia="{}", creato_da=u.nome)
    s.add(e)
    s.flush()
    e.nome_file = nome_file(foto, e.id)
    xml = genera(foto, f.id, rev, progressivo(e.id))
    valida(xml)
    e.xml, e.sha256, e.fotografia = xml.decode(), hashlib.sha256(xml).hexdigest(), dumps(foto)
    return e


def esito(s, u, id, d):
    e = get(s, EsportazioneFattura, id)
    f = get(s, Fattura, e.fattura_id)
    codice = str(d.get("identificativo_origine", "")).strip()
    stato = d.get("esito")
    if not codice or len(codice) > 120 or stato not in ESITI:
        raise ErroreUtente("Esito o identificativo della ricevuta non valido.")
    old = s.scalar(
        select(EsitoFattura).where(EsitoFattura.identificativo_origine == codice)
    )
    if old:
        if old.esportazione_id == id and old.esito == stato:
            return f
        raise Conflitto("Identificativo della ricevuta già utilizzato.")
    if e.revisione != f.revisione_xml:
        raise Conflitto(
            "La ricevuta riguarda un tentativo precedente: non cambia lo stato del tentativo corrente."
        )
    # Una ricevuta di scarto non deve annullare un XML già consegnato/accettato.
    ammessi = {
        "emessa": {"scartata", "consegnata", "mancata_consegna"},
        "consegnata": {"accettata_pa", "rifiutata_pa"},
        "mancata_consegna": {"consegnata"},
        "scartata": set(),
        "accettata_pa": set(),
        "rifiutata_pa": set(),
    }
    if stato not in ammessi.get(f.stato, set()):
        raise ErroreUtente("Esito non coerente con lo stato del documento.")
    s.add(
        EsitoFattura(
            esportazione_id=e.id,
            esito=stato,
            messaggio=str(d.get("messaggio", ""))[:4000],
            identificativo_origine=codice,
            registrato_da=u.nome,
        )
    )
    f.stato = stato
    evento(s, u, f, "esito_registrato", {"esito": stato, "esportazione_id": e.id})
    return f


def prepara_correzione(s, u, f, d):
    controlla_versione(f, d.get("versione"))
    if f.stato != "scartata":
        raise ErroreUtente("Si corregge così solo un documento scartato.")
    if saldo(s, f)["pagato"]:
        raise ErroreUtente("Documento con incassi: risolvi prima le associazioni.")
    # I tentativi precedenti restano integri. Il numero resta riservato.
    f.stato = "bozza"
    evento(s, u, f, "correzione_scarto_aperta")
    return f


def riemetti(s, u, f, d):
    # Per un documento già numerato la nuova esportazione conserva numero/data e tutte le versioni.

    controlla_versione(f, d.get("versione"))
    if f.stato != "bozza" or not f.numero:
        raise ErroreUtente("Apri la correzione di un XML scartato.")
    controlla_prestazioni(s, f)
    sums = somme(righe(s, f), json.loads(f.opzioni))
    if (
        sums["dovuto"] < 0
        or sums["totale"] <= 0
        or (scadenze(s, f) and sum(q.importo for q in scadenze(s, f)) != sums["dovuto"])
    ):
        raise ErroreUtente("Controlla righe e scadenze del nuovo tentativo.")
    for k in ("imponibile", "iva", "totale", "dovuto"):
        setattr(f, k, sums[k])
    foto = fotografia(s, f)
    rev = f.revisione_xml + 1
    esporta(s, u, f, foto, rev)
    f.fotografia = dumps(foto)
    f.revisione_xml = rev
    f.stato = "emessa"
    evento(s, u, f, "xml_riemesso", {"revisione": rev})
    return f


def incasso_json(s, x):
    allocations = list(
        s.scalars(
            select(AllocazioneIncasso).where(AllocazioneIncasso.incasso_id == x.id)
        )
    )
    return {
        "id": x.id,
        "societa_id": x.societa_id,
        "cliente_id": x.cliente_id,
        "cliente": get(s, Cliente, x.cliente_id).ragione_sociale,
        "data": x.data.isoformat(),
        "importo": x.importo,
        "causale": x.causale,
        "metodo": x.metodo,
        "stornato": x.stornato,
        "motivo_storno": x.motivo_storno,
        "versione": x.versione,
        "non_associato": x.importo - sum(a.importo for a in allocations),
        "allocazioni": [
            {
                "fattura_id": a.fattura_id,
                "codice": get(s, Fattura, a.fattura_id).codice,
                "importo": a.importo,
            }
            for a in allocations
        ],
    }


def registra_incasso(s, u, d):
    imp = cent(d.get("importo", "0"))
    if imp <= 0:
        raise ErroreUtente("Importo incasso positivo obbligatorio.")
    so = get(s, Societa, ident(d["societa_id"]))
    c = get(s, Cliente, ident(d["cliente_id"]))
    x = Incasso(
        societa_id=so.id,
        cliente_id=c.id,
        data=giorno(d["data"]),
        importo=imp,
        causale=str(d.get("causale", ""))[:500],
        metodo=str(d.get("metodo", "bonifico"))[:60],
        creato_da=u.nome,
    )
    s.add(x)
    s.flush()
    ripartisci(
        s, u, x, {"versione": x.versione, "allocazioni": d.get("allocazioni", [])}
    )
    return x


def ripartisci(s, u, x, d):
    controlla_versione(x, d.get("versione"))
    if x.stornato:
        raise ErroreUtente("Movimento stornato.")
    for a in list(
        s.scalars(
            select(AllocazioneIncasso).where(AllocazioneIncasso.incasso_id == x.id)
        )
    ):
        s.delete(a)
    s.flush()
    seen = set()
    somma = 0
    allocazioni = d.get("allocazioni", [])
    if not isinstance(allocazioni, list) or len(allocazioni) > 200:
        raise ErroreUtente("Ripartizioni non valide.")
    for alloc in allocazioni:
        if not isinstance(alloc, dict) or not {"fattura_id", "importo"}.issubset(alloc):
            raise ErroreUtente("Ripartizione non valida.")
        f = get(s, Fattura, ident(alloc["fattura_id"]))
        imp = cent(alloc["importo"])
        if (
            f.id in seen
            or imp <= 0
            or f.tipo == "TD04"
            or f.stato in ("bozza", "scartata")
        ):
            raise ErroreUtente("Associazione di incasso non valida.")
        if (f.societa_id, f.cliente_id) != (x.societa_id, x.cliente_id):
            raise ErroreUtente(
                "Associa fatture della stessa società e dello stesso intestatario."
            )
        if imp > saldo(s, f)["residuo"]:
            raise ErroreUtente("Importo associato superiore al residuo della fattura.")
        seen.add(f.id)
        somma += imp
        s.add(AllocazioneIncasso(incasso_id=x.id, fattura_id=f.id, importo=imp))
        s.flush()
    if somma > x.importo:
        raise ErroreUtente("Ripartizione superiore al movimento incassato.")
    evento(s, u, x, "incasso_ripartito", {"somma": somma})
    return x


def storna(s, u, x, d):
    controlla_versione(x, d.get("versione"))
    motivo = str(d.get("motivo", "")).strip()[:500]
    if not motivo or x.stornato:
        raise ErroreUtente("Scrivi un motivo; il movimento deve essere attivo.")
    x.stornato = True
    x.motivo_storno = motivo
    evento(s, u, x, "incasso_stornato", {"motivo": motivo})
    return x


def controlla_prestazioni(s, f):
    totali = {}
    for r in righe(s, f):
        if r.riga_preventivo_id and f.tipo != "TD04":
            totali[r.riga_preventivo_id] = (
                totali.get(r.riga_preventivo_id, 0) + r.importo
            )
    for rid, imp in totali.items():
        all_rows = [r for r in righe(s, f) if r.riga_preventivo_id == rid]
        intera = any(r.prestazione_intera for r in all_rows)
        disponibile = disponibile_riga(s, rid, esclusa=f.id)
        if (intera and (len(all_rows) != 1 or disponibile <= 0)) or (not intera and imp > disponibile):
            raise Conflitto("Prestazione già fatturata su un altro documento.")
        rp = get(s, RigaPreventivo, rid)
        prestazioni.controlla(s, rp, f)


def righe_da_lavori(s, d):
    """R139 (0.16, Federico 12/10/2026, 17:33: «in garda da righe preventivo, mi piacerebbe rimanesse ma anche da verbali»):
    dalle verifiche DPR e dagli incarichi DM selezionati alle righe di preventivo da fatturare, con le stesse regole
    di «Fattura le selezionate…». Trasferta e voci a corpo dei loro preventivi, non ancora fatturate, si aggiungono da sole."""
    from ..dm.modelli import IncaricoDM
    from ..verifiche.modelli import Verifica
    from .da_fatturare import righe_da_fatturare

    verifiche = [ident(x) for x in (d.get("verifiche") or [])]
    incarichi = [ident(x) for x in (d.get("incarichi") or [])]
    if not verifiche and not incarichi:
        raise ErroreUtente("Seleziona le verifiche da fatturare.")
    lavori = ([(v.riga_id, v.codice_verbale or f"verifica n. {v.id}") for v in s.scalars(select(Verifica).where(Verifica.id.in_(verifiche)))]
              + [(x.riga_id, x.codice_verbale or f"incarico n. {x.id}") for x in s.scalars(select(IncaricoDM).where(IncaricoDM.id.in_(incarichi)))])
    if len(lavori) != len(set(verifiche)) + len(set(incarichi)):
        raise ErroreUtente("Verifiche non trovate: ricarica l'elenco.")
    ids = [r for r, _ in lavori if r]
    pronte = righe_da_fatturare(s, ids)
    fuori = [n for r, n in lavori if r not in pronte]
    if fuori:
        raise ErroreUtente("Queste verifiche non sono da fatturare (non riesaminate, o già fatturate): " + ", ".join(sorted(fuori)[:10]))
    preventivi = set(s.scalars(select(RigaPreventivo.preventivo_id).where(RigaPreventivo.id.in_(ids))))
    voci = [r.id for r in s.scalars(select(RigaPreventivo).where(RigaPreventivo.preventivo_id.in_(preventivi), RigaPreventivo.impianto_id.is_(None),
                                                                 RigaPreventivo.asset_id.is_(None), RigaPreventivo.stato == "accettata"))]
    voci = sorted(righe_da_fatturare(s, voci) - set(ids))
    tutte = ids + voci
    righe = list(s.scalars(select(RigaPreventivo).where(RigaPreventivo.id.in_(tutte))))
    clienti = sorted({s.get(Preventivo, r.preventivo_id).cliente_id for r in righe})
    ambiti = sorted({s.get(Preventivo, r.preventivo_id).ambito for r in righe})
    return {"righe": tutte, "voci": len(voci), "clienti": clienti, "ambiti": ambiti, "totale": sum(r.tariffa_applicata for r in righe)}


def fattura_della_riga(s, riga_id):
    """R139: la fattura (non nota di credito, non scartata) che contiene la riga del preventivo, per la scheda della verifica."""
    if not riga_id:
        return None
    f = s.scalar(select(Fattura).join(RigaFattura, RigaFattura.fattura_id == Fattura.id)
                 .where(RigaFattura.riga_preventivo_id == riga_id, Fattura.tipo != "TD04", Fattura.stato != "scartata")
                 .order_by(Fattura.id.desc()).limit(1))
    return None if f is None else {"id": f.id, "codice": f.codice or "", "stato": f.stato, "ambito": f.ambito}


def _aggiungi_documenti(s, u, f, preventivi):
    o = json.loads(f.opzioni or "{}")
    docs = list(o.get("documenti") or [])
    chiavi = {chiave_documento(x) for x in docs}
    nuovi = 0
    for p in {p.id: p for p in preventivi}.values():
        for x in json.loads(p.documenti_collegati or "[]"):
            k = chiave_documento(x)
            if k not in chiavi:
                chiavi.add(k)
                docs.append(x)
                nuovi += 1
    if nuovi:
        modifica(s, u, f, {"versione": f.versione, "opzioni": {**o, "documenti": docs}})


def da_righe(s, u, d):
    """N7 / R125 (0.12.8): «Fattura le selezionate…» dalle righe dei preventivi, come in Garda
    (`gi_preventivi_righe_fattura_cliente_genera`): una bozza di fattura con una riga per ogni riga di preventivo da
    fatturare. Stesso committente per tutte; intestatario proposto dal committente (modificabile, R72). Con `fattura_id`
    le righe si aggiungono a una bozza esistente dello stesso intestatario e ambito, come la «fattura da integrare» di Garda.
    IVA: quella del cliente intestatario, altrimenti 22% ordinaria. Nessun dato dell'XML cambia rispetto alla fattura
    fatta a mano: la descrizione è quella della prestazione (per il DM il testo di Garda)."""
    from .da_fatturare import righe_da_fatturare

    ids = [ident(x) for x in (d.get("righe") or [])]
    if not ids:
        raise ErroreUtente("Seleziona le righe da fatturare.")
    righe = [(r, s.get(Preventivo, r.preventivo_id)) for r in s.scalars(select(RigaPreventivo).where(RigaPreventivo.id.in_(ids)))]
    if len(righe) != len(set(ids)):
        raise ErroreUtente("Righe non trovate: ricarica l'elenco.")
    pronte = righe_da_fatturare(s, ids)
    fuori = [f"{p.codice}/{r.ordine}" for r, p in righe if r.id not in pronte]
    if fuori:
        raise ErroreUtente("Queste righe non sono da fatturare (lavoro non concluso o non riesaminato, oppure già fatturate): "
                           + ", ".join(sorted(fuori)[:10]))
    ambiti = {p.ambito for _, p in righe}
    committenti = {p.cliente_id for _, p in righe}
    if len(ambiti) > 1:
        raise ErroreUtente("Le righe selezionate sono di attività diverse (DPR e DM): una fattura per attività.")
    if len(committenti) > 1:
        raise ErroreUtente("Le righe selezionate sono di clienti diversi: una fattura riguarda un solo cliente.")
    ambito, committente = ambiti.pop(), committenti.pop()
    if d.get("fattura_id"):
        f = get(s, Fattura, ident(d["fattura_id"]))
        if f.stato != "bozza" or f.tipo != "TD01" or f.ambito != ambito:
            raise ErroreUtente("Si aggiunge solo a una fattura in bozza della stessa attività.")
        for rf in s.scalars(select(RigaFattura).where(RigaFattura.fattura_id == f.id)):
            cid = json.loads(rf.riferimenti or "{}").get("committente_id")
            if cid and cid != committente:
                raise ErroreUtente("La bozza scelta contiene prestazioni di un altro cliente.")
    else:
        so = s.scalar(select(Societa).where(Societa.codice == "AD"))
        if so is None:
            raise ErroreUtente("Manca la società emittente AD nella configurazione delle fatture.")
        f = crea(s, u, {"societa_id": so.id, "cliente_id": d.get("cliente_id") or committente, "ambito": ambito, "tipo": "TD01",
                        "data": d.get("data") or oggi_italia().isoformat()})
        preventivi = {p.id: p for _, p in righe}
        if len(preventivi) == 1:
            p = next(iter(preventivi.values()))
            if p.rif_ordine and not json.loads(p.documenti_collegati or "[]"):
                modifica(s, u, f, {"versione": f.versione, "opzioni": {**json.loads(f.opzioni or "{}"), "ordine": p.rif_ordine,
                                                                       **({"data_ordine": p.data_ordine.isoformat()} if p.data_ordine else {})}})
    # R138 (0.16): i documenti per la fattura elettronica dei preventivi entrano da soli nella bozza, senza doppioni
    _aggiungi_documenti(s, u, f, [p for _, p in righe])
    intestatario = get(s, Cliente, f.cliente_id)
    iva = {"aliquota": "22", "natura": "", "esigibilita": "I"}
    if intestatario.aliquota_iva is not None:
        x = intestatario.aliquota_iva
        iva = {"aliquota": str((x.percentuale or 0) / 100), "natura": x.natura or "", "esigibilita": "S" if x.scissione_pagamenti else "I"}
    for r, _p in sorted(righe, key=lambda rp: (rp[1].id, rp[0].ordine)):
        aggiungi_riga(s, u, f, {"versione": f.versione, "riga_preventivo_id": r.id, **iva})
    registro.scrivi(s, utente=u, azione="economia.fattura_da_righe", oggetto_tipo="fatture", oggetto_id=f.id,
                    descrizione=f"Bozza di fattura n. interno {f.id}: aggiunte {len(righe)} righe dai preventivi "
                                + ", ".join(sorted({p.codice for _, p in righe})),
                    dettagli={"righe_preventivo": ids})
    return f
