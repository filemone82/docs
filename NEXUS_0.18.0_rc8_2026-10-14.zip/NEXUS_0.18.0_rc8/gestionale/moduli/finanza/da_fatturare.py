"""«Da fatturare» (N6, N7/R125, 0.12.8): le stesse regole per l'elenco Verifiche, gli incarichi DM, le righe dei
preventivi e la fattura creata dalle righe.

Regola di Garda (meta `preventivi_righe`, azione «Genera fattura cliente», condizione
`t.verifica IS NOT NULL AND t.stato_verifica='effettuata' AND t.fattura IS NULL AND t.fattura_cliente IS NULL AND
t.riesame_ver_fatto = 'T' AND t.riesame_ver_esito = 'C'`), resa sui dati del gestionale:
- riga del preventivo accettata, con l'ultimo riesame del contratto conforme;
- lavoro concluso: DPR verifica «riesaminata» con riesame del verbale conforme; DM incarico «effettuato» con riesame
  conforme. Le voci senza impianto o attrezzatura (trasferta, a corpo) diventano fatturabili insieme alla prima verifica
  fatturabile del loro preventivo;
- non già fatturata: il netto fatturato (fatture valide meno note di credito emesse) non copre la tariffa applicata.
  Una fattura stornata per intero da una nota di credito riporta la riga tra le «da fatturare». Nel DM la riga si
  fattura per intero (Garda, IE-38): basta un netto positivo per considerarla fatturata.
"""

from __future__ import annotations

from sqlalchemy import and_, case, exists, func, or_, select
from sqlalchemy.orm import aliased

from ..dm.modelli import IncaricoDM
from ..preventivi.modelli import Preventivo, Riesame, RigaPreventivo
from ..verifiche.modelli import Verifica
from .modelli import Fattura, RigaFattura


def _valide():  # noqa: ANN202
    return and_(Fattura.stato != "scartata", ~and_(Fattura.tipo == "TD04", Fattura.stato == "bozza"))


def netto_fatturato(riga_id):  # noqa: ANN001, ANN201
    return (select(func.coalesce(func.sum(case((Fattura.tipo == "TD04", -RigaFattura.importo), else_=RigaFattura.importo)), 0))
            .select_from(RigaFattura).join(Fattura, RigaFattura.fattura_id == Fattura.id)
            .where(RigaFattura.riga_preventivo_id == riga_id, _valide()).scalar_subquery())


def _intera(riga_id):  # noqa: ANN001, ANN202
    return (select(RigaFattura.id).join(Fattura, RigaFattura.fattura_id == Fattura.id)
            .where(RigaFattura.riga_preventivo_id == riga_id, RigaFattura.prestazione_intera.is_(True),
                   Fattura.tipo != "TD04", Fattura.stato != "scartata").exists())


def gia_fatturata(r):  # noqa: ANN001, ANN201
    """`r`: RigaPreventivo o un suo alias."""
    n = netto_fatturato(r.id)
    return or_(n >= r.tariffa_applicata, and_(_intera(r.id), n > 0))


def _riesame_conforme(preventivo_id):  # noqa: ANN001, ANN202
    ultimo = (select(Riesame.esito).where(Riesame.preventivo_id == preventivo_id).order_by(Riesame.id.desc()).limit(1)
              .scalar_subquery())
    return ultimo == "conforme"


def _verifica_pronta(riga_id):  # noqa: ANN001, ANN202
    return exists().where(Verifica.riga_id == riga_id, Verifica.stato == "riesaminata", Verifica.riesame_esito == "conforme")


def _incarico_pronto(riga_id):  # noqa: ANN001, ANN202
    return exists().where(IncaricoDM.riga_id == riga_id, IncaricoDM.stato == "effettuata", IncaricoDM.riesame_fatto.is_(True),
                          IncaricoDM.riesame_esito == "C")


def lavoro_pronto(r):  # noqa: ANN001, ANN201
    altra = aliased(RigaPreventivo)
    voce_libera = and_(r.impianto_id.is_(None), r.asset_id.is_(None),
                       exists().where(altra.preventivo_id == r.preventivo_id, altra.stato == "accettata", _verifica_pronta(altra.id)))
    return or_(_verifica_pronta(r.id), _incarico_pronto(r.id), voce_libera)


def da_fatturare(r):  # noqa: ANN001, ANN201
    """Espressione SQL booleana sulla riga `r` (RigaPreventivo o alias)."""
    return and_(r.stato == "accettata", _riesame_conforme(r.preventivo_id), lavoro_pronto(r), ~gia_fatturata(r))


def riga_da_fatturare_di(riga_id_col):  # noqa: ANN001, ANN201
    """Per gli elenchi delle verifiche e degli incarichi: la loro riga di preventivo è da fatturare."""
    rp = aliased(RigaPreventivo)
    return exists().where(rp.id == riga_id_col, da_fatturare(rp))


def righe_da_fatturare(s, ids: list[int]) -> set[int]:  # noqa: ANN001
    """Tra le righe indicate, quelle da fatturare (controllo lato server di «Fattura le selezionate…»)."""
    if not ids:
        return set()
    return set(s.scalars(select(RigaPreventivo.id).where(RigaPreventivo.id.in_(ids), da_fatturare(RigaPreventivo))))


__all__ = ["da_fatturare", "gia_fatturata", "lavoro_pronto", "netto_fatturato", "riga_da_fatturare_di", "righe_da_fatturare",
           "Preventivo"]
