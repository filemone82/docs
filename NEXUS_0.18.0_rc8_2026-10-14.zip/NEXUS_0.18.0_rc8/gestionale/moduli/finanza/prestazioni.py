"""Regole commerciali specifiche DPR/DM; fonte Garda lavori_batch_cli.php."""
import json

from sqlalchemy import select

from ...core.errori import ErroreUtente
from ..anagrafica.modelli import Cliente
from ..beni.modelli import Asset
from ..dm.modelli import IncaricoDM
from ..preventivi.modelli import Preventivo, Riesame
from ..verifiche.modelli import Verifica
from .riferimenti import documenti_del_preventivo


def tecnico(s, r):
    p = s.get(Preventivo, r.preventivo_id)
    model = IncaricoDM if p.ambito == 'DM' else Verifica
    return s.scalar(select(model).where(model.riga_id == r.id).order_by((model.stato == 'annullata').asc(), model.id.desc()).limit(1))


def pronto(s, r):
    p = s.get(Preventivo, r.preventivo_id)
    v = tecnico(s, r)
    if p.ambito == 'DM':
        return bool(v and v.stato == 'effettuata' and v.riesame_fatto and v.riesame_esito == 'C')
    return not r.impianto_id or bool(v and v.stato == 'riesaminata' and v.riesame_esito == 'conforme')


def controlla(s, r, f):
    p = s.get(Preventivo, r.preventivo_id)
    if p.ambito != f.ambito:
        raise ErroreUtente('La prestazione e la fattura devono appartenere allo stesso ambito.')
    rc = s.scalar(select(Riesame).where(Riesame.preventivo_id == p.id).order_by(Riesame.id.desc()).limit(1))
    if r.stato != 'accettata' or not rc or rc.esito != 'conforme':
        raise ErroreUtente('Accettazione e riesame conforme del preventivo necessari.')
    if f.tipo == 'TD01' and not pronto(s, r):
        raise ErroreUtente('La fatturazione ordinaria richiede lavoro concluso e riesame conforme.')
    # Intestatario terzo ammesso; le prestazioni aggregate hanno un unico committente.
    from .modelli import RigaFattura
    for rf in s.scalars(select(RigaFattura).where(RigaFattura.fattura_id == f.id)):
        cid = json.loads(rf.riferimenti).get('committente_id')
        if cid and cid != p.cliente_id:
            raise ErroreUtente('Le prestazioni aggregate devono avere lo stesso committente.')
    return p, tecnico(s, r)


def descrizione(s, r):
    p = s.get(Preventivo, r.preventivo_id)
    if p.ambito != 'DM':
        # 0.12.8: anche le voci libere (trasferta, «a corpo»: il testo sta in sede_nome) hanno una descrizione
        testo = ' · '.join(x for x in (r.tipologia, r.descrizione) if x) or r.sede_nome
        return (testo or f'Prestazione del preventivo {p.codice}')[:1000]
    a = s.get(Asset, r.asset_id)
    raw = json.loads(a.attributi_json)
    parts = ['Verifiche attrezzature di lavoro gruppo ' + a.gruppo]
    for prefix, val in [('matr. ', a.matr_informale), ('reparto ', raw.get('reparto')),
                        ('rif. interno ', raw.get('rif_interno')), ('n.f. ', a.num_fabbrica)]:
        if val:
            parts.append(prefix + val)
    parts.append('prima verifica periodica' if r.tipo_verifica_dm == 'V1' else 'verifica periodica successiva')
    comb = {'funz': 'verifica funzionamento', 'integrita': 'verifica integrità', 'interna': 'visita interna',
            'funz_integrita': 'ver. funzionamento + ver. integrità',
            'funz_integrita_interna': 'ver. funzionamento + ver. integrità + visita interna',
            'funz_interna': 'ver. funzionamento + visita interna', 'integrita_interna': 'ver. integrità + visita interna'}
    if a.gruppo == 'GVR':
        parts.append(comb[r.tipo_verifica_gvr])
    parts.append('preventivo ' + p.codice)
    if p.rif_ordine:
        parts.append('rif. ordine cliente ' + p.rif_ordine)
    return ', '.join(parts).encode('latin-1', errors='ignore').decode('latin-1')[:1000]


def riferimenti(s, r, p, v):
    return {'ambito': p.ambito, 'preventivo_id': p.id, 'preventivo': p.codice,
            'committente_id': p.cliente_id, 'committente': s.get(Cliente, p.cliente_id).ragione_sociale,
            'verifica_id': v.id if v and p.ambito == 'DPR' else None,
            'incarico_dm_id': v.id if v and p.ambito == 'DM' else None,
            'verbale': v.codice_verbale if v else '',
            'documenti_collegati': documenti_del_preventivo(p)}
