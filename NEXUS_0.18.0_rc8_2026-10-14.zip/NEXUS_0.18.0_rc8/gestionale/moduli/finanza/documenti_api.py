import json
from typing import Annotated

from fastapi import APIRouter, Body, Depends, File, Form, UploadFile
from fastapi.responses import Response

from ...core.db import Archivio
from ...core.errori import ErroreUtente, NonTrovato
from ...web.dipendenze import archivio, richiede
from ..documenti import servizio as archivio_documenti
from ..utenti.accesso import UtenteCorrente
from . import documenti, servizio as S
from .modelli import Fattura, DocumentoFattura

router = APIRouter(prefix='/api/fatture')
U = Annotated[UtenteCorrente, Depends(richiede('fatture.genera'))]
A = Annotated[Archivio, Depends(archivio)]


@router.post('/{id}/pdf-archivia')
def genera(id: int, d: Annotated[dict, Body(...)], u: U, arc: A):
    from .stampa import pdf_fattura
    with arc.lettura() as s:
        f = S.get(s, Fattura, id)
        S.controlla_versione(f, d.get('versione'))
        if f.stato in ('bozza', 'scartata'):
            raise ErroreUtente('Emetti la fattura prima di archiviare il PDF.')
        foto = json.loads(f.fotografia)
    raw = pdf_fattura(foto, arc.cfg.libreoffice)
    with arc.scrittura() as s:
        f = S.get(s, Fattura, id)
        documenti.salva(s, arc, u, f, raw, d['versione'], 'generato')
        return S.fattura_json(s, f)


@router.post('/{id}/pdf-carica')
async def carica(id: int, u: U, arc: A, versione: Annotated[int, Form(...)], file: Annotated[UploadFile, File(...)]):
    raw = await file.read(25 * 1024 * 1024 + 1)
    with arc.scrittura() as s:
        f = S.get(s, Fattura, id)
        documenti.salva(s, arc, u, f, raw, versione)
        return S.fattura_json(s, f)


@router.get('/{id}/documenti/{documento_id}')
def scarica(id: int, documento_id: int, arc: A,
            u: Annotated[UtenteCorrente, Depends(richiede('fatture.vedere'))]):
    with arc.lettura() as s:
        x = s.get(DocumentoFattura, documento_id)
        if not x or x.fattura_id != id:
            raise NonTrovato('PDF della fattura non trovato.')
        _, raw = archivio_documenti.leggi(s, arc.cfg.cartella_documenti, x.documento_id)
    return Response(raw, media_type='application/pdf',
        headers={'Content-Disposition': 'attachment; filename="fattura.pdf"'})
