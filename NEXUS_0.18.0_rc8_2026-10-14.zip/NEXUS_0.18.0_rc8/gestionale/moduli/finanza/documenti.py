"""PDF fiscali archiviati e versionati senza rigenerazione durante l'export."""
import hashlib

from sqlalchemy import select

from ...core.db import adesso
from ...core.errori import ErroreUtente
from ..documenti import servizio as archivio
from ..dm.documenti import valida_pdf
from .modelli import DocumentoFattura
from . import servizio as S


def corrente(s, f):
    return s.scalar(select(DocumentoFattura).where(DocumentoFattura.fattura_id == f.id,
        DocumentoFattura.revisione_xml == f.revisione_xml,
        DocumentoFattura.fotografia_sha256 == hashlib.sha256(f.fotografia.encode()).hexdigest())
        .order_by(DocumentoFattura.revisione.desc()).limit(1))


def elenco(s, f):
    return [{'id': x.id, 'revisione': x.revisione, 'revisione_xml': x.revisione_xml, 'nome': x.nome_file,
             'origine': x.origine, 'url': f'/api/fatture/{f.id}/documenti/{x.id}'}
            for x in s.scalars(select(DocumentoFattura).where(DocumentoFattura.fattura_id == f.id)
                              .order_by(DocumentoFattura.revisione.desc()))]


def salva(s, arc, u, f, raw, versione, origine='caricato'):
    S.controlla_versione(f, versione)
    if f.stato in ('bozza', 'scartata'):
        raise ErroreUtente('Archivia il PDF soltanto dopo l’emissione della fattura.')
    valida_pdf(raw)
    nome = f"Fattura_{f.codice.replace('/', '_')}.pdf"
    doc = archivio.salva(s, arc.cfg.cartella_documenti, raw, nome, 'application/pdf', u.id)
    xs = elenco(s, f)
    x = DocumentoFattura(fattura_id=f.id, documento_id=doc.id, revisione=(xs[0]['revisione'] if xs else 0)+1,
        revisione_xml=f.revisione_xml, fotografia_sha256=hashlib.sha256(f.fotografia.encode()).hexdigest(),
        nome_file=nome, origine=origine, creato_il=adesso(), creato_da=u.nome)
    s.add(x)
    S.evento(s, u, f, 'pdf_archiviato', {'documento_id': doc.id, 'impronta': doc.impronta})
    return x
