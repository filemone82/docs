"""Esiti dello SdI caricati da file (0.14): le ricevute che Aruba scarica per ogni fattura.

Si caricano i file XML delle notifiche (anche più insieme, o uno ZIP che li contiene). Ogni notifica si collega al
tentativo XML tramite il nome del file inviato (`NomeFile`) e si registra con l'identificativo SdI e il tipo, così
la stessa ricevuta caricata due volte non cambia nulla.

| Notifica SdI | Codice | Esito registrato |
|---|---|---|
| RicevutaConsegna | RC | consegnata |
| NotificaScarto | NS | scartata (con l'elenco degli errori) |
| NotificaMancataConsegna | MC | mancata consegna (la fattura è comunque emessa: è nel cassetto fiscale del cliente) |
| AttestazioneTrasmissioneFattura | AT | mancata consegna (PA irraggiungibile) |
| NotificaEsito EC01 / EC02 | NE | accettata / rifiutata dalla PA |
| NotificaDecorrenzaTermini | DT | accettata dalla PA per decorrenza dei termini |

Le notifiche dell'esito inviate dal committente (EsitoCommittente) e i metadati (MetadatiInvioFile) non cambiano lo
stato e si segnalano come ignorate.
"""

from __future__ import annotations

import io
import json
import zipfile

from lxml import etree as E
from sqlalchemy import select

from ...core.errori import Conflitto, ErroreUtente
from .modelli import EsportazioneFattura, Fattura

TIPI = {"RicevutaConsegna": ("RC", "consegnata"), "NotificaScarto": ("NS", "scartata"),
        "NotificaMancataConsegna": ("MC", "mancata_consegna"), "AttestazioneTrasmissioneFattura": ("AT", "mancata_consegna"),
        "NotificaDecorrenzaTermini": ("DT", "accettata_pa"), "NotificaEsito": ("NE", None)}
MASSIMO = 5 * 1024 * 1024


def _testo(root, nome):
    x = root.find(f".//{{*}}{nome}")
    if x is None:
        x = root.find(f".//{nome}")
    return (x.text or "").strip() if x is not None and x.text else ""


def _tutti(root, nome):
    return [x for x in root.iter() if isinstance(x.tag, str) and E.QName(x).localname == nome]


def leggi_notifica(raw: bytes) -> dict:
    """{tipo, codice, esito, identificativo, nome_file, messaggio} oppure ErroreUtente se non è una notifica SdI."""
    try:
        root = E.fromstring(raw, E.XMLParser(resolve_entities=False, no_network=True, huge_tree=False))
    except E.XMLSyntaxError:
        raise ErroreUtente("Non è un file XML leggibile.") from None
    nome = E.QName(root).localname
    if nome not in TIPI:
        raise ErroreUtente(f"«{nome}» non è una ricevuta dello SdI che cambia lo stato della fattura.")
    codice, esito = TIPI[nome]
    messaggio = ""
    if nome == "NotificaScarto":
        errori = [f"{_testo(e, 'Codice')} {_testo(e, 'Descrizione')}".strip() for e in _tutti(root, "Errore")]
        messaggio = "; ".join(x for x in errori if x)
    if nome == "NotificaEsito":
        ec = _testo(root, "Esito")
        if ec not in ("EC01", "EC02"):
            raise ErroreUtente("Notifica di esito senza EC01/EC02.")
        esito = "accettata_pa" if ec == "EC01" else "rifiutata_pa"
        messaggio = ec + (" " + _testo(root, "Descrizione") if _testo(root, "Descrizione") else "")
    if nome == "NotificaDecorrenzaTermini":
        messaggio = "Decorrenza dei termini: nessuna risposta della PA entro 15 giorni"
    identificativo, nome_file = _testo(root, "IdentificativoSdI"), _testo(root, "NomeFile")
    if not identificativo or not nome_file:
        raise ErroreUtente("Ricevuta senza identificativo SdI o nome del file.")
    for coda in (".p7m", ".P7M"):
        nome_file = nome_file.removesuffix(coda)
    return {"tipo": nome, "codice": codice, "esito": esito, "identificativo": identificativo, "nome_file": nome_file,
            "messaggio": messaggio or nome, "data": _testo(root, "DataOraRicezione") or _testo(root, "DataOraConsegna")}


def file_da(nome: str, raw: bytes) -> list[tuple[str, bytes]]:
    """Un XML, oppure uno ZIP di XML (come li scarica Aruba)."""
    if len(raw) > MASSIMO:
        raise ErroreUtente(f"{nome}: file troppo grande (massimo 5 MB).")
    if raw[:2] == b"PK":
        out = []
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            for i in z.infolist()[:500]:
                if i.is_dir() or not i.filename.lower().endswith(".xml") or i.file_size > MASSIMO:
                    continue
                out.append((i.filename.rsplit("/", 1)[-1], z.read(i)))
        return out
    return [(nome, raw)]


def _esportazione(s, nome_file):
    e = s.scalar(select(EsportazioneFattura).where(EsportazioneFattura.nome_file == nome_file))
    if e is not None:
        return e
    # esportazioni precedenti alla 0.14: nome IT<partita IVA>_<id><rev> ricostruito
    for x in s.scalars(select(EsportazioneFattura).where(EsportazioneFattura.nome_file == "")):
        piva = json.loads(x.fotografia).get("societa", {}).get("partita_iva", "")
        if f"IT{piva}_{x.fattura_id:X}{x.revisione:02X}.xml" == nome_file:
            return x
    return None


def importa(s, u, files: list[tuple[str, bytes]]) -> list[dict]:
    """Registra le ricevute: per ognuna dice se è stata registrata, era già presente, o perché è stata scartata.
    Un file che non va non blocca gli altri."""
    from .servizio import esito
    risultati = []
    for nome, raw in files:
        for interno, contenuto in file_da(nome, raw):
            r = {"file": interno}
            try:
                n = leggi_notifica(contenuto)
                e = _esportazione(s, n["nome_file"])
                if e is None:
                    raise ErroreUtente(f"Nessuna fattura inviata con il file «{n['nome_file']}».")
                f = s.get(Fattura, e.fattura_id)
                prima = f.stato
                with s.begin_nested():
                    esito(s, u, e.id, {"esito": n["esito"], "identificativo_origine": f"SDI-{n['identificativo']}-{n['codice']}",
                                       "messaggio": (n["data"] + " · " if n["data"] else "") + n["messaggio"]})
                r |= {"fattura": f.codice, "esito": n["esito"], "stato": "già registrata" if prima == f.stato == n["esito"] else "registrata"}
            except (ErroreUtente, Conflitto) as x:
                r |= {"stato": "non registrata", "motivo": str(x)}
            risultati.append(r)
    if not risultati:
        raise ErroreUtente("Nessun file XML trovato.")
    return risultati
