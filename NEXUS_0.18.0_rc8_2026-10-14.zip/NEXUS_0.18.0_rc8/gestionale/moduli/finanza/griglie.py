"""Griglia delle fatture (0.12.10, doc. 30 § 9): come le altre — filtri, Excel, configurazioni — con la stampa rapida del
PDF di cortesia. Si apre sull'attività della pagina (Fatture AD_DPR o AD_DM); «Tutti gli ambiti» le mostra tutte."""

from __future__ import annotations

from sqlalchemy import case

from ...core.sql_portabile import oggi_italiano, data_tra_giorni, anno_dopo, giorni_fra, testi_uniti, json_testo
from ...core.griglia import Colonna, Griglia, registra
from ..anagrafica.modelli import Cliente
from .modelli import Fattura



def _da():  # noqa: ANN202
    return Fattura.__table__.join(Cliente.__table__, Fattura.cliente_id == Cliente.id)


registra(Griglia(
    codice="fatture", titolo="Fatture", permesso="fatture.vedere", da=_da,
    ordine_predefinito=[("data", "desc"), ("id", "desc")],
    ambito=lambda a: Fattura.ambito == a,
    colonne=[
        Colonna("id", "N. interno", "numero", Fattura.id, visibile=False, larghezza=80),
        Colonna("tipo", "Tipo", "elenco", Fattura.tipo, larghezza=80, opzioni=("TD01", "TD02", "TD04")),
        Colonna("codice", "Numero / anno / sezionale", "testo", Fattura.codice, larghezza=170,
                descrizione="Vuoto per le bozze, che si numerano all'emissione"),
        Colonna("data", "Data", "data", Fattura.data, larghezza=110),
        Colonna("cliente", "Cliente", "testo", Cliente.ragione_sociale, larghezza=260),
        Colonna("xml", "Fatt. elettronica generata", "elenco", case((Fattura.revisione_xml > 0, "Sì"), else_="No"), larghezza=120,
                opzioni=("Sì", "No")),
        Colonna("imponibile", "Totale imponibile", "importo", Fattura.imponibile, larghezza=130, somma=True),
        Colonna("dovuto", "Totale dovuto", "importo", Fattura.dovuto, larghezza=130, somma=True,
                descrizione="Quanto il cliente deve pagare (al netto di scissione dei pagamenti e ritenute)"),
        Colonna("totale", "Totale documento", "importo", Fattura.totale, visibile=False, larghezza=130),
        Colonna("stato", "Stato", "testo", Fattura.stato, visibile=False, larghezza=120),
        Colonna("ambito", "Attività", "elenco", Fattura.ambito, visibile=False, larghezza=90, opzioni=("DPR", "DM", "EX", "IEC")),
        Colonna("cliente_id", "N. cliente", "numero", Fattura.cliente_id, visibile=False, larghezza=80),
    ],
))


# ---------------------------------------------------------------- 0.14: scadenze di pagamento (Garda «pagamenti»)

from sqlalchemy import func, select  # noqa: E402

from .modelli import AllocazioneIncasso, Incasso, ScadenzaFattura  # noqa: E402

_Nota = Fattura.__table__.alias("nota")
_incassato = (select(func.coalesce(func.sum(AllocazioneIncasso.importo), 0))
              .select_from(AllocazioneIncasso.__table__.join(Incasso.__table__, AllocazioneIncasso.incasso_id == Incasso.id))
              .where(AllocazioneIncasso.fattura_id == Fattura.id, Incasso.stornato.is_(False)).correlate(Fattura).scalar_subquery())
_note = (select(func.coalesce(func.sum(_Nota.c.dovuto), 0)).where(
    _Nota.c.originale_id == Fattura.id, _Nota.c.tipo == "TD04", _Nota.c.stato.not_in(("bozza", "scartata")))
    .correlate(Fattura).scalar_subquery())
_residuo = Fattura.dovuto - _incassato - _note
# Le scadenze precedenti di una fattura assorbono gli incassi per prime (FIFO): una rata è saldata se gli incassi
# coprono lei e le precedenti.
_Prec = ScadenzaFattura.__table__.alias("prec")
_fino_a_qui = (select(func.coalesce(func.sum(_Prec.c.importo), 0)).where(
    _Prec.c.fattura_id == ScadenzaFattura.fattura_id,
    (_Prec.c.data < ScadenzaFattura.data) | ((_Prec.c.data == ScadenzaFattura.data) & (_Prec.c.id <= ScadenzaFattura.id)))
    .correlate(ScadenzaFattura).scalar_subquery())
_coperto = Fattura.dovuto - _residuo   # incassi + note di credito


# «oggi» calcolato dal database a ogni lettura (ora locale), non all'avvio del programma
_stato_rata = case((_coperto >= _fino_a_qui, "Saldata"), (ScadenzaFattura.data < oggi_italiano(), "Scaduta"),
                   else_="Da incassare")


def _da_scadenze():  # noqa: ANN202
    return (ScadenzaFattura.__table__.join(Fattura.__table__, ScadenzaFattura.fattura_id == Fattura.id)
            .join(Cliente.__table__, Fattura.cliente_id == Cliente.id))


registra(Griglia(
    codice="scadenze_pagamento", titolo="Scadenze di pagamento", permesso="incassi.vedere", da=_da_scadenze,
    condizione=lambda u: Fattura.stato.not_in(("bozza", "scartata")),
    ordine_predefinito=[("data_scadenza", "asc"), ("id", "asc")],
    ambito=lambda a: Fattura.ambito == a,
    colonne=[
        Colonna("id", "N. scadenza", "numero", ScadenzaFattura.id, visibile=False, larghezza=80),
        Colonna("fattura_id", "N. fattura (interno)", "numero", Fattura.id, visibile=False, larghezza=80),
        Colonna("data_scadenza", "Scadenza", "data", ScadenzaFattura.data, larghezza=110),
        Colonna("stato_rata", "Stato", "elenco", _stato_rata, larghezza=120, opzioni=("Scaduta", "Da incassare", "Saldata")),
        Colonna("importo", "Importo rata", "importo", ScadenzaFattura.importo, larghezza=120, somma=True),
        Colonna("modalita", "Modalità", "testo", ScadenzaFattura.modalita, larghezza=90),
        Colonna("fattura", "Fattura", "testo", Fattura.codice, larghezza=150),
        Colonna("data_fattura", "Data fattura", "data", Fattura.data, larghezza=110),
        Colonna("cliente", "Cliente", "testo", Cliente.ragione_sociale, larghezza=260),
        Colonna("dovuto", "Totale dovuto", "importo", Fattura.dovuto, larghezza=120, visibile=False),
        Colonna("residuo", "Residuo fattura", "importo", _residuo, larghezza=120,
                descrizione="Totale dovuto meno incassi e note di credito"),
        Colonna("ambito", "Attività", "elenco", Fattura.ambito, visibile=False, larghezza=90, opzioni=("DPR", "DM", "EX", "IEC")),
    ],
))
