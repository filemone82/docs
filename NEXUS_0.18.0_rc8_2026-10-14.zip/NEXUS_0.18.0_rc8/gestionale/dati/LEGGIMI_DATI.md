# Dati di riferimento

## comuni_istat.csv
Elenco dei comuni italiani (codice ISTAT, nome, sigla e nome della provincia, regione, CAP, codice catastale).

- Fonte dei comuni: archivio ISTAT (https://www.istat.it/it/archivio/6789), licenza CC BY 3.0 IT.
- Raccolta in formato JSON: https://github.com/matteocontrini/comuni-json (scaricata il 04/10/2026), convertita in CSV con `;` come separatore e CAP multipli separati da `|`.
- I CAP di quella raccolta provengono da fonti varie senza licenza dichiarata: uso interno.

Aggiornamento: per ora l'elenco si carica solo al primo avvio; un aggiornamento guidato (comuni nuovi o fusi) arriverà in una versione successiva. Le schede salvate conservano comunque comune, CAP, provincia e regione scritti per esteso.
