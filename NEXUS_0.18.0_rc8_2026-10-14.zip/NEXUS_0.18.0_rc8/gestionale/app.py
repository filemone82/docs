"""Creazione dell'applicazione: prepara l'archivio (migrazioni + dati di base), registra le pagine
e le interfacce dei moduli, imposta le protezioni del browser e i backup automatici."""

from __future__ import annotations

import logging
import re
import threading
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException

from . import VERSIONE
from .core import migrazioni
from .core.config import Config, carica_config
from .core.db import Archivio
from .core.errori import ErroreUtente
from .moduli.anagrafica import servizio as anagrafica
from .moduli.backup import servizio as backup
from .moduli.documenti import modelli_servizio as modelli_documento
from .moduli.registro import servizio as registro
from .moduli.tariffario import servizio as tariffario
from .moduli.utenti import servizio as utenti

log = logging.getLogger("gestionale")

PDF_PREVENTIVO = re.compile(r"/api/preventivi/\d+/documenti/\d+")
PDF_DM = re.compile(r"/api/dm/incarichi/\d+/documenti/\d+")
CSP = ("default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; font-src 'self'; "
       "connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")


class DatabaseTroppoNuovo(RuntimeError):
    pass


def prepara_archivio(cfg: Config) -> Archivio:
    """Apre il database; se serve fa il backup e applica le migrazioni; allinea ruoli e permessi."""
    if (cfg.cartella_dati / "ripristino_postgresql_in_corso.json").exists():
        raise RuntimeError("Ripristino PostgreSQL incompleto: mantenere l'applicazione ferma e consultare la procedura di recupero.")
    esisteva = cfg.postgresql or cfg.percorso_database.exists()
    arc = Archivio(cfg)
    revisione = migrazioni.revisione_database(arc.motore) if esisteva else None
    if revisione is not None and revisione not in migrazioni.revisioni_note():
        arc.chiudi()
        raise DatabaseTroppoNuovo("Il database è stato creato da una versione più recente di NEXUS: "
                                  "installa la versione più recente prima di avviare.")
    da_aggiornare = esisteva and revisione != migrazioni.revisione_programma()
    if da_aggiornare and revisione is not None:
        backup.crea(arc, "pre_aggiornamento", registra=False)
    migrazioni.aggiorna(arc.motore)
    from .moduli.beni import ponte_dpr  # noqa: F401 (proiezione transazionale)
    from .moduli.anagrafica import ambiti  # noqa: F401 (ambiti di clienti e sedi, R114)
    from .moduli.anagrafica import origini  # noqa: F401 (origini degli oggetti eliminati, AD-REV-005)
    with arc.scrittura() as s:
        from .moduli.finanza import servizio as finanza
        finanza.inizializza(s)
        utenti.inizializza(s)
        anagrafica.inizializza(s)  # elenco ISTAT dei comuni, elenchi di valori di partenza
        tariffario.prepara(s)      # tariffa terre del gestionale attuale come prima versione
        tariffario.prepara_m03_rev01(s)  # voci del tariffario M03-RG01_dpr rev. 01 (0.4.0)
        modelli_documento.prepara_dm(s, cfg)
        modelli_documento.prepara(s, cfg)  # modello dell'offerta M01-RG01_dpr rev. 03
        modelli_documento.prepara_verbali_dm(s, cfg)
        if da_aggiornare and revisione is not None:
            registro.scrivi(s, utente=None, azione="sistema.aggiornamento", oggetto_tipo="sistema",
                            descrizione=f"Database aggiornato alla versione {VERSIONE} del programma (backup fatto prima dell'aggiornamento)",
                            dettagli={"da": revisione, "a": migrazioni.revisione_programma()})
    return arc


def _ciclo_backup(arc: Archivio, ferma: threading.Event) -> None:
    """Backup automatico: subito se l'ultimo ha più di 24 ore, poi ogni N ore di uso."""
    try:
        if backup.serve_backup_giornaliero(arc):
            backup.crea(arc, "automatico")
    except Exception:  # un backup fallito non deve fermare il programma
        log.exception("Backup automatico non riuscito")
    while not ferma.wait(arc.cfg.ore_tra_backup_automatici * 3600):
        try:
            backup.crea(arc, "automatico")
        except Exception:
            log.exception("Backup automatico non riuscito")


def archivio_vuoto(arc: Archivio) -> bool:
    """O16: nessun cliente in archivio (prima installazione o cartella dei dati sbagliata)."""
    from sqlalchemy import func, select

    from .moduli.anagrafica.modelli import Cliente

    with arc.lettura() as s:
        return not s.execute(select(func.count()).select_from(Cliente)).scalar()


def crea_app(cfg: Config | None = None) -> FastAPI:
    cfg = cfg or carica_config()
    arc = prepara_archivio(cfg)
    ferma = threading.Event()

    @asynccontextmanager
    async def ciclo_di_vita(_app: FastAPI):  # noqa: ANN202
        if cfg.backup_automatico:
            threading.Thread(target=_ciclo_backup, args=(arc, ferma), daemon=True, name="backup-automatico").start()
        yield
        ferma.set()
        arc.chiudi()

    # Niente pagine di documentazione automatica: userebbero risorse da Internet.
    app = FastAPI(title="NEXUS", version=VERSIONE, docs_url=None, redoc_url=None, openapi_url=None, lifespan=ciclo_di_vita)
    app.state.archivio = arc
    # Verbali (VerbalizzAI dentro il gestionale, D67): archivio proprio nella cartella dei dati
    from .moduli.verbali import servizio as verbali
    from .moduli.verbali.archivio import ArchivioVerbali, ArchivioVerbaliPostgresql, PostaVerbali

    from .terzi.verbalizzai import pdfconv as vz_pdfconv

    vz_pdfconv.configure(cfg.libreoffice)  # 0.12.6: anche l'anteprima PDF dei verbali usa il LibreOffice indicato in config.json
    if cfg.verbali_postgresql:
        try:
            if not cfg.postgresql:
                raise RuntimeError("I verbali PostgreSQL richiedono GESTIONALE_DATABASE_URL.")
            app.state.verbali = ArchivioVerbaliPostgresql(cfg.cartella_dati / "verbali", arc)
            vecchio = cfg.cartella_dati / "verbali" / "archivio.sqlite"
            from .moduli.verbali.attivazione import verifica_archivio_precedente

            verifica_archivio_precedente(app.state.verbali, vecchio)
        except BaseException:
            arc.chiudi()
            raise
    else:
        app.state.verbali = ArchivioVerbali(cfg.cartella_dati / "verbali", arc)
    app.state.posta_verbali = PostaVerbali(cfg.cartella_dati)
    arc.verbali = app.state.verbali  # nei backup del gestionale
    app.state.archivio_vuoto = archivio_vuoto(arc)
    try:
        verbali.prepara(app.state.verbali)
    except Exception:  # modelli dei verbali non caricati: si possono importare da «Template Word»
        log.exception("Modelli dei verbali non caricati")

    @app.middleware("http")
    async def intestazioni_sicurezza(request: Request, call_next):  # noqa: ANN001, ANN202
        risposta = await call_next(request)
        # I PDF aperti nel browser per stamparli non ricevono la CSP: in Chrome/Edge «object-src 'none'» può
        # bloccare il lettore PDF interno. Un PDF non esegue script della pagina; restano nosniff e DENY.
        if not risposta.headers.get("content-type", "").startswith("application/pdf"):
            risposta.headers["Content-Security-Policy"] = CSP
        risposta.headers["X-Content-Type-Options"] = "nosniff"
        risposta.headers["Referrer-Policy"] = "same-origin"
        # Anteprima del verbale PDF dentro la pagina dei verbali (VerbalizzAI 0.3.31+): solo dallo stesso sito
        # e, dalla 0.7.0 (D80), del PDF del preventivo nella finestra «Controlla il documento»
        pdf = risposta.headers.get("content-type", "").startswith("application/pdf")
        anteprima = pdf and ((request.url.path == "/verbali/api/document" and request.query_params.get("inline") == "1")
                             or ((PDF_PREVENTIVO.fullmatch(request.url.path) is not None or PDF_DM.fullmatch(request.url.path) is not None) and request.query_params.get("in_linea") == "true"))
        risposta.headers["X-Frame-Options"] = "SAMEORIGIN" if anteprima else "DENY"
        risposta.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        if request.url.path.startswith("/api/"):
            risposta.headers["Cache-Control"] = "no-store"
        return risposta

    @app.exception_handler(ErroreUtente)
    async def errore_utente(request: Request, e: ErroreUtente):  # noqa: ANN202
        if e.stato == 401 and not request.url.path.startswith("/api/"):
            return RedirectResponse("/accesso", status_code=303)
        return JSONResponse({"errore": e.messaggio}, status_code=e.stato)

    @app.exception_handler(RequestValidationError)
    async def dati_non_validi(_request: Request, e: RequestValidationError):  # noqa: ANN202
        campi = sorted({str(err["loc"][-1]) for err in e.errors() if err.get("loc")})
        return JSONResponse({"errore": "Dati non validi o incompleti" + (f" nei campi: {', '.join(campi)}" if campi else "") + ". Controlla e riprova."},
                            status_code=422)

    @app.exception_handler(StarletteHTTPException)
    async def errore_http(_request: Request, e: StarletteHTTPException):  # noqa: ANN202
        messaggi = {404: "Pagina non trovata.", 405: "Operazione non consentita."}
        return JSONResponse({"errore": messaggi.get(e.status_code, str(e.detail))}, status_code=e.status_code)

    @app.exception_handler(Exception)
    async def errore_imprevisto(_request: Request, e: Exception):  # noqa: ANN202
        log.exception("Errore imprevisto", exc_info=e)
        return JSONResponse({"errore": "Errore imprevisto del programma: riprova; se si ripete, avvisa l'amministratore (dettagli nel file di log)."},
                            status_code=500)

    from .moduli.anagrafica import griglie as _griglie_anagrafica  # noqa: F401  (registra le griglie)
    from .moduli.anagrafica.api import router as r_anagrafica
    from .moduli.anagrafica.importazione_api import router as r_importazione
    from .moduli.backup.api import router as r_backup
    from .moduli.griglie.api import router as r_griglie
    from .moduli.registro.api import router as r_registro
    from .moduli.preventivi import griglie as _griglie_preventivi  # noqa: F401
    from .moduli.preventivi.api import router as r_preventivi
    from .moduli.tariffario import griglie as _griglie_tariffario  # noqa: F401
    from .moduli.tariffario.api import router as r_tariffario
    from .moduli.utenti import griglie as _griglie_utenti  # noqa: F401  (registra le griglie)
    from .moduli.utenti.api import router as r_utenti
    from .moduli.verifiche import griglie as _griglie_verifiche  # noqa: F401
    from .moduli.verifiche.api import router as r_verifiche
    from .moduli.verbali.api import router as r_verbali
    from .moduli.finanza.api import router as r_finanza
    from .moduli.beni import griglie as _griglie_beni  # noqa: F401  (attrezzature, valvole, cataloghi: R117)
    from .moduli.dm import griglie as _griglie_dm  # noqa: F401  (incarichi DM, 0.12.9)
    from .moduli.finanza import griglie as _griglie_fatture  # noqa: F401  (fatture, 0.12.10)
    from .moduli.strumenti import griglie as _griglie_strumenti  # noqa: F401  (strumenti DM e I&C, 0.16)
    from .moduli.strumenti.api import router as r_strumenti
    from .moduli.beni.api import router as r_beni
    from .moduli.dm.api import router as r_dm
    from .moduli.dm.inail_api import router as r_inail
    from .moduli.finanza.documenti_api import router as r_fatture_documenti
    from .moduli.documenti.destinazioni_api import router as r_destinazioni
    from .web.pagine import router as r_pagine

    for r in (r_utenti, r_registro, r_backup, r_griglie, r_anagrafica, r_importazione, r_tariffario, r_preventivi, r_verifiche, r_verbali, r_finanza, r_fatture_documenti, r_beni, r_dm, r_inail, r_strumenti, r_destinazioni, r_pagine):
        app.include_router(r)
    app.mount("/static", StaticFiles(directory=str(Path(__file__).resolve().parent / "static")), name="static")
    return app
