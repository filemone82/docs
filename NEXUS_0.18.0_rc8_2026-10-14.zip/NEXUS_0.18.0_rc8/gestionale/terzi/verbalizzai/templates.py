"""Imported Word templates, stable tags, repeat tables and DOCX generation."""
from __future__ import annotations
import copy, io, re, struct, threading, zlib, functools, xml.etree.ElementTree as ET
from zipfile import ZipFile, ZIP_DEFLATED
from .wordio import NS,q,txt,package,parse_word,paragraphs,GROUPS,sha,clean

_xml_lock=threading.RLock()
def serial_operation(fn):
    @functools.wraps(fn)
    def wrapped(*args,**kwargs):
        with _xml_lock:return fn(*args,**kwargs)
    return wrapped

def set_tag(s,value):
    pr=s.find('w:sdtPr',NS)
    if pr is None:pr=ET.SubElement(s,q('w:sdtPr'))
    t=pr.find('w:tag',NS)
    if t is None:t=ET.SubElement(pr,q('w:tag'))
    t.set(q('w:val'),value)
    for binding in list(pr.findall('w:dataBinding',NS)):pr.remove(binding)
def run(text,rpr=None):
    r=ET.Element(q('w:r'))
    if rpr is not None:r.append(copy.deepcopy(rpr))
    parts=str(text).split('\n')
    for i,s in enumerate(parts):
        if i:ET.SubElement(r,q('w:br'))
        t=ET.SubElement(r,q('w:t'));t.set('{http://www.w3.org/XML/1998/namespace}space','preserve');t.text=s
    return r
def replace_p(p,tag,rpr=None):
    if rpr is None:rpr=next((r.find('w:rPr',NS) for r in p.iter(q('w:r')) if r.find('w:rPr',NS) is not None),None)
    for e in list(p):
        if e.tag!=q('w:pPr'):p.remove(e)
    s=ET.SubElement(p,q('w:sdt'));set_tag(s,tag)
    content=ET.SubElement(s,q('w:sdtContent'));content.append(run('{{'+tag+'}}',rpr))
def replace_cell(c,tag,rpr=None):
    ps=c.findall('w:p',NS)
    p=ps[0] if ps else ET.SubElement(c,q('w:p'))
    for other in ps[1:]:c.remove(other)
    replace_p(p,tag,rpr if not any(r.find('w:rPr',NS) is not None for r in p.iter(q('w:r'))) else None)
def checked(s,val):
    c=s.find('w:sdtPr/w14:checkbox/w14:checked',NS)
    if c is not None:c.set(q('w14:val'),'1' if val else '0')
    ts=s.findall('.//w:t',NS)
    if ts:ts[0].text='☒' if val else '☐'
def serialize(root,original):
    # Preserve namespaces mentioned by mc:Ignorable even when not used by a node.
    namespaces=[]
    for _,item in ET.iterparse(io.BytesIO(original),events=['start-ns']):
        prefix,uri=item
        if prefix and not re.fullmatch(r'ns\d+',prefix):
            try:ET.register_namespace(prefix,uri)
            except ValueError:pass
            namespaces.append((prefix,uri))
    body=ET.tostring(root,encoding='unicode')
    first=body.split('>',1)[0]
    missing=''.join(' xmlns:'+k+'="'+v+'"' for k,v in dict(namespaces).items() if 'xmlns:'+k+'=' not in first)
    body=body.replace('>',missing+'>',1)
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'+body).encode('utf-8')
def write_package(z,modified):
    out=io.BytesIO()
    with ZipFile(out,'w',ZIP_DEFLATED) as target:
        for name in z.namelist():
            if any(s in name.lower() for s in ['vbaproject','vbadata','customxml/','activex/','_xmlsignatures/']):continue
            data=modified.get(name,z.read(name))
            if name=='[Content_Types].xml':
                root=ET.fromstring(data)
                for e in list(root):
                    if any(s in str(e.attrib).lower() for s in ['vba','customxml','activex','signature']):root.remove(e)
                    if e.get('PartName')=='/word/document.xml':e.set('ContentType','application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml')
                ET.register_namespace('',root.tag[1:].split('}')[0])
                data=ET.tostring(root,encoding='utf-8',xml_declaration=True)
            elif name.endswith('.rels'):
                root=ET.fromstring(data)
                for e in list(root):
                    if any(s in str(e.attrib).lower() for s in ['vba','customxml','activex','signature']):root.remove(e)
                ET.register_namespace('',root.tag[1:].split('}')[0])
                data=ET.tostring(root,encoding='utf-8',xml_declaration=True)
            target.writestr(name,data)
        for name,data in modified.items():
            if name not in z.namelist():target.writestr(name,data)
    return out.getvalue()
def split_newlines(root):
    # Un testo con «a capo» (es. cliente + denominazione impianto) diventa più righe nello stesso paragrafo.
    for r in list(root.iter(q('w:r'))):
        for t in list(r.findall('w:t',NS)):
            if t.text and '\n' in t.text:
                parts=t.text.split('\n');t.text=parts[0];i=list(r).index(t)
                for part in parts[1:]:
                    br=ET.Element(q('w:br'));nt=ET.Element(q('w:t'));nt.set('{http://www.w3.org/XML/1998/namespace}space','preserve');nt.text=part
                    r.insert(i+1,br);r.insert(i+2,nt);i+=2
def text_replace(p,pattern,replacement):
    nodes=list(p.iter(q('w:t')));texts=[t.text or '' for t in nodes];full=''.join(texts)
    matches=list(re.finditer(pattern,full,re.I))
    for m in reversed(matches):
        start,end=m.span();replacement_text=replacement(m) if callable(replacement) else m.expand(replacement)
        pos=0;first=True
        for i,s in enumerate(texts):
            a,b=pos,pos+len(s);pos=b
            if b<=start or a>=end:continue
            lo=max(0,start-a);hi=min(len(s),end-a)
            texts[i]=s[:lo]+(replacement_text if first else '')+s[hi:];first=False
    for n,s in zip(nodes,texts):n.text=s
    return len(matches)
def repeat_role(t,role,headers):
    pr=t.find('w:tblPr',NS)
    if pr is None:pr=ET.SubElement(t,q('w:tblPr'))
    cap=pr.find('w:tblCaption',NS)
    if cap is None:cap=ET.SubElement(pr,q('w:tblCaption'))
    cap.set(q('w:val'),'AD_REPEAT:'+role+':'+str(headers))
    rows=t.findall('w:tr',NS)
    prototype=None
    expected={'rcd':5,'overcurrent':7,'continuity':3,'instruments':5}[role]
    for r in rows[headers:]:
        cs=r.findall('w:tc',NS)
        if len(cs)==expected and (prototype is None or any(txt(c).strip() for c in cs[1:])):prototype=copy.deepcopy(r);break
    if prototype is None:
        prototype=ET.Element(q('w:tr'))
        for _ in range(expected):ET.SubElement(ET.SubElement(prototype,q('w:tc')),q('w:p'))
    for r in rows[headers:]:t.remove(r)
    for r in rows[:min(headers,2 if role=='rcd' else 1)]:
        rp=r.find('w:trPr',NS)
        if rp is None:rp=ET.SubElement(r,q('w:trPr'))
        if rp.find('w:tblHeader',NS) is None:ET.SubElement(rp,q('w:tblHeader'))
    # Empty prototype rows inherit the look of the last header row (e.g. the *** row).
    hdr_rpr=next((r.find('w:rPr',NS) for r in rows[max(0,headers-1)].iter(q('w:r')) if r.find('w:rPr',NS) is not None),None) if rows else None
    for cell in prototype.findall('w:tc',NS):
        prc=cell.find('w:tcPr',NS)
        if prc is not None:
            for e in list(prc):
                if e.tag in (q('w:vMerge'),q('w:gridSpan')):prc.remove(e)
        replace_cell(cell,'row.placeholder',hdr_rpr)
    t.append(prototype)

def _plain(rpr):
    if rpr is None:return None
    r=copy.deepcopy(rpr)
    for e in list(r):
        if e.tag in (q('w:b'),q('w:bCs'),q('w:i'),q('w:iCs'),q('w:caps'),q('w:u')):r.remove(e)
    return r
def _new_p_like(p,tag,rpr=None):
    new=ET.Element(q('w:p'));pr=p.find('w:pPr',NS)
    if pr is not None:
        pr=copy.deepcopy(pr)
        for e in list(pr):
            if e.tag in (q('w:rPr'),q('w:numPr'),q('w:pStyle')):pr.remove(e)
        new.append(pr)
    replace_p(new,tag,rpr);return new
def adapt_form(raw,filename,module):
    """Associazione automatica dei modelli M02/M03: caselle per ancora, campi per testo."""
    from .forms import FORMS,stream,locate,GROUP_TITLES
    spec=FORMS[module];z,root=package(raw);paragraphs(root);warnings=[]
    s,cbs=stream(root);found,missing,marks=locate(s,spec)
    for key,_a,opts,*_ in spec['groups']:
        for k,idx in zip(opts,found.get(key,[])):set_tag(cbs[idx],'flags.'+key+'.'+k);checked(cbs[idx],False)
    if missing:warnings.append('Gruppi di caselle non riconosciuti nel modello: '+', '.join(GROUP_TITLES.get(k,k) for k in missing))
    parent={c:pp for pp in root.iter() for c in pp}
    ps=list(root.iter(q('w:p')));text=[txt(p).strip() for p in ps]
    # Body font of the model: taken from its ordinary text, without bold/italic.
    def first_rpr(pred):
        par=next((p for p,x in zip(ps,text) if pred(x)),None)
        return next((r.find('w:rPr',NS) for r in par.iter(q('w:r')) if r.find('w:rPr',NS) is not None),None) if par is not None else None
    base=_plain(first_rpr(lambda x:x.startswith('Sulla base dell')))       # font of the body text
    small=first_rpr(lambda x:'struttura autoprotetta' in x or 'secondo norma CEI EN 60079-10-1' in x)  # size used in the tables
    if base is not None and small is not None:
        for tagname in ('w:sz','w:szCs'):
            src=small.find(tagname,NS);dst=base.find(tagname,NS)
            if src is not None:
                if dst is not None:base.remove(dst)
                base.append(copy.deepcopy(src))
    subs=[(r'Verbale n\.\s*\S+\s+del\s+\S+','Verbale n. {{header.number}} del {{header.report_date}}'),
      (r'Il Verificatore\s+_+\s+in data\s+_+','{{header.inspector_word}} {{header.inspectors}} in data {{header.dates_text}}'),
      (r'^ha proceduto','{{header.proceeded_word}}'),(r'a seguito di\s*_+','a seguito di {{header.reason}}'),
      (r'presso l.Azienda\s*_+','presso l’Azienda {{plant.client_name}}'),(r'ubicata in\s*_+','ubicata in {{plant.address}}'),
      (r'Rearth\s*=\s*_+','Rearth = {{tests.earth_re}}'),(r'(adottati:)\s*_+',r'\1 {{sampling.main}}'),
      (r'(eseguirsi entro:)\s*_+',r'\1 {{header.due_date}}'),(r'(pari a \(circa\):)\s*_+',r'\1 {{header.hours}}')]
    for p in ps:
        for pat,rep_ in subs:text_replace(p,pat,rep_)
    for i,(p,tx) in enumerate(zip(ps,text)):
        if re.search(r'Criteri di campionamento adottati:\s*$',tx) and i+1<len(ps) and re.fullmatch(r'_+',text[i+1]):replace_p(ps[i+1],'sampling.main',base)
        if re.search(r'Note e/o osservazioni:\s*$',tx) and i+1<len(ps) and re.fullmatch(r'[….\s]+',text[i+1]):replace_p(ps[i+1],'notes',base)
        if re.match(r'_+\s*,\s*in qualit',tx):replace_p(p,'header.representative',base)
        if re.search(r'consistite in:',tx):
            text_replace(p,r'(consistite in:)\s*[….]+',r'\1');par=parent.get(p)
            if par is not None:par.insert(list(par).index(p)+1,_new_p_like(p,'nonconformities',base))
    for path,a,b in spec['blocks']:
        ps=list(root.iter(q('w:p')));text=[txt(p).strip() for p in ps];parent={c:pp for pp in root.iter() for c in pp}
        ia=next((i for i,x in enumerate(text) if re.search(a,x,re.I)),None)
        ib=next((i for i in range((ia or 0)+1,len(text)) if re.search(b,text[i],re.I)),None) if ia is not None else None
        if ia is None or ib is None:warnings.append('Blocco non trovato: '+path);continue
        mid=ps[ia+1:ib]
        if mid:
            replace_p(mid[0],path,base)
            for extra in mid[1:]:
                if extra in parent:parent[extra].remove(extra)
        else:
            par=parent[ps[ib]];par.insert(list(par).index(ps[ib]),_new_p_like(ps[ib],path,base))
    for path,title in spec['cells']:
        cell=next((c for c in root.iter(q('w:tc')) if c.findall('w:p',NS) and txt(c.findall('w:p',NS)[0]).strip().startswith(title)),None)
        if cell is None:warnings.append('Cella non trovata: '+title);continue
        cps=cell.findall('w:p',NS);first=cps[0]
        for extra in cps[1:]:cell.remove(extra)
        cell.append(_new_p_like(first,path,base))
    for table in root.iter(q('w:tbl')):
        rows=table.findall('w:tr',NS)
        if len(rows)>=2 and 'Data di emissione del Verbale' in txt(rows[0]):
            cells=rows[1].findall('w:tc',NS)
            if len(cells)>=2:replace_cell(cells[0],'header.issued_date',base);replace_cell(cells[1],'header.signature_line',base)
        if rows and 'tipologia strumento' in txt(rows[0]).lower():repeat_role(table,'instruments',2)
    warnings.append('Associazione automatica '+module+': verificare il Word prodotto prima dell’uso operativo.')
    mod={'word/document.xml':serialize(root,z.read('word/document.xml'))}
    output=write_package(z,mod)
    tags=sorted({s_.find('w:sdtPr/w:tag',NS).get(q('w:val')) for s_ in root.iter(q('w:sdt')) if s_.find('w:sdtPr/w:tag',NS) is not None})
    tags+=sorted(set(re.findall(r'\{\{([a-zA-Z0-9_.]+)\}\}',' '.join(txt(p) for p in root.iter(q('w:p')))))-set(tags))
    return output,{'name':filename,'auto_associated':True,'fields':tags,'repeat_roles':['instruments'],'warnings':warnings,'format':'docx','version':'template-1','module':module}

@serial_operation
def adapt_template(raw,filename,mapping=None):
    z,root=package(raw);ps=paragraphs(root);existing=[]
    for s in root.iter(q('w:sdt')):
        tag=s.find('w:sdtPr/w:tag',NS)
        if tag is not None and tag.get(q('w:val')):existing.append(tag.get(q('w:val')))
    placeholders=re.findall(r'\{\{([a-zA-Z0-9_.]+)\}\}','\n'.join(txt(p) for p in ps))
    from .forms import detect_module
    module=detect_module(txt(root))
    if not existing and not placeholders and module in ('M02','M03'):return adapt_form(raw,filename,module)
    known=module=='M01'
    warnings=[];auto=False
    if not existing and not placeholders and known:
        parsed,root,ps,flagloc,tableloc,z=parse_word(raw,filename,True);auto=True
        body=root.find('w:body',NS);children=list(body)
        # Remove duplicate attachment sections; one repeat table per kind is retained.
        sections=[]
        for i,ch in enumerate(children):
            if ch.tag==q('w:p') and re.search(r'^Allegato al Verbale',txt(ch),re.I):
                nearby=' '.join(txt(e) for e in children[i+1:i+5])
                role='rcd' if re.search(r'PROVA DI FUNZIONAMENTO DEI DISPOSITIVI',nearby,re.I) else 'overcurrent' if re.search(r'PROVA DI COORDINAMENTO',nearby,re.I) else 'continuity' if re.search(r'PROVE DI CONTINUIT',nearby,re.I) else None
                if role:sections.append((i,role))
        seen=set();remove=set()
        for j,(i,role) in enumerate(sections):
            end=sections[j+1][0] if j+1<len(sections) else len(children)
            if role in seen:remove.update(k for k in range(i,end) if children[k].tag!=q('w:sectPr'))
            seen.add(role)
        for i in sorted(remove,reverse=True):body.remove(children[i])
        alive=set(root.iter())
        for key,s in flagloc.items():
            if s in alive:set_tag(s,'flags.'+key if not key.startswith('attachment_') else 'attachments.'+key[11:]+'.declared');checked(s,False)
        # Replace static record-specific paragraphs with fields, preserving paragraph styles.
        for p in list(root.iter(q('w:p'))):
            s=txt(p).strip();tag=None
            if re.search(r'^Allegato al Verbale n\.',s,re.I):tag='header.attachment_line'
            elif re.search(r'^Verbale n\.',s,re.I):tag='header.main_line'
            elif re.search(r'Il Verificator.*in data',s,re.I):tag='header.inspector_line'
            elif re.search(r'^presso l.Azienda',s,re.I):tag='plant.client_line'
            elif re.search(r'^ubicata in',s,re.I):tag='plant.address_line'
            elif re.search(r'^Anno di installazione',s,re.I):tag='plant.details_line'
            elif re.search(r'^Con alimentazione',s,re.I):tag='plant.pod_line'
            elif re.search(r'^Corrente di guasto',s,re.I):tag='plant.fault_line'
            elif re.search(r'^Rearth',s,re.I):tag='tests.earth_line'
            elif re.search(r'^Prossima verifica',s,re.I):tag='header.due_line'
            elif re.search(r'La durata della verifica',s,re.I):tag='header.hours_line'
            if tag:replace_p(p,tag)
        def section(a,b,tag):
            current=list(root.iter(q('w:p')));text=[txt(p) for p in current]
            ia=next((i for i,s in enumerate(text) if re.search(a,s,re.I)),None)
            ib=next((i for i in range(ia+1,len(text)) if re.search(b,text[i],re.I)),None) if ia is not None else None
            if ia is None or ib is None:return
            between=current[ia+1:ib]
            if not between:return
            first=between[0];replace_p(first,tag)
            parentmap={c:p for p in root.iter() for c in p}
            for p in between[1:]:
                if p in parentmap:parentmap[p].remove(p)
        section(r'non conformità rilevate sono consistite',r'Note e/o osservazioni','nonconformities')
        section(r'Note e/o osservazioni',r'Periodicità delle Verifiche','notes')
        section(r'in rappresentanza del Datore',r'Data di emissione del Verbale','header.representative')
        alive=set(root.iter())
        for key,cell in tableloc.items():
            if key.startswith('table.') or cell not in alive:continue
            if key.startswith('sampling.'):
                prefixes={'continuity':'Continuità elettrica\nCriterio di campionamento adottato:\n',
                  'overcurrent':'Coordinamento protezioni magnetotermiche (sistemi TN)\nCriterio di campionamento / motivazione:\n',
                  'rcd':'Coordinamento e funzionamento interruttori differenziali (sistemi TT e TN)\nCriterio di campionamento adottato:\n'}
                replace_cell(cell,key+'_line')
            else:replace_cell(cell,key)
        for role in ['rcd','overcurrent','continuity','instruments']:
            tables=[t for t in tableloc.get('table.'+role,[]) if t in alive]
            if tables:repeat_role(tables[0],role,3 if role in ('rcd','continuity') else 2)
        for table in root.iter(q('w:tbl')):
            rows=table.findall('w:tr',NS)
            if len(rows)>=2 and 'Data di emissione del Verbale' in txt(rows[0]):
                cells=rows[1].findall('w:tc',NS)
                if len(cells)>=2:replace_cell(cells[0],'header.issued_date');replace_cell(cells[1],'header.inspectors')
        for p in root.iter(q('w:p')):
            # Inline values share paragraphs with checkboxes; preserve their controls.
            text_replace(p,r'a seguito di\s*.*','a seguito di {{header.reason}}')
            text_replace(p,r'n\.\s*[_/\d ]+\s*cabin[ae] MT/BT','n. {{plant.cabins}} cabine MT/BT')
            text_replace(p,r'n\.\s*[_/\d ]+\s*stazioni AT','n. {{plant.stations}} stazioni AT')
            for kind,pat in [('rcd',r'prova dispositivi a corrente differenziale'),('overcurrent',r'misure dell.impedenza dell.anello'),('continuity',r'prove di continuità dei conduttori'),('contact',r'misure di tensione di contatto')]:
                if re.search(pat,txt(p),re.I):text_replace(p,r'n\.\s*[_/\d ]+\s*pag\.','n. {{attachments.'+kind+'.pages}} pag.')
        s=flagloc.get('at_relation.yes')
        if s is not None and s in alive:
            parent=next((p for p in root.iter(q('w:p')) if s in list(p.iter())),None)
            if parent is not None:
                text_replace(parent,r'\bSI\b.*','SI {{tests.at_calculation}}')
        # Remove diagonal "unused rows" markings; header logos stay intact.
        parentmap={c:p for p in root.iter() for c in p}
        for e in list(root.iter()):
            if e.tag.endswith('}line') and e in parentmap:parentmap[e].remove(e)
            elif e.tag==q('w:drawing'):
                has_image=any(n.tag.endswith('}blip') for n in e.iter())
                if not has_image and any(n.attrib.get('prst')=='line' for n in e.iter()) and e in parentmap:parentmap[e].remove(e)
        warnings.append('Associazione automatica M01: verificare il Word prodotto prima dell’uso operativo.')
    elif not existing and not placeholders:
        warnings.append('Template senza campi riconosciuti. Aggiungere segnaposto {{campo}} o controlli Word nominati e reimportare.')
    else:
        for s in root.iter(q('w:sdt')):
            tag=s.find('w:sdtPr/w:tag',NS)
            if tag is not None and mapping and tag.get(q('w:val')) in mapping:set_tag(s,mapping[tag.get(q('w:val'))])
    # Apply manual associations to tokens and controls, including headers/footers.
    parts={'word/document.xml':root}
    for name in z.namelist():
        if re.match(r'word/(header|footer)\d+\.xml',name):parts[name]=ET.fromstring(z.read(name))
    for part in parts.values():
        for s in part.iter(q('w:sdt')):
            tag=s.find('w:sdtPr/w:tag',NS)
            if tag is not None and mapping and tag.get(q('w:val')) in mapping:set_tag(s,mapping[tag.get(q('w:val'))])
        if mapping:
            for p in part.iter(q('w:p')):
                text_replace(p,r'\{\{([a-zA-Z0-9_.]+)\}\}',lambda m:'{{'+mapping.get(m[1],m[1])+'}}')
    # Remove data bindings even for manually tagged templates.
    for s in root.iter(q('w:sdt')):
        pr=s.find('w:sdtPr',NS)
        if pr is not None:
            for binding in list(pr.findall('w:dataBinding',NS)):pr.remove(binding)
    mod={name:serialize(part,z.read(name)) for name,part in parts.items()}
    output=write_package(z,mod)
    tags=sorted({s.find('w:sdtPr/w:tag',NS).get(q('w:val')) for part in parts.values() for s in part.iter(q('w:sdt')) if s.find('w:sdtPr/w:tag',NS) is not None})
    tags+=sorted(set(re.findall(r'\{\{([a-zA-Z0-9_.]+)\}\}',' '.join(txt(p) for p in parts.values())))-set(tags))
    roles=[]
    for t in root.iter(q('w:tbl')):
        cap=t.find('w:tblPr/w:tblCaption',NS)
        if cap is not None and cap.get(q('w:val'),'').startswith('AD_REPEAT:'):roles.append(cap.get(q('w:val')).split(':')[1])
    return output,{'name':filename,'auto_associated':auto,'fields':tags,'repeat_roles':roles,'warnings':warnings,'format':'docx','version':'template-1','module':module or 'M01'}

def field_values(d):
    values={}
    def flatten(obj,prefix=''):
        if isinstance(obj,dict):
            for k,v in obj.items():flatten(v,prefix+'.'+k if prefix else k)
        elif not isinstance(obj,list):values[prefix]=obj
    flatten(d)
    # Modello M03 rev. 01: casella «impianti Ex i non presenti» (non ancora gestita nella maschera: resta vuota).
    values.setdefault('flags.i_absent.yes',False)
    h=d['header'];p=d['plant'];t=d['tests']
    if d.get('revision_of'):values['header.number']=h.get('number','')+' — Revisione %02d'%int(d.get('rev_index',1))
    power=str(p.get('power','') or '').strip()
    if re.fullmatch(r'\d+(?:[.,]\d+)?',power):values['plant.power']=power+' kW'
    same=h.get('start_date')==h.get('end_date');dates=h.get('start_date','') if same else h.get('start_date','')+' - '+h.get('end_date','')
    many=bool(re.search(r'\s e \s*|,|\n',h.get('inspectors','') or ''))
    values.update({'header.inspector_word':'I Verificatori' if many else 'Il Verificatore','header.proceeded_word':'hanno proceduto' if many else 'ha proceduto',
      'header.dates_text':dates,'header.signature_line':re.sub(r'\s+e\s+|\s*,\s*','\n',h.get('inspectors','') or '').strip()})
    # Corrente di guasto e tempo in una riga; «non applicabile» in bassa tensione; «/» storici trattati come vuoti.
    cl=lambda v:'' if re.fullmatch(r'[\s/\-_.]*',str(v or '')) else str(v).strip()
    sup=[k for k,v in (d.get('flags',{}).get('supply') or {}).items() if v]
    if sup==['lt']:fault='non applicabile'
    else:
        parts=[]
        if cl(p.get('if_value')):parts.append('If = '+cl(p.get('if_value'))+' '+(p.get('if_unit') or 'A'))
        if cl(p.get('tf')):parts.append('tempo di intervento '+cl(p.get('tf'))+' s')
        fault=' — '.join(parts)
    values.update({'plant.fault_text':fault,'plant.cabins':cl(p.get('cabins')),'plant.stations':cl(p.get('stations')),'header.signature_image':''})
    # 0.3.26 (punto 54): con esito negativo non c'è una prossima scadenza (il D.P.R. 462/01 prevede
    # una verifica straordinaria). Nella casella si stampa «*» e la motivazione sta nelle
    # osservazioni, su una riga che inizia con «*», scritta dal verificatore.
    out=d.get('flags',{}).get('outcome') or {}
    if out.get('negative') and not out.get('positive'):values['header.due_date']='*'
    values.update({'header.main_line':'Verbale n. '+values.get('header.number','')+' del '+h.get('report_date',''),
      'header.attachment_line':'Allegato al Verbale n. '+values.get('header.number','')+' del '+h.get('report_date',''),
      'header.inspector_line':('I Verificatori ' if many else 'Il Verificatore ')+h.get('inspectors','')+' in data '+dates+(' hanno' if many else ' ha')+' proceduto ad effettuare la verifica:',
      'plant.client_line':'presso l’Azienda '+p.get('client_name','')+('\n'+p['site_name'] if p.get('site_name') else ''),'plant.client_full':p.get('client_name','')+('\n'+p['site_name'] if p.get('site_name') else ''),'plant.address_line':'ubicata in '+p.get('address',''),
      'plant.details_line':'Anno di installazione: '+p.get('installation_year','')+'    Potenzialità: '+values.get('plant.power','')+'    Tensione di esercizio: '+p.get('voltage',''),
      'plant.pod_line':'Con alimentazione'+(' POD: '+p['pod'] if p.get('pod') else ':'),
      'plant.fault_line':'Corrente di guasto MT / AT: '+p.get('if_value','')+' ['+p.get('if_unit','A')+']    Tempo di intervento: '+p.get('tf','')+' [s]',
      'tests.earth_line':'Rearth = '+t.get('earth_re','')+' Ω',
      'header.due_line':'Prossima verifica da eseguirsi entro: '+h.get('due_date',''),
      'header.hours_line':'La durata della verifica (inclusi esame documentale e redazione del Verbale e del Rapporto di Verifica) è stata pari a (circa): '+h.get('hours','')+' ore / uomo.'})
    for kind,prefix in [('continuity','Continuità elettrica\nCriterio di campionamento adottato:\n'),('overcurrent','Coordinamento protezioni magnetotermiche (sistemi TN)\nCriterio di campionamento / motivazione:\n'),('rcd','Coordinamento e funzionamento interruttori differenziali (sistemi TT e TN)\nCriterio di campionamento adottato:\n')]:
        values['sampling.'+kind+'_line']=prefix+d.get('sampling',{}).get(kind,'')
    reasons=[s.get('board','')+' · '+s.get('name','')+': '+s['reason'] for s in d.get('samples',[]) if s.get('state')!='excluded' and s.get('reason')]
    if reasons:values['notes']=(d.get('notes','')+'\n\nMotivazioni relative alle prove:\n'+'\n'.join(reasons)).strip()
    return values
def fill_cell(c,value,bold=False):
    ps=c.findall('w:p',NS);p=ps[0] if ps else ET.SubElement(c,q('w:p'))
    for other in ps[1:]:c.remove(other)
    # Stile del campo: quello dichiarato nel controllo contenuto (non quello grigio del segnaposto).
    rpr=next((x for x in (s.find('w:sdtPr/w:rPr',NS) for s in p.iter(q('w:sdt'))) if x is not None),None)
    if rpr is None:rpr=next((r.find('w:rPr',NS) for r in p.iter(q('w:r')) if r.find('w:rPr',NS) is not None),None)
    if bold and rpr is not None:
        rpr=copy.deepcopy(rpr)
        if rpr.find('w:b',NS) is None:rpr.insert(1,ET.Element(q('w:b')))
    for e in list(p):
        if e.tag!=q('w:pPr'):p.remove(e)
    p.append(run(value,rpr))
    pr=c.find('w:tcPr',NS)
    if pr is not None:
        for e in list(pr):
            if e.tag in (q('w:vMerge'),q('w:gridSpan')):pr.remove(e)
def append_table(root,role,d):
    """Never silently omit selected samples when a template lacks their table."""
    labels={'rcd':['Circuito protetto','Marca / modello','Idn [A]','Meccanico','Tempo [ms]'],
      'overcurrent':['Circuito protetto','Marca / modello','In [A]','Ia [A]','Zs [Ω]','Ig [A]','Coordinamento'],
      'continuity':['Massa / circuito','Punto di riferimento','Esito'],
      'instruments':['Tipo','Marca','Modello','Matricola','Ultima taratura']}
    titles={'rcd':'Prova dispositivi differenziali','overcurrent':'Prova coordinamento protezioni magnetotermiche','continuity':'Prove di continuità','instruments':'Strumentazione utilizzata'}
    body=root.find('w:body',NS);section=body.find('w:sectPr',NS);pos=list(body).index(section) if section is not None else len(body)
    p=ET.Element(q('w:p'));pr=ET.SubElement(p,q('w:pPr'));ET.SubElement(pr,q('w:pageBreakBefore'));p.append(run('Allegato al Verbale n. '+d['header'].get('number','')+' del '+d['header'].get('report_date','')+'\n'+titles[role]));body.insert(pos,p);pos+=1
    t=ET.Element(q('w:tbl'));pr=ET.SubElement(t,q('w:tblPr'));ET.SubElement(pr,q('w:tblW'),{q('w:w'):'5000',q('w:type'):'pct'})
    borders=ET.SubElement(pr,q('w:tblBorders'))
    for edge in ['top','left','bottom','right','insideH','insideV']:ET.SubElement(borders,q('w:'+edge),{q('w:val'):'single',q('w:sz'):'4',q('w:color'):'808080'})
    grid=ET.SubElement(t,q('w:tblGrid'))
    widths={'rcd':[3300,3300,1300,1200,1300],'overcurrent':[2800,2600,800,800,900,1100,1400],'continuity':[4500,4400,1500],'instruments':[2400,1800,2000,2000,2200]}[role]
    for width in widths:ET.SubElement(grid,q('w:gridCol'),{q('w:w'):str(width)})
    for vals in [labels[role],['']*len(labels[role])]:
        row=ET.SubElement(t,q('w:tr'))
        for val,width in zip(vals,widths):
            c=ET.SubElement(row,q('w:tc'));cp=ET.SubElement(c,q('w:tcPr'));ET.SubElement(cp,q('w:tcW'),{q('w:w'):str(width),q('w:type'):'dxa'});p=ET.SubElement(c,q('w:p'));rpr=ET.Element(q('w:rPr'));ET.SubElement(rpr,q('w:sz'),{q('w:val'):'18'});p.append(run(val,rpr))
    repeat_role(t,role,1);body.insert(pos,t)

def remove_unused_annexes(root,d):
    body=root.find('w:body',NS);children=list(body);sections=[]
    for i,ch in enumerate(children):
        if ch.tag!=q('w:p') or not re.search(r'^Allegato al Verbale',txt(ch),re.I):continue
        following=children[i:i+5];nearby=' '.join(txt(e) for e in children[i+1:i+3] if e.tag==q('w:p'))
        captions=[cap.get(q('w:val'),'').split(':') for e in following for cap in e.findall('.//w:tblCaption',NS)]
        role=next((bits[1] for bits in captions if len(bits)>1 and bits[0]=='AD_REPEAT' and bits[1] in ('rcd','overcurrent','continuity')),None)
        if role is None:role='rcd' if re.search(r'PROVA DI FUNZIONAMENTO DEI DISPOSITIVI',nearby,re.I) else 'overcurrent' if re.search(r'PROVA DI COORDINAMENTO',nearby,re.I) else 'continuity' if re.search(r'PROVE DI CONTINUIT',nearby,re.I) else None
        if role:sections.append((i,role))
    for j,(i,role) in reversed(list(enumerate(sections))):
        active=any(s['kind']==role and s.get('state')!='excluded' for s in d.get('samples',[]))
        if active or d.get('attachments',{}).get(role,{}).get('declared'):continue
        end=sections[j+1][0] if j+1<len(sections) else len(children)
        for ch in children[i:end]:
            if ch.tag!=q('w:sectPr') and ch in list(body):body.remove(ch)

ANNEX_KINDS=('rcd','overcurrent','continuity')
def drop_empty_optional_lines(root,values,tags):
    """Righe facoltative vuote (es. seconda riga del cliente): il paragrafo viene tolto, così il testo resta
    allineato all'etichetta invece di lasciare una riga bianca."""
    parent={c:pp for pp in root.iter() for c in pp}
    for s in list(root.iter(q('w:sdt'))):
        tag=s.find('w:sdtPr/w:tag',NS);name=tag.get(q('w:val'),'') if tag is not None else ''
        if name not in tags or str(values.get(name) or '').strip():continue
        p=s
        while p in parent and p.tag!=q('w:p'):p=parent[p]
        if p.tag!=q('w:p') or p not in parent or txt(p).strip():continue
        cell=parent[p]
        if len(cell.findall('w:p',NS))>1 and p in list(cell):cell.remove(p)
def _keep_next(p):
    pr=p.find('w:pPr',NS)
    if pr is None:pr=ET.Element(q('w:pPr'));p.insert(0,pr)
    if pr.find('w:keepNext',NS) is None:pr.insert(sum(1 for e in pr if e.tag==q('w:pStyle')),ET.Element(q('w:keepNext')))
KEEP_WITH_SIGN=3   # 0.3.25 (punto 47): righe finali della tabella delle prove tenute con il riquadro firme
def keep_signature_blocks(root):
    """Il riquadro firme («Data di emissione… / Il Verificatore») non si spezza fra due pagine:
    righe non divisibili e paragrafi «mantieni con il successivo»; la legenda e la riga vuota che lo
    precedono restano con lui."""
    body=root.find('w:body',NS);children=list(body)
    for i,t in enumerate(children):
        if t.tag!=q('w:tbl') or 'Il Verificatore' not in txt(t) or t.find('w:tblPr/w:tblCaption',NS) is not None:continue
        rows=t.findall('w:tr',NS)
        for r in rows:
            rp=r.find('w:trPr',NS)
            if rp is None:rp=ET.Element(q('w:trPr'));r.insert(0 if r.find('w:tblPrEx',NS) is None else 1,rp)
            if rp.find('w:cantSplit',NS) is None:rp.insert(0,ET.Element(q('w:cantSplit')))
        for r in rows[:-1]:
            for p in r.iter(q('w:p')):_keep_next(p)
        j=i-1
        while j>=0 and children[j].tag==q('w:p') and i-j<=2:
            if children[j].find('w:pPr/w:sectPr',NS) is not None:break
            _keep_next(children[j]);j-=1
        if j>=0 and children[j].tag==q('w:tbl') and children[j].find('w:tblPr/w:tblCaption',NS) is not None:
            # Le ultime righe della tabella delle prove restano con legenda e firme: mai una riga sola
            # con il riquadro firme (punto 47). 0.3.24 ne teneva una sola e capitava che quella riga
            # finisse da sola in fondo. Se ne tengono fino a KEEP_WITH_SIGN, lasciandone almeno una
            # (più l'intestazione) sulla pagina precedente, altrimenti si sposta la tabella intera.
            last=children[j].findall('w:tr',NS)
            keep=min(KEEP_WITH_SIGN,max(0,len(last)-2))
            for r in last[len(last)-keep:] if keep else []:
                for p in r.iter(q('w:p')):_keep_next(p)
def page_breaks_before(root):
    """Un paragrafo vuoto che contiene solo un'interruzione di pagina, se la tabella precedente riempie la pagina
    fino in fondo, finisce da solo sulla pagina successiva e crea una pagina bianca. Lo si sostituisce con
    «interruzione di pagina prima» sul paragrafo che segue (es. «Allegato al Verbale…»)."""
    body=root.find('w:body',NS);children=list(body)
    for i,ch in enumerate(children[:-1]):
        nxt=children[i+1]
        if ch.tag!=q('w:p') or nxt.tag!=q('w:p') or txt(ch).strip():continue
        brs=ch.findall('.//w:br',NS)
        if len(brs)!=1 or brs[0].get(q('w:type'))!='page' or ch.find('.//w:drawing',NS) is not None or ch.find('w:pPr/w:sectPr',NS) is not None:continue
        pr=nxt.find('w:pPr',NS)
        if pr is None:pr=ET.Element(q('w:pPr'));nxt.insert(0,pr)
        if pr.find('w:pageBreakBefore',NS) is None:
            el=ET.Element(q('w:pageBreakBefore'))
            # ordine dello schema: pStyle, keepNext, keepLines, pageBreakBefore, ...
            pos=sum(1 for e in pr if e.tag in (q('w:pStyle'),q('w:keepNext'),q('w:keepLines')))
            pr.insert(pos,el)
        body.remove(ch)
def drop_undeclared_attachment_lines(root,values):
    """Nell'elenco «Allegati» si stampano solo le righe degli allegati presenti (decisione 03/10):
    via i paragrafi la cui casella «attachments.<tipo>.declared» non è spuntata."""
    parent={c:pp for pp in root.iter() for c in pp}
    for s in list(root.iter(q('w:sdt'))):
        tag=s.find('w:sdtPr/w:tag',NS);name=tag.get(q('w:val'),'') if tag is not None else ''
        m=re.fullmatch(r'attachments\.(\w+)\.declared',name)
        if not m or values.get(name):continue
        p=s
        while p in parent and p.tag!=q('w:p'):p=parent[p]
        if p.tag==q('w:p') and p in parent and p in list(parent[p]):parent[p].remove(p)
def annex_sections(root):
    """Paragrafi «Allegato al Verbale…» del corpo, nell'ordine, con il ruolo dell'allegato (None per le parti
    senza tabella di prove, es. il Rapporto di verifica): il ruolo è la prima tabella ripetibile della sezione."""
    body=root.find('w:body',NS);children=list(body)
    idx=[i for i,ch in enumerate(children) if ch.tag==q('w:p') and re.search(r'^Allegato al Verbale',txt(ch),re.I)]
    out=[]
    for j,i in enumerate(idx):
        end=idx[j+1] if j+1<len(idx) else len(children);role=None
        for e in children[i:end]:
            for cap in e.findall('.//w:tblCaption',NS):
                bits=cap.get(q('w:val'),'').split(':')
                if len(bits)>1 and bits[0]=='AD_REPEAT' and bits[1] in ANNEX_KINDS:role=role or bits[1]
        if role is None:
            title=next((txt(e).strip() for e in children[i+1:end] if e.tag==q('w:p') and txt(e).strip()),'')
            role='rcd' if re.match(r'PROVA DI FUNZIONAMENTO DEI DISPOSITIVI',title,re.I) else 'overcurrent' if re.match(r'(PROVA DI COORDINAMENTO|MISURE DELL.IMPEDENZA)',title,re.I) else 'continuity' if re.match(r'PROVE DI CONTINUIT',title,re.I) else None
        out.append((children[i],role))
    return out
def mark_annexes(root):
    """Livello di struttura sul paragrafo iniziale di ogni parte «Allegato al Verbale»: diventa un segnalibro
    del PDF e permette di contare le pagine di ciascun allegato. Restituisce i ruoli nell'ordine ('-' = altra parte)."""
    roles=[]
    for p,role in annex_sections(root):
        pr=p.find('w:pPr',NS)
        if pr is None:pr=ET.Element(q('w:pPr'));p.insert(0,pr)
        for e in pr.findall('w:outlineLvl',NS):pr.remove(e)
        ET.SubElement(pr,q('w:outlineLvl'),{q('w:val'):'0'});roles.append(role or '-')
    return roles
def annex_roles(missing):
    """Ordine degli allegati riportato da generate_word."""
    return [x.split(':',2)[2] for x in sorted(m for m in missing if m.startswith('AD_ANNEX:'))]
def auto_attachments(d,pages=None):
    """Copia dei dati con gli allegati delle prove dichiarati in base agli elementi provati e, se note, le pagine."""
    d=copy.deepcopy(d);att=d.setdefault('attachments',{})
    for k in ANNEX_KINDS:
        a=att.setdefault(k,{'declared':False,'pages':''})
        a['declared']=any(s.get('kind')==k and s.get('state')!='excluded' for s in d.get('samples',[]))
        a['pages']=str(pages[k]) if a['declared'] and pages and pages.get(k) else ('' if not a['declared'] else a.get('pages',''))
    anyatt=any(v.get('declared') for v in att.values())
    d.setdefault('flags',{})['attachments']={'no':not anyatt,'yes':anyatt}
    return d

# --- firma grafica del verificatore --------------------------------------------------------
NS_WP='http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing'
NS_A='http://schemas.openxmlformats.org/drawingml/2006/main'
NS_PIC='http://schemas.openxmlformats.org/drawingml/2006/picture'
NS_REL='http://schemas.openxmlformats.org/package/2006/relationships'
NS_CT='http://schemas.openxmlformats.org/package/2006/content-types'
SIGN_MAX_W=6.5;SIGN_MAX_H=3.0   # cm (0.3.26: con il ritaglio automatico del punto 40c il riquadro vale per il contenuto, quindi il timbro tondo esce davvero di 3,0 cm; 0.3.25 era 3,5 su immagine non ritagliata, cioè 2,94 visibili)
def image_info(data):
    """Formato e dimensioni in pixel di un PNG o JPEG (solo libreria standard)."""
    if data[:8]==b'\x89PNG\r\n\x1a\n' and len(data)>24:
        return 'png',int.from_bytes(data[16:20],'big'),int.from_bytes(data[20:24],'big')
    if data[:2]==b'\xff\xd8':
        i=2
        while i+9<len(data):
            if data[i]!=0xFF:i+=1;continue
            m=data[i+1];ln=int.from_bytes(data[i+2:i+4],'big')
            if m in (0xC0,0xC1,0xC2,0xC3,0xC5,0xC6,0xC7,0xC9,0xCA,0xCB,0xCD,0xCE,0xCF):
                return 'jpeg',int.from_bytes(data[i+7:i+9],'big'),int.from_bytes(data[i+5:i+7],'big')
            i+=2+ln
    raise ValueError('Immagine della firma non valida: usare un file PNG o JPG.')
# --- 0.3.26 (punto 40c): ritaglio automatico del margine vuoto della firma -------------------
# Le immagini di timbro e firma arrivano quasi sempre con una cornice vuota attorno (il timbro di
# AD ne ha l'8% per lato). Quella cornice occupa spazio nel riquadro firme senza mostrare nulla:
# a parità di riquadro il timbro si vede più piccolo, e stringere il riquadro lo rimpicciolirebbe
# ancora invece di togliere il vuoto. Qui si misura il riquadro del contenuto e lo si ritaglia in
# fase di inserimento, con <a:srcRect>: l'immagine archiviata non viene toccata, cambia solo come
# il Word la mostra. Si legge solo il PNG (il JPEG richiederebbe un decodificatore completo):
# su qualunque formato o variante non gestita si restituisce None e non si ritaglia nulla.
CROP_MIN=0.02   # sotto il 2% di margine non vale la pena ritagliare
CROP_MAX=0.45   # non si toglie mai più di così per lato: protegge da immagini quasi vuote
_crop_cache={}

def png_content_box(data):
    """(sinistra, alto, destra, basso) come frazioni di margine vuoto, oppure None.

    Vuoto = trasparente o quasi bianco, così funziona sia con i PNG con trasparenza sia con le
    scansioni su fondo bianco. Gestisce profondità 8 e 16 bit, scala di grigi, RGB, tavolozza e
    canale alfa, senza interlacciamento."""
    if data[:8]!=b'\x89PNG\r\n\x1a\n':return None
    pos=8;width=height=depth=ctype=interlace=None;idat=bytearray();plte=trns=None
    while pos+8<=len(data):
        ln=int.from_bytes(data[pos:pos+4],'big');typ=data[pos+4:pos+8]
        body=data[pos+8:pos+8+ln];pos+=12+ln
        if typ==b'IHDR':
            if len(body)<13:return None
            width,height,depth,ctype,_,_,interlace=struct.unpack('>IIBBBBB',body[:13])
        elif typ==b'PLTE':plte=body
        elif typ==b'tRNS':trns=body
        elif typ==b'IDAT':idat+=body
        elif typ==b'IEND':break
    if not width or not height or interlace!=0 or depth not in (8,16):return None
    channels={0:1,2:3,3:1,4:2,6:4}.get(ctype)
    if channels is None or (ctype==3 and plte is None):return None
    sample=depth//8;bpp=channels*sample;stride=width*bpp
    try:raw=zlib.decompress(bytes(idat))
    except zlib.error:return None
    if len(raw)<(stride+1)*height:return None
    prev=bytearray(stride);lines=[];p=0
    for _ in range(height):
        f=raw[p];line=bytearray(raw[p+1:p+1+stride]);p+=1+stride
        if f==1:
            for i in range(bpp,stride):line[i]=(line[i]+line[i-bpp])&255
        elif f==2:
            for i in range(stride):line[i]=(line[i]+prev[i])&255
        elif f==3:
            for i in range(stride):
                a=line[i-bpp] if i>=bpp else 0
                line[i]=(line[i]+((a+prev[i])>>1))&255
        elif f==4:
            for i in range(stride):
                a=line[i-bpp] if i>=bpp else 0
                b=prev[i];c=prev[i-bpp] if i>=bpp else 0
                t=a+b-c;pa,pb,pc=abs(t-a),abs(t-b),abs(t-c)
                line[i]=(line[i]+(a if pa<=pb and pa<=pc else b if pb<=pc else c))&255
        elif f!=0:return None
        lines.append(bytes(line));prev=line
    left,top,right,bottom=width,height,-1,-1
    for y,line in enumerate(lines):
        for x in range(width):
            o=x*bpp
            if ctype==3:
                idx=line[o]
                if idx*3+2>=len(plte):continue
                r,g,b=plte[idx*3],plte[idx*3+1],plte[idx*3+2];a=trns[idx] if trns and idx<len(trns) else 255
            elif ctype==0:r=g=b=line[o];a=255
            elif ctype==4:r=g=b=line[o];a=line[o+sample]
            elif ctype==2:r,g,b=line[o],line[o+sample],line[o+2*sample];a=255
            else:r,g,b=line[o],line[o+sample],line[o+2*sample];a=line[o+3*sample]
            if a<=25:continue                      # trasparente
            if r>=240 and g>=240 and b>=240:continue   # quasi bianco: sfondo
            if x<left:left=x
            if x>right:right=x
            if y<top:top=y
            if y>bottom:bottom=y
    if right<0:return None                          # immagine tutta vuota: meglio non toccarla
    return (left/width,top/height,(width-1-right)/width,(height-1-bottom)/height)

def signature_crop(data):
    """Margine da togliere alla firma, con memoria interna (la stessa immagine ricorre su verbale
    e allegati). None se non c'è niente da ritagliare o se l'immagine non è leggibile."""
    key=sha(data)
    if key in _crop_cache:return _crop_cache[key]
    box=png_content_box(data)
    if box and (max(box)<CROP_MIN or max(box)>CROP_MAX):box=None
    if len(_crop_cache)>32:_crop_cache.clear()
    _crop_cache[key]=box;return box

def signature_extent(w_px,h_px,crop=None):
    """Ingombro (cx, cy in EMU) del timbro nel riquadro firme: identico in anteprima e all'emissione."""
    l,t,r,b=crop or (0,0,0,0)
    cw=w_px*(1-l-r);ch=h_px*(1-t-b)      # il riquadro vale per il contenuto, non per la cornice
    ratio=min(SIGN_MAX_W/max(cw,1),SIGN_MAX_H/max(ch,1))
    return int(cw*ratio*360000),int(ch*ratio*360000)
def signature_run(rid,w_px,h_px,name='Firma',crop=None,extent=None):
    cx,cy=extent or signature_extent(w_px,h_px,crop)
    l,t,r,b=crop or (0,0,0,0)
    xml=('<w:r xmlns:w="%s" xmlns:r="%s" xmlns:wp="%s" xmlns:a="%s" xmlns:pic="%s"><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0">'
         '<wp:extent cx="%d" cy="%d"/><wp:docPr id="9001" name="%s" descr="%s"/><wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr>'
         '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="9001" name="%s"/><pic:cNvPicPr/></pic:nvPicPr>'
         '<pic:blipFill><a:blip r:embed="%s"/>%s<a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
         '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="%d" cy="%d"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic>'
         '</wp:inline></w:drawing></w:r>')%(NS['w'],NS['r'],NS_WP,NS_A,NS_PIC,cx,cy,name,name,name,rid,
           # srcRect ritaglia l'immagine al momento della resa, in millesimi di punto percentuale
           '' if not crop else '<a:srcRect l="%d" t="%d" r="%d" b="%d"/>'%tuple(round(v*100000) for v in (l,t,r,b)),
           cx,cy)
    return ET.fromstring(xml)
def drop_signature_names(root,parent=None):
    """0.3.25 (punto 41): tolto il nome e cognome sotto il riquadro «Il Verificatore» quando il
    timbro con firma grafica è stato inserito (verbale e allegati). Senza firma grafica il nome
    resta, perché è l'unica indicazione del verificatore in calce. Il nome in testa al verbale
    («Il Verificatore … in data … ha proceduto») non viene toccato: è un campo diverso
    (header.inspector_line / header.inspectors)."""
    if parent is None:parent={c:pp for pp in root.iter() for c in pp}
    n=0
    for s in [s for s in root.iter(q('w:sdt')) if (lambda t:t is not None and t.get(q('w:val'))=='header.signature_line')(s.find('w:sdtPr/w:tag',NS))]:
        p0=s
        while p0 in parent and p0.tag!=q('w:p'):p0=parent[p0]
        if p0.tag==q('w:p') and p0 in parent:parent[p0].remove(p0);n+=1
        elif s in parent:parent[s].remove(s);n+=1
    return n
# --- 1.0.0 rc3: spazio firma riservato in anteprima ------------------------------------------
# Fino alla rc2 l'anteprima (e il Word da ritoccare) aveva sotto «Il Verificatore» il solo nome,
# mentre all'emissione arrivava il timbro alto 3 cm al posto del nome: ogni riquadro firme
# cresceva di circa 2,5 cm DOPO la presa visione. Con i ritocchi a righe vuote fatti
# sull'anteprima, i blocchi legati («mantieni con il successivo») non stavano più nella pagina
# e saltavano interi alla successiva (VP/692/26: 6 pagine in anteprima, 9 nel PDF firmato).
# Ora l'anteprima contiene già, in ogni riquadro, un segnaposto con l'ingombro esatto del timbro
# del firmatario (e senza il nome, come nel definitivo); all'emissione si sostituisce soltanto
# l'immagine dentro lo stesso riquadro: l'impaginazione non può più cambiare.
RESERVED_NAME='AD_SPAZIO_FIRMA'
RESERVED_RID='rIdAdSpazioFirma';RESERVED_MEDIA='media/spazio_firma.png'
SIGN_RID='rIdAdFirmaVerificatore'

def _png(width,height,pixel):
    """PNG RGBA minimale (solo libreria standard); pixel(x,y) -> (r,g,b,a)."""
    rows=b''.join(b'\x00'+bytes(v for x in range(width) for v in pixel(x,y)) for y in range(height))
    chunk=lambda t,d:struct.pack('>I',len(d))+t+d+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
    return (b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',width,height,8,6,0,0,0))
            +chunk(b'IDAT',zlib.compress(rows,9))+chunk(b'IEND',b''))

def placeholder_png(cx,cy):
    """Riquadro tratteggiato grigio chiaro, interno trasparente, con le proporzioni del timbro."""
    w=240;h=max(24,min(960,round(w*cy/max(cx,1))));line=3;dash=14
    def px(x,y):
        edge=x<line or y<line or x>=w-line or y>=h-line
        on=((x if (y<line or y>=h-line) else y)//dash)%2==0
        return (184,196,196,255) if edge and on else (0,0,0,0)
    return _png(w,h,px)

def _register_media(z,modified,rid,media,data,fmt):
    """Relazione e tipo di contenuto per un'immagine del documento (sostituisce quella con lo stesso Id)."""
    ext='png' if fmt=='png' else 'jpeg'
    relname='word/_rels/document.xml.rels'
    rels=ET.fromstring(modified.get(relname) or (z.read(relname) if relname in z.namelist() else ('<Relationships xmlns="%s"/>'%NS_REL).encode()))
    for e in list(rels):
        if e.get('Id')==rid:rels.remove(e)
    ET.SubElement(rels,'{%s}Relationship'%NS_REL,{'Id':rid,'Type':'http://schemas.openxmlformats.org/officeDocument/2006/relationships/image','Target':media})
    ET.register_namespace('',NS_REL);modified[relname]=ET.tostring(rels,encoding='utf-8',xml_declaration=True)
    ct=ET.fromstring(modified.get('[Content_Types].xml') or z.read('[Content_Types].xml'))
    if not any(e.get('Extension','').lower()==ext for e in ct):
        ET.SubElement(ct,'{%s}Default'%NS_CT,{'Extension':ext,'ContentType':'image/'+ext})
    ET.register_namespace('',NS_CT);modified['[Content_Types].xml']=ET.tostring(ct,encoding='utf-8',xml_declaration=True)
    modified['word/'+media]=data

def reserved_slots(root):
    """Segnaposto del timbro presenti nel documento (riconosciuti dal nome o dal testo alternativo,
    che Word conserva quando si salva il documento ritoccato)."""
    out=[]
    for d in root.iter('{%s}docPr'%NS_WP):
        if RESERVED_NAME in (d.get('name',''),d.get('descr','')):out.append(d)
    return out

def place_signature(root,z,modified,image,drop_name=False,reserve=False):
    """Inserisce l'immagine della firma sopra il nome del verificatore. Restituisce True se inserita.
    Con drop_name il nome sotto il riquadro viene tolto (punto 41): lo fa solo a inserimento riuscito.
    Con reserve (anteprima) inserisce invece un segnaposto con lo stesso ingombro del timbro e lascia
    al suo posto il campo header.signature_image, che resta riconoscibile per il caricamento dei ritocchi."""
    fmt,w,h=image_info(image)
    crop=signature_crop(image)   # 0.3.26 (punto 40c): via la cornice vuota attorno al timbro
    extent=signature_extent(w,h,crop)
    for pfx,uri in (('wp',NS_WP),('a',NS_A),('pic',NS_PIC)):ET.register_namespace(pfx,uri)
    parent={c:pp for pp in root.iter() for c in pp}
    def tagged(name):
        return [s for s in root.iter(q('w:sdt')) if (lambda t:t is not None and t.get(q('w:val'))==name)(s.find('w:sdtPr/w:tag',NS))]
    if reserve:rid=RESERVED_RID;media=RESERVED_MEDIA
    else:rid=SIGN_RID;media='media/firma_verificatore.'+('png' if fmt=='png' else 'jpeg')
    # Firma su ogni blocco «Il Verificatore» (verbale e allegati): il verificatore firma tutte le parti.
    slots=tagged('header.signature_image');n=0
    def pic():
        nonlocal n;n+=1
        if reserve:e=signature_run(rid,w,h,RESERVED_NAME,None,extent)
        else:e=signature_run(rid,w,h,'Firma %d'%n,crop,extent)
        for d in e.iter():
            if d.tag in ('{%s}docPr'%NS_WP,'{%s}cNvPr'%NS_PIC):d.set('id',str(9000+n))
        return e
    def centered():
        p=ET.Element(q('w:p'));pp=ET.SubElement(p,q('w:pPr'));ET.SubElement(pp,q('w:jc'),{q('w:val'):'center'});p.append(pic());return p
    if slots:
        for s in slots:
            par=parent[s];i=list(par).index(s)
            if reserve:par.insert(i+1,pic() if par.tag==q('w:p') else centered())   # il campo resta: è il «riquadro firma»
            else:par.remove(s);par.insert(i,pic() if par.tag==q('w:p') else centered())
    else:
        for line in tagged('header.signature_line'):
            p0=line
            while p0 in parent and p0.tag!=q('w:p'):p0=parent[p0]
            if p0.tag!=q('w:p') or p0 not in parent:continue
            cell=parent[p0];cell.insert(list(cell).index(p0),centered())
        if not n:
            # Modelli non associati (es. M01 rev. 00): cella sotto l'intestazione «Il Verificatore», sopra il nome.
            for tbl in root.iter(q('w:tbl')):
                rows=tbl.findall('w:tr',NS)
                for ri,tr in enumerate(rows[:-1]):
                    for ci,tc in enumerate(tr.findall('w:tc',NS)):
                        if re.sub(r'\s+',' ',txt(tc)).strip().casefold()=='il verificatore':
                            below=rows[ri+1].findall('w:tc',NS)
                            if ci<len(below):
                                cell=below[ci];first=cell.find('w:p',NS)
                                cell.insert(list(cell).index(first) if first is not None else len(cell),centered())
        if not n:return False
    # punto 41: firma grafica inserita → via il nome sotto il riquadro. In anteprima il nome si toglie
    # solo se resta comunque un campo firma riconoscibile (header.signature_image).
    if drop_name and (not reserve or slots):drop_signature_names(root)
    _register_media(z,modified,rid,media,placeholder_png(*extent) if reserve else image,'png' if reserve else fmt)
    return True

def swap_reserved_signature(root,z,modified,image):
    """Emissione da anteprima con spazio riservato: dentro ogni segnaposto si mette il timbro, con lo
    stesso ingombro. Nessun paragrafo o riga cambia, quindi l'impaginazione resta quella visionata.
    Restituisce il numero di segnaposto sostituiti (0 = documento senza spazio riservato)."""
    found=reserved_slots(root)
    if not found:return 0
    fmt,w,h=image_info(image);crop=signature_crop(image);cx,cy=signature_extent(w,h,crop)
    parent={c:pp for pp in root.iter() for c in pp};n=0
    for d in found:
        inline=parent.get(d)
        if inline is None or inline.tag!='{%s}inline'%NS_WP:
            raise ValueError('Riquadro firma non valido: rigenerare l’anteprima e conservare i segnaposto.')
        fills=list(inline.iter('{%s}blipFill'%NS_PIC))
        blips=list(fills[0].iter('{%s}blip'%NS_A)) if len(fills)==1 else []
        if len(blips)!=1 or not blips[0].get('{%s}embed'%NS['r']):
            raise ValueError('Immagine del riquadro firma mancante: rigenerare l’anteprima e conservare i segnaposto.')
        n+=1;d.set('name','Firma %d'%n);d.set('descr','Firma %d'%n)
        ext=inline.find('wp:extent',{'wp':NS_WP})
        if ext is not None:ext.set('cx',str(cx));ext.set('cy',str(cy))
        for xfrm_ext in inline.iter('{%s}ext'%NS_A):
            if xfrm_ext.get('cx') is not None:xfrm_ext.set('cx',str(cx));xfrm_ext.set('cy',str(cy))
        for c in inline.iter('{%s}cNvPr'%NS_PIC):c.set('name','Firma %d'%n)
        for fill in fills:
            blip=blips[0]
            for k in list(blip.attrib):
                if k.endswith('}embed') or k.endswith('}link'):del blip.attrib[k]
            blip.set('{%s}embed'%NS['r'],SIGN_RID)
            for e in list(blip):blip.remove(e)            # niente effetti ereditati dal segnaposto
            for e in fill.findall('a:srcRect',{'a':NS_A}):fill.remove(e)
            if crop:
                src=ET.Element('{%s}srcRect'%NS_A,{k:str(round(v*100000)) for k,v in zip('ltrb',crop)})
                fill.insert(list(fill).index(blip)+1,src)
    _register_media(z,modified,SIGN_RID,'media/firma_verificatore.'+('png' if fmt=='png' else 'jpeg'),image,fmt)
    return n

# --- 1.0.0 rc3: riquadro firme in fondo alla pagina ---------------------------------------------
# Il riquadro «Data di emissione / Il Verificatore» viene spinto in fondo alla pagina in cui cade,
# come si faceva a mano con le righe vuote. Il posto libero si misura sul PDF di LibreOffice (lo
# stesso che produce il definitivo): in una prima generazione dopo ogni riquadro c'è un segnalibro
# invisibile «ADFIRMA<n>», che nel PDF dà pagina e quota del fondo del riquadro; il fondo dell'area
# di testo della pagina si misura una volta per modello (pagina sonda, vedi page_bottom). Nella
# generazione definitiva prima di ogni riquadro va un paragrafo vuoto alto quanto lo spazio libero,
# meno un margine di sicurezza. Il paragrafo è «mantieni con il successivo», come il riquadro.
SIGN_AT_BOTTOM=True          # config.json: "firme_in_fondo_pagina": false per disattivare
SIGN_MARK='ADFIRMA'
SIGN_SAFETY=6.0              # punti lasciati liberi sotto il riquadro (differenze di arrotondamento)
PROBE_MARK='ADSONDA'

def signature_tables(root):
    body=root.find('w:body',NS)
    return [t for t in body if t.tag==q('w:tbl') and 'Il Verificatore' in txt(t) and 'emissione' in txt(t).casefold()]

def _tiny_par(text='',before=0,keep=False,outline=False):
    """Paragrafo alto 1 punto (più lo spazio prima), carattere da 1 punto bianco."""
    p=ET.Element(q('w:p'));pr=ET.SubElement(p,q('w:pPr'))
    if keep:ET.SubElement(pr,q('w:keepNext'))
    ET.SubElement(pr,q('w:spacing'),{q('w:before'):str(int(before)),q('w:after'):'0',q('w:line'):'20',q('w:lineRule'):'exact'})
    if outline:ET.SubElement(pr,q('w:outlineLvl'),{q('w:val'):'0'})
    rpr=ET.SubElement(pr,q('w:rPr'));ET.SubElement(rpr,q('w:color'),{q('w:val'):'FFFFFF'});ET.SubElement(rpr,q('w:sz'),{q('w:val'):'2'})
    if text:
        r=ET.SubElement(p,q('w:r'));rp=ET.SubElement(r,q('w:rPr'))
        ET.SubElement(rp,q('w:color'),{q('w:val'):'FFFFFF'});ET.SubElement(rp,q('w:sz'),{q('w:val'):'2'});ET.SubElement(rp,q('w:szCs'),{q('w:val'):'2'})
        t=ET.SubElement(r,q('w:t'));t.text=text
    return p

def single_section(root):
    return root.find('w:body/w:sectPr',NS) is not None and not root.findall('.//w:pPr/w:sectPr',NS)

def add_signature_markers(root):
    """Solo per la generazione di misura: segnalibro invisibile subito sotto ogni riquadro firme."""
    if not single_section(root):return 0
    body=root.find('w:body',NS);tables=signature_tables(root)
    for k,t in enumerate(tables):body.insert(list(body).index(t)+1,_tiny_par(SIGN_MARK+str(k),outline=True))
    return len(tables)

def push_signatures_down(root,spaces):
    """Paragrafo distanziatore (spazio in punti) prima di ciascun riquadro firme."""
    body=root.find('w:body',NS);n=0
    for t,space in zip(signature_tables(root),spaces or []):
        if not space or space<2:continue
        body.insert(list(body).index(t),_tiny_par(before=round((space-1)*20),keep=True));n+=1
    return n

def probe_word(docx):
    """Documento sonda: stesse intestazioni, piè di pagina e margini del verbale, corpo fatto di
    paragrafi alti 1 punto con un segnalibro ciascuno. L'ultimo della prima pagina dà il fondo
    dell'area di testo."""
    z,root=package(docx);body=root.find('w:body',NS);sect=body.find('w:sectPr',NS)
    for c in list(body):body.remove(c)
    for i in range(900):body.append(_tiny_par(PROBE_MARK+str(i),outline=True))
    body.append(sect)
    return write_package(z,{'word/document.xml':serialize(root,z.read('word/document.xml'))})

def page_key(docx):
    """Chiave della geometria della pagina: sezione, intestazioni e piè di pagina."""
    z=ZipFile(io.BytesIO(docx));root=ET.fromstring(z.read('word/document.xml'))
    sect=root.find('w:body/w:sectPr',NS)
    parts=[ET.tostring(sect) if sect is not None else b'']+[z.read(n) for n in sorted(z.namelist()) if re.match(r'word/(header|footer)\d+\.xml$',n)]
    return sha(b'\0'.join(parts))

def signature_spaces(points,bottom):
    """Spazio da aggiungere sopra ciascun riquadro, dai segnalibri ADFIRMA<n> del PDF di misura."""
    marks={t.strip():(pg,y) for t,pg,y in points if t.strip().startswith(SIGN_MARK)}
    out=[]
    for k in range(len(marks)):
        pg,y=marks.get(SIGN_MARK+str(k),(None,None))
        out.append(max(0.0,round(y-bottom-SIGN_SAFETY,1)) if y is not None and bottom is not None else 0.0)
    return out

def drop_trailing_page_breaks(root):
    """1.0.0 rc3: un'interruzione di pagina in fondo al documento (resto dell'ultimo allegato tolto
    perché senza prove) crea una pagina bianca finale, contata anche come pagina dell'allegato.
    Si tolgono i paragrafi finali senza testo né immagini che contengono solo interruzioni."""
    body=root.find('w:body',NS);n=0
    while True:
        kids=[c for c in body if c.tag!=q('w:sectPr')]
        if not kids or kids[-1].tag!=q('w:p'):return n
        p=kids[-1]
        if txt(p).strip() or p.find('.//w:drawing',NS) is not None or p.find('w:pPr/w:sectPr',NS) is not None:return n
        if not any(br.get(q('w:type'))=='page' for br in p.iter(q('w:br'))):return n
        body.remove(p);n+=1

def center_signature_dates(root):
    for table in root.iter(q('w:tbl')):
        rows=table.findall('w:tr',NS)
        for i,row in enumerate(rows[:-1]):
            cells=row.findall('w:tc',NS)
            if len(cells)<2 or not any('Il Verificatore' in txt(c) for c in cells):continue
            if not any('emissione' in txt(c).casefold() for c in cells):continue
            for cell in rows[i+1].findall('w:tc',NS):
                pr=cell.find('w:tcPr',NS)
                if pr is None:pr=ET.Element(q('w:tcPr'));cell.insert(0,pr)
                align=pr.find('w:vAlign',NS)
                if align is None:align=ET.SubElement(pr,q('w:vAlign'))
                align.set(q('w:val'),'center')


def remove_repeated_units(root,values):
    """Rev.01 conserva un suffisso fisso dopo il campo: non duplicare l'unità."""
    parents={child:parent for parent in root.iter() for child in parent}
    for s in root.iter(q('w:sdt')):
        tag=s.find('w:sdtPr/w:tag',NS)
        name=tag.get(q('w:val'),'') if tag is not None else ''
        unit={'plant.power':r'kW|kVA','plant.voltage':r'V|kV'}.get(name)
        if not unit or not re.search(r'\b(?:'+unit+r')\s*$',str(values.get(name,'')),re.I):continue
        parent=parents.get(s)
        if parent is None:continue
        siblings=list(parent);index=siblings.index(s)
        if index+1>=len(siblings):continue
        following=siblings[index+1]
        if following.tag==q('w:r') and re.fullmatch(r'\s*(?:'+unit+r')\s*',txt(following),re.I):
            for t in following.iter(q('w:t')):t.text=''


def add_revision_notice(root,d):
    if not d.get('revision_of'):return
    body=root.find('w:body',NS);reference=d.get('revision_reference',{})
    old=reference.get('number') or d['header'].get('number','')
    rev=int(reference.get('rev_index',max(0,int(d.get('rev_index',1))-1)))
    if rev:old+=' — revisione %02d'%rev
    date=reference.get('issued_date','')
    if re.match(r'^\d{4}-\d{2}-\d{2}$',date):date='/'.join(reversed(date.split('-')))
    notice='Il presente verbale sostituisce il verbale n. '+old+(', emesso il '+date if date else '')+'.'
    p=ET.Element(q('w:p'));pp=ET.SubElement(p,q('w:pPr'));ET.SubElement(pp,q('w:keepNext'))
    p.append(run(notice))
    children=list(body);at=None
    for i,node in enumerate(children):
        if any((lambda t:t is not None and t.get(q('w:val'))=='header.number')(el.find('w:sdtPr/w:tag',NS)) for el in node.iter(q('w:sdt'))):at=i+1;break
    if at is None:
        at=next((i for i,n in enumerate(children) if n.tag==q('w:p') and 'ha proceduto' in txt(n)),len(children)-1)
    body.insert(max(0,at),p)


@serial_operation
def generate_word(template,d,signature=None,reserve=None,measure=False,sign_space=None):
    z,root=package(template);values=field_values(d);missing=[]
    roles={c.get(q('w:val')).split(':')[1] for c in root.findall('.//w:tblPr/w:tblCaption',NS) if c.get(q('w:val'),'').startswith('AD_REPEAT:')}
    for role in ['rcd','overcurrent','continuity','instruments']:
        active=d.get('instruments',[]) if role=='instruments' else [s for s in d.get('samples',[]) if s['kind']==role and s.get('state')!='excluded']
        if active and role not in roles:append_table(root,role,d);missing.append('AD_APPEND:'+role)
    for s in list(root.iter(q('w:sdt'))):
        tag=s.find('w:sdtPr/w:tag',NS)
        if tag is None:continue
        name=tag.get(q('w:val'),'')
        if name=='row.placeholder' or name.startswith('row.'):continue  # filled with the repeated rows below
        if name not in values:missing.append(name);continue
        val=values[name]
        if s.find('w:sdtPr/w14:checkbox',NS) is not None:checked(s,bool(val));continue
        content=s.find('w:sdtContent',NS)
        if content is not None:
            existing_p=content.find('w:p',NS)
            if existing_p is not None:fill_cell(content,'' if val is None else str(val))
            else:
                rpr=s.find('w:sdtPr/w:rPr',NS)
                if rpr is None:rpr=next((r.find('w:rPr',NS) for r in content.iter(q('w:r')) if r.find('w:rPr',NS) is not None),None)
                ph=s.find('w:sdtPr/w:showingPlcHdr',NS)
                if ph is not None:s.find('w:sdtPr',NS).remove(ph)
                for e in list(content):content.remove(e)
                content.append(run('' if val is None else str(val),rpr))
    for p in root.iter(q('w:p')):
        for key in set(re.findall(r'\{\{([a-zA-Z0-9_.]+)\}\}',txt(p))):
            if key=='row.placeholder':continue
            if key not in values:missing.append(key);continue
            val=values[key]
            if key=='plant.client_name' and re.match(r'\s*presso l.Azienda',txt(p),re.I):val=values.get('plant.client_full',val)
            text_replace(p,re.escape('{{'+key+'}}'),str(val) if val is not None else '')
    remove_unused_annexes(root,d)
    drop_undeclared_attachment_lines(root,values)
    drop_empty_optional_lines(root,values,('plant.site_name',))
    page_breaks_before(root)
    drop_trailing_page_breaks(root)
    missing+=['AD_ANNEX:%02d:%s'%(i,r) for i,r in enumerate(mark_annexes(root))]  # ordine degli allegati, per contarne le pagine nel PDF
    split_newlines(root)
    for table in root.iter(q('w:tbl')):
        cap=table.find('w:tblPr/w:tblCaption',NS)
        if cap is None or not cap.get(q('w:val'),'').startswith('AD_REPEAT:'):continue
        _,role,n=cap.get(q('w:val')).split(':');headers=int(n);allrows=table.findall('w:tr',NS)
        prototype=copy.deepcopy(allrows[-1])
        for r in allrows[headers:]:table.remove(r)
        samples=d.get('instruments',[]) if role=='instruments' else [s for s in d.get('samples',[]) if s['kind']==role and s.get('state')!='excluded']
        if role in ('rcd','overcurrent','continuity'):
            # One heading per board: elements of the same board are kept together, in first-seen order.
            first={}
            for s in samples:first.setdefault(re.sub(r'\W+','',(s.get('board') or '').casefold()),len(first))
            samples=sorted(samples,key=lambda s:first[re.sub(r'\W+','',(s.get('board') or '').casefold())])
        board=None;last_ref=['',None]
        for sample in samples:
            if role=='instruments':vals=[sample.get(k,'') for k in ['type','brand','model','serial','calibration']]
            else:
                a=sample.get('attributes',{});r=sample.get('results',{});ne=sample.get('state')=='not_executed'
                if role in ('rcd','overcurrent','continuity') and sample.get('board') and sample['board']!=board:
                    heading=copy.deepcopy(prototype);cells=heading.findall('w:tc',NS);first=cells[0]
                    for c in cells[1:]:heading.remove(c)
                    fill_cell(first,sample['board'],bold=True);pr=first.find('w:tcPr',NS)
                    if pr is None:pr=ET.SubElement(first,q('w:tcPr'))
                    for e in pr.findall('w:shd',NS):pr.remove(e)
                    ET.SubElement(pr,q('w:shd'),{q('w:val'):'clear',q('w:color'):'auto',q('w:fill'):'EEF5F4'})
                    ET.SubElement(pr,q('w:gridSpan'),{q('w:val'):str(len(cells))})
                    table.append(heading);board=sample['board']
                if role=='rcd':vals=[sample.get('name',''),a.get('brand_model',''),a.get('idn_text',''),'n.e.' if ne else r.get('mechanical',''),'n.e.' if ne else r.get('time','')]
                elif role=='overcurrent':vals=[sample.get('name',''),a.get('brand_model',''),a.get('in',''),a.get('ia',''),'n.e.' if ne else r.get('zs',''),'n.e.' if ne else r.get('ig',''),'n.e.' if ne else r.get('coordination','')]
                else:
                    # Riferimento non indicato = uguale alla riga sopra: si stampa «|» (decisione 03/10).
                    ref=(a.get('reference') or '').strip()
                    if not ref and sample.get('board','')==last_ref[0] and last_ref[1]:ref='|'
                    elif ref:last_ref[:]=[sample.get('board',''),ref]
                    vals=[sample.get('name',''),ref,'n.e.' if ne else r.get('outcome','')]
            row=copy.deepcopy(prototype)
            rp=row.find('w:trPr',NS)
            if rp is None:rp=ET.SubElement(row,q('w:trPr'))
            for e in list(rp):
                if e.tag in (q('w:trHeight'),q('w:tblHeader')):rp.remove(e)
            if rp.find('w:cantSplit',NS) is None:ET.SubElement(rp,q('w:cantSplit'))
            for c,v in zip(row.findall('w:tc',NS),vals):fill_cell(c,v)
            table.append(row)
    keep_signature_blocks(root)
    remove_repeated_units(root,values)
    center_signature_dates(root)
    add_revision_notice(root,d)
    modified={}
    # Punto 41: con un solo verificatore il nome sotto il riquadro sparisce (lo dice già il timbro).
    # Con più verificatori resta: la firma grafica è di uno solo e gli altri nomi vanno comunque indicati.
    many_inspectors=bool(re.search(r'\s e \s*|,|\n',d['header'].get('inspectors','') or ''))
    if signature and not place_signature(root,z,modified,signature,drop_name=not many_inspectors):missing.append('AD_SIGNATURE')
    # 1.0.0 rc3: anteprima con lo spazio del timbro già occupato (stesso ingombro del definitivo).
    elif reserve and not signature and not place_signature(root,z,modified,reserve,drop_name=not many_inspectors,reserve=True):missing.append('AD_SIGNATURE')
    # 1.0.0 rc3: riquadro firme in fondo alla pagina (misura, poi distanziatori).
    if measure:add_signature_markers(root)
    elif sign_space:push_signatures_down(root,sign_space)
    modified['word/document.xml']=serialize(root,z.read('word/document.xml'))
    # Tagged fields in headers and footers are supported too.
    for name in z.namelist():
        if re.match(r'word/(header|footer)\d+\.xml',name):
            part=ET.fromstring(z.read(name))
            for p in part.iter(q('w:p')):
                for key in re.findall(r'\{\{([a-zA-Z0-9_.]+)\}\}',txt(p)):
                    if key in values:text_replace(p,re.escape('{{'+key+'}}'),str(values[key] or ''))
            for s in part.iter(q('w:sdt')):
                tag=s.find('w:sdtPr/w:tag',NS)
                if tag is not None and tag.get(q('w:val')) in values:
                    content=s.find('w:sdtContent',NS)
                    if content is not None:
                        for e in list(content):content.remove(e)
                        content.append(run(str(values[tag.get(q('w:val'))] or '')))
            modified[name]=serialize(part,z.read(name))
    return write_package(z,modified),sorted(set(missing))
