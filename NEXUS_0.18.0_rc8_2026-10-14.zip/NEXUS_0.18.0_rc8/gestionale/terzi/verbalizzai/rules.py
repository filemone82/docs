"""Advisory structured adaptation of AD RiesaminAI 0.10.3 / core 0.10.2.
No rule blocks saving or export. This adaptation requires AD validation.
"""
from __future__ import annotations
import datetime as dt, math, re
RULES_VERSION='AD-strutturato 0.3 — R0–R41 (bozza 9 del 25/09/2026) + specifica M01 del 02–03/10/2026 (R42–R54) + calcolo Re × If (R55, 04/10/2026)'
# Campi della maschera a cui si riferisce ciascun controllo («Vai al campo» ed evidenza a colori), se il controllo
# non indica campi più precisi. Chiavi: percorso del campo, gruppo di caselle, «gruppo.voce», «row:<id>:<colonna>».
TARGETS={'R1b':['header.number','header.report_date'],'R2':['check_type'],'R3':['environment'],'R3b':['period'],'R4':['header.due_date'],
  'R6':['igia'],'R7':['earth_method'],'R8':['reidn'],'R9':['ul'],'R10':['at_app'],'R11':['plant.cabins','plant.stations'],'R12':['R12'],
  'R15':['header.issued_date'],'R16':['supply','systems'],'R17':['plant.if_value','plant.tf'],'R18':['protections'],'R19':['earth_types'],
  'R21':['sampling.continuity'],'R22':['sampling.rcd'],'R23':['sampling.overcurrent'],'R24':['instruments'],'R25':['header.hours'],'R27':['template'],
  'R28':['grid-rcd'],'R29':['reidn'],'R30':['rcd_outcome'],'R31':['tn_time'],'R32':['plant.medical_group'],'R33':['at_relation','contact_app'],
  'R35':['utp','plant.tf'],'R56':['notes'],'R36':['grid-overcurrent'],'R37':['protections','igia'],'R38':['diri','dico','plant.installation_year'],'R39':['header.inspectors'],
  'R40':['header.reason'],'R41':['header.representative'],'R42':['plant.installation_year'],'R43':['plant.power'],'R44':['plant.voltage'],'R45':['tests.earth_re'],
  'R46':['plant.cabins','plant.stations'],'R47':['plant.if_value','plant.tf'],'R48':['protections'],'R49':['special'],'R50':['contact_app'],'R51':['special'],
  'R52':['at_relation'],'R53':['contact_app','contact_result'],'R55':['plant.if_value','tests.earth_re','utp','at_relation']}
# Controlli senza un campo da correggere: dove si risolvono.
NO_TARGET={'R26':'Numerazione delle pagine: da controllare sul Word o sul PDF finale.','R34':'Riguarda il tipo di verbale (M01), non un campo della maschera.'}
ORDER=['R27','R0','R1','R1b','R2','R3','R3b']+['R'+str(i) for i in range(4,27)]+['R'+str(i) for i in range(28,42)]+['R'+str(i) for i in range(42,54)]+['R55','R56']
def number(s):
    s=str(s or '').strip().replace(' ','')
    if re.match(r'^\d{1,3}(\.\d{3})+(,\d+)?(?:[^\d]|$)',s):s=s.replace('.','')
    s=s.replace(',','.')
    m=re.search(r'(-?\d+(?:\.\d+)?)(?:[x×*]10(?:\^)?([+-]?\d+|³))?',s)
    if not m:return None
    n=float(m[1]); exp=m[2]
    return n*10**(3 if exp=='³' else int(exp)) if exp else n
def coordination_number(value):
    """Ia/Ig in A: stesso contratto di numCell in app.js (casi comuni nei test JSON).
    Niente estrazione di numeri da testo arbitrario o conversione implicita di mA/kA.
    """
    s=re.sub(r'\s','',str(value if value is not None else ''))
    if len(s)>256:return None
    m=re.fullmatch(r'([+-]?(?:[0-9]+(?:[.,][0-9]+)?|[0-9]{1,3}(?:\.[0-9]{3})+(?:,[0-9]+)?))(?:[x×*]10\^?([+-]?[0-9]+|³))?[Aa]?',s)
    if not m:return None
    base=m[1]
    if re.fullmatch(r'[+-]?[0-9]{1,3}(?:\.[0-9]{3})+(?:,[0-9]+)?',base):base=base.replace('.','')
    try:n=float(base.replace(',','.'))*10.0**(3 if m[2]=='³' else int(m[2] or 0))
    except (ValueError,OverflowError):return None
    return n if math.isfinite(n) else None

def normalize_coordination(data):
    """Solo bozze M01 lavorate: nessuna migrazione e nessuna modifica alle misure."""
    if data.get('module','M01')!='M01' or data.get('historical') or data.get('status') in ('issued','annulled','discarded'):return False
    changed=False
    for s in data.get('samples',[]):
        if s.get('kind')!='overcurrent' or s.get('state') in ('excluded','not_executed'):continue
        r=s.get('results') or {}
        if re.fullmatch(r'n\.?\s*e\.?',str(r.get('coordination','')).strip(),re.I):continue
        ia=coordination_number((s.get('attributes') or {}).get('ia'));ig=coordination_number(r.get('ig'))
        if ia is None or ig is None:continue  # il dato precedente resta; R36 segnala il valore da verificare
        result='SI' if ig>=ia else 'NO'
        if r.get('coordination')!=result:
            s.setdefault('results',{})['coordination']=result;changed=True
    return changed

def date(s):
    try:return dt.datetime.strptime(str(s),'%d/%m/%Y').date()
    except (TypeError,ValueError):return None
def due(s,years):
    d=date(s)
    if not d:return ''
    try:n=d.replace(year=d.year+years)
    except ValueError:n=d.replace(year=d.year+years,day=28)
    return (n-dt.timedelta(days=1)).strftime('%d/%m/%Y')
# Tensione di contatto ammissibile UTp in funzione del tempo di eliminazione del guasto tf
# (CEI EN 50522:2011-07, CEI 99-3): tabella fornita da AD S.r.l. il 03/10/2026, 111 punti da 0,01 s a 10 s; oltre 10 s: 80 V.
UTP_TABLE=[(0.01,790), (0.02,770), (0.03,750), (0.04,732), (0.05,716), (0.06,703), (0.07,690), (0.08,677), (0.09,666), (0.1,654),
  (0.11,643), (0.12,632), (0.13,621), (0.14,610), (0.15,599), (0.16,587), (0.17,574), (0.18,562), (0.19,549), (0.2,537),
  (0.21,522), (0.22,508), (0.23,493), (0.24,479), (0.25,464), (0.26,451), (0.27,437), (0.28,424), (0.29,410), (0.3,397),
  (0.31,386), (0.32,374), (0.33,363), (0.34,351), (0.35,340), (0.36,330), (0.37,321), (0.38,311), (0.39,302), (0.4,292),
  (0.41,284), (0.42,276), (0.43,268), (0.44,260), (0.45,252), (0.46,246), (0.47,239), (0.48,233), (0.49,226), (0.5,220),
  (0.51,215), (0.52,211), (0.53,206), (0.54,202), (0.55,197), (0.56,194), (0.57,190), (0.58,187), (0.59,183), (0.6,180),
  (0.61,177), (0.62,175), (0.63,172), (0.64,170), (0.65,167), (0.66,165), (0.67,163), (0.68,161), (0.69,159), (0.7,157),
  (0.71,155), (0.72,154), (0.73,153), (0.74,150), (0.75,148), (0.76,146), (0.77,144), (0.78,143), (0.79,141), (0.8,139),
  (0.81,138), (0.82,137), (0.83,135), (0.84,134), (0.85,133), (0.86,132), (0.87,131), (0.88,129), (0.89,128), (0.9,127),
  (1,117), (1.1,114), (1.2,111), (1.3,108), (1.4,105), (1.5,102), (1.6,101), (1.7,100), (1.8,98), (1.9,97),
  (2,96), (2.2,95), (2.4,94), (2.6,92), (2.8,91), (3,90), (3.67,89), (4.3,87), (5,86), (7,85),
  (10,85)]
UTP_BEYOND=80
def utp_for(tf):
    """UTp proposta per tf [s]: valore del tempo tabellato uguale o immediatamente superiore (scelta cautelativa:
    fra due punti si prende la tensione più bassa). Oltre 10 s: 80 V."""
    m=re.search(r'\d+(?:[.,]\d+)?',str(tf or ''))   # tempo in secondi: «0,5» e «0.5» valgono 0,5 s
    t=float(m.group(0).replace(',','.')) if m else None
    if t is None or t<=0:return None
    if t>UTP_TABLE[-1][0]:return UTP_BEYOND
    return next(u for x,u in UTP_TABLE if x>=t-1e-9)
def fmt(x):
    """Numero all'italiana per i messaggi: 2 decimali al massimo, virgola decimale."""
    return ('%.2f'%x).rstrip('0').rstrip('.').replace('.',',')
def at_calc(d):
    """Guasti in alta tensione (decisione 04/10/2026): Ucalc = If [A] × Re [Ω] confrontata con Uamm = Utp (CEI EN 50522, da tf).
    Restituisce (If, Re, Uamm, Ucalc, fascia) con fascia 'ok' (Ucalc ≤ Uamm), 'warn' (≤ 2 × Uamm), 'ko' (> 2 × Uamm); None se mancano dati."""
    p=d.get('plant',{});If=number(p.get('if_value'));Re=number((d.get('tests') or {}).get('earth_re'))
    if If is not None and str(p.get('if_unit') or '').strip().lower()=='ka':If*=1000
    Ua=number(d.get('utp','')) or utp_for(p.get('tf'))
    if If is None or Re is None or not Ua:return None
    Uc=If*Re;return If,Re,Ua,Uc,('ok' if Uc<=Ua+1e-9 else 'warn' if Uc<=2*Ua+1e-9 else 'ko')
def filled(s):return bool(re.sub(r'[_/\s.\-]','',str(s or '')))
def evaluate(d,template=None):
    if d.get('module') in ('M02','M03'):
        from .forms import evaluate_form
        return evaluate_form(d,template)
    h=d.get('header',{});p=d.get('plant',{});f=d.get('flags',{});t=d.get('tests',{});sam=d.get('sampling',{})
    rows=d.get('samples',[]);out={}
    def flags(g):return [k for k,v in f.get(g,{}).items() if v]
    def selected(g,k):return k in flags(g)
    def add(code,title,status='OK',detail='Coerente con i dati disponibili.',targets=None):
        out[code]={'code':code,'title':title,'status':status,'detail':detail,'blocking':False,
          'acknowledgement':d.get('acknowledgements',{}).get(code,'')}
        if targets is not None:out[code]['targets']=targets
    def issues(code,title,errors=None,warnings=None,ok='Coerente con i dati disponibili.',targets=None):
        errors=errors or [];warnings=warnings or []
        add(code,title,'Errore' if errors else 'Avviso' if warnings else 'OK','; '.join(errors+warnings) if errors or warnings else ok,targets)
    rid=lambda x:x.get('asset_id') or x.get('tmp_id') or ''
    def cell(x,key,status=None):
        r='row:'+rid(x)+(':'+key if key else '') if rid(x) else 'grid-'+x.get('kind','rcd')
        return [r,status] if status else r
    def one(g,code,title,required=True):
        a=flags(g)
        if len(a)!=1:
            add(code,title,'Errore' if required or a else 'OK','Selezionare una sola voce: '+g if required or a else 'Non richiesto.');return None
        return a[0]
    system=flags('systems');mixed=len(system)>1;s=system[0] if len(system)==1 else None;tt='tt' in system;tn=any(x.startswith('tn') for x in system)
    sup=flags('supply');bt=sup==['lt'];hv=bool(sup) and 'lt' not in sup;vk=bt or hv
    def nov(code,title):add(code,title,'Non verificabile','Alimentazione (< 1.000 V / > 1.000 V) non indicata o non univoca.')
    def must(g,code,title,allowed,label,neg_warn=False):
        if not vk:return nov(code,title)
        a=flags(g)
        if len(a)!=1:return add(code,title,'Errore','Selezionare una sola voce ('+label+').')
        if a[0] not in allowed:return add(code,title,'Errore',('Bassa tensione' if bt else 'Media/alta tensione')+': ammesso '+label+'.')
        if neg_warn and a[0] in ('no','nonconform'):return add(code,title,'Avviso','Risposta NO: confrontare risultato, non conformità ed esito finale.')
        add(code,title)
    rcd=[x for x in rows if x['kind']=='rcd' and x.get('state')!='excluded']
    mt=[x for x in rows if x['kind']=='overcurrent' and x.get('state')!='excluded']
    co=[x for x in rows if x['kind']=='continuity' and x.get('state')!='excluded']
    def unknown(code,title):add(code,title,'Non verificabile','Sistema di distribuzione non univoco.')
    def expected(g,code,title,value,allow_negative=False):
        if not s:return unknown(code,title)
        got=one(g,code,title)
        if got is None:return
        if got==value:add(code,title)
        elif allow_negative and got=='no':add(code,title,'Avviso','Risposta NO: confrontare risultato, non conformità ed esito finale.')
        else:add(code,title,'Avviso',f'Profilo AD: atteso {value}, indicato {got}. Valutare il caso concreto.')
    required=['check_type','systems','supply','protections','earth_types','outcome','igia','earth_method','reidn','at_app','special','contact_app','attachments','rcd_outcome','period']
    errors=[];tg=[]
    for g in required:
        if not flags(g):errors.append(g+': nessuna selezione');tg.append(g)
        elif len(flags(g))>1 and g not in ('systems','protections','earth_types','supply'):errors.append(g+': selezioni multiple');tg.append(g)
    if selected('supply','lt') and len(flags('supply'))>1:errors.append('Alimentazione BT e MT/AT selezionate insieme');tg.append('supply')
    for parent,child in [('at_app','at_relation'),('contact_app','contact_result')]:
        if selected(parent,'no') and flags(child):errors.append(child+': compilato ma dichiarato non applicabile');tg+=[child,parent]
    if selected('reidn','na') and flags('ul'):errors.append('Ul compilata con relazione Re × Idn non applicabile');tg+=['ul','reidn.na']
    if selected('special','no') and not bt:
        for g in ('pe5','medical2','it_first'):
            if any(k!='na' for k in flags(g)):errors.append(g+': risultato con prescrizioni non applicabili');tg.append(g)
    issues('R0','Compilazione dei blocchi a scelta',errors,targets=tg)
    headers=d.get('source_meta',{}).get('headers',[])
    err=[];tg=[]
    # 0.3.34: tre cifre (VP/001/26) e, oltre il 999, quattro (VP/1000/26).
    if not re.fullmatch(r'[A-Z]{2}/\d{3,4}/\d{2}/?',h.get('number','')):err.append('Numero assente o diverso dal formato XX/nnn/aa (XX/nnnn/aa oltre il 999)');tg.append('header.number')
    if not date(h.get('report_date')):err.append('Data verbale mancante o non valida');tg.append('header.report_date')
    pf=h.get('number','')[:2];ct=flags('check_type')
    if (pf=='VP' and ct==['extra']) or (pf=='VS' and ct==['periodic']):err.append('Prefisso '+pf+' non coerente con il tipo di verifica (VP periodica, VS straordinaria)');tg+=['header.number','check_type']
    if any(x['number'].rstrip('/')!=h.get('number','').rstrip('/') or x['date']!=h.get('report_date') for x in headers):err.append('Intestazioni diverse nel Word originale');tg.append('header.number')
    issues('R1','Numero e data del verbale',err,targets=tg)
    yy=re.search(r'/(\d{2})/?$',h.get('number',''));rd=date(h.get('report_date'))
    add('R1b','Anno nel numero verbale','Non verificabile' if not yy or not rd else 'Errore' if int(yy[1])!=rd.year%100 else 'OK',
      'Confrontare anno del numero e data del verbale.' if not yy or not rd or int(yy[1])!=rd.year%100 else 'Anno coerente.')
    if one('check_type','R2','Tipo di verifica'):add('R2','Tipo di verifica')
    env=flags('environment');issues('R3','Ambiente',['Classificazione mancante'] if not env else ['Ordinario selezionato insieme ad altri ambienti'] if 'ordinary' in env and len(env)>1 else [])
    per=flags('period');ey=5 if env==['ordinary'] else 2 if env else None
    issues('R3b','Periodicità',['Selezionare una periodicità'] if len(per)!=1 else [],
      ['Periodicità diversa dal profilo AD per l’ambiente indicato'] if ey and len(per)==1 and per[0]!=('five' if ey==5 else 'two') else [],
      targets=['period','environment'] if ey and len(per)==1 and per[0]!=('five' if ey==5 else 'two') else ['period'])
    yrs=2 if per==['two'] else 5 if per==['five'] else None
    base=h.get('start_date') or h.get('report_date');exp=due(base,yrs) if yrs else '';sc=date(h.get('due_date'))
    # 0.3.26 (punto 54): con esito negativo il controllo si rovescia. Non esiste una prossima
    # scadenza — il D.P.R. 462/01 prevede una verifica straordinaria — quindi il campo deve restare
    # vuoto e una data compilata è un errore. La periodicità (R3b) invece resta richiesta: dipende
    # dall'impianto, non da come è andata la verifica.
    neg=(f.get('outcome') or {}).get('negative') and not (f.get('outcome') or {}).get('positive')
    if neg:
        add('R4','Prossima verifica','Errore' if h.get('due_date') else 'OK',
          'Esito negativo: la scadenza non va indicata, togliere la data.' if h.get('due_date') else
          'Esito negativo: nessuna scadenza, nel verbale viene stampato «*».')
    elif not sc:add('R4','Prossima verifica','Errore','Scadenza assente o data non valida.')
    elif not exp:add('R4','Prossima verifica','Non verificabile','Manca la data di inizio o la periodicità.')
    else:add('R4','Prossima verifica','Errore' if sc>date(exp) else 'Avviso' if sc<date(exp) else 'OK','Calcolo del profilo AD da inizio verifica: '+exp)
    # R56 (0.3.26, punto 54): con esito negativo l'asterisco della prossima verifica rimanda alle
    # osservazioni, dove il verificatore scrive la motivazione. Qui si controlla solo che la riga
    # con l'asterisco ci sia: il testo è suo e il programma non lo propone.
    note=str(d.get('notes') or '')
    if not neg:add('R56','Motivazione dell’esito negativo','Non applicabile','Serve solo con esito negativo.')
    elif re.search(r'(?m)^\s*\*',note):add('R56','Motivazione dell’esito negativo','OK','Motivazione presente nelle osservazioni.')
    else:add('R56','Motivazione dell’esito negativo','Avviso','Con esito negativo le osservazioni devono contenere una riga che inizia con «*», richiamata dall’asterisco della prossima verifica.')
    err=[];tg=[]
    for g in ('dico','project','diri'):
        a=flags(g);n0=len(err)
        if ('present' in a)==('absent' in a):err.append(g+': presenza non univoca')
        if 'present' in a and len([x for x in a if x in ('total','partial')])!=1:err.append(g+': estensione totale/parziale non univoca')
        if 'absent' in a and ('total' in a or 'partial' in a):err.append(g+': estensione compilata con documento assente')
        if len(err)>n0:tg.append(g)
    issues('R5','Documentazione',err,targets=tg)
    if mixed and bt and flags('igia') in (['yes'],['no']):
        add('R6','Ig > Ia','Avviso','Sistemi misti in bassa tensione: verificare che Ig ≥ Ia sia riferita alla parte TN pertinente.',['systems','igia'])
    else:must('igia','R6','Ig > Ia',['na'] if bt else ['yes','no'],'«non applicabile»' if bt else 'SI o NO (non «non applicabile»)',True)
    glob=selected('at_relation','global')
    if not vk:nov('R7','Metodo di misura Re')
    elif glob:add('R7','Metodo di misura Re',detail='Impianto di terra globale: Rearth non si misura.')
    elif s and (tn or s=='it') and selected('earth_method','loop'):add('R7','Metodo di misura Re','Errore','Sistema '+s.upper().replace('_','-')+': Rearth non si misura con il loop test (anello di guasto); usare il metodo voltamperometrico.',['earth_method.loop','systems.'+s])
    elif mixed and selected('earth_method','loop'):add('R7','Metodo di misura Re','Avviso','Sistemi multipli: verificare a quale parte dell’impianto si riferisce il metodo di misura Re.',['earth_method.loop','systems'])
    elif bt and not flags('earth_method'):add('R7','Metodo di misura Re','Errore','Metodo di misura non indicato.')
    elif bt and selected('earth_method','voltamp'):add('R7','Metodo di misura Re','Avviso','Bassa tensione: metodo voltamperometrico ammesso ma insolito (di norma anello di guasto). Verificare.',['earth_method.voltamp'])
    elif hv and not (flags('earth_method')==['voltamp']):add('R7','Metodo di misura Re','Errore','Media/alta tensione: Rearth misurata solo con metodo voltamperometrico.')
    else:add('R7','Metodo di misura Re')
    must('reidn','R8','Re × Idn ≤ Ul',['yes','no'] if bt else ['na'],'SI o NO (non «non applicabile»)' if bt else '«non applicabile»',True)
    if selected('reidn','na'):issues('R9','Valore Ul',warnings=['Ul compilata ma relazione non applicabile'] if flags('ul') else [])
    else:
        u=flags('ul');issues('R9','Valore Ul',['Ul non univoca'] if len(u)!=1 else [],
          ['Profilo AD: valutare Ul 25 V per l’ambiente indicato'] if selected('environment','medical') and u==['v50'] else [])
    must('at_app','R10','Guasti in alta tensione',['no'] if bt else ['yes'],'«non applicabile»' if bt else '«applicabile»')
    if not vk:nov('R11','Cabine MT / stazioni AT')
    elif bt:add('R11','Cabine MT / stazioni AT',detail='Non richiesto in bassa tensione (vedi R46).')
    else:
        issues('R11','Cabine MT / stazioni AT',['Indicare il numero di cabine MT o di stazioni AT (almeno uno)'] if not ((number(p.get('cabins')) or 0)>0 or (number(p.get('stations')) or 0)>0) else [])
    # Allegati delle prove (differenziali, magnetotermiche, continuità): dichiarazione e pagine calcolate alla generazione del Word.
    probs=[];att=d.get('attachments',{}).get('contact') or {}
    if att.get('declared') and not (number(att.get('pages')) or 0)>0:probs.append('misure di tensione di contatto e passo: pagine non indicate')
    add('R12','Allegati e pagine','Errore' if probs else 'OK','; '.join(probs) if probs else 'Allegati delle prove e numero di pagine compilati in automatico alla generazione del Word.')
    negflags=[g for g in ('igia','reidn','rcd_outcome','tn_time','pe5','medical2','it_first','contact_result') if any(k in ('no','negative','nonconform') for k in flags(g))]
    badrows=[x for x in rows if x.get('state')!='excluded' and any(re.fullmatch(r'NO|KO|NEGATIVO|NON CONFORME',str(v).strip(),re.I) for v in x.get('results',{}).values())]
    nc=d.get('nonconformities','').strip();hasnc=filled(nc) and not re.match(r'^nessuna\b',nc,re.I)
    errors=[];outcome=flags('outcome');tg=['outcome']
    if outcome==['positive'] and (negflags or badrows or hasnc):
        errors.append('Esito positivo con risultati negativi o non conformità descritte: valutarne la coerenza')
        tg+=[g+'.'+k for g in negflags for k in flags(g) if k in ('no','negative','nonconform')]+(['nonconformities'] if hasnc else [])
        tg+=[cell(x,k) for x in badrows for k,v in x.get('results',{}).items() if re.fullmatch(r'NO|KO|NEGATIVO|NON CONFORME',str(v).strip(),re.I)]
    if outcome==['negative'] and not hasnc:errors.append('Esito negativo senza descrizione delle non conformità');tg.append('nonconformities')
    if len(outcome)!=1:errors.append('Esito non univoco')
    issues('R13','Congruenza con l’esito',errors,ok='Esito e registrazioni coerenti; un esito negativo documentato è ammesso.',targets=tg)
    start=date(h.get('start_date'));end=date(h.get('end_date'))
    issues('R14','Date di esecuzione',['Date inizio/fine mancanti o non valide'] if not start or not end else ['Fine precedente all’inizio'] if end<start else ['Fine diversa dalla data del verbale'] if end!=rd else [],
      targets=['header.end_date','header.report_date'] if start and end and end>=start else ['header.start_date','header.end_date'])
    emissions=d.get('source_meta',{}).get('emission_dates',[]) or [h.get('issued_date')]
    issues('R15','Data di emissione',['Emissione mancante o date diverse fra i blocchi'] if any(not date(x) for x in emissions) or len(set(emissions))>1 else [],
      ['Emissione precedente alla fine della verifica'] if end and date(h.get('issued_date')) and date(h['issued_date'])<end else [])
    if not vk or not system:add('R16','Alimentazione e sistema','Non verificabile','Alimentazione o sistema non indicati o non univoci.')
    elif mixed:add('R16','Alimentazione e sistema','Avviso','Più sistemi di distribuzione presenti: verificare nelle osservazioni quali parti dell’impianto e quali prove riguardano ciascun sistema. Non è una non conformità automatica.',['systems','supply'])
    elif bt and not tt:add('R16','Alimentazione e sistema','Errore','Bassa tensione: atteso sistema TT, indicato '+s.upper()+'.',['supply','systems.'+s])
    elif hv and tt:add('R16','Alimentazione e sistema','Errore','Media/alta tensione: atteso sistema TN o IT, indicato TT.',['supply','systems.tt'])
    else:add('R16','Alimentazione e sistema')
    if not vk:nov('R17','Corrente di guasto e tempo')
    elif hv:issues('R17','Corrente di guasto e tempo',['Corrente di guasto MT o tempo di intervento mancanti'] if number(p.get('if_value')) is None or number(p.get('tf')) is None else [])
    else:add('R17','Corrente di guasto e tempo',detail='Non richiesto in bassa tensione (vedi R47).')
    issues('R18','Dispositivi di protezione',['Dispositivi non indicati'] if not flags('protections') else ['TT senza differenziali dichiarati'] if tt and not mixed and not selected('protections','rcd') else [],
      ['TT presente con più sistemi: verificare le protezioni pertinenti a ciascuna parte'] if tt and mixed and not selected('protections','rcd') else [],
      targets=['protections','systems.tt'] if tt and flags('protections') and not selected('protections','rcd') else ['protections'])
    issues('R19','Dispersore',['Tipi di dispersore non indicati'] if not flags('earth_types') else [])
    # Decisione 04/10/2026: avviso (non errore); accanto a ciascun gruppo compare solo la parte che lo riguarda.
    notes=d.get('notes','');warn=[];tg=[]
    for g,pat,name in [('dico',r'dichiarazione di conformit|di\.?\s*co','Dichiarazione di conformità'),('project',r'progett','Progetto')]:
        if selected(g,'present') and not re.search(pat,notes,re.I):
            m=name+' presente ma non citata nelle osservazioni attuali';warn.append(m);tg.append([g+'.present','Avviso',m])
    issues('R20','Documentazione citata nelle note',warnings=warn,targets=[['notes','Avviso']]+tg if warn else ['notes'])
    for code,kind,title in [('R21','continuity','Campionamento continuità'),('R22','rcd','Campionamento differenziali'),('R23','overcurrent','Campionamento magnetotermiche')]:
        needed=kind!='overcurrent' or hv
        issues(code,title,['Criterio o motivazione non indicati'] if needed and not filled(sam.get(kind)) else [])
    instr=d.get('instruments',[])
    ref=date(h.get('start_date')) or date(h.get('report_date'))
    expired=[(x.get('type') or '?')+' '+(x.get('serial') or '')+': taratura scaduta il '+x['calibration_due'] for x in instr if ref and date(x.get('calibration_due')) and date(x['calibration_due'])<ref]
    issues('R24','Strumentazione',(['Nessuno strumento indicato'] if not instr else ['Righe strumenti incomplete'] if any(not all(filled(x.get(k)) for k in ('type','brand','model','serial','calibration')) for x in instr) else [])+expired,
      ['Il controllo verifica la compilazione; idoneità e validità metrologica richiedono valutazione del verificatore'] if instr else [])
    issues('R25','Ore uomo',['Durata mancante o non positiva'] if not (number(h.get('hours')) or 0)>0 else [])
    add('R26','Numerazione pagine','Non verificabile','Numerazione da verificare sul Word/PDF finale.')
    if d.get('historical'):
        ref=d.get('source_meta',{}).get('template_reference','');known='M01-PO01_dpr, rev. 00 del 29.09.2025' in ref
        add('R27','Modello e struttura','OK' if known else 'Avviso','M01 AD riconosciuto.' if known else 'Modello storico da verificare; importazione conservata.')
    elif not template:add('R27','Modello e struttura','Avviso','Nessun template selezionato. Si può salvare; per produrre il Word occorre caricare un modello.')
    else:add('R27','Modello e struttura','Avviso','Template '+template.get('name','')+' associato. Verificare l’output della prima emissione su questa revisione.')
    err=[];warn=[];tg=[];rpos=flags('rcd_outcome')==['positive']
    for x in rcd:
        state=x.get('state');res=x.get('results',{});a=x.get('attributes',{});name=x.get('name','?')
        if not x.get('board'):warn.append(name+': quadro non identificato');tg.append(cell(x,'name','Avviso'))
        if not a.get('brand_model') or number(a.get('idn_text')) is None:
            err.append(name+': marca/modello o Idn mancanti');tg+=[cell(x,k) for k in ('brand_model','idn_text') if not filled(a.get(k))] or [cell(x,'idn_text')]
        if state in ('selected','tested'):
            if not filled(res.get('mechanical')) or number(res.get('time')) is None:err.append(name+': prove incomplete');tg+=[cell(x,k) for k in ('mechanical','time') if not filled(res.get(k))] or [cell(x,'time')]
            if str(res.get('time','')).lstrip().startswith('>'):warn.append(name+': tempo fuori scala');tg.append(cell(x,'time','Avviso'))
            else:
                ms=number(res.get('time'))
                # Prova a Idn: 300 ms per i differenziali generali, fino a 500 ms per i selettivi (tipo S).
                if ms is not None and ms>500:
                    (err if rpos else warn).append(name+': '+f'{ms:g}'+' ms oltre 500 ms'+(' con esito delle prove positivo' if rpos else ''));tg.append(cell(x,'time','Errore' if rpos else 'Avviso'))
                elif ms is not None and ms>300:warn.append(name+': '+f'{ms:g}'+' ms oltre 300 ms (ammesso solo per differenziali selettivi, fino a 500 ms)');tg.append(cell(x,'time','Avviso'))
    issues('R28','Prove differenziali e allegato',err[:8],warn[:8],ok=str(len(rcd))+' dispositivi attivi; righe compilate.',targets=tg)
    rearth=number(t.get('earth_re'));idns=[number(x.get('attributes',{}).get('idn_text')) for x in rcd]
    idns=[x for x in idns if x is not None];uls=flags('ul');ul=50 if uls==['v50'] else 25 if uls==['v25'] else None
    if not bt:add('R29','Calcolo Re × Idn ≤ Ul',detail='Non richiesto: si applica alla bassa tensione.')
    elif mixed:add('R29','Calcolo Re × Idn ≤ Ul','Avviso','Sistemi misti: il valore unico di Re, Ul e gli Idn elencati non consentono un confronto automatico riferito alla sola parte TT. Verificare le misure pertinenti.',['systems','reidn','tests.earth_re'])
    elif rearth is None or not idns or not ul:add('R29','Calcolo Re × Idn ≤ Ul','Non verificabile','Mancano Re, Ul o Idn leggibili.')
    else:
        product=rearth*max(idns);holds=product<=ul
        mismatch=(selected('reidn','yes') and not holds) or (selected('reidn','no') and holds)
        add('R29','Calcolo Re × Idn ≤ Ul','Errore' if mismatch else 'Avviso',
          f'{rearth:g} Ω × {max(idns):g} A = {product:g} V; Ul = {ul} V. Calcolo sui dispositivi elencati, senza attestare copertura completa dell’impianto.',
          ['reidn','tests.earth_re'] if mismatch else ['reidn'])
    go=flags('rcd_outcome')
    if len(go)!=1:add('R30','Esito prove differenziali','Errore','Esito delle prove non univoco.')
    elif go==['negative']:add('R30','Esito prove differenziali','Avviso','Prove negative: verificare descrizione delle non conformità ed esito complessivo. Non è un errore di compilazione automatico.')
    else:add('R30','Esito prove differenziali')
    if mixed and tn:add('R31','Tempo intervento interruttori (sistemi TN)','Avviso','Sistemi multipli con TN: verificare che la voce sia riferita alla parte TN e che le prove pertinenti siano documentate.',['systems','tn_time'])
    elif bt:issues('R31','Tempo intervento interruttori (sistemi TN)',['Bassa tensione: la voce non va selezionata'] if flags('tn_time') else [])
    elif tn:expected('tn_time','R31','Tempo intervento interruttori (sistemi TN)','conform',True)
    else:issues('R31','Tempo intervento interruttori (sistemi TN)',['Voce TN compilata per altro sistema'] if flags('tn_time') else [])
    issues('R32','Locale medico',warnings=['Locale medico: indicare gruppo e valutare prescrizioni pertinenti'] if selected('environment','medical') and not p.get('medical_group') else [])
    tcp=selected('at_app','yes') and selected('at_relation','no')
    issues('R33','Guasti AT e tensioni di contatto',['Relazione Re × If ≤ Utp non soddisfatta: servono le misure delle tensioni di contatto e di passo («applicabile»)'] if tcp and not selected('contact_app','yes') else [],
      ['Misure delle tensioni di contatto e di passo: allegato non dichiarato'] if tcp and selected('contact_app','yes') and not ((d.get('attachments') or {}).get('contact') or {}).get('declared') else [],
      targets=['contact_app'] if tcp and not selected('contact_app','yes') else ['R12'] if tcp else ['at_relation','contact_app'])
    add('R34','Oggetto della verifica',detail='Prototipo dedicato al verbale M01 di messa a terra; LPS/ATEX richiedono altri modelli e regole.')
    # Il calcolo Re × If non viene effettuato (implicito nella dichiarazione SI / NO): si controlla solo il limite adottato.
    if selected('at_app','yes') and not selected('at_relation','global'):
        exp=utp_for(p.get('tf'));u=number(d.get('utp',''))
        if u is None:issues('R35','Limite Utp adottato',warnings=['Limite Utp non indicato'+(' (CEI EN 50522 per tf = '+str(p.get('tf'))+' s: '+str(exp)+' V)' if exp else ' e tempo di intervento tf mancante')])
        elif exp and u>exp+0.5:issues('R35','Limite Utp adottato',warnings=['Utp '+str(d.get('utp'))+' V superiore al valore della tabella CEI EN 50522 per tf = '+str(p.get('tf'))+' s ('+str(exp)+' V): verificare'])
        else:add('R35','Limite Utp adottato',detail='Limite Utp '+str(d.get('utp',''))+' V'+(' coerente con tf = '+str(p.get('tf'))+' s (CEI EN 50522).' if exp else '.'))
    else:add('R35','Limite Utp adottato',detail='Non richiesto nella configurazione indicata.')
    if selected('at_app','yes') and not selected('at_relation','global') and not bt:
        c=at_calc(d);rel=flags('at_relation')
        if not c:add('R55','Calcolo Re × If ≤ Utp','Non verificabile','Per il calcolo servono corrente di guasto [A], resistenza di terra Re e limite Utp (o tempo di intervento tf).',
          [k for k,v in (('plant.if_value',number(p.get('if_value'))),('tests.earth_re',number(t.get('earth_re')))) if v is None] or ['utp'])
        else:
            If,Re,Ua,Uc,band=c;txt='Ucalc = '+fmt(If)+' A × '+fmt(Re)+' Ω = '+fmt(Uc)+' V; Uamm = Utp = '+fmt(Ua)+' V'
            if band=='ok':add('R55','Calcolo Re × If ≤ Utp','Avviso' if rel==['no'] else 'OK',txt+' → relazione soddisfatta'+(', ma nel verbale è indicato NO: verificare.' if rel==['no'] else '.'),['at_relation.no'] if rel==['no'] else ['at_relation'])
            elif band=='warn':add('R55','Calcolo Re × If ≤ Utp','Avviso',txt+' → oltre Uamm ma entro 2 × Uamm: valutare. Se la relazione non è soddisfatta servono le misure delle tensioni di contatto e di passo.',['at_relation'])
            else:add('R55','Calcolo Re × If ≤ Utp','Errore' if rel==['yes'] else 'OK',txt+' → oltre 2 × Uamm: relazione non soddisfatta'+(', ma nel verbale è indicato SI.' if rel==['yes'] else '; servono le misure delle tensioni di contatto e di passo (l’esito del verbale non diventa negativo per questo).'),['at_relation.yes'] if rel==['yes'] else ['at_relation'])
    else:add('R55','Calcolo Re × If ≤ Utp',detail='Non richiesto nella configurazione indicata.')
    err=[];warn=[];tg=[]
    # 0.3.34 (Federico, 09/10): niente confronto Ig con 230 V / Zs. Uo è quella misurata (es. 127 V verso terra
    # nei sistemi a 230 V trifase): Zs e Ig si scrivono a mano dallo strumento e un Uo fisso darebbe avvisi falsi.
    for x in mt:
        a=x.get('attributes',{});r=x.get('results',{});n=x.get('name','?')
        if x.get('state')=='not_executed':
            continue
        zs=number(r.get('zs'));ia=coordination_number(a.get('ia'));ig=coordination_number(r.get('ig'))
        miss=[k for k,v in (('Zs',zs is not None and zs>0),('Ia',ia is not None),('Ig',ig is not None),('Ig > Ia',filled(r.get('coordination')))) if not v]
        if miss:
            err.append('«'+n+'»'+(' ('+x.get('board')+')' if x.get('board') else '')+': manca '+', '.join(miss))
            tg+=[cell(x,k) for k,lab in (('zs','Zs'),('ia','Ia'),('ig','Ig'),('coordination','Ig > Ia')) if lab in miss];continue
        # 0.3.34: Ig > Ia nel verbale = condizione Zs × Ia ≤ Uo (CEI 64-8), cioè Ig ≥ Ia: con Ig = Ia è soddisfatta.
        # Il valore è calcolato dal programma; «n.e.» (prova non eseguita) non si confronta.
        coord=str(r.get('coordination','')).strip()
        if not re.match(r'n\.?\s*e\.?$',coord,re.I):
            yes=re.match(r'SI|SÌ|OK',coord,re.I)
            if bool(yes)!=(ig>=ia):err.append(n+': Ig > Ia non coerente con Ig e Ia');tg.append(cell(x,'coordination','Errore'))
    issues('R36','Prove magnetotermiche (tabella Magnetotermiche)',err[:8],warn[:8],targets=tg)
    issues('R37','Protezioni contro le sovracorrenti',warnings=['Ig > Ia indicato SI senza protezioni contro le sovracorrenti: verificare motivazione'] if hv and selected('igia','yes') and not selected('protections','overcurrent') and not re.search(r'non eseguit|differenzial',sam.get('overcurrent',''),re.I) else [])
    year=number(p.get('installation_year'));warn=[]
    if year and year>=2008 and selected('diri','present'):warn.append('Di.Ri. presente su impianto indicato dal 2008: verificare epoca effettiva e ambito')
    if year and year>1990 and selected('diri','absent') and selected('dico','absent'):warn.append('Impianto post 1990 senza Di.Co./Di.Ri.: valutare documentazione')
    issues('R38','Documentazione e anno installazione',warnings=warn)
    add('R39','Nomi nei blocchi firma','Non verificabile' if not filled(h.get('inspectors')) else 'Avviso',
      'Verificatore non indicato.' if not filled(h.get('inspectors')) else 'Il nome viene ripetuto dal template; presenza e validità delle firme restano da verificare sul documento emesso.')
    issues('R42','Anno di installazione',['Anno di installazione non indicato (ammesso «n.a.»)'] if not filled(p.get('installation_year')) else [])
    # R43 — 0.3.25 (punto 46): dalla rev. 02 il modello non stampa più il «kW» fisso, l'unità sta nel valore.
    # Senza unità il verbale uscirebbe con il solo numero: avviso, non blocco.
    pw=str(p.get('power') or '').strip()
    issues('R43','Potenzialità',['Potenzialità non indicata'] if not filled(p.get('power')) else [],
      warnings=['Potenzialità senza unità di misura: indicarla nel valore (es. «30 kW» o «250 kVA»). '
                'Dalla revisione 02 dei modelli l\'unità non è più stampata dal modello.']
        if filled(p.get('power')) and re.search(r'\d',pw) and not re.search(r'\b(kW|kVA|MW|MVA|VA|W)\s*$',pw,re.I) and not re.fullmatch(r'\d+(?:[.,]\d+)?',pw) else [])
    issues('R44','Tensione di esercizio',['Tensione di esercizio non indicata'] if not filled(p.get('voltage')) else [])
    if glob:issues('R45','Rearth',warnings=['Impianto di terra globale: Rearth non si misura, valore indicato '+str(t.get('earth_re'))] if rearth is not None else [],ok='Impianto di terra globale: Rearth non richiesta.')
    else:issues('R45','Rearth',['Rearth mancante o non numerica'] if rearth is None else [])
    if not vk:
        for c,tl in [('R46','BT: cabine e stazioni'),('R47','BT: corrente di guasto MT'),('R48','BT: dispositivi contro le sovracorrenti'),('R49','BT: prescrizioni particolari'),('R50','BT: tensioni di contatto'),('R51','MT: prescrizioni particolari'),('R52','MT: giudizio guasti in alta tensione'),('R53','MT: tensioni di contatto')]:nov(c,tl)
    elif bt:
        issues('R46','BT: cabine e stazioni',['Numero di cabine o stazioni compilato in bassa tensione'] if (number(p.get('cabins')) or 0)>0 or (number(p.get('stations')) or 0)>0 else [])
        issues('R47','BT: corrente di guasto MT',['Corrente di guasto MT o tempo di intervento compilati in bassa tensione'] if filled(p.get('if_value')) or filled(p.get('tf')) else [])
        e=['«Sovracorrenti» selezionato fra i dispositivi di protezione'] if selected('protections','overcurrent') else []
        if d.get('attachments',{}).get('overcurrent',{}).get('declared'):e.append('Allegato magnetotermiche dichiarato')
        issues('R48','BT: dispositivi contro le sovracorrenti',[] if mixed else e,
          ['Sistemi misti: verificare che sovracorrenti e relativo allegato riguardino la parte pertinente'] if mixed and e else [],
          targets=(['protections.overcurrent','supply.lt'] if selected('protections','overcurrent') else [])+(['grid-overcurrent'] if d.get('attachments',{}).get('overcurrent',{}).get('declared') else []))
        e=[] if flags('special')==['no'] else ['Prescrizioni particolari: ammesso solo «non applicabili»']
        e+=[g+': colonna destra selezionata' for g in ('pe5','medical2','it_first') if flags(g)]
        issues('R49','BT: prescrizioni particolari',[] if mixed else e,
          ['Sistemi misti: verificare che prescrizioni e risultati indicati riguardino la parte pertinente'] if mixed and e else [])
        issues('R50','BT: tensioni di contatto',['Tensioni di contatto: ammesso solo «non applicabile»'] if flags('contact_app')!=['no'] else [])
        for c,tl in [('R51','MT: prescrizioni particolari'),('R52','MT: giudizio guasti in alta tensione'),('R53','MT: tensioni di contatto')]:add(c,tl,detail='Non applicabile in bassa tensione.')
    else:
        for c,tl in [('R46','BT: cabine e stazioni'),('R47','BT: corrente di guasto MT'),('R48','BT: dispositivi contro le sovracorrenti'),('R49','BT: prescrizioni particolari'),('R50','BT: tensioni di contatto')]:add(c,tl,detail='Non applicabile in media/alta tensione.')
        e=[] if len(flags('special'))==1 else ['Scegliere «applicabili» o «non applicabili»']
        if selected('special','yes'):e+=[g+': scegliere conforme, non conforme o non applicabile' for g in ('pe5','medical2','it_first') if len(flags(g))!=1]
        issues('R51','MT: prescrizioni particolari',e)
        issues('R52','MT: giudizio guasti in alta tensione',['Giudizio Re × If ≤ Utp (SI / NO / terra globale) non compilato'] if selected('at_app','yes') and len(flags('at_relation'))!=1 else [])
        e=[] if len(flags('contact_app'))==1 else ['Scegliere «applicabile» o «non applicabile»']
        if selected('contact_app','yes') and len(flags('contact_result'))!=1:e.append('Esito delle tensioni di contatto non compilato')
        issues('R53','MT: tensioni di contatto',e)
    issues('R40','Motivo verifica straordinaria',['Motivo della straordinaria non indicato'] if selected('check_type','extra') and not filled(h.get('reason')) else [])
    issues('R41','Rappresentante datore di lavoro',['Nome e qualifica del rappresentante mancanti'] if not filled(h.get('representative')) else [])
    result=[out[k] for k in ORDER]
    # Controllo interno (verifica intermedia) scaduto alla data di inizio verifica: solo avviso, nessun blocco.
    ic=[(x.get('type') or '?')+' '+(x.get('serial') or '')+': controllo interno scaduto il '+x['internal_check_due'] for x in instr if ref and date(x.get('internal_check_due')) and date(x['internal_check_due'])<ref]
    if ic and not d.get('historical'):result.append({'code':'R24b','title':'Controllo interno degli strumenti','status':'Avviso','detail':'; '.join(ic),'blocking':False,'acknowledgement':d.get('acknowledgements',{}).get('R24b',''),'targets':['instruments']})
    for r in result:
        if 'targets' not in r:r['targets']=list(TARGETS.get(r['code'],[]))
    # Avvisi solo informativi (sempre presenti): nel pannello e nella finestra di emissione, ma senza colorare i campi.
    if template and not d.get('historical'):out['R27']['info']=True
    if filled(h.get('inspectors')):out['R39']['info']=True
    if out['R24']['status']=='Avviso':out['R24']['info']=True   # solo il richiamo alla valutazione metrologica
    if out['R29']['status']=='Avviso' and not mixed:out['R29']['info']=True   # calcolo coerente con la risposta: solo promemoria
    if not d.get('historical') and not d.get('confirmed'):
        result.append({'code':'D01','title':'Dati riproposti dallo storico','status':'Avviso','detail':'Caratteristiche e documentazione dell’impianto da confermare per la verifica attuale.','blocking':False,'acknowledgement':d.get('acknowledgements',{}).get('D01',''),'targets':['confirm']})
    car={k:v for k,v in (d.get('carried') or {}).items() if str(v)==str((d.get('tests') or {}).get(k.split('.',1)[1],''))}
    if not d.get('historical') and car:
        names={'tests.earth_re':'resistenza di terra','tests.at_calculation':'calcolo Re × If','tests.continuity_description':'prove di continuità','tests.contact_description':'tensioni di contatto'}
        result.append({'code':'D03','title':'Misure riproposte dall’ultima verifica','status':'Avviso','detail':'Valori non ancora modificati né confermati: '+', '.join(names.get(k,k) for k in car)+'. Inserire la misura attuale o confermare che è invariata.','blocking':False,'acknowledgement':d.get('acknowledgements',{}).get('D03',''),'targets':list(car)})
    if d.get('import_conflicts'):result.append({'code':'D02','title':'Differenze fra verbali importati','status':'Avviso','detail':str(len(d['import_conflicts']))+' elementi con caratteristiche diverse; versioni conservate nello storico.','blocking':False,'acknowledgement':'','targets':['grid-rcd']})
    return result
