"""Transactional archive for one server process, users, and verified recovery packages.

The SQLite file must be opened only by the process running on the machine that stores it
(never from several PCs through a shared folder). Clients use the browser.
"""
from __future__ import annotations
import copy, datetime as dt, hashlib, hmac, io, json, os, re, secrets, sqlite3, threading, time, uuid
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from .wordio import norm, sha, empty_draft
from . import plantstate

APP_VERSION='1.0.1'
FORMAT_VERSION=2
AUTO_BACKUP_INTERVAL=300          # seconds between routine data backups
AUTO_KEEP_RECENT=50               # most recent routine backups kept
AUTO_KEEP_DAYS=90                 # plus the first backup of each day for this many days
PBKDF2_ROUNDS=600_000
SAVE_SNAPSHOT_EVERY=600         # seconds: full previous version of a draft kept in the change log at most this often
ROLES=('admin','rt','tecnico','segreteria')
ROLE_LABELS={'admin':'Amministratore','rt':'Responsabile tecnico','tecnico':'Tecnico','segreteria':'Segreteria'}
# Permessi configurabili dall'amministratore (superuser). «users» resta solo dell'amministratore.
PERMISSIONS=[('import','Importare verbali storici'),('draft','Creare e compilare verifiche (bozze), generare Word e PDF'),
  ('issue','Emettere verbali'),('send','Inviare i verbali emessi al cliente via email'),('revision','Creare revisioni di verbali emessi'),('draft_delete','Eliminare bozze'),
  ('plant','Creare e correggere gli impianti'),('plant_technical','Confermare e correggere lo stato tecnico degli impianti'),('templates','Caricare template Word'),
  ('instruments_view','Vedere il registro strumenti'),('instruments','Gestire il registro strumenti (comprende vederlo)'),
  ('signatures_view','Vedere le firme dei verificatori'),('signatures','Caricare le firme di altri utenti (comprende vederle)'),
  ('annul','Annullare verbali emessi e storici (con motivazione)'),('oplog','Consultare il registro delle operazioni'),('backup','Backup, ripristino e rilettura dei verbali storici'),('users','Utenti e permessi, impostazioni email')]
DEFAULT_PERMISSIONS={'admin':[k for k,_ in PERMISSIONS],
  'rt':['import','draft','issue','send','revision','draft_delete','plant','plant_technical','templates','instruments_view','instruments','signatures_view','signatures'],
  'tecnico':['import','draft','issue','send','draft_delete','plant','plant_technical'],
  'segreteria':['import','draft','plant','instruments_view','instruments']}
# 0.3.24: permessi aggiunti dopo la 0.3.23. Nelle tabelle dei permessi salvate prima ricevono il valore iniziale del ruolo.
PERMISSIONS_0323={'import','draft','issue','revision','draft_delete','plant','templates','instruments','signatures','annul','oplog','backup','users'}
IMPLIED={'instruments_view':'instruments','signatures_view':'signatures'}   # «gestire» comprende «vedere»
TITLES=re.compile(r'^(?:(?:dott|dr|ing|per|ind|p|i|geom|arch|avv|sig\.ra|sig|prof|rag)(?:\.\s*|\s+))+',re.I)
def plain_name(s):
    """Nome senza titoli («Dott. Ing. Federico Amateis» → «Federico Amateis»), per abbinare assegnatari e verificatori."""
    s=re.sub(r'\s+',' ',str(s or '')).strip()
    return TITLES.sub('',s).strip() or s
def now():return dt.datetime.now(dt.timezone.utc).isoformat(timespec='microseconds')
def uid():return uuid.uuid4().hex
def jdump(x):return json.dumps(x,ensure_ascii=False,separators=(',',':'))
def iso_date(s):
    try:return dt.datetime.strptime(s,'%d/%m/%Y').date().isoformat()
    except (ValueError,TypeError):return ''
def pw_hash(password,salt):return hashlib.pbkdf2_hmac('sha256',password.encode('utf-8'),bytes.fromhex(salt),PBKDF2_ROUNDS).hex()
class Conflict(ValueError):pass
# 0.3.29: impianto nuovo identico a uno esistente. Non blocca: chiede conferma (due cabine allo stesso indirizzo esistono).
class Duplicate(ValueError):pass

class Archive:
    def __init__(self,directory,backup_dir=None):
        self.directory=Path(directory).resolve();self.directory.mkdir(parents=True,exist_ok=True)
        self.backups=Path(backup_dir).resolve() if backup_dir else self.directory/'backups';self.backups.mkdir(parents=True,exist_ok=True)
        # Immutable, content-addressed copies of every Word (originals, templates, generated).
        self.docstore=self.backups/'documenti';self.docstore.mkdir(exist_ok=True)
        self.path=self.directory/'archivio.sqlite';self.lock=threading.RLock();self.backup_error=''
        self._local=threading.local();self._last_backup=time.monotonic()   # 0.3.23: la prima copia periodica 5 minuti dopo l'avvio
        self._initialize();self._sync_docstore();self._migrate_plant_state()
    # --- who is acting (set per request thread by the web server) -------------------------
    def set_actor(self,username):self._local.user=username or ''
    @property
    def actor(self):return getattr(self._local,'user','')
    def connect(self):
        c=sqlite3.connect(self.path,timeout=30,isolation_level=None)
        c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON');c.execute('PRAGMA synchronous=FULL')
        return c
    def _initialize(self):
        c=self.connect()
        try:
            ok=c.execute('PRAGMA integrity_check').fetchone()[0]
            if ok!='ok':raise ValueError('Archivio danneggiato. Ripristinare una copia con --restore FILE.adbackup.zip.')
            c.execute('PRAGMA journal_mode=WAL')
            c.executescript('''CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS objects(id TEXT PRIMARY KEY,kind TEXT NOT NULL,data TEXT NOT NULL,revision INTEGER NOT NULL,updated_at TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS documents(sha TEXT PRIMARY KEY,filename TEXT NOT NULL,data BLOB NOT NULL,created_at TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY,object_id TEXT NOT NULL,action TEXT NOT NULL,previous TEXT,created_at TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS users(username TEXT PRIMARY KEY,name TEXT NOT NULL,role TEXT NOT NULL,salt TEXT NOT NULL,hash TEXT NOT NULL,active INTEGER NOT NULL,created_at TEXT NOT NULL);
              CREATE INDEX IF NOT EXISTS object_kind ON objects(kind);
              CREATE INDEX IF NOT EXISTS ev_obj ON events(object_id,created_at);''')
            # 0.1/0.2 archives: add authorship columns without touching existing rows.
            c.execute("UPDATE users SET role='tecnico' WHERE role='ispettore'")  # 0.3: «ispettore» diventa «tecnico»
            if 'user' not in [r[1] for r in c.execute('PRAGMA table_info(events)')]:c.execute("ALTER TABLE events ADD COLUMN user TEXT NOT NULL DEFAULT ''")
            if 'updated_by' not in [r[1] for r in c.execute('PRAGMA table_info(objects)')]:c.execute("ALTER TABLE objects ADD COLUMN updated_by TEXT NOT NULL DEFAULT ''")
            v=c.execute("SELECT value FROM meta WHERE key='format_version'").fetchone()
            if v and int(v[0]) not in (1,FORMAT_VERSION):raise ValueError('Versione archivio non supportata: conservare il file e usare una versione compatibile.')
            # 0.3.23: indici per l'importazione degli storici (elementi dell'impianto, doppioni); facoltativi se SQLite non ha JSON1
            try:
                c.execute("CREATE INDEX IF NOT EXISTS obj_plant ON objects(kind,json_extract(data,'$.plant_id'))")
                c.execute("CREATE INDEX IF NOT EXISTS obj_source ON objects(kind,json_extract(data,'$.source_sha'))")
                c.execute("CREATE INDEX IF NOT EXISTS obj_insp ON objects(kind,json_extract(data,'$.inspection_id'))")
            except sqlite3.OperationalError:pass
            c.execute("INSERT OR IGNORE INTO meta VALUES('format_version',?)",(str(FORMAT_VERSION),))
            c.execute("INSERT OR IGNORE INTO meta VALUES('archive_id',?)",(uid(),))
        finally:c.close()
    def _migrate_plant_state(self):
        """Migrazione unica e atomica: originali e verifiche restano intatti."""
        with self.connect() as c:
            if int(c.execute("SELECT value FROM meta WHERE key='format_version'").fetchone()[0]) == FORMAT_VERSION:return
        target=self.backups/('prima_schema2_'+dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.adbackup.zip')
        self.export_backup(target,include_documents=True)
        self.verify_backup(target)
        def op(c):
            if int(c.execute("SELECT value FROM meta WHERE key='format_version'").fetchone()[0]) == FORMAT_VERSION:return
            for row in c.execute("SELECT * FROM objects WHERE kind='asset'").fetchall():
                asset=self._obj(row);iid=asset['data'].get('provenance',{}).get('inspection')
                source=c.execute("SELECT data FROM objects WHERE id=? AND kind='inspection'",(iid,)).fetchone() if iid else None
                if source and json.loads(source['data']).get('status') in ('draft','discarded'):
                    ad=dict(asset['data'],active=False)
                    if json.loads(source['data']).get('status')=='draft':ad['pending_inspection']=iid
                    self._put(c,'asset',ad,asset['id'],asset['revision'],action='plant_state_provisional')
            for row in c.execute("SELECT * FROM objects WHERE kind='plant'").fetchall():
                plant=self._obj(row)
                if plant['data'].get('deleted'):continue
                histories=[self._obj(r) for r in self._json_rows(c,'inspection','plant_id',plant['id'])
                           if json.loads(r['data']).get('status')!='annulled' and
                           (json.loads(r['data']).get('historical') or json.loads(r['data']).get('status')=='issued')]
                pd=copy.deepcopy(plant['data']);pd['profiles']={}
                for module in ('M01','M02','M03'):
                    eligible=[x for x in histories if self.module_of(x['data'])==module]
                    if not eligible:continue
                    latest=max(eligible,key=lambda x:(self._state_date(x['data']),x['updated_at'],x['id']))
                    if module=='M01':
                        known={}
                        for historical in sorted(eligible,key=lambda x:(self._state_date(x['data']),x['updated_at'],x['id'])):
                            for sample in historical['data'].get('samples',[]):
                                if sample.get('asset_id'):known[sample['asset_id']]=copy.deepcopy(sample)
                        latest=copy.deepcopy(latest);latest['data']['samples']=list(known.values())
                    self._set_profile(c,plant['id'],pd,latest,False,'migration')
                self._put(c,'plant',pd,plant['id'],plant['revision'],action='plant_state_migration')
            c.execute("UPDATE meta SET value=? WHERE key='format_version'",(str(FORMAT_VERSION),))
            c.execute("INSERT OR REPLACE INTO meta VALUES('plant_state_migration_backup',?)",(str(target),))
        self.mutate(op)
    @staticmethod
    def _state_date(d):
        return iso_date(d.get('header',{}).get('end_date') or d.get('header',{}).get('report_date') or '')
    def _set_profile(self,c,pid,pd,source,confirmed,origin):
        module=self.module_of(source['data']);old=pd.get('profiles',{}).get(module,{})
        state=plantstate.extract(source['data'])
        if module=='M01':
            known={} if origin in ('rollback','adopted') else {s['asset_id']:copy.deepcopy(s) for s in old.get('state',{}).get('samples',[])}
            known.update({s['asset_id']:s for s in state['samples'] if s.get('asset_id')})
            for sample in source['data'].get('samples',[]):
                if sample.get('retired'):known.pop(sample.get('asset_id'),None)
            state['samples']=list(known.values())
        profile={'revision':old.get('revision',0)+1,'state':state,'source_id':source['id'],
                 'observed_date':self._state_date(source['data']),'confirmed':bool(confirmed),
                 'updated_at':now(),'updated_by':self.actor,'origin':origin}
        pd.setdefault('profiles',{})[module]=profile
        if module=='M01':
            retired={s.get('asset_id') for s in source['data'].get('samples',[]) if s.get('retired')}
            definitions={s['asset_id']:s for s in state['samples'] if s.get('asset_id')}
            for row in self._json_rows(c,'asset','plant_id',pid):
                asset=self._obj(row);ad=copy.deepcopy(asset['data']);s=definitions.get(asset['id'])
                if s:
                    ad.update({k:copy.deepcopy(s[k]) for k in ('kind','board','name','occurrence','attributes')})
                    ad['active']=True;ad['retired']=False;ad.pop('pending_inspection',None)
                elif ad.get('pending_inspection') and ad['pending_inspection']!=source['id']:
                    continue
                else:
                    ad['active']=False
                    if asset['id'] in retired:ad['retired']=True
                if ad!=asset['data']:self._put(c,'asset',ad,asset['id'],asset['revision'],action='plant_state_asset')
        return profile
    def plant_state(self,pid,module='M01'):
        plant=self.get(pid)
        if plant['kind']!='plant' or plant['data'].get('deleted'):raise ValueError('Impianto non trovato.')
        plantstate.module_of({'module':module})
        candidates=[x for x in self.where('inspection','plant_id',pid)
                    if self.module_of(x['data'])==module and x['data'].get('status')!='annulled'
                    and (x['data'].get('historical') or x['data'].get('status')=='issued')]
        return {'plant':plant,'profile':plant['data'].get('profiles',{}).get(module),'schema':plantstate.schema(module),
                'stamp':plantstate.stamp(plant['data'],module),
                'candidates':[{'id':x['id'],'number':x['data']['header'].get('number',''),
                               'date':x['data']['header'].get('end_date') or x['data']['header'].get('report_date','')}
                              for x in sorted(candidates,key=lambda x:(self._state_date(x['data']),x['updated_at']),reverse=True)]}
    def _candidate_snapshot(self,pid,pd,source,rollback=False):
        """Un campione storico non è l'intero censimento: conserva gli altri elementi."""
        source=copy.deepcopy(source);d=source['data'];module=self.module_of(d)
        if module!='M01':return source
        old=pd.get('profiles',{}).get(module,{})
        known={} if rollback else {s['asset_id']:copy.deepcopy(s) for s in old.get('state',{}).get('samples',[])}
        explicit={s.get('asset_id') for s in d.get('samples',[]) if not s.get('retired')}
        retired=set() if rollback else {a['id'] for a in self.where('asset','plant_id',pid) if a['data'].get('retired') and a['id'] not in explicit}
        dismissed={}
        eligible=[x for x in self.where('inspection','plant_id',pid) if self.module_of(x['data'])==module
                  and x['data'].get('status')!='annulled' and (x['data'].get('historical') or x['data'].get('status')=='issued')
                  and self._state_date(x['data'])<=self._state_date(d)]
        for historical in sorted(eligible,key=lambda x:(self._state_date(x['data']),x['updated_at'],x['id'])):
            for sample in historical['data'].get('samples',[]):
                aid=sample.get('asset_id')
                if not aid or aid in retired:continue
                if rollback or aid not in known or self._state_date(historical['data'])>old.get('observed_date',''):
                    if sample.get('retired'):known.pop(aid,None);dismissed[aid]=copy.deepcopy(sample)
                    else:known[aid]=copy.deepcopy(sample);dismissed.pop(aid,None)
        for sample in d.get('samples',[]):
            aid=sample.get('asset_id')
            if sample.get('retired'):known.pop(aid,None);dismissed[aid]=copy.deepcopy(sample)
            elif aid:known[aid]=copy.deepcopy(sample);dismissed.pop(aid,None)
        source['data']['samples']=list(known.values())+list(dismissed.values())
        return source
    def preview_plant_state(self,pid,iid):
        plant=self.get(pid);source=self.get(iid);d=source['data'];module=self.module_of(d)
        if plant['kind']!='plant' or plant['data'].get('deleted') or source['kind']!='inspection' or d.get('plant_id')!=pid or d.get('status')=='annulled' or not (d.get('historical') or d.get('status')=='issued'):
            raise ValueError('Scegliere uno storico valido dello stesso impianto.')
        profile=plant['data'].get('profiles',{}).get(module,{})
        rollback=bool(profile.get('review_required') and profile.get('source_id') and self.get(profile['source_id'])['data'].get('status')=='annulled')
        state=plantstate.extract(self._candidate_snapshot(pid,plant['data'],source,rollback)['data'])
        return {'state':state,'proposal_hash':sha(jdump(state).encode()),'stamp':plantstate.stamp(plant['data'],module)}
    def adopt_plant_state(self,pid,iid,expected_stamp,confirmed=False,expected_proposal_hash=None):
        if confirmed is not True:raise ValueError('Confermare lo stato dell’impianto prima di adottarlo.')
        def op(c):
            row=c.execute("SELECT * FROM objects WHERE id=? AND kind='plant'",(pid,)).fetchone()
            if not row or json.loads(row['data']).get('deleted'):raise ValueError('Impianto non trovato.')
            plant=self._obj(row);source=self.get(iid);d=source['data'];module=self.module_of(d)
            if source['kind']!='inspection' or d.get('plant_id')!=pid or d.get('status')=='annulled' or not (d.get('historical') or d.get('status')=='issued'):
                raise ValueError('Scegliere un verbale storico o emesso dello stesso impianto.')
            old=plant['data'].get('profiles',{}).get(module,{})
            rollback=bool(old.get('review_required') and old.get('source_id') and self.get(old['source_id'])['data'].get('status')=='annulled')
            self._check_state(plant['data'],module,expected_stamp,self._state_date(d),allow_rollback=rollback)
            source=self._candidate_snapshot(pid,plant['data'],source,rollback)
            if expected_proposal_hash is not None and expected_proposal_hash!=sha(jdump(plantstate.extract(source['data'])).encode()):
                raise Conflict('Gli storici sono cambiati durante il confronto: aggiornare la proposta prima di adottarla.')
            pd=copy.deepcopy(plant['data']);self._set_profile(c,pid,pd,source,True,'rollback' if rollback else 'adopted')
            self._put(c,'plant',pd,pid,plant['revision'],action='plant_state_adopt')
        self.mutate(op,True);return self.plant_state(pid,self.module_of(self.get(iid)['data']))
    def _check_state(self,pd,module,expected_stamp,observed_date,d=None,allow_rollback=False):
        if expected_stamp!=plantstate.stamp(pd,module):
            raise Conflict('Lo stato dell’impianto è cambiato oppure la bozza è precedente alla migrazione. Confrontare lo stato impianto prima di aggiornarlo, oppure emettere senza aggiornarlo.')
        if not observed_date:raise ValueError('Per aggiornare l’impianto serve una data di fine verifica o del verbale valida.')
        old=pd.get('profiles',{}).get(module,{})
        if not allow_rollback and old.get('observed_date','')>observed_date:
            raise ValueError('Questa verifica è precedente allo stato dell’impianto. Emettere senza aggiornare la scheda impianto.')
        if d and d.get('revision_of'):
            raise ValueError('Una revisione corregge una fotografia storica. Emetterla senza aggiornare la scheda impianto.')
    def save_plant_state(self,pid,module,state,observed_date,expected_stamp,confirmed=False):
        if confirmed is not True:raise ValueError('Confermare i dati tecnici e la data di riferimento.')
        plantstate.module_of({'module':module})
        if not isinstance(state,dict) or any(not isinstance(state.get(k),dict) for k in ('plant','flags','tests')):
            raise ValueError('Dati tecnici non validi.')
        spec=plantstate.schema(module)
        for part,fields in (('plant',spec['plant_fields']),('tests',spec['test_fields'])):
            if any(k not in fields or not isinstance(v,str) or len(v)>20000 for k,v in state[part].items()):raise ValueError('Campo tecnico non valido.')
        for key,values in state['flags'].items():
            if key not in spec['groups'] or not isinstance(values,dict) or any(k not in spec['groups'][key]['options'] or not isinstance(v,bool) for k,v in values.items()):
                raise ValueError('Scelte tecniche non valide.')
        def op(c):
            plant=self.get(pid);pd=copy.deepcopy(plant['data'])
            if plant['kind']!='plant' or pd.get('deleted'):raise ValueError('Impianto non trovato.')
            self._check_state(pd,module,expected_stamp,iso_date(observed_date))
            old=pd.get('profiles',{}).get(module,{})
            if not old and module=='M01':
                if not state['plant'].get('power','').strip():raise ValueError('Inserire la potenza dell’impianto, con la sua unità.')
                if not any(state['flags'].get('supply',{}).values()):raise ValueError('Selezionare il tipo di alimentazione.')
            samples=copy.deepcopy(old.get('state',{}).get('samples',[]))
            proposed=state.get('samples',samples)
            if not isinstance(proposed,list) or [s.get('asset_id') for s in proposed]!=[s.get('asset_id') for s in samples]:
                raise ValueError('Gli elementi si aggiungono o dismettono attraverso una verifica.')
            for current,incoming in zip(samples,proposed):
                attrs=incoming.get('attributes')
                if not isinstance(attrs,dict) or set(attrs)!=set(current['attributes']) or any(not isinstance(v,str) for v in attrs.values()):raise ValueError('Caratteristiche elemento non valide.')
                current['attributes']=copy.deepcopy(attrs)
            data={'module':module,'plant':state['plant'],'flags':state['flags'],'tests':state['tests'],
                  'samples':samples,'header':{'report_date':observed_date}}
            self._set_profile(c,pid,pd,{'id':None,'data':data},True,'manual_correction')
            self._put(c,'plant',pd,pid,plant['revision'],action='plant_state_corrected')
        self.mutate(op,True);return self.plant_state(pid,module)
    def acknowledge_plant_state(self,oid,revision,expected_stamp,confirmed=False):
        """Confronto esplicito: conserva le correzioni della bozza, aggiorna il riferimento."""
        if confirmed is not True:raise ValueError('Confermare di aver confrontato i dati dell’impianto.')
        def op(c):
            current=self.get(oid);d=copy.deepcopy(current['data'])
            if current['kind']!='inspection' or self.locked(d):raise ValueError('Solo una bozza può essere riallineata.')
            pd=self.get(d['plant_id'])['data'];module=self.module_of(d)
            if expected_stamp!=plantstate.stamp(pd,module):raise Conflict('Lo stato è cambiato durante il confronto: ricaricare.')
            d['plant_state_base']=expected_stamp
            return self._put(c,'inspection',d,oid,revision,action='plant_state_compared')
        self.mutate(op);return self.get(oid)
    def _store_file(self,digest,data):
        if sha(data)!=digest:raise ValueError('Documento non integro: copia non scritta.')
        target=self.docstore/(digest+'.bin')
        if target.exists() and sha(target.read_bytes())==digest:return
        tmp=target.with_name(target.name+'.'+uuid.uuid4().hex+'.tmp')
        try:
            with open(tmp,'xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
            os.replace(tmp,target)
        finally:
            if tmp.exists():tmp.unlink()
    def _sync_docstore(self):
        c=self.connect()
        try:
            for (digest,) in c.execute('SELECT sha FROM documents').fetchall():
                if not (self.docstore/(digest+'.bin')).exists():
                    self._store_file(digest,bytes(c.execute('SELECT data FROM documents WHERE sha=?',(digest,)).fetchone()[0]))
        finally:c.close()
    # --- objects -------------------------------------------------------------------------
    def all(self,kind=None):
        with self.lock:
            c=self.connect()
            try:
                rows=c.execute('SELECT * FROM objects'+(' WHERE kind=?' if kind else ''),(kind,) if kind else ()).fetchall()
                return [self._obj(r) for r in rows]
            finally:c.close()
    def _obj(self,r):return {'id':r['id'],'kind':r['kind'],'data':json.loads(r['data']),'revision':r['revision'],'updated_at':r['updated_at'],'updated_by':r['updated_by']}
    def get(self,oid):
        with self.lock:
            c=self.connect()
            try:
                r=c.execute('SELECT * FROM objects WHERE id=?',(oid,)).fetchone()
                if not r:raise ValueError('Elemento non trovato.')
                return self._obj(r)
            finally:c.close()
    def document(self,digest):
        with self.lock:
            c=self.connect()
            try:
                r=c.execute('SELECT filename,data FROM documents WHERE sha=?',(digest,)).fetchone()
                if not r:raise ValueError('Word non trovato.')
                return r['filename'],bytes(r['data'])
            finally:c.close()
    def _put(self,c,kind,data,oid=None,revision=None,action='save'):
        # 0.3.29.1: il destinatario va ricontrollato nella transazione di scrittura.
        # Un'altra richiesta puo' aver eliminato l'impianto dopo la lettura iniziale.
        if kind in ('inspection','asset'):
            parent=c.execute("SELECT data FROM objects WHERE id=? AND kind='plant'",(data.get('plant_id'),)).fetchone()
            if not parent or json.loads(parent['data']).get('deleted'):
                raise ValueError('Impianto non trovato o eliminato: ricaricare l’archivio.')
            if kind=='asset' and data.get('pending_inspection'):
                draft=c.execute("SELECT data FROM objects WHERE id=? AND kind='inspection'",(data['pending_inspection'],)).fetchone()
                if not draft or self.locked(json.loads(draft['data'])) or json.loads(draft['data']).get('plant_id')!=data['plant_id']:
                    raise ValueError('La bozza dell’elemento non è più aperta.')
        oid=oid or uid();old=c.execute('SELECT * FROM objects WHERE id=?',(oid,)).fetchone()
        if old and revision is not None and old['revision']!=revision:raise Conflict('Il documento è stato modificato da un altro utente o in un’altra finestra. Ricaricare prima di salvare.')
        rev=old['revision']+1 if old else 1;previous=old['data'] if old else None
        if previous is not None and action=='save':
            # Salvataggi automatici della bozza: chi e quando sempre; il contenuto precedente al massimo una volta ogni 10 minuti
            # (0.3.23: prima ogni salvataggio copiava l'intera bozza, ~17 kB, e il registro cresceva di gigabyte).
            last=c.execute('SELECT created_at FROM events WHERE object_id=? AND previous IS NOT NULL ORDER BY created_at DESC LIMIT 1',(oid,)).fetchone()
            if last and (dt.datetime.now(dt.timezone.utc)-dt.datetime.fromisoformat(last[0])).total_seconds()<SAVE_SNAPSHOT_EVERY:previous=None
        c.execute('INSERT INTO events(id,object_id,action,previous,created_at,user) VALUES(?,?,?,?,?,?)',(uid(),oid,action,previous,now(),self.actor))
        c.execute('INSERT OR REPLACE INTO objects(id,kind,data,revision,updated_at,updated_by) VALUES(?,?,?,?,?,?)',(oid,kind,jdump(data),rev,now(),self.actor))
        return oid
    def mutate(self,callback,force_backup=False):
        with self.lock:
            c=self.connect()
            try:
                c.execute('BEGIN IMMEDIATE');result=callback(c);c.execute('COMMIT')
            except BaseException:
                if c.in_transaction:c.execute('ROLLBACK')
                raise
            finally:c.close()
        # Routine saves are backed up at most every AUTO_BACKUP_INTERVAL; imports,
        # emissions, template and user changes immediately. The database itself is durable.
        # 0.3.23: the copy is written outside the archive lock (consistent SQLite snapshot), so nobody waits for it.
        if force_backup:
            try:self.auto_backup()
            except Exception as e:self.backup_error=str(e)
        elif time.monotonic()-self._last_backup>=AUTO_BACKUP_INTERVAL:
            # copia periodica in sottofondo: il salvataggio della bozza risponde subito
            self._last_backup=time.monotonic();threading.Thread(target=self._background_backup,daemon=True).start()
        return result
    def _background_backup(self):
        try:self.auto_backup()
        except Exception as e:self.backup_error=str(e)
    def add_document(self,c,data,filename):
        digest=sha(data)
        self._store_file(digest,data)
        c.execute('INSERT OR IGNORE INTO documents VALUES(?,?,?,?)',(digest,Path(filename).name,data,now()))
        return digest
    def import_word(self,data,filename,parsed,plant_id=None):
        digest=sha(data)
        def op(c):
            # 0.3.23: ricerche mirate (doppione e elementi dell'impianto) invece di rileggere tutto l'archivio a ogni Word
            for r in self._json_rows(c,'inspection','source_sha',digest):
                d=json.loads(r['data'])
                if d.get('historical') and d.get('source_sha')==digest and d.get('status')!='annulled':return {'inspection_id':r['id'],'plant_id':d['plant_id'],'duplicate':True,'conflicts':[],'same_number':None}
            self.add_document(c,data,filename)
            # 0.3.25 (punto 32): stesso impianto, stesso numero e stessa data ma file diverso.
            # Non è il doppione esatto intercettato sopra (quello ha lo stesso SHA): è un Word
            # differente che dichiara lo stesso verbale, cioè una rilavorazione o un file sbagliato.
            # Si archivia comunque, ma l'esito lo segnala.
            same_number=None
            num=(parsed.get('header') or {}).get('number') or ''
            day=(parsed.get('header') or {}).get('report_date') or ''
            if plant_id and num and day:
                for r in self._json_rows(c,'inspection','plant_id',plant_id):
                    o=json.loads(r['data'])
                    if o.get('status')=='annulled':continue
                    if (o.get('header') or {}).get('number')==num and (o.get('header') or {}).get('report_date')==day \
                       and o.get('source_sha')!=digest:
                        same_number={'inspection_id':r['id'],'number':num,'date':day,
                          'filename':(o.get('source_meta') or {}).get('filename') or '','historical':bool(o.get('historical'))}
                        break
            if plant_id:
                rr=c.execute("SELECT * FROM objects WHERE id=? AND kind='plant'",(plant_id,)).fetchone()
                if not rr:raise ValueError('Impianto destinatario non trovato.')
                plant=json.loads(rr['data'])
            else:
                plant={'client_name':parsed['plant']['client_name'],'site_name':parsed['plant'].get('site_name',''),'address':parsed['plant']['address'],
                  'label':parsed['plant']['address'] or 'Impianto da identificare'}
            pid=plant_id or self._put(c,'plant',plant,action='import')
            existing={}
            for r in self._json_rows(c,'asset','plant_id',pid):
                a=json.loads(r['data'])
                if a['plant_id']==pid:existing[self.asset_key(a)]=(r['id'],a)
            imported=copy.deepcopy(parsed);conflicts=[]
            for sample in imported['samples']:
                key=self.asset_key(sample)
                if key in existing:
                    aid,a=existing[key]
                    if a['attributes']!=sample['attributes']:
                        conflicts.append({'asset_id':aid,'name':a['name'],'board':a['board'],
                          'existing':a['attributes'],'incoming':sample['attributes']})
                else:
                    a={k:copy.deepcopy(sample[k]) for k in ['kind','board','name','occurrence','attributes']}
                    a.update({'plant_id':pid,'provenance':{'sha':digest,'source':sample['source']},'active':not bool(plant.get('profiles',{}).get('M01'))})
                    aid=self._put(c,'asset',a,action='import');existing[key]=(aid,a)
                sample['asset_id']=aid
            imported.update({'plant_id':pid,'source_sha':digest,'historical':True,'imported_at':now(),'import_conflicts':conflicts,'status':'historical'})
            iid=self._put(c,'inspection',imported,action='import')
            module=self.module_of(imported)
            current_profile=plant.get('profiles',{}).get(module)
            incoming=plantstate.extract(imported);differences=[]
            if current_profile:
                for part in ('plant','flags','tests'):
                    for key,value in incoming[part].items():
                        if current_profile['state'].get(part,{}).get(key)!=value:differences.append(part+'.'+key)
                if incoming['samples']!=current_profile['state'].get('samples',[]):differences.append('samples')
            if not plant.get('profiles',{}).get(module):
                pd=copy.deepcopy(plant)
                self._set_profile(c,pid,pd,{'id':iid,'data':imported},False,'import_proposal')
                self._put(c,'plant',pd,pid,action='plant_state_proposal')
            return {'inspection_id':iid,'plant_id':pid,'duplicate':False,'conflicts':conflicts,'same_number':same_number,
                    'state_proposal':{'module':module,'differences':differences,'requires_review':bool(differences),
                                      'date':self._state_date(imported),'initial':not bool(current_profile)}}
        # Copia automatica al massimo ogni 5 minuti durante un lotto; a fine lotto la fa finish_import().
        return self.mutate(op)
    def finish_import(self):
        """Copia automatica dopo un lotto di importazioni (chiamata dal browser al termine)."""
        try:self.auto_backup();return {'backup':True}
        except Exception as e:self.backup_error=str(e);return {'backup':False,'error':str(e)}
    _json1=None
    def _json_rows(self,c,kind,field,value):
        """Oggetti di un tipo con data.<field> = value; usa json_extract di SQLite se disponibile, altrimenti filtra in Python."""
        if Archive._json1 is not False:
            try:
                rows=c.execute("SELECT * FROM objects WHERE kind=? AND json_extract(data,'$."+field+"')=?",(kind,value)).fetchall()
                Archive._json1=True;return rows
            except sqlite3.OperationalError:Archive._json1=False
        return [r for r in c.execute('SELECT * FROM objects WHERE kind=?',(kind,)) if json.loads(r['data']).get(field)==value]
    @staticmethod
    def asset_key(a):return (a['kind'],norm(a.get('board','')),norm(a.get('name','')),a.get('occurrence',1))
    @staticmethod
    def locked(d):return bool(d.get('historical')) or d.get('status') in ('issued','discarded','annulled')
    @staticmethod
    def module_of(d):return d.get('module') or 'M01'
    # --- letture mirate (0.3.23): con migliaia di verbali non si rilegge tutto l'archivio --------------
    def where(self,kind,field,value):
        """Oggetti di un tipo con data.<field> = value (indice JSON di SQLite se disponibile)."""
        with self.lock:
            c=self.connect()
            try:return [self._obj(r) for r in self._json_rows(c,kind,field,value)]
            finally:c.close()
    # 0.3.25: «due» (prossima verifica) serve all'ordinamento dell'archivio degli impianti (punto 44).
    LIGHT={'plant_id':'$.plant_id','module':'$.module','number':'$.header.number','date':'$.header.report_date','due':'$.header.due_date','out_neg':'$.flags.outcome.negative','out_pos':'$.flags.outcome.positive','historical':'$.historical','status':'$.status',
      'rev_index':'$.rev_index','client':'$.plant.client_name','inspectors':'$.header.inspectors','template_id':'$.template_id','revision_of':'$.revision_of',
      'site':'$.plant.site_name','address':'$.plant.address','end_date':'$.header.end_date','issued_date':'$.header.issued_date','issued_at':'$.issued_at','imported_at':'$.imported_at','source_sha':'$.source_sha','a_reason':'$.annulled.reason','a_at':'$.annulled.at','a_by':'$.annulled.by_name','annul_log':'$.annul_log'}
    def light_inspections(self):
        """Dati essenziali di tutti i verbali (senza elementi provati): elenchi, statistiche, controlli di numerazione."""
        out=[]
        with self.lock:
            c=self.connect()
            try:
                if Archive._json1 is not False:
                    try:
                        cols=','.join("json_extract(data,'%s')"%v for v in self.LIGHT.values())
                        rows=c.execute('SELECT id,updated_at,updated_by,'+cols+" FROM objects WHERE kind='inspection'").fetchall();Archive._json1=True
                        for r in rows:
                            x=dict(zip(['id','updated_at','updated_by']+list(self.LIGHT),tuple(r)))
                            x['annul_log']=json.loads(x['annul_log']) if x['annul_log'] else []
                            out.append(x)
                    except sqlite3.OperationalError:Archive._json1=False
                if Archive._json1 is False:
                    for r in c.execute("SELECT * FROM objects WHERE kind='inspection'"):
                        d=json.loads(r['data']);a=d.get('annulled') or {}
                        out.append({'id':r['id'],'updated_at':r['updated_at'],'updated_by':r['updated_by'],'plant_id':d.get('plant_id'),'module':d.get('module'),
                          'number':d.get('header',{}).get('number'),'date':d.get('header',{}).get('report_date'),'due':d.get('header',{}).get('due_date'),'out_neg':(d.get('flags',{}).get('outcome') or {}).get('negative'),'out_pos':(d.get('flags',{}).get('outcome') or {}).get('positive'),'historical':d.get('historical'),'status':d.get('status'),
                          'rev_index':d.get('rev_index'),'client':d.get('plant',{}).get('client_name'),'inspectors':d.get('header',{}).get('inspectors'),
                          'template_id':d.get('template_id'),'revision_of':d.get('revision_of'),'site':d.get('plant',{}).get('site_name'),'address':d.get('plant',{}).get('address'),'end_date':d.get('header',{}).get('end_date'),'issued_date':d.get('header',{}).get('issued_date'),'issued_at':d.get('issued_at'),'imported_at':d.get('imported_at'),'source_sha':d.get('source_sha'),
                          'a_reason':a.get('reason'),'a_at':a.get('at'),'a_by':a.get('by_name'),'annul_log':d.get('annul_log') or []})
            finally:c.close()
        for x in out:
            x['historical']=bool(x['historical']);x['status']=x['status'] or '';x['module']=x['module'] or 'M01';x['number']=x['number'] or '';x['date']=x['date'] or ''
            x['rev_index']=x['rev_index'] or 0;x['client']=x['client'] or '';x['inspectors']=x['inspectors'] or ''
            x['locked']=x['historical'] or x['status'] in ('issued','discarded','annulled')
        return out
    def asset_counts(self):
        with self.lock:
            c=self.connect()
            try:
                try:return dict(c.execute("SELECT json_extract(data,'$.plant_id'),COUNT(*) FROM objects WHERE kind='asset' AND COALESCE(json_extract(data,'$.active'),1)=1 AND json_extract(data,'$.pending_inspection') IS NULL GROUP BY 1").fetchall())
                except sqlite3.OperationalError:
                    n={}
                    for (raw,) in c.execute("SELECT data FROM objects WHERE kind='asset'"):
                        d=json.loads(raw)
                        if d.get('active',True) and not d.get('pending_inspection'):k=d['plant_id'];n[k]=n.get(k,0)+1
                    return n
            finally:c.close()
    def active_templates(self):return [x for x in self.all('template') if not x['data'].get('deleted')]
    def templates_for(self,module):return [x for x in self.active_templates() if (x['data'].get('module') or 'M01')==module]
    def _blank_baseline(self,plant,module):
        """Prima verifica di un modulo senza storico: struttura letta dal template, tutto vuoto."""
        from .wordio import parse_word
        tpls=self.templates_for(module)
        if not tpls:raise ValueError('Nessuno storico '+module+' per questo impianto: caricare prima il template '+module+' nella sezione Template Word.')
        t=max(tpls,key=lambda x:x['updated_at']);_,raw=self.document(t['data']['original_sha'])
        d=parse_word(raw,t['data']['name'])
        if self.module_of(d)!=module:raise ValueError('Il template caricato non corrisponde al modulo '+module+'.')
        for g in d['flags']:d['flags'][g]={k:False for k in d['flags'][g]}
        for sec in ('header','tests','sampling'):d[sec]={k:'' for k in d[sec]}
        d['plant']={k:('' if not isinstance(v,bool) else False) for k,v in d['plant'].items()}
        d['plant'].update(client_name=plant['data']['client_name'],site_name=plant['data'].get('site_name',''),address=plant['data']['address'])
        d.update(samples=[],instruments=[],notes='',document_notes='',nonconformities='',module=module,source_meta={'blank_from_template':t['data']['name']})
        if module=='M01':d['attachments']={k:{'declared':False,'pages':''} for k in d.get('attachments',{})}
        return {'id':None,'data':d}
    def create_draft(self,plant_id,baseline_id=None,inspector=None,module=None):
        p=self.get(plant_id)
        if p['kind']!='plant' or p['data'].get('deleted'):raise ValueError('Impianto non valido.')
        if not str(p['data'].get('client_name','')).strip() or not str(p['data'].get('address','')).strip():
            raise ValueError('Prima della nuova verifica completare l’anagrafica dell’impianto: cliente e indirizzo della sede sono obbligatori.')
        if baseline_id:
            baseline=self.get(baseline_id)
            if baseline['kind']!='inspection' or baseline['data']['plant_id']!=plant_id:raise ValueError('Storico di un altro impianto.')
            if baseline['data'].get('status')=='annulled' or not (baseline['data'].get('historical') or baseline['data'].get('status')=='issued'):
                raise ValueError('Come riferimento scegliere un verbale storico o emesso valido, non una bozza.')
            module=self.module_of(baseline['data'])
        module=module or 'M01'
        histories=[x for x in self.where('inspection','plant_id',plant_id) if self.module_of(x['data'])==module]
        if not baseline_id:
            eligible=[x for x in histories if x['data'].get('status')!='annulled' and
                      (x['data'].get('historical') or x['data'].get('status')=='issued')]
            baseline=max(eligible,key=lambda x:(self._state_date(x['data']),x['updated_at'],x['id'])) if eligible else None
        if baseline is None:baseline=self._blank_baseline(p,module)
        profile=p['data'].get('profiles',{}).get(module)
        seed=copy.deepcopy(baseline['data'])
        if profile:plantstate.apply(seed,profile['state'])
        if module=='M01':
            if profile:
                assets=[dict(copy.deepcopy(s),id=s['asset_id']) for s in profile['state']['samples']]
            else:
                assets=[dict(x['data'],id=x['id']) for x in self.where('asset','plant_id',plant_id)
                        if x['data'].get('active',True) and not x['data'].get('pending_inspection')]
            board_order={}
            for a in assets:board_order.setdefault(norm(a.get('board','')),len(board_order))
            assets.sort(key=lambda a:board_order[norm(a.get('board',''))])
            if baseline.get('id'):
                previous_ids={s.get('asset_id') for s in seed.get('samples',[])}
                seed['samples'].extend({'asset_id':a['id'],'state':'excluded'} for a in assets if a['id'] not in previous_ids)
            d=empty_draft(seed,assets)
        else:
            from .forms import empty_form_draft
            d=empty_form_draft(dict(seed,module=module))
            if module=='M02':d['tests']['visual_note']=''
        if module=='M01':
            for key in ('continuity_description','contact_description'):d['tests'][key]=''
        if 'period' in d.get('flags',{}):d['flags']['period']={k:False for k in d['flags']['period']}
        d['plant_state_base']=plantstate.stamp(p['data'],module)
        d.update({'plant_id':plant_id,'historical':False,'status':'draft','baseline_id':baseline['id'],'module':module})
        for k in ('issued_at','issued_by','issued_by_name','issued_export_id','issue_anomalies','due_auto','date_auto','revision_of','rev_index','annulled','annul_log'):d.pop(k,None)
        if inspector:d['header']['inspectors']=inspector
        # Anagrafica sempre dall'impianto (corretta in archivio), non dal verbale precedente.
        for k in ('client_name','site_name','address'):
            if k in p['data']:d['plant'][k]=p['data'][k]
        # Instruments assigned to the inspector are proposed from the registry, as copies.
        who=norm(d['header'].get('inspectors',''))
        d['instruments']=[self.instrument_row(x) for x in self.all('instrument')
          if who and x['data'].get('active',True) and norm(plain_name(x['data'].get('assigned_to',''))) and norm(plain_name(x['data']['assigned_to'])) in who]
        templates=self.templates_for(module);d['template_id']=max(templates,key=lambda x:x['updated_at'])['id'] if templates else None
        oid=self.mutate(lambda c:self._put(c,'inspection',d,action='new_draft'));return self.get(oid)
    INSTRUMENT_FIELDS=('code','type','brand','model','serial','calibration','calibration_due','internal_check','internal_check_due','assigned_to','status')
    INSTRUMENT_STATES=('Attivo','In taratura','Fuori servizio','Dismesso','Non attivo')
    @staticmethod
    def instrument_row(x):
        # «code» (codice interno, 0.3.24) resta nella bozza ma non viene stampato nel Word (la tabella usa tipo, marca, modello, matricola, taratura).
        d=x['data'];row={k:d.get(k,'') for k in ('code','type','brand','model','serial','calibration','calibration_due','internal_check','internal_check_due')}
        row['instrument_id']=x['id'];row['auto']=True;return row   # auto = proposto perché assegnato al verificatore
    def _clean_instrument(self,data):
        if not isinstance(data,dict):raise ValueError('Dati strumento non validi.')
        clean={k:str(data.get(k,'') or '').strip() for k in self.INSTRUMENT_FIELDS}
        clean['code']=clean['code'].upper()
        if clean['status'] and clean['status'] not in self.INSTRUMENT_STATES:clean['status']=clean['status'][:40]
        if 'status' in data and clean['status']:clean['active']=clean['status']=='Attivo'
        else:
            clean['active']=bool(data.get('active',True));clean['status']='Attivo' if clean['active'] else (clean['status'] if clean['status'] and clean['status']!='Attivo' else 'Non attivo')
        if not clean['type'] or not (clean['serial'] or clean['model']):raise ValueError('Indicare almeno tipo e matricola (o modello) dello strumento.')
        for k in ('calibration','calibration_due','internal_check','internal_check_due'):
            if clean[k] and not iso_date(clean[k]):raise ValueError('Data non valida (gg/mm/aaaa): '+clean[k])
        return clean
    def save_instrument(self,oid,data,revision=None):
        clean=self._clean_instrument(data)
        if oid and self.get(oid)['kind']!='instrument':raise ValueError('Strumento non trovato.')
        if clean['code'] and any(x['id']!=oid and (x['data'].get('code') or '').upper()==clean['code'] for x in self.all('instrument')):
            raise ValueError('Codice interno '+clean['code']+' già usato da un altro strumento del registro.')
        new=self.mutate(lambda c:self._put(c,'instrument',clean,oid or None,revision if oid else None,action='instrument'),True)
        return self.get(new)
    # --- 0.3.24: importazione del registro Excel M07 (scheda «Apparecchiature») ---------------------
    M07_COLUMNS={'code':'codice interno','type':'tipologia','brand':'costruttore','model':'modello','serial':'matricola (s/n)',
      'assigned_to':'assegnatario','status':'stato operativo','calibration':'data ultima taratura','calibration_due':'scadenza taratura (auto)',
      'internal_check':'ultimo controllo positivo (auto)','internal_check_due':'scadenza controllo (auto)'}
    def parse_instrument_registry(self,raw):
        """Righe dello strumento dal registro M07. Restituisce (strumenti, avvisi)."""
        from .xlsxio import Workbook
        wb=Workbook(raw);rows,_=wb.rows('Apparecchiature')
        key=lambda v:re.sub(r'\s+',' ',str(v or '')).strip().casefold()
        head=next((i for i,r in enumerate(rows[:15]) if 'codice interno' in [key(v) for v in r] and any(key(v).startswith('matricola') for v in r)),None)
        if head is None:raise ValueError('Nella scheda «Apparecchiature» non trovo la riga delle intestazioni (Codice interno, Matricola…).')
        cols={}
        for j,v in enumerate(rows[head]):
            k=key(v)
            for f,name in self.M07_COLUMNS.items():
                if f not in cols and (k==name or (f=='serial' and k.startswith('matricola'))):cols[f]=j
        miss=[self.M07_COLUMNS[f] for f in ('code','type','serial') if f not in cols]
        if miss:raise ValueError('Colonne mancanti nella scheda «Apparecchiature»: '+', '.join(miss)+'.')
        out=[];warnings=[]
        for n,r in enumerate(rows[head+1:],start=head+2):
            cell=lambda f:(r[cols[f]] if f in cols and cols[f]<len(r) else None)
            txt=lambda f:'' if cell(f) is None else (str(int(cell(f))) if isinstance(cell(f),float) and cell(f).is_integer() else str(cell(f))).strip()
            code=txt('code').upper()
            if not code and not txt('serial'):continue
            d={'code':code,'type':txt('type'),'brand':txt('brand'),'model':txt('model'),'serial':txt('serial')}
            for f in ('calibration','calibration_due','internal_check','internal_check_due'):d[f]=wb.to_date(cell(f))
            who=txt('assigned_to');d['assigned_to']='' if key(who) in ('odi','','organismo','organismo di ispezione') else plain_name(who)
            st=txt('status') or 'Attivo';st={'attivo':'Attivo','in taratura':'In taratura','fuori servizio':'Fuori servizio','dismesso':'Dismesso'}.get(key(st),st)
            d['status']=st;d['active']=st=='Attivo';d['row']=n
            if d['calibration'] and not d['calibration_due']:warnings.append('Riga '+str(n)+' ('+(code or d['serial'])+'): scadenza taratura vuota. Le colonne «(auto)» sono formule: aprire il file in Excel, salvarlo e ricaricarlo.')
            if not d['type'] or not (d['serial'] or d['model']):warnings.append('Riga '+str(n)+' ('+(code or '?')+'): manca tipologia o matricola, riga saltata.');continue
            out.append(d)
        codes=[d['code'] for d in out if d['code']]
        dup=sorted({c for c in codes if codes.count(c)>1})
        if dup:raise ValueError('Codice interno ripetuto nel registro Excel: '+', '.join(dup)+'.')
        return out,warnings
    def instrument_import_plan(self,raw):
        """Confronto fra registro Excel e registro del programma: nuovi, aggiornati, invariati, solo nel programma."""
        rows,warnings=self.parse_instrument_registry(raw)
        current=self.all('instrument');by_code={};by_serial={}
        for x in current:
            if x['data'].get('code'):by_code[x['data']['code'].upper()]=x
            if x['data'].get('serial'):by_serial.setdefault(norm(x['data']['serial']),[]).append(x)
        plan=[];matched=set()
        for d in rows:
            x=by_code.get(d['code']) if d['code'] else None
            if not x and d['serial']:
                cand=[c for c in by_serial.get(norm(d['serial']),[]) if c['id'] not in matched and (not c['data'].get('code') or c['data']['code'].upper()==d['code'])]
                x=cand[0] if cand else None
            data={k:d[k] for k in self.INSTRUMENT_FIELDS};data['active']=d['active']
            if x:
                matched.add(x['id']);old=dict(x['data']);old['status']=old.get('status') or ('Attivo' if old.get('active',True) else 'Non attivo')
                ch=[[self.INSTR_LABELS.get(k,k),str(old.get(k,'') or ''),str(data[k] or '')] for k in self.INSTRUMENT_FIELDS if str(old.get(k,'') or '')!=str(data[k] or '')]
                plan.append({'action':'update' if ch else 'same','id':x['id'],'revision':x['revision'],'data':data,'changes':ch,'row':d['row']})
            else:plan.append({'action':'new','id':None,'data':data,'changes':[],'row':d['row']})
        only=[{'id':x['id'],'data':x['data']} for x in current if x['id'] not in matched]
        return {'plan':plan,'only_here':only,'warnings':warnings,
          'counts':{'new':sum(p['action']=='new' for p in plan),'update':sum(p['action']=='update' for p in plan),'same':sum(p['action']=='same' for p in plan),'only_here':len(only)}}
    def instrument_import_apply(self,raw):
        p=self.instrument_import_plan(raw);todo=[x for x in p['plan'] if x['action'] in ('new','update')]
        clean=[(x,self._clean_instrument(x['data'])) for x in todo]
        def op(c):
            for x,d in clean:self._put(c,'instrument',d,x['id'],action='instrument')
            return len(clean)
        if clean:self.mutate(op,True)
        return dict(p,applied=len(clean))
    def save(self,oid,data,revision):
        current=self.get(oid)
        if current['kind']!='inspection' or current['data'].get('historical'):raise ValueError('Lo storico originale è conservato. Creare una nuova bozza per modificarlo.')
        if current['data'].get('status')=='annulled':raise ValueError('Verbale annullato: non modificabile.')
        if current['data'].get('status') in ('issued','discarded'):raise ValueError('Verbale emesso: non modificabile. Per correggerlo creare una revisione.')
        # Identity, provenance and emission cannot be reassigned by a form edit.
        for k in ['plant_id','historical','baseline_id','source_sha','status','revision_of','rev_index','plant_state_base','plant_state_update','revision_reference']:
            if k in current['data']:data[k]=current['data'][k]
            else:data.pop(k,None)
        for k in ('issued_at','issued_by','issued_by_name','issued_export_id','issue_anomalies','annulled','annul_log'):data.pop(k,None)
        required={'header':dict,'plant':dict,'flags':dict,'samples':list,'tests':dict,'attachments':dict,'sampling':dict,'instruments':list}
        if any(not isinstance(data.get(k),typ) for k,typ in required.items()):raise ValueError('Struttura della bozza non valida.')
        from .rules import normalize_coordination
        normalize_coordination(data)
        if len(jdump(data))>10*1024*1024:raise ValueError('Bozza troppo grande.')
        if data.get('module','M01')=='M01':
            # Righe senza nome e senza elemento (appena aggiunte) restano in bozza; le altre devono avere un elemento.
            data['samples']=[x for x in data['samples'] if x.get('asset_id') or (x.get('name') or '').strip() or any((x.get('attributes') or {}).values()) or any((x.get('results') or {}).values())]
        create=[];plant_assets={a['id']:a for a in self.where('asset','plant_id',data['plant_id'])};seen=set()
        for sample in data['samples']:
            if sample.get('retired'):
                # Un elemento dismesso non torna nel campione tramite i comandi di spunta.
                # La dismissione entra nel censimento solo alla conferma dello stato all'emissione.
                sample['state']='excluded'
            if sample.get('state') not in ('excluded','selected','tested','not_executed'):raise ValueError('Stato del campione non valido.')
            if sample.get('kind') not in ('rcd','overcurrent','continuity'):raise ValueError('Tipo di elemento non valido.')
            if not sample.get('asset_id'):
                if (sample.get('name') or '').strip():create.append(sample)
                continue
            if sample['asset_id'] in seen:raise ValueError('Lo stesso elemento compare due volte nella verifica.')
            seen.add(sample['asset_id'])
            asset=plant_assets.get(sample['asset_id']) or self.get(sample['asset_id'])
            if asset['kind']!='asset' or asset['data']['plant_id']!=data['plant_id']:raise ValueError('Elemento di un altro impianto.')
            pending=asset['data'].get('pending_inspection')
            if pending and pending!=oid:raise ValueError('Elemento appartenente a un’altra bozza.')
        if data.get('template_id') and self.get(data['template_id'])['kind']!='template':raise ValueError('Template non valido.')
        used={x.get('asset_id') for x in data['samples']}
        orphans=[a for a in plant_assets.values() if a['data'].get('provenance',{}).get('inspection')==oid and a['id'] not in used and a['data'].get('active',True)]
        def op(c):
            for sample in create:
                ad={'plant_id':data['plant_id'],'kind':sample['kind'],'board':(sample.get('board') or '').strip(),'name':sample['name'].strip(),
                    'occurrence':sample.get('occurrence',1),'attributes':dict(sample.get('attributes') or {}),'active':False,'pending_inspection':oid,'provenance':{'manual':True,'inspection':oid}}
                sample['asset_id']=self._put(c,'asset',ad,action='manual_asset')
            for a in orphans:self._put(c,'asset',dict(a['data'],active=False),a['id'],action='manual_asset_removed')
            return self._put(c,'inspection',data,oid,revision)
        self.mutate(op);return self.get(oid)
    def boards(self,plant_id):
        seen={}
        profile=self.get(plant_id)['data'].get('profiles',{}).get('M01')
        rows=profile['state']['samples'] if profile else [a['data'] for a in self.where('asset','plant_id',plant_id) if a['data'].get('active',True) and not a['data'].get('pending_inspection')]
        for a in rows:
            if a.get('board'):seen.setdefault(norm(a['board']),a['board'])
        return sorted(seen.values(),key=norm)
    def rename_board(self,plant_id,old,new):
        """Rinomina (o unisce a un quadro esistente) per tutti gli elementi dell'impianto."""
        new=str(new or '').strip()
        if not new:raise ValueError('Indicare il nuovo nome del quadro.')
        if self.get(plant_id)['kind']!='plant':raise ValueError('Impianto non trovato.')
        hits=[a for a in self.where('asset','plant_id',plant_id) if norm(a['data'].get('board',''))==norm(old)]
        if not hits:raise ValueError('Nessun elemento nel quadro indicato.')
        def op(c):
            for a in hits:self._put(c,'asset',dict(a['data'],board=new),a['id'],action='board_rename')
            plant=self.get(plant_id);pd=copy.deepcopy(plant['data']);profile=pd.get('profiles',{}).get('M01')
            if profile:
                for sample in profile['state']['samples']:
                    if norm(sample.get('board',''))==norm(old):sample['board']=new
                profile['revision']+=1;profile['updated_at']=now();profile['updated_by']=self.actor
                self._put(c,'plant',pd,plant_id,plant['revision'],action='plant_state_board')
            return len(hits)
        return {'renamed':self.mutate(op,True),'board':new}
    # --- emission and revisions -------------------------------------------------------------
    def issue(self,oid,revision,anomalies=None,confirmed=False,dry_run=False,export_id=None,patch=None,update_plant=True):
        """Lock a draft as issued. The Word archived must be generated from this exact version."""
        current=self.get(oid);d=current['data']
        if current['kind']!='inspection' or self.locked(d):raise ValueError('Solo una bozza può essere emessa.')
        if current['revision']!=revision:raise Conflict('La bozza è cambiata: ricaricare e aggiornare l’anteprima PDF prima di emettere.')
        exports=self.where('export','inspection_id',oid)
        last=max(exports,key=lambda e:e['data']['created_at']) if exports else None
        if export_id:last=next((e for e in exports if e['id']==export_id),None)
        if not dry_run and (not last or last['data']['inspection_revision']!=current['revision']):
            raise ValueError('Generare il Word dalla versione attuale della bozza prima di emettere il verbale.')
        if not d['header'].get('number') or not d['header'].get('report_date'):raise ValueError('Numero e data del verbale sono necessari per l’emissione.')
        # Strumenti: taratura scaduta alla data di inizio verifica → emissione bloccata (salvataggio e anteprime restano possibili).
        ref=iso_date(d['header'].get('start_date') or '') or iso_date(d['header'].get('report_date') or '')
        expired=[(x.get('type') or '?')+' '+(x.get('serial') or x.get('model') or '')+' (scaduta il '+x['calibration_due']+')' for x in d.get('instruments',[]) if ref and iso_date(x.get('calibration_due') or '') and iso_date(x['calibration_due'])<ref]
        if expired:raise ValueError('Taratura scaduta alla data di inizio verifica: '+'; '.join(expired)+'. Correggere la strumentazione nella scheda «Strumentazione» prima di emettere.')
        if [k for k,v in (d.get('flags',{}).get('outcome') or {}).items() if v] not in (['positive'],['negative']):raise ValueError('Esito della verifica obbligatorio: scegliere positivo o negativo prima di emettere.')
        # 0.3.26 (punto 56): con esito negativo le non conformita' vanno descritte a mano. «NESSUNA»
        # contraddice l'esito, e senza descrizione il verbale non dice perche' la verifica non e'
        # superata: l'emissione e' bloccata, non solo segnalata.
        if [k for k,v in (d.get('flags',{}).get('outcome') or {}).items() if v]==['negative']:
            nc=str(d.get('nonconformities') or '').strip()
            if not nc or re.match(r'^nessun',nc,re.I) or len(re.findall(r'[^\W\d_]',nc))<3:
                raise ValueError('Esito negativo: descrivere le non conformità rilevate prima di emettere il verbale '
                  '(«NESSUNA» o un campo vuoto non sono ammessi con esito negativo).')
        # Decisione 03/10: nessun elemento «provato» senza risultato («n.e.» non richiede più un motivo).
        need={'rcd':('mechanical','time'),'overcurrent':('zs','ig','coordination'),'continuity':('outcome',)}
        missing=[]
        for x in d.get('samples',[]):
            st=x.get('state');res=x.get('results') or {}
            if st in ('tested','selected') and any(not str(res.get(k) or '').strip() for k in need.get(x.get('kind'),())):missing.append((x.get('board') or '')+' · '+(x.get('name') or '?'))
        if missing:raise ValueError(str(len(missing))+' elementi spuntati come provati senza risultato completo: '+'; '.join(missing[:6])+('…' if len(missing)>6 else '')+'. Completare i risultati, indicare n.e. oppure togliere la spunta.')
        for x in self.light_inspections():
            if x['id']!=oid and x['status']=='issued' and x['number']==d['header']['number'] and x['revision_of']!=oid and d.get('revision_of')!=x['id'] and not self._same_chain(x['id'],oid):
                raise ValueError('Esiste già un verbale emesso con numero '+d['header']['number']+'.')
        anomalies=[{k:a.get(k,'') for k in ('code','title','status','detail','acknowledgement')} for a in (anomalies or [])]
        if anomalies and not confirmed:raise ValueError('Il verbale ha '+str(len(anomalies))+' anomalie aperte: confermare l’emissione dopo averle esaminate.')
        if not isinstance(update_plant,bool):raise ValueError('Scelta aggiornamento impianto non valida.')
        if update_plant:
            self._check_state(self.get(d['plant_id'])['data'],self.module_of(d),d.get('plant_state_base'),self._state_date(d),d)
        if dry_run:return current
        who=self.user(self.actor) if self.actor else None
        if patch:d=dict(d,**patch)
        d=dict(d,status='issued',issued_at=now(),issued_by=self.actor,issued_by_name=who['name'] if who else self.actor,issued_export_id=last['id'],issue_anomalies=anomalies)
        def op(c):
            fresh=self.get(oid)
            if fresh['revision']!=revision or self.locked(fresh['data']):raise Conflict('La bozza è cambiata durante l’emissione.')
            if update_plant:
                plant=self.get(d['plant_id']);pd=copy.deepcopy(plant['data'])
                self._check_state(pd,self.module_of(d),d.get('plant_state_base'),self._state_date(d),d)
                self._set_profile(c,plant['id'],pd,{'id':oid,'data':d},True,'issued')
                pd.update({k:str(d.get('plant',{}).get(k,'')).strip() for k in plantstate.IDENTITY})
                self._put(c,'plant',pd,plant['id'],plant['revision'],action='plant_state_confirmed')
            d['plant_state_update']=update_plant
            return self._put(c,'inspection',d,oid,revision,action='issue')
        self.mutate(op,True);return self.get(oid)
    def update_plant(self,pid,client_name,address,site_name='',email_to=None,email_cc=None):
        """Corregge l'anagrafica di un impianto: vale per le nuove verifiche; le bozze aperte restano fotografie.
        Verbali storici ed emessi restano come sono (documenti conservati)."""
        p=self.get(pid)
        if p['kind']!='plant' or p['data'].get('deleted'):raise ValueError('Impianto non trovato.')
        client_name=(client_name or '').strip();address=(address or '').strip();site_name=(site_name or '').strip()
        if not client_name:raise ValueError('Indicare la ragione sociale.')
        emails={}
        if email_to is not None or email_cc is not None:
            from .mailer import split_addresses
            emails={'email_to':', '.join(split_addresses(email_to)),'email_cc':', '.join(split_addresses(email_cc))}
        def op(c):
            fresh=self.get(pid)
            if fresh['kind']!='plant' or fresh['data'].get('deleted'):raise ValueError('Impianto non trovato.')
            self._put(c,'plant',dict(fresh['data'],client_name=client_name,address=address,site_name=site_name,label=address or fresh['data'].get('label',''),**emails),pid,fresh['revision'],action='plant_update')
        self.mutate(op,True);return self.get(pid)
    # --- 0.3.29: cliente/impianto nuovo senza importare un verbale precedente -----------------
    def live_plants(self):
        """Impianti degli elenchi: esclude quelli eliminati, che restano nel registro e nei backup."""
        return [x for x in self.all('plant') if not x['data'].get('deleted')]
    def plant_duplicates(self,client_name,address,exclude=None):
        """Impianti già presenti con la stessa ragione sociale, distinguendo stesso indirizzo e indirizzo diverso."""
        cn=norm(client_name or '');ad=norm(address or '');out=[]
        for x in self.live_plants():
            if x['id']==exclude or norm(x['data'].get('client_name',''))!=cn:continue
            out.append({'id':x['id'],'client_name':x['data'].get('client_name',''),'site_name':x['data'].get('site_name',''),
              'address':x['data'].get('address',''),'same_address':norm(x['data'].get('address',''))==ad})
        return out
    def _plant_duplicates_in_transaction(self,c,client_name,address):
        cn=norm(client_name);ad=norm(address);out=[]
        for row in c.execute("SELECT id,data FROM objects WHERE kind='plant'"):
            d=json.loads(row['data'])
            if d.get('deleted') or norm(d.get('client_name',''))!=cn:continue
            out.append({'id':row['id'],'client_name':d.get('client_name',''),'site_name':d.get('site_name',''),
              'address':d.get('address',''),'same_address':norm(d.get('address',''))==ad})
        return out
    def create_plant(self,client_name,site_name='',address='',email_to=None,email_cc=None,confirm=False):
        """Nuovo impianto in archivio senza alcun verbale: la prima verifica si crea dopo, dall'archivio,
        e senza storico parte vuota dalla struttura del template del modulo (vedi _blank_baseline)."""
        client_name=(client_name or '').strip();site_name=(site_name or '').strip();address=(address or '').strip()
        if not client_name:raise ValueError('Indicare la ragione sociale del cliente.')
        if not address:raise ValueError('Indicare l’indirizzo dell’impianto: identifica l’impianto in archivio e compare nel verbale.')
        from .mailer import split_addresses
        data={'client_name':client_name,'site_name':site_name,'address':address,'label':address,
          'email_to':', '.join(split_addresses(email_to)),'email_cc':', '.join(split_addresses(email_cc))}
        def op(c):
            dup=self._plant_duplicates_in_transaction(c,client_name,address)
            if any(d['same_address'] for d in dup) and confirm is not True:
                raise Duplicate('Esiste già un impianto di «'+client_name+'» a questo indirizzo. Se è un impianto diverso (per esempio una seconda cabina allo stesso indirizzo) confermare la creazione.')
            return self._put(c,'plant',data,action='plant_new'),dup
        pid,dup=self.mutate(op,True)
        return {'plant':self.get(pid),'duplicates':dup}
    def delete_plant(self,pid):
        """Elimina dall'archivio un impianto creato per sbaglio: solo se non ha alcun verbale e alcun elemento.
        Come le bozze scartate resta nel registro delle modifiche e nei backup, ma non negli elenchi."""
        def op(c):
            row=c.execute("SELECT * FROM objects WHERE id=? AND kind='plant'",(pid,)).fetchone()
            if not row:raise ValueError('Impianto non trovato.')
            p=self._obj(row)
            if p['data'].get('deleted'):raise ValueError('Impianto non trovato.')
            if self._json_rows(c,'inspection','plant_id',pid):raise ValueError('L’impianto ha dei verbali: non si elimina. Un verbale si annulla uno per uno, con motivazione.')
            if self._json_rows(c,'asset','plant_id',pid):raise ValueError('L’impianto ha elementi nel censimento: non si elimina.')
            d=dict(p['data'],deleted=True,deleted_at=now(),deleted_by=self.actor)
            return self._put(c,'plant',d,pid,p['revision'],action='plant_delete')
        self.mutate(op,True)
        return {'deleted':pid}
    def delete_draft(self,oid):
        """Scarta una bozza mai emessa: sparisce da bozze, storico e riferimenti, ma resta nell'archivio
        (stato «discarded») perché registro modifiche e backup restino coerenti."""
        x=self.get(oid);d=x['data']
        if x['kind']!='inspection' or self.locked(d):raise ValueError('Si possono eliminare solo bozze non emesse.')
        d=dict(d,status='discarded',discarded_at=now(),discarded_by=self.actor)
        self.mutate(lambda c:self._put(c,'inspection',d,oid,x['revision'],action='discard'),True);return {'deleted':oid}
    def annul(self,oid,reason,revision=None):
        """Annulla un verbale emesso o storico importato: sparisce da storico, riferimenti e statistiche,
        ma documenti, Word/PDF emessi e registro restano conservati. Motivazione obbligatoria; ripristinabile."""
        x=self.get(oid);d=x['data'];reason=str(reason or '').strip()
        if x['kind']!='inspection':raise ValueError('Verbale non trovato.')
        if d.get('status')=='annulled':raise ValueError('Verbale già annullato.')
        if not (d.get('historical') or d.get('status')=='issued'):raise ValueError('Si annullano solo verbali emessi o storici: le bozze si eliminano.')
        if len(reason)<5:raise ValueError('Indicare la motivazione dell’annullamento.')
        if revision is not None and int(revision)!=x['revision']:raise Conflict('Il verbale è stato modificato da un altro utente: ricaricare.')
        if any(y['data'].get('status') not in ('issued','discarded','annulled') for y in self.where('inspection','revision_of',oid)):
            raise ValueError('Esiste una revisione in bozza di questo verbale: eliminarla prima di annullarlo.')
        who=next((u for u in self.users() if u['username']==self.actor),None)
        info={'reason':reason,'at':now(),'by':self.actor,'by_name':who['name'] if who else self.actor,'prev_status':d.get('status') or ('historical' if d.get('historical') else 'issued')}
        d=dict(d,status='annulled',annulled=info,annul_log=list(d.get('annul_log',[]))+[dict(info,action='annullato')])
        def op(c):
            self._put(c,'inspection',d,oid,x['revision'],action='annul')
            plant=self.get(d['plant_id']);pd=copy.deepcopy(plant['data']);changed=False
            for profile in pd.get('profiles',{}).values():
                if profile.get('source_id')==oid:
                    profile.update(confirmed=False,review_required=True,review_reason='La verifica da cui deriva questo stato è stata annullata.',revision=profile['revision']+1)
                    changed=True
            if changed:self._put(c,'plant',pd,plant['id'],plant['revision'],action='plant_state_review')
        self.mutate(op,True);return {'annulled':oid}
    def restore_annulled(self,oid):
        x=self.get(oid);d=x['data']
        if x['kind']!='inspection' or d.get('status')!='annulled':raise ValueError('Il verbale non è annullato.')
        if d.get('historical') and d.get('source_sha') and any(y['id']!=oid and y['data'].get('historical') and y['data'].get('status')!='annulled' for y in self.where('inspection','source_sha',d['source_sha'])):
            raise ValueError('Lo stesso Word è stato importato di nuovo dopo l’annullamento: il ripristino creerebbe un doppione.')
        info=d.get('annulled') or {};who=next((u for u in self.users() if u['username']==self.actor),None)
        d=dict(d,status=info.get('prev_status') or ('historical' if d.get('historical') else 'issued'))
        d.pop('annulled',None);d['annul_log']=list(d.get('annul_log',[]))+[{'action':'ripristinato','at':now(),'by':self.actor,'by_name':who['name'] if who else self.actor}]
        self.mutate(lambda c:self._put(c,'inspection',d,oid,x['revision'],action='annul_restore'),True);return {'restored':oid}
    def reread_historical(self):
        """Rilegge le caselle dei verbali storici dai Word originali conservati, con il lettore attuale.
        Aggiorna solo scelte, allegati dichiarati e avvisi di lettura: anagrafica, elementi e note restano."""
        from .wordio import parse_word
        work=[]
        for x in self.all('inspection'):
            d=x['data']
            if not d.get('historical') or not d.get('source_sha') or d.get('status')=='annulled':continue
            try:fn,raw=self.document(d['source_sha']);new=parse_word(raw,fn)
            except Exception as e:work.append((x,None,str(e)));continue
            work.append((x,new,''))
        report={'checked':0,'changed':[],'errors':[]};plants={x['id']:x for x in self.all('plant')};site_fix={}
        def apply(c):
            for x,new,err in work:
                report['checked']+=1;d=copy.deepcopy(x['data'])
                if new is None:report['errors'].append((d['header'].get('number') or '?')+': '+err);continue
                if new.get('module','M01')!=d.get('module','M01'):continue
                changed=d.get('flags')!=new['flags'] or d.get('attachments')!=new.get('attachments',d.get('attachments'))
                d['flags']=new['flags']
                if new.get('plant',{}).get('site_name') and not d['plant'].get('site_name'):d['plant']['site_name']=new['plant']['site_name'];changed=True
                pl=plants.get(d.get('plant_id'))
                if new.get('plant',{}).get('site_name') and pl and not pl['data'].get('site_name') and d.get('plant_id') not in site_fix:
                    site_fix[d['plant_id']]=1;fresh=self.get(pl['id']);self._put(c,'plant',dict(fresh['data'],site_name=new['plant']['site_name']),pl['id'],fresh['revision'],action='reread')
                if 'attachments' in new:d['attachments']=new['attachments']
                d.setdefault('source_meta',{})['warnings']=new.get('source_meta',{}).get('warnings',[])
                if changed:
                    self._put(c,'inspection',d,x['id'],x['revision'],action='reread')
                    report['changed'].append((d['header'].get('number') or '?')+' · '+d.get('plant',{}).get('client_name',''))
        self.mutate(apply,True)
        report['drafts']=sum(1 for x in self.light_inspections() if not x['historical'] and x['status'] not in ('issued','discarded','annulled'))
        return report
    def _root(self,oid):
        seen=set()
        while oid and oid not in seen:
            seen.add(oid);prev=self.get(oid)['data'].get('revision_of')
            if not prev:return oid
            oid=prev
        return oid
    def _same_chain(self,a,b):return self._root(a)==self._root(b)
    def create_revision(self,oid):
        current=self.get(oid);d=current['data']
        if current['kind']!='inspection' or d.get('status')!='issued':raise ValueError('Si può revisionare solo un verbale emesso.')
        children=self.where('inspection','revision_of',oid)
        if any(x['data'].get('status')=='issued' for x in children):raise ValueError('Esiste già una revisione emessa: creare la successiva da quel verbale.')
        if any(x['data'].get('status') not in ('issued','discarded','annulled') for x in children):
            raise ValueError('Esiste già una revisione in lavorazione di questo verbale.')
        new=copy.deepcopy(d)
        for k in ('issued_at','issued_by','issued_by_name','issued_export_id','issue_anomalies','due_auto','annulled','annul_log'):new.pop(k,None)
        new.update(status='draft',revision_of=oid,rev_index=int(d.get('rev_index',0))+1,carried={},revision_reference={'number':d['header'].get('number',''),'rev_index':int(d.get('rev_index',0)),'issued_date':d['header'].get('issued_date') or str(d.get('issued_at',''))[:10]})
        new['header']['issued_date']=dt.datetime.now().strftime('%d/%m/%Y')
        nid=self.mutate(lambda c:self._put(c,'inspection',new,action='revision'),True);return self.get(nid)
    def add_template(self,original,filename,adapted,info):
        def op(c):
            original_sha=self.add_document(c,original,filename)
            adapted_sha=self.add_document(c,adapted,Path(filename).stem+'_associato.docx')
            for r in c.execute("SELECT * FROM objects WHERE kind='template'"):
                old=json.loads(r['data'])
                if old['original_sha']==original_sha and old['adapted_sha']==adapted_sha:
                    if old.get('deleted'):   # lo stesso file caricato di nuovo dopo l'eliminazione: torna disponibile come il più recente
                        for k in ('deleted','deleted_at','deleted_by'):old.pop(k,None)
                        return self._put(c,'template',old,r['id'],action='template_import')
                    return r['id']
            return self._put(c,'template',dict(info,original_sha=original_sha,adapted_sha=adapted_sha),action='template_import')
        # Le bozze senza modello non vengono toccate qui (chi le sta compilando avrebbe un conflitto di salvataggio):
        # ricevono il modello più recente all'apertura, alla generazione del Word o con «Associa» nel menu Template.
        oid=self.mutate(op,True);return self.get(oid)
    def assign_template(self,template_id,scope='missing'):
        """Associa il modello alle bozze del suo modulo: scope 'missing' = solo quelle senza modello valido,
        'all' = tutte le bozze aperte. Verbali storici ed emessi non cambiano."""
        t=self.get(template_id)
        if t['kind']!='template':raise ValueError('Template non valido.')
        module=t['data'].get('module') or 'M01';valid={x['id'] for x in self.active_templates()}
        targets=[x for x in self.all('inspection') if not self.locked(x['data']) and x['data'].get('status')!='discarded'
                 and self.module_of(x['data'])==module and (scope=='all' or x['data'].get('template_id') not in valid)
                 and x['data'].get('template_id')!=template_id]
        if not targets:return 0
        def op(c):
            for x in targets:self._put(c,'inspection',dict(x['data'],template_id=template_id),x['id'],action='template_assign')
        self.mutate(op,True);return len(targets)
    def template_usage(self):
        """Per ogni modello: quante bozze, verbali emessi, altri verbali (annullati o bozze eliminate) e Word generati lo usano."""
        use={};new=lambda:{'drafts':0,'issued':0,'other':0,'exports':0}
        for x in self.light_inspections():
            if not x['template_id']:continue
            u=use.setdefault(x['template_id'],new());st=x['status']
            if st=='issued':u['issued']+=1
            elif st in ('annulled','discarded') or x['historical']:u['other']+=1
            else:u['drafts']+=1
        with self.lock:
            c=self.connect()
            try:
                try:ex=c.execute("SELECT json_extract(data,'$.template_id'),COUNT(*) FROM objects WHERE kind='export' GROUP BY 1").fetchall()
                except sqlite3.OperationalError:
                    ex={}
                    for (d,) in c.execute("SELECT data FROM objects WHERE kind='export'"):k=json.loads(d).get('template_id');ex[k]=ex.get(k,0)+1
                    ex=list(ex.items())
            finally:c.close()
        for tid,n in ex:
            if tid:use.setdefault(tid,new())['exports']+=n
        return use
    def delete_template(self,oid):
        """Elimina un modello mai usato (caricato per errore). Quelli già usati restano: il più recente di ogni modulo è «in uso»,
        i precedenti sono «superati» e restano consultabili. Il record resta nell'archivio (eliminato = nascosto) per coerenza del registro."""
        t=self.get(oid)
        if t['kind']!='template' or t['data'].get('deleted'):raise ValueError('Modello non trovato.')
        d=dict(t['data'],deleted=True,deleted_at=now(),deleted_by=self.actor)
        def op(c):
            # controllo dentro la transazione: una bozza creata nel frattempo con questo modello impedisce l'eliminazione
            u=self.template_usage().get(oid)
            if u and sum(u.values()):raise ValueError('Il modello è già stato usato ('+str(u['drafts'])+' bozze, '+str(u['issued'])+' verbali emessi, '+str(u['other']+u['exports'])+' altri documenti): non si può eliminare. Quando ne carichi uno più recente passa da solo fra i superati.')
            self._put(c,'template',d,oid,t['revision'],action='template_delete')
        self.mutate(op,True);return {'deleted':oid}
    def save_export(self,iid,data,filename,alerts,pdf=None,extra=None,expected_revision=None):
        inspection=self.get(iid)
        def op(c):
            fresh=self.get(iid)
            if expected_revision is not None and (fresh['revision']!=expected_revision or self.locked(fresh['data'])):raise Conflict('La bozza è cambiata durante la preparazione: aggiornare l’anteprima PDF.')
            digest=self.add_document(c,data,filename)
            rec={'inspection_id':iid,'inspection_revision':inspection['revision'],
              'template_id':inspection['data'].get('template_id'),'sha':digest,'filename':filename,'alerts':alerts,
              'created_at':now(),'kind':'docx'}
            if pdf:rec['pdf_sha']=self.add_document(c,pdf,Path(filename).with_suffix('.pdf').name)
            rec.update(extra or {})
            return self._put(c,'export',rec,action='export')
        oid=self.mutate(op,True);return self.get(oid)
    def attach_pdf(self,export_id,pdf):
        """Aggiunge il PDF a un Word già generato (anche di un verbale emesso: il Word non cambia)."""
        e=self.get(export_id)
        if e['kind']!='export':raise ValueError('Documento non trovato.')
        def op(c):
            digest=self.add_document(c,pdf,Path(e['data']['filename']).with_suffix('.pdf').name)
            self._put(c,'export',dict(e['data'],pdf_sha=digest),export_id,action='export_pdf');return digest
        return self.mutate(op,True)
    def regenerate_pdf(self,export_id,pdf):
        """0.3.25 (punto 50) — rifà il PDF dal Word già emesso, senza toccare il Word.

        Serve quando il PDF è stato prodotto con caratteri sbagliati o con una versione di
        LibreOffice che impaginava male: il documento firmato resta quello, cambia solo la
        resa in PDF. L'operazione finisce nel registro delle operazioni con il PDF precedente
        indicato, così resta tracciato che cosa è stato sostituito."""
        e=self.get(export_id)
        if e['kind']!='export':raise ValueError('Documento non trovato.')
        old=e['data'].get('pdf_sha') or ''
        def op(c):
            digest=self.add_document(c,pdf,Path(e['data']['filename']).with_suffix('.pdf').name)
            if digest==old:return {'pdf_sha':digest,'changed':False}
            # _put registra da solo la voce nel registro operazioni, con lo stato precedente
            # (quindi il PDF sostituito) nel campo «previous».
            self._put(c,'export',dict(e['data'],pdf_sha=digest),export_id,action='pdf_regenerated')
            return {'pdf_sha':digest,'changed':True}
        return self.mutate(op,True)
    # --- 0.3.24: invio dei verbali via email -------------------------------------------------------
    def mail_texts(self):
        from .mailer import DEFAULT_TEXTS
        st=next((x['data'] for x in self.all('settings') if x['id']=='mail_texts'),None) or {}
        return {k:st.get(k,v) for k,v in DEFAULT_TEXTS.items()}
    def set_mail_texts(self,data):
        from .mailer import DEFAULT_TEXTS
        clean={}
        for k in DEFAULT_TEXTS:
            v=str((data or {}).get(k) or '').replace('\r\n','\n').strip()
            if k in ('subject','body') and not v:raise ValueError('Oggetto e messaggio non possono essere vuoti.')
            if len(v)>(300 if k=='subject' else 8000):raise ValueError('Testo troppo lungo.')
            if k=='subject' and '\n' in v:raise ValueError('L’oggetto deve stare su una riga.')
            clean[k]=v
        self.mutate(lambda c:self._put(c,'settings',clean,'mail_texts',action='mail_texts'),True);return self.mail_texts()
    def mail_recipients(self,plant_id):
        """Indirizzi per l'invio: quelli dell'impianto; se mancano, quelli di un altro impianto dello stesso cliente."""
        p=self.get(plant_id);d=p['data']
        if d.get('email_to'):return {'to':d.get('email_to',''),'cc':d.get('email_cc',''),'from_plant':True}
        same=[x for x in self.live_plants() if x['id']!=plant_id and norm(x['data'].get('client_name',''))==norm(d.get('client_name','')) and x['data'].get('email_to')]
        if same:
            x=max(same,key=lambda x:x['updated_at']);return {'to':x['data']['email_to'],'cc':x['data'].get('email_cc',''),'from_plant':False,'other_site':x['data'].get('site_name') or x['data'].get('address','')}
        return {'to':'','cc':'','from_plant':False}
    def set_plant_emails(self,plant_id,to,cc):
        from .mailer import split_addresses
        p=self.get(plant_id)
        if p['kind']!='plant':raise ValueError('Impianto non trovato.')
        to=', '.join(split_addresses(to));cc=', '.join(split_addresses(cc))
        if (p['data'].get('email_to','') or '')==to and (p['data'].get('email_cc','') or '')==cc:return p
        def op(c):
            fresh=self.get(plant_id)
            if fresh['data'].get('deleted'):raise ValueError('Impianto non trovato.')
            self._put(c,'plant',dict(fresh['data'],email_to=to,email_cc=cc),plant_id,fresh['revision'],action='plant_email')
        self.mutate(op,True);return self.get(plant_id)
    def record_mailing(self,rec):
        """Registra un invio (riuscito o no): oggetto «mailing» collegato al verbale; voce nel registro operazioni."""
        rec=dict(rec,at=now(),by=self.actor,by_name=(self.user(self.actor) or {}).get('name',self.actor))
        oid=self.mutate(lambda c:self._put(c,'mailing',rec,action='mail_sent' if rec.get('ok') else 'mail_failed'),True);return self.get(oid)
    def log_event(self,action,info):
        """Voce del registro operazioni senza oggetto (es. impostazioni del server di posta, che non stanno nell'archivio)."""
        def op(c):c.execute('INSERT INTO events(id,object_id,action,previous,created_at,user) VALUES(?,?,?,?,?,?)',(uid(),'user:'+(self.actor or ''),action,jdump(info),now(),self.actor))
        self.mutate(op)
    def mailings(self,inspection_id):
        return sorted(self.where('mailing','inspection_id',inspection_id),key=lambda x:x['data'].get('at',''),reverse=True)
    # --- permessi per ruolo -------------------------------------------------------------------
    def permissions(self):
        """Permessi effettivi per ruolo («gestire» comprende «vedere»)."""
        stored=next((x['data'] for x in self.all('settings') if x['id']=='permissions'),None) or {}
        keys=[k for k,_ in PERMISSIONS];out={}
        known=set(stored.get('_keys') or PERMISSIONS_0323)
        for r in ROLES:
            if r=='admin':v=set(keys)
            else:
                v={k for k in stored.get(r,DEFAULT_PERMISSIONS[r]) if k in known}|{k for k in DEFAULT_PERMISSIONS[r] if k not in known}
            for view,manage in IMPLIED.items():
                if manage in v:v.add(view)
            out[r]=[k for k in keys if k in v and (k!='users' or r=='admin')]
        return out
    def set_permissions(self,matrix):
        keys={k for k,_ in PERMISSIONS};clean={'_keys':sorted(keys)}
        for r in ROLES:
            if r=='admin':continue
            v=matrix.get(r,[])
            if not isinstance(v,list) or any(k not in keys for k in v):raise ValueError('Permessi non validi.')
            v=set(v)
            for view,manage in IMPLIED.items():
                if manage in v:v.add(view)
            clean[r]=[k for k,_ in PERMISSIONS if k in v and k!='users']
        self.mutate(lambda c:self._put(c,'settings',clean,'permissions',action='permissions'),True);return self.permissions()
    def perms_of(self,user):
        if not user:return []
        return self.permissions().get('tecnico' if user.get('role')=='ispettore' else user.get('role'),[])
    def can(self,user,perm):return perm in self.perms_of(user)
    # --- firma grafica del verificatore ---------------------------------------------------------
    def signature_record(self,username):
        username=str(username or '').strip().lower()
        return next((x for x in self.all('signature') if x['data'].get('username')==username),None)
    def signature_image(self,username):
        r=self.signature_record(username)
        if not r or not r['data'].get('sha'):return None
        return self.document(r['data']['sha'])[1]
    def set_signature(self,username,data,filename):
        from .templates import image_info
        u=self.user(username)
        if not u:raise ValueError('Utente non trovato.')
        if len(data)>2*1024*1024:raise ValueError('Immagine della firma troppo grande: massimo 2 MB.')
        fmt,w,h=image_info(data)
        if w<50 or h<20:raise ValueError('Immagine della firma troppo piccola: usare una scansione leggibile (almeno 300 × 100 pixel).')
        old=self.signature_record(u['username'])
        def op(c):
            digest=self.add_document(c,data,'firma_'+u['username']+('.png' if fmt=='png' else '.jpg'))
            return self._put(c,'signature',{'username':u['username'],'sha':digest,'format':fmt,'width':w,'height':h,'updated_at':now()},old['id'] if old else None,action='signature')
        self.mutate(op,True);return self.signature_record(u['username'])
    def remove_signature(self,username):
        old=self.signature_record(username)
        if old:self.mutate(lambda c:self._put(c,'signature',dict(old['data'],sha='',updated_at=now()),old['id'],action='signature_remove'),True)
    def signer_for(self,d):
        """Il verificatore che firma: l'utente il cui nome compare tra i verificatori del verbale
        (chi emette, se è tra loro); se il campo è vuoto, chi emette."""
        names=(d.get('header',{}).get('inspectors') or '').casefold()
        users=[u for u in self.users() if u['active']]
        hit=[u for u in users if u['name'].strip() and u['name'].strip().casefold() in names]
        me=self.user(self.actor) if self.actor else None
        if me and (me in hit or not names.strip()):return me
        return hit[0] if hit else None
    # --- users ------------------------------------------------------------------------------
    def users(self):
        with self.lock:
            c=self.connect()
            try:return [{'username':r['username'],'name':r['name'],'role':r['role'],'active':bool(r['active']),'created_at':r['created_at']} for r in c.execute('SELECT * FROM users ORDER BY name')]
            finally:c.close()
    def user(self,username):
        return next((u for u in self.users() if u['username']==str(username or '').strip().lower()),None)
    @staticmethod
    def _check_password(p):
        if not isinstance(p,str) or len(p)<10:raise ValueError('La password deve avere almeno 10 caratteri.')
    def add_user(self,username,name,role,password,*,only_if_empty=False):
        username=str(username or '').strip().lower();name=str(name or '').strip()
        if not username or not all(ch.isalnum() or ch in '._-' for ch in username):raise ValueError('Nome utente non valido: usare lettere, numeri, punto o trattino.')
        if not name:raise ValueError('Indicare nome e cognome come compaiono nei verbali.')
        if role=='ispettore':role='tecnico'  # nome del ruolo fino alla 0.3.12
        if role not in ROLES:raise ValueError('Ruolo non valido.')
        self._check_password(password);salt=secrets.token_hex(16)
        def op(c):
            if only_if_empty and c.execute('SELECT 1 FROM users LIMIT 1').fetchone():
                raise PermissionError('Configurazione iniziale già eseguita.')
            self._check_available_username(c,username)
            c.execute('INSERT INTO users VALUES(?,?,?,?,?,?,?)',(username,name,role,salt,pw_hash(password,salt),1,now()))
            c.execute('INSERT INTO events(id,object_id,action,previous,created_at,user) VALUES(?,?,?,?,?,?)',(uid(),'user:'+username,'user_add',None,now(),self.actor))
        self.mutate(op,True);return self.user(username)
    @staticmethod
    def _public_user(r):
        return {k:bool(r[k]) if k=='active' else r[k] for k in ('username','name','role','active','created_at')}
    def _check_available_username(self,c,username):
        if c.execute('SELECT 1 FROM users WHERE username=?',(username,)).fetchone():
            raise ValueError('Esiste già un utente «'+username+'».')
        if (c.execute('SELECT 1 FROM events WHERE user=? OR object_id=? LIMIT 1',(username,'user:'+username)).fetchone()
                or c.execute('SELECT 1 FROM objects WHERE updated_by=? LIMIT 1',(username,)).fetchone()):
            raise ValueError('Nome utente già presente nella cronologia: scegliere un nome mai utilizzato.')
    def update_user(self,username,name=None,role=None,active=None,password=None,*,new_username=None):
        username=str(username or '').strip().lower()
        new=username if new_username is None else str(new_username).strip().lower()
        if not new or not all(ch.isalnum() or ch in '._-' for ch in new):
            raise ValueError('Nome utente non valido: usare lettere, numeri, punto o trattino.')
        if password is not None:self._check_password(password)
        if role=='ispettore':role='tecnico'
        if role is not None and role not in ROLES:raise ValueError('Ruolo non valido.')
        def op(c):
            r=c.execute('SELECT * FROM users WHERE username=?',(username,)).fetchone()
            if not r:raise ValueError('Utente non trovato: ricaricare la lista.')
            u=self._public_user(r)
            if new!=username:
                self._guard_removable(c,u,'rinominare')
                self._check_available_username(c,new)
            final_role=u['role'] if role is None else role
            final_active=u['active'] if active is None else bool(active)
            if u['role']=='admin' and u['active'] and (final_role!='admin' or not final_active):
                if not c.execute("SELECT 1 FROM users WHERE role='admin' AND active=1 AND username!=?",(username,)).fetchone():
                    raise ValueError('Deve restare almeno un amministratore attivo.')
            if new!=username:
                c.execute('UPDATE users SET username=? WHERE username=?',(new,username))
                sig=next((self._obj(x) for x in c.execute("SELECT * FROM objects WHERE kind='signature'") if json.loads(x['data']).get('username')==username),None)
                if sig:self._put(c,'signature',dict(sig['data'],username=new),sig['id'],action='signature')
                c.execute('INSERT INTO events(id,object_id,action,previous,created_at,user) VALUES(?,?,?,?,?,?)',
                          (uid(),'user:'+new,'user_rename',jdump(u),now(),self.actor))
            if any(v is not None for v in (name,role,active,password)):
                c.execute('UPDATE users SET name=?,role=?,active=? WHERE username=?',
                          (str(name).strip() or u['name'] if name is not None else u['name'],final_role,int(final_active),new))
                if password is not None:
                    salt=secrets.token_hex(16)
                    c.execute('UPDATE users SET salt=?,hash=? WHERE username=?',(salt,pw_hash(password,salt),new))
                personal_password=(self.actor==username and password is not None and name is None and role is None and active is None and new==username)
                action='user_update password' if personal_password else 'user_update'
                c.execute('INSERT INTO events(id,object_id,action,previous,created_at,user) VALUES(?,?,?,?,?,?)',
                          (uid(),'user:'+new,action,jdump(dict(u,username=new)),now(),self.actor))
            return self._public_user(c.execute('SELECT * FROM users WHERE username=?',(new,)).fetchone())
        return self.mutate(op,True)
    def _traces(self,c,username):
        # Escludere soltanto password e firme PROPRIE. Operazioni su terzi contano.
        own_signatures=[r['id'] for r in c.execute("SELECT id,data FROM objects WHERE kind='signature'")
                        if json.loads(r['data']).get('username')==username]
        own_clause='e.object_id IN ('+','.join('?' for _ in own_signatures)+')' if own_signatures else '0'
        ev=c.execute("SELECT COUNT(*) FROM events e WHERE e.user=? AND NOT ("
                     "(e.action='user_update password' AND e.object_id=?) OR "
                     "(e.action IN ('signature','signature_remove') AND "+own_clause+"))",
                     (username,'user:'+username,*own_signatures)).fetchone()[0]
        # Oggetti senza relativo evento dell'autore: riferimenti conservati da vecchi archivi.
        ob=c.execute("""SELECT COUNT(*) FROM objects o WHERE o.updated_by=? AND o.kind!='signature'
            AND NOT EXISTS (SELECT 1 FROM events e WHERE e.object_id=o.id AND e.user=?)""",(username,username)).fetchone()[0]
        return ev+ob
    def user_traces(self):
        with self.lock:
            c=self.connect()
            try:return {r['username']:self._traces(c,r['username']) for r in c.execute('SELECT username FROM users')}
            finally:c.close()
    def _guard_removable(self,c,u,what):
        if u['username']==self.actor:raise ValueError('Non si può '+what+' il proprio utente: farlo da un altro amministratore.')
        n=self._traces(c,u['username'])
        if n:raise ValueError('L’utente «'+u['username']+'» ha '+str(n)+' tracce operative: per conservare la tracciabilità non si può '+what+'. Disattivarlo e, se serve, creare un nuovo utente.')
        if u['role']=='admin' and u['active'] and not c.execute("SELECT 1 FROM users WHERE role='admin' AND active=1 AND username!=?",(u['username'],)).fetchone():
            raise ValueError('Deve restare almeno un amministratore attivo.')
    def rename_user(self,username,new_username):
        return self.update_user(username,new_username=new_username)
    def delete_user(self,username):
        username=str(username or '').strip().lower()
        def op(c):
            r=c.execute('SELECT * FROM users WHERE username=?',(username,)).fetchone()
            if not r:raise ValueError('Utente non trovato: ricaricare la lista.')
            u=self._public_user(r);self._guard_removable(c,u,'eliminare')
            sig=next((self._obj(x) for x in c.execute("SELECT * FROM objects WHERE kind='signature'") if json.loads(x['data']).get('username')==username),None)
            c.execute('DELETE FROM users WHERE username=?',(username,))
            if sig and sig['data'].get('sha'):self._put(c,'signature',dict(sig['data'],sha='',updated_at=now()),sig['id'],action='signature_remove')
            c.execute('INSERT INTO events(id,object_id,action,previous,created_at,user) VALUES(?,?,?,?,?,?)',
                      (uid(),'user:'+username,'user_delete',jdump(u),now(),self.actor))
            return u
        return self.mutate(op,True)
    def authenticate(self,username,password):
        username=str(username or '').strip().lower()
        with self.lock:
            c=self.connect()
            try:r=c.execute('SELECT * FROM users WHERE username=?',(username,)).fetchone()
            finally:c.close()
        salt=r['salt'] if r else '00'*16
        ok=hmac.compare_digest(pw_hash(str(password or ''),salt),r['hash'] if r else '0'*64)
        return self.user(username) if r and ok and r['active'] else None
    def has_users(self):
        with self.lock:
            c=self.connect()
            try:return c.execute('SELECT COUNT(*) FROM users').fetchone()[0]>0
            finally:c.close()
    # --- summary ------------------------------------------------------------------------------
    def _templates_view(self,objects):
        use=self.template_usage();live=[x for x in objects if x['kind']=='template' and not x['data'].get('deleted')];cur={}
        for x in live:
            m=x['data'].get('module') or 'M01'
            if m not in cur or x['updated_at']>cur[m]['updated_at']:cur[m]=x
        out=[]
        for x in sorted(live,key=lambda x:x['updated_at'],reverse=True):
            u=use.get(x['id']) or {'drafts':0,'issued':0,'other':0,'exports':0}
            out.append(dict(x,current=cur[x['data'].get('module') or 'M01']['id']==x['id'],usage=u,deletable=not sum(u.values())))
        return out
    def summary(self,user=None):
        """Dati di tutte le pagine. Dalla 0.3.23 senza rileggere elementi e prove di ogni verbale (5.000 verbali: da 49 s a meno di 1 s)."""
        ps=self.live_plants();ins=self.light_inspections();counts=self.asset_counts();by={}
        for i in ins:by.setdefault(i['plant_id'],[]).append(i)
        for p in ps:
            mine=by.get(p['id'],[])
            p['inspections']=[{'id':i['id'],'module':i['module'],'number':i['number'],'date':i['date'],'due':i.get('due'),'neg':bool(i.get('out_neg')) and not bool(i.get('out_pos')),'historical':i['historical'],'status':i['status'],
              'rev_index':i['rev_index'],'updated_at':i['updated_at']} for i in mine if i['status'] not in ('discarded','annulled')]
            p['annulled']=[{'id':i['id'],'module':i['module'],'number':i['number'],'date':i['date'],'historical':i['historical'],'reason':i['a_reason'] or '',
              'at':i['a_at'] or '','by':i['a_by'] or ''} for i in mine if i['status']=='annulled']
            p['assets']=counts.get(p['id'],0)
        drafts=[i for i in ins if not i['locked']]
        objects=ps+self.all('template')
        # 0.3.24: senza «Vedere il registro strumenti» arrivano solo gli strumenti attivi (servono per sceglierli nella verifica).
        instruments=self.all('instrument')
        if user is not None and not self.can(user,'instruments_view'):instruments=[x for x in instruments if x['data'].get('active',True)]
        sent={}
        for m in self.all('mailing'):
            d=m['data']
            if d.get('ok') and d.get('at','')>sent.get(d.get('inspection_id'),''):sent[d['inspection_id']]=d['at']
        for p in ps:
            for i in p['inspections']:
                if i['id'] in sent:i['sent_at']=sent[i['id']]
        # Elenco globale: date del documento e degli eventi restano distinte.
        replaced={i['revision_of'] for i in ins if i['status']=='issued' and i.get('revision_of')}
        reports=[]
        for i in ins:
            if i['status'] not in ('issued','historical','annulled') and not i['historical']:continue
            if i['status']=='annulled' and user is not None and not self.can(user,'annul'):continue
            row={k:i.get(k) or '' for k in ('id','plant_id','module','number','client','site','address','inspectors','issued_date','issued_at','imported_at')}
            row.update(date=i.get('end_date') or i['date'],rev_index=i['rev_index'],
              state='annulled' if i['status']=='annulled' else 'replaced' if i['id'] in replaced else 'historical' if i['historical'] else 'issued',sent_at=sent.get(i['id'],''))
            reports.append(row)
        return {'version':APP_VERSION,'reports':reports,'plants':ps,'instruments':instruments,'templates':self._templates_view(objects),
          'drafts':[{'id':i['id'],'module':i['module'],'plant_id':i['plant_id'],'client':i['client'],'rev_index':i['rev_index'],
             'number':i['number'],'inspectors':i['inspectors'],'updated_at':i['updated_at'],'updated_by':i['updated_by']} for i in drafts],
          'people':[u['name'] for u in self.users() if u['active']],
          'directory':str(self.directory),'backup_directory':str(self.backups),'backup_error':self.backup_error,
          'backups':[p.name for p in sorted(self.backups.glob('*.adbackup.zip'),reverse=True)],
          'stats':{'plants':len(ps),'clients':len({norm(p['data']['client_name']) for p in ps}),
            'assets':sum(counts.values()),'histories':sum(i['historical'] and i['status']!='annulled' for i in ins),
            'issued':sum(i['status']=='issued' for i in ins),'drafts':len(drafts)}}
    # --- registro delle operazioni critiche ----------------------------------------------------
    OPLOG={'issue':('verbali','Emissione verbale'),'revision':('verbali','Revisione di verbale emesso'),'annul':('verbali','Annullamento verbale'),
      'annul_restore':('verbali','Ripristino di verbale annullato'),'discard':('verbali','Eliminazione bozza'),'import':('verbali','Importazione verbale storico'),
      'user_add':('utenti','Nuovo utente'),'user_update':('utenti','Modifica utente'),'user_update password':('utenti','Password modificata'),'user_rename':('utenti','Nome utente cambiato'),'user_delete':('utenti','Utente eliminato'),
      'permissions':('utenti','Permessi dei ruoli'),'signature':('utenti','Firma grafica caricata'),'signature_remove':('utenti','Firma grafica rimossa'),
      'template_import':('modelli','Modello Word caricato'),'template_assign':('modelli','Modello associato alle bozze'),'template_delete':('modelli','Modello Word eliminato'),
      'instrument':('strumenti','Registro strumenti'),
      'mail_sent':('verbali','Verbale inviato al cliente'),'mail_failed':('verbali','Invio verbale non riuscito'),
      'mail_texts':('utenti','Testi email modificati'),'mail_server':('utenti','Impostazioni server di posta'),
      'plant_email':('archivio','Indirizzi email impianto'),
      'plant_new':('archivio','Nuovo impianto creato'),'plant_delete':('archivio','Impianto eliminato dall’archivio'),
      'plant_update':('archivio','Anagrafica impianto corretta'),'reread':('archivio','Rilettura dei verbali storici'),'restore':('archivio','Ripristino da backup'),
      'pdf_regenerated':('verbali','PDF rigenerato dal Word emesso'),'pdf_reviewed':('verbali','PDF definitivo controllato')}
    OPLOG_CATEGORIES=[('verbali','Verbali'),('utenti','Utenti, permessi e firme'),('modelli','Modelli Word'),('strumenti','Strumenti'),('archivio','Archivio e backup')]
    INSTR_LABELS={'code':'codice interno','status':'stato','type':'tipo','brand':'marca','model':'modello','serial':'matricola','calibration':'ultima taratura','calibration_due':'scadenza taratura','internal_check':'ultimo controllo interno','internal_check_due':'scadenza controllo interno','assigned_to':'assegnato a','active':'attivo'}
    def oplog(self,since='',until='',user='',category='',limit=1000):
        """Operazioni critiche (chi, quando, cosa), dalla più recente. since/until: «AAAA-MM-GGTHH:MM:SS» in UTC.
        Si basa sul registro delle modifiche (events) senza i salvataggi automatici delle bozze."""
        limit=max(1,min(int(limit or 1000),50000));objs={x['id']:x for k in ('plant','template','instrument','signature','settings','mailing') for x in self.all(k)}
        for i in self.light_inspections():objs[i['id']]={'kind':'inspection','data':{'module':i['module'],'header':{'number':i['number'],'report_date':i['date']},'rev_index':i['rev_index'],'plant':{'client_name':i['client']},'annul_log':i['annul_log']}}
        names={u['username']:u['name'] for u in self.users()}
        c=self.connect()
        try:
            marks=','.join('?'*len(self.OPLOG))
            rows=[dict(r) for r in c.execute('SELECT id,object_id,action,previous,created_at,user FROM events WHERE action IN ('+marks+') ORDER BY created_at,id',tuple(self.OPLOG))]
        finally:c.close()
        # stato di ogni oggetto dopo ciascun evento = «previous» dell'evento successivo sullo stesso oggetto (l'ultimo: lo stato attuale)
        by={}
        for r in rows:by.setdefault((r['object_id'],r['action']=='restore'),[]).append(r)
        def js(v):
            try:return json.loads(v) if v else None
            except ValueError:return None
        for (oid,_),lst in by.items():
            for i,r in enumerate(lst):
                nxt=lst[i+1]['previous'] if i+1<len(lst) else None
                r['_after']=js(nxt) if i+1<len(lst) else (objs[oid]['data'] if oid in objs else None)
        def diff(old,new,labels):
            out=[]
            for k,lab in labels.items():
                a,b=(old or {}).get(k,''),(new or {}).get(k,'')
                if a!=b:out.append(lab+': '+(str(a) if a!='' else '—')+' → '+(str(b) if b!='' else '—'))
            return out
        res=[]
        for r in rows:
            act=r['action'];cat,label=self.OPLOG[act];oid=r['object_id'];o=objs.get(oid);d=(o or {}).get('data') or {};detail='';ref=''
            if act in ('issue','revision','annul','annul_restore','discard','import'):
                if not o or o['kind']!='inspection':continue
                mod=self.module_of(d);num=d.get('header',{}).get('number') or '(senza numero)'
                detail=mod+' '+num+(' rev. '+str(d['rev_index']) if d.get('rev_index') else '')+' · '+(d.get('plant',{}).get('client_name') or '');ref=num
                if act=='import':detail+=' · '+(d.get('header',{}).get('report_date') or '')
                if act=='annul':
                    log=[e for e in d.get('annul_log',[]) if e.get('action')=='annullato' and abs((dt.datetime.fromisoformat(e['at'])-dt.datetime.fromisoformat(r['created_at'])).total_seconds())<5]
                    if log:detail+=' · motivo: '+log[-1].get('reason','')
            elif act in ('plant_new','plant_update','plant_delete'):
                if not o or o['kind']!='plant':continue
                detail=(d.get('client_name') or '')+' · '+(d.get('address') or '')
            elif act=='plant_email':
                if not o or o['kind']!='plant':continue
                after=r['_after'] if isinstance(r['_after'],dict) else d
                detail=(d.get('client_name') or '')+' · a: '+(after.get('email_to') or '—')+((' · cc: '+after['email_cc']) if after.get('email_cc') else '')
            elif act in ('mail_sent','mail_failed'):
                if not o or o['kind']!='mailing':continue
                detail=(d.get('number') or '')+' · '+(d.get('client') or '')+' · a: '+', '.join(d.get('to',[]))+(' · cc: '+', '.join(d.get('cc',[])) if d.get('cc') else '')
                if act=='mail_failed':detail+=' · errore: '+(d.get('error') or '')
                ref=d.get('number') or ''
            elif act=='mail_texts':detail='oggetto, messaggio o firma standard'
            elif act=='mail_server':
                info=js(r['previous']) or {};detail=info.get('detail','')
            elif act=='reread':
                if not o or o['kind']!='inspection':continue
                detail='1 verbale'
            elif act in ('user_add','user_update','user_update password'):
                un=oid[5:];detail=names.get(un,un)+' ('+un+')'
                if act=='user_update':
                    before=js(r['previous']);after=r['_after'] if isinstance(r['_after'],dict) and 'role' in r['_after'] else self.user(un)
                    ch=diff(before,after,{'name':'nome','role':'ruolo','active':'attivo'}) if before and after else []
                    if ch:detail+=' · '+'; '.join(ch)
                elif act=='user_add':
                    u=self.user(un);detail+=(' · ruolo '+u['role']) if u else ''
            elif act in ('user_rename','user_delete'):
                un=oid[5:];before=js(r['previous']) or {}
                detail=(before.get('name') or names.get(un,un))+' ('+(before.get('username','')+' → '+un if act=='user_rename' else un)+')'
            elif act=='permissions':
                before=js(r['previous']);after=r['_after'] or {}
                prev=dict(before) if isinstance(before,dict) else {k:list(v) for k,v in DEFAULT_PERMISSIONS.items()}
                ch=[]
                for role in ROLES:
                    if role=='admin':continue
                    a=set(prev.get(role,DEFAULT_PERMISSIONS[role]));b=set(after.get(role,DEFAULT_PERMISSIONS[role]))
                    lab=dict(PERMISSIONS)
                    for k in sorted(b-a):ch.append(ROLE_LABELS[role]+': + '+lab.get(k,k))
                    for k in sorted(a-b):ch.append(ROLE_LABELS[role]+': − '+lab.get(k,k))
                detail='; '.join(ch) or 'nessuna differenza'
            elif act in ('signature','signature_remove'):
                if not o or o['kind']!='signature':continue
                un=d.get('username','');detail=names.get(un,un)+' ('+un+')'
            elif act in ('template_import','template_delete','template_assign'):
                if act=='template_assign':
                    if not o or o['kind']!='inspection':continue
                    detail='1 bozza'
                else:
                    if not o or o['kind']!='template':continue
                    detail=(d.get('module') or 'M01')+' · '+(d.get('name') or '')
            elif act=='instrument':
                if not o or o['kind']!='instrument':continue
                before=js(r['previous']);after=r['_after'] if isinstance(r['_after'],dict) else d
                detail=(d.get('type') or '')+' '+(d.get('serial') or d.get('model') or '')
                detail+=' · '+('; '.join(diff(before,after,self.INSTR_LABELS)) if before else 'inserito nel registro')
            elif act=='restore':
                info=js(r['previous']) or {};detail=str(info.get('objects',0))+' oggetti, '+str(info.get('documents',0))+' documenti, '+str(info.get('users',0))+' utenti; copia di recupero conservata'
            res.append({'at':r['created_at'],'user':r['user'],'user_name':names.get(r['user'],r['user'] or 'sistema'),'category':cat,'action':act,'label':label,'detail':detail,'ref':ref})
        # azioni di gruppo (associazione modello, rilettura): una riga sola per gli eventi ravvicinati dello stesso utente
        merged=[]
        for x in res:
            m=merged[-1] if merged else None
            if m and x['action'] in ('template_assign','reread') and m['action']==x['action'] and m['user']==x['user'] and abs((dt.datetime.fromisoformat(x['at'])-dt.datetime.fromisoformat(m['last'])).total_seconds())<10:
                m['n']+=1;m['last']=x['at']
            else:merged.append(dict(x,n=1,last=x['at']))
        for m in merged:
            if m['action']=='template_assign':m['detail']=str(m['n'])+(' bozza' if m['n']==1 else ' bozze')
            elif m['action']=='reread':m['detail']=str(m['n'])+(' verbale corretto' if m['n']==1 else ' verbali corretti')
            m.pop('n');m.pop('last')
        merged.reverse()
        if since:merged=[x for x in merged if x['at'][:19]>=since[:19]]
        if until:merged=[x for x in merged if x['at'][:19]<until[:19]]
        if user:merged=[x for x in merged if x['user']==user]
        if category:merged=[x for x in merged if x['category']==category]
        total=len(merged)
        users=sorted({x['user'] for x in res if x['user']})
        return {'rows':merged[:limit],'total':total,'truncated':total>limit,'users':[{'username':u,'name':names.get(u,u)} for u in users],
          'categories':[{'id':k,'label':l} for k,l in self.OPLOG_CATEGORIES]}
    # --- backups ------------------------------------------------------------------------------
    def _snapshot(self):
        with self.lock:
            c=self.connect()
            try:
                c.execute('BEGIN');meta={r['key']:r['value'] for r in c.execute('SELECT * FROM meta')}
                objs=[dict(r) for r in c.execute('SELECT * FROM objects ORDER BY id')]
                events=[dict(r) for r in c.execute('SELECT * FROM events ORDER BY created_at,id')]
                users=[dict(r) for r in c.execute('SELECT * FROM users ORDER BY username')]
                docs=[dict(r) for r in c.execute('SELECT sha,filename,created_at FROM documents ORDER BY sha')];c.execute('COMMIT')
            finally:c.close()
        return {'format':'VerbalizzAI.AD','format_version':FORMAT_VERSION,'app_version':APP_VERSION,
          'meta':meta,'objects':objs,'events':events,'users':users,'documents':docs}
    def export_backup(self,target=None,include_documents=True):
        """Write a backup to a file and return its path. Since 0.3.23 archive.json is streamed row by row from a
        consistent SQLite read snapshot (WAL): low memory and no lock held, so other users keep saving meanwhile.
        Same file format as before. Full backups are self-contained; data backups refer to the document folder."""
        target=Path(target) if target else self.backups/('tmp_'+uid()+'.zip');tmp=target.with_name(target.name+'.part')
        c=self.connect()
        try:
            with ZipFile(tmp,'w',ZIP_DEFLATED) as z:
                h=hashlib.sha256();size=0
                with z.open('archive.json','w',force_zip64=True) as out:
                    def w(text):
                        nonlocal size
                        b=text.encode('utf-8');h.update(b);size+=len(b);out.write(b)
                    c.execute('BEGIN')
                    meta={r['key']:r['value'] for r in c.execute('SELECT * FROM meta')}
                    version=int(meta['format_version'])
                    w('{"format":"VerbalizzAI.AD","format_version":'+jdump(version)+',"app_version":'+jdump(APP_VERSION)+',"meta":'+jdump(meta))
                    for key,sql in (('objects','SELECT * FROM objects ORDER BY id'),('events','SELECT * FROM events ORDER BY created_at,id'),('users','SELECT * FROM users ORDER BY username')):
                        w(',"'+key+'":[');first=True
                        for r in c.execute(sql):
                            w(('' if first else ',')+jdump(dict(r)));first=False
                        w(']')
                    docs=[dict(r) for r in c.execute('SELECT sha,filename,created_at FROM documents ORDER BY sha')];c.execute('COMMIT')
                    w(',"documents":'+jdump(docs)+'}')
                files={'archive.json':{'sha256':h.hexdigest(),'size':size}}
                if include_documents:
                    for d in docs:
                        blob=self._document_bytes(d['sha']);name='files/'+d['sha']+'.bin'
                        z.writestr(name,blob);files[name]={'sha256':sha(blob),'size':len(blob)}
                manifest={'format':'VerbalizzAI.AD.backup','format_version':version,'created_at':now(),
                  'documents':'included' if include_documents else 'external','files':files}
                z.writestr('manifest.json',jdump(manifest))
            with open(tmp,'rb+') as f:os.fsync(f.fileno())
            os.replace(tmp,target)
        finally:
            if c.in_transaction:c.execute('ROLLBACK')
            c.close()
            if tmp.exists():tmp.unlink()
        return target
    def _document_bytes(self,digest):
        f=self.docstore/(digest+'.bin')
        if f.exists():
            blob=f.read_bytes()
            if sha(blob)==digest:return blob
        blob=self.document(digest)[1]
        if sha(blob)!=digest:raise ValueError('Documento non integro nel database e nessuna copia valida: '+digest)
        self._store_file(digest,blob)
        return blob
    @staticmethod
    def verify_backup(source,docstore=None):
        """source: path or bytes. Returns (archive, loader, manifest); loader(sha)->bytes."""
        src=io.BytesIO(source) if isinstance(source,(bytes,bytearray)) else Path(source)
        size=len(source) if isinstance(source,(bytes,bytearray)) else src.stat().st_size
        if size>8*1024**3:raise ValueError('Backup troppo grande.')
        with ZipFile(src) as z:
            names=z.namelist()
            if len(names)!=len(set(names)) or len(names)>200000:raise ValueError('Parti duplicate o troppe parti nel backup.')
            m=json.loads(z.read('manifest.json'))
            if m.get('format')!='VerbalizzAI.AD.backup' or m.get('format_version') not in (1,FORMAT_VERSION):raise ValueError('Formato backup non supportato.')
            if set(names)!=set(m['files'])|{'manifest.json'}:raise ValueError('Elenco file del backup non coerente.')
            for n,info in m['files'].items():
                h=hashlib.sha256();total=0
                with z.open(n) as f:
                    for chunk in iter(lambda:f.read(1<<20),b''):h.update(chunk);total+=len(chunk)
                if total!=info['size'] or h.hexdigest()!=info['sha256']:raise ValueError('Backup danneggiato: '+n)
            a=json.loads(z.read('archive.json'))
        if a.get('format')!='VerbalizzAI.AD' or a.get('format_version') not in (1,FORMAT_VERSION) or a.get('format_version')!=m.get('format_version'):raise ValueError('Archivio non supportato.')
        if any(not isinstance(a.get(k),list) for k in ['objects','events','documents']):raise ValueError('Archivio incompleto.')
        if not isinstance(a.get('users',[]),list):raise ValueError('Utenti non validi.')
        if not isinstance(a.get('meta'),dict) or a['meta'].get('format_version')!=str(a.get('format_version')):raise ValueError('Metadati archivio non validi.')
        ids={r['id'] for r in a['objects']}
        if len(ids)!=len(a['objects']):raise ValueError('Identificatori duplicati.')
        docs={r['sha']:r for r in a['documents']}
        if len(docs)!=len(a['documents']):raise ValueError('Documenti duplicati.')
        loaded={}
        allowed={'plant','asset','inspection','template','export','instrument','signature','settings','mailing'}
        for r in a['objects']:
            d=json.loads(r['data']);loaded[r['id']]=(r['kind'],d)
            if not isinstance(d,dict) or r['kind'] not in allowed or not isinstance(r['revision'],int) or r['revision']<1:raise ValueError('Oggetto non valido.')
        event_ids=set()
        for r in a['events']:
            known=r['object_id'] in loaded or str(r['object_id']).startswith('user:')
            if r['id'] in event_ids or not known or not isinstance(r['action'],str):raise ValueError('Registro delle modifiche non valido.')
            event_ids.add(r['id'])
            if r.get('previous') is not None:json.loads(r['previous'])
        for u in a.get('users',[]):
            if not all(isinstance(u.get(k),str) and u.get(k) for k in ('username','name','role','salt','hash')) or u['role'] not in ROLES+('ispettore',):raise ValueError('Utente non valido nel backup.')
        def ref(oid,kind):
            if oid and (oid not in loaded or loaded[oid][0]!=kind):raise ValueError('Relazione '+kind+' non valida.')
        for oid,(kind,d) in loaded.items():
            if kind=='plant':
                profiles=d.get('profiles',{})
                if not isinstance(profiles,dict):raise ValueError('Stato impianto non valido.')
                for module,profile in profiles.items():
                    plantstate.module_of({'module':module})
                    if not isinstance(profile,dict) or not isinstance(profile.get('revision'),int) or profile['revision']<1:
                        raise ValueError('Revisione stato impianto non valida.')
                    state=profile.get('state')
                    if not isinstance(state,dict) or any(not isinstance(state.get(k),dict) for k in ('plant','flags','tests')) or not isinstance(state.get('samples'),list):
                        raise ValueError('Contenuti stato impianto non validi.')
                    ref(profile.get('source_id'),'inspection')
                    if profile.get('source_id') and loaded[profile['source_id']][1].get('plant_id')!=oid:raise ValueError('Fonte stato di un altro impianto.')
                    seen=set()
                    for sample in state['samples']:
                        aid=sample.get('asset_id');ref(aid,'asset')
                        if not aid or aid in seen or loaded[aid][1].get('plant_id')!=oid:raise ValueError('Elemento stato impianto non valido.')
                        seen.add(aid)
            if kind in ('asset','inspection'):ref(d['plant_id'],'plant')
            if kind=='inspection':
                if not isinstance(d.get('samples'),list) or not isinstance(d.get('header'),dict):raise ValueError('Verifica incompleta.')
                ref(d.get('template_id'),'template');ref(d.get('baseline_id'),'inspection');ref(d.get('revision_of'),'inspection');ref(d.get('issued_export_id'),'export')
                if d.get('baseline_id') and loaded[d['baseline_id']][1]['plant_id']!=d['plant_id']:raise ValueError('Storico collegato a un altro impianto.')
                for s in d['samples']:
                    ref(s.get('asset_id'),'asset')
                    if s.get('asset_id') and loaded[s['asset_id']][1]['plant_id']!=d['plant_id']:raise ValueError('Campione collegato a un altro impianto.')
            if kind=='export':ref(d['inspection_id'],'inspection');ref(d.get('template_id'),'template')
            if kind=='mailing':ref(d.get('inspection_id'),'inspection');ref(d.get('export_id'),'export')
            for k in ['source_sha','original_sha','adapted_sha','sha','pdf_sha']:
                if d.get(k) and d[k] not in docs:raise ValueError('Documento sorgente mancante.')
        external=m.get('documents')=='external'
        if external:
            if docstore is None:raise ValueError('Questa copia contiene solo i dati: serve la cartella «documenti» dei backup.')
            expected={'archive.json'}
            for digest in docs:
                f=Path(docstore)/(digest+'.bin')
                if not f.exists():raise ValueError('Documento mancante nella cartella documenti: '+digest[:12]+'…')
                if sha(f.read_bytes())!=digest:raise ValueError('Documento non integro nella cartella documenti: '+digest[:12]+'…')
            loader=lambda digest:(Path(docstore)/(digest+'.bin')).read_bytes()
        else:
            expected={'archive.json'}|{'files/'+digest+'.bin' for digest in docs}
            for digest in docs:
                if 'files/'+digest+'.bin' not in m['files'] or m['files']['files/'+digest+'.bin']['sha256']!=digest:raise ValueError('Documento non integro.')
            def loader(digest):
                with ZipFile(src) as z:return z.read('files/'+digest+'.bin')
        if set(m['files'])!=expected:raise ValueError('Parti non riferite nell’archivio.')
        return a,loader,m
    _backup_lock=threading.Lock()
    def auto_backup(self,prefix='auto'):
        with self._backup_lock:
            name=prefix+'_'+dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.adbackup.zip'
            target=self.export_backup(self.backups/name,include_documents=False)
            self._last_backup=time.monotonic();self.backup_error=''
            self._prune()
            return str(target)
    def _prune(self):
        autos=sorted(self.backups.glob('auto_*.adbackup.zip'),reverse=True)
        keep=set(autos[:AUTO_KEEP_RECENT]);daily={}
        limit=(dt.datetime.now()-dt.timedelta(days=AUTO_KEEP_DAYS)).strftime('%Y%m%d')
        for p in autos:
            day=p.name.split('_')[1]
            if day>=limit:daily[day]=p          # oldest of each day wins (list is newest first)
        keep|=set(daily.values())
        for p in autos:
            if p not in keep:p.unlink()
    def restore(self,source):
        a,loader,m=self.verify_backup(source,self.docstore)
        with self.lock:
            before=self.auto_backup('prima_ripristino')
            def op(c):
                for table in ['objects','documents','events','meta','users']:c.execute('DELETE FROM '+table)
                for k,v in a['meta'].items():c.execute('INSERT INTO meta VALUES(?,?)',(k,str(v)))
                for r in a['objects']:c.execute('INSERT INTO objects(id,kind,data,revision,updated_at,updated_by) VALUES(?,?,?,?,?,?)',(r['id'],r['kind'],r['data'],r['revision'],r['updated_at'],r.get('updated_by','')))
                for r in a['events']:c.execute('INSERT INTO events(id,object_id,action,previous,created_at,user) VALUES(?,?,?,?,?,?)',(r['id'],r['object_id'],r['action'],r['previous'],r['created_at'],r.get('user','')))
                for u in a.get('users',[]):c.execute('INSERT INTO users VALUES(?,?,?,?,?,?,?)',(u['username'],u['name'],u['role'],u['salt'],u['hash'],int(u.get('active',1)),u.get('created_at',now())))
                for r in a['documents']:
                    blob=loader(r['sha']);self._store_file(r['sha'],blob)
                    c.execute('INSERT INTO documents VALUES(?,?,?,?)',(r['sha'],r['filename'],blob,r['created_at']))
                info={'objects':len(a['objects']),'documents':len(a['documents']),'users':len(a.get('users',[])),'recovery_copy':before}
                # Evento nel registro delle operazioni (object_id «user:…» per restare valido anche per le versioni precedenti nella verifica del backup).
                c.execute('INSERT INTO events(id,object_id,action,previous,created_at,user) VALUES(?,?,?,?,?,?)',(uid(),'user:'+(self.actor or ''),'restore',jdump(info),now(),self.actor))
                return info
            result=self.mutate(op,True)
            self._migrate_plant_state()
            return result
