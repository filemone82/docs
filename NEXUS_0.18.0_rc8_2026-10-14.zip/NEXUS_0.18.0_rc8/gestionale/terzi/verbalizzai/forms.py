"""Moduli M02 (scariche atmosferiche) e M03 (luoghi con pericolo di esplosione).

Lettura, preparazione del template, bozza e controlli sono guidati da una specifica:
ogni gruppo di caselle è individuato dal testo che lo precede nel modello (ancora),
cercato in ordine nel documento. Un gruppo assente viene segnalato, mai inventato.
"""
from __future__ import annotations
import copy, re, xml.etree.ElementTree as ET
from .wordio import NS, q, txt, clean, sha, package, paragraphs

# (chiave, ancora, opzioni, etichette, multipla, tipo, scheda)
# tipo: 'struct' = caratteristica dell'impianto (riproposta alla verifica successiva)
#       'result' = esito della verifica attuale (azzerato nella nuova bozza)
OKKO = (['ok', 'ko'], ['Conforme', 'Non conforme'])
DOCS = (['present', 'total', 'partial', 'absent'], ['Presente', 'Totale', 'Parziale', 'Non presente'])
COMMON_HEAD = [
    ('check_type', r'ha(?:nno)? proceduto ad effettuare la verifica:', ['periodic', 'extra'], ['Periodica', 'Straordinaria'], False, 'struct', 'inspection'),
]
COMMON_TAIL = [
    ('outcome', r'l.esito della verifica è:', ['positive', 'negative'], ['Positivo', 'Negativo'], False, 'result', 'review'),
]
FORMS = {
 'M02': {
  'name': 'M02 · Scariche atmosferiche', 'title': r'SCARICHE ATMOSFERICHE', 'model': 'M02-PO01_dpr',
  'object': r'dei dispositivi di protezione contro le scariche atmosferiche installati',
  'period': 'select',
  'groups': COMMON_HEAD + [
    ('dvr', r'Documento di valutazione del rischio:', *DOCS, True, 'struct', 'docs'),
    ('risk', r'Valutazione del rischio', ['self', 'not_self', 'na'], ['Struttura autoprotetta', 'Struttura NON autoprotetta (servono ulteriori misure)', 'n.a.'], False, 'struct', 'tests'),
    ('captators', r'Captatori:', ['rods', 'wires', 'mesh', 'natural'], ['Aste', 'Funi sospese', 'Conduttori a maglia', 'Captatori naturali'], True, 'struct', 'tests'),
    ('downconductors', r'Calate:', ['intentional', 'rebar', 'natural'], ['Elementi intenzionali', 'Ferri di armatura', 'Componenti naturali'], True, 'struct', 'tests'),
    ('electrode', r'Dispersore:', ['type_a', 'type_b', 'natural'], ['Dispersore di tipo A', 'Dispersore di tipo B', 'Componenti naturali'], True, 'struct', 'tests'),
    ('conservation', r'Condizioni di conservazione', ['good', 'fair', 'sufficient', 'inadequate'], ['Buone', 'Discrete', 'Sufficienti', 'Inadeguate'], False, 'result', 'tests'),
    ('connections', r'Connessioni:', ['ok', 'ko'], ['Presenti e integre, senza discontinuità', 'Danneggiate / mancanti'], False, 'result', 'tests'),
    ('corrosion', r'Segni di corrosione:', ['absent', 'present'], ['Assenti / non significativi', 'Presenti / rilevanti'], False, 'result', 'tests'),
    ('equipotential', r'Conduttori equipotenziali:', ['ok', 'ko'], ['Presenti e intatti', 'Mancanti / danneggiati'], False, 'result', 'tests'),
    ('distances', r'Distanze di sicurezza:', ['ok', 'ko'], ['Rispettate', 'Non conformi'], False, 'result', 'tests'),
    ('continuity', r'Misure di continuit', ['positive', 'negative'], ['Positivo / conforme', 'Negativo / non conforme'], False, 'result', 'tests'),
    ('spd_criteria', r'criteri per le installazioni relative agli SPD', ['yes', 'no', 'na'], ['Sì', 'No', 'n.a.'], False, 'struct', 'tests'),
    ('spd_indicators', r'Indicatori di funzionamento SPD', ['ok', 'ko'], ['Presenti, integri e funzionanti', 'Mancanti, danneggiati o non funzionanti'], False, 'result', 'tests'),
    ('spm', r'SPM \(se applicabile\)', ['shields', 'spd', 'earthing'], ['Schermi magnetici', 'Sistemi SPD', 'Messa a terra ed equipotenziali'], True, 'struct', 'tests'),
  ] + COMMON_TAIL + [
    ('period', r'Periodicit', ['two', 'five'], ['2 anni', '5 anni'], False, 'struct', 'inspection'),
  ],
  'cells': [('tests.risk_note', 'Valutazione del rischio'), ('tests.lps_description', 'LPS esterno (se presente)'),
            ('tests.visual_note', 'Ispezione visiva LPS esterno (se presente)'), ('tests.lps_int_note', 'LPS interno (se presente)'),
            ('tests.spm_note', 'SPM (se applicabile)')],
  'blocks': [('plant.description', r'Descrizione dell.impianto', r'Documentazione')],
  'measures': ['earth_re'],
  'sections': [
    ('plant', 'Impianto', [('text', 'plant.client_name'), ('text', 'plant.site_name'), ('text', 'plant.address'), ('group', 'environment'), ('area', 'plant.description')]),
    ('docs', 'Documentazione', [('group', 'dvr')]),
    ('tests', 'Valutazione del rischio', [('group', 'risk'), ('area', 'tests.risk_note')]),
    ('tests', 'LPS esterno', [('area', 'tests.lps_description'), ('group', 'captators'), ('group', 'downconductors'), ('group', 'electrode')]),
    ('tests', 'Ispezione visiva LPS esterno', [('area', 'tests.visual_note'), ('group', 'conservation'), ('group', 'connections'), ('group', 'corrosion'), ('group', 'equipotential'), ('group', 'distances')]),
    ('tests', 'Prove LPS esterno', [('area', 'sampling.main'), ('text', 'tests.earth_re'), ('group', 'continuity')]),
    ('tests', 'LPS interno e SPM', [('area', 'tests.lps_int_note'), ('group', 'spd_criteria'), ('group', 'spd_indicators'), ('area', 'tests.spm_note'), ('group', 'spm')]),
  ],
 },
 'M03': {
  'name': 'M03 · Luoghi con pericolo di esplosione', 'title': r'PERICOLO DI ESPLOSIONE', 'model': 'M03-PO01_dpr',
  'object': r'installato in luoghi con pericolo di esplosione per la presenza di',
  'period': 'two',
  'groups': COMMON_HEAD + [
    ('atmosphere', r'installato in luoghi con pericolo di esplosione per la presenza di:', ['gas', 'dust'], ['Gas, vapori o nebbie', 'Polveri'], True, 'struct', 'plant'),
    ('zones_gas', r'Pericolo di esplosione per la presenza di gas, vapori e/o nebbie:', ['z0', 'z1', 'z2', 'na'], ['Zona 0', 'Zona 1', 'Zona 2', 'n.a.'], True, 'struct', 'plant'),
    ('zones_dust', r'Pericolo di esplosione per la presenza di polveri', ['z20', 'z21', 'z22', 'na'], ['Zona 20', 'Zona 21', 'Zona 22', 'n.a.'], True, 'struct', 'plant'),
    ('dvr', r'Documento di valutazione del rischio:', *DOCS, True, 'struct', 'docs'),
    ('plant_docs', r'Documentazione dell.impianto elettrico:', *DOCS, True, 'struct', 'docs'),
    ('certs', r'Certificazioni dei componenti installati:', *DOCS, True, 'struct', 'docs'),
    ('risk_method', r'Valutazione del rischio', ['gas_std', 'dust_std', 'na'], ['CEI EN 60079-10-1 (Guida CEI 31-35), gas', 'CEI EN 60079-10-2 (Guida CEI 31-56), polveri', 'n.a.'], True, 'struct', 'tests'),
    ('cl_gas', r'Check list impianti elettrici con pericolo di esplosione per la presenza di gas', ['yes', 'no'], ['Applicabile', 'Non applicabile'], False, 'struct', 'tests'),
    ('den_constr', r'Costruzioni elettriche:', *OKKO, False, 'result', 'tests'),
    ('den_inst', r'Impianti:', *OKKO, False, 'result', 'tests'),
    ('den_env', r'Condizioni ambientali:', *OKKO, False, 'result', 'tests'),
    ('i_constr', r'Costruzioni elettriche:', *OKKO, False, 'result', 'tests'),
    ('i_inst', r'Impianti:', *OKKO, False, 'result', 'tests'),
    ('i_env', r'Condizioni ambientali:', *OKKO, False, 'result', 'tests'),
    ('cl_dust', r'Check list impianti elettrici con pericolo di esplosione per la presenza di polveri', ['yes', 'no'], ['Applicabile', 'Non applicabile'], False, 'struct', 'tests'),
    ('dust_ex', r'Costruzioni Ex:', *OKKO, False, 'result', 'tests'),
  ] + COMMON_TAIL,
  'cells': [('tests.risk_note', 'Valutazione del rischio')],
  'blocks': [('plant.environments', r'descrizione degli ambienti interessati dal rischio esplosione:', r'Descrizione dell.impianto'),
             ('plant.description', r'Descrizione dell.impianto', r'Classificazione dell.impianto')],
  'measures': [],
  'sections': [
    ('plant', 'Impianto', [('text', 'plant.client_name'), ('text', 'plant.site_name'), ('text', 'plant.address'), ('area', 'plant.environments'), ('area', 'plant.description')]),
    ('plant', 'Atmosfere e classificazione', [('group', 'atmosphere'), ('group', 'zones_gas'), ('group', 'zones_dust')]),
    ('docs', 'Documentazione', [('group', 'dvr'), ('group', 'plant_docs'), ('group', 'certs')]),
    ('tests', 'Valutazione del rischio', [('group', 'risk_method'), ('area', 'tests.risk_note')]),
    ('tests', 'Check list gas, vapori e nebbie', [('group', 'cl_gas'), ('area', 'sampling.main'), ('group', 'den_constr'), ('group', 'den_inst'), ('group', 'den_env'), ('group', 'i_constr'), ('group', 'i_inst'), ('group', 'i_env')]),
    ('tests', 'Check list polveri', [('group', 'cl_dust'), ('group', 'dust_ex')]),
  ],
 },
}
GROUP_TITLES = {'environment': 'Classificazione dell’ambiente (solo VerbalizzAI, non stampata nel Word)', 'check_type': 'Tipo verifica', 'outcome': 'Esito della verifica', 'period': 'Periodicità',
  'dvr': 'Documento di valutazione del rischio', 'risk': 'Valutazione del rischio', 'captators': 'Captatori', 'downconductors': 'Calate',
  'electrode': 'Dispersore', 'conservation': 'Condizioni di conservazione dell’LPS', 'connections': 'Connessioni',
  'corrosion': 'Segni di corrosione', 'equipotential': 'Conduttori equipotenziali', 'distances': 'Distanze di sicurezza',
  'continuity': 'Continuità delle connessioni equipotenziali', 'spd_criteria': 'Criteri per le installazioni SPD definiti',
  'spd_indicators': 'Indicatori di funzionamento SPD', 'spm': 'SPM', 'atmosphere': 'Pericolo di esplosione per la presenza di',
  'zones_gas': 'Zone gas, vapori e nebbie', 'zones_dust': 'Zone polveri', 'plant_docs': 'Documentazione dell’impianto elettrico',
  'certs': 'Certificazioni dei componenti installati', 'risk_method': 'Valutazione del rischio secondo', 'cl_gas': 'Check list gas',
  'den_constr': 'Ex “d”, “e”, “n” · costruzioni elettriche', 'den_inst': 'Ex “d”, “e”, “n” · impianti', 'den_env': 'Ex “d”, “e”, “n” · condizioni ambientali',
  'i_constr': 'Ex “i” · costruzioni elettriche', 'i_inst': 'Ex “i” · impianti', 'i_env': 'Ex “i” · condizioni ambientali',
  'cl_dust': 'Check list polveri', 'dust_ex': 'Costruzioni Ex (polveri)'}
FIELD_LABELS = {'plant.site_name': 'Denominazione dell’impianto · seconda riga', 'plant.description': 'Descrizione dell’impianto', 'plant.environments': 'Ambienti interessati dal rischio esplosione',
  'tests.risk_note': 'Valutazione del rischio · note', 'tests.lps_description': 'LPS esterno · descrizione',
  'tests.visual_note': 'Ispezione visiva · note', 'tests.lps_int_note': 'LPS interno · note', 'tests.spm_note': 'SPM · note',
  'sampling.main': 'Criteri di campionamento adottati', 'tests.earth_re': 'Resistenza di terra Rearth · Ω'}

def detect_module(text):
    head = ' '.join(text.split()[:40]).upper()
    if 'MESSA A TERRA' in head: return 'M01'
    for m, f in FORMS.items():
        if re.search(f['title'], head): return m
    return None

# --- lettura lineare: testo + segnaposto delle caselle, in ordine di documento ------------
BOX_ON, BOX_OFF = '■', '□'
def stream(root):
    out, cbs = [], []
    def walk(e):
        if e.tag == q('w:sdt') and e.find('w:sdtPr/w14:checkbox', NS) is not None:
            from .wordio import box_state
            on = box_state(e)
            cbs.append(e); out.append(BOX_ON if on else BOX_OFF); return
        if e.tag == q('w:t'): out.append(e.text or '')
        elif e.tag == q('w:tab'): out.append(' ')
        elif e.tag == q('w:br'): out.append('\n')
        for c in e: walk(c)
        if e.tag == q('w:p'): out.append('\n')
        elif e.tag == q('w:tc'): out.append('\t')
    walk(root.find('w:body', NS))
    return ''.join(out), cbs

def locate(s, spec):
    """Per ogni gruppo: indici delle caselle che seguono la sua ancora (ricerca in ordine)."""
    marks = [i for i, ch in enumerate(s) if ch in (BOX_ON, BOX_OFF)]
    pos, found, missing = 0, {}, []
    for key, anchor, opts, *_ in spec['groups']:
        m = re.compile(anchor, re.I).search(s, pos)
        if not m: missing.append(key); continue
        after = [k for k, p in enumerate(marks) if p >= m.end()][:len(opts)]
        if len(after) < len(opts): missing.append(key); continue
        found[key] = after; pos = marks[after[-1]] + 1
    return found, missing, marks

def unline(v):
    """Toglie le linee di compilazione (____ e ……) e i segnaposto ///."""
    v = re.sub(r'[_…]+|\.{4,}', ' ', v or '')
    v = '\n'.join(re.sub(r'[ \t]+', ' ', l).strip() for l in v.split('\n'))
    v = re.sub(r'\n{3,}', '\n\n', v).strip()
    return '' if re.fullmatch(r'[/\s.\-]*|,?\s*in qualit. di\s*', v) else v

def between(s, a, b, start=0):
    m = re.compile(a, re.I).search(s, start)
    if not m: return ''
    n = re.compile(b, re.I).search(s, m.end())
    return s[m.end():n.start()] if n else ''

def cell_after(s, title):
    i = s.find(title)
    if i < 0: return ''
    j = s.find('\t', i)
    return s[i + len(title): j if j >= 0 else None]

def instruments(root):
    out = []
    for t in root.iter(q('w:tbl')):
        rows = [[clean(txt(c)) for c in r.findall('w:tc', NS)] for r in t.findall('w:tr', NS)]
        if rows and 'tipologia strumento' in ' '.join(rows[0]).lower():
            for v in rows[1:]:
                if len(v) >= 5 and v[0] != '***' and any(x and not re.fullmatch(r'[/\-* ]+', x) for x in v[1:]):
                    out.append(dict(zip(['type', 'brand', 'model', 'serial', 'calibration'], v[:5])))
    return out

def model_refs(z, root):
    refs = set()
    for name in z.namelist():
        if re.match(r'word/(document|footer\d+|header\d+)\.xml', name):
            for m in re.finditer(r'(M0\d-PO01[_ ]?dpr, rev\. *\d+ del \d{2}\.\d{2}\.\d{4})', re.sub(r'<[^>]+>', '', z.read(name).decode('utf-8', 'ignore'))):
                refs.add(m.group(1))
    return sorted(refs)

def parse_form(data, filename, module, with_tree=False):
    spec = FORMS[module]
    from .wordio import MISMATCHED_BOXES; MISMATCHED_BOXES.clear()
    z, root = package(data); paragraphs(root)
    s, cbs = stream(root)
    found, missing, marks = locate(s, spec)
    flags = {g[0]: {k: False for k in g[2]} for g in spec['groups']}
    for key, opts, *_ in [(g[0], g[2]) for g in spec['groups']]:
        for k, idx in zip(opts, found.get(key, [])):
            flags[key][k] = s[marks[idx]] == BOX_ON
    warnings = ['Gruppo non trovato: ' + GROUP_TITLES.get(k, k) for k in missing]
    from .wordio import MISMATCHED_BOXES
    if MISMATCHED_BOXES: warnings.append(str(len(MISMATCHED_BOXES)) + ' caselle hanno lo stato interno di Word diverso dal simbolo visibile: è stato letto il simbolo visibile (☒ / ☐). Controllare le scelte.')
    hm = re.search(r'Verbale n\.\s*(\S+)\s+del\s+(\S+)', s)
    number, date = (unline(hm.group(1)), unline(hm.group(2))) if hm else ('', '')
    im = re.search(r'Verificator[ei]\s+(.*?),?\s+in data\s+(.*?),?\s+ha(?:nno)? proceduto', s, re.S)
    inspectors, indate = (unline(im.group(1)), unline(im.group(2))) if im else ('', '')
    dates = re.findall(r'\d{2}/\d{2}/\d{4}', indate)
    span = re.search(r'(\d{2})-(\d{2})/(\d{2})/(\d{4})', indate)
    if span: dates = [f'{span[1]}/{span[3]}/{span[4]}', f'{span[2]}/{span[3]}/{span[4]}']
    line = lambda pat: (re.search(pat, s) or [None, ''])[1]
    em = re.search(r'Data di emissione del Verbale\s*\t\s*Il Verificator\w*\s*\t\s*(.*?)\t\s*(.*?)\t', s, re.S)
    sm = re.search(r'presso l.Azienda[^\n]*\n(.*?)\n[ \t]*ubicata in', s, re.S)
    site = ' – '.join(x for x in (unline(l) for l in (sm.group(1).split('\n') if sm and sm.group(1).count('\n') < 3 else [])) if x)
    plant = {'client_name': unline(line(r'presso l.Azienda[ \t]*(.*)')), 'site_name': site, 'address': unline(line(r'ubicata in[ \t]*(.*)'))}
    for path, a, b in spec['blocks']:
        plant[path.split('.')[1]] = unline(between(s, a + r'\s*\n', r'\n\s*' + b))
    tests = {}
    for path, title in spec['cells']:
        tests[path.split('.')[1]] = unline(cell_after(s, title))
    re_m = re.search(r'Rearth\s*=\s*([^\n]*?)\s*[\u03a9\u2126]', s)
    tests['earth_re'] = unline(re_m.group(1)) if re_m else ''
    samp = re.search(r'Criteri di campionamento adottati:(.*?)\t', s, re.S)
    head = {'number': number, 'report_date': date, 'start_date': dates[0] if dates else date, 'end_date': dates[-1] if dates else date,
            'in_date': indate, 'inspectors': inspectors, 'reason': unline(line(r'a seguito di[ \t]*(.*)')),
            'issued_date': unline(em.group(1)) if em else '', 'due_date': unline(line(r'Prossima verifica da eseguirsi entro:[ \t]*(.*)')),
            'hours': unline(line(r'pari a \(circa\):\s*(.*?)\s*ore')),
            'representative': unline(between(s, r'era presente:', r'Data di emissione del Verbale')),
            'signature_names': unline(em.group(2)) if em else ''}
    notes = unline(between(s, r'Note e/o osservazioni:', r'Periodicit|Prossima verifica'))
    ncs = unline(between(s, r'non conformit. rilevate sono consistite in:', r'Note e/o osservazioni:'))
    refs = model_refs(z, root)
    d = {'module': module, 'header': head, 'plant': plant, 'flags': flags, 'tests': tests,
         'sampling': {'main': unline(samp.group(1)) if samp else ''}, 'samples': [], 'attachments': {},
         'instruments': instruments(root), 'notes': notes, 'document_notes': notes, 'nonconformities': ncs,
         'confirmed': False, 'acknowledgements': {}, 'template_id': None, 'u0': '',
         'source_meta': {'filename': filename, 'sha256': sha(data), 'warnings': warnings, 'missing_groups': missing,
            'headers': [{'number': number, 'date': date}], 'emission_dates': [head['issued_date']] if head['issued_date'] else [],
            'model_refs': refs, 'object_ok': bool(re.search(spec['object'], s, re.I)),
            'foreign_object': [m for m, f in FORMS.items() if m != module and re.search(f['object'], s, re.I)],
            'template_reference': ' '.join(refs)}}
    if with_tree: return d, root, z, s, cbs, found
    return d

def empty_form_draft(baseline):
    """Nuova bozza: caratteristiche riproposte, risultati e dati della verifica azzerati."""
    module = baseline['module']; spec = FORMS[module]; d = copy.deepcopy(baseline)
    for k in ['number', 'report_date', 'start_date', 'end_date', 'in_date', 'issued_date', 'hours', 'representative', 'due_date', 'reason', 'signature_names']:
        d['header'][k] = ''
    for key, _a, opts, _l, _m, kind, _s in spec['groups']:
        if kind == 'result': d['flags'][key] = {k: False for k in opts}
    d['carried'] = {'tests.' + k: d['tests'].get(k, '') for k in spec['measures'] if unline(d['tests'].get(k, ''))}
    d['notes'] = ''; d['nonconformities'] = ''; d['instruments'] = []; d['confirmed'] = False; d['acknowledgements'] = {}
    d['source_meta'] = {'baseline': baseline.get('source_meta', {}).get('filename', ''), 'warnings': []}
    d['samples'] = []; d['attachments'] = {}
    return d

# Scelte gestite solo da VerbalizzAI: non lette dal Word né scritte nel modello.
EXTRA_GROUPS = {'M02': [('environment', None, ['ordinary', 'fire', 'construction', 'medical', 'explosion'],
                         ['Ordinario', 'Maggior rischio incendio', 'Cantiere', 'Uso medico', 'Pericolo esplosione'], True, 'struct', 'plant')]}

def schema():
    return {m: {'name': f['name'], 'period': f['period'],
                'groups': {g[0]: {'options': g[2], 'labels': g[3], 'multi': g[4], 'kind': g[5], 'title': GROUP_TITLES.get(g[0], g[0])} for g in f['groups'] + EXTRA_GROUPS.get(m, [])},
                'sections': [{'tab': t, 'title': title, 'items': items} for t, title, items in f['sections']]}
            for m, f in FORMS.items()} | {'_labels': FIELD_LABELS}

# --- controlli M02 / M03 (consultivi, come per il M01) -----------------------------------
# Campi a cui si riferisce ciascun controllo M02/M03 («Vai al campo» ed evidenza a colori), se non indicati dal controllo.
FORM_TARGETS = {'C02': ['header.number', 'header.report_date'], 'C03': ['header.reason', 'check_type'], 'C04': ['header.start_date', 'header.end_date'],
    'C05': ['header.issued_date'], 'C06': ['header.due_date'], 'C08': ['outcome'], 'C09': ['instruments'], 'C10': ['header.hours'], 'C11': ['header.representative'],
    'C12': ['template'], 'C14': ['header.inspectors'], 'D01': ['confirm'],
    'S01': ['risk'], 'S02': ['captators', 'downconductors', 'electrode'], 'S03': ['conservation', 'connections', 'corrosion', 'equipotential', 'distances'],
    'S04': ['continuity', 'tests.earth_re'], 'S05': ['spd_criteria', 'spd_indicators'], 'S06': ['environment', 'period'],
    'X01': ['atmosphere'], 'X02': ['zones_gas'], 'X03': ['zones_dust'], 'X04': ['risk_method']}
FORM_NO_TARGET = {'C13': 'Frase dell’oggetto del verbale storico: riguarda il documento originale, non un campo della maschera.'}
NEGATIVE = {'M02': [('conservation', 'inadequate'), ('connections', 'ko'), ('corrosion', 'present'), ('equipotential', 'ko'),
                    ('distances', 'ko'), ('continuity', 'negative'), ('spd_indicators', 'ko')],
            'M03': [(g, 'ko') for g in ('den_constr', 'den_inst', 'den_env', 'i_constr', 'i_inst', 'i_env', 'dust_ex')]}
ALWAYS_ONE = {'M02': ['check_type', 'outcome', 'period', 'risk', 'spd_criteria'], 'M03': ['check_type', 'outcome', 'cl_gas', 'cl_dust']}

def evaluate_form(d, template=None):
    from .rules import number as num, date, due, filled
    module = d['module']; spec = FORMS[module]
    h, p, f, t = d.get('header', {}), d.get('plant', {}), d.get('flags', {}), d.get('tests', {})
    meta = d.get('source_meta', {}); hist = bool(d.get('historical')); out = []
    def add(code, title, status='OK', detail='Coerente con i dati disponibili.', targets=None):
        out.append({'code': code, 'title': title, 'status': status, 'detail': detail, 'blocking': False,
                    'acknowledgement': d.get('acknowledgements', {}).get(code, ''),
                    'targets': list(targets) if targets is not None else list(FORM_TARGETS.get(code, []))})
    def issues(code, title, errors=(), warnings=(), ok='Coerente con i dati disponibili.', targets=None):
        errors, warnings = list(errors), list(warnings)
        add(code, title, 'Errore' if errors else 'Avviso' if warnings else 'OK', '; '.join(errors + warnings) if errors or warnings else ok, targets)
    sel = lambda g: [k for k, v in f.get(g, {}).items() if v]
    T = lambda g: GROUP_TITLES.get(g, g)
    multi = {g[0]: g[4] for g in spec['groups']}
    # C00 compilazione delle scelte singole
    err = []; tg = []
    for g in multi:
        if not multi[g] and len(sel(g)) > 1: err.append(T(g) + ': più voci selezionate'); tg.append(g)
    for g in ALWAYS_ONE[module]:
        if not sel(g): err.append(T(g) + ': nessuna selezione'); tg.append(g)
    for g in meta.get('missing_groups', []): err.append(T(g) + ': gruppo assente nel documento'); tg.append(g)
    issues('C00', 'Compilazione dei blocchi a scelta', err, targets=tg)
    # C01-C02 numero e data
    err = []; tg = []
    if not re.fullmatch(r'[A-Z]{2}/\d{3,4}/\d{2}', h.get('number', '')): err.append('numero assente o diverso dal formato XX/nnn/aa (XX/nnnn/aa oltre il 999)'); tg.append('header.number')
    if not date(h.get('report_date')): err.append('data del verbale mancante o non nel formato gg/mm/aaaa (' + (h.get('report_date') or 'vuota') + ')'); tg.append('header.report_date')
    pf = h.get('number', '')[:2]
    if (pf == 'VP' and sel('check_type') == ['extra']) or (pf == 'VS' and sel('check_type') == ['periodic']): err.append('prefisso ' + pf + ' non coerente con il tipo di verifica (VP periodica, VS straordinaria)'); tg += ['header.number', 'check_type']
    issues('C01', 'Numero e data del verbale', err, targets=tg)
    yy = re.search(r'/(\d{2})$', h.get('number', '')); rd = date(h.get('report_date'))
    add('C02', 'Anno nel numero verbale', 'Non verificabile' if not yy or not rd else 'Errore' if int(yy[1]) != rd.year % 100 else 'OK',
        'Anno coerente.' if yy and rd and int(yy[1]) == rd.year % 100 else 'Confrontare anno del numero e data del verbale.')
    # C03 tipo di verifica
    issues('C03', 'Tipo di verifica e motivo', ['Straordinaria senza motivo indicato'] if sel('check_type') == ['extra'] and not filled(h.get('reason')) else [],
           ['Motivo compilato per una verifica periodica'] if sel('check_type') == ['periodic'] and filled(h.get('reason')) else [])
    # C04 date di esecuzione
    st, en = date(h.get('start_date')), date(h.get('end_date'))
    issues('C04', 'Date di esecuzione', ['date di inizio/fine mancanti o non valide'] if not st or not en else ['fine precedente all’inizio'] if en < st else [],
           ['fine verifica diversa dalla data del verbale'] if st and en and rd and en != rd else [],
           targets=['header.end_date', 'header.report_date'] if st and en and en >= st else ['header.start_date', 'header.end_date'])
    # C05 emissione
    em = date(h.get('issued_date'))
    issues('C05', 'Data di emissione', ['emissione mancante o non valida'] if not em else ['emissione precedente alla fine della verifica'] if en and em < en else [])
    # C06 prossima verifica
    yrs = 2 if spec['period'] == 'two' else (2 if sel('period') == ['two'] else 5 if sel('period') == ['five'] else None)
    sc = date(h.get('due_date')); exp = due(h.get('start_date') or h.get('report_date'), yrs) if yrs else ''
    if not sc: add('C06', 'Prossima verifica', 'Errore', 'Scadenza assente o non valida.')
    elif not exp: add('C06', 'Prossima verifica', 'Non verificabile', 'Manca la data di inizio o la periodicità.')
    else: add('C06', 'Prossima verifica', 'Errore' if sc > date(exp) else 'Avviso' if sc < date(exp) else 'OK',
              ('Periodicità biennale (luoghi con pericolo di esplosione). ' if spec['period'] == 'two' else '') + 'Calcolo del profilo AD da inizio verifica: ' + exp)
    # C07 documentazione
    err = []; tg = []
    for g in [x[0] for x in spec['groups'] if x[6] == 'docs']:
        a = sel(g); n0 = len(err)
        if ('present' in a) == ('absent' in a): err.append(T(g) + ': presenza non univoca')
        if 'present' in a and len([x for x in a if x in ('total', 'partial')]) != 1: err.append(T(g) + ': estensione totale/parziale non univoca')
        if 'absent' in a and ('total' in a or 'partial' in a): err.append(T(g) + ': estensione indicata con documento non presente')
        if len(err) > n0: tg.append(g)
    issues('C07', 'Documentazione', err, targets=tg)
    # C08 esito
    negs = [T(g) + ' = ' + spec_label(module, g, k) for g, k in NEGATIVE[module] if f.get(g, {}).get(k)]
    nc = d.get('nonconformities', '').strip(); hasnc = filled(nc) and not re.match(r'^nessuna\b', nc, re.I)
    out_ = sel('outcome'); err = []
    if out_ == ['positive'] and (negs or hasnc): err.append('esito positivo con risultati negativi o non conformità descritte (' + ', '.join(negs or ['non conformità nel testo']) + ')')
    if out_ == ['negative'] and not hasnc: err.append('esito negativo senza descrizione delle non conformità')
    if len(out_) != 1: err.append('esito non univoco')
    issues('C08', 'Congruenza con l’esito', err, ok='Esito e registrazioni coerenti; un esito negativo documentato è ammesso.',
           targets=['outcome'] + ([g + '.' + k for g, k in NEGATIVE[module] if f.get(g, {}).get(k)] + (['nonconformities'] if hasnc else []) if out_ == ['positive'] else ['nonconformities'] if out_ == ['negative'] else []))
    # C09 strumentazione
    instr = d.get('instruments', []); ref = st or rd
    exp_ = [(x.get('type') or '?') + ' ' + (x.get('serial') or '') + ': taratura scaduta il ' + x['calibration_due'] for x in instr if ref and date(x.get('calibration_due')) and date(x['calibration_due']) < ref]
    issues('C09', 'Strumentazione', (['nessuno strumento indicato'] if not instr else ['righe strumenti incomplete'] if any(not all(filled(x.get(k)) for k in ('type', 'brand', 'model', 'serial', 'calibration')) for x in instr) else []) + exp_)
    ic_ = [(x.get('type') or '?') + ' ' + (x.get('serial') or '') + ': controllo interno scaduto il ' + x['internal_check_due'] for x in instr if ref and date(x.get('internal_check_due')) and date(x['internal_check_due']) < ref]
    if ic_ and not hist: add('C09b', 'Controllo interno degli strumenti', 'Avviso', '; '.join(ic_), ['instruments'])
    issues('C10', 'Ore uomo', ['durata mancante o non positiva'] if not (num(h.get('hours')) or 0) > 0 else [])
    issues('C11', 'Rappresentante del datore di lavoro', ['nome e qualifica mancanti'] if not filled(h.get('representative')) else [])
    # C12 modello e revisione
    if hist:
        refs = meta.get('model_refs', []); err = []; warn = []
        if refs and not any(r.startswith(spec['model']) for r in refs): err.append('riferimento al modello diverso da ' + spec['model'])
        if len(set(refs)) > 1: warn.append('nel documento compaiono revisioni diverse del modello: ' + '; '.join(refs))
        issues('C12', 'Modello e revisione', err, warn, ok='Riferimento al modello univoco: ' + (refs[0] if refs else 'non trovato'))
        # C13 oggetto della verifica
        err = []
        if not meta.get('object_ok'): err.append('manca la frase dell’oggetto prevista dal modello ' + module)
        for m in meta.get('foreign_object', []): err.append('presente la frase dell’oggetto del modello ' + m)
        issues('C13', 'Oggetto della verifica', err)
        sig = meta.get('signature_names') or h.get('signature_names', '')
        norm_ = lambda x: sorted(re.findall(r'[a-zà-ü]{3,}', (x or '').lower()))
        issues('C14', 'Verificatori: intestazione e firma', ['verificatore non indicato'] if not filled(h.get('inspectors')) else [],
               ['nomi nel blocco firma diversi dall’intestazione'] if sig and norm_(sig) != norm_(h.get('inspectors')) else [])
    else:
        add('C12', 'Modello e revisione', 'Avviso' if template else 'Avviso', ('Template ' + template.get('name', '') + ' associato. Verificare la prima emissione su questa revisione.') if template else 'Nessun template selezionato: per produrre il Word occorre caricarlo.')
        if template: out[-1]['info'] = True
        issues('C14', 'Verificatori', ['verificatore non indicato'] if not filled(h.get('inspectors')) else [])
    if module == 'M02': _rules_m02(d, sel, T, issues, add, num, filled)
    else: _rules_m03(d, sel, T, issues, add, filled)
    if not hist and not d.get('confirmed'):
        add('D01', 'Dati riproposti dallo storico', 'Avviso', 'Caratteristiche e documentazione dell’impianto da confermare per la verifica attuale.')
    car = {k: v for k, v in (d.get('carried') or {}).items() if str(v) == str(t.get(k.split('.', 1)[1], ''))}
    if not hist and car:
        add('D03', 'Misure riproposte dall’ultima verifica', 'Avviso', 'Valori non ancora modificati né confermati: ' + ', '.join(FIELD_LABELS.get(k, k) for k in car) + '.', list(car))
    return out

def spec_label(module, g, k):
    for x in FORMS[module]['groups']:
        if x[0] == g: return x[3][x[2].index(k)]
    return k

def _lps_present(d, sel):
    desc = d.get('tests', {}).get('lps_description', '')
    return bool(sel('captators') or sel('downconductors') or sel('electrode')) or (bool(desc.strip()) and not re.match(r'\s*non\s+(applicabile|presente)', desc, re.I))

def _rules_m02(d, sel, T, issues, add, num, filled):
    t = d.get('tests', {}); present = _lps_present(d, sel)
    issues('S01', 'Valutazione del rischio', warnings=['struttura NON autoprotetta senza LPS esterno descritto: valutare misure ed esito'] if sel('risk') == ['not_self'] and not present else [])
    if present:
        issues('S02', 'LPS esterno · tipologia', [T(g) + ': nessuna selezione' for g in ('captators', 'downconductors', 'electrode') if not sel(g)],
               targets=[g for g in ('captators', 'downconductors', 'electrode') if not sel(g)])
        issues('S03', 'Ispezione visiva LPS esterno', [T(g) + ': selezionare una voce' for g in ('conservation', 'connections', 'corrosion', 'equipotential', 'distances') if len(sel(g)) != 1],
               targets=[g for g in ('conservation', 'connections', 'corrosion', 'equipotential', 'distances') if len(sel(g)) != 1])
        err = []
        tg = []
        if len(sel('continuity')) != 1: err.append('continuità: selezionare l’esito'); tg.append('continuity')
        if num(t.get('earth_re')) is None: err.append('Rearth mancante o non numerica'); tg.append('tests.earth_re')
        if not filled(d.get('sampling', {}).get('main')) or re.fullmatch(r'\s*n\.?\s*a\.?\s*', d.get('sampling', {}).get('main', ''), re.I): err.append('criterio di campionamento non indicato'); tg.append('sampling.main')
        issues('S04', 'Prove LPS esterno', err, targets=tg)
    else:
        add('S02', 'LPS esterno · tipologia', 'OK', 'LPS esterno non presente o non applicabile.')
        filled_vis = [T(g) for g in ('conservation', 'connections', 'corrosion', 'equipotential', 'distances') if sel(g)]
        issues('S03', 'Ispezione visiva LPS esterno', warnings=['LPS esterno non presente ma ispezione compilata: ' + ', '.join(filled_vis)] if filled_vis else [])
        w = []
        if filled(t.get('earth_re')): w.append('LPS esterno non presente ma Rearth = ' + t['earth_re'] + ' Ω riportata: chiarire a cosa si riferisce')
        if sel('continuity'): w.append('LPS esterno non presente ma esito di continuità indicato')
        issues('S04', 'Prove LPS esterno', warnings=w)
    w = []
    if sel('spd_criteria') == ['yes'] and not sel('spd_indicators'): w.append('criteri SPD definiti ma indicatori di funzionamento non indicati')
    issues('S05', 'LPS interno · SPD', warnings=w)
    env = sel('environment')
    if d.get('historical'):
        add('S06', 'Ambiente e periodicità', 'Non verificabile', 'Classificazione non presente nel modello M02: si indica nelle nuove verifiche.')
    elif not env:
        add('S06', 'Ambiente e periodicità', 'Avviso', 'Indicare la classificazione dell’ambiente: ordinario → 5 anni, altrimenti 2 anni.')
    elif 'ordinary' in env and len(env) > 1:
        add('S06', 'Ambiente e periodicità', 'Errore', '«Ordinario» selezionato insieme ad altre classificazioni.', ['environment'])
    else:
        exp = 'five' if env == ['ordinary'] else 'two'
        issues('S06', 'Ambiente e periodicità', warnings=['Periodicità diversa dal profilo AD per l’ambiente indicato (atteso ' + ('5' if exp == 'five' else '2') + ' anni)'] if sel('period') and sel('period') != [exp] else [])

def _rules_m03(d, sel, T, issues, add, filled):
    atm = sel('atmosphere'); gas, dust = 'gas' in atm, 'dust' in atm
    issues('X01', 'Atmosfere esplosive (gas / polveri)', ['nessuna atmosfera indicata: manca la scelta gas, vapori o nebbie / polveri'] if not atm else [])
    # Zone: atmosfera spuntata → almeno una zona del suo gruppo (n.a. non ammesso); atmosfera non spuntata → zone vuote o n.a. (OK).
    # Si evidenzia la zona sbagliata, non la casella dell'atmosfera.
    for code, g, flag, zones in (('X02', 'zones_gas', gas, ['z0', 'z1', 'z2']), ('X03', 'zones_dust', dust, ['z20', 'z21', 'z22'])):
        z = sel(g); zs = [k for k in z if k in zones]; err = []; warn = []; tg = [g]
        if 'na' in z and zs: err.append(T(g) + ': n.a. selezionato insieme a zone'); tg = [g + '.na']
        elif flag and not zs and 'na' in z: err.append(T(g) + ': atmosfera indicata, n.a. non ammesso (indicare almeno una zona)'); tg = [g + '.na']
        elif flag and not zs: err.append(T(g) + ': atmosfera indicata ma nessuna zona selezionata')
        elif not flag and zs: warn.append(T(g) + ': zone indicate ma atmosfera non selezionata'); tg = [g + '.' + k for k in zs]
        issues(code, T(g), err, warn, targets=tg)
    rm = sel('risk_method'); warn = []
    if atm:
        if gas and 'gas_std' not in rm: warn.append('atmosfera gas senza valutazione secondo CEI EN 60079-10-1')
        if dust and 'dust_std' not in rm: warn.append('atmosfera polveri senza valutazione secondo CEI EN 60079-10-2')
        if not gas and 'gas_std' in rm: warn.append('valutazione gas indicata senza atmosfera gas')
        if not dust and 'dust_std' in rm: warn.append('valutazione polveri indicata senza atmosfera polveri')
    if 'na' in rm and len(rm) > 1: warn.append('n.a. selezionato insieme a una norma')
    issues('X04', 'Valutazione del rischio', warnings=warn)
    err, warn, tg = [], [], []
    if sel('cl_gas') == ['yes']:
        bad = [g for g in ('den_constr', 'den_inst', 'den_env') if len(sel(g)) != 1]; err += [T(g) + ': selezionare conforme / non conforme' for g in bad]; tg += bad
        empty = [g for g in ('i_constr', 'i_inst', 'i_env') if not sel(g)]; warn += [T(g) + ': non compilato (se non vi sono costruzioni Ex “i”, indicarlo nelle note)' for g in empty]; tg += empty
        if not filled(d.get('sampling', {}).get('main')): err.append('criterio di campionamento delle misure di continuità non indicato'); tg.append('sampling.main')
    elif sel('cl_gas') == ['no'] and any(sel(g) for g in ('den_constr', 'den_inst', 'den_env', 'i_constr', 'i_inst', 'i_env')):
        warn.append('check list non applicabile ma voci compilate'); tg += ['cl_gas.no'] + [g for g in ('den_constr', 'den_inst', 'den_env', 'i_constr', 'i_inst', 'i_env') if sel(g)]
    if atm and (sel('cl_gas') == ['yes']) != gas: warn.append('applicabilità della check list gas non coerente con l’atmosfera indicata'); tg += ['cl_gas']
    issues('X05', 'Check list gas, vapori e nebbie', err, warn, targets=tg)
    err, warn, tg = [], [], []
    if sel('cl_dust') == ['yes'] and len(sel('dust_ex')) != 1: err.append('costruzioni Ex: selezionare conforme / non conforme'); tg.append('dust_ex')
    if sel('cl_dust') == ['no'] and sel('dust_ex'): warn.append('check list non applicabile ma voce compilata'); tg += ['cl_dust.no', 'dust_ex']
    if atm and (sel('cl_dust') == ['yes']) != dust: warn.append('applicabilità della check list polveri non coerente con l’atmosfera indicata'); tg += ['cl_dust']
    issues('X06', 'Check list polveri', err, warn, targets=tg)
