"""Lettura minima di un foglio Excel (.xlsx) con la sola libreria standard.

Serve per importare il registro strumenti M07 (scheda «Apparecchiature»).
Le celle con formula restituiscono il valore calcolato salvato da Excel; se il file è stato
salvato da un programma che non calcola le formule, quelle celle risultano vuote
(conteggiate in `formulas_without_value`).
"""
from __future__ import annotations
import datetime as dt, io, posixpath, re
import xml.etree.ElementTree as ET
from zipfile import ZipFile, BadZipFile

NS = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
      'pr': 'http://schemas.openxmlformats.org/package/2006/relationships'}
MAX_BYTES = 20 * 1024 * 1024
MAX_XML = 80 * 1024 * 1024


def _col(ref):
    """«AB12» → indice di colonna 0-based (27)."""
    n = 0
    for ch in re.match(r'[A-Z]+', ref).group(0):
        n = n * 26 + ord(ch) - 64
    return n - 1


def _text(el):
    """Testo di una stringa condivisa o in linea (anche con formattazione a pezzi)."""
    return ''.join(t.text or '' for t in el.iter('{%s}t' % NS['m']))


class Workbook:
    def __init__(self, data: bytes):
        if len(data) > MAX_BYTES:
            raise ValueError('File Excel troppo grande (massimo 20 MB).')
        try:
            self.z = ZipFile(io.BytesIO(data))
            names = set(self.z.namelist())
        except BadZipFile:
            raise ValueError('Il file non è un Excel .xlsx valido (salvarlo come «Cartella di lavoro di Excel»).')
        if 'xl/workbook.xml' not in names:
            raise ValueError('Il file non è un Excel .xlsx valido.')
        if sum(i.file_size for i in self.z.infolist()) > MAX_XML * 4:
            raise ValueError('File Excel non valido (contenuto troppo grande).')
        wb = ET.fromstring(self._read('xl/workbook.xml'))
        pr = wb.find('m:workbookPr', NS)
        self.date1904 = pr is not None and pr.get('date1904') in ('1', 'true')
        rels = ET.fromstring(self._read('xl/_rels/workbook.xml.rels'))
        targets = {r.get('Id'): r.get('Target') for r in rels.findall('pr:Relationship', NS)}
        self.sheets = {}
        for s in wb.findall('m:sheets/m:sheet', NS):
            t = targets.get(s.get('{%s}id' % NS['r']), '')
            path = t.lstrip('/') if t.startswith('/') else posixpath.normpath(posixpath.join('xl', t))
            self.sheets[s.get('name')] = path
        self.shared = []
        if 'xl/sharedStrings.xml' in names:
            sst = ET.fromstring(self._read('xl/sharedStrings.xml'))
            self.shared = [_text(si) for si in sst.findall('m:si', NS)]

    def _read(self, name):
        info = self.z.getinfo(name)
        if info.file_size > MAX_XML:
            raise ValueError('File Excel non valido (foglio troppo grande).')
        return self.z.read(name)

    def rows(self, sheet_name):
        """Righe del foglio come liste di valori (str, float, bool o None), dalla riga 1.
        Restituisce (righe, celle con formula senza valore calcolato)."""
        path = self.sheets.get(sheet_name)
        if not path:
            lower = {k.casefold().strip(): v for k, v in self.sheets.items()}
            path = lower.get(sheet_name.casefold().strip())
        if not path:
            raise ValueError('Nel file manca la scheda «' + sheet_name + '». Schede presenti: ' + ', '.join(self.sheets) + '.')
        root = ET.fromstring(self._read(path))
        out, missing = {}, 0
        for row in root.iter('{%s}row' % NS['m']):
            r = int(row.get('r')) if row.get('r') else (max(out) + 1 if out else 1)
            vals = {}
            for i, c in enumerate(row.findall('m:c', NS)):
                col = _col(c.get('r')) if c.get('r') else i
                t = c.get('t', 'n')
                v = c.find('m:v', NS)
                f = c.find('m:f', NS)
                if t == 'inlineStr':
                    is_ = c.find('m:is', NS)
                    val = _text(is_) if is_ is not None else ''
                elif v is None or v.text is None:
                    if f is not None:
                        missing += 1
                    val = None
                elif t == 's':
                    val = self.shared[int(v.text)]
                elif t in ('str',):
                    val = v.text
                elif t == 'b':
                    val = v.text == '1'
                elif t == 'e':
                    val = None          # errore di formula (#VALORE!, #N/D…)
                else:
                    try:
                        val = float(v.text)
                    except ValueError:
                        val = v.text
                if isinstance(val, str):
                    val = val.strip()
                    if val == '':
                        val = None
                vals[col] = val
            if vals:
                width = max(vals) + 1
                out[r] = [vals.get(j) for j in range(width)]
        if not out:
            return [], missing
        return [out.get(r, []) for r in range(1, max(out) + 1)], missing

    def to_date(self, value):
        """Numero di serie di Excel (o testo gg/mm/aaaa) → «gg/mm/aaaa»; '' se non è una data."""
        if value is None or value == '':
            return ''
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if not 1 <= value < 2958466:
                return ''
            base = dt.date(1904, 1, 1) if self.date1904 else dt.date(1899, 12, 30)
            return (base + dt.timedelta(days=int(value))).strftime('%d/%m/%Y')
        s = str(value).strip()
        m = re.fullmatch(r'(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})', s) or None
        if m:
            try:
                return dt.date(int(m[3]), int(m[2]), int(m[1])).strftime('%d/%m/%Y')
            except ValueError:
                return ''
        m = re.fullmatch(r'(\d{4})-(\d{2})-(\d{2})(?:[ T].*)?', s)
        if m:
            try:
                return dt.date(int(m[1]), int(m[2]), int(m[3])).strftime('%d/%m/%Y')
            except ValueError:
                return ''
        return ''
