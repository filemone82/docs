"""Conversione Word → PDF con LibreOffice (gratuito), in modalità invisibile.

Cerca LibreOffice in quest'ordine: percorso indicato in config.json («libreoffice»),
programmi nel PATH (soffice / libreoffice), cartelle standard di Windows, Linux e macOS.
Le conversioni sono eseguite una alla volta, con un profilo LibreOffice separato:
non interferiscono con un LibreOffice aperto dall'utente sullo stesso PC.
"""
from __future__ import annotations
import os, shutil, subprocess, tempfile, threading
from pathlib import Path

_lock = threading.Lock()
_configured = None          # percorso da config.json, impostato da app.py
TIMEOUT = 180               # secondi per una conversione

CANDIDATES = [
    r'C:\Program Files\LibreOffice\program\soffice.exe',
    r'C:\Program Files (x86)\LibreOffice\program\soffice.exe',
    '/usr/bin/soffice', '/usr/bin/libreoffice', '/usr/lib/libreoffice/program/soffice',
    '/opt/libreoffice/program/soffice', '/snap/bin/libreoffice',
    '/Applications/LibreOffice.app/Contents/MacOS/soffice',
]

def configure(path):
    global _configured
    _configured = (path or '').strip() or None

def find():
    """Percorso dell'eseguibile LibreOffice, oppure None se non installato."""
    if _configured and Path(_configured).is_file():
        return _configured
    for name in ('soffice', 'libreoffice'):
        p = shutil.which(name)
        if p:
            return p
    for p in CANDIDATES:
        if Path(p).is_file():
            return p
    return None

def status():
    exe = find()
    return {'available': bool(exe), 'path': exe or '',
            'hint': '' if exe else 'LibreOffice non trovato: installarlo (gratuito) oppure indicare il percorso di soffice in config.json alla voce «libreoffice».'}

def to_pdf(docx: bytes, name: str = 'verbale.docx') -> bytes:
    exe = find()
    if not exe:
        raise RuntimeError(status()['hint'])
    with _lock, tempfile.TemporaryDirectory(prefix='adpdf_') as tmp:
        src = Path(tmp) / (Path(name).stem.replace(' ', '_') + '.docx')
        src.write_bytes(docx)
        profile = Path(tmp) / 'profilo'
        cmd = [exe, '-env:UserInstallation=' + profile.resolve().as_uri(), '--headless', '--norestore',
               '--nologo', '--convert-to', 'pdf', '--outdir', tmp, str(src)]
        kw = {}
        if os.name == 'nt':
            kw['creationflags'] = 0x08000000  # CREATE_NO_WINDOW
        try:
            subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=TIMEOUT, check=False, **kw)
        except subprocess.TimeoutExpired:
            raise RuntimeError('Conversione in PDF troppo lenta (oltre %d s): riprovare.' % TIMEOUT)
        out = src.with_suffix('.pdf')
        if not out.is_file() or out.stat().st_size == 0:
            raise RuntimeError('LibreOffice non ha prodotto il PDF. Chiudere eventuali finestre di LibreOffice bloccate e riprovare.')
        return out.read_bytes()


# --- pagine degli allegati dai segnalibri del PDF ----------------------------------------------
import re as _re, zlib as _zlib
def _objects(pdf):
    objs={}
    for m in _re.finditer(rb'(\d+)\s+0\s+obj(.*?)endobj',pdf,_re.S):objs[int(m.group(1))]=m.group(2)
    return objs
def _text(raw):
    raw=raw.strip()
    if raw.startswith(b'<'):
        h=bytes.fromhex(raw[1:-1].decode('ascii'))
        return h[2:].decode('utf-16-be','replace') if h[:2]==b'\xfe\xff' else h.decode('latin-1')
    s=raw[1:-1]
    s=_re.sub(rb'\\([()\\])',rb'\1',s)
    return s[2:].decode('utf-16-be','replace') if s[:2]==b'\xfe\xff' else s.decode('latin-1','replace')
def outline(pdf: bytes):
    """[(titolo, indice pagina da 0)] dei segnalibri del PDF, più il numero totale di pagine.
    Legge solo PDF con oggetti non compressi (come quelli di LibreOffice)."""
    marks,total=outline_points(pdf)
    return [(t,pg) for t,pg,_ in marks],total
def outline_points(pdf: bytes):
    """Come outline(), con in più la quota verticale (punti PDF dal basso) del punto di arrivo
    di ciascun segnalibro, quando il PDF la indica (/XYZ, come fa LibreOffice); altrimenti None."""
    objs=_objects(pdf);order=[]
    def kids(n,seen=0):
        body=objs.get(n,b'')
        if _re.search(rb'/Type\s*/Pages\b',body):
            k=_re.search(rb'/Kids\s*\[(.*?)\]',body,_re.S)
            for r in _re.findall(rb'(\d+)\s+0\s+R',k.group(1) if k else b''):kids(int(r))
        elif _re.search(rb'/Type\s*/Page\b',body):order.append(n)
    root=next((n for n,b in objs.items() if _re.search(rb'/Type\s*/Catalog\b',b)),None)
    if root is None:return [],0
    pr=_re.search(rb'/Pages\s+(\d+)\s+0\s+R',objs[root])
    if pr:kids(int(pr.group(1)))
    index={n:i for i,n in enumerate(order)};marks=[]
    for n,b in objs.items():
        t=_re.search(rb'/Title\s*(<[0-9A-Fa-f\s]*>|\((?:\\.|[^\\)])*\))',b,_re.S)
        xyz=rb'\s+0\s+R\s*(?:/XYZ\s+[-\d.]+\s+([-\d.]+))?'
        dest=_re.search(rb'/Dest\s*\[\s*(\d+)'+xyz,b)
        if not dest:
            a=_re.search(rb'/A\s+(\d+)\s+0\s+R',b) or None
            dest=_re.search(rb'/D\s*\[\s*(\d+)'+xyz,objs.get(int(a.group(1)),b'') if a else b)
        if t and dest and int(dest.group(1)) in index and _re.search(rb'/Parent',b):
            y=float(dest.group(2)) if dest.group(2) else None
            marks.append((_text(t.group(1)),index[int(dest.group(1))],y))
    marks.sort(key=lambda x:x[1]);return marks,len(order)
def annex_pages(pdf: bytes, roles):
    """Pagine di ciascun allegato: dal suo segnalibro «Allegato al Verbale…» al successivo, l'ultimo fino alla fine."""
    marks,total=outline(pdf)
    starts=[pg for title,pg in marks if title.strip().lower().startswith('allegato al verbale')]
    if len(starts)!=len(roles) or not total:return {}
    out={}
    for i,(role,start) in enumerate(zip(roles,starts)):
        end=starts[i+1]-1 if i+1<len(starts) else total-1
        if role!='-':out[role]=out.get(role,0)+max(1,end-start+1)
    return out

# --- 0.3.25 (punto 49): caratteri dei modelli --------------------------------------------------
# I modelli usano Calibri e Cambria. Su Linux non ci sono: servono i sostituti metricamente
# identici Carlito e Caladea (pacchetti fonts-crosextra-carlito e fonts-crosextra-caladea).
# Senza, LibreOffice ripiega su DejaVu: testo più largo, intestazione su quattro righe,
# codice del modello tagliato e verbali di due o tre pagine più lunghi del dovuto.
FONT_PAIRS = [('Calibri', 'Carlito'), ('Cambria', 'Caladea')]
APT_HINT = 'sudo apt install fonts-crosextra-carlito fonts-crosextra-caladea'
_fonts_cache = None

def _installed_fonts():
    """Famiglie di caratteri note al sistema, in minuscolo. Vuoto se non si riesce a chiederlo."""
    exe = shutil.which('fc-list')
    if not exe:
        return None
    try:
        out = subprocess.run([exe, '--format', '%{family}\n'], stdout=subprocess.PIPE,
                             stderr=subprocess.DEVNULL, timeout=20, check=False)
    except Exception:
        return None
    names = set()
    for line in out.stdout.decode('utf-8', 'replace').splitlines():
        for part in line.split(','):
            if part.strip():
                names.add(part.strip().lower())
    return names

def fonts_status(refresh: bool = False):
    """Stato dei caratteri: ok, elenco dei mancanti e suggerimento per installarli.

    Su Windows Calibri e Cambria fanno parte del sistema e fc-list non esiste: in quel caso
    non si segnala nulla. Il risultato viene tenuto in memoria (i caratteri non cambiano
    durante l'esecuzione), salvo richiesta esplicita di rilettura."""
    global _fonts_cache
    if _fonts_cache is not None and not refresh:
        return _fonts_cache
    have = _installed_fonts()
    if have is None:
        _fonts_cache = {'checked': False, 'ok': True, 'missing': [], 'hint': ''}
        return _fonts_cache
    missing = [pair for pair in FONT_PAIRS if not any(n.lower() in have for n in pair)]
    _fonts_cache = {
        'checked': True,
        'ok': not missing,
        'missing': [' o '.join(p) for p in missing],
        'hint': '' if not missing else
            'Caratteri mancanti sul server: ' + '; '.join(' o '.join(p) for p in missing) +
            '. I verbali verrebbero impaginati con un caratter'
            'e di ripiego, più largo: intestazione e numero di pagine sbagliati. Installarli con: ' + APT_HINT,
    }
    return _fonts_cache
