"""Invio dei verbali via email (0.3.24), solo libreria standard.

Impostazioni del server di posta: file `posta.json` nella cartella dell'archivio, fuori dal
database e quindi fuori dai backup (contiene la password della casella). Si modificano
dal menu «Impostazioni email» (solo amministratore); la password non viene mai rimandata al browser.
Testi standard (oggetto, messaggio, firma): nell'archivio (oggetto settings «mail_texts»).
"""
from __future__ import annotations
import json, os, re, smtplib, socket, ssl
from email.message import EmailMessage
from email.utils import formataddr, make_msgid, formatdate
from pathlib import Path

DEFAULTS = {'host': 'smtps.aruba.it', 'port': 465, 'security': 'ssl', 'username': 'elettrico@adsrl.net',
            'password': '', 'from_address': 'elettrico@adsrl.net', 'from_name': 'AD S.r.l.',
            'office_copy': 'elettrico@adsrl.net'}
SECURITY = ('ssl', 'starttls', 'none')     # «none» solo per prove su server locale
DEFAULT_TEXTS = {
    'subject': 'Verbale di verifica n. {numero}{revisione} del {data_verbale} – {cliente} – D.P.R. 462/01',
    # ATTENZIONE: la frase della prossima verifica sta su una RIGA PROPRIA. Con esito negativo
    # {prossima_verifica} e' vuoto e la riga sparisce da sola (vedi render). Se la si accorpa alla
    # frase sulla conservazione, con esito negativo sparirebbero tutte e due.
    'body': ('Spett.le {cliente},\n\n'
             'in allegato trasmettiamo il verbale n. {numero}{revisione} del {data_verbale}, '
             'relativo alla {tipo_verifica} presso {impianto}, {indirizzo}, eseguita in data '
             '{data_verifica} ai sensi del D.P.R. 462/01.\n\n'
             'Esito della verifica: {esito}.\n\n'
             'Il verbale va conservato e reso disponibile agli organi di vigilanza.\n'
             'La prossima verifica è da eseguirsi entro il {prossima_verifica}.\n\n'
             'Per chiarimenti è possibile rispondere a questa email.\n\n'
             'Cordiali saluti'),
    'signature': ('Il verificatore: {verificatore}\n\n'
                  'AD S.r.l. a socio unico\n'
                  'Organismo abilitato D.P.R. 462/01 – Decreto Direttoriale MIMIT 29.09.2025\n'
                  'Corso Giovanni Arnaud n. 28, 10088 Volpiano (TO)\n'
                  'tel. 011.9881759 · elettrico@adsrl.net · ad@pec.adsrl.net · www.adsrl.net'),
}
PLACEHOLDERS = [('numero', 'Numero del verbale (es. VP/649/26)'),
                ('revisione', 'Revisione del verbale (« rev. 1»; vuoto alla prima emissione)'),
                ('data_verbale', 'Data del verbale'),
                ('data_verifica', 'Data o periodo della verifica'), ('modulo', 'Modulo (M01, M02, M03)'),
                ('tipo_verifica', 'Tipo di verifica in parole (es. verifica periodica dell’impianto di messa a terra)'),
                ('cliente', 'Ragione sociale'), ('impianto', 'Ragione sociale e denominazione (seconda riga)'),
                ('indirizzo', 'Sede dell’impianto'), ('verificatore', 'Verificatore / verificatori'),
                ('esito', 'Esito (positivo / negativo)'), ('prossima_verifica', 'Prossima verifica entro')]
ADDR = re.compile(r'^[A-Za-z0-9._%+\-\']+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$')
MODULE_WORDS = {'M01': 'impianto di messa a terra', 'M02': 'impianto di protezione contro le scariche atmosferiche',
                'M03': 'impianto elettrico in luogo con pericolo di esplosione'}


def split_addresses(text):
    """«a@x.it; b@y.it, c@z.it» → lista; errore se un indirizzo non è valido."""
    out = []
    for part in re.split(r'[;,\s]+', str(text or '')):
        part = part.strip().strip('<>')
        if not part:
            continue
        if not ADDR.match(part):
            raise ValueError('Indirizzo email non valido: ' + part)
        if part.lower() not in [x.lower() for x in out]:
            out.append(part)
    return out


class MailConfig:
    def __init__(self, directory):
        self.path = Path(directory) / 'posta.json'

    def load(self):
        cfg = dict(DEFAULTS)
        if self.path.exists():
            try:
                cfg.update(json.loads(self.path.read_text('utf-8')))
            except (OSError, ValueError):
                pass
        env = os.environ.get('VERBALIZZAI_SMTP_PASSWORD')
        if env:
            cfg['password'] = env
        return cfg

    def public(self):
        """Impostazioni da mostrare nel browser: mai la password."""
        cfg = self.load()
        pub = {k: cfg[k] for k in DEFAULTS if k != 'password'}
        pub['password_set'] = bool(cfg.get('password'))
        pub['password_env'] = bool(os.environ.get('VERBALIZZAI_SMTP_PASSWORD'))
        pub['configured'] = bool(cfg['host'] and cfg['from_address'] and cfg['office_copy'] and (cfg['password'] or cfg['security'] == 'none'))
        pub['file'] = str(self.path)
        return pub

    def save(self, data):
        cfg = self.load() if self.path.exists() else dict(DEFAULTS)
        if os.environ.get('VERBALIZZAI_SMTP_PASSWORD') and self.path.exists():
            try:
                cfg['password'] = json.loads(self.path.read_text('utf-8')).get('password', '')
            except (OSError, ValueError):
                cfg['password'] = ''
        new = {}
        new['host'] = str(data.get('host') or '').strip()
        try:
            new['port'] = int(data.get('port'))
        except (TypeError, ValueError):
            raise ValueError('Porta del server di posta non valida.')
        if not 1 <= new['port'] <= 65535:
            raise ValueError('Porta del server di posta non valida.')
        new['security'] = data.get('security') if data.get('security') in SECURITY else 'ssl'
        new['username'] = str(data.get('username') or '').strip()
        new['from_name'] = str(data.get('from_name') or '').strip()[:80]
        for k, label in (('from_address', 'mittente'), ('office_copy', 'copia per l’ufficio')):
            v = split_addresses(data.get(k))
            if len(v) != 1:
                raise ValueError('Indicare un solo indirizzo ' + label + '.')
            new[k] = v[0]
        if not new['host'] or not re.fullmatch(r'[A-Za-z0-9.\-]+', new['host']):
            raise ValueError('Server di posta (SMTP) non valido: es. smtps.aruba.it')
        if data.get('password'):
            new['password'] = str(data['password'])
        elif data.get('clear_password'):
            new['password'] = ''
        else:
            new['password'] = cfg.get('password', '')
        tmp = self.path.with_suffix('.tmp')
        tmp.write_text(json.dumps(new, ensure_ascii=False, indent=1), 'utf-8')
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        os.replace(tmp, self.path)
        return self.public()


def values_for(d):
    """Valori dei campi {…} per un verbale."""
    h = d.get('header', {}); p = d.get('plant', {}); m = d.get('module') or 'M01'
    ct = {k for k, v in (d.get('flags', {}).get('check_type') or {}).items() if v}
    kind = 'verifica straordinaria' if ('extra' in ct and 'periodic' not in ct) else 'verifica periodica'
    out = {k for k, v in (d.get('flags', {}).get('outcome') or {}).items() if v}
    st, en = h.get('start_date', ''), h.get('end_date', '')
    impianto = p.get('client_name', '') + (' – ' + p['site_name'] if p.get('site_name') else '')
    rev = d.get('rev_index')
    return {'numero': h.get('number', ''), 'data_verbale': h.get('report_date', ''),
            # 0.3.27 (punto 27d): un verbale riesaminato ha stesso numero e data nuova; senza
            # questo campo il cliente riceverebbe due mail apparentemente identiche.
            'revisione': (' rev. ' + str(rev)) if rev else '',
            'data_verifica': st if (not en or st == en) else st + ' – ' + en,
            'modulo': m, 'tipo_verifica': kind + ' dell’' + MODULE_WORDS.get(m, 'impianto'),
            'cliente': p.get('client_name', ''), 'impianto': impianto, 'indirizzo': p.get('address', ''),
            'verificatore': h.get('inspectors', ''),
            'esito': 'positivo' if out == {'positive'} else 'negativo' if out == {'negative'} else '',
            'prossima_verifica': h.get('due_date', '')}


def render(text, values):
    """Sostituisce {campo}; i campi sconosciuti restano come scritti.

    0.3.27 (punto 27d): una riga i cui campi risultano TUTTI vuoti sparisce. Serve per la frase
    della prossima verifica, che con esito negativo non ha senso — non c'è una scadenza, il
    D.P.R. 462/01 prevede una verifica straordinaria — e senza questa regola uscirebbe come
    «La prossima verifica è da eseguirsi entro il .». Così la frase resta scritta da Federico nei
    testi standard, invece di essere fissata nel programma. Una riga con più campi sparisce solo
    se sono vuoti tutti: «n. {numero}{revisione}» resta, perché il numero c'è. Una riga senza
    campi non sparisce mai.
    """
    out = []
    for line in (text or '').split('\n'):
        names = re.findall(r'\{(\w+)\}', line)
        noti = [n for n in names if n in values]
        if noti and all(not str(values[n]).strip() for n in noti):
            continue
        out.append(re.sub(r'\{(\w+)\}', lambda m: str(values[m.group(1)]) if m.group(1) in values else m.group(0), line))
    return '\n'.join(out)


def unknown_fields(*texts):
    names = {k for k, _ in PLACEHOLDERS}
    return sorted({m for t in texts for m in re.findall(r'\{(\w+)\}', t or '') if m not in names})


def build(cfg, to, cc, subject, body, attachments):
    msg = EmailMessage()
    msg['From'] = formataddr((cfg.get('from_name') or '', cfg['from_address']))
    msg['To'] = ', '.join(to)
    if cc:
        msg['Cc'] = ', '.join(cc)
    msg['Reply-To'] = cfg['from_address']
    msg['Subject'] = subject
    msg['Date'] = formatdate(localtime=True)
    msg['Message-ID'] = make_msgid(domain=cfg['from_address'].split('@')[-1])
    msg.set_content(body)
    for name, data, ctype in attachments:
        main, sub = ctype.split('/', 1)
        msg.add_attachment(data, maintype=main, subtype=sub, filename=name)
    return msg


def send(cfg, msg, timeout=40):
    """Invia; restituisce la risposta del server. Errori come ValueError con testo in italiano."""
    if not cfg.get('host'):
        raise ValueError('Server di posta non configurato: impostarlo nel menu «Impostazioni email».')
    rcpt = [a for h in ('To', 'Cc', 'Bcc') for a in re.split(r'\s*,\s*', msg.get(h, '')) if a]
    try:
        if cfg['security'] == 'ssl':
            s = smtplib.SMTP_SSL(cfg['host'], cfg['port'], timeout=timeout, context=ssl.create_default_context())
        else:
            s = smtplib.SMTP(cfg['host'], cfg['port'], timeout=timeout)
        with s:
            s.ehlo()
            if cfg['security'] == 'starttls':
                s.starttls(context=ssl.create_default_context()); s.ehlo()
            if cfg.get('username') and cfg.get('password'):
                s.login(cfg['username'], cfg['password'])
            refused = s.send_message(msg, from_addr=cfg['from_address'], to_addrs=rcpt)
            if refused:
                raise ValueError('Il server ha rifiutato alcuni destinatari: ' + ', '.join(refused))
            return 'Accettato dal server ' + cfg['host']
    except smtplib.SMTPAuthenticationError:
        raise ValueError('Accesso alla casella non riuscito: controllare utente e password nel menu «Impostazioni email».')
    except smtplib.SMTPRecipientsRefused as e:
        raise ValueError('Il server ha rifiutato i destinatari: ' + ', '.join(e.recipients))
    except smtplib.SMTPException as e:
        raise ValueError('Il server di posta ha risposto con un errore: ' + str(e)[:300])
    except ssl.SSLError as e:
        raise ValueError('Connessione sicura non riuscita (' + str(e)[:120] + '): controllare porta e sicurezza (465 = SSL, 587 = STARTTLS).')
    except (socket.timeout, TimeoutError):
        raise ValueError('Il server di posta non risponde (tempo scaduto): controllare server e porta.')
    except OSError as e:
        raise ValueError('Server di posta non raggiungibile (' + str(e)[:120] + '): controllare il nome del server, la porta e la connessione.')
