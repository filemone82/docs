"""Stato riutilizzabile dell'impianto, distinto dalle rilevazioni di una verifica.

La selezione è esplicita: aggiungere un campo a una maschera non lo rende
automaticamente un attributo dell'impianto. Nessuna misura o esito è persistito
in questo stato. I dati completi restano nelle fotografie delle verifiche.
"""
import copy
import hashlib
import json

IDENTITY = ('client_name', 'site_name', 'address')
M01_GROUPS = ('environment', 'systems', 'supply', 'protections', 'earth_types',
              'dico', 'project', 'diri', 'ul', 'special', 'at_app', 'contact_app')
M01_FIELDS = ('installation_year', 'power', 'voltage', 'pod', 'cabins', 'stations',
              'if_value', 'if_unit', 'tf', 'disperser_description',
              'connections_description', 'conductors_description', 'medical_group')
DESCRIPTIONS = {'M01': (), 'M02': ('risk_note', 'lps_description', 'lps_int_note', 'spm_note'),
                'M03': ('risk_note',)}

def module_of(d):
    module = d.get('module') or 'M01'
    if module not in ('M01', 'M02', 'M03'):
        raise ValueError('Modulo impianto non valido.')
    return module

def groups(module):
    if module == 'M01': return M01_GROUPS
    from .forms import FORMS, EXTRA_GROUPS
    return tuple(g[0] for g in FORMS[module]['groups'] + EXTRA_GROUPS.get(module, [])
                 if g[5] == 'struct' and g[0] not in ('check_type', 'period'))

def schema(module):
    from .wordio import GROUPS, LABELS
    from .forms import FORMS, EXTRA_GROUPS, GROUP_TITLES, FIELD_LABELS
    fields = M01_FIELDS if module == 'M01' else ('description', 'environments') if module == 'M03' else ('description',)
    if module == 'M01':
        choices = {k: {'options': GROUPS[k], 'labels': LABELS[k]} for k in groups(module)}
    else:
        choices = {g[0]: {'options': g[2], 'labels': g[3]} for g in FORMS[module]['groups'] + EXTRA_GROUPS.get(module, []) if g[0] in groups(module)}
    return {'plant_fields': list(fields), 'test_fields': list(DESCRIPTIONS[module]),
            'groups': choices, 'titles': GROUP_TITLES, 'labels': FIELD_LABELS}

def asset_definition(s):
    return {k: copy.deepcopy(s.get(k, {} if k == 'attributes' else 1 if k == 'occurrence' else ''))
            for k in ('asset_id', 'kind', 'board', 'name', 'occurrence', 'attributes')}

def extract(d):
    module = module_of(d)
    fields = M01_FIELDS if module == 'M01' else ('description', 'environments') if module == 'M03' else ('description',)
    state = {'plant': {k: copy.deepcopy(d.get('plant', {}).get(k, '')) for k in fields},
             'flags': {k: copy.deepcopy(d.get('flags', {}).get(k, {})) for k in groups(module)},
             'tests': {k: copy.deepcopy(d.get('tests', {}).get(k, '')) for k in DESCRIPTIONS[module]},
             'samples': [asset_definition(s) for s in d.get('samples', []) if not s.get('retired')] if module == 'M01' else []}
    return state

def apply(d, state):
    """Applica soltanto caratteristiche: non importa prove, date o esiti."""
    for part in ('plant', 'flags', 'tests'):
        d.setdefault(part, {}).update(copy.deepcopy(state.get(part, {})))
    return d

def stamp(plant, module):
    identity = json.dumps({k: plant.get(k, '') for k in IDENTITY}, ensure_ascii=False, sort_keys=True)
    return {'profile_revision': plant.get('profiles', {}).get(module, {}).get('revision', 0),
            'identity': hashlib.sha256(identity.encode()).hexdigest()}
