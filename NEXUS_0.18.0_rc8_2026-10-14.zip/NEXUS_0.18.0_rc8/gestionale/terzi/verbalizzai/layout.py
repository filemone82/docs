"""1.0.0 rc3: misure di impaginazione sul PDF di LibreOffice (riquadro firme in fondo alla pagina)."""
from __future__ import annotations
import threading
from . import pdfconv; from . import templates

_cache={};_lock=threading.Lock()

def page_bottom(docx: bytes):
    """Quota (punti PDF) dell'ultimo paragrafo da 1 punto che entra nella prima pagina, per la
    geometria di pagina del documento. Misurata una volta per modello e tenuta in memoria.
    None se non si riesce a misurare (in quel caso le firme restano dove cadono)."""
    key=templates.page_key(docx)
    with _lock:
        if key in _cache:return _cache[key]
    try:
        points,total=pdfconv.outline_points(pdfconv.to_pdf(templates.probe_word(docx),'sonda.docx'))
        ys=[y for t,pg,y in points if t.strip().startswith(templates.PROBE_MARK) and pg==0 and y is not None]
        bottom=min(ys) if total>1 and len(ys)>100 else None
    except Exception:
        bottom=None
    with _lock:_cache[key]=bottom
    return bottom

def spaces_from(measured_docx: bytes, measured_pdf: bytes):
    """Spazi da aggiungere sopra i riquadri firme, dal Word e dal PDF della generazione di misura."""
    try:points,_=pdfconv.outline_points(measured_pdf)
    except Exception:return []
    expected=len(templates.signature_tables(templates.package(measured_docx)[1]))
    if not expected or signature_pages(points,expected) is None:return []
    bottom=page_bottom(measured_docx)
    if bottom is None:return []
    return templates.signature_spaces(points,bottom)

def signature_pages(points,expected):
    """Pagine dei riquadri in ordine, oppure None se manca anche una sola misura."""
    marks=[(t.strip(),pg,y) for t,pg,y in points if t.strip().startswith(templates.SIGN_MARK)]
    if len(marks)!=expected:return None
    by_name={t:(pg,y) for t,pg,y in marks}
    if len(by_name)!=expected:return None
    pages=[]
    for i in range(expected):
        v=by_name.get(templates.SIGN_MARK+str(i))
        if v is None or v[1] is None:return None
        pages.append(v[0])
    return pages
