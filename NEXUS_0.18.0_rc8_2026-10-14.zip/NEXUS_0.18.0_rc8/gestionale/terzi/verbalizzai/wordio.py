"""OOXML import/export. Standard library only; VBA is never executed."""
from __future__ import annotations
import copy, io, json, re, hashlib, xml.etree.ElementTree as ET
from zipfile import ZipFile, ZIP_DEFLATED

NS = {'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
      'w14':'http://schemas.microsoft.com/office/word/2010/wordml',
      'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
      'mc':'http://schemas.openxmlformats.org/markup-compatibility/2006'}
for k,v in NS.items(): ET.register_namespace(k,v)
def q(k):
    prefix, local = k.split(':'); return '{'+NS[prefix]+'}'+local
def txt(el): return ''.join(t.text or '' for t in el.iter(q('w:t')))
def clean(s): return re.sub(r'[_\s]+',' ',s or '').strip()
def norm(s): return re.sub(r'[^a-z0-9à-ü]+',' ',s.casefold()).strip()
def sha(data): return hashlib.sha256(data).hexdigest()

ENV = ['ordinary','fire','construction','medical','explosion']
SYSTEMS = ['tt','tn_s','tn_c','tn_cs','it']
GROUPS = {
 'check_type': ['periodic','extra'], 'environment':ENV, 'systems':SYSTEMS,
 'supply':['lt','gt','station'], 'protections':['rcd','overcurrent'],
 'earth_types':['rods','copper','mesh','natural'],
 'dico':['present','total','partial','absent'], 'project':['present','total','partial','absent'],
 'diri':['present','total','partial','absent'], 'outcome':['positive','negative'],
 'period':['two','five'], 'igia':['yes','no','na'], 'earth_method':['loop','voltamp'],
 'reidn':['yes','no','na'], 'ul':['v50','v25'], 'rcd_outcome':['positive','negative'],
 'tn_time':['conform','nonconform'], 'special':['yes','no'],
 'pe5':['conform','nonconform','na'], 'medical2':['conform','nonconform','na'],
 'it_first':['conform','nonconform','na'], 'at_app':['yes','no'],
 'at_relation':['yes','no','global'], 'contact_app':['yes','no'],
 'contact_result':['conform','nonconform'], 'attachments':['no','yes']}
LABELS = {
 'check_type':['Periodica','Straordinaria'], 'environment':['Ordinario','Maggior rischio incendio','Cantiere','Uso medico','Pericolo esplosione'],
 'systems':['TT','TN-S','TN-C','TN-C-S','IT'], 'supply':['< 1.000 V','> 1.000 V','Stazioni AT'],
 'protections':['Differenziali','Sovracorrenti'], 'earth_types':['Picchetti','Treccia rame','Maglia','Di fatto'],
 'dico':['Presente','Totale','Parziale','Assente'], 'project':['Presente','Totale','Parziale','Assente'],
 'diri':['Presente','Totale','Parziale','Assente'], 'outcome':['Positivo','Negativo'],
 'period':['2 anni','5 anni'], 'igia':['Sì','No','Non applicabile'], 'earth_method':['Loop test','Volt-amperometrico'],
 'reidn':['Sì','No','Non applicabile'], 'ul':['50 V','25 V'], 'rcd_outcome':['Positivo','Negativo'],
 'tn_time':['Conforme','Non conforme'], 'special':['Applicabili','Non applicabili'],
 'pe5':['Conforme','Non conforme','Non applicabile'], 'medical2':['Conforme','Non conforme','Non applicabile'],
 'it_first':['Conforme','Non conforme','Non applicabile'], 'at_app':['Applicabile','Non applicabile'],
 'at_relation':['Sì','No','Terra globale'], 'contact_app':['Applicabile','Non applicabile'],
 'contact_result':['Conforme','Non conforme'], 'attachments':['No','Sì']}
ANCHORS = {
 'check_type':r'periodica', 'environment':r'Ambiente ordinario', 'systems':r'Sistema di distribuzione',
 'supply':r'<\s*1[.]?000\s*V', 'protections':r'Dispositivi di protezione:', 'earth_types':r'^Dispersore',
 'dico':r'^Dichiarazione di conformità:', 'project':r'^Progetto:', 'diri':r'^Dichiarazione di rispondenza:',
 'outcome':r'POSITIVO', 'period':r'2 anni', 'igia':r'Ig\s*>\s*Ia',
 'earth_method':r'Resistenza di terra misurata', 'reidn':r'Re x Idn', 'ul':r'con Ul',
 'rcd_outcome':r'Esito prove di funzionamento', 'tn_time':r'Tempo intervento interruttori',
 'special':r'^Prescrizioni particolari', 'pe5':r'Misura dell.impedenza dei conduttori',
 'medical2':r'Misura di resistenza dei conduttori', 'it_first':r'Misura della corrente di primo',
 'at_app':r'^Guasti in alta tensione', 'at_relation':r'Re x If',
 'contact_app':r'^Tensioni di contatto:', 'contact_result':r'^Tensioni di contatto:', 'attachments':r'^Allegati:'}

def package(data):
    if len(data)>25*1024*1024: raise ValueError('Word troppo grande (massimo 25 MB).')
    z=ZipFile(io.BytesIO(data))
    infos=z.infolist()
    if len(infos)>3000 or sum(i.file_size for i in infos)>100*1024*1024: raise ValueError('Pacchetto Word troppo esteso.')
    if len({i.filename for i in infos})!=len(infos): raise ValueError('Il Word contiene parti duplicate.')
    if 'word/document.xml' not in z.namelist(): raise ValueError('Usare un file DOCX o DOCM. Il formato DOC non è supportato.')
    raw=z.read('word/document.xml')
    if b'<!DOCTYPE' in raw or b'<!ENTITY' in raw: raise ValueError('XML non ammesso.')
    return z, ET.fromstring(raw)

def paragraphs(root):
    # Word keeps older fallback shapes; the active branch is authoritative.
    for parent in root.iter():
        for child in list(parent):
            if child.tag==q('mc:Fallback'): parent.remove(child)
    return list(root.iter(q('w:p')))

MISMATCHED_BOXES=[]
def box_state(s):
    """Stato di una casella Word. Vale il simbolo visibile (quello che si legge e si stampa);
    lo stato interno w14:checked serve solo se il simbolo non è riconoscibile.
    Alcuni verbali hanno caselle con stato interno «spuntato» ma simbolo ☐ (o viceversa)."""
    ck=s.find('w:sdtPr/w14:checkbox/w14:checked',NS)
    internal=(ck.get(q('w14:val'),'0') in ('1','true','on')) if ck is not None else None
    glyph=''.join(t.text or '' for t in s.iter(q('w:t'))).strip()
    on_chars={'☒','☑','✓','✔','■','⊠','x','X'};off_chars={'☐','□'}
    cb=s.find('w:sdtPr/w14:checkbox',NS)
    if cb is not None:
        for tag,bucket in (('w14:checkedState',on_chars),('w14:uncheckedState',off_chars)):
            st=cb.find(tag,NS)
            if st is not None:
                try:bucket.add(chr(int(st.get(q('w14:val')),16)))
                except (TypeError,ValueError):pass
    visible=True if glyph in on_chars else False if glyph in off_chars else None
    if visible is None:return bool(internal)
    if internal is not None and internal!=visible:MISMATCHED_BOXES.append(1)
    return visible
def controls(p):
    return [s for s in p.iter(q('w:sdt')) if s.find('w:sdtPr/w14:checkbox',NS) is not None]

def parse_word(data, filename='documento.docx', with_tree=False):
    z,root=package(data)
    from .forms import detect_module, parse_form
    module=detect_module(txt(root))
    if module in ('M02','M03'): return parse_form(data, filename, module, with_tree)
    ps=paragraphs(root); texts=[txt(p).strip() for p in ps]
    MISMATCHED_BOXES.clear()
    flags={g:{k:False for k in keys} for g,keys in GROUPS.items()}
    flag_locations={}; provenance={}; warnings=[]
    def find(pattern, start=0):
        return next((i for i in range(start,len(ps)) if re.search(pattern,texts[i],re.I)),None)
    def group(g):
        i=find(ANCHORS[g]); keys=GROUPS[g]
        if i is None: warnings.append('Gruppo non riconosciuto: '+g); return
        found=[]
        for j in range(i,min(i+15,len(ps))):
            found += [(s,j) for s in controls(ps[j])]
            if len(found)>=len(keys)+(2 if g=='contact_result' else 0): break
        if g=='contact_result': found=found[2:]
        # In several originals the heading for Ul and first answer share one p.
        if g=='reidn':
            found=[(s,j) for s,j in found if j!=find(r'con Ul')]
            if len(found)<len(keys):
                found=[]
                for j in range(i+1,min(i+15,len(ps))):
                    if re.search(r'con Ul',texts[j],re.I): continue
                    found += [(s,j) for s in controls(ps[j])]
                    if len(found)>=len(keys):break
        if len(found)<len(keys): warnings.append('Caselle incomplete: '+g)
        for k,(s,j) in zip(keys,found):
            flags[g][k]=box_state(s); flag_locations[g+'.'+k]=s
            provenance['flags.'+g+'.'+k]={'paragraph':j+1,'text':texts[j]}
    for g in GROUPS: group(g)
    def line(pattern):
        i=find(pattern);return texts[i] if i is not None else ''
    def extract(path,pattern,source=None):
        s=source if source is not None else line(pattern);m=re.search(pattern,s,re.I)
        val=clean(m.group(1)) if m else ''
        provenance[path]={'text':s,'paragraph':(find(re.escape(s))+1 if s and find(re.escape(s)) is not None else None)}
        return val
    header=line(r'(?<!Allegato al )Verbale n\.')
    hm=re.search(r'Verbale n\.\s*(\S+)\s+del\s+(\d{2}/\d{2}/\d{4})',header,re.I)
    number=hm.group(1) if hm else '';date=hm.group(2) if hm else ''
    if not number:warnings.append('Numero o data del verbale non riconosciuti.')
    hl=line(r'Il Verificator.*in data'); inspectors=extract('header.inspectors',r'Verificator[ei]\s+(.*?)\s+in data',hl)
    indate=extract('header.in_date',r'in data:?\s*(.*?)\s*(?:ha(?:nno)? proceduto|$)',hl)
    inspection_dates=re.findall(r'\d{2}/\d{2}/\d{4}',indate)
    if not inspection_dates:warnings.append('Date della verifica da confermare: usata la data del verbale.')
    client=extract('plant.client_name',r'presso l.Azienda\s*(.*)',line(r'presso l.Azienda'))
    address=extract('plant.address',r'ubicata in\s*(.*)',line(r'ubicata in'))
    # Righe tra «presso l'Azienda» e «ubicata in» (es. «SCUOLA MATERNA»): denominazione dell'impianto.
    ci,ai=find(r'presso l.Azienda'),find(r'ubicata in');site=''
    if ci is not None and ai is not None and 0<ai-ci<=4:
        site=' – '.join(x for x in (clean(texts[j]) for j in range(ci+1,ai)) if x)
    det=line(r'Anno di installazione'); plant={
      'client_name':client,'site_name':site,'address':address,
      'installation_year':extract('plant.installation_year',r'Anno di installazione:?\s*(.*?)\s*Potenzialit',det),
      'power':normalize_power(extract('plant.power',r'Potenzialità:?\s*(.*?)\s*Tensione di esercizio',det))[0],
      'voltage':re.sub(r'\s*\(?V\)?\s*$','',re.sub(r'^\(?V\)?\s*:?\s*','',extract('plant.voltage',r'Tensione di esercizio:?\s*(.*)',det),flags=re.I),flags=re.I),
      'pod':extract('plant.pod',r'POD:?\s*(.*)',line(r'Con alimentazione')),
      'cabins':extract('plant.cabins',r'>\s*1[.]?000\s*V\s*(?:con\s*)?n\.\s*(.*?)\s*cabin',line(r'1[.]?000\s*V')),   # rev. 01: «> 1.000 V con n. …»
      'stations':extract('plant.stations',r'.*\bn\.\s*([^☐☒]*?)\s*stazioni AT',line(r'stazioni AT')),   # l'ultimo «n.» prima di «stazioni AT» (0.3.23: nel modello rev. 01 c'è anche «n. … cabine MT»)
      'if_value':extract('plant.if_value',r'AT:\s*(.*?)\s*\[',line(r'Corrente di guasto')),
      'if_unit':'kA' if '[kA]' in line(r'Corrente di guasto') else 'A',
      'tf':extract('plant.tf',r'Tempo di intervento:\s*(.*?)\s*\[',line(r'Tempo di intervento:')),
      'disperser_description':'','connections_description':'','conductors_description':'',
      'medical_group':''}
    all_headers=[]
    for i,t in enumerate(texts):
        m=re.search(r'(?:Allegato al )?Verbale n\.\s*(\S+)\s+del\s+(\d{2}/\d{2}/\d{4})',t,re.I)
        if m:all_headers.append({'number':m.group(1),'date':m.group(2),'paragraph':i+1})
    def between(a,b):
        i=find(a);j=find(b,i+1) if i is not None else None
        return '\n'.join(texts[i+1:j]) .strip() if i is not None and j is not None else ''
    notes=between(r'Note e/o osservazioni',r'Periodicità delle Verifiche')
    ncs=between(r'non conformità rilevate sono consistite',r'Note e/o osservazioni')
    tests={'earth_re':extract('tests.earth_re',r'Rearth\s*=\s*(.*?)\s*[ΩΩ]',line(r'Rearth')),
      'continuity_description':'','at_calculation':'','contact_description':''}
    sampling={'continuity':'','rcd':'','overcurrent':''}; samples=[]; instruments=[]
    table_locations={}; board_by_kind={}; counts={}
    tables=list(root.iter(q('w:tbl')))
    for ti,t in enumerate(tables):
        rows=t.findall('w:tr',NS)
        cells=[[clean(txt(c)) for c in r.findall('w:tc',NS)] for r in rows]
        if not cells:continue
        first=cells[0];f=norm(' '.join(first)); role=None
        if 'sistema disperdente' in f:
            for row,vals in zip(rows,cells):
                cs=row.findall('w:tc',NS)
                if len(cs)<2:continue
                left=norm(vals[0]); right=vals[1]
                for anchor,key in [('sistema disperdente','disperser_description'),('connessioni','connections_description'),('conduttori di terra di protezione','conductors_description')]:
                    if left.startswith(anchor):plant[key]=right;table_locations['plant.'+key]=cs[1]
                if left.startswith('continuità elettrica'):
                    tests['continuity_description']=right;table_locations['tests.continuity_description']=cs[1]
                    sampling['continuity']=clean(re.split(r'Criterio di campionamento(?: adottato)?:',vals[0],flags=re.I)[-1]) if 'campionamento' in vals[0].lower() else ''
                    table_locations['sampling.continuity']=cs[0]
                if left.startswith('coordinamento protezioni magnetotermiche'):
                    sampling['overcurrent']=clean(re.sub(r'^Coordinamento protezioni magnetotermiche\s*\(sistemi TN\)\s*','',vals[0],flags=re.I))
                    sampling['overcurrent']=clean(re.sub(r'Criterio di campionamento(?: adottato)?:','',sampling['overcurrent'],flags=re.I))
                    table_locations['sampling.overcurrent']=cs[0]
                if left.startswith('coordinamento e funzionamento'):
                    sampling['rcd']=clean(re.split(r'Criterio di campionamento(?: adottato)?:',vals[0],flags=re.I)[-1]) if 'campionamento' in vals[0].lower() else ''
                    table_locations['sampling.rcd']=cs[0]
        elif 'tipologia strumento' in f:
            role='instruments'
            for vals in cells[1:]:
                if len(vals)>=5 and vals[0]!='***' and any(v and not re.fullmatch(r'[/\-* ]+',v) for v in vals[1:]):
                    instruments.append(dict(zip(['type','brand','model','serial','calibration'],vals[:5])))
        elif 'circuito protetto' in f and any('Idn' in v for v in first):role='rcd'
        elif 'circuito protetto' in f and any(re.match(r'Ia\b',v) for v in first):role='overcurrent'
        elif 'massa' in f and 'punto di riferimento' in f:role='continuity'
        if role:table_locations.setdefault('table.'+role,[]).append(t)
        if role not in ('rcd','overcurrent','continuity'):continue
        board=board_by_kind.get(role,'');reference=''
        cap=t.find('w:tblPr/w:tblCaption',NS);capv=(cap.get(q('w:val')) if cap is not None else '') or ''
        mh=re.fullmatch(r'AD_REPEAT:\w+:(\d+)',capv)
        heads=int(mh.group(1)) if mh else (3 if role in ('rcd','continuity') else 2)   # modelli rev. 01: righe di intestazione dalla didascalia
        for ri,(row,vals) in enumerate(zip(rows,cells)):
            if ri<heads or not any(vals):continue
            if all(not v or v=='***' for v in vals):continue
            if role in ('rcd','overcurrent') and vals[0] and all(not v or re.fullmatch(r'[/\- ]+',v) for v in vals[1:]):
                board=vals[0];continue
            if role=='continuity' and vals[0] and len(vals)>=3 and not vals[2] and is_bold(row.findall('w:tc',NS)[0]):
                # Riga in grassetto senza esito = reparto / zona (come il quadro per i differenziali).
                board=vals[0]
                if vals[1]:reference=ref_text(row.findall('w:tc',NS)[1])
                continue
            if role=='rcd' and len(vals)>=5:
                if not (vals[0] or vals[1]) or not any(vals[1:]):continue
                attrs={'brand_model':vals[1],'idn_text':vals[2]}; result={'mechanical':vals[3],'time':vals[4]}
            elif role=='overcurrent' and len(vals)>=7:
                attrs={'brand_model':vals[1],'in':vals[2],'ia':vals[3]}; result={'zs':vals[4],'ig':vals[5],'coordination':vals[6]}
            elif role=='continuity' and len(vals)>=3:
                # Riferimento solo dove è scritto (cella unita: le righe sotto restano vuote = «|», stesso riferimento).
                ref=ref_text(row.findall('w:tc',NS)[1]) if vals[1] else ''
                if not ref and reference and not any(x.get('kind')=='continuity' and x.get('board')==board for x in samples):ref=reference
                reference='' if ref else reference
                attrs={'reference':ref};result={'outcome':vals[2]}
            else:
                warnings.append(f'Riga da interpretare: tabella {ti+1}, riga {ri+1}.');continue
            key=role+'|'+norm(board)+'|'+norm(vals[0]);counts[key]=counts.get(key,0)+1
            raw=' | '.join(vals); ne=any(re.fullmatch(r'n\s*\.?\s*e\s*\.?|non eseguit[ao]',v,re.I) for v in result.values())
            samples.append({'kind':role,'board':board,'name':vals[0],'occurrence':counts[key],
              'attributes':attrs,'results':result,'state':'not_executed' if ne else 'tested',
              'reason':'','source':{'table':ti+1,'row':ri+1,'text':raw}})
        board_by_kind[role]=board
    attachments={kind:{'declared':False,'pages':''} for kind in ('rcd','overcurrent','continuity','contact')}
    for kind,pat in [('rcd',r'prova dispositivi a corrente differenziale'),('overcurrent',r'misure dell.impedenza dell.anello'),('continuity',r'continuit\w* dei conduttori'),('contact',r'misure di tensione di contatto')]:
        i=find(pat)
        if i is not None:
            cs=controls(ps[i]);attachments[kind]['declared']=bool(cs and box_state(cs[0]))
            m=re.search(r'n\.\s*_*\s*(\d+)',texts[i]);attachments[kind]['pages']=m.group(1) if m else ''
            if cs:flag_locations['attachment_'+kind]=cs[0]
    emission=line(r'Data di emissione del Verbale'); emi_dates=[]
    for i,t in enumerate(texts):
        if re.search(r'Data di emissione del Verbale',t,re.I):
            dates=[re.search(r'\d{2}/\d{2}/\d{4}',s) for s in texts[i+1:i+5]]
            emi_dates.append(next((m.group() for m in dates if m),''))
    representative=between(r'in rappresentanza del Datore',r'Data di emissione del Verbale')
    data_out={'header':{'number':number,'report_date':date,'start_date':inspection_dates[0] if inspection_dates else date,'end_date':inspection_dates[-1] if inspection_dates else date,'in_date':indate,
      'issued_date':emi_dates[0] if emi_dates else date,'inspectors':inspectors,'reason':extract('header.reason',r'a seguito di\s*(.*)',line(r'a seguito di')),
      'hours':extract('header.hours',r'pari a \(circa\):\s*(.*?)\s*ore\s*/\s*uomo',line(r'pari a \(circa\)')),
      'representative':clean(representative),'due_date':extract('header.due_date',r'entro:\s*(.*)',line(r'Prossima verifica'))},
      'plant':plant,'flags':flags,'document_notes':notes,'notes':notes,'nonconformities':ncs,
      'tests':tests,'sampling':sampling,'samples':samples,'instruments':instruments,'attachments':attachments,
      'confirmed':False,'acknowledgements':{},'source_meta':{'filename':filename,'sha256':sha(data),
       'headers':all_headers,'emission_dates':emi_dates,'warnings':warnings+([str(len(MISMATCHED_BOXES))+' caselle hanno lo stato interno di Word diverso dal simbolo visibile: è stato letto il simbolo visibile (☒ / ☐). Controllare le scelte.'] if MISMATCHED_BOXES else []),'provenance':provenance,
       'template_reference':clean(' '.join(txt(ET.fromstring(z.read(n))) for n in z.namelist() if re.match(r'word/footer\d+\.xml',n)))},
      'u0':'230','template_id':None,'module':'M01'}
    # Capture explicit arithmetic without interpreting it as a fresh result.
    si=flag_locations.get('at_relation.yes')
    if si is not None:
        parent=next((p for p in ps if si in list(p.iter())),None)
        if parent is not None:tests['at_calculation']=re.sub(r'^SI\s*','',clean(txt(parent).replace('☒','').replace('☐','')),flags=re.I)
    if with_tree:return data_out,root,ps,flag_locations,table_locations,z
    return data_out

CARRIED_MEASURES=('earth_re','continuity_description','contact_description')
POWER_UNITS=('kVA','kW','MW','MVA','VA','W')
def normalize_power(value):
    """0.3.25 (punto 46) — una sola unità nel valore della potenzialità.

    Dalla rev. 02 il modello non stampa più il «kW» fisso: l'unità sta nel valore.
    Rileggendo gli storici capita di trovarla due volte («30 kW kW», valore della rev. 01
    più l'unità fissa del modello) oppure di non trovarla affatto (modelli vecchi, dove
    il «kW» era solo nel modello). Qui si normalizza: un'unità sola, e se manca si
    assume kW, che è quella che i modelli precedenti stampavano.
    Restituisce (valore, unita_assunta) — unita_assunta è True se il kW è stato aggiunto qui.
    """
    v=re.sub(r'\s+',' ',(value or '').strip())
    v=re.sub(r'^\(?\s*(?:kW|kVA)\s*\)?\s*:?\s*','',v,flags=re.I)   # etichetta davanti, es. «(kW): 30»
    if not v:return '',False
    for _ in range(4):   # «30 kW kW» e simili
        m=re.search(r'\b('+'|'.join(POWER_UNITS)+r')\s+('+'|'.join(POWER_UNITS)+r')\s*$',v,re.I)
        if not m:break
        v=v[:m.start()].rstrip()+' '+m.group(1)
    if re.search(r'\b('+'|'.join(POWER_UNITS)+r')\s*$',v,re.I):
        return re.sub(r'\s+',' ',v).strip(),False
    if re.search(r'\d',v):return v+' kW',True
    return v,False
def _num(v):
    m=re.search(r'\d+(?:[.,]\d+)?',str(v or ''));return float(m[0].replace(',','.')) if m else None
def is_bold(cell):
    for r in cell.iter(q('w:r')):
        b=r.find('w:rPr/w:b',NS)
        if txt(r).strip():return b is not None and b.get(q('w:val'),'1') not in ('0','false')
    return False
def ref_text(cell):
    """Testo del punto di riferimento: paragrafi separati da « / » (in una cella unita possono essercene più d'uno)."""
    return ' / '.join(x for x in (clean(txt(p)) for p in cell.findall('.//w:p',NS)) if x)
def empty_draft(baseline, assets):
    d=copy.deepcopy(baseline)
    for k in ['number','report_date','start_date','end_date','in_date','issued_date','hours','representative','due_date','reason']:d['header'][k]=''
    for g in ['outcome','igia','reidn','rcd_outcome','tn_time','pe5','medical2','it_first','at_relation','contact_result']:
        d['flags'][g]={k:False for k in GROUPS[g]}
    # Specifica 03/10: solo «< 1.000 V» / «> 1.000 V»; la casella «stazioni AT» del modello rev. 00 vale come «> 1.000 V».
    sp=d.get('flags',{}).get('supply',{})
    if sp.get('station'):sp['gt']=True;sp['station']=False
    # Tensioni di contatto: proposte «non applicabile», salvo sottostazioni (specifica M01 del 02/10/2026).
    st=d.get('flags',{}).get('supply',{}).get('station') or (lambda n:bool(n and n>0))(_num(d.get('plant',{}).get('stations')))
    if not st:d['flags']['contact_app']={'yes':False,'no':True}
    # Limite Utp proposto dal tempo di intervento tf (CEI EN 50522, tabella B.3); modificabile. Solo impianti > 1.000 V.
    from .rules import utp_for
    u=utp_for(d.get('plant',{}).get('tf'));v=str(u) if u and not (sp.get('lt') and not sp.get('gt')) else ''
    d['utp']=v;d['utp_auto']=v
    # Il calcolo Re × If non si riporta: la relazione è dichiarata con SI / NO / terra globale.
    d.setdefault('tests',{})['at_calculation']=''
    # Measures and criteria are proposed from the last verification for comparison.
    # Measured values stay flagged as 'carried' until the inspector edits or confirms them.
    d['carried']={'tests.'+k:v for k,v in d['tests'].items() if k in CARRIED_MEASURES and re.sub(r'[_/\s.\-]','',str(v or ''))}
    d['notes']='';d['nonconformities']='';d['instruments']=[];d['confirmed']=False;d['acknowledgements']={}
    d['source_meta']={'baseline':baseline.get('source_meta',{}).get('filename',''),'warnings':[]}
    # Decisione 03/10: si riparte dal campione della verifica precedente (100% precedente = tutti spuntati).
    # Elementi nuovi del censimento partono spuntati; quelli non provati l'ultima volta restano nel censimento ma esclusi.
    prev={s.get('asset_id'):s.get('state','tested') for s in baseline.get('samples',[]) if s.get('asset_id')}
    d['samples']=[]
    for a in assets:
        st='tested' if prev.get(a['id'],'tested') in ('tested','selected','not_executed') else 'excluded'
        d['samples'].append({'asset_id':a['id'],'kind':a['kind'],'board':a['board'],'name':a['name'],
          'occurrence':a['occurrence'],'attributes':copy.deepcopy(a['attributes']),'results':({'mechanical':'SI'} if a['kind']=='rcd' else {'outcome':'POSITIVO'} if a['kind']=='continuity' else {}) if st=='tested' else {},'state':st,'reason':'','source':{}})
    d['attachments']={kind:{'declared':False,'pages':''} for kind in ['rcd','overcurrent','continuity','contact']}
    return d
