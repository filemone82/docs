# 1.0.1 rc2 — 09/10/2026

Firme in fondo alla pagina con misurazione su PDF e verifica che ogni firma resti sulla propria pagina. Include i due controlli all’emissione introdotti nella rc1. Archivio e modelli invariati. Vedere AGGIORNAMENTO_1.0.1.md.

# 1.0.1 rc1 — 09/10/2026

Correzioni di sicurezza del flusso di emissione dopo la rc3: un conteggio pagine PDF non disponibile blocca l'emissione; un segnaposto firma privo dell'immagine da sostituire blocca l'emissione, senza registrare il verbale. Codice e directory di release distinti dalla 1.0.0 in produzione. Formato archivio 2 invariato. Vedere AGGIORNAMENTO_1.0.1.md.

# 1.0.0 rc3 — 09/10/2026

Impaginazione all'emissione: spazio del timbro riservato già in anteprima (il definitivo sostituisce solo l'immagine), niente pagina bianca finale, emissione bloccata se il PDF firmato ha pagine diverse dall'anteprima. Formato archivio invariato. Vedere AGGIORNAMENTO_1.0.0_rc3.md.

# 0.3.34 — 08/10/2026

Magnetotermiche: «Ig > Ia» ricavata da Ig e Ia (Ig ≥ Ia, n.e. conservato), Zs e Ig sempre a mano, R36 senza il confronto con 230 V / Zs. Tabelle degli elementi provati: colonna Esito, tasti S/N/E, tabella a tutta larghezza, etichetta «stesso campione della verifica precedente». Tolti «Ig > Ia: SI a tutte le righe vuote» e «Genera Word» dal menu. Numero del verbale a quattro cifre oltre il 999 (R1). «Prove eseguite» della continuità riprendibile dall'ultima verifica. Formato 2 invariato. Vedere AGGIORNAMENTO_0.3.34.md e VERIFICA_0.3.34.md.

# 0.3.33 — 08/10/2026

Interfaccia nei colori del logo AD (navy e petrolio), testo a 16 px e contrasti a norma, scelte a una voce come pulsanti a segmenti, messaggi in italiano una volta sola accanto al campo, azioni secondarie nel menu «⋯», conferma dell'app per «Elimina bozza», Ctrl+S, barra e schede sempre visibili, modalità ufficio/campo. Solo interfaccia: formato 2, regole, modelli Word e striscia BREAKING NEWS invariati. Vedere AGGIORNAMENTO_0.3.33.md e VERIFICA_0.3.33.md.

# 0.3.32.3 — 08/10/2026

Gestione utenti: esclusioni personali, nomi storici riservati, salvataggio atomico e controlli transazionali. Formato 2 invariato. Vedere AGGIORNAMENTO_0.3.32.3.md e VERIFICA_0.3.32.3.md.

# 0.3.32.2 — 08/10/2026

Rinomina ed eliminazione degli utenti dall'amministratore, solo per utenti senza operazioni nel registro; gli altri si disattivano. Formato 2 invariato. Vedere AGGIORNAMENTO_0.3.32.2.md.

# 0.3.32.1 — 07/10/2026

Correzione A26: Emetti verbale mostra il documento corrente dopo il salvataggio; anteprima con revisione indipendente; ritocchi conservati solo a bozza invariata. Ripresa del collaudo già configurato con --test-dir. Formato 2 invariato. Vedere AGGIORNAMENTO_0.3.32.1.md e VERIFICA_0.3.32.1.md.

# Novità VerbalizzAI 0.3.32

Candidata finale di collaudo del 7 ottobre 2026. Formato archivio 2.

- Avvio locale isolato con creazione dell'archivio vuoto e ripresa identificata; nessun reset o import automatico.
- Potenza storica precompilata e modificabile con unità originale. Nuovi campi numerici in kW. Nessuna conversione implicita dei kVA.
- Cabine/stazioni nascoste per TT nella maschera tecnica M01; valori conservati.
- Menu sinistro riducibile, risorse e amministrazione raggruppate; nuova lista Verbali con filtri e date distinte. Bozze nell'elenco dedicato.
- Anteprima/invio PDF con pannello riducibile a destra senza ricostruire i campi.
- Strumento inventario e archivio release VPS senza cancellazione.

Modelli Word, Breaking News e componenti di emissione/firma/invio restano invariati rispetto alla 0.3.31. La release non aggiunge il secondo fattore né riconfigura VPN, Nginx o il VPS. Non include dati, firme personali, chiavi o credenziali.

Prove automatiche: 233 test Python, 223 superati, 10 saltati per originali Word non disponibili; due suite JavaScript superate. L'accettazione nel browser Windows, Microsoft Word reale, SMTP e recupero operativo è a carico della campagna di collaudo descritta in COLLAUDO_0.3.32.md.


# 0.3.31 — 07/10/2026

Anteprima PDF in finestra, firma ed emissione dal Word controllato, ritocchi di impaginazione, PDF definitivo con invio esplicito, POD iniziale, potenza numerica kW e richiamo al precedente nelle revisioni. Vedi NOVITA_0.3.31.md e VERIFICA_0.3.31.md.

# 0.3.30.1 — 07/10/2026

Scheda tecnica compatta: primo inserimento distinto dalla modifica, sezioni per modulo, dati iniziali essenziali M01 e chiarimento della data. Vedi NOVITA_0.3.30.1.md.

# VerbalizzAI AD — Versioni e funzionalità

Questo file è incluso in ogni pacchetto e descrive **tutte** le versioni, dalla più recente.
Le istruzioni d'uso della versione contenuta nel pacchetto sono in `LEGGIMI.md`.

| Versione | Data | Uso previsto | Stato |
|---|---|---|---|
| 0.3.30 | 06/10/2026 | Copia isolata, validazione prima del lancio | Stato tecnico per modulo, censimento confermato all’emissione, importazione con confronto; formato archivio 2 |
| 0.3.29.1 | 06/10/2026 | Prova isolata, poi VPS privato | Comprende la 0.3.29; controlli transazionali sugli impianti, conferma dei doppioni e destinatari proposti corretti; guida completa di upgrade e VPN |
| 0.3.29 | 06/10/2026 | Superata dalla 0.3.29.1 | Cliente e impianto nuovi senza importare un verbale precedente. Comprende tutta la 0.3.28.1 |
| 0.3.28.1 | 06/10/2026 | Superata dalla 0.3.29 | Correzioni proxy e prima attivazione; preparazione WireGuard con Nginx/HTTPS. Non ancora installata sul VPS |
| 0.3.28 | 06/10/2026 | VPS dietro Nginx; moduli M01, M02, M03 | Proposta precedente. Consapevolezza del proxy inverso e codice di attivazione per il primo amministratore (punti 58 e 58b) |
| 0.3.27 | 05/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Testo della mail completo: revisione nel numero e frase della prossima verifica che sparisce con esito negativo |
| 0.3.26 | 05/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Ritaglio automatico della firma, esito negativo senza scadenza, impianti in attesa di verifica straordinaria in evidenza |
| 0.3.25 | 04/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Modelli rev. 02 (allegati compatti, timbro 3,5 cm senza nome, unità della potenzialità), scadenze strumenti 60/30, nomi dei file, rigenera PDF, controllo dei caratteri |
| 0.3.24 | 04/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Invio dei verbali via email, registro strumenti dall'Excel M07 con codice interno, permessi «vedere», timbro e firma più grandi |
| 0.3.23 | 04/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Calcolo guasti AT, ordine degli elementi, archivio veloce con migliaia di verbali, modelli armonizzati |
| 0.3.22 | 03/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Modelli in uso/superati, registro operazioni, scadenze strumenti, zone M03 |
| 0.3.21 | 03/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Evidenza a colori, «Vai al campo» ovunque, ripresa della bozza, allegati senza pagine bianche |
| 0.3.20 | 03/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Date e scadenza corrette, elimina bozza e annullamento verbali |
| 0.3.19 | 03/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Nuova verifica da un verbale, continuità più rapida, «Vai al campo» |
| 0.3.18 | 03/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Strumenti del verificatore automatici, tolta la colonna Nota |
| 0.3.17 | 03/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Associazione dei modelli alle bozze |
| 0.3.16 | 03/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Pagina «Prove di continuità» nel modello M01 |
| 0.3.15 | 03/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Allegato continuità nel modello M01, righe allegati solo se presenti |
| 0.3.14 | 03/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Tabella Utp di AD, nuovo logo |
| 0.3.13 | 03/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Ruoli e permessi configurabili, menu Firme |
| 0.3.12 | 03/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Evidenza in ocra, test meccanico SI, quadri tutto/parziale, «|» nella continuità |
| 0.3.11 | 03/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Correzioni dai test d'uso automatici |
| 0.3.10 | 03/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Pagine degli allegati automatiche, Utp da CEI EN 50522, avvisi accanto ai campi |
| 0.3.9 | 03/10/2026 | Prove in locale (poi VPS Ubuntu); moduli M01, M02, M03 | Prototipo, superato. Firma grafica, PDF con LibreOffice, modelli rev. 01, regole decise il 03/10 |
| 0.3.8 | 02/10/2026 | Server dell'ufficio o prove in locale; moduli M01, M02, M03 | Prototipo, superato. Anagrafica modificabile, seconda riga del cliente |
| 0.3.7 | 02/10/2026 | Server dell'ufficio o prove in locale; moduli M01, M02, M03 | Prototipo, superato. Pannello controlli richiudibile, esito e date |
| 0.3.6 | 02/10/2026 | Server dell'ufficio o prove in locale; moduli M01, M02, M03 | Prototipo, superato. Elementi provati come la tabella dell'allegato Word |
| 0.3.5 | 02/10/2026 | Server dell'ufficio o prove in locale; moduli M01, M02, M03 | Prototipo, superato. Numero e date più rapidi; maschera M01 nell'ordine del verbale Word |
| 0.3.4 | 02/10/2026 | Server dell'ufficio o prove in locale; moduli M01, M02, M03 | Prototipo, superato. Navigazione più comoda |
| 0.3.3 | 02/10/2026 | Server dell'ufficio o prove in locale; moduli M01, M02, M03 | Prototipo, superato. Corretta la lettura delle caselle dei verbali M01 reali |
| 0.3.2 | 02/10/2026 | Server dell'ufficio o prove in locale; moduli M01, M02, M03 | Prototipo, superato: legge come spuntate caselle che nel Word appaiono vuote |
| 0.3.1 | 02/10/2026 | Server dell'ufficio o prove in locale; moduli M01, M02, M03 | Prototipo, superato. Provata sui modelli M02/M03 e su 5 verbali reali |
| 0.3.0 | 30/09/2026 (script aggiornati 01/10/2026) | Server dell'ufficio, più utenti dal browser | Prototipo. Su un PC con WatchGuard EPDR `app.py` viene rimosso come «PUP» senza esclusione della cartella |
| 0.2.0 | 30/09/2026 (script aggiornati 01/10/2026) | Un solo PC, prove in locale | Prototipo, superato |
| 0.1.0 | 30/09/2026 | Un solo PC | Prototipo iniziale, superato |

Tutte le versioni sono prototipi da validare (ISO/IEC 17020 § 6.2.9) prima dell'uso operativo. Un archivio creato con una versione si apre con le successive senza perdita di dati (verificato da 0.2.0 a 0.3.0).

---

## 0.3.30 — Stato dell’impianto e fotografie delle verifiche

- Censimento di cliente, sede e impianto prima della nuova verifica; cliente e
  indirizzo obbligatori. Possibilità di compilare i dati tecnici prima del primo
  verbale. Restano importabili i Word storici.
- Scheda tecnica distinta per M01/M02/M03 con data, provenienza e conferma.
  Misure, esiti, periodicità e documenti emessi restano nelle singole verifiche.
- Tutti i differenziali censiti attivi vengono proposti; l’assenza dal campione
  storico non equivale a dismissione. Nuovi elementi, rinomine, cambi di quadro
  e dismissioni sono pubblicati solo alla conferma all’emissione.
- Storici fuori ordine e diversi campioni vengono confrontati esplicitamente.
  La proposta ricostruisce anche gli elementi presenti solo in storici intermedi.
  Se una nuova importazione cambia la proposta durante il confronto, occorre
  ripeterlo. Le bozze non alimentano lo stato tecnico.
- Permesso «Confermare e correggere lo stato tecnico»: inizialmente
  amministratore, RT e tecnico. Correzioni dirette datate e registrate.
- Protezione dalle pubblicazioni concorrenti e dai ritorni cronologici involontari;
  possibile emettere senza aggiornare l’impianto. Revisioni senza pubblicazione
  automatica sul presente. Annullamento della fonte: riesame e ritorno confermato.
- Formato archivio 2, con backup completo verificato prima della migrazione;
  conservazione delle fotografie storiche e supporto al ripristino dei backup 1/2.
- Corretto l’autosalvataggio delle sole spunte allegati che poteva lasciare R0
  «attachments: nessuna selezione». Da verificare anche sul caso reale segnalato.
- Modelli, regole tecniche, generatore VPN, sicurezza del proxy e Breaking News
  conservati. Nessuna nuova dipendenza Python.
- Verifica: 205 test Python (195 riusciti, 10 saltati), test JavaScript e Word/PDF
  dei tre modelli. Prova completa nel browser e validazione reale ancora da fare.

Le sezioni delle versioni precedenti descrivono il comportamento di allora;
per l’uso attuale prevalgono LEGGIMI e PUNTO_61_STATO_IMPIANTO.md.

## 0.3.29.1 — Correzioni dopo la verifica e guida completa per il VPS

- Conserva tutte le funzionalità e le correzioni proxy/VPN della 0.3.29.
- Impianti: eliminazione e controllo dei doppioni nella stessa transazione
  della scrittura. Una verifica o un elemento non può essere collegato a un
  impianto eliminato nel frattempo da un’altra richiesta.
- Conferma del doppione: accettata soltanto come valore booleano true;
  cambiando cliente o indirizzo la maschera richiede una nuova conferma.
- Le email proposte automaticamente si svuotano cambiando a un cliente senza
  email note. I campi modificati manualmente sono preservati separatamente.
- Sette regressioni aggiuntive sulle operazioni concorrenti; corretto il
  percorso di un test del modello rev. 01 che era saltato pur essendo incluso.
- vpn/GUIDA_VPS.md: sequenza completa 0.3.27 → 0.3.29.1, prova isolata,
  backup a freddo verificato anche su Windows, attivazione, VPN e client.
- Nessuna nuova dipendenza Python o modifica allo schema SQLite, ai modelli,
  alle regole tecniche o alle Breaking News. VPS ancora da aggiornare.

## 0.3.29 — Cliente e impianto nuovi senza verbale precedente

- Fino alla 0.3.28.1 l'unico modo di far entrare un cliente o un impianto in
  archivio era **importare un suo verbale Word**: nel codice l'unico punto che
  creava un impianto stava dentro `import_word`. Per un primo incarico, senza
  verbali precedenti, non c'era alcuna strada.
- **«＋ Nuovo impianto»** in «Clienti e impianti» (permesso «Creare e correggere
  gli impianti», che prima si chiamava «Correggere anagrafica degli impianti»):
  ragione sociale, denominazione dell'impianto, indirizzo e indirizzi email.
  La ragione sociale si **scegli fra quelle già in archivio** invece di
  riscriverla, così le sedi di uno stesso cliente non si separano per un refuso;
  scegliendo un cliente noto vengono proposti gli indirizzi email di un suo
  altro impianto.
- **Doppioni: avviso, non blocco.** Stesso cliente ad altro indirizzo: nota
  informativa. Stesso cliente allo **stesso** indirizzo: la creazione chiede una
  conferma esplicita («Crea comunque»), perché due cabine allo stesso indirizzo
  esistono, ma un doppio invio no.
- La **prima verifica si crea dopo**, dall'archivio, con «Nuova verifica»: non
  avendo storico parte vuota dalla struttura del template del modulo. I moduli
  senza template caricato restano non selezionabili con la spiegazione (già
  così dalla 0.3.23).
- **Eliminazione controllata** di un impianto creato per sbaglio, riservata
  all'amministratore (permesso «Annullare verbali»): possibile **solo** se non
  ha alcun verbale — bozze e bozze scartate comprese — e alcun elemento nel
  censimento. Come le bozze scartate l'impianto resta nel registro delle
  operazioni e nei backup, ma esce dagli elenchi; sull'impianto eliminato non si
  creano più verifiche né correzioni di anagrafica.
- Nel registro delle operazioni due voci nuove: «Nuovo impianto creato» e
  «Impianto eliminato dall'archivio», con cliente e indirizzo.
- Ordinamento «Ultima verifica»: un impianto senza alcuna verifica finiva in
  **cima** all'elenco. Ora sta in fondo, con l'etichetta «Nessuna verifica».
- Tolto il campo **«censimento completo dei differenziali»**: era salvato
  sull'impianto e copiato in ogni bozza, ma nessuna regola lo leggeva, non
  compariva in nessun segnaposto dei modelli e non c'era modo di impostarlo.
- Test automatici 168 (13 nuovi: creazione senza Word, campi obbligatori,
  conferma dei doppioni, prima verifica vuota dal template, eliminazione solo a
  impianto vuoto, registro, permessi via HTTP).

---

## 0.3.28.1 — Correzioni della proposta e preparazione VPN privata

- Parte dal pacchetto 0.3.28-3, senza modificare lo schema SQLite e senza
  introdurre dipendenze Python. Non introduce MFA/TOTP.
- Proxy locale: indirizzi verificati con ipaddress, un solo valore per
  intestazione, niente fallback al loopback quando manca X-Forwarded-For.
  Richieste con intestazioni mancanti/ambigue rifiutate; ascolto pubblico
  vietato con --behind-proxy. TLS diretto non può essere declassato dal proxy.
- Primo amministratore: codice casuale di 128 bit, limitazione dei tentativi,
  consumo del codice, controllo del database nella stessa transazione di
  creazione per impedire più amministratori iniziali simultanei.
- Prove HTTP reali su login/cookie, proxy malformato, tentativi setup e
  attivazioni simultanee. Configurazione di esempio aggiornata.
- vpn/GUIDA_VPS.md e vpn/vpn_prepara.py: tunnel parziale, DNS VPN confinato,
  Nginx/HTTPS conservati, rinnovo webroot verificato, chiusura pubblica dopo
  le prove. Le configurazioni generate sono candidate, da confrontare con
  quelle effettive del VPS prima di installarle.
- Non costituisce installazione sul VPS né audit completo della sicurezza.

## 0.3.28 — Dietro il proxy inverso, e primo amministratore con codice

Versione di sicurezza. Nasce da una verifica della superficie pre-autenticazione fatta il 05/10 e dalle
osservazioni raccolte da Federico. I modelli non cambiano (rev. 02 del 04.10.2026).

- **`--behind-proxy`** (nuovo): dice al programma che davanti a lui c'è un proxy inverso **sulla stessa macchina**. Solo allora legge `X-Forwarded-For` e `X-Forwarded-Proto`, e **solo se la connessione arriva davvero dal loopback** — altrimenti chiunque potrebbe dichiarare l'indirizzo che preferisce. Senza l'opzione il comportamento è identico a prima.
- **Punto 58 — `/api/setup` raggiungibile da internet.** Il primo amministratore si creava solo «dal server», e il controllo era `client_address == 127.0.0.1`. Dietro Nginx **ogni** richiesta arriva dal loopback, quindi quel controllo era vero per chiunque: finché l'archivio non aveva utenti — stato previsto dalla procedura di installazione — il primo che arrivava diventava amministratore. Ora il controllo sull'indirizzo è **sostituito** da un **codice di attivazione** stampato nella finestra del programma all'avvio quando l'archivio è vuoto, e richiesto dalla pagina di configurazione iniziale. Cambia a ogni riavvio. Non dipende da com'è fatta la rete, e permette di creare il primo amministratore anche dalla VPN invece che solo dalla console del server.
- **Punto 58b — blocco dei tentativi.** La chiave era `nome utente | indirizzo`, e dietro il proxy l'indirizzo era sempre `127.0.0.1`: il blocco dopo 5 tentativi valeva di fatto per solo nome utente, e un collega poteva bloccarne un altro sbagliandone apposta la password. Con `--behind-proxy` torna a distinguere i client.
- **Contrassegno `Secure` sul cookie.** Il programma lo metteva solo se faceva TLS da sé, quindi dietro Nginx mai: dipendeva interamente dalla configurazione del proxy, e sarebbe sparito in silenzio se qualcuno l'avesse toccata. Ora con `--behind-proxy` lo decide il programma, leggendo `X-Forwarded-Proto`.
- Test automatici: **137** (11 saltati senza i file reali), con 7 nuovi sul riconoscimento dell'indirizzo e sul cookie. Provata anche la catena completa del codice di attivazione: senza codice e con codice errato la creazione è rifiutata, con quello giusto riesce, e dopo l'endpoint si chiude da solo.

**Da fare in Nginx** quando si aggiorna: inoltrare le due intestazioni, altrimenti `--behind-proxy` non ha nulla da leggere.

```nginx
proxy_set_header X-Forwarded-For   $remote_addr;
proxy_set_header X-Forwarded-Proto $scheme;
```

## 0.3.27 — Testo della mail completo

Chiude il punto 27 iniziato con la 0.3.24: i testi standard sono ora utilizzabili su **qualunque** verbale,
compreso quello con esito negativo. I modelli non cambiano (restano i rev. 02 del 04.10.2026).

- **Campo `{revisione}`** (punto 27d): finora `{numero}` non portava l'indice di revisione, che compariva solo nel nome del file. Un verbale riesaminato sarebbe partito con lo stesso numero del primo invio e solo la data diversa, in contrasto con la regola del sistema di gestione (rev. xx, data nuova, menzione esplicita del riesame). Il campo è vuoto alla prima emissione e vale « rev. 1», « rev. 2» sulle successive.
- **Righe che spariscono da sole** (punto 27d): una riga i cui campi risultano **tutti vuoti** non viene stampata. Serve per la frase della prossima verifica, che con esito negativo non ha senso — non c'è una scadenza, il D.P.R. 462/01 prevede una verifica straordinaria — e che senza questa regola sarebbe uscita come «La prossima verifica è da eseguirsi entro il .». La frase resta scritta nei testi standard e modificabile, invece di essere fissata nel programma. Una riga con più campi sparisce solo se sono vuoti tutti, così «n. {numero}{revisione}» resta; una riga senza campi non sparisce mai.
- **ATTENZIONE alla scrittura dei testi**: la frase della prossima verifica va tenuta **su una riga sua**. Se la si unisce a un'altra frase, con esito negativo spariscono tutte e due. La pagina «Impostazioni email» lo spiega sotto i campi.
- **Testi predefiniti aggiornati** al testo approvato da Federico il 05/10: oggetto con numero e revisione, esito citato («positivo» / «negativo», senza motivazione: non la dà il verificatore nella mail), frase sulla conservazione e prossima verifica su righe separate, firma con il verificatore come **riferimento tecnico della verifica** (la mail può partire anche dalla segreteria) e il blocco aziendale completo con il decreto di abilitazione. Mai la sede di Parma. Chi ha già salvato testi propri li mantiene: i predefiniti valgono solo per i campi mai modificati.
- Test automatici: **130** (11 saltati senza i file reali), con 5 nuovi.

Resta aperto, per scelta: chi invia materialmente la mail (si lega al punto 39) e gli allegati oltre al PDF.

## 0.3.26 — Firma ritagliata da sola, esito negativo senza scadenza

I modelli **non cambiano**: restano i rev. 02 del 04.10.2026 consegnati con la 0.3.25.

- **Ritaglio automatico della firma** (punto 40c): le immagini di timbro e firma arrivano quasi sempre con una cornice vuota attorno — quella di AD ne ha l'8% per lato su 500 × 500 pixel. Quella cornice occupava spazio nel riquadro senza mostrare nulla, così un riquadro da 3,5 cm dava un timbro di 2,94. Ora il programma misura il riquadro del contenuto e lo ritaglia al momento dell'inserimento: **l'immagine caricata non viene toccata**, cambia solo come il Word la mostra (`a:srcRect`). Vale per il timbro di qualunque verificatore, senza doverlo ritagliare a mano. Si legge il PNG con la sola libreria standard (profondità 8 e 16 bit, grigi, RGB, tavolozza, canale alfa, senza interlacciamento); su JPEG o varianti non gestite non si ritaglia nulla e tutto resta come prima. Non si ritaglia sotto il 2% di margine (inutile) né oltre il 45% (immagini quasi vuote).
- **Timbro 3,0 cm** (punto 40b): il riquadro massimo passa da 6,5 × 3,5 a **6,5 × 3,0 cm**. Siccome ora il riquadro vale per il contenuto e non per la cornice, il timbro tondo esce davvero di 3,0 cm — leggermente più grande dei 2,94 della 0.3.25 — e il riquadro firme cala da 4,50 a **4,00 cm**.
- **Esito negativo: nessuna prossima scadenza** (punto 54). Con esito negativo non esiste una scadenza periodica: il D.P.R. 462/01 prevede una verifica straordinaria. Perciò il campo «Prossima verifica da eseguirsi entro» **resta vuoto** e nel verbale viene stampato un **asterisco**; la motivazione la scrive il verificatore nelle **osservazioni**, su una riga che inizia con `*`. In maschera il campo viene svuotato da solo quando l'esito diventa negativo, ma resta scrivibile. La **periodicità** (2 o 5 anni) resta obbligatoria: dipende dall'impianto, non da come è andata la verifica.
- **R4 rovesciata e nuova R56** (punto 54): con esito negativo R4 segnala **errore se la scadenza è compilata** (prima segnalava errore quando era vuota) e la nuova **R56** avvisa se le osservazioni non contengono una riga che inizia con `*`. Con esito positivo R4 non cambia di una virgola e R56 risulta «non applicabile».
- **Non conformità obbligatorie con esito negativo** (punto 56, segnalato da Federico): «Le non conformità rilevate sono consistite in: NESSUNA» contraddice un esito negativo. Ora con esito negativo la descrizione va **scritta a mano** e **l'emissione è bloccata** finché manca: non è un avviso da confermare, il verbale non si chiude. Non sono ammessi il campo vuoto, «NESSUNA» e i riempitivi senza testo («---», «n.a.»). In maschera il campo risulta obbligatorio e un «NESSUNA» ereditato da un verbale precedente viene tolto quando l'esito diventa negativo. Con esito positivo non cambia nulla: «NESSUNA» resta il valore proposto.
- **Impianti in attesa di verifica straordinaria** (punto 54b): senza data di scadenza un impianto con esito negativo sarebbe sparito in fondo all'ordinamento «prossima verifica in scadenza» — proprio quello che ha più bisogno di attenzione. Ora quegli impianti stanno **in testa** all'elenco, con l'etichetta rossa «In attesa di verifica straordinaria». L'attesa cade da sola quando arriva un verbale successivo con esito positivo.
- **Annullamento dallo storico** (punto 55, segnalato da Federico): annullando un verbale dalla finestra «Apri storico» si tornava in cima all'archivio, perdendo il punto in cui si era. Ora la finestra si riapre sullo stesso impianto. Vale anche per il ripristino di un verbale annullato.
- Test automatici: **125** (11 saltati senza i file reali), con 12 nuovi.

Resta da fare, concordato con Federico: il testo standard della mail con esito e revisione (campi `{revisione}` e la frase della prossima verifica), rimandato a una prossima sessione.

## 0.3.25 — Modelli rev. 02, allegati più compatti, nomi dei file, manutenzione del PDF

Versione che chiude i punti di impaginazione decisi il 04/10 e porta i modelli M01, M02 e M03 alla **revisione 02**
(cartella `modelli_rev02/m01/`, da caricare dal menu Template Word e poi «Usa per tutte le bozze»).
Lo script che li costruisce dai rev. 01 è incluso: `strumenti/costruisci_modelli_rev02.py`.

- **Allegati più compatti** (punto 47): nelle tabelle delle prove l'interlinea passa da 1,15 (ereditata) a singola e i margini alto/basso delle celle da 55 a 40 twip. Inoltre **mai una riga sola con il riquadro firme**: le ultime **tre** righe della tabella restano con la legenda e con le firme (la 0.3.24 ne teneva una, e capitava che finisse da sola in fondo). Su un verbale reale con 16 differenziali: **da 6 a 5 pagine**, con l'ultima riga, la legenda e il riquadro firme tutti sulla stessa pagina.
- **Timbro e firma** (punti 38b e 40): riquadro massimo da 6,5 × 4 a **6,5 × 3,5 cm**, timbro tondo di 3,5 cm con la scritta circolare ancora leggibile.
- **Nome sotto il riquadro firme** (punto 41): quando il timbro con firma grafica viene inserito, il nome e cognome sotto il riquadro **sparisce** (lo dice già il timbro), nel verbale e negli allegati. Se la firma grafica manca il nome **resta**. Con più verificatori resta comunque, perché la firma grafica è di uno solo. Il nome in testa al verbale («Il Verificatore … in data … ha proceduto») non cambia mai.
- **Potenzialità con unità doppia** (punto 46): il modello non stampa più il «kW» fisso, l'unità sta nel valore: niente più «30 kW kW». La maschera chiede «Potenzialità · valore e unità (kW o kVA)» e un **avviso (R43)** segnala il valore senza unità. Rileggendo gli storici l'unità viene normalizzata: «30 kW kW» → «30 kW», «250 kVA kW» → «250 kVA», e un vecchio «30» senza unità diventa «30 kW». La «V» della tensione resta, perché quel valore («230/400») non la porta.
- **Riga «> 1.000 V con n. … cabine MT e/o n. … stazioni AT»** (punto 46b): spazi normali al posto di quelli larghi (da 16,5 a 4,4 punti dopo «n.»). La rilettura dei verbali storici rev. 01 non ne risente: gli spazi larghi vengono comunque normalizzati in lettura.
- **Nota «inclusi i tempi impiegati…» che non compariva nel PDF** (punto 52, segnalato da Federico il 04/10): nella riga «Durata della verifica» la nota in corsivo era un paragrafo **annidato dentro un altro paragrafo**, cosa che lo schema OOXML non ammette. Word la tollerava e la stampava *in linea* (la nota finiva sulla stessa riga di «… ore uomo» e andava a capo male), LibreOffice la scartava e **nel PDF la nota spariva del tutto**. Nei modelli rev. 02 il paragrafo è stato portato fuori: ora la nota sta su una riga propria in Word **e** compare nel PDF. Corretti anche 12 paragrafi per modello che avevano due blocchi `<w:pPr>` (lo schema ne ammette uno): si è tenuto il secondo, che conteneva già tutto il primo più l'interlinea. Il difetto era nei modelli fin dalla rev. 01.
- **Riquadro firme centrato in altezza** (punto 41b): la data di emissione e il timbro erano appoggiati in basso nella cella; ora sono centrati verticalmente.
- **Casella del codice modello nel piè di pagina** (punto 48): larga 8 cm invece di 5,2 e senza ritorno a capo automatico.
- **Scadenze degli strumenti** (punto 23): preavviso **60 giorni** (era 30), rosso negli **ultimi 30** (era 7) e quando è scaduta. Vale per la striscia in home, per il registro e per la bozza; il testo della pagina Strumenti lo spiega.
- **Avviso all'importazione** (punto 32): se sullo stesso impianto esiste già un verbale con lo **stesso numero e la stessa data** ma il file è **diverso** (non il doppione esatto, che era già riconosciuto), il verbale viene archiviato e l'esito lo segnala, indicando il file già presente.
- **Ordinamento dell'archivio degli impianti** (punto 44): menu **«Ordina per»** accanto alla ricerca, con cliente (A→Z), ultima verifica, prossima verifica in scadenza, località. L'ordine alfabetico ignora maiuscole, accenti e la forma societaria (S.r.l., S.p.A., S.n.c., S.a.s.), così «AD S.r.l.» sta dove ci si aspetta. La scelta viene ricordata dal browser.
- **Nomi dei file Word e PDF** (punto 51): numero con «_» al posto di «/», poi « - » e ragione sociale (più la seconda riga, se c'è). Niente più «_AD». Esempi: «VP_111_26 - MASSANO s.n.c.pdf», «VP_700_26 - VERDELLO S.r.l. - Residenza CASAMIA VERDELLO.pdf», revisioni «VP_700_26_rev1 - …». Le bozze («Genera Word» e «Anteprima PDF») finiscono con « - BOZZA»; senza numero il nome parte da «Bozza». Vale anche per l'allegato della mail. Dalla ragione sociale vengono tolti i caratteri vietati da Windows e le virgolette tipografiche, e la lunghezza è limitata.
- **Avviso sui caratteri del server** (punto 49): all'avvio e prima dell'emissione il programma controlla che ci siano Calibri/Carlito e Cambria/Caladea. Senza, LibreOffice ripiega su un carattere più largo e il verbale esce con l'intestazione su quattro righe e due o tre pagine in più. L'avviso indica il comando per installarli. Su Windows, dove Calibri e Cambria fanno parte del sistema, non viene segnalato nulla.
- **«↻ Rigenera PDF»** (punto 50): sul verbale emesso, per chi ha il permesso di backup e manutenzione. Riconverte in PDF il **Word già emesso**, che non viene toccato: cambiano solo il PDF e la sua resa. Serve quando il PDF è stato prodotto con i caratteri sbagliati. L'operazione finisce nel registro delle operazioni come «PDF rigenerato dal Word emesso», con il PDF precedente tracciato.
- Test automatici: **113** (11 saltati senza i file reali), con 12 nuovi per i punti qui sopra.

## 0.3.24 — Invio dei verbali via email, registro strumenti dall'Excel, permessi «vedere», timbro e firma leggibili

- **Invio del verbale al cliente** (punto 27, deciso il 04/10): sul verbale emesso **✉ Invia al cliente** (anche nella finestra finale dell'emissione). Messaggio dalla casella aziendale (di base elettrico@adsrl.net) con il **PDF emesso e firmato** in allegato; **elettrico@adsrl.net sempre in copia**, non rimovibile; destinatari dall'anagrafica dell'impianto (o da un altro impianto dello stesso cliente), altrimenti scritti al primo invio e salvati; oggetto e testo già compilati, ritoccabili per il singolo invio; nessun invio automatico. Ogni invio, riuscito o no, resta nel verbale (Riesame → Invii al cliente), nel registro delle operazioni e nei backup; segno ✉ in archivio. Nuovo permesso «Inviare i verbali emessi al cliente via email» (di base amministratore, RT, tecnico).
- **Impostazioni email** (nuovo menu, solo amministratore): server di posta, porta e sicurezza, utente e password, mittente, copia per l'ufficio, **Invia una prova**; testi standard (oggetto, messaggio, firma) con campi tra graffe e anteprima su un verbale vero. Server e password in `posta.json` nella cartella dell'archivio, fuori dal database e dai backup; la password non torna mai al browser.
- **Codice interno degli strumenti** (punto 34): nel registro, nella scelta «Dal registro strumenti» e nella riga della bozza; non stampato nel verbale; unico nel registro. Nuovo campo **Stato** (Attivo, In taratura, Fuori servizio, Dismesso): solo gli «Attivo» vengono proposti.
- **Importazione dal registro Excel M07** (punto 35): «⇪ Importa da Excel M07» legge la scheda «Apparecchiature», mostra nuovi, aggiornamenti campo per campo, invariati e strumenti solo nel programma, poi applica. Riconoscimento per codice interno o matricola; «OdI» = non assegnato; titoli tolti dall'assegnatario; date dai valori calcolati da Excel (avviso se mancano). Lettura con la sola libreria standard (nuovo modulo `xlsxio.py`). Provato sul registro M07 reale: 12 strumenti.
- **Abbinamento strumenti–verificatore senza titoli**: «Dott. Ing. Federico Amateis» nel registro corrisponde a «Federico Amateis» nel verbale (proposta automatica, striscia «I TUOI»).
- **Permessi «vedere» separati da «gestire»** (punto 37): «Vedere il registro strumenti» e «Vedere le firme dei verificatori»; gestire comprende vedere. Il tecnico di base non vede le voci Strumenti e Firme; il server non gli manda gli strumenti non attivi né le firme altrui. Continua a scegliere gli strumenti nella verifica. La propria firma si carica da **La mia firma** sotto il nome. Striscia «BREAKING NEWS» per chi non vede il registro: solo gli strumenti affidati a lui, senza apertura del registro (deciso il 04/10). Le tabelle dei permessi già salvate ricevono i valori iniziali per i permessi nuovi.
- **Timbro e firma più grandi** (punto 38): riquadro massimo da 5,5 × 1,6 cm a **6,5 × 4 cm**; un timbro tondo con firma esce di 4 cm di diametro con la scritta circolare leggibile. Provato con l'immagine reale su M01, M02, M03 rev. 01 e negli allegati: stesso numero di pagine, riquadro firme non diviso.
- **«(es. Scuola materna)»** tolto dal campo «Denominazione dell’impianto · seconda riga» in tutte le maschere (punto 36).
- Barra dei pulsanti in alto che va a capo quando i pulsanti sono molti (verbale emesso).
- Test automatici: 101 (11 saltati senza i file reali), compresi invio con server di posta di prova, rifiuto dei destinatari, importazione Excel e permessi via HTTP.

## 0.3.23 — Calcolo dei guasti in alta tensione, ordine degli elementi, archivio veloce, modelli armonizzati

- **Guasti in alta tensione** (punto 25, deciso il 04/10): nella scheda Rapporto di verifica il calcolo è scritto per esteso, es. «Ucalc = 500 A × 0,8 Ω = 400 V · Uamm = Utp = 220 V (tf 0,5 s)». Uamm dalla tabella CEI EN 50522 in base al tempo di intervento dichiarato. Ucalc ≤ Uamm → relazione soddisfatta; fra Uamm e 2 × Uamm → avviso, da valutare; oltre 2 × Uamm → non soddisfatta. La casella SI / NO è proposta in automatico (SI sotto Uamm, NO oltre 2 × Uamm; nella fascia intermedia decide il verificatore) e resta modificabile. Nuovo controllo R55. La relazione non soddisfatta non rende negativo il verbale: R33 chiede le tensioni di contatto «applicabile» e avvisa se manca l'allegato delle misure. Corrente di guasto in ampere (gli storici in kA vengono convertiti). Il caso 2 × Utp con rete magliata per ora non si considera.
- **R20** (punto 24): DiCo o progetto presenti ma non citati nelle osservazioni → avviso (prima errore); sotto ciascun gruppo compare solo la frase che lo riguarda.
- **Ordine degli elementi provati** (punto 26): frecce ▲ ▼ per spostare la singola riga dentro il suo quadro e l'intero quadro (blocco) rispetto agli altri, in differenziali, magnetotermiche e continuità. L'ordine vale per gli allegati del Word e viene riproposto nella verifica successiva dell'impianto.
- **Scheda Riesame** (punto 28): tolto «Backup completo dell'archivio» (resta nel menu Backup e ripristino). «Scarica Word originale» resta solo nei verbali storici importati; nelle bozze compaiono «Word del verbale precedente (numero)» e «Apri il verbale precedente».
- **Archivio con migliaia di verbali** (punto 29, prova di carico con 5.000 verbali, 1.667 impianti, 91.685 elementi):
  - importazione degli storici: ricerche mirate con indici e una sola copia automatica a fine lotto; 5.000 verbali in circa 2 minuti e un quarto, tempo costante per verbale (prima rallentava a ogni Word: ore);
  - pagine (Clienti e impianti, Bozze, Template): da 49 s a 0,7 s con 5.000 verbali; salvataggio automatico della bozza da 1,3 s a pochi millesimi;
  - registro delle modifiche: il contenuto precedente della bozza si conserva al massimo ogni 10 minuti (chi e quando sempre): da circa 17 kB a meno di 1 kB per salvataggio;
  - copie automatiche scritte in modo progressivo, in sottofondo e senza bloccare gli altri utenti; memoria del programma circa 110 MB con 5.000 verbali.
- **Modelli Word M01, M02, M03 armonizzati** (punto 30), rev. 01 del 04.10.2026 nella cartella `modelli_rev01`: righe del rapporto di verifica che non si spezzano fra due pagine; la riga «Note e/o osservazioni» può continuare alla pagina dopo e il blocco esito non trascina più tutte le note (niente mezza pagina vuota prima dell'esito); titolo del M01 su due righe come M02 e M03, con la seconda riga del titolo accostata alla prima in tutti e tre (ritocco del 04/10 mattina); la frase «Sulla base dell’esame…» resta sulla stessa pagina della tabella del rapporto; la tabella della strumentazione non si divide fra due pagine; le righe molto lunghe delle check list M03 possono continuare alla pagina dopo (niente terzo di pagina vuoto); stessa data di revisione nei tre piè di pagina. La spaziatura delle caselle, confrontata a parità di contenuto, era già la stessa nei tre modelli. **Caricare i tre modelli nel menu Template Word** (diventano «in uso»).
- Correzione: rilettura dei verbali M01 rev. 01 importati (numero di cabine MT e stazioni AT: prima la frase «> 1.000 V con n. …» non veniva letta e le stazioni prendevano anche il testo delle cabine).
- Correzione: alcune larghezze dei campi nella scheda Verbale venivano ignorate dal browser (regole di sicurezza della pagina); ora sono applicate.
- Prove: 89 (nuove: rilettura cabine/stazioni rev. 01, fasce del calcolo AT e conversione kA, allegato TCP, R20 per gruppo, importazione senza copia per ogni Word e con SQLite senza JSON1, modelli armonizzati). Prova di carico ripetibile con 5.000 verbali; prova nel browser di calcolo AT, frecce e Riesame.

## 0.3.22 — Modelli in uso e superati, registro operazioni, scadenze degli strumenti, zone M03

- **Template Word** (punto 16): per ogni modulo il modello caricato per ultimo è «in uso», i precedenti «superati» in una sezione chiusa in fondo alla pagina. Accanto a ciascuno: data e ora del caricamento e quante bozze e verbali emessi lo usano. **Elimina** solo per un modello mai usato (nessuna bozza, verbale o anteprima); gli altri si conservano. Il modello eliminato resta nell'archivio come nascosto (registro e backup coerenti); ricaricando lo stesso file torna disponibile. Nella bozza l'elenco dei modelli indica data di caricamento e «in uso» / «superato».
- **Versione visibile** (punto 17) nella schermata di accesso e in alto nella home.
- **Schermata di accesso** (punto 18): tolta la riga «Verbali DPR 462/01 · M01 · M02 · M03».
- **M03, zone di pericolo** (punto 19): corrette X02/X03. Gas spuntato → almeno una fra zona 0, 1, 2 (n.a. non ammesso); polveri spuntato → almeno una fra zona 20, 21, 22; entrambi → una per gruppo. Atmosfera non spuntata → zone vuote o n.a. = corretto, e le sue zone vengono proposte «n.a.» in automatico (anche nelle bozze esistenti, all'apertura). Si colora la zona sbagliata (gruppo vuoto, n.a. non ammesso, zona senza atmosfera), mai la casella dell'atmosfera; anche X04/X05 non colorano più l'atmosfera. Nelle zone n.a. e le zone si escludono a vicenda.
- **Tolto «Scarica copia JSON della bozza»** (punto 20): la copia di recupero resta nel backup dell'amministratore.
- **Registro operazioni** (punto 22): nuova pagina con utente, data e ora e dettaglio di emissioni, revisioni, annullamenti e ripristini, bozze eliminate, importazioni, utenti, permessi, firme, modelli, registro strumenti (con le date cambiate), anagrafiche, rilettura storici e ripristini da backup; filtri per periodo, utente e tipo; esportazione CSV. Nuovo permesso «Consultare il registro delle operazioni», di base solo amministratore. Comprende anche le operazioni delle versioni precedenti (il registro delle modifiche esisteva già). Il ripristino da backup ora lascia una voce nel registro.
- **Scadenze strumenti** (punto 23):
  - registro strumenti con **controllo interno** (verifica intermedia): data ultima e scadenza, copiate nella bozza ma non stampate nel verbale;
  - striscia «BREAKING NEWS» scorrevole nella home, per tutti, con taratura e controllo interno in scadenza entro 30 giorni o scaduti (rosso negli ultimi 7 e se scaduti), i propri strumenti in testa con «I TUOI»; si ferma al passaggio del mouse, clic → registro strumenti;
  - **taratura scaduta alla data di inizio verifica → emissione bloccata** (salvataggio, Genera Word e anteprime restano possibili); nella finestra di emissione «Vai alla strumentazione»;
  - **controllo interno scaduto → solo avviso** arancione (R24b nel M01, C09b nel M02/M03);
  - se nel registro una taratura o un controllo viene rinnovato con data anteriore all'inizio verifica, la riga della bozza si aggiorna all'apertura (mai con date successive, quindi non nelle revisioni di verifiche passate).
  - **Da confermare**: preavviso 30 giorni, rosso negli ultimi 7, striscia per tutti, blocco dell'emissione.
- **Annullamento / eliminazione dei verbali** (punto 21): invariato, resta l'annullamento motivato della 0.3.20, in attesa di decisione.
- Specifica regole aggiornata: R24 (blocco), R24b/C09b, striscia delle scadenze, nuovo capitolo «8. Moduli M02 e M03 — aggiornamento 0.3.22» con X02/X03 (da riportare nella copia di progetto con il capitolo 8 completo).
- Prove: 83 (nuove: modelli in uso/superati ed eliminazione, backup dopo l'eliminazione, registro operazioni e filtri, voce di ripristino, permessi via HTTP, blocco taratura, controllo interno, zone M03). Verificata anche l'interfaccia in un browser (accesso, home con striscia, modelli, registro operazioni con CSV, bozza M03).

## 0.3.21 — Colori per gravità, «Vai al campo» ovunque, ripresa della bozza

- **Evidenza a colori** (punto 14): rosso = errore, arancione = avviso, grigio = avviso valutato per iscritto, ocra = da compilare.
  - si colora la singola casella sbagliata (es. «loop test» e «TN-S» quando il loop test è spuntato in un sistema TN), il campo compilato in modo incoerente o la cella della tabella delle prove;
  - i colori si aggiornano a ogni salvataggio automatico; i contatori sulle schede hanno il colore del caso più grave; legenda nel pannello Controlli;
  - i promemoria sempre presenti (R24, R27, R29, R39, C12) non colorano i campi.
- **Tempi dei differenziali** (R28): oltre 300 ms → avviso (ammesso solo per i selettivi tipo S); oltre 500 ms → errore se l'esito delle prove è positivo. Soglie da confermare (vedi Specifica regole).
- **«Vai al campo» su tutti i controlli** (punto 15): anche M02 e M03, anche nella finestra «Emetti il verbale»; porta al primo campo vuoto o sbagliato, alla singola cella per le prove. Ogni controllo indica i propri campi; una prova automatica segnala i controlli nuovi senza campo. Restano senza campo R26, R34 e C13, con l'indicazione di dove si risolvono.
- **Ripresa dopo il ricaricamento** (punto 13): F5 o riavvio del server riaprono la bozza, la scheda e la posizione; le modifiche dell'ultimo istante vengono inviate all'uscita dalla pagina; riquadro «Riprendi l'ultima bozza» in Clienti e impianti.
- **Allegati nel Word**: corrette le pagine bianche fra gli allegati (l'interruzione di pagina finiva da sola su una nuova pagina quando la tabella riempiva la pagina; il conteggio delle pagine dell'allegato ne risultava gonfiato) e il riquadro firme che si spezzava fra due pagine. Verificato sui verbali di prova: tutti gli allegati con righe spuntate compaiono.
- Specifica regole M01 aggiornata (R28, automatismi della 0.3.20 e 0.3.21).
- Prove: 75.

## 0.3.20 — Date e scadenza, elimina bozza, annullamento dei verbali

- **Date del verbale**: scrivendo la data del verbale vengono proposte uguali inizio verifica, fine verifica e data di emissione. La fine verifica coincide sempre con la data del verbale; inizio verifica e data di emissione restano modificabili. Scrivere l'inizio verifica non cambia più le altre date.
- **Scadenza** («Prossima verifica da eseguirsi entro») = inizio verifica + 2 o 5 anni − 1 giorno (es. inizio 02/12/2026 → 01/12/2028):
  - corretto l'errore per cui, dopo il salvataggio o riaprendo la bozza, la scadenza non si aggiornava più (veniva considerata modificata a mano);
  - una scadenza non successiva all'inizio verifica viene ricalcolata comunque;
  - sotto il campo è indicato come è stata calcolata, se è stata modificata a mano o che cosa manca (periodicità, data di inizio); **Ricalcola** è ora sotto il campo e, se non può calcolare, dice perché.
- **Elimina bozza** anche dall'interno della bozza aperta (pulsante in alto), oltre che dall'elenco Bozze.
- **Annullamento di verbali emessi e storici importati**: nuovo permesso «Annullare verbali emessi e storici», di base solo amministratore. Motivazione obbligatoria; il verbale sparisce da storico, statistiche e riferimenti, ma Word, PDF, originale e registro restano; elenco «Verbali annullati» nello storico dell'impianto, con ripristino. Uno storico annullato si può reimportare.
- Barra laterale: tolte le due righe di testo in basso; icona di **Firme** monocromatica come le altre.
- Verbale Word: con la seconda riga del cliente vuota, la ragione sociale è ora allineata a «Presso l'Azienda» (non resta più una riga vuota).
- Prove: 70 (nuove: annullamento e ripristino, permessi via HTTP, reimportazione, scadenza automatica dopo il salvataggio, riga cliente).

## 0.3.19 — Nuova verifica da un verbale, continuità più rapida, «Vai al campo»

- **Nuova verifica da questo verbale**: nello storico dell'impianto (accanto a «Apri») e in alto nel verbale storico o emesso aperto. La verifica parte dal verbale scelto invece che dall'ultimo.
- **Continuità**:
  - esito proposto **POSITIVO** sulle righe spuntate (nuove verifiche, righe aggiunte, bozze già aperte), modificabile; togliendo la spunta il POSITIVO proposto viene tolto;
  - **«come la verifica precedente»** riprende spunte, riferimenti ed esiti dell'ultima verifica (solo per la continuità, prova positivo/negativo);
  - riferimento «come sopra»: «|» o «=» nella cella, oppure il pulsante «↓ come sopra» nell'intestazione della colonna.
- **Differenziali e magnetotermiche**: «come la verifica precedente» riprende solo le spunte e lo dice («erano già uguali» se non cambia nulla); i valori misurati non vengono mai ripresi.
- **Vai al campo**: pulsante «Vai ↗» su errori e avvisi del pannello Controlli e della finestra di emissione (anche sui blocchi: numero, esito, elementi da completare). Apre la scheda, porta al campo e lo fa lampeggiare.
- **Finestra di emissione**: se l'emissione è bloccata, il riquadro degli errori/avvisi non dice più «l'emissione è possibile».
- **Niente suggerimenti automatici del browser** nei campi della bozza (numero, date, tabelle).
- **Messaggio chiaro** se il server non risponde (al posto di «Failed to fetch»).
- 62 prove automatiche.

---

## 0.3.18 — Strumenti del verificatore, senza colonna «Nota»

- **Strumenti assegnati al verificatore** inseriti da soli nella bozza: alla creazione (come prima), ma ora anche **all'apertura** delle bozze già esistenti e quando si **cambia il verificatore** (gli strumenti del verificatore precedente proposti in automatico vengono tolti). Gli strumenti aggiunti a mano restano. Se si toglie uno strumento proposto, in quella bozza non viene più riproposto. Etichette «Assegnato al verificatore» / «Dal registro» / «Aggiunto a mano».
- **Tolta la colonna «Nota»** dalle tabelle degli elementi (differenziali, magnetotermiche, continuità): «n.e.» non richiede più un motivo. Tolti di conseguenza gli avvisi R28/R36 «non eseguito senza motivazione» e il blocco dell'emissione per «n.e.» senza motivo (R54). Specifica regole aggiornata.
- Modelli rev. 01: nota sotto la tabella dei differenziali «n.e. = prova non eseguita» (senza «motivo nelle note»).
- 60 prove automatiche.

---

## 0.3.17 — Associazione dei modelli alle bozze

- **Bozze senza modello** (verbali importati prima di caricare i template): all'apertura ricevono da sole il modello più recente del loro modulo; Genera Word, Anteprima PDF ed Emissione lo usano comunque se manca.
- **Associazione in blocco** nel menu Template Word, su ogni modello: «Associa alle bozze M0x senza modello» e «Usa per tutte le bozze M0x» (con conferma). Verbali storici ed emessi invariati.
- Caricare un modello non modifica da solo le bozze aperte, per non creare conflitti di salvataggio a chi le sta compilando.
- Corretto: se Genera Word falliva (es. modello mancante) lo stato diceva «Non salvato · riprova» anche se la bozza era salvata.
- 60 prove automatiche.

---

## 0.3.16 — Allegato «Prove di continuità» nel modello M01

- **Modello M01-PO01 rev. 01**: aggiunta la pagina di allegato «PROVE DI CONTINUITÀ DEI CONDUTTORI DI TERRA, DI PROTEZIONE ED EQUIPOTENZIALI» (sul fac-simile VP/535/26): colonne «Massa / massa estranea controllata», «Punto di riferimento», «Esito»; righe raggruppate per reparto o zona; «|» per il riferimento uguale alla riga sopra; blocco firma. Prima la tabella veniva aggiunta in coda in forma standard (avviso T02). **Ricaricare il modello M01 in Template Word.**
- **Importazione della continuità** dai verbali rev. 00:
  - le righe in grassetto senza esito («Reparto J2», «Aree esterne», «REPARTO H»…) diventano il **reparto/zona** e non più un elemento da provare;
  - il punto di riferimento (cella unita su più righe) resta solo sulla prima riga; le altre risultano «| come sopra»; se la cella contiene più paragrafi sono separati da « / »;
  - riconosciuta anche la dicitura «prove equipotenziali e di continuità dei conduttori di protezione» nell'elenco degli allegati.
- Le tabelle dei modelli rev. 01 vengono lette con il numero di righe di intestazione indicato dal modello (prima si saltavano sempre 2–3 righe).
- I verbali già importati non cambiano: per riprendere la continuità con reparti e riferimenti, eliminare e reimportare il verbale storico (oppure correggere a mano nella bozza).
- Provato sul VP/535/26: 230 differenziali (9 pagine) e 107 punti di continuità in 5 reparti/zone (5 pagine, contate automaticamente).
- 59 prove automatiche.

---

## 0.3.15 — Allegato continuità nel modello M01

- **Modello M01-PO01 rev. 01** corretto: nell'elenco «Allegati» del rapporto mancava «prova di continuità dei conduttori di terra, di protezione ed equipotenziali» (con casella e n. pagine). Ora l'ordine è: differenziali, impedenza dell'anello di guasto, continuità, tensioni di contatto e passo. Data del modello: 03.10.2026 (anche M02 e M03, invariati nel contenuto). **Ricaricare il modello M01 in Template Word.**
- **Righe degli allegati stampate solo se presenti**: nel Word e nel PDF, sotto «Allegati» compaiono solo le righe degli allegati effettivamente presenti; senza allegati resta «☒ NO». Vale anche per i modelli rev. 00.
- L'importazione dei verbali riconosce sia «prove» sia «prova di continuità dei conduttori».
- 58 prove automatiche.

---

## 0.3.14 — Tabella Utp di AD e logo

- **Limite Utp** dalla tabella «Tensioni di contatto ammissibili – CEI EN 50522:2011-07 (CEI 99-3)» fornita da AD: 111 punti da 0,01 s a 10 s, oltre 10 s 80 V. Fra due punti si prende il **tempo tabellato immediatamente superiore** (tensione più bassa, scelta cautelativa). I valori che la 0.3.10 usava (tab. B.3) coincidono con la tabella nei punti comuni. Proposta sempre modificabile.
- **R35**: avviso se Utp manca o è **superiore** al valore di tabella (un valore più basso, più cautelativo, è accettato).
- Il tempo tf si legge sia «0,5» sia «0.5» (prima «0.505» veniva letto come 505 s).
- **Logo**: nuovo marchio VerbalizzAI (foglio del verbale con la spunta AD) nella barra laterale e come icona della scheda del browser; nella pagina di accesso compare il logo AD S.r.l. Inspections.
- 57 prove automatiche.

---

## 0.3.13 — Ruoli, permessi, menu Firme

- **Quattro ruoli**: Amministratore (superuser), Responsabile tecnico, Tecnico, Segreteria. Gli «Ispettore» delle versioni precedenti diventano «Tecnico» all'avvio.
- **Utenti e permessi** (menu a sinistra, solo amministratore): oltre agli utenti, una tabella «Permessi per ruolo» con 11 permessi (importare, compilare, emettere, revisionare, eliminare bozze, anagrafica, template, strumenti, firme di altri, backup, utenti). L'amministratore ha sempre tutto; «Utenti e permessi» resta solo suo. Impostazione iniziale in LEGGIMI.md.
- I permessi sono controllati dal server su ogni operazione (non solo nascondendo i pulsanti). Senza permesso di compilazione una bozza si apre in sola lettura.
- **Menu Firme** a sinistra: elenco dei verificatori con l'anteprima della firma; ognuno carica la propria, chi ha il permesso anche quelle degli altri. Il menu **Template Word** è visibile a chi ha il permesso di caricarli.
- **R36** (magnetotermiche): il messaggio ora dice quale dato manca («manca Zs, Ig > Ia») e che si riferisce alla tabella Magnetotermiche.
- 57 prove automatiche (nuova: ruoli e tabella dei permessi via HTTP).

---

## 0.3.12 — Evidenza in ocra e compilazione più rapida degli elementi

- **Evidenza in giallo ocra prima dell'emissione**: campi obbligatori vuoti, voci con errori o avvisi (la tinta è più carica per gli errori) e righe degli elementi spuntati senza risultato completo; nelle righe è evidenziata anche la cella mancante. Le schede del verbale mostrano quanti punti restano da controllare (es. «Elementi provati 9»). L'evidenza si aggiorna mentre si compila.
- **Test meccanico dei differenziali proposto SI** sulle righe spuntate (nuove verifiche, righe aggiunte, righe rispuntate, bozze già aperte); si cambia in NO o n.e. Togliendo la spunta, il SI proposto viene tolto se non c'è un tempo misurato.
- **Quadro tutto / parziale**: casella accanto al nome di ogni quadro, per spuntare o togliere tutti i suoi elementi; indica «tutto», «parziale n/N» o «nessuno».
- **Aggiungere righe**: pulsante «＋ aggiungi una riga in «quadro»» in fondo a ogni quadro (prima c'era solo un piccolo «+ riga» accanto al nome). Nelle tabelle vuote si può partire dai quadri già noti dell'impianto.
- **Continuità**: riferimento vuoto = uguale alla riga sopra (stesso quadro): «| come sopra» nella tabella, «|» nel verbale.
- Corretto: l'avviso delle prove dei differenziali (R28) compariva anche nella tabella delle magnetotermiche.
- 56 prove automatiche.


---

## 0.3.11 — Correzioni dai test d'uso

Prove eseguite con un browser automatico (Chromium) su un archivio nuovo: primo avvio, caricamento dei tre modelli rev. 01, importazione dei 7 verbali di esempio, nuova verifica M01/M02/M03, compilazione da tastiera, griglia, incolla, Genera Word, Anteprima PDF, emissione, revisione, stessa bozza in due finestre, utenti e firma, storico, anagrafica, backup e verifica, schermi da tablet (1024 e 800 px).

**Corretti**
- **Stessa bozza aperta in due finestre**: dopo il primo conflitto la bozza restava bloccata (ogni salvataggio falliva e non si riusciva nemmeno a uscire). Ora compare una finestra che chiede se **ricaricare** la versione salvata o **sovrascriverla**; se un salvataggio non riesce si può uscire con «Esci senza salvare».
- **Incolla da Word**: le righe il cui circuito inizia con «Circuito…», «Punto…», «Prova…», «Test…» venivano scambiate per l'intestazione della tabella e **scartate senza avviso**. Ora è intestazione solo una riga fatta di titoli di colonna.
- **Valutazione scritta nel pannello controlli**: a ogni salvataggio automatico il cursore usciva dal riquadro. Ora resta dove si sta scrivendo.
- **Tabella degli elementi**: a ogni clic su SI/NO o spunta la tabella tornava in cima. Tolto lo scorrimento interno della tabella (doppia barra di scorrimento): ora scorre la pagina e l'intestazione delle colonne resta visibile in alto.
- **Avvisi accanto ai campi**: quando compaiono o spariscono sopra la voce su cui si sta lavorando, la pagina viene compensata e la voce non si sposta.
- **Importazione**: verbali dello stesso cliente con lo stesso indirizzo (in archivio o nella stessa importazione) ora propongono già lo stesso impianto. Prima, importando insieme due verbali ICE PHARMA, nascevano due impianti distinti.
- **Storico dell'impianto**: l'elenco era ordinato in modo errato (per giorno invece che per data). Ora dal più recente.
- **Genera Word / Anteprima PDF**: il pulsante mostra «in preparazione…» per tutta la durata (con il conteggio delle pagine servono alcuni secondi).
- **Nuovo quadro**: il cursore va subito nel nome; Invio conferma.
- **Firma**: tolta la segnalazione d'errore nella console quando la firma non è ancora caricata.
- **Backup**: nella verifica del pacchetto le firme erano indicate come «signature». **Guida rapida** aggiornata.

**Da sapere (non corretti in questa versione)**
- Su schermi stretti (tablet in verticale) la barra laterale resta sempre aperta e il pannello «Controlli del verbale» va in fondo alla pagina: gli avvisi accanto ai campi compensano, ma la vera interfaccia tablet è prevista nella fase 2.
- «Elimina bozza» chiede conferma con la finestra standard del browser.

---

## 0.3.10 — Allegati automatici, Utp, avvisi accanto ai campi

**Dalle prove della 0.3.9 (03/10)**
- **Pagine degli allegati calcolate**: il programma genera il Word, lo converte in PDF, conta le pagine di ciascun allegato (dai segnalibri «Allegato al Verbale…») e rigenera il Word con «n. X pag.». Vale per Genera Word, Anteprima PDF ed Emissione; serve LibreOffice (senza, le pagine restano da scrivere a mano). Gli allegati delle prove risultano dichiarati se ci sono elementi spuntati. Le misure di tensione di contatto e passo restano manuali. R12 ridotta di conseguenza.
- **Limite Utp** (guasti in alta tensione): non più 25/50 V (che riguarda Ul in BT), ma proposto dal tempo di intervento tf secondo la **CEI EN 50522, tabella B.3**, con interpolazione fra i punti; R35 avvisa se manca o si scosta oltre il 10%. *Valori di tabella da confermare sulla norma.*
- **Loop test con sistema TN o IT** → Errore R7 (va usato il voltamperometrico).
- **Avvisi accanto ai campi**: errori e avvisi compaiono anche sotto la voce interessata, non solo nel pannello di destra.
- **Tolta** la casella «Dispongo di un censimento completo» e l'avviso «censimento incompleto» di R21–R23 (non serviva a decidere nulla).
- **Tolto** il campo «Uo adottata per Uo/Zs»: il controllo di Ig (R36) usa 230 V.
- **Elementi provati**: frecce ↑/↓ per spostarsi in verticale (oltre a Invio); «SI a tutte le righe vuote» per test meccanico / Ig > Ia; spiegato che i valori grigi sono quelli dell'ultima verifica.
- **Emetti il verbale**: la finestra controlla subito se l'emissione è possibile (elementi senza risultato, esito, numero…) e tiene disattivato «Emetti» finché non lo è; dice se la firma del verificatore è caricata (con il link per caricarla) e se LibreOffice c'è. Corretto il messaggio «Firma e PDF in preparazione…» che si ripeteva. A emissione avvenuta compaiono i pulsanti «Scarica Word» e «Scarica PDF».
- Specifica regole M01 aggiornata (R7, R12, R21, R22, R35, R36) e di nuovo inclusa nel pacchetto.
- 53 prove automatiche (nuove: Utp da tf, loop test in TN, allegati automatici, conteggio delle pagine nel PDF).

---

## 0.3.9 — Firma grafica, PDF, regole del 03/10

**Firma e PDF**
- **Firma grafica del verificatore**: ogni utente carica la propria immagine (PNG/JPG) dal link «Firma»; l'amministratore anche per gli altri da Utenti (colonna «Firma»). All'emissione l'immagine viene inserita sopra il nome in ogni riquadro «Il Verificatore» (verbale e allegati), ridimensionata a max 5,5 × 1,6 cm. Firma solo l'utente il cui nome compare tra i verificatori del verbale. Bozze e anteprime restano senza firma.
- **PDF con LibreOffice**: all'emissione vengono archiviati il Word firmato e il PDF; pulsanti «Word emesso» / «PDF emesso». Nelle bozze, **Anteprima PDF** (senza firma). Per i verbali emessi senza PDF (es. LibreOffice assente in quel momento) c'è **Crea PDF**. LibreOffice viene cercato da solo o indicato in `config.json` (`libreoffice`); l'avvio scrive se è stato trovato.
- L'emissione non richiede più di generare prima il Word: il Word definitivo è prodotto dall'emissione stessa (i controlli bloccanti vengono fatti prima di generarlo).
- Nuovo avviso **T03** se il modello non ha il riquadro «Il Verificatore».

**Modelli**
- Inclusi in `modelli_rev01` i modelli M01, M02, M03 riimpaginati (rev. 01, in approvazione): si caricano da Template come nuova revisione. Provati con i verbali di esempio (Techcab, Chieri, AGN, BASF).
- Corretto: con i modelli rev. 01 il Word generato segnalava per errore T01 sui campi delle righe ripetute (`row.*`).
- M03 rev. 01: la casella «impianti Ex i non presenti» resta vuota (decisione sul mantenerla ancora aperta).

**Regole e flusso (decisioni del 03/10)**
- Alimentazione: solo «< 1.000 V» / «> 1.000 V». Con > 1.000 V è obbligatorio il numero di cabine MT o di stazioni AT (almeno uno, **R11**). La casella «stazioni AT» dei verbali rev. 00 vale come «> 1.000 V».
- **Impianto di terra globale**: Rearth non si misura; R7 e R45 non la richiedono (avviso se è comunque scritta).
- **Metodo di misura in BT**: non indicato = Errore; voltamperometrico = Avviso (ammesso).
- **Emissione bloccata** se un elemento spuntato come provato non ha il risultato completo (differenziali: test meccanico e tempo; sovracorrenti: Zs, Ig, coordinamento; continuità: esito), o se «n.e.» è senza motivo.
- **Nuova verifica**: partono spuntati gli stessi elementi provati nell'ultima verifica (tutti se era il 100%); gli elementi nuovi del censimento partono spuntati.
- 50 prove automatiche (nuove: firma nel Word, archivio firme e scelta del firmatario, campione dalla verifica precedente, blocco dell'emissione).

**Da sapere**
- Per l'installazione sul VPS Ubuntu seguirà una versione con script di installazione (HTTPS, servizio di sistema, backup verso il server locale).

---

## 0.3.8 — Anagrafica dell'impianto

- **Seconda riga del cliente** (es. «CITTA' DI CHIERI» + «SCUOLA MATERNA»): letta dai verbali M01, M02 e M03 come «denominazione dell'impianto», mostrata nell'archivio e nella maschera, riportata nel Word generato su una seconda riga sotto la ragione sociale. Prima veniva persa.
- **Anagrafica modificabile**: pulsante «✎ Anagrafica» su ogni impianto in Clienti e impianti (ragione sociale, denominazione, indirizzo); le stesse correzioni fatte nella maschera di una bozza valgono per l'impianto. Si applicano alle nuove verifiche e alle bozze aperte; i verbali storici ed emessi restano come sono. Ogni modifica è registrata.
- In anteprima di importazione si può correggere anche la denominazione.
- **«Rileggi i verbali storici»** recupera anche la seconda riga del cliente dai verbali già importati.
- Corretta la lettura della data «in data: 04/12/2024» (con i due punti): prima veniva usata la data del verbale.
- La ricerca trova anche la denominazione (es. «materna»).

---

## 0.3.7 — Pannello controlli, esito, date

- **Controlli del verbale** richiudibili con il pulsante sopra il pannello: chiuso lascia tutta la larghezza alla maschera e mostra il numero di errori («◀ Controlli · 14 errori»). La scelta resta memorizzata nel browser.
- **Esito obbligatorio**: positivo o negativo (uno esclude l'altro); senza esito il verbale **non si può emettere** (blocco, non solo avviso).
- Con **esito positivo** le non conformità vengono compilate «NESSUNA»; passando a negativo il testo proposto viene tolto (un testo scritto a mano resta).
- **Data del verbale** riportata anche in inizio, fine verifica ed emissione (come già la data di inizio); i campi restano modificabili e, una volta cambiati a mano, non vengono sovrascritti. La scadenza si ricalcola.

---

## 0.3.6 — Elementi provati come nell'allegato Word

- Scheda **Elementi provati** rifatta come la tabella dell'allegato: il **quadro è una riga di intestazione** (si rinomina scrivendo sull'intestazione, per tutti gli elementi), una riga per circuito con le colonne del Word (differenziali: circuito, marca/modello, Idn, test meccanico, test con Idn in ms, nota). Tre schede: Differenziali, Magnetotermiche, Continuità, con il conteggio provati/totali.
- **Tutte le celle modificabili** come in una tabella (circuito, marca, modello, Idn compresi). Un nome di circuito corretto vale anche per le verifiche future.
- Test meccanico e Ig > Ia con pulsanti **SI / NO / n.e.**; il risultato dell'ultima verifica compare in grigio nella cella vuota e non viene copiato. **Invio** porta alla cella sotto (Maiusc+Invio a quella sopra).
- **Incolla da Word** (Ctrl+V su una cella): dalla colonna «Circuito» le righe vengono abbinate per nome e quelle nuove aggiunte al quadro; un'intestazione di quadro incollata (es. «Q.E.G.») crea o usa quel quadro; da un'altra colonna i valori riempiono le celle verso il basso. SI/NO/n.e. riconosciuti anche in minuscolo.
- **+ riga** in ogni quadro e **+ Nuovo quadro**; i nuovi elementi entrano nel censimento al salvataggio. Menu «⋯» di riga: sposta in un altro quadro; elimina (righe aggiunte in questa verifica) oppure «Dismesso» (elementi del censimento che non esistono più: escono dalle verifiche future).
- Righe non spuntate in grigio: restano nel censimento, non vanno nel verbale. Spunte rapide: «togli tutte», «metti tutte», «come la verifica precedente». Una nuova verifica parte ancora con tutte le righe spuntate.

---

## 0.3.5 — Numero del verbale e date

- **Numero del verbale**: si scrive solo il progressivo (es. «649»). Il prefisso viene da «Tipo verifica» (periodica → VP, straordinaria → VS) e l'anno dalla data del verbale; il numero completo (VP/649/26) si aggiorna da solo se cambiano tipo o data. Nuovo controllo in R1 / C01: prefisso non coerente con il tipo di verifica → Errore.
- **Date senza «/»**: si possono scrivere come 15102026 o 151026 (anche 15.10.26 o 15-10-2026); vengono convertite in 15/10/2026.
- **Data di inizio verifica** riportata automaticamente in fine verifica, data del verbale ed emissione (e nella data «in data» del modello). I campi restano modificabili: una volta cambiati a mano non vengono più sovrascritti.
- **Maschera M01 nell'ordine del Word**: schede «Verbale» (intestazione, azienda, descrizione dell'impianto, documentazione, esito e note, periodicità e chiusura), «Rapporto di verifica» (sistema disperdente, continuità, magnetotermiche, resistenza di terra, differenziali, prescrizioni particolari, guasti in alta tensione, tensioni di contatto, allegati), «Elementi provati», «Strumentazione e modello», «Riesame». Le voci sono righe come nel verbale (etichetta e caselle affiancate), le voci dipendenti sono rientrate sotto quella principale; numero cabine e stazioni stanno sulla riga dell'alimentazione.
- Le voci che non si applicano all'alimentazione scelta sono attenuate, con un'indicazione (es. «in BT: non applicabile»); restano modificabili.
- **Scelte esclusive**: nelle voci a scelta singola spuntare una casella toglie le altre (tipo verifica, sistema, periodicità, esito, SI/NO/n.a.…); «Ordinario» esclude le altre classificazioni; «< 1.000 V» esclude «> 1.000 V» e «Stazioni AT»; «totale/parziale» spuntano «presente». Vale anche per M02/M03.
- **Limite Utp** proposto 25 V per uso medico, 50 V negli altri casi; modificabile (es. locali zootecnici 25 V). Il calcolo Re × If non viene più eseguito né riproposto: R35 controlla solo che il limite sia indicato quando la relazione è applicabile.
- **Campi obbligatori** segnati con un asterisco rosso: date, ore uomo, rappresentante del datore di lavoro, tipo di verifica, periodicità, scadenza; nel M01 anche anno di installazione, potenzialità, tensione di esercizio e Rearth. Se mancano sono Errore nei controlli (R25, R41, R3b, R4 per il M01; C10, C11, C00, C06 per M02/M03).

---

## 0.3.4 — Navigazione

- Pulsante **← Indietro** in ogni verbale (storico, bozza o emesso): torna alla schermata da cui era stato aperto (Clienti e impianti o Bozze), salvando prima le modifiche. Funziona anche il tasto «indietro» del browser.
- In **Clienti e impianti**, sotto ogni impianto, l'elenco dei verbali registrati (modulo, numero, data), dal più recente; un clic apre il verbale. Bordo tratteggiato = bozza, fondo verde = emesso.
- La ricerca trova anche i numeri di verbale (es. «649»).

---

## 0.3.3 — Lettura corretta delle caselle, verbali storici riletti

**Correzione importante**
- Nei verbali reali (es. VP/649/26 Techcab) alcune caselle hanno lo stato interno di Word «spuntato» ma il simbolo visibile ☐: in VP/649 sono 16 su 76. Fino alla 0.3.2 il programma leggeva lo stato interno e mostrava spuntate quasi tutte le voci (tutti i sistemi, tutte le alimentazioni, tutti i dispersori…). Ora vale il **simbolo visibile** (☒ / ☐), cioè quello che si legge e si stampa; lo stato interno si usa solo se il simbolo non è riconoscibile. Vale per M01, M02 e M03.
- All'importazione un avviso indica quante caselle avevano stato interno e simbolo diversi.

**Per sistemare l'archivio esistente**
- Nuovo pulsante **Backup e ripristino → Rileggi i verbali storici** (amministratore): rilegge caselle e allegati dichiarati dai Word originali già archiviati. Anagrafiche, elementi e note non cambiano; prima viene fatta una copia automatica. Reimportare lo stesso file non basta, perché un file già presente non viene letto di nuovo.
- **Elimina** nelle bozze non emesse: la bozza sparisce da bozze, storico e riferimenti, ma resta nell'archivio come «scartata», per la coerenza di registro e backup. Le bozze create dai verbali letti male vanno eliminate e ricreate.

**Prove**: 42 prove automatiche (nuove: simbolo visibile contro stato interno, rilettura degli storici, eliminazione delle bozze, VP/649 reale); nel browser: VP/649 importato con la 0.3.2 (5 sistemi spuntati), riletto con la 0.3.3 (solo TT).

---

## 0.3.2 — Regole M01 per bassa e media tensione, emissione con conferma

**Regole M01** (documento «Specifica regole verbale M01 — messa a terra» del 02/10/2026)
- I controlli dipendono dall'alimentazione: < 1.000 V oppure > 1.000 V (cabine MT e stazioni AT). Prima dipendevano dal sistema TT/TN e molti erano solo avvisi; ora una voce non ammessa è un **Errore**.
- Nuove: R42 anno di installazione (ammesso «n.a.»), R43 potenzialità, R44 tensione di esercizio, R45 Rearth sempre numerica.
- Solo in bassa tensione: R46 niente cabine né stazioni, R47 niente corrente di guasto MT né tempo di intervento, R48 niente «sovracorrenti» né allegato magnetotermiche, R49 prescrizioni particolari «non applicabili» con colonna destra vuota, R50 tensioni di contatto «non applicabile».
- Solo in media/alta tensione: R51 prescrizioni particolari (se applicabili, ogni voce a destra conforme / non conforme / non applicabile), R52 giudizio Re × If ≤ Utp compilato, R53 tensioni di contatto con scelta ed esito.
- Modificate: R6 Ig > Ia (BT «non applicabile», MT SI/NO), R7 metodo (BT non voltamperometrico, MT solo voltamperometrico), R8 Re × Idn (BT SI/NO, MT «non applicabile»), R10 guasti AT, R11 numero cabine obbligatorio in MT, R16 BT ↔ TT e MT ↔ TN/IT come Errore, R17 corrente e tempo di guasto obbligatori in MT, R23 criterio magnetotermiche solo in MT, R31 tempo di intervento TN mai in BT. R32 non impone più «non applicabili» ai TT.
- Interpretazioni adottate sulle domande ancora aperte della specifica: le stazioni AT seguono le regole > 1.000 V (domanda 1); una risposta «NO» resta un **Avviso** da confrontare con non conformità ed esito, mentre una voce non ammessa è un Errore (domanda 3); in BT non si spunta «sovracorrenti» né si dichiara l'allegato magnetotermiche (domanda 6); l'anno di installazione accetta qualsiasi testo (domanda 7); Rearth deve essere un numero anche con terra globale (domanda 8). Si cambiano facilmente se la decisione è diversa.

**Compilazione**
- **Scadenza automatica**: inizio verifica + 2 o 5 anni − 1 giorno, ricalcolata quando cambiano data di inizio, periodicità o ambiente, finché non viene modificata a mano. Pulsante «Ricalcola scadenza».
- **Tensioni di contatto** proposte «non applicabile» nelle nuove bozze M01, salvo sottostazioni (stazioni AT selezionate o numero di stazioni compilato).
- **M02**: classificazione dell'ambiente nella scheda Impianto (solo VerbalizzAI, non stampata nel Word); controllo S06: ordinario → 5 anni, altrimenti 2 anni. Tolto l'avviso «criteri SPD n.a. con indicatori compilati».

**Emissione**
- Con errori o avvisi aperti la finestra «Emetti il verbale» li elenca con le valutazioni scritte e chiede di spuntare una conferma; il server rifiuta l'emissione senza conferma. Elenco e conferma restano registrati nel verbale emesso e sono mostrati nella sua intestazione.

**Importazione**
- I modelli vuoti (nessun cliente né numero) vengono riconosciuti in anteprima e non archiviati, con l'indicazione di caricarli dalla sezione Template.
- Un documento non archiviato mostra il motivo in rosso sotto di sé (correzione già distribuita il 02/10 per la 0.3.1).

**Prove**: 39 prove automatiche (nuove: regole BT e MT corrette ed errate, emissione con conferma, tensioni di contatto, ambiente M02 e SPD); flusso nel browser: template M02, importazione di un verbale e di un modello vuoto, nuova verifica M02, scadenza automatica, emissione con conferma.

**Limiti noti:** le regole M01 sono provate su casi costruiti, non ancora sui DOCM originali VP/034, 625, 674; la scelta «BT ↔ MT» non svuota i campi diventati non ammessi (proposta della specifica, da decidere).

---

## 0.3.1 — Moduli M02 e M03, quadri elettrici

**M02 (scariche atmosferiche) e M03 (luoghi con pericolo di esplosione)**
- Riconoscimento automatico del modulo dal titolo del verbale.
- Lettura dei verbali M02/M03: tutte le caselle (individuate dal testo che le precede nel modello, in ordine), intestazione, date anche come intervallo («10-11/08/2026»), verificatori, descrizioni, note delle celle, criteri di campionamento, Rearth, non conformità, note, scadenza, ore, rappresentante, data di emissione e firme, strumenti.
- Associazione automatica dei modelli `M02-PO01_dpr` e `M03-PO01_dpr` rev. 00 del 29.09.2025 per la generazione del Word; testi inseriti con il carattere del modello e la dimensione del testo delle tabelle.
- Prova di andata e ritorno sui 5 verbali reali (VP/447, 536, 537, 675, 676/26): lettura → generazione → nuova lettura con dati identici.
- Maschere dedicate: Impianto, Verifica, Esame e prove, Documentazione, Riesame; per ogni voce di esito è mostrato l'esito della verifica precedente.
- Controlli consultivi C00–C14 (comuni), S01–S05 (M02), X01–X06 (M03). Sui verbali reali segnalano: oggetto della verifica del M02 nei verbali M03 (VP/537 e VP/676), scelta gas/polveri mancante, revisioni diverse del modello nello stesso documento, data del verbale a intervallo (VP/537), Rearth riportata con LPS esterno non applicabile (VP/536), criteri SPD «n.a.» con indicatori compilati (VP/675).
- Scadenza M03 calcolata come biennale.

**Archivio**
- Storico e «base» della verifica successiva distinti per impianto + modulo.
- Nuova verifica con scelta del modulo; senza storico di quel modulo si parte vuoti dal template caricato, con ragione sociale e sede dell'impianto.
- Template associati a un modulo; la bozza propone l'ultimo template dello stesso modulo.

**Quadri elettrici (M01)**
- Una sola intestazione per quadro nel Word generato, anche se gli elementi sono in ordine sparso.
- Nuova bozza con gli elementi raggruppati per quadro; un nuovo elemento entra nel blocco del suo quadro.
- Quadro modificabile nella tabella dei campioni, con suggerimenti; la correzione vale per le verifiche future.
- «Rinomina / unisci quadro» per tutti gli elementi di un quadro.
- Anteprima di importazione con l'elenco dei quadri riconosciuti.

**Altro**
- Eliminata la chiamata alle funzioni dei dischi di Windows (riduce i falsi allarmi antivirus). Le unità di rete mappate non sono più riconosciute automaticamente: resta il blocco dei percorsi `\\server\cartella`.
- La frase «Il Verificatore … ha proceduto» diventa «I Verificatori … hanno proceduto» quando i verificatori sono più di uno.
- 33 prove automatiche (le prove M02/M03 richiedono i verbali di esempio indicati con `AD_TEST_WORD_DIR`, non inclusi nel pacchetto).

**Correzione del 02/10/2026 (stesso numero di versione, cambia solo `static/app.js`)**
- Importazione: se un documento non viene archiviato, il motivo compare in rosso sotto quel documento nella finestra «Conferma l’importazione» (prima il messaggio restava nascosto dietro la finestra). Gli altri documenti proseguono; il pulsante diventa «Riprova i non archiviati».

**Limiti noti:** impaginazione M03 con interruzione di pagina del modello (possibile pagina in più con testi lunghi); costruzioni Ex «i» senza opzione «non presenti» nel modello (il controllo X05 lo segnala come avviso); tre M01 originali ancora da provare.

---

## 0.3.0 — Versione server multiutente

**Rete e installazione**
- Un solo programma gira sul server; gli ispettori lo usano dal browser (rete interna o VPN).
- Il programma rifiuta di partire se l'archivio è su una cartella condivisa o un'unità di rete, dove il database rischierebbe di corrompersi.
- `config.json` per porta, cartella archivio e cartella backup.
- Script per Windows Server 2022: avvio automatico all'accensione (account SYSTEM), riavvio se il programma si chiude, regola firewall, registro in `logs\server.log`; script di disinstallazione.
- HTTPS opzionale con certificato.

**Utenti e tracciabilità**
- Accesso con utente e password; ruoli **amministratore** (utenti, template, strumenti, backup, revisioni) e **ispettore** (import, compilazione, emissione).
- Primo amministratore creabile solo dal server stesso o da riga di comando.
- Password di almeno 10 caratteri, conservate come impronta (PBKDF2); blocco di 1 minuto dopo 5 tentativi errati; sessioni di 12 ore; protezione dalle richieste contraffatte.
- Ogni modifica registra l'utente che l'ha fatta; l'elenco bozze mostra chi ha salvato per ultimo.
- Il verificatore della nuova bozza è l'utente che la crea (modificabile).

**Emissione e revisioni**
- «Emetti verbale»: possibile solo se l'ultimo Word generato corrisponde alla versione attuale della bozza; dopo l'emissione il verbale è bloccato e resta archiviato il Word emesso.
- Rifiutata l'emissione con un numero già usato da un altro verbale emesso.
- «Crea revisione» (amministratore): nuova bozza rev. 1, 2… con lo stesso numero; l'originale resta nello storico. La verifica successiva parte dall'ultima revisione emessa.

**Backup**
- Cartella `documenti` con una copia di ogni Word, scritta una volta e mai modificata.
- Copie automatiche dei soli dati, al massimo ogni 5 minuti e subito dopo importazioni, emissioni, template e utenti; conservate le ultime 50 più una al giorno per 90 giorni.
- Backup completo in un unico file, scritto in streaming (nessun limite di 150 MB); ripristino da copia del server o da file, con verifica di integrità.
- Prova con 600 verbali: salvataggio < 0,01 s; copia automatica 0,12 s e 0,30 MB (nella 0.1: 75 MB e 2,3 s già con 300 verbali).

**Avvio su Windows (01/10/2026)**
- `TROVA_PYTHON.bat`: cerca Python 3.10+ tramite il launcher `py`, nelle cartelle di installazione e nel PATH, scartando l'alias del Microsoft Store.
- Messaggi distinti per «Python non trovato» e «programma fermato con un errore».

**Limiti noti**
- Mai provata su Windows Server; script PowerShell non ancora provati.
- Su un PC di prova l'antivirus ha rimosso `app.py` (probabile falso positivo: server di rete + gestione password + chiamata a funzioni di sistema). Prevista una revisione che elimini la chiamata alle funzioni dei dischi di Windows e sposti la gestione utenti da riga di comando in uno script separato.

---

## 0.2.0 — Compilazione più rapida

- **Misure e criteri riproposti** dall'ultima verifica per confronto (Re, calcolo Re × If, continuità, tensioni di contatto, criteri di campionamento, Uo, Utp).
- Le misure restano segnalate «da aggiornare» (avviso **D03**) finché non vengono modificate o confermate con «conferma invariato».
- **Spunta «provato in questa verifica»** sui campioni, attiva per impostazione predefinita, al posto del menu «Stato nella verifica».
- Test meccanico **SI / NO / n.e.** e tempo in ms; con «n.e.» la prova risulta non eseguita.
- Pulsanti **Tutti**, **Nessuno**, **Solo campione precedente**.
- **Registro strumenti** (tipo, marca, modello, matricola, ultima taratura, scadenza, verificatore assegnatario); proposta automatica degli strumenti del verificatore; avviso «in scadenza» (30 giorni) e «scaduta»; controllo **R24** sulla taratura alla data di inizio verifica.
- La nuova bozza parte dall'**ultima verifica svolta** (storico importato o bozza già generata in Word), mai da una bozza vuota.
- Corretta l'etichetta «Ultima verifica:» vuota sotto campi mai compilati.
- Numerazione manuale (assegnata dal gestionale).

**Limiti:** un solo PC, nessun accesso con utenti, verbale emesso ancora modificabile, backup automatici che copiano l'intero archivio a ogni salvataggio (adatti solo a prove con pochi verbali).

---

## 0.1.0 — Prototipo iniziale

- Importazione dei verbali Word DOCX/DOCM (M01 messa a terra): intestazione, anagrafica, flag, differenziali, magnetotermiche, continuità, strumenti. Macro mai eseguite.
- Word originale conservato con impronta SHA-256; reimportare lo stesso file non crea doppioni.
- Archivio impianti con parco elementi costruito progressivamente dagli storici; differenze fra verbali conservate e segnalate (D02).
- Bozza di nuova verifica con anagrafica e caratteristiche riproposte, risultati da compilare.
- Template Word versionati: associazione automatica per il M01, segnaposto `{{campo}}`, tabelle ripetibili, avvisi T01/T02.
- Controlli R0–R41 adattati da RiesaminAI, tutti consultivi.
- Generazione del Word anche con alert ed esito negativo.
- Conflitto fra due finestre sulla stessa bozza: il secondo salvataggio viene rifiutato.
- Backup con verifica di integrità e ripristino.

**Limiti emersi in revisione:** backup non scalabile, verbale emesso modificabile, possibile riferimento a bozze vuote. Corretti nelle versioni successive.

---

## Problemi noti aperti (tutte le versioni)

- **Quadri elettrici:** un differenziale storico con il solo nome può ancora essere letto come intestazione di quadro all'importazione (l'anteprima elenca i quadri riconosciuti per controllarlo). Corretti nella 0.3.1: intestazioni doppie, quadro non modificabile, nomi diversi dello stesso quadro.
- **M01 mai provato sui tre DOCM originali** di AD (VP/034, 625, 674).
- **Modelli M02/M03:** riconoscimento costruito sulla rev. 00 del 29.09.2025; nel modello M02 la voce «mancanti e/o danneggiati e/o funzionanti» degli indicatori SPD probabilmente intende «non funzionanti».
- **Regole in due copie** (RiesaminAI e VerbalizzAI), che possono divergere. Dalla 0.3.2 il riferimento comune per il M01 è la «Specifica regole verbale M01» del 02/10/2026: RiesaminAI va allineato.
- **Impaginazione, firme e numero di pagine** da controllare sempre sul documento finale.
# 1.0.0 — 09/10/2026

Candidata al rilascio su archivio già in produzione. Conserva formato 2 e modelli Word. Correzioni mirate al calcolo Ig ≥ Ia nelle bozze, visualizzazione immutabile dei risultati storici, verifica/riparazione delle copie documentali per il backup. Nella tabella, «Dismesso» è distinto da «Fuori campione» e le prove negative sono distinte dalla valutazione complessiva del verbale. Dettagli e procedura: AGGIORNAMENTO_1.0.0.md; prove: VERIFICA_1.0.0.md.

