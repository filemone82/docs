"""VerbalizzAI AD dentro il gestionale: il modulo di verbalizzazione (D27, D67; documento 15).

Versione di origine: VerbalizzAI AD 1.0.1.
I file sono quelli di VerbalizzAI, SENZA MODIFICHE tranne gli import tra i suoi file, resi relativi
(«from .wordio import …») dallo script `strumenti/aggiorna_verbalizzai.py`.
Il gestionale li usa attraverso `gestionale/moduli/verbali` (utenti, permessi, anagrafica e posta del gestionale):
l'anagrafica (cliente, sede, impianto) è una sola, quella del gestionale.

Per passare a una versione più recente di VerbalizzAI:
    python strumenti/aggiorna_verbalizzai.py <cartella o zip di VerbalizzAI>
poi tutti i test (in particolare tests/test_ponte_contratto.py e tests/test_verbali.py) e una prova nel browser.
"""

VERSIONE = "1.0.1"
