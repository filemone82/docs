"""VerbalizzAI AD: web application. Python 3.10+, no pip packages.

Local test:  python app.py
Server:      python app.py --server --data-dir D:\\VerbalizzAI\\archivio --backup-dir E:\\VerbalizzAI\\backup
"""
from __future__ import annotations
import argparse, base64, datetime as dt, getpass, hmac, ipaddress, json, mimetypes, os, re, secrets, ssl, sys, threading, time, traceback, urllib.parse, webbrowser
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
from .storage import Archive,Conflict,Duplicate,APP_VERSION,ROLES,ROLE_LABELS,PERMISSIONS
from . import mailer
from .wordio import parse_word,GROUPS,LABELS
from .templates import adapt_template,generate_word,field_values,auto_attachments,annex_roles
from .rules import evaluate,RULES_VERSION,due,UTP_TABLE,UTP_BEYOND
from . import pdfconv; from . import layout; from . import templates
from . import finalization

ROOT=Path(__file__).resolve().parent
SESSION_IDLE=12*3600
# Permesso richiesto da ogni funzione (i ruoli e i permessi si configurano in «Utenti e permessi»).
NEEDS={'/api/review/preview':'draft','/api/review/upload':'draft','/api/review/issue':'issue','/api/review/final':'send','/api/import/preview':'import','/api/import/commit':'import','/api/import/finish':'import',
  '/api/plant/state/adopt':'plant_technical','/api/plant/state/save':'plant_technical','/api/draft/state/compare':'draft','/api/draft/new':'draft','/api/draft/save':'draft','/api/asset/add':'draft','/api/board/rename':'plant_technical','/api/export':'draft','/api/calculate/due':'draft',
  '/api/inspection/issue':'issue','/api/inspection/precheck':'issue','/api/inspection/revision':'revision','/api/draft/delete':'draft_delete','/api/inspection/annul':'annul','/api/inspection/annul-restore':'annul',
  '/api/plant/new':'plant','/api/plant/update':'plant','/api/plant/delete':'annul','/api/template/import':'templates','/api/template/preview':'templates','/api/template/assign':'templates','/api/template/delete':'templates','/api/oplog':'oplog','/api/instrument/save':'instruments',
  '/api/instrument/import/preview':'instruments','/api/instrument/import/commit':'instruments','/api/signatures':'signatures_view',
  '/api/mail/prepare':'send','/api/inspection/send':'send','/api/mail/settings':'users','/api/mail/texts':'users','/api/mail/test':'users',
  '/api/export/pdf-regenerate':'backup',   # 0.3.25 (punto 50): manutenzione, come la rilettura degli storici
  '/api/backup':'backup','/api/backup/local':'backup','/api/backup/verify':'backup','/api/backup/restore':'backup','/api/backup/restore-local':'backup','/api/reread':'backup',
  '/api/users':'users','/api/users/add':'users','/api/users/update':'users','/api/users/rename':'users','/api/users/delete':'users','/api/permissions':'users'}
PERM_LABEL=dict(PERMISSIONS)
def default_data():
    if os.name=='nt':return Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'AppData/Local')))/'AD'/'VerbalizzAI'
    return Path.home()/'.local/share/AD/VerbalizzAI'
def decode_file(req):
    try:b=base64.b64decode(req['content'],validate=True)
    except Exception:raise ValueError('Contenuto del file non valido.')
    return b,Path(req.get('filename','documento.docx')).name

# --- 0.3.25 (punto 51): nomi dei file Word e PDF ----------------------------------------------
FORBIDDEN=str.maketrans({c:None for c in '/\\:*?"<>|“”‘’«»'})
MAX_PART=80      # caratteri della parte «ragione sociale + seconda riga»
MAX_STEM=120     # caratteri del nome senza estensione

def clean_part(s):
    """Ragione sociale utilizzabile come nome di file: via i caratteri vietati da Windows e le
    virgolette tipografiche, spazi normalizzati, lunghezza limitata."""
    s=re.sub(r'\s+',' ',str(s or '').translate(FORBIDDEN)).strip()
    s=''.join(ch for ch in s if ch >= ' ')
    return s[:MAX_PART].strip()

def document_filename(d,ext='docx',draft=False):
    """Nome del file come deciso il 04/10: «VP_111_26 - MASSANO s.n.c.pdf»,
    «VP_700_26 - VERDELLO S.r.l. - Residenza CASAMIA VERDELLO.pdf», revisioni «VP_700_26_rev1 - …».
    Le bozze («Genera Word» e «Anteprima PDF» prima dell'emissione) finiscono con « - BOZZA»;
    senza numero il nome parte da «Bozza». Niente «_AD».
    Se la ragione sociale finisce con un punto («s.n.c.») il punto dell'estensione non si raddoppia."""
    h=d.get('header',{});p=d.get('plant',{})
    number=str(h.get('number') or '').replace('/','_').strip()
    if number and d.get('rev_index'):number+='_rev'+str(d['rev_index'])
    who=' - '.join(x for x in (clean_part(p.get('client_name')),clean_part(p.get('site_name'))) if x)
    head=number or 'Bozza'
    stem=head+(' - '+who if who else '')
    if draft and number:stem+=' - BOZZA'
    stem=re.sub(r'\s+',' ',stem).strip()[:MAX_STEM].strip()
    if not stem:stem='Documento'
    return stem+ext if stem.endswith('.') else stem+'.'+ext

def build_word(a,item,signature=None,want_pdf=False,draft=True,reserve=None):
    """Word dalla bozza con il template scelto (firma grafica solo all'emissione).
    Con LibreOffice: conta le pagine di ciascun allegato nel PDF e le scrive nel Word (seconda generazione)."""
    d=item['data'];tid=d.get('template_id')
    if not tid or tid not in {x['id'] for x in a.active_templates()}:
        # Bozza senza modello (es. importata prima di caricare i template): si usa il più recente del suo modulo.
        ts=a.templates_for(a.module_of(d))
        if not ts:raise ValueError('Nessun template Word '+a.module_of(d)+' caricato: caricarlo nel menu Template Word.')
        tid=max(ts,key=lambda x:x['updated_at'])['id']
    template=a.get(tid)['data'];_,blob=a.document(template['adapted_sha'])
    dd=auto_attachments(d)
    if d.get('revision_of') and not d.get('revision_reference'):
        previous=a.get(d['revision_of'])['data']
        dd['revision_reference']={'number':previous['header'].get('number',''),'rev_index':int(previous.get('rev_index',0)),'issued_date':previous['header'].get('issued_date','')}
    lo=bool(pdfconv.find());measure=lo and templates.SIGN_AT_BOTTOM
    output,missing=generate_word(blob,dd,signature,reserve=reserve,measure=measure);pdf=None;pdf_error=''
    if lo:
        try:
            first=pdfconv.to_pdf(output);pages=pdfconv.annex_pages(first,annex_roles(missing))
            # 1.0.0 rc3: la prima generazione serve anche a misurare lo spazio sotto i riquadri firme.
            spaces=layout.spaces_from(output,first) if measure else []
            if pages or measure:
                if pages:
                    reference=dd.get('revision_reference');dd=auto_attachments(d,pages)
                    if reference:dd['revision_reference']=reference
                output,missing=generate_word(blob,dd,signature,reserve=reserve,sign_space=spaces)
                if spaces and any(spaces):
                    # Verifica anche la pagina di ciascuna firma, non solo il totale delle pagine.
                    marked,_=generate_word(blob,dd,signature,reserve=reserve,measure=True,sign_space=spaces)
                    marked_pdf=pdfconv.to_pdf(marked)
                    before,total=pdfconv.outline_points(first)
                    after,new_total=pdfconv.outline_points(marked_pdf)
                    expected=len(spaces)
                    same_places=(total==new_total and
                                 layout.signature_pages(before,expected) is not None and
                                 layout.signature_pages(before,expected)==layout.signature_pages(after,expected))
                    check=pdfconv.to_pdf(output)
                    if not same_places or pdfconv.outline(check)[1]!=total:
                        output,missing=generate_word(blob,dd,signature,reserve=reserve);check=pdfconv.to_pdf(output)
                    pdf=check if want_pdf else None
                else:pdf=pdfconv.to_pdf(output) if want_pdf else None
            else:pdf=first if want_pdf else None
        except RuntimeError as err:pdf_error=str(err)
    elif want_pdf:pdf_error=pdfconv.status()['hint']
    alerts=evaluate(dd,template)
    additions=[k[10:] for k in missing if k.startswith('AD_APPEND:')];unknown=[k for k in missing if not k.startswith('AD_')]
    if unknown:alerts.append({'code':'T01','title':'Campi del template non associati','status':'Avviso','detail':', '.join(unknown),'blocking':False})
    if additions:alerts.append({'code':'T02','title':'Allegati aggiunti al modello','status':'Avviso','detail':'Il template non conteneva queste tabelle: '+', '.join(additions)+'. Aggiunti allegati standard; verificare impaginazione e approvazione del modello.','blocking':False})
    if 'AD_SIGNATURE' in missing:alerts.append({'code':'T03','title':'Firma non inserita','status':'Avviso','detail':'Nel modello non è stato trovato il riquadro «Il Verificatore»: firmare il PDF a mano o aggiornare il template.','blocking':False})
    filename=document_filename(d,'docx',draft=draft)
    roles=annex_roles(missing)
    missing=[k for k in missing if not k.startswith('AD_ANNEX:')]
    return {'word':output,'alerts':alerts,'missing':missing,'filename':filename,'attachments':dd['attachments'],'annex_roles':roles,'pdf':pdf,'pdf_error':pdf_error}

class Sessions:
    def __init__(self):self.items={};self.lock=threading.Lock();self.failures={}
    def create(self,user):
        sid=secrets.token_urlsafe(32)
        with self.lock:self.items[sid]={'user':user['username'],'csrf':secrets.token_urlsafe(24),'last':time.time()}
        return sid
    def get(self,sid):
        with self.lock:
            s=self.items.get(sid or '')
            if not s:return None
            if time.time()-s['last']>SESSION_IDLE:self.items.pop(sid,None);return None
            s['last']=time.time();return dict(s)
    def drop(self,sid):
        with self.lock:self.items.pop(sid or '',None)
    def drop_user(self,username):
        with self.lock:
            for k in [k for k,v in self.items.items() if v['user']==username]:self.items.pop(k)
    def throttle(self,key):
        with self.lock:
            n,until=self.failures.get(key,(0,0))
            if time.time()<until:raise PermissionError('Troppi tentativi: riprovare fra un minuto.')
    def failed(self,key):
        with self.lock:
            n,_=self.failures.get(key,(0,0));n+=1
            self.failures[key]=(n,time.time()+60 if n>=5 else 0)
    def ok(self,key):
        with self.lock:self.failures.pop(key,None)

class Handler(BaseHTTPRequestHandler):
    server_version='VerbalizzAI';sys_version=''
    def log_message(self,fmt,*args):
        # Keep filenames and inspection data out of the log.
        if len(args)>1 and str(args[1]).isdigit() and int(args[1])>=400:
            print(dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),'Richiesta non completata:',str(args[1]),flush=True)
    def send(self,status,data,ctype='application/json; charset=utf-8',filename=None,cookie=None,inline_pdf=False):
        if isinstance(data,(dict,list)):data=json.dumps(data,ensure_ascii=False).encode('utf-8')
        elif isinstance(data,str):data=data.encode('utf-8')
        self.send_response(status);self.send_header('Content-Type',ctype);self.send_header('Content-Length',str(len(data)))
        self.headers_common(filename,cookie,inline_pdf);self.end_headers();self.wfile.write(data)
    def send_path(self,path,filename,remove=False):
        try:
            size=path.stat().st_size;self.send_response(200);self.send_header('Content-Type','application/zip');self.send_header('Content-Length',str(size))
            self.headers_common(filename);self.end_headers()
            with open(path,'rb') as f:
                for chunk in iter(lambda:f.read(1<<20),b''):self.wfile.write(chunk)
        finally:
            if remove and path.exists():path.unlink()
    def headers_common(self,filename=None,cookie=None,inline_pdf=False):
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer');self.send_header('X-Frame-Options','SAMEORIGIN' if inline_pdf else 'DENY')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors "+("'self'" if inline_pdf else "'none'")+"; form-action 'self'; base-uri 'none'")
        if filename:self.send_header('Content-Disposition',("inline; filename*=UTF-8''" if inline_pdf else "attachment; filename*=UTF-8''")+urllib.parse.quote(filename))
        if cookie is not None:
            secure='; Secure' if self.client_tls() else ''   # 0.3.28: vale anche con TLS terminato dal proxy
            self.send_header('Set-Cookie',('ADSESSION='+cookie+'; HttpOnly; SameSite=Strict; Path=/'+secure) if cookie else 'ADSESSION=; Max-Age=0; HttpOnly; SameSite=Strict; Path=/'+secure)
    def sid(self):
        for part in self.headers.get('Cookie','').split(';'):
            k,_,v=part.strip().partition('=')
            if k=='ADSESSION':return v
        return ''
    # --- 0.3.28: consapevolezza del proxy inverso ------------------------------------------------
    # Senza questa, dietro Nginx ogni richiesta sembra arrivare da 127.0.0.1: il controllo sul
    # loopback diventa vero per chiunque e il blocco dei tentativi non distingue piu' i client.
    # Le intestazioni si leggono SOLO se il collegamento arriva davvero dal loopback (cioe' dal
    # proxy sulla stessa macchina) e solo con --behind-proxy: altrimenti chiunque potrebbe
    # dichiarare l'indirizzo che preferisce.
    def _from_loopback(self):return self.client_address[0] in ('127.0.0.1','::1')
    def client_ip(self):
        if getattr(self.server,'behind_proxy',False) and self._from_loopback():
            # Contratto con il solo Nginx locale: sovrascrivere, non concatenare.
            values=self.headers.get_all('X-Forwarded-For',[])
            if len(values)!=1:raise PermissionError('Proxy non configurato: X-Forwarded-For deve contenere un solo indirizzo.')
            try:return str(ipaddress.ip_address(values[0].strip()))
            except ValueError:raise PermissionError('Proxy non configurato: indirizzo client non valido.')
        return self.client_address[0]
    def client_tls(self):
        if getattr(self.server,'tls',False):return True
        if getattr(self.server,'behind_proxy',False) and self._from_loopback():
            values=self.headers.get_all('X-Forwarded-Proto',[])
            if len(values)!=1 or values[0].strip().lower() not in ('http','https'):
                raise PermissionError('Proxy non configurato: protocollo client non valido.')
            return values[0].strip().lower()=='https'
        return False
    def local_client(self):return self.client_ip() in ('127.0.0.1','::1')
    def guard(self,path,mutation=False):
        if getattr(self.server,'behind_proxy',False):
            if not self._from_loopback():raise PermissionError('Accesso consentito soltanto dal proxy locale.')
            self.client_ip();self.client_tls()  # intestazioni assenti o ambigue: rifiutare
        host=self.headers.get('Host','')
        if self.server.allowed_hosts and host.lower() not in self.server.allowed_hosts:raise PermissionError('Indirizzo non ammesso. Aggiungerlo a allowed_hosts nella configurazione.')
        if mutation:
            origin=self.headers.get('Origin')
            if origin and urllib.parse.urlparse(origin).netloc.lower()!=host.lower():raise PermissionError('Origine della richiesta non ammessa.')
        self.session=None;self.user=None;self.server.archive.set_actor('')
        if not path.startswith('/api/') or path in ('/api/me','/api/login','/api/setup','/api/logout'):return
        s=self.server.sessions.get(self.sid());u=self.server.archive.user(s['user']) if s else None
        if not s or not u or not u['active']:raise PermissionError('LOGIN')
        if mutation and self.headers.get('X-AD-Token')!=s['csrf']:raise PermissionError('Sessione non valida: ricaricare la pagina.')
        need=NEEDS.get(path)
        if need and not self.server.archive.can(u,need):raise PermissionError('Il tuo ruolo non ha il permesso: '+PERM_LABEL[need]+'. Chiedere all’amministratore.')
        self.session=s;self.user=u;self.server.archive.set_actor(u['username'])
    def fail(self,e):
        if isinstance(e,PermissionError):return self.send(401 if str(e)=='LOGIN' else 403,{'error':'Accesso richiesto.' if str(e)=='LOGIN' else str(e),'login':str(e)=='LOGIN'})
        if isinstance(e,Conflict):return self.send(409,{'error':str(e),'conflict':True})
        if isinstance(e,Duplicate):return self.send(409,{'error':str(e),'duplicate':True})
        if isinstance(e,(ValueError,KeyError,json.JSONDecodeError)):return self.send(400,{'error':str(e)})
        traceback.print_exc();self.send(500,{'error':'Operazione non completata. I dati già salvati rimangono nell’archivio.'})
    # --- 0.3.24: invio dei verbali via email -------------------------------------------------------
    def mail_settings(self):
        a=self.server.archive;ex=next((x for x in sorted(a.light_inspections(),key=lambda x:x['updated_at'],reverse=True) if x['status']=='issued'),None)
        values=mailer.values_for(a.get(ex['id'])['data']) if ex else {'numero':'VP/649/26','data_verbale':'03/10/2026','data_verifica':'03/10/2026','modulo':'M01',
          'tipo_verifica':'verifica periodica dell’impianto di messa a terra','cliente':'Cliente di esempio S.r.l.','impianto':'Cliente di esempio S.r.l. – Scuola','indirizzo':'Via Roma 1, Torino',
          'verificatore':'Mario Rossi','esito':'positivo','prossima_verifica':'02/10/2028'}
        return {'server':self.server.mail.public(),'texts':a.mail_texts(),'placeholders':mailer.PLACEHOLDERS,'defaults':mailer.DEFAULT_TEXTS,'unknown':mailer.unknown_fields(*a.mail_texts().values()),'example':values,'example_from':ex['number'] if ex else ''}
    def mail_item(self,iid):
        a=self.server.archive;item=a.get(iid)
        if item['kind']!='inspection':raise ValueError('Verbale non trovato.')
        d=item['data']
        if d.get('status')!='issued':raise ValueError('Si possono inviare solo i verbali emessi.')
        exp=a.get(d['issued_export_id']) if d.get('issued_export_id') else None
        if not exp:raise ValueError('Documento emesso non trovato.')
        if not exp['data'].get('pdf_sha'):
            # PDF mancante (es. emesso senza LibreOffice): si prova a crearlo adesso dal Word emesso.
            if not pdfconv.find():raise ValueError('Il verbale non ha il PDF e LibreOffice non è disponibile: crearlo con «Crea PDF» quando LibreOffice è installato.')
            _,word=a.document(exp['data']['sha'])
            try:a.attach_pdf(exp['id'],pdfconv.to_pdf(word,exp['data']['filename']))
            except RuntimeError as err:raise ValueError('PDF non creato: '+str(err))
            exp=a.get(exp['id'])
        return item,exp
    def mail_prepare(self,iid):
        a=self.server.archive;item,exp=self.mail_item(iid);d=item['data'];cfg=self.server.mail.public();texts=a.mail_texts();v=mailer.values_for(d)
        body=mailer.render(texts['body'],v)+('\n\n--\n'+texts['signature'] if texts.get('signature') else '')
        name,pdf=a.document(exp['data']['pdf_sha'])
        return {'recipients':a.mail_recipients(d['plant_id']),'office_copy':cfg['office_copy'],'from':cfg['from_address'],'configured':cfg['configured'],
          'subject':mailer.render(texts['subject'],v),'body':body,'attachments':[{'name':name,'size':len(pdf),'sha':exp['data']['pdf_sha']}],'mailings':a.mailings(iid),'number':d['header'].get('number','')}
    def mail_send(self,req):
        a=self.server.archive;item,exp=self.mail_item(req['id']);d=item['data'];cfg=self.server.mail.load()
        if not self.server.mail.public()['configured']:raise ValueError('Invio non configurato: l’amministratore deve impostare il server di posta nel menu «Impostazioni email».')
        to=mailer.split_addresses(req.get('to'));cc=mailer.split_addresses(req.get('cc'))
        if not to:raise ValueError('Indicare almeno un destinatario.')
        office=cfg['office_copy']
        if not office:raise ValueError('Manca l’indirizzo dell’ufficio in copia: impostarlo nel menu «Impostazioni email».')
        cc_all=[x for x in cc if x.lower()!=office.lower() and x.lower() not in [t.lower() for t in to]]+[office]   # copia all'ufficio sempre, non rimovibile
        subject=str(req.get('subject') or '').strip();body=str(req.get('body') or '').strip()
        if not subject or not body:raise ValueError('Oggetto e messaggio non possono essere vuoti.')
        if '\n' in subject or '\r' in subject:raise ValueError('L’oggetto deve stare su una riga.')
        if exp['data'].get('preview_export_id'):
            fresh=a.get(exp['id']);review=fresh['data'].get('final_review',{})
            if review.get('by')!=a.actor or review.get('pdf_sha')!=fresh['data'].get('pdf_sha') or req.get('pdf_sha')!=fresh['data'].get('pdf_sha'):raise ValueError('Aprire e controllare il PDF definitivo prima di inviarlo.')
            exp=fresh
        name,pdf=a.document(exp['data']['pdf_sha'])
        msg=mailer.build(cfg,to,cc_all,subject,body,[(name,pdf,'application/pdf')])
        rec={'inspection_id':item['id'],'export_id':exp['id'],'number':d['header'].get('number',''),'client':d['plant'].get('client_name',''),
          'to':to,'cc':cc_all,'subject':subject,'body':body,'attachments':[{'name':name,'sha':exp['data']['pdf_sha']}],'from':cfg['from_address'],'message_id':msg['Message-ID']}
        try:response=mailer.send(cfg,msg)
        except ValueError as err:
            a.record_mailing(dict(rec,ok=False,error=str(err)));raise
        if req.get('save_addresses',True):
            try:a.set_plant_emails(d['plant_id'],', '.join(to),', '.join(x for x in cc if x.lower()!=office.lower()))
            except ValueError:pass
        m=a.record_mailing(dict(rec,ok=True,response=response))
        return {'mailing':m,'mailings':a.mailings(item['id'])}
    def do_GET(self):
        try:
            u=urllib.parse.urlparse(self.path);args=urllib.parse.parse_qs(u.query);path=u.path;self.guard(path);a=self.server.archive
            if path=='/':return self.send(200,(ROOT/'static/index.html').read_text('utf-8'),'text/html; charset=utf-8')
            if path.startswith('/static/'):
                file=(ROOT/path.lstrip('/')).resolve()
                if not file.is_relative_to(ROOT/'static') or not file.is_file():return self.send(404,{'error':'File non trovato.'})
                return self.send(200,file.read_bytes(),mimetypes.guess_type(str(file))[0] or 'application/octet-stream')
            if path=='/api/me':
                s=self.server.sessions.get(self.sid());user=a.user(s['user']) if s else None
                if user and user['active']:return self.send(200,{'user':user,'csrf':s['csrf'],'version':APP_VERSION,'server':self.server.server_mode,'perms':a.perms_of(user),'roles':ROLE_LABELS,'permission_list':PERMISSIONS})
                return self.send(200,{'user':None,'setup':not a.has_users(),'version':APP_VERSION})
            if path=='/api/summary':return self.send(200,a.summary(self.user))
            if path=='/api/mail/settings':return self.send(200,self.mail_settings())
            if path=='/api/oplog':
                g=lambda k:args.get(k,[''])[0]
                return self.send(200,a.oplog(g('since'),g('until'),g('user'),g('category'),g('limit') or 1000))
            if path=='/api/pdf/status':return self.send(200,pdfconv.status())
            if path=='/api/signature':
                target=(args.get('username',[''])[0] or self.user['username']).lower()
                if target!=self.user['username'] and not a.can(self.user,'signatures_view'):raise PermissionError('Non consentito.')
                img=a.signature_image(target)
                if not img:self.send_response(204);self.headers_common();self.end_headers();return  # nessuna firma: l'interfaccia mostra «non caricata»
                return self.send(200,img,'image/png' if img[:4]==b'\x89PNG' else 'image/jpeg')
            if path=='/api/schema':
                fields={'header':['number','report_date','start_date','end_date','issued_date','inspectors','reason','hours','representative','due_date'],
                  'plant':['client_name','address','installation_year','power','voltage','pod','cabins','stations','if_value','if_unit','tf','disperser_description','connections_description','conductors_description','medical_group'],
                  'tests':['earth_re','continuity_description','at_calculation','contact_description'],
                  'sampling':['continuity','rcd','overcurrent']}
                from .forms import schema as form_schema
                return self.send(200,{'groups':GROUPS,'labels':LABELS,'fields':fields,'rules_version':RULES_VERSION,'forms':form_schema(),'utp_table':UTP_TABLE,'utp_beyond':UTP_BEYOND})
            if path=='/api/plant/state':return self.send(200,a.plant_state(args['id'][0],args.get('module',['M01'])[0]))
            if path=='/api/plant/state/preview':return self.send(200,a.preview_plant_state(args['id'][0],args['source'][0]))
            if path=='/api/inspection':
                item=a.get(args['id'][0]);data=item['data'];template=a.get(data['template_id'])['data'] if data.get('template_id') else None
                boards=a.boards(data['plant_id']) if (data.get('module') or 'M01')=='M01' else []
                baseline=a.get(data['baseline_id']) if data.get('baseline_id') else None
                return self.send(200,{'item':item,'alerts':evaluate(data,template),'baseline':baseline,'boards':boards,'plant_definition':__import__(__package__ + '.plantstate', fromlist=['plantstate']).extract(data),
                  'exports':a.where('export','inspection_id',item['id']),'mailings':a.mailings(item['id'])})
            if path=='/api/document':
                filename,data=a.document(args['sha'][0]);inline=args.get('inline',[''])[0]=='1'
                if inline and (not filename.lower().endswith('.pdf') or not data.startswith(b'%PDF-')):raise ValueError('Solo i PDF possono essere visualizzati in anteprima.')
                return self.send(200,data,'application/pdf' if inline else 'application/octet-stream',filename,inline_pdf=inline)
            if path=='/api/backup':
                p=a.export_backup();return self.send_path(p,'Archivio_AD_completo_'+dt.datetime.now().strftime('%Y%m%d_%H%M%S')+'.adbackup.zip',remove=True)
            if path=='/api/backup/local':
                file=(a.backups/args['name'][0]).resolve()
                if file.parent!=a.backups or not file.is_file() or not file.name.endswith('.adbackup.zip'):raise ValueError('Copia non trovata.')
                return self.send_path(file,file.name)
            if path=='/api/permissions':return self.send(200,{'matrix':a.permissions(),'roles':ROLE_LABELS,'permissions':PERMISSIONS})
            if path=='/api/signatures':return self.send(200,{'users':[{'username':u['username'],'name':u['name'],'role':u['role'],'signature':bool(((a.signature_record(u['username']) or {}).get('data') or {}).get('sha'))} for u in a.users() if u['active']]})
            if path=='/api/users':
                tr=a.user_traces()
                return self.send(200,{'users':[dict(u,signature=bool(((a.signature_record(u['username']) or {}).get('data') or {}).get('sha')),traces=tr.get(u['username'],0)) for u in a.users()]})
            if path=='/api/fieldkeys':
                inspections=a.all('inspection');base=inspections[0]['data'] if inspections else None
                keys=sorted(field_values(base)) if base else [g+'.'+k for g,ks in {'header':['number','report_date','inspectors'],'plant':['client_name','address']}.items() for k in ks]
                return self.send(200,{'keys':[k for k in keys if not k.startswith(('source_meta.','acknowledgements.','carried.','plant_state_base.','plant_state_update'))]})
            return self.send(404,{'error':'Funzione non trovata.'})
        except Exception as e:self.fail(e)
    def do_POST(self):
        try:
            path=urllib.parse.urlparse(self.path).path;self.guard(path,True);length=int(self.headers.get('Content-Length','0'))
            if length<=0 or length>220*1024*1024:raise ValueError('Richiesta troppo grande o vuota.')
            req=json.loads(self.rfile.read(length));a=self.server.archive;S=self.server.sessions
            if path=='/api/login':
                key=str(req.get('username','')).strip().lower()+'|'+self.client_ip();S.throttle(key)
                user=a.authenticate(req.get('username'),req.get('password'))
                if not user:S.failed(key);time.sleep(0.5);raise PermissionError('Utente o password non corretti.')
                S.ok(key);sid=S.create(user);return self.send(200,{'user':user,'csrf':S.get(sid)['csrf']},cookie=sid)
            if path=='/api/logout':S.drop(self.sid());return self.send(200,{'ok':True},cookie='')
            if path=='/api/setup':
                # 0.3.28 (punto 58): il primo amministratore si crea con il codice di attivazione
                # stampato nella console del server. Prima bastava arrivare dal loopback, ma dietro
                # un proxy inverso quel controllo e' vero per chiunque, da internet compreso.
                if a.has_users():raise PermissionError('Configurazione iniziale già eseguita.')
                setup_key='setup|'+self.client_ip();S.throttle(setup_key)
                code=getattr(self.server,'setup_code','') or ''
                given=str(req.get('code') or '').strip().replace(' ','')
                if not code:raise PermissionError('Codice di attivazione non disponibile: riavviare il programma e leggere il codice nella sua finestra.')
                if not given or not given.isascii() or not hmac.compare_digest(given.lower(),code.lower()):
                    S.failed(setup_key)
                    time.sleep(0.5);raise PermissionError('Codice di attivazione non corretto: si trova nella finestra del programma sul server.')
                a.set_actor(str(req.get('username','')).lower());user=a.add_user(req.get('username'),req.get('name'),'admin',req.get('password'),only_if_empty=True)
                self.server.setup_code='';S.ok(setup_key)
                sid=S.create(user);return self.send(200,{'user':user,'csrf':S.get(sid)['csrf']},cookie=sid)
            if path=='/api/password':
                if not a.authenticate(self.user['username'],req.get('current')):raise ValueError('Password attuale non corretta.')
                a.update_user(self.user['username'],password=req.get('password'));return self.send(200,{'ok':True})
            if path=='/api/permissions':return self.send(200,{'matrix':a.set_permissions(req.get('matrix') or {})})
            if path=='/api/users/add':return self.send(200,a.add_user(req.get('username'),req.get('name'),req.get('role'),req.get('password')))
            if path=='/api/users/update':
                old=str(req['username']).strip().lower()
                u=a.update_user(old,name=req.get('name'),role=req.get('role'),active=req.get('active'),password=req.get('password'),new_username=req.get('new_username'))
                if u['username']!=old:S.drop_user(old)
                if req.get('active') is False or req.get('password'):S.drop_user(u['username'])
                return self.send(200,u)
            if path=='/api/users/rename':
                old=str(req.get('username','')).strip().lower();u=a.rename_user(old,req.get('new_username'))
                if u['username']!=old:S.drop_user(old)
                return self.send(200,u)
            if path=='/api/users/delete':
                u=a.delete_user(req.get('username'));S.drop_user(u['username']);return self.send(200,{'ok':True})
            if path=='/api/import/preview':
                raw,name=decode_file(req);d=parse_word(raw,name)
                if not d['plant'].get('client_name') and not d['header'].get('number'):
                    d.setdefault('source_meta',{}).setdefault('warnings',[]).insert(0,'Sembra un modello vuoto (nessun cliente né numero di verbale): i modelli si caricano nella sezione Template, non qui. Rimuoverlo dalla selezione o indicare il cliente.')
                    d['source_meta']['blank_template']=True
                candidates=[x for x in a.all('plant') if x['data']['client_name'].casefold().strip('. ')==d['plant']['client_name'].casefold().strip('. ')]
                return self.send(200,{'parsed':d,'candidates':candidates,'alerts':evaluate(dict(d,historical=True))})
            if path=='/api/import/commit':
                raw,name=decode_file(req);d=parse_word(raw,name)
                if isinstance(req.get('client_name'),str):d['plant']['client_name']=req['client_name'].strip()
                if isinstance(req.get('address'),str):d['plant']['address']=req['address'].strip()
                if isinstance(req.get('site_name'),str):d['plant']['site_name']=req['site_name'].strip()
                if not d['plant']['client_name']:raise ValueError('Cliente mancante. Se il file è un modello vuoto va caricato nella sezione Template; altrimenti scrivere il cliente e riprovare.')
                return self.send(200,a.import_word(raw,name,d,req.get('plant_id') or None))
            if path=='/api/import/finish':return self.send(200,a.finish_import())
            if path=='/api/plant/new':
                # 0.3.29: cliente/impianto nuovo senza importare un verbale. La verifica si crea dopo, dall'archivio.
                return self.send(200,a.create_plant(req.get('client_name'),req.get('site_name',''),req.get('address'),
                  req.get('email_to'),req.get('email_cc'),req.get('confirm') is True))
            if path=='/api/plant/delete':return self.send(200,a.delete_plant(req['id']))
            if path=='/api/plant/update':
                if ('email_to' in req or 'email_cc' in req) and not a.can(self.user,'send') and not a.can(self.user,'plant'):raise PermissionError('Non consentito.')
                return self.send(200,a.update_plant(req['id'],req.get('client_name'),req.get('address'),req.get('site_name',''),req.get('email_to'),req.get('email_cc')))
            if path=='/api/instrument/import/preview':
                raw,_=decode_file(req);return self.send(200,a.instrument_import_plan(raw))
            if path=='/api/instrument/import/commit':
                raw,_=decode_file(req);return self.send(200,a.instrument_import_apply(raw))
            if path=='/api/mail/prepare':return self.send(200,self.mail_prepare(req['id']))
            if path=='/api/inspection/send':return self.send(200,self.mail_send(req))
            if path=='/api/mail/settings':
                before=self.server.mail.public();after=self.server.mail.save(req.get('server') or {})
                ch=[k for k in ('host','port','security','username','from_address','from_name','office_copy') if before.get(k)!=after.get(k)]
                if (req.get('server') or {}).get('password') or (req.get('server') or {}).get('clear_password'):ch.append('password')
                a.log_event('mail_server',{'detail':('modificati: '+', '.join(ch)) if ch else 'nessuna modifica'})
                return self.send(200,self.mail_settings())
            if path=='/api/mail/texts':a.set_mail_texts(req.get('texts') or {});return self.send(200,self.mail_settings())
            if path=='/api/mail/test':
                cfg=self.server.mail.load();to=mailer.split_addresses(req.get('to') or cfg['office_copy'])
                if not to:raise ValueError('Indicare l’indirizzo a cui inviare la prova.')
                msg=mailer.build(cfg,to,[],'Prova di invio da VerbalizzAI AD','Messaggio di prova inviato da VerbalizzAI AD ('+APP_VERSION+') da '+self.user['name']+'.\nSe lo ricevete, le impostazioni del server di posta sono corrette.',[])
                return self.send(200,{'ok':True,'response':mailer.send(cfg,msg),'to':to})
            if path=='/api/draft/delete':return self.send(200,a.delete_draft(req['id']))
            if path=='/api/inspection/annul':return self.send(200,a.annul(req['id'],req.get('reason',''),req.get('revision')))
            if path=='/api/inspection/annul-restore':return self.send(200,a.restore_annulled(req['id']))
            if path=='/api/reread':return self.send(200,a.reread_historical())
            if path=='/api/plant/state/save':return self.send(200,a.save_plant_state(req['plant_id'],req['module'],req.get('state'),req.get('observed_date',''),req.get('stamp'),req.get('confirmed')))
            if path=='/api/plant/state/adopt':
                if not isinstance(req.get('proposal_hash'),str) or len(req['proposal_hash'])!=64:raise ValueError('Confrontare la proposta prima di adottarla.')
                return self.send(200,a.adopt_plant_state(req['plant_id'],req['inspection_id'],req.get('stamp'),req.get('confirmed'),req['proposal_hash']))
            if path=='/api/draft/state/compare':return self.send(200,a.acknowledge_plant_state(req['id'],int(req['revision']),req.get('stamp'),req.get('confirmed')))
            if path=='/api/draft/new':return self.send(200,a.create_draft(req['plant_id'],req.get('baseline_id'),self.user['name'],req.get('module')))
            if path=='/api/draft/save':
                item=a.save(req['id'],req['data'],int(req['revision']));tid=item['data'].get('template_id');template=a.get(tid)['data'] if tid else None
                return self.send(200,{'item':item,'alerts':evaluate(item['data'],template),'backup_error':a.backup_error})
            if path=='/api/review/preview':
                return self.send(200,finalization.preview(a,req['id'],int(req['revision']),build_word))
            if path=='/api/review/upload':
                raw,name=decode_file(req)
                return self.send(200,finalization.upload_layout(a,req['id'],int(req['revision']),req['preview_id'],raw,name))
            if path in ('/api/inspection/issue','/api/review/issue'):
                if not req.get('preview_id'):raise ValueError('Aprire e controllare l’anteprima PDF prima di firmare ed emettere.')
                return self.send(200,finalization.issue_preview(a,req['id'],int(req['revision']),req['preview_id'],req.get('approved'),req.get('update_plant')))
            if path=='/api/review/final':
                finalization.review_final_pdf(a,req['id'],req.get('pdf_sha'),req.get('confirmed'))
                return self.send(200,{'ok':True})
            if path=='/api/inspection/precheck':
                cur=a.get(req['id']);tid=cur['data'].get('template_id');template=a.get(tid)['data'] if tid else None
                blocking='';signer=a.signer_for(cur['data'])
                try:
                    if req.get('update_plant',True) and not a.can(self.user,'plant_technical'):raise ValueError('Il ruolo non può confermare lo stato tecnico: emettere senza aggiornare l’impianto.')
                    a.issue(req['id'],int(req['revision']),[],True,dry_run=True,update_plant=req.get('update_plant',True))
                except (ValueError,Conflict) as err:blocking=str(err)
                return self.send(200,{'blocking':blocking,'signer':signer['name'] if signer else '','signer_username':signer['username'] if signer else '',
                  'signature':bool(signer and a.signature_image(signer['username'])),'pdf':pdfconv.status(),'fonts':pdfconv.fonts_status()})
            if path=='/api/inspection/revision':return self.send(200,a.create_revision(req['id']))
            if path=='/api/template/preview':
                raw,name=decode_file(req);associated,info=adapt_template(raw,name,req.get('mapping'))
                return self.send(200,{'info':info})
            if path=='/api/template/delete':return self.send(200,a.delete_template(req['id']))
            if path=='/api/template/assign':return self.send(200,{'updated':a.assign_template(req['id'],'all' if req.get('scope')=='all' else 'missing')})
            if path=='/api/template/import':
                raw,name=decode_file(req);associated,info=adapt_template(raw,name,req.get('mapping'))
                return self.send(200,a.add_template(raw,name,associated,info))
            if path=='/api/export':
                item=a.get(req['id']);d=item['data']
                if a.locked(d):raise ValueError('Documento non modificabile: il Word emesso è già archiviato.')
                w=build_word(a,item,want_pdf=bool(req.get('pdf')))
                if req.get('pdf') and not w['pdf']:raise ValueError('PDF non creato: '+w['pdf_error'])
                exp=a.save_export(item['id'],w['word'],w['filename'],w['alerts'],w['pdf'],{'attachments':w['attachments']})
                return self.send(200,{'export':exp,'alerts':w['alerts'],'missing':w['missing'],'attachments':w['attachments']})
            if path=='/api/export/pdf':
                e=a.get(req['id'])
                if e['kind']!='export':raise ValueError('Documento non trovato.')
                if not e['data'].get('pdf_sha'):
                    _,word=a.document(e['data']['sha'])
                    try:pdf=pdfconv.to_pdf(word,e['data']['filename'])
                    except RuntimeError as err:raise ValueError(str(err))
                    a.attach_pdf(e['id'],pdf);e=a.get(e['id'])
                return self.send(200,{'export':e})
            if path=='/api/export/pdf-regenerate':
                # 0.3.25 (punto 50): rifà il PDF dal Word emesso. Il Word non viene rigenerato né
                # modificato: si riconverte quello archiviato, così firma e contenuti restano identici.
                e=a.get(req['id'])
                if e['kind']!='export':raise ValueError('Documento non trovato.')
                _,word=a.document(e['data']['sha'])
                try:pdf=pdfconv.to_pdf(word,e['data']['filename'])
                except RuntimeError as err:raise ValueError(str(err))
                res=a.regenerate_pdf(e['id'],pdf)
                return self.send(200,{'export':a.get(e['id']),'changed':res['changed'],'fonts':pdfconv.fonts_status(refresh=True)})
            if path=='/api/signature':
                target=str(req.get('username') or self.user['username']).lower()
                if target!=self.user['username'] and not a.can(self.user,'signatures'):raise PermissionError('Il tuo ruolo non può caricare la firma di un altro utente.')
                if req.get('remove'):a.remove_signature(target);return self.send(200,{'signature':None})
                raw,_=decode_file(req);return self.send(200,{'signature':a.set_signature(target,raw,req.get('filename','firma.png'))})
            if path=='/api/backup/verify':
                raw,name=decode_file(req);data,_,m=a.verify_backup(raw,a.docstore)
                counts={}
                for o in data['objects']:counts[o['kind']]=counts.get(o['kind'],0)+1
                return self.send(200,{'filename':name,'created_at':m['created_at'],'counts':counts,'documents':len(data['documents']),'users':len(data.get('users',[])),'external':m.get('documents')=='external'})
            if path=='/api/backup/restore':
                raw,name=decode_file(req);result=a.restore(raw);S.items.clear();return self.send(200,result,cookie='')
            if path=='/api/backup/restore-local':
                file=(a.backups/str(req.get('name',''))).resolve()
                if file.parent!=a.backups or not file.is_file() or not file.name.endswith('.adbackup.zip'):raise ValueError('Copia non trovata.')
                result=a.restore(file);S.items.clear();return self.send(200,result,cookie='')
            if path=='/api/calculate/due':return self.send(200,{'due_date':due(req['date'],int(req['years']))})
            if path=='/api/instrument/save':return self.send(200,a.save_instrument(req.get('id') or None,req.get('data'),req.get('revision')))
            if path=='/api/board/rename':return self.send(200,a.rename_board(req['plant_id'],req.get('old',''),req.get('new','')))
            if path=='/api/asset/add':
                plant=a.get(req['plant_id'])
                if plant['kind']!='plant' or plant['data'].get('deleted'):raise ValueError('Impianto non trovato.')
                draft=a.get(req.get('inspection_id',''));dd=draft['data']
                if draft['kind']!='inspection' or dd.get('plant_id')!=plant['id'] or a.locked(dd):raise ValueError('Indicare una bozza aperta dello stesso impianto.')
                data={'plant_id':req['plant_id'],'kind':req['kind'],'board':req.get('board',''),'name':req.get('name',''),
                  'occurrence':req.get('occurrence',1),'attributes':req.get('attributes',{}),'active':False,'pending_inspection':draft['id'],'provenance':{'manual':True}}
                if data['kind'] not in ('rcd','overcurrent','continuity') or not data['name']:raise ValueError('Indicare tipo e nome del nuovo elemento.')
                oid=a.mutate(lambda c:a._put(c,'asset',data,action='manual_asset'));return self.send(200,a.get(oid))
            return self.send(404,{'error':'Funzione non trovata.'})
        except Exception as e:self.fail(e)

def is_network_path(p):
    s=str(p)
    if s.startswith('\\\\') or s.startswith('//'):return True
    # Mapped network drives (e.g. Z:) are not detected here: see LEGGIMI.
    return False
def load_config():
    f=ROOT/'config.json'
    if not f.exists():return {}
    try:return json.loads(f.read_text('utf-8-sig'))
    except json.JSONDecodeError as e:sys.exit('config.json non valido: '+str(e))
def main():
    cfg=load_config()
    parser=argparse.ArgumentParser(description='VerbalizzAI AD '+APP_VERSION)
    parser.add_argument('--server',action='store_true',default=cfg.get('server',False),help='accetta connessioni dalla rete interna')
    parser.add_argument('--host',default=cfg.get('host'));parser.add_argument('--port',type=int,default=cfg.get('port'))
    parser.add_argument('--data-dir',type=Path,default=Path(cfg['data_dir']) if cfg.get('data_dir') else None)
    parser.add_argument('--backup-dir',type=Path,default=Path(cfg['backup_dir']) if cfg.get('backup_dir') else None)
    parser.add_argument('--allowed-host',action='append',default=None,help='nome:porta con cui i client raggiungono il server (ripetibile)')
    parser.add_argument('--cert',default=cfg.get('cert'));parser.add_argument('--key',default=cfg.get('key'))
    parser.add_argument('--behind-proxy',action='store_true',default=cfg.get('behind_proxy',False),
      help='il programma sta dietro un proxy inverso sulla stessa macchina (Nginx): legge X-Forwarded-For e X-Forwarded-Proto')
    parser.add_argument('--no-browser',action='store_true');parser.add_argument('--restore',type=Path)
    parser.add_argument('--add-user',metavar='UTENTE');parser.add_argument('--name');parser.add_argument('--admin',action='store_true')
    parser.add_argument('--reset-password',metavar='UTENTE')
    args=parser.parse_args()
    if not isinstance(args.behind_proxy,bool):parser.error('behind_proxy deve essere true o false.')
    host=args.host or ('127.0.0.1' if args.behind_proxy or not args.server else '0.0.0.0')
    if args.behind_proxy and host not in ('127.0.0.1','::1'):
        parser.error('--behind-proxy richiede --host 127.0.0.1 (o ::1).')
    if args.server and not args.data_dir:sys.exit('In modalità server indicare --data-dir (o data_dir in config.json): cartella su un disco locale del server, non una cartella di rete.')
    data_dir=args.data_dir or default_data()
    for d in (data_dir,args.backup_dir):
        if d and is_network_path(d):sys.exit('La cartella '+str(d)+' è su un’unità di rete. L’archivio deve stare su un disco locale del computer che esegue il programma; gli altri utenti si collegano dal browser.')
    if args.restore:
        Archive.verify_backup(args.restore,Path(args.backup_dir or data_dir/'backups')/'documenti')
        target=data_dir;target.mkdir(parents=True,exist_ok=True)
        if (target/'archivio.sqlite').exists():
            stamp=dt.datetime.now().strftime('%Y%m%d_%H%M%S')
            for suffix in ['','-wal','-shm']:
                file=target/('archivio.sqlite'+suffix)
                if file.exists():file.rename(target/('prima_recupero_'+stamp+'.sqlite'+suffix))
        archive=Archive(target,args.backup_dir);archive.restore(args.restore);print('Ripristino completato. Originali conservati in',target)
    else:archive=Archive(data_dir,args.backup_dir)
    if args.add_user or args.reset_password:
        pw=getpass.getpass('Password (almeno 10 caratteri): ')
        if pw!=getpass.getpass('Ripeti la password: '):sys.exit('Le password non coincidono.')
        if args.add_user:
            u=archive.add_user(args.add_user,args.name or input('Nome e cognome come nei verbali: '),'admin' if args.admin else 'tecnico',pw)
        else:u=archive.update_user(args.reset_password,password=pw)
        print('Utente',u['username'],'('+u['role']+') salvato.');return
    port=args.port if args.port is not None else (8765 if args.server else 0)
    pdfconv.configure(cfg.get('libreoffice'))
    templates.SIGN_AT_BOTTOM=cfg.get('firme_in_fondo_pagina',True) is not False
    server=ThreadingHTTPServer((host,port),Handler);server.daemon_threads=True
    server.archive=archive;server.sessions=Sessions();server.server_mode=bool(args.server);port=server.server_port
    server.mail=mailer.MailConfig(archive.directory)
    server.tls=bool(args.cert);server.behind_proxy=bool(args.behind_proxy)
    # 0.3.28 (punto 58): con l'archivio vuoto il primo amministratore si crea solo con questo
    # codice, che esiste soltanto qui nella finestra del programma. Cambia a ogni avvio.
    server.setup_code=secrets.token_hex(16) if not archive.has_users() else ''
    if args.cert:
        ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.minimum_version=ssl.TLSVersion.TLSv1_2;ctx.load_cert_chain(args.cert,args.key)
        server.socket=ctx.wrap_socket(server.socket,server_side=True)
    allowed=[h.lower() for h in (args.allowed_host or cfg.get('allowed_hosts') or [])]
    if not args.server:allowed+= [f'127.0.0.1:{port}',f'localhost:{port}']
    server.allowed_hosts=set(allowed)
    scheme='https' if args.cert else 'http'
    print(f'\nVerbalizzAI AD {APP_VERSION}  ·  {dt.datetime.now():%d/%m/%Y %H:%M}\nArchivio: {archive.directory}\nBackup:   {archive.backups}')
    if args.server:print(f'Server in ascolto sulla porta {port}. Dai client: {scheme}://NOME-SERVER:{port}')
    else:print(f'Aprire: {scheme}://127.0.0.1:{port}')
    lo=pdfconv.status();print('PDF:      '+('LibreOffice '+lo['path'] if lo['available'] else 'LibreOffice non trovato (i verbali vengono emessi solo in Word)'))
    # 0.3.25 (punto 49): senza Carlito/Caladea i PDF escono con un carattere di ripiego più largo.
    fo=pdfconv.fonts_status()
    if not fo['ok']:print('ATTENZIONE: '+fo['hint'])
    elif fo['checked']:print('Caratteri: Calibri/Carlito e Cambria/Caladea presenti.')
    if server.setup_code:
        print('\nPRIMO AVVIO: non ci sono ancora utenti.')
        print('Codice di attivazione per creare l\'amministratore:  '+server.setup_code)
        print('Da digitare nella pagina di configurazione iniziale. Cambia a ogni riavvio.\n')
    print('Ctrl+C per chiudere.\n',flush=True)
    if not args.server and not args.no_browser:webbrowser.open(f'{scheme}://127.0.0.1:{port}')
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close()
if __name__=='__main__':main()
