"""Anteprima controllata, firma del documento visionato e ritocchi di sola impaginazione."""
from __future__ import annotations
import copy, hashlib, io, json, re, xml.etree.ElementTree as ET
from zipfile import ZipFile, BadZipFile
from .storage import Conflict, jdump, now, iso_date
from .templates import NS, q, txt, package, write_package, serialize, place_signature, serial_operation, reserved_slots, swap_reserved_signature, drop_trailing_page_breaks
from . import pdfconv


def digest(data):
    return hashlib.sha256(json.dumps(data,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()


def checked_package(raw):
    if len(raw)>20*1024*1024:raise ValueError('Word troppo grande: massimo 20 MB.')
    try:z=ZipFile(io.BytesIO(raw))
    except BadZipFile:raise ValueError('Caricare un documento .docx valido.')
    infos=z.infolist();names=[i.filename for i in infos]
    if len(names)!=len(set(names)) or len(names)>2000 or sum(i.file_size for i in infos)>80*1024*1024:
        raise ValueError('Struttura del Word non valida o troppo grande.')
    for name in names:
        if name.startswith('/') or '..' in name.split('/') or '\\' in name:raise ValueError('Percorso non valido nel Word.')
        if any(s in name.lower() for s in ('vbaproject','activex/','embeddings/','_xmlsignatures/')):
            raise ValueError('Il Word contiene macro, oggetti incorporati o firme non supportati.')
        if name.endswith(('.xml','.rels')):
            rawpart=z.read(name)
            if b'<!DOCTYPE' in rawpart.upper() or b'<!ENTITY' in rawpart.upper():raise ValueError('XML del Word non supportato.')
            try:root=ET.fromstring(rawpart)
            except ET.ParseError:raise ValueError('XML del Word non valido.')
            if name.endswith('.rels'):
                for e in root:
                    if e.get('TargetMode','').lower()!='external':continue
                    # I modelli contengono normali link al sito/email nel piè di pagina.
                    # Non consentire invece immagini, modelli o dati caricati dall'esterno.
                    if not (e.get('Type','').endswith('/hyperlink') and re.match(r'^(https?://|mailto:)',e.get('Target',''),re.I)):
                        raise ValueError('Il Word contiene risorse esterne non supportate: incorporarle o rimuoverle prima del caricamento.')
            if any(e.tag.rsplit('}',1)[-1] in ('altChunk','object','oleObject') for e in root.iter()):raise ValueError('Contenuto incorporato non supportato.')
            fields=' '.join((e.text or '') if e.tag==q('w:instrText') else e.get(q('w:instr'),'') for e in root.iter() if e.tag in (q('w:instrText'),q('w:fldSimple')))
            if re.search(r'\b(DDE|DDEAUTO|INCLUDETEXT|INCLUDEPICTURE|LINK)\b',fields,re.I):raise ValueError('Campi con contenuto esterno non supportati.')
            if any(e.tag in (q('w:ins'),q('w:del')) for e in root.iter()):raise ValueError('Accettare o rifiutare le revisioni Word prima del caricamento.')
    if 'word/document.xml' not in names:raise ValueError('Documento Word mancante.')
    return z


def content_signature(raw):
    """Confronto prudente: testo, caselle, note, immagini e campi restano identici.
    Margini, stili, interruzioni, spaziatura e suddivisione dei run possono cambiare.
    Non promette di riconoscere semanticamente modifiche arbitrarie a un verbale.
    """
    z=checked_package(raw);parts=[]
    for name in sorted(z.namelist()):
        if re.match(r'word/(document|header\d+|footer\d+|footnotes|endnotes)\.xml$',name):
            root=ET.fromstring(z.read(name))
            # Word aggiorna i risultati dei campi pagina quando cambia l'impaginazione.
            for simple in root.iter(q('w:fldSimple')):
                if re.match(r'^\s*(PAGE|NUMPAGES|SECTIONPAGES)\b',simple.get(q('w:instr'),''),re.I):
                    for e in simple.iter(q('w:t')):e.text=''
            stack=[]
            for e in root.iter():
                if e.tag==q('w:fldChar'):
                    kind=e.get(q('w:fldCharType'))
                    if kind=='begin':stack.append(['',False])
                    elif kind=='separate' and stack:stack[-1][1]=True
                    elif kind=='end' and stack:stack.pop()
                elif e.tag==q('w:instrText') and stack:stack[-1][0]+=e.text or ''
                elif e.tag==q('w:t') and any(result and re.match(r'^\s*(PAGE|NUMPAGES|SECTIONPAGES)\b',field,re.I) for field,result in stack):e.text=''
            # Run separati da Word non devono cambiare il testo di una parola.
            text=re.sub(r'\s+',' ',''.join(e.text or '' for e in root.iter(q('w:t')))).strip()
            flags=[e.get(q('w:val'),'') for e in root.iter() if e.tag.rsplit('}',1)[-1]=='checked']
            fields=[re.sub(r'\s+',' ',(e.text or '') if e.tag==q('w:instrText') else e.get(q('w:instr'),'')).strip() for e in root.iter() if e.tag in (q('w:instrText'),q('w:fldSimple'))]
            parts.append((name,text,flags,fields))
    images=sorted(hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/'))
    links=sorted((n,e.get('Target','')) for n in z.namelist() if n.endswith('.rels') for e in ET.fromstring(z.read(n)) if e.get('TargetMode','').lower()=='external')
    return digest([parts,images,links])


@serial_operation
def reconcile_annex_pages(raw,filename,roles,attachments):
    """Conta e corregge solo le caselle pagine: conserva l'impaginazione del Word."""
    att=copy.deepcopy(attachments)
    for _ in range(3):
        pdf=pdfconv.to_pdf(raw,filename)
        pages=pdfconv.annex_pages(pdf,roles) if roles else {}
        changes={k:str(v) for k,v in pages.items() if att.get(k,{}).get('declared') and str(v)!=str(att[k].get('pages',''))}
        if not changes:return raw,pdf,att
        z,root=package(raw);found=set()
        for s in root.iter(q('w:sdt')):
            tag=s.find('w:sdtPr/w:tag',NS)
            name=tag.get(q('w:val'),'') if tag is not None else ''
            for k,value in changes.items():
                if name=='attachments.'+k+'.pages':
                    texts=s.findall('.//w:sdtContent//w:t',NS)
                    if not texts:raise ValueError('Campo pagine allegato non modificabile: conservare le caselle del modello.')
                    texts[0].text=value
                    for e in texts[1:]:e.text=''
                    found.add(k)
        if found!=set(changes):raise ValueError('Campi pagine allegati non riconosciuti: controllare il modello prima dell’emissione.')
        for k,value in changes.items():att[k]['pages']=value
        raw=write_package(z,{'word/document.xml':serialize(root,z.read('word/document.xml'))})
    raise ValueError('Conteggio pagine allegati non stabile: controllare l’impaginazione e riprovare.')


def signature_slots(raw):
    z=checked_package(raw);root=ET.fromstring(z.read('word/document.xml'))
    return sum(1 for s in root.iter(q('w:sdt')) if (lambda t:t is not None and t.get(q('w:val')) in ('header.signature_image','header.signature_line'))(s.find('w:sdtPr/w:tag',NS)))+len(reserved_slots(root))


def normalize_layout(raw):
    """Correzioni di sola impaginazione applicate a ogni Word da emettere (anche se ritoccato):
    via l'interruzione di pagina finale che crea una pagina bianca."""
    z,root=package(raw)
    if not drop_trailing_page_breaks(root):return raw
    return write_package(z,{'word/document.xml':serialize(root,z.read('word/document.xml'))})


def total_pages(pdf):
    try:pages=pdfconv.outline(pdf)[1]
    except Exception as err:raise ValueError('Impossibile verificare il numero di pagine del PDF: emissione non eseguita.') from err
    if not isinstance(pages,int) or pages<1:
        raise ValueError('Impossibile verificare il numero di pagine del PDF: emissione non eseguita.')
    return pages


@serial_operation
def sign_reviewed_word(raw,image,inspectors):
    raw=normalize_layout(raw)
    z,root=package(raw);modified={}
    if not signature_slots(raw):raise ValueError('Riquadro firma non riconosciuto. Ripristinare il riquadro del Word originale.')
    # 1.0.0 rc3: se l'anteprima ha lo spazio firma riservato si sostituisce solo l'immagine (stesso ingombro).
    if not swap_reserved_signature(root,z,modified,image):
        many=bool(re.search(r'\s e \s*|,|\n',inspectors or ''))
        if not place_signature(root,z,modified,image,drop_name=not many):raise ValueError('Non è stato possibile inserire la firma nel riquadro previsto.')
    modified['word/document.xml']=serialize(root,z.read('word/document.xml'))
    return write_package(z,modified)


def get_preview(a,iid,eid,revision):
    item=a.get(iid);e=a.get(eid)
    if item['kind']!='inspection' or a.locked(item['data']):raise ValueError('Solo una bozza può essere emessa.')
    if e['kind']!='export' or e['data'].get('inspection_id')!=iid or not e['data'].get('review_preview'):
        raise ValueError('Anteprima non valida per questo verbale.')
    if revision!=item['revision'] or e['data']['inspection_revision']!=revision or e['data'].get('source_digest')!=digest(item['data']):
        raise Conflict('La bozza è cambiata: aggiornare e controllare l’anteprima PDF.')
    if not e['data'].get('pdf_sha'):raise ValueError('Anteprima PDF non disponibile.')
    return item,e


def publish_default(a,item):
    d=item['data'];user=a.user(a.actor) if a.actor else None
    if d.get('revision_of') or (user and not a.can(user,'plant_technical')):return False
    profile=a.get(d['plant_id'])['data'].get('profiles',{}).get(a.module_of(d),{})
    return not (profile.get('observed_date','')>a._state_date(d))


def preview(a,iid,revision,build_word):
    item=a.get(iid)
    if a.locked(item['data']):raise ValueError('Il verbale è già emesso: aprire il PDF definitivo.')
    if item['revision']!=revision:raise Conflict('La bozza è cambiata: ricaricarla prima dell’anteprima.')
    from .rules import normalize_coordination
    data=copy.deepcopy(item['data'])
    if normalize_coordination(data):
        item=a.save(iid,data,revision);revision=item['revision']
    # 1.0.0 rc3: lo spazio del timbro è riservato già in anteprima, con l'ingombro esatto del timbro
    # del firmatario: ciò che si controlla (e si ritocca) è impaginato come il definitivo.
    signer=a.signer_for(item['data']);stamp=a.signature_image(signer['username']) if signer else None
    w=build_word(a,item,want_pdf=True,reserve=stamp) if stamp else build_word(a,item,want_pdf=True)
    if not w['pdf']:raise ValueError('Anteprima PDF non creata: '+w['pdf_error'])
    # I conteggi automatici degli allegati devono essere salvati PRIMA di fissare la revisione.
    if w['attachments']!=item['data'].get('attachments'):
        data=copy.deepcopy(item['data']);data['attachments']=w['attachments']
        flags=data.setdefault('flags',{}).setdefault('attachments',{})
        declared=any(v.get('declared') for v in w['attachments'].values());flags.update(yes=declared,no=not declared)
        item=a.save(iid,data,revision);revision=item['revision']
    signer=a.signer_for(item['data']);image=a.signature_image(signer['username']) if signer else None
    exp=a.save_export(iid,w['word'],w['filename'],w['alerts'],w['pdf'],
      {'review_preview':True,'source_digest':digest(item['data']),'signer_digest':hashlib.sha256(image).hexdigest() if image else '',
       'attachments':w['attachments'],'annex_roles':w.get('annex_roles',[]),'source_mode':'generated'},expected_revision=revision)
    return preview_info(a,item,exp)


def preview_info(a,item,exp):
    blocking='';update=publish_default(a,item)
    try:a.issue(item['id'],item['revision'],[],True,dry_run=True,update_plant=update)
    except (ValueError,Conflict) as err:blocking=str(err)
    signer=a.signer_for(item['data']);image=a.signature_image(signer['username']) if signer else None
    if not signer or not image:blocking=blocking or 'Firma grafica del verificatore non disponibile: caricarla prima di firmare ed emettere.'
    _,raw=a.document(exp['data']['sha'])
    if not signature_slots(raw):blocking=blocking or 'Riquadro firma non riconosciuto nel Word: controllare il modello.'
    return {'item':item,'export':exp,'alerts':exp['data']['alerts'],'blocking':blocking,'update_plant':update,'fonts':pdfconv.fonts_status()}


def upload_layout(a,iid,revision,base_id,raw,filename):
    if not filename.lower().endswith('.docx'):raise ValueError('Caricare il Word in formato .docx.')
    item,base=get_preview(a,iid,base_id,revision);_,original=a.document(base['data']['sha'])
    if content_signature(raw)!=content_signature(original):raise ValueError('Il Word contiene modifiche al testo, alle caselle o agli allegati. Questo percorso ammette solo ritocchi di impaginazione: correggere i dati nel gestionale e generare una nuova anteprima.')
    if signature_slots(raw)!=signature_slots(original):raise ValueError('Il riquadro firma è stato modificato: conservare quello del Word originale.')
    raw=normalize_layout(raw)
    raw,pdf,attachments=reconcile_annex_pages(raw,filename,base['data'].get('annex_roles',[]),base['data'].get('attachments',{}))
    exp=a.save_export(iid,raw,base['data']['filename'],base['data']['alerts'],pdf,
      {'review_preview':True,'source_digest':base['data']['source_digest'],'signer_digest':base['data']['signer_digest'],
       'attachments':attachments,'annex_roles':base['data'].get('annex_roles',[]),'source_mode':'layout_upload','original_export_id':base_id,'uploaded_filename':filename},expected_revision=revision)
    return preview_info(a,item,exp)


def issue_preview(a,iid,revision,eid,approved,update_plant=None):
    if approved is not True:raise ValueError('Controllare l’anteprima prima di firmare ed emettere.')
    item,e=get_preview(a,iid,eid,revision);signer=a.signer_for(item['data']);image=a.signature_image(signer['username']) if signer else None
    if not signer or not image:raise ValueError('Firma grafica del verificatore non disponibile.')
    if e['data'].get('signer_digest')!=hashlib.sha256(image).hexdigest():raise Conflict('La firma è cambiata: aggiornare l’anteprima.')
    update=publish_default(a,item) if update_plant is None else update_plant
    user=a.user(a.actor) if a.actor else None
    if update and user and not a.can(user,'plant_technical'):raise PermissionError('Il ruolo non può aggiornare lo stato tecnico dell’impianto.')
    anomalies=[x for x in e['data']['alerts'] if x['status'] in ('Errore','Avviso')]
    a.issue(iid,revision,anomalies,True,dry_run=True,update_plant=update)
    _,raw=a.document(e['data']['sha']);signed=sign_reviewed_word(raw,image,item['data']['header'].get('inspectors',''))
    signed,pdf,attachments=reconcile_annex_pages(signed,e['data']['filename'],e['data'].get('annex_roles',[]),e['data'].get('attachments',{}))
    # 1.0.0 rc3: il PDF firmato deve avere le stesse pagine dell'anteprima visionata. Se cambiano
    # (es. Word ritoccato prima della rc3, senza spazio firma riservato) non si emette nulla.
    seen=total_pages(a.document(e['data']['pdf_sha'])[1])
    final=total_pages(pdf)
    if seen!=final:
        raise ValueError('Con il timbro il PDF passa da %d a %d pagine: l’impaginazione non corrisponde all’anteprima controllata. Aggiornare l’anteprima (il nuovo Word riserva già lo spazio del timbro), ritoccarla se serve e ripetere l’emissione.'%(seen,final))
    # Non bloccare un’emissione parziale senza PDF e non usare dati cambiati durante la conversione.
    get_preview(a,iid,eid,revision)
    fresh_signer=a.signer_for(item['data'])
    fresh_image=a.signature_image(fresh_signer['username']) if fresh_signer else None
    if not fresh_signer or fresh_signer['username']!=signer['username'] or not fresh_image or hashlib.sha256(fresh_image).hexdigest()!=e['data']['signer_digest']:
        raise Conflict('La firma è cambiata durante la conversione: aggiornare l’anteprima.')
    exp=a.save_export(iid,signed,e['data']['filename'].replace(' - BOZZA',''),anomalies,pdf,
      {'final':True,'signed_by':signer['username'],'preview_export_id':eid,'reviewed_by':a.actor,'reviewed_at':now(),
       'reviewed_pdf_sha':e['data']['pdf_sha'],'source_mode':e['data'].get('source_mode'),'attachments':attachments},expected_revision=revision)
    issued=a.issue(iid,revision,anomalies,True,export_id=exp['id'],patch={'attachments':attachments},update_plant=update)
    return dict(issued,export=exp,notes=[])


def review_final_pdf(a,iid,pdf_sha,confirmed):
    if confirmed is not True:raise ValueError('Controllare il PDF definitivo prima di inviarlo.')
    item=a.get(iid)
    if item['data'].get('status')!='issued':raise ValueError('Il verbale non è emesso.')
    e=a.get(item['data']['issued_export_id'])
    if not pdf_sha or pdf_sha!=e['data'].get('pdf_sha'):raise Conflict('Il PDF è cambiato: aprire e controllare il PDF definitivo attuale.')
    def op(c):
        current=a.get(iid)
        if current['data'].get('status')!='issued' or current['data'].get('issued_export_id')!=e['id']:raise Conflict('Il verbale è cambiato durante la presa visione.')
        fresh=a.get(e['id'])
        if fresh['data'].get('pdf_sha')!=pdf_sha:raise Conflict('Il PDF è cambiato durante la presa visione.')
        return a._put(c,'export',dict(fresh['data'],final_review={'by':a.actor,'at':now(),'pdf_sha':pdf_sha}),e['id'],fresh['revision'],action='pdf_reviewed')
    a.mutate(op,True)
    return e
