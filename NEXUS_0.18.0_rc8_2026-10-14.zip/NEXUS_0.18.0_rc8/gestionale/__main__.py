"""Avvio: `python -m gestionale` (usato da AVVIA_WINDOWS.bat)."""

from __future__ import annotations

import logging
import sys
import threading
import webbrowser
from logging.handlers import RotatingFileHandler

import uvicorn

from . import VERSIONE
from .app import DatabaseTroppoNuovo, crea_app
from .core.config import carica_config, fissa_cartella_dati


def main() -> int:
    cfg = carica_config()
    cfg.prepara_cartelle()
    gestore = RotatingFileHandler(cfg.cartella_dati / "gestionale.log", maxBytes=5_000_000, backupCount=5, encoding="utf-8")
    logging.basicConfig(level=logging.INFO, handlers=[gestore, logging.StreamHandler()],
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    print(f"NEXUS {VERSIONE} — dati in {cfg.cartella_dati}")
    if fissa_cartella_dati(cfg):
        print("La cartella dei dati è stata scritta in config.json (cartella_dati).")
    try:
        app = crea_app(cfg)
    except DatabaseTroppoNuovo as e:
        print(f"\nERRORE: {e}\n")
        return 2
    if app.state.archivio_vuoto:
        print("\nATTENZIONE: l'archivio è vuoto (nessun cliente). Se avevi già dei dati, chiudi il programma e scrivi in")
        print("config.json la loro cartella in \"cartella_dati\" (LEGGIMI, paragrafo 7).\n")
    indirizzo = f"http://{'localhost' if cfg.indirizzo in ('127.0.0.1', '0.0.0.0') else cfg.indirizzo}:{cfg.porta}/"
    print(f"Apri {indirizzo} nel browser. Per chiudere il programma chiudi questa finestra (o premi Ctrl+C).")
    if cfg.apri_browser:
        threading.Timer(1.5, lambda: webbrowser.open(indirizzo)).start()
    # Un solo processo: le scritture sono in fila e il registro a catena resta coerente.
    uvicorn.run(app, host=cfg.indirizzo, port=cfg.porta, workers=1, log_level="warning", proxy_headers=cfg.https)
    return 0


if __name__ == "__main__":
    sys.exit(main())
