"""Elenco di tutti i modelli: serve alle migrazioni per conoscere l'intero schema.

Ogni modulo nuovo aggiunge qui l'importazione dei propri modelli.
"""

from .core.db import Base  # noqa: F401
from .moduli.documenti.modelli import Documento  # noqa: F401
from .moduli.griglie.modelli import ConfigurazioneGriglia  # noqa: F401
from .moduli.impostazioni.modelli import Impostazione  # noqa: F401
from .moduli.registro.modelli import RegistroOperazione  # noqa: F401
from .moduli.utenti.modelli import Permesso, Ruolo, RuoloPermesso, Sessione, Utente, UtenteRuolo  # noqa: F401
from .moduli.anagrafica.modelli import Cliente, Commerciale, Comune, ElencoValore, Impianto, ImpiantoPod, Sede  # noqa: F401
from .moduli.anagrafica.modelli import ClienteDoppioneEscluso, Origine, SedeDoppioneEsclusa  # noqa: F401
from .moduli.tariffario.modelli import ScaglioneTariffa, VersioneTariffa, VoceTariffa  # noqa: F401
from .moduli.documenti.modelli import ModelloDocumento  # noqa: F401
from .moduli.preventivi.modelli import DocumentoPreventivo, InvioPreventivo, Preventivo, Riesame, RigaPreventivo  # noqa: F401
from .moduli.verifiche.modelli import DocumentoVerifica, ElementoImpianto, Verifica  # noqa: F401

from .moduli.finanza.modelli import Societa, Fattura, RigaFattura, ScadenzaFattura, EsportazioneFattura, EsitoFattura, Incasso, AllocazioneIncasso  # noqa: F401

from .moduli.verifiche.modelli import RiesameVerifica  # noqa: F401

from .moduli.beni.modelli import Asset, AssetOrigine, AssetRelazione, CameraGvr, ScadenzaTecnica, FamigliaGvr, TipoAttrezzatura, IdSpecifica, CompatibilitaClassificazione  # noqa: F401

from .moduli.dm.modelli import TariffaDM, IncaricoDM, ContatoreDM, DocumentoDM, RiesameDM, InvioDM  # noqa: F401
from .moduli.finanza.modelli import DocumentoFattura  # noqa: F401
from .moduli.dm.modelli import EsportazioneINAIL, RigaEsportazioneINAIL  # noqa: F401
from .moduli.strumenti.modelli import StrumentoMisura  # noqa: F401
from .moduli.preventivi.modelli import AllegatoPreventivo  # noqa: F401
