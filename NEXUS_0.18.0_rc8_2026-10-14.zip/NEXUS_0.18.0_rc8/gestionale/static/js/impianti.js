/* Impianti: elenco con sede e cliente (D43), scheda con i campi della tipologia, POD multipli (G35),
   prossima verifica calcolata (D9), tariffa proposta dal tariffario, dismissione (D10), storico. */
"use strict";

(async () => {
  const { el, api, toast, errore, conferma, pannello, modale, formatta } = GAD;
  const S = GAD.schede;
  const { f, campo, sezione } = S;
  await S.me();
  const valori = await api("GET", "/api/anagrafica/valori");
  const g = await GAD.griglia(document.getElementById("griglia"), "impianti", {
    suRiga: (r) => apri(r.id),
    azioni: {
      modifica: (r) => apri(r.id),
      elimina: S.puo("anagrafica.impianti") ? (r) => S.eliminaDaRiga(`/api/impianti/${r.id}`, `l'impianto n. ${r.id}`, g) : null,
      collegamenti: [
        { testo: "Cliente → scheda", vai: (r) => `/clienti?apri=${r.cliente_id}` },
        { testo: "Sede operativa → scheda", vai: (r) => `/sedi?apri=${r.sede_id}` },
        { testo: "Altri impianti della sede", vai: (r) => S.filtro("impianti", "sede_id", r.sede_id, `impianti della sede ${r.sede_denominazione}`) },
        { testo: "Impianti ← Cliente", vai: (r) => S.filtro("impianti", "cliente_id", r.cliente_id, `impianti di ${r.cliente_ragione_sociale}`) },
        ...(S.puo("verifiche.vedere_proprie", "DPR") ? [{ testo: "Verifiche ← Impianto", vai: (r) => S.filtro("verifiche", "impianto_id", r.id, `verifiche dell'impianto n. ${r.id}`) }] : []),
        { testo: "Scadenza dell'impianto", vai: (r) => S.filtro("scadenze", "id", r.id, `impianto n. ${r.id}`) },
      ],
    },
  });

  /** Stessa regola del server: ultima verifica + periodicità − 1 giorno. */
  function calcolaProssima(ultima, anni) {
    if (!ultima || !anni) return "";
    const [a, m, d] = ultima.split("-").map(Number);
    const giorniMese = new Date(a + Number(anni), m, 0).getDate();
    const dt = new Date(Date.UTC(a + Number(anni), m - 1, Math.min(d, giorniMese)));
    dt.setUTCDate(dt.getUTCDate() - 1);
    return dt.toISOString().slice(0, 10);
  }

  function elencoPod(iniziali) {
    const box = el("div", { class: "elenco-pod" });
    const riga = (valore = "") => {
      const input = f.testo(valore, { maxlength: "20", placeholder: "IT001E12345678" });
      const r = el("div", { class: "riga" }, input, el("button", { class: "btn small", type: "button", title: "Togli", onclick: () => r.remove() }, "×"));
      return r;
    };
    (iniziali.length ? iniziali : [""]).forEach((p) => box.append(riga(p)));
    const aggiungi = el("button", { class: "btn small", type: "button", onclick: () => aggiungi.before(riga()) }, "＋ Aggiungi POD");
    box.append(aggiungi);
    return { el: box, valori: () => [...box.querySelectorAll("input")].map((i) => i.value.trim()).filter(Boolean) };
  }

  function modulo(x, sede) {
    x = x || { tipologia: "terra_bt", periodicita_anni: 2, pod: [] };  // O9: 2 anni di partenza
    const sedeScelta = S.ricerca({
      cerca: (t) => api("GET", "/api/sedi/cerca?q=" + encodeURIComponent(t)),
      mostra: (s) => [s.denominazione, [s.cliente, s.comune].filter(Boolean).join(" · ")],
      scelto: sede, segnaposto: "Cerca la sede (nome della sede, del cliente o comune)…",
    });
    const m = {
      tipologia: f.scelta(Object.entries(valori.tipologie).map(([k, v]) => ({ valore: k, testo: v })), x.tipologia),
      denominazione: f.testo(x.denominazione, { maxlength: "300" }),
      matricola_anno: f.testo(x.matricola_anno, { maxlength: "4", placeholder: "anno" }),
      matricola_attivita: f.testo(x.matricola_attivita, { maxlength: "10", placeholder: "cod. att." }),
      matricola_numero: f.testo(x.matricola_numero, { maxlength: "20", placeholder: "numero" }),
      matricola_provincia: f.testo(x.matricola_provincia, { maxlength: "2", placeholder: "prov." }),
      potenza_kw: f.numero(x.potenza_kw),
      cabine_mt_bt: f.numero(x.cabine_mt_bt),
      sottostazioni_at_mt: f.numero(x.sottostazioni_at_mt),
      pod_note: f.area(x.pod_note, { maxlength: "2000" }),
      numero_aste: f.numero(x.numero_aste),
      gabbia_fascia: f.scelta(Object.entries(valori.fasce_gabbia).map(([k, v]) => ({ valore: k, testo: v })), x.gabbia_fascia, { vuota: "—" }),
      periodicita_anni: f.scelta(valori.periodicita.map((p) => ({ valore: p, testo: `${p} anni` })), x.periodicita_anni, { vuota: "—" }),
      ultima_verifica_data: f.data(x.ultima_verifica_data),
      ultima_verifica_numero: f.testo(x.ultima_verifica_numero, { maxlength: "40", placeholder: "es. VP/659/26" }),
      prossima_verifica: f.data(x.prossima_verifica),
      note: f.area(x.note, { maxlength: "8000" }),
      avvisi: f.area(x.avvisi, { maxlength: "8000" }),
      codice_esterno: f.testo(x.codice_esterno, { maxlength: "40" }),
    };
    const asta = f.casella("Aste (parafulmini ad asta)", x.asta);
    const gabbia = f.casella("Gabbia di Faraday", x.gabbia);
    const gas = f.casella("Gas, vapori, nebbie (zone 0, 1, 2)", x.gas);
    const polveri = f.casella("Polveri (zone 20, 21, 22)", x.polveri);
    const zoneScelte = (x.zone || "").split(",").map((z) => z.trim());
    const zone = valori.zone.map((z) => f.casella(`Zona ${z}`, zoneScelte.includes(z)));
    const pod = elencoPod(x.pod || []);

    const terra = el("div", { class: "field-grid" }, sezione("Messa a terra"),
      campo("Potenza (kW)", m.potenza_kw, { aiuto: "Sempre; serve anche per la tariffa." }),
      campo("Cabine di trasformazione MT/BT", m.cabine_mt_bt, { aiuto: "Solo oltre 1.000 V." }),
      campo("Sottostazioni AT/MT", m.sottostazioni_at_mt, { aiuto: "Solo oltre 1.000 V." }),
      campo("Codici POD", pod.el, { pieno: true, aiuto: "Uno per fornitura: un impianto di terra unico può averne più d'uno (un solo verbale)." }),
      campo("Note POD", m.pod_note, { pieno: true, aiuto: "Numeri cliente o testi che non sono POD." }));
    const scariche = el("div", { class: "field-grid" }, sezione("Scariche atmosferiche"),
      el("div", { class: "field" }, asta.el), campo("Numero di aste", m.numero_aste),
      el("div", { class: "field" }, gabbia.el), campo("Superficie protetta dalla gabbia", m.gabbia_fascia));
    const esplosione = el("div", { class: "field-grid" }, sezione("Luoghi con pericolo di esplosione"),
      el("div", { class: "field" }, gas.el), el("div", { class: "field" }, polveri.el),
      campo("Zone classificate", el("div", { class: "caselle" }, ...zone.map((z) => z.el)), { pieno: true }));
    const prossimaCalcolata = el("div", { class: "riquadro" });
    const verifiche = el("div", { class: "field-grid" },
      campo("Periodicità", m.periodicita_anni, { aiuto: "2 o 5 anni, scritta a mano (D8)." }),
      campo("Ultima verifica (data)", m.ultima_verifica_data), campo("Ultimo verbale (numero)", m.ultima_verifica_numero),
      campo("Prossima verifica", el("div", {}, m.prossima_verifica, prossimaCalcolata), { aiuto: "Con ultima verifica e periodicità si calcola da sola (D9); altrimenti scrivila a mano." }));
    function aggiorna() {
      const t = m.tipologia.value;
      terra.hidden = !t.startsWith("terra");
      m.cabine_mt_bt.closest(".field").hidden = t !== "terra_at";
      m.sottostazioni_at_mt.closest(".field").hidden = t !== "terra_at";
      scariche.hidden = t !== "scariche";
      esplosione.hidden = t !== "esplosione";
      // O8: pericolo di esplosione → sempre 2 anni
      if (t === "esplosione") { m.periodicita_anni.value = "2"; m.periodicita_anni.disabled = true; m.periodicita_anni.dataset.esplosione = "1"; }
      else if (m.periodicita_anni.dataset.esplosione) { m.periodicita_anni.disabled = false; delete m.periodicita_anni.dataset.esplosione; }
      m.numero_aste.disabled = !asta.valore;
      m.gabbia_fascia.disabled = !gabbia.valore;
      const calc = calcolaProssima(m.ultima_verifica_data.value, m.periodicita_anni.value);
      m.prossima_verifica.hidden = !!calc;
      prossimaCalcolata.hidden = !calc;
      prossimaCalcolata.replaceChildren("Calcolata: ", el("strong", {}, formatta.data(calc)), " (ultima verifica + periodicità − 1 giorno, come il gestionale attuale)");
    }
    [m.tipologia, asta.input, gabbia.input, m.ultima_verifica_data, m.periodicita_anni].forEach((i) => i.addEventListener("change", aggiorna));
    m.ultima_verifica_data.addEventListener("input", aggiorna);
    const dati = el("div", {}, el("div", { class: "field-grid" },
      campo("Sede operativa", sedeScelta.el, { pieno: true }),
      campo("Tipologia", m.tipologia), campo("Denominazione dell'impianto", m.denominazione, { aiuto: "Facoltativa (es. «Cabina 2», «Capannone B»)." }),
      campo("Matricola INAIL", el("div", { class: "riga-campi" }, m.matricola_anno, m.matricola_attivita, m.matricola_numero, m.matricola_provincia), { pieno: true, aiuto: "Anno / codice attività / numero / provincia." })),
    terra, scariche, esplosione);
    const note = el("div", { class: "field-grid" }, campo("Note", m.note, { pieno: true }), campo("Da controllare", m.avvisi, { pieno: true }),
      campo("Codice nel gestionale attuale", m.codice_esterno));
    aggiorna();
    return {
      dati, verifiche, note, campi: m,
      valori: () => ({
        ...Object.fromEntries(Object.entries(m).map(([k, v]) => [k, v.value])),
        sede_id: sedeScelta.valore ? sedeScelta.valore.id : null, pod: pod.valori(),
        asta: asta.valore, gabbia: gabbia.valore, gas: gas.valore, polveri: polveri.valore,
        zone: valori.zone.filter((_z, i) => zone[i].valore),
      }),
    };
  }

  function riquadroTariffa(t) {
    if (!t) return null;
    const righe = t.voci.map((v) => el("div", {}, `${v.voce}: `, el("strong", {}, formatta.importo(v.importo)), ` (${v.spiegazione})`));
    return el("div", { class: "riquadro" },
      el("div", {}, "Tariffa standard proposta dal tariffario in vigore oggi:"),
      el("strong", { class: "grande" }, t.totale === null ? "non calcolabile" : formatta.importo(t.totale)),
      ...righe, ...t.problemi.map((p) => el("div", { class: "subtle" }, "⚠ " + p)));
  }

  async function nuovo(sedeId) {
    let sede = null;
    if (sedeId) { try { const s = await api("GET", `/api/sedi/${sedeId}`); sede = { id: s.id, denominazione: s.denominazione, cliente: s.cliente, comune: s.comune }; } catch (e) { errore(e); } }
    const m = modulo(null, sede);
    const salva = S.azione("Crea impianto", "primary", async () => {
      const x = await api("POST", "/api/impianti", m.valori());
      toast(`Impianto n. ${x.id} creato.`); g.ricarica(); apri(x.id);
    });
    pannello.apri("Nuovo impianto", S.linguette([{ titolo: "Impianto", contenuto: m.dati }, { titolo: "Verifiche", contenuto: m.verifiche }, { titolo: "Note", contenuto: m.note }]), [salva], { largo: true });
  }

  async function apri(id) {
    let x;
    try { x = await api("GET", `/api/impianti/${id}`); } catch (e) { return errore(e); }
    const m = modulo(x, { id: x.sede_id, denominazione: x.sede, cliente: x.cliente });
    const storico = el("div");
    // 0.4.0 (G39) → 0.12.7 (R122): una sola scheda tecnica, quella di VerbalizzAI, da cui riparte il verbale successivo
    const tecnica = el("div", {}, el("p", { class: "subtle" }, "Caricamento…"));
    const caricaTecnica = async () => {
      let d, sc;
      try {
        [d, sc] = await Promise.all([api("GET", `/api/impianti/${x.id}/verifiche`), api("GET", `/api/impianti/${x.id}/scheda-tecnica`)]);
      } catch (e) { return tecnica.replaceChildren(el("p", { class: "subtle" }, e.message)); }
      const attr = (a) => Object.entries(a || {}).filter(([, val]) => val).map(([k, val]) => `${{ brand_model: "marca/modello", idn_text: "Idn", in: "In", ia: "Ia", reference: "riferimento" }[k] || k}: ${val}`).join(" · ");
      const stato = !sc.fonte ? "Ancora vuota: si compila con il primo verbale (emesso o caricato) o a mano dalla scheda."
        : [sc.da_riesaminare ? "Da riesaminare: il verbale da cui deriva è stato annullato" : sc.confermata ? "Confermata" : "Recuperata dallo storico: da confermare",
          sc.data ? `aggiornata al ${formatta.data(sc.data)}` : "", sc.verbale ? `verbale ${sc.verbale}` : "", sc.origine].filter(Boolean).join(" · ");
      const comandi = [];
      if (S.puo("verifiche.vedere_proprie", "DPR")) {
        comandi.push(S.azione(S.puo("impianti.stato_tecnico", "DPR") ? "Modifica scheda tecnica" : "Apri scheda tecnica", "", async () => {
          const r = await api("POST", `/api/impianti/${x.id}/scheda-tecnica/apri`, {});
          location.href = r.url;
        }));
      }
      tecnica.replaceChildren(...[
        sezione("Scheda tecnica"),
        el("p", { class: sc.da_riesaminare || (sc.fonte && !sc.confermata) ? "notice" : "subtle" }, stato),
        el("p", { class: "subtle" }, "Una sola scheda per l'impianto: è quella di VerbalizzAI e il verbale successivo riparte da qui. " +
          "Si aggiorna all'emissione del verbale (se si sceglie «Aggiorna la scheda impianto») o a mano. Esito, durata, persona presente, " +
          "misure e note restano nei singoli verbali."),
        sc.voci.length ? S.tabella([{ titolo: "Voce", valore: (v) => v.etichetta }, { titolo: "Valore", valore: (v) => v.valore }], sc.voci) : null,
        comandi.length ? el("p", {}, ...comandi) : null,
        sezione(`Elementi dell'impianto (${sc.elementi.length})`),
        sc.elementi.length ? S.tabella([{ titolo: "Quadro", valore: (e) => e.quadro }, { titolo: "Tipo", valore: (e) => e.tipo_testo },
          { titolo: "Elemento", valore: (e) => e.nome }, { titolo: "Dati", valore: (e) => attr(e.attributi) }], sc.elementi) : el("p", { class: "subtle" }, "Nessun elemento."),
        sezione("Verifiche"),
        d.verifiche.length ? S.tabella([{ titolo: "Verbale", valore: (v) => v.codice_verbale || `verifica n. ${v.id}` }, { titolo: "Stato", valore: (v) => v.stato_testo },
          { titolo: "Data", valore: (v) => (v.data_esecuzione ? formatta.data(v.data_esecuzione) : "—") }, { titolo: "Esito", valore: (v) => v.esito_testo || "—" }],
        d.verifiche, (v) => (location.href = `/verifiche?apri=${v.id}`)) : el("p", { class: "subtle" }, "Nessuna verifica nel gestionale.")].filter(Boolean));
    };
    const testata = [el("div", { class: "riquadro" }, "Cliente: ", el("a", { href: `/clienti?apri=${x.cliente_id}` }, x.cliente),
      " · Sede: ", el("a", { href: `/sedi?apri=${x.sede_id}` }, x.sede), x.sede_indirizzo ? ` — ${x.sede_indirizzo}` : "")];
    if (x.dismesso) testata.unshift(el("div", { class: "notice" }, "Impianto dismesso: resta in archivio ma non compare nello scadenziario (D10)."));
    const av = S.avvisi(x.avvisi, m.campi.avvisi);
    if (av) testata.unshift(av);
    const corpo = el("div", {}, ...testata, S.linguette([
      { titolo: "Impianto", contenuto: m.dati },
      { titolo: "Verifiche e tariffa", contenuto: el("div", {}, m.verifiche, riquadroTariffa(x.tariffa)) },
      { titolo: "Scheda tecnica", contenuto: tecnica, apri: caricaTecnica },
      { titolo: "Note", contenuto: m.note },
      { titolo: "Storico", contenuto: storico, apri: async () => storico.replaceChildren(await S.storico("impianto", x.id)) },
    ]), S.traccia(x));
    const pulsanti = [];
    if (S.puo("anagrafica.dismetti")) {
      pulsanti.push(S.azione(x.dismesso ? "Rimetti in servizio" : "Dismetti…", x.dismesso ? "" : "danger", async () => {
        let motivo = "";
        if (!x.dismesso) {
          const c = el("input", { maxlength: "500", placeholder: "es. impianto smantellato, attività chiusa" });
          if (!(await modale("Dismettere l'impianto?", [el("p", {}, "L'impianto resta in archivio ma esce dallo scadenziario."), campo("Motivo", c)],
            [{ testo: "Annulla", valore: false }, { testo: "Dismetti", classe: "danger", valore: true }]))) return;
          motivo = c.value;
        }
        await api("POST", `/api/impianti/${x.id}/dismesso`, { dismesso: !x.dismesso, motivo, versione: x.versione });
        toast("Fatto."); g.ricarica(); apri(x.id);
      }));
    }
    if (S.puo("anagrafica.impianti") && !x.ultima_verifica_data && !x.ultima_verifica_numero) {
      pulsanti.push(S.azione("Elimina", "danger", async () => {
        if (!(await conferma("Eliminare l'impianto?", "Senza verifiche registrate si può eliminare (i dati restano nel registro). Se esiste ma non si verifica più, meglio «Dismetti».", { pulsante: "Elimina", pericolo: true }))) return;
        await api("DELETE", `/api/impianti/${x.id}`); toast("Impianto eliminato."); pannello.chiudi(); g.ricarica();
      }));
    }
    pulsanti.push(el("span", { class: "spazio" }));
    if (S.puo("anagrafica.impianti")) {
      pulsanti.push(S.azione("Salva", "primary", async () => {
        await api("PUT", `/api/impianti/${x.id}`, { ...m.valori(), versione: x.versione });
        toast("Modifiche salvate."); g.ricarica(); apri(x.id);
      }));
    } else S.solaLettura(corpo);
    pannello.apri(`Impianto n. ${x.id} · ${x.tipologia_testo}`, corpo, pulsanti, { largo: true });
  }

  document.getElementById("nuovo")?.addEventListener("click", () => nuovo(S.daFiltro("sede_id")));  // O5
  const richiesta = S.apriDaIndirizzo(apri);
  if (richiesta && richiesta.nuovo) nuovo(richiesta.sede_id);
})().catch((e) => GAD.errore(e));
