/* Verbali di VerbalizzAI (0.5.0): importazione dell'archivio e collegamento di ogni impianto di VerbalizzAI a una sede del gestionale. */
"use strict";

(async () => {
  const { el, api, toast, errore, modale } = GAD;
  const S = GAD.schede;
  const { f, campo } = S;
  const box = document.getElementById("verbali-importa");
  const MOTIVI = { POD: "ok", "cliente e indirizzo": "ok", probabile: "avviso", "da scegliere": "avviso", "": "errore" };
  let dati = null;
  const filtro = f.scelta([
    { valore: "da_collegare", testo: "Da collegare" }, { valore: "tutti", testo: "Tutti" }, { valore: "collegati", testo: "Collegati" },
    { valore: "POD", testo: "Proposta: POD" }, { valore: "cliente e indirizzo", testo: "Proposta: cliente e indirizzo" },
    { valore: "probabile", testo: "Proposta: probabile" }, { valore: "da scegliere", testo: "Da scegliere" }, { valore: "", testo: "Senza proposta" },
  ], "da_collegare");
  const cerca = el("input", { type: "search", placeholder: "Cerca cliente o indirizzo…" });
  const elenco = el("div");
  filtro.addEventListener("change", disegnaElenco);
  cerca.addEventListener("input", disegnaElenco);

  const descrizioneSede = (x) => el("div", {}, el("strong", {}, x.cliente), x.denominazione ? ` · ${x.denominazione}` : "", el("div", { class: "subtle" }, x.indirizzo));

  async function collega(r, sedeId) {
    const esito = await api("POST", `/api/verbali/collegamenti/${encodeURIComponent(r.id)}`, { sede_id: sedeId });
    toast(`Collegato: ${r.cliente}.`);
    if (esito.note.length) await modale("Collegamento fatto, con alcune note", [el("ul", {}, ...esito.note.map((n) => el("li", {}, n)))], [{ testo: "Ok", valore: true }]);
    await carica();
  }

  async function scegli(r) {
    const q = el("input", { type: "search", placeholder: "Ragione sociale, sede o comune", value: (r.cliente || "").split(/[–,(]/)[0].trim() });
    const risultati = el("div", { class: "lista-scelta" });
    let scelta = null;
    const mostra = (righe) => risultati.replaceChildren(...(righe.length ? righe.map((x) => el("label", { class: "riga-scelta" },
      el("input", { type: "radio", name: "sede", onchange: () => { scelta = x.id; } }), descrizioneSede({ ...x, indirizzo: [x.comune, x.provincia && `(${x.provincia})`].filter(Boolean).join(" ") })))
      : [el("p", { class: "subtle" }, "Nessuna sede trovata. Se il cliente non c'è, crealo in Anagrafica › Clienti e poi torna qui.")]));
    const trova = async () => { try { mostra(await api("GET", `/api/sedi/cerca?q=${encodeURIComponent(q.value)}`)); } catch (e) { errore(e); } };
    q.addEventListener("input", () => { clearTimeout(q._t); q._t = setTimeout(trova, 250); });
    if (r.alternative.length) mostra(r.alternative.map((x) => ({ id: x.id, cliente: x.cliente, denominazione: x.denominazione, comune: x.indirizzo })));
    else trova();
    if (!(await modale(`Sede per «${r.cliente}»`, [el("p", { class: "subtle" }, `VerbalizzAI: ${r.indirizzo} · ${r.verbali} verbali (${r.moduli.join(", ")})`),
      campo("Cerca", q), risultati], [{ testo: "Annulla", valore: false }, { testo: "Collega", classe: "primary", valore: true }]))) return;
    if (!scelta) throw new Error("Scegli una sede dall'elenco.");
    await collega(r, scelta);
  }

  function disegnaElenco() {
    const t = cerca.value.trim().toLowerCase();
    const righe = dati.impianti.filter((r) => {
      const v = filtro.value;
      if (v === "da_collegare" && r.collegata) return false;
      if (v === "collegati" && !r.collegata) return false;
      if (!["da_collegare", "tutti", "collegati"].includes(v) && (r.collegata || r.motivo !== v)) return false;
      return !t || `${r.cliente} ${r.sede} ${r.indirizzo}`.toLowerCase().includes(t);
    });
    elenco.replaceChildren(el("p", { class: "subtle" }, `${righe.length} impianti di VerbalizzAI`), S.tabella([
      { titolo: "In VerbalizzAI", valore: (r) => el("div", {}, el("strong", {}, r.cliente), r.sede ? ` · ${r.sede}` : "", el("div", { class: "subtle" }, r.indirizzo),
        r.pod.length ? el("div", { class: "subtle" }, "POD " + r.pod.join(", ")) : null) },
      { titolo: "Verbali", valore: (r) => el("div", {}, `${r.verbali} (${r.moduli.join(", ")})`, el("div", { class: "subtle" }, r.ultimo ? `ultimo ${r.ultimo} del ${r.ultimo_data}` : "")) },
      { titolo: "Sede del gestionale", valore: (r) => r.collegata ? el("div", {}, el("span", { class: "badge ok" }, "collegata"), descrizioneSede(r.collegata))
        : el("div", {}, el("span", { class: "badge " + MOTIVI[r.motivo] }, r.motivo || "nessuna proposta"), r.proposta ? descrizioneSede(r.proposta) : null,
          r.alternative.length ? el("div", { class: "subtle" }, `${r.alternative.length} sedi possibili`) : null) },
      { titolo: "", valore: (r) => el("span", { class: "actions" },
        !r.collegata && r.proposta ? S.azione("Collega", "small primary", () => collega(r, r.proposta.id)) : null,
        S.azione(r.collegata ? "Cambia…" : "Scegli…", "small", () => scegli(r)),
        r.collegata ? S.azione("Scollega", "small", async () => { await api("DELETE", `/api/verbali/collegamenti/${encodeURIComponent(r.id)}`); toast("Scollegato."); await carica(); }) : null) },
    ], righe));
  }

  async function carica() {
    dati = await api("GET", "/api/verbali/collegamenti");
    const c = dati.riepilogo;
    const sicure = (c.POD || 0) + (c["cliente e indirizzo"] || 0);
    const file = el("input", { type: "file", accept: ".zip" });
    box.replaceChildren(...[
      dati.verbali ? null : el("div", { class: "panel" }, el("h3", {}, "1. Importa l'archivio di VerbalizzAI"),
        el("p", { class: "subtle" }, "In VerbalizzAI: Backup e ripristino › «Backup completo» (file …adbackup.zip, con i documenti). " +
          "L'importazione si fa una volta, al passaggio: tutti i verbali, i modelli, gli strumenti e le firme entrano nel gestionale."),
        el("div", { class: "field-grid" }, campo("Backup completo di VerbalizzAI (.zip)", file, { pieno: true })),
        el("div", { class: "actions" }, S.azione("Importa", "primary", async () => {
          if (!file.files[0]) throw new Error("Scegli il file di backup.");
          const fd = new FormData(); fd.append("file", file.files[0]);
          const r = await api("POST", "/api/verbali/importa", fd);
          toast(`Importati ${r.oggetti} elementi e ${r.documenti} documenti.`); await carica();
        }))),
      dati.impianti.length ? el("div", { class: "panel" }, el("h3", {}, "Collegamento alle sedi del gestionale"),
        el("p", { class: "subtle" }, `${dati.impianti.length} impianti di VerbalizzAI, ${dati.verbali} verbali. Collegati: ${c.collegata || 0}. ` +
          `Proposte: POD ${c.POD || 0}, cliente e indirizzo ${c["cliente e indirizzo"] || 0}, probabili ${c.probabile || 0}, da scegliere ${c["da scegliere"] || 0}, senza proposta ${c.nessuna || 0}.`),
        el("p", { class: "subtle" }, "Collegando, ogni modulo (M01, M02, M03) va sull'impianto del gestionale dello stesso tipo, che si aggiorna con l'ultimo verbale " +
          "(date, caratteristiche, elementi provati). Ragione sociale e indirizzo dei verbali nuovi verranno sempre dal gestionale."),
        el("div", { class: "actions" }, sicure ? S.azione(`Collega le ${sicure} proposte sicure (POD, cliente e indirizzo)`, "primary", async () => {
          const r = await api("POST", "/api/verbali/collegamenti/proposte");
          toast(`${r.collegati} impianti collegati.`);
          if (r.note.length) await modale("Collegamenti fatti, con alcune note", [el("ul", {}, ...r.note.map((n) => el("li", {}, n)))], [{ testo: "Ok", valore: true }]);
          await carica();
        }) : null, el("a", { class: "btn", href: "/verbali" }, "Apri i verbali")),
        el("div", { class: "field-grid" }, campo("Mostra", filtro), campo("Cerca", cerca)), elenco) : null].filter(Boolean));
    if (dati.impianti.length) disegnaElenco();
  }
  await carica();
})().catch((e) => GAD.errore(e));
