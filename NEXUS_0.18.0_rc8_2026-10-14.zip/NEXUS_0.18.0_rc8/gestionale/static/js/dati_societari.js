/* Dati della società e pagamenti (rc8, punto 6 · decisione di Federico del 14/10/2026): in Gestione › Configurazione i
   dati fiscali della società emittente, le modalità di pagamento e le regole generali di calcolo delle scadenze.
   Le date e gli importi delle scadenze della singola fattura restano nella sua scheda (modificabili prima dell'emissione).
   Stesse funzioni di prima (PUT /api/societa/{id}, PUT /api/finanza/modalita/{id}/regole): cambia solo dove si trovano.
   Con ?ritorno=/fatture?apri=N, dopo il salvataggio si torna alla bozza con gli avvisi aggiornati. */
"use strict";

(async () => {
  const { el, api, toast, errore, modale } = GAD;
  const S = GAD.schede;
  const box = document.getElementById("impostazioni");
  const ritorno = (() => { const r = new URLSearchParams(location.search).get("ritorno") || ""; return /^\/fatture\?apri=\d+$/.test(r) ? r : ""; })();
  const MP = [["MP01", "MP01 Contanti"], ["MP02", "MP02 Assegno"], ["MP03", "MP03 Assegno circolare"], ["MP05", "MP05 Bonifico"], ["MP06", "MP06 Vaglia cambiario"],
    ["MP07", "MP07 Bollettino bancario"], ["MP08", "MP08 Carta di pagamento"], ["MP09", "MP09 RID"], ["MP10", "MP10 RID utenze"], ["MP11", "MP11 RID veloce"],
    ["MP12", "MP12 RIBA"], ["MP13", "MP13 MAV"], ["MP14", "MP14 Quietanza erario"], ["MP15", "MP15 Giroconto su conti di contabilità speciale"],
    ["MP16", "MP16 Domiciliazione bancaria"], ["MP17", "MP17 Domiciliazione postale"], ["MP18", "MP18 Bollettino di c/c postale"], ["MP19", "MP19 SEPA Direct Debit"],
    ["MP20", "MP20 SEPA Direct Debit CORE"], ["MP21", "MP21 SEPA Direct Debit B2B"], ["MP22", "MP22 Trattenuta su somme già riscosse"], ["MP23", "MP23 PagoPA"]];
  const CAMPI = { ragione_sociale: "Ragione sociale", partita_iva: "Partita IVA", codice_fiscale: "Codice fiscale", indirizzo: "Indirizzo", cap: "CAP", comune: "Comune",
    provincia: "Provincia", nazione: "Nazione", regime_fiscale: "Regime fiscale (RF01)", iban: "IBAN", banca: "Banca", id_trasmittente: "Identificativo trasmittente",
    rea_ufficio: "REA · ufficio (sigla provincia)", rea_numero: "REA · numero", capitale_sociale: "Capitale sociale €", socio_unico: "Socio unico (SU) o più soci (SM)",
    stato_liquidazione: "Liquidazione: LN no, LS sì", telefono: "Telefono", fax: "Fax", email: "Email" };
  const OBBLIGATORI = new Set(["ragione_sociale", "partita_iva", "indirizzo", "cap", "comune", "provincia", "regime_fiscale"]);
  const input = (v, tipo = "text") => el("input", { type: tipo, value: v ?? "" });
  const scelta = (opzioni, v) => { const x = el("select", {}, ...opzioni.map(([k, t]) => el("option", { value: k }, t))); x.value = v || opzioni[0][0]; return x; };

  async function disegna() {
    const valori = await api("GET", "/api/finanza/valori");
    const so = valori.societa.find((x) => x.codice === "AD");
    const inputs = {};
    const griglia = el("div", { class: "field-grid" });
    for (const [k, t] of Object.entries(CAMPI)) {
      inputs[k] = input(so.dati[k] || ({ nazione: "IT", regime_fiscale: "RF01", stato_liquidazione: "LN" }[k] || ""));
      griglia.append(S.campo(t + (OBBLIGATORI.has(k) ? " *" : ""), inputs[k]));
    }
    const mancano = [...OBBLIGATORI].filter((k) => !String(so.dati[k] || "").trim()).map((k) => CAMPI[k].replace(/ \(.*\)$/, ""));
    const torna = ritorno ? el("a", { class: "btn", href: ritorno }, "← Torna alla fattura") : null;
    box.replaceChildren(
      ritorno ? el("div", { class: "notice" }, "Completa i dati della società emittente e salva: poi torni alla bozza della fattura con gli avvisi aggiornati. ", torna) : null,
      el("div", { class: "panel" }, el("h3", {}, `Società emittente · dati fiscali (${so.codice})`),
        el("p", { class: "subtle" }, "Cedente nelle fatture elettroniche e nei PDF di cortesia. Si fissano nel documento al momento dell'emissione: cambiarli non tocca le fatture già emesse. * = indispensabili per emettere."),
        mancano.length ? el("div", { class: "notice errore" }, "Mancano: " + mancano.join(", ") + ".") : el("div", { class: "notice ok" }, "Dati indispensabili completi."),
        griglia,
        el("div", { class: "actions" }, S.azione("Salva i dati della società", "primary", async () => {
          await api("PUT", `/api/societa/${so.id}`, { versione: so.versione, dati: Object.fromEntries(Object.entries(inputs).map(([k, v]) => [k, v.value])) });
          toast("Dati della società salvati.");
          if (ritorno) { location.assign(ritorno); return; }
          disegna();
        }), torna)),
      el("div", { class: "panel" }, el("h3", {}, "Modalità di pagamento e regole generali delle scadenze"),
        el("p", { class: "subtle" }, "Come i «tipi di pagamento» di Garda: codice FatturaPA e rate. Le scadenze di una fattura si calcolano dalla modalità del preventivo, poi del cliente, poi dalla predefinita; nella fattura si possono ancora correggere prima dell'emissione."),
        ...valori.modalita.map((m) => {
          const r = m.regole;
          return el("div", { class: "riquadro" }, el("strong", {}, m.descrizione + (r.predefinito ? " · predefinita" : "")),
            el("p", { class: "subtle" }, `${r.mp} · rate: ${r.rate.map((q) => q.giorni + " gg" + (q.fine_mese ? " f.m." : "") + " " + q.percentuale + "%").join(", ")}` +
              `${r.fm_paga_dopo ? " · paga il " + r.fm_paga_dopo + " del mese dopo" : ""}${r.sposta_scadenze ? " · 31/8 e 31/12 → 10 del mese dopo" : ""}${r.salda_subito ? " · salda subito" : ""}`),
            S.azione("Modifica", "", () => regola(m)));
        }),
        el("p", { class: "subtle" }, "Nuove modalità e descrizioni: ", el("a", { href: "/tipi-pagamento" }, "Tipi di pagamento"), ".")));
  }

  async function regola(m) {
    const r = m.regole, mp = scelta(MP, r.mp), fm = input(r.fm_paga_dopo || "", "number");
    const sp = el("input", { type: "checkbox" }), ss = el("input", { type: "checkbox" }), pr = el("input", { type: "checkbox" });
    sp.checked = !!r.sposta_scadenze; ss.checked = !!r.salda_subito; pr.checked = !!r.predefinito;
    const rate = el("div", {}), voci = [];
    const agg = (q = { giorni: 30, percentuale: "100", fine_mese: false }) => {
      const v = { g: input(q.giorni, "number"), p: input(q.percentuale), f: el("input", { type: "checkbox" }), attivo: true };
      v.f.checked = !!q.fine_mese;
      const riga = el("div", { class: "field-grid" }, S.campo("Giorni", v.g), S.campo("% del totale", v.p), el("label", { class: "check" }, v.f, "Fine mese"));
      riga.append(S.azione("Togli", "", () => { v.attivo = false; riga.remove(); }));
      voci.push(v); rate.append(riga);
    };
    r.rate.forEach(agg);
    const corpo = el("div", {}, el("div", { class: "field-grid" }, S.campo("Codice FatturaPA", mp), S.campo("Con «fine mese» paga il giorno del mese dopo (vuoto = ultimo del mese)", fm)),
      ...[[sp, "Sposta le scadenze del 31/8 e del 31/12 al 10 del mese dopo"], [ss, "Salda subito il documento con questo pagamento (es. contanti, carta)"],
        [pr, "Predefinita (quando preventivo e cliente non ne indicano una)"]].map(([c, t]) => el("div", {}, el("label", { class: "check" }, c, t))),
      el("h4", {}, "Rate"), rate, S.azione("Aggiungi rata", "", () => agg({ giorni: 60, percentuale: "", fine_mese: true })));
    if (!await modale(m.descrizione, corpo, [{ testo: "Annulla", valore: null }, { testo: "Salva", valore: true, classe: "primary" }])) return;
    await api("PUT", `/api/finanza/modalita/${m.id}/regole`, { versione: m.versione, regole: { mp: mp.value, fm_paga_dopo: fm.value || null, sposta_scadenze: sp.checked,
      salda_subito: ss.checked, predefinito: pr.checked, rate: voci.filter((v) => v.attivo).map((v) => ({ giorni: Number(v.g.value || 0), percentuale: v.p.value, fine_mese: v.f.checked })) } });
    toast("Regole salvate."); disegna();
  }
  disegna().catch(errore);
})();
