/* Il mio profilo: misura del testo e cambio della password. */
"use strict";

(() => {
  const { api, toast, errore } = GAD;
  document.querySelectorAll("input[name=testo]").forEach((r) => r.addEventListener("change", async () => {
    const prima = document.documentElement.dataset.testo;
    document.documentElement.dataset.testo = r.value;  // si vede subito
    try {
      await api("PUT", "/api/io/testo", { misura: r.value });
      toast(r.value === "grande" ? "Testo grande: salvato." : "Testo normale: salvato.");
    } catch (e) {
      document.documentElement.dataset.testo = prima;
      document.querySelector(`input[name=testo][value=${prima}]`).checked = true;
      errore(e);
    }
  }));
  // 0.12.9: dati del tecnico per i verbali (una volta per tutte)
  const box = document.getElementById("dati-tecnico");
  if (box) GAD.schede.datiTecnico(Number(box.dataset.utente)).then((x) => box.replaceChildren(x)).catch(errore);
  const modulo = document.getElementById("modulo-password");
  modulo.addEventListener("submit", async (ev) => {
    ev.preventDefault();
    const f = new FormData(modulo);
    if (f.get("nuova") !== f.get("ripeti")) return errore(new Error("Le due nuove password non coincidono."));
    const pulsante = modulo.querySelector("button[type=submit]");
    pulsante.disabled = true;
    try {
      await api("POST", "/api/io/password", { attuale: f.get("attuale"), nuova: f.get("nuova") });
      toast("Password cambiata.");
      modulo.reset();
      setTimeout(() => (location.href = "/"), 900);
    } catch (e) {
      errore(e);
    } finally {
      pulsante.disabled = false;
    }
  });
})();
