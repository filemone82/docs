/* Importazione iniziale dell'anagrafica: anteprima con i problemi trovati, poi conferma. */
"use strict";

(() => {
  const { el, api, toast, errore, conferma, formatta } = GAD;
  const esito = document.getElementById("esito");
  const pulsante = document.getElementById("anteprima");

  function riquadroNumeri(r) {
    const voce = (n, t) => el("div", { class: "stat" }, el("strong", {}, formatta.numero(n)), el("span", {}, t));
    return el("div", { class: "cards" },
      voce(r.nuovi.clienti, `clienti nuovi (${r.gia_presenti.clienti} già presenti)`),
      voce(r.nuovi.sedi, `sedi nuove (${r.gia_presenti.sedi} già presenti)`),
      voce(r.nuovi.impianti, `impianti nuovi (${r.gia_presenti.impianti} già presenti)`),
      voce(r.problemi.length, "segnalazioni «da controllare»"));
  }

  pulsante.addEventListener("click", async () => {
    const dati = new FormData();
    for (const nome of ["clienti", "sedi", "impianti"]) {
      const f = document.getElementById("f-" + nome).files[0];
      if (f) dati.append(nome, f);
    }
    pulsante.disabled = true;
    esito.replaceChildren(el("div", { class: "panel" }, "Analisi dei file in corso…"));
    let r;
    try { r = await api("POST", "/api/importazione/anteprima", dati); } catch (e) { esito.replaceChildren(); pulsante.disabled = false; return errore(e); }
    pulsante.disabled = false;
    const tabellaProblemi = el("div");
    const area = el("div", { class: "panel" },
      el("h3", {}, "2 · Anteprima"),
      riquadroNumeri(r),
      el("p", { class: "subtle" }, ...Object.entries(r.lettura).map(([k, v]) => el("div", {}, `${k}: ${v}`))),
      r.nuovi_valori.modalita_pagamento.length || r.nuovi_valori.aliquota_iva.length
        ? el("p", { class: "subtle" }, "Valori nuovi da aggiungere agli elenchi: ", [...r.nuovi_valori.modalita_pagamento, ...r.nuovi_valori.aliquota_iva].join(" · ")) : null,
      el("h3", {}, "Tipi di segnalazione"),
      GAD.schede.tabella([{ titolo: "Segnalazione", valore: (x) => x.problema }, { titolo: "Quante", num: true, valore: (x) => formatta.numero(x.quanti) }], r.tipi_di_problema),
      el("p", { class: "subtle" }, "Le segnalazioni non fermano l'importazione: finiscono nel campo «Da controllare» di ciascuna scheda (colonna filtrabile nelle griglie) e si tolgono quando il dato è sistemato."),
      el("h3", {}, "Elenco delle segnalazioni"), tabellaProblemi);
    new Tabulator(tabellaProblemi, {
      data: r.problemi, layout: "fitColumns", height: "45vh", pagination: true, paginationSize: 100,
      columns: [{ title: "Cosa", field: "entita", width: 110, headerFilter: "input" }, { title: "Nome", field: "nome", headerFilter: "input" },
        { title: "Segnalazione", field: "problema", headerFilter: "input" }],
    });
    const conferma_ = el("button", { class: "btn primary", type: "button" }, "3 · Importa");
    conferma_.addEventListener("click", async () => {
      if (!(await conferma("Importare?", `Verranno aggiunti ${r.nuovi.clienti} clienti, ${r.nuovi.sedi} sedi e ${r.nuovi.impianti} impianti. Prima il programma fa un backup.`, { pulsante: "Importa" }))) return;
      conferma_.disabled = true;
      try {
        const x = await api("POST", "/api/importazione/conferma", { codice: r.codice });
        esito.replaceChildren(el("div", { class: "panel" }, el("div", { class: "notice ok" },
          `Importazione completata: ${x.clienti} clienti, ${x.sedi} sedi, ${x.impianti} impianti. Backup fatto prima: ${x.backup}. I file importati sono conservati nell'archivio documenti.`),
          el("div", { class: "actions" }, el("a", { class: "btn", href: "/clienti" }, "Vai ai clienti"), el("a", { class: "btn", href: "/impianti" }, "Vai agli impianti"), el("a", { class: "btn", href: "/scadenze" }, "Vai alle scadenze"))));
        toast("Importazione completata.");
      } catch (e) { conferma_.disabled = false; errore(e); }
    });
    area.append(el("div", { class: "actions" }, conferma_));
    esito.replaceChildren(area);
  });
})();
