/* Preventivi (D13–D19, D26, D36, D38, D39): elenco, scheda con righe, accettazione per riga, revisioni,
   riesame, Word/PDF e invio email. */
"use strict";

(async () => {
  const { el, api, toast, errore, conferma, pannello, modale, formatta, scarica } = GAD;
  const S = GAD.schede;
  const ambitoDM = location.pathname === "/preventivi-dm";
  const { f, campo, sezione } = S;
  const schedaIniziale = new Map();  // dati della testata all'apertura: per sapere se ci sono modifiche non salvate
  await S.me();
  const [valori, commerciali, pagamenti, termini] = await Promise.all([
    api("GET", "/api/preventivi/valori"), api("GET", "/api/commerciali").catch(() => []), api("GET", "/api/elenchi/modalita_pagamento").catch(() => []),
    api("GET", "/api/elenchi/termine_esecuzione").catch(() => []),
  ]);
  const filtro = (testo, valore) => el("button", { class: "btn small", type: "button", onclick: () => { g.tabella.clearHeaderFilter(); if (valore) g.filtra("stato", valore); } }, testo);
  const g = await GAD.griglia(document.getElementById("griglia"), ambitoDM ? "preventivi_dm" : "preventivi", {
    suRiga: (r) => apri(r.id),
    pulsanti: [filtro("Creati", "Creato"), filtro("Inviati senza ordine", "Inviato"), filtro("Accettati parzialmente", "Accettato parzialmente"),
      filtro("Accettati totalmente", "Accettato totalmente"), filtro("Tutti", "")],
    azioni: {
      modifica: (r) => apri(r.id),
      elimina: S.puo("preventivi.elimina_bozza") ? (r) => S.eliminaDaRiga(`/api/preventivi/${r.id}`, `il preventivo ${r.etichetta}`, g) : null,
      collegamenti: ambitoDM ? [
        {testo:"Cliente → scheda", vai:r=>`/clienti?apri=${r.cliente_id}`},
        {testo:"Righe ← Preventivo", vai:r=>S.filtro("righe-preventivi-dm", "preventivo_id", r.id, `righe del preventivo ${r.etichetta}`)},
      ] : [
        { testo: "Cliente → scheda", vai: (r) => `/clienti?apri=${r.cliente_id}` },
        { testo: "Righe ← Preventivo", vai: (r) => S.filtro("righe-preventivi", "preventivo_id", r.id, `righe del preventivo ${r.etichetta}`) },
        ...(S.puo("verifiche.vedere_proprie") ? [{ testo: "Verifiche ← Preventivo", vai: (r) => S.filtro("verifiche", "preventivo_id", r.id, `verifiche del preventivo ${r.etichetta}`) }] : []),
        { testo: "Preventivi ← Cliente", vai: (r) => S.filtro("preventivi", "cliente_id", r.cliente_id, `preventivi di ${r.cliente_ragione_sociale}`) },
      ],
    },
  });

  const badge = (stato, testo) => el("span", { class: "badge " + ({ accettato_totalmente: "ok", accettata: "ok", accettato_parzialmente: "ok", inviato: "avviso",
    rifiutato: "errore", rifiutata: "errore", annullato: "grigio", annullata: "grigio", sostituito: "grigio" }[stato] || "grigio") }, testo);

  // ---------------------------------------------------------------- nuovo preventivo
  document.getElementById("nuovo")?.addEventListener("click", async () => {
    if (ambitoDM) return nuovoDM();
    // O5: dall'elenco «Preventivi ← Cliente» il cliente è già scelto (modificabile)
    let scelto = null;
    const idCliente = S.daFiltro("cliente_id");
    if (idCliente) { try { scelto = await api("GET", `/api/clienti/${idCliente}`); } catch (e) { scelto = null; } }
    const cli = S.ricerca({ cerca: (t) => api("GET", "/api/clienti/cerca?ambito=DPR&q=" + encodeURIComponent(t)),
      mostra: (c) => [c.ragione_sociale, [c.comune, c.partita_iva].filter(Boolean).join(" · ")], segnaposto: "Cerca il cliente AD_DPR…",
      scelto: scelto ? { id: scelto.id, ragione_sociale: scelto.ragione_sociale, comune: scelto.comune, partita_iva: scelto.partita_iva } : null });
    const ok = await modale("Nuovo preventivo", [el("p", { class: "subtle" }, "Il preventivo è intestato al cliente; poi aggiungi gli impianti di una o più sedi (D39). Si può partire anche dallo scadenziario con ⚡."),
      campo("Cliente", cli.el), el("p", { class: "subtle" }, "Compaiono solo i clienti AD_DPR. Se manca, aggiungi l'ambito AD_DPR nella scheda del cliente.")], [{ testo: "Annulla", valore: false }, { testo: "Crea", classe: "primary", valore: true }]);
    if (!ok) return;
    if (!cli.valore) return errore(new Error("Scegli il cliente."));
    try { const p = await api("POST", "/api/preventivi", { cliente_id: cli.valore.id }); g.ricarica(); apri(p.id, "Righe"); } catch (e) { errore(e); }
  });

  async function nuovoDM() {
    const sede=S.ricerca({cerca:t=>api("GET","/api/sedi/cerca?ambito=DM&q="+encodeURIComponent(t)),mostra:x=>[`${x.cliente} · ${x.denominazione}`,x.comune],segnaposto:"Cerca cliente o sede AD_DM…"});
    const serie=f.testo(String(new Date().getFullYear()));
    if (!await modale("Nuovo preventivo DM",[campo("Sede operativa",sede.el),el("p",{class:"subtle"},"Compaiono le sedi dei clienti AD_DM, prima quelle con attrezzature. Se manca, aggiungi l'ambito AD_DM nella scheda del cliente: vale per tutte le sue sedi."),campo("Serie",serie)], [{testo:"Annulla",valore:false},{testo:"Crea",valore:true,classe:"primary"}])) return;
    if(!sede.valore) return errore(new Error("Scegli la sede operativa."));
    try {const p=await api("POST","/api/preventivi",{ambito:"DM",sede_id:sede.valore.id,serie:serie.value});await g.ricarica();await apri(p.id,"Righe");} catch(e){errore(e);}
  }
  async function aggiungiAttrezzature(p) {
    const q=f.testo(""),tbody=el("tbody"),campi=new Map(),info=el("p",{class:"subtle"});
    async function cerca() {
      const d=await api("GET",`/api/beni?sede_id=${p.sede_id}&solo_attivi=true&per_pagina=500&q=${encodeURIComponent(q.value)}`);
      campi.clear();
      tbody.replaceChildren(...d.righe.filter(a=>["GVR","SC","SP"].includes(a.gruppo)).map(a=>{
        const check=el("input",{type:"checkbox"}),tipo=f.scelta(Object.entries(valori.tipi_dm).map(([k,v])=>({valore:k,testo:v})),
          // C13 (0.16): la PVP va alla prima riga dell'attrezzatura nel preventivo; le altre sono successive
          a.tipo_prox_verifica==="V1" && (p.righe||[]).some(r=>r.asset_id===a.id && r.tipo_verifica_dm==="V1") ? "V2" : (a.tipo_prox_verifica||""),{vuota:"Scegli"}),gvr=a.gruppo==="GVR" ? f.scelta(Object.entries(valori.tipi_gvr).map(([k,v])=>({valore:k,testo:v})),"",{vuota:"Scegli attività"}) : null;
        campi.set(a.id,{check,tipo,gvr});
        return el("tr",{},el("td",{},check),el("td",{},a.gruppo),el("td",{},a.matricola),el("td",{},a.denominazione),el("td",{},tipo),el("td",{},gvr));
      }));
      info.textContent=d.totale>500 ? "Affina la ricerca: prime 500 schede." : "Attrezzature attive della sede del preventivo.";
    }
    await cerca();
    if(!await modale("Aggiungi attrezzature",[campo("Ricerca",q),S.azione("Cerca","",cerca),info,el("div",{class:"tabella-scorrevole"},el("table",{class:"tabella-semplice"},tbody))],[{testo:"Annulla",valore:false},{testo:"Aggiungi",valore:true,classe:"primary"}]))return;
    const attrezzature=[...campi].filter(([,x])=>x.check.checked).map(([id,x])=>({asset_id:id,tipo_verifica_dm:x.tipo.value,tipo_verifica_gvr:x.gvr?.value||""}));
    if(!attrezzature.length)return;
    try {await api("POST",`/api/dm/preventivi/${p.id}/attrezzature`,{versione:p.versione,attrezzature});await g.ricarica();await apri(p.id,"Righe");}catch(e){errore(e);}
  }

  // ---------------------------------------------------------------- scheda
  async function apri(id, linguettaIniziale) {
    let p;
    try { p = await api("GET", `/api/preventivi/${id}`); } catch (e) { return errore(e); }
    const mod = p.modificabile && S.puo("preventivi.modifica");
    const puoScontare = mod && (p.ambito === "DM" || p.cliente_sconti_ammessi) && S.puo("preventivi.sconti_applica");
    const ricarica = (msg) => { if (msg) toast(msg); g.ricarica(); apri(p.id, linguettaAperta); };
    const datiInvariati = () => schedaIniziale.get(p.id) === JSON.stringify(datiTestata());
    let linguettaAperta = linguettaIniziale || "Preventivo";

    // testata
    const m = {
      data: f.data(p.data), rif_ordine: f.testo(p.rif_ordine, { maxlength: "120" }), data_ordine: f.data(p.data_ordine),
      modalita_pagamento: f.testo(p.modalita_pagamento, { maxlength: "200", list: "elenco-pagamenti" }),
      termine_esecuzione: f.testo(p.termine_esecuzione, { maxlength: "300", list: "elenco-termini" }), note: f.area(p.note, { maxlength: "4000" }),
      commerciale_id: f.scelta(commerciali.filter((c) => c.attivo || c.id === p.commerciale_id).map((c) => ({ valore: c.id, testo: c.nome })), p.commerciale_id, { vuota: "—" }),
    };
    // 0.12.9: termini di esecuzione proposti (Gestione › Configurazione › Termini di esecuzione), testo sempre modificabile
    const elencoTermini = el("datalist", { id: "elenco-termini" }, ...termini.filter((x) => x.attivo).map((x) => el("option", { value: x.descrizione })));
    const elencoPagamenti = el("datalist", { id: "elenco-pagamenti" }, ...pagamenti.filter((x) => x.attivo).map((x) => el("option", { value: x.descrizione })));
    if (!mod) for (const k of ["data", "modalita_pagamento", "termine_esecuzione", "commerciale_id"]) m[k].disabled = true;
    const testata = el("div", {},
      el("div", { class: "riquadro" }, el("div", { class: "numeri" },
        el("span", {}, "Stato: ", badge(p.stato, p.stato_testo)),
        el("span", {}, "Totale: ", el("strong", {}, formatta.importo(p.totale))),
        p.totale !== p.totale_standard ? el("span", {}, "standard ", formatta.importo(p.totale_standard)) : null,
        p.inviato_il ? el("span", {}, "inviato il ", formatta.dataora(p.inviato_il)) : null,
        p.riesame ? el("span", {}, "Riesame: ", badge(p.riesame.esito === "conforme" ? "accettata" : "rifiutata", p.riesame.esito_testo)) : null)),
      ...p.avvisi.map((a) => el("div", { class: "notice" }, a)),
      p.stato === "annullato" ? el("div", { class: "notice errore" }, "Annullato: " + p.motivo_annullamento) : null,
      p.stato === "sostituito" ? el("div", { class: "notice" }, "Questa revisione è stata sostituita: resta com'era (D16). Vedi «Revisioni».") : null,
      p.stato === "inviato" && S.puo("preventivi.revisione") ? el("p", { class: "subtle" }, "Già inviato: per cambiare righe o prezzi usa «Crea revisione».") : null,
      el("div", { class: "field-grid" },
        campo("Cliente", el("div", { class: "scelto" }, el("a", { class: "nome", href: `/clienti?apri=${p.cliente_id}` }, p.cliente)), { pieno: true }),
        p.sede_id ? campo("Sede operativa", el("a", {href:`/sedi?apri=${p.sede_id}`},p.sede),{pieno:true}) : null,
        campo("Data", m.data), campo("Commerciale AD", m.commerciale_id),
        campo("Modalità di pagamento", el("div", {}, m.modalita_pagamento, elencoPagamenti), { pieno: true, aiuto: "Proposta dal cliente; si può cambiare qui." }),
        campo("Termine di esecuzione", el("div", {}, m.termine_esecuzione, elencoTermini), { pieno: true, aiuto: "Scegli una proposta o scrivi un testo libero." }),
        sezione("Ordine del cliente (D36)"), campo("Riferimento ordine", m.rif_ordine), campo("Data ordine", m.data_ordine),
        campo("Note interne", m.note, { pieno: true })));

    if (p.ambito === "DM") {
      m.lic_gest = f.scelta([{valore:"no",testo:"No"},{valore:"si",testo:"Sì"}],p.lic_gest ? "si":"no");
      m.prezzo_licenza = f.numero((p.prezzo_licenza/100).toFixed(2).replace(".",","));
      m.lic_gest.disabled=m.prezzo_licenza.disabled=!mod;
      testata.append(el("div",{class:"field-grid"},campo("Licenza gestionale (12 mesi)",m.lic_gest),campo("Prezzo licenza, euro",m.prezzo_licenza)));
    }
    // righe
    const scelte = new Set();
    const caselle = [];
    // N4 (0.12.8): la casella seleziona la riga su cui agire; lo stato è nella colonna «Stato della riga»
    const tutte = el("input", { type: "checkbox", title: "Seleziona tutte", onchange: (ev) => caselle.forEach(([id, c]) => {
      c.checked = ev.target.checked; if (c.checked) scelte.add(id); else scelte.delete(id); }) });
    const campiRiga = {};
    const celleLavoro = {};  // 0.12.9: verifica o incarico nato dalla riga, con l'icona «Affida» (come in Garda)
    const tbody = el("tbody", {}, ...p.righe.map((r) => {
      const sel = el("input", { type: "checkbox", title: "Seleziona la riga", onchange: (ev) => (ev.target.checked ? scelte.add(r.id) : scelte.delete(r.id)) });
      caselle.push([r.id, sel]);
      const tipo = f.scelta(Object.entries(r.asset_id ? valori.tipi_dm : valori.tipi_verifica).map(([k, v]) => ({ valore: k, testo: v })), r.asset_id ? r.tipo_verifica_dm : r.tipo_verifica);
      const sconto = f.numero(r.sconto || "", { placeholder: "0", class: "stretto" });
      tipo.disabled = !mod; sconto.disabled = !puoScontare;
      // 0.4.0: calcolo della riga — automatico dall'impianto, voce a ore, voce a scelta, importo a corpo
      const voce = p.voci_manuali.find((v) => v.id === r.voce_id);
      const cr = { tipo, sconto };
      if (r.asset_id && r.tipologia === "GVR") {cr.gvr = f.scelta(Object.entries(valori.tipi_gvr).map(([k,v])=>({valore:k,testo:v})),r.tipo_verifica_gvr);cr.gvr.disabled=!mod;}
      if (r.impianto_id && mod) {
        cr.voce = f.scelta([{ valore: "", testo: "Tariffario (automatico)" },
          ...p.voci_manuali.filter((v) => v.grandezza === "ore").map((v) => ({ valore: v.id, testo: `A ore: ${v.nome}` }))], r.voce_id || "");
      }
      if (voce && voce.grandezza === "ore") cr.quantita = f.numero(r.quantita ?? "", { placeholder: "ore", class: "stretto" });
      if (voce && voce.grandezza === "scelta") cr.quantita = f.scelta(voce.opzioni, r.quantita ?? "", { vuota: "—" });
      if (r.a_corpo) { cr.descrizione = f.testo(r.sede_nome, { maxlength: "300" }); cr.importo = f.numero((r.tariffa_standard / 100).toFixed(2).replace(".", ","), { class: "stretto" }); }
      for (const k of ["voce", "quantita", "descrizione", "importo"]) if (cr[k] && !mod) cr[k].disabled = true;
      campiRiga[r.id] = cr;
      const aOre = cr.quantita && voce && voce.grandezza === "ore" ? el("div", { class: "ore" }, cr.quantita, " ore") : null;
      return el("tr", {},
        el("td", {}, sel), el("td", {}, String(r.ordine)),
        el("td", {}, r.asset_id ? el("a",{href:`/attrezzature?scheda=${r.asset_id}`},`n. ${r.asset_id}`) : r.impianto_id ? el("a", { href: `/impianti?apri=${r.impianto_id}` }, `n. ${r.impianto_id}`) : "—"),
        el("td", {}, r.a_corpo ? cr.descrizione : el("div", {}, r.sede_nome),
          (r.impianto_id || r.asset_id) ? el("div", { class: "subtle" }, [r.sede_indirizzo, r.sede_comune].filter(Boolean).join(" · ")) : null),
        el("td", {}, r.impianto_id ? el("div", {}, r.tipologia) : null,
          cr.voce || (r.impianto_id && voce ? el("div", { class: "subtle" }, `A ore: ${voce.nome}`) : null),
          voce && voce.grandezza === "scelta" ? cr.quantita : el("div", { class: "subtle" }, r.descrizione), aOre,
          ...r.avvisi_tariffa.map((a) => el("div", { class: "subtle avviso" }, "⚠ " + a))),
        el("td", {}, tipo, cr.gvr || null,
          // N9 (0.12.8): colonna del tariffario usata (GVR V1/V2 prima periodica secondo la messa in servizio, V3/V4 successive)
          r.asset_id && r.dettaglio.length && r.dettaglio[0].colonna ? el("div", { class: "subtle" }, `Tariffa: colonna ${r.dettaglio[0].colonna}`) : null),
        el("td", { class: "num", title: r.dettaglio.map((d) => `${d.voce}: ${formatta.importo(d.importo)} (${d.spiegazione})`).join("\n") + (r.problemi_tariffa.length ? "\n⚠ " + r.problemi_tariffa.join("\n⚠ ") : "") },
          r.a_corpo ? cr.importo : formatta.importo(r.tariffa_standard),
          r.problemi_tariffa.length ? el("div", { class: "subtle" }, "⚠ " + r.problemi_tariffa.join("; ")) : null),
        el("td", { class: "num" }, sconto),
        el("td", { class: "num" }, el("strong", {}, formatta.importo(r.tariffa_applicata))),
        el("td", {}, badge(r.stato, r.stato_testo)),
        celleLavoro[r.id] = el("td", { class: "lavoro-riga" }, r.stato === "accettata" ? el("span", { class: "subtle" }, "…") : "—"));
    }));
    const tabellaRighe = p.righe.length ? el("table", { class: "tabella-semplice righe-preventivo" },
      el("thead", {}, el("tr", {}, el("th", { title: "Seleziona le righe su cui agire (non è lo stato della riga)" }, tutte, " Sel."),
        ...["N.", p.ambito === "DM" ? "Attrezzatura" : "Impianto", "Sede", "Tipologia", "Verifica", "Standard", "Sconto %", "Applicata", "Stato della riga", p.ambito === "DM" ? "Incarico" : "Verifica affidata"].map((t, i) => el("th", { class: i >= 5 && i <= 7 ? "num" : "" }, t)))),
      tbody, el("tfoot", {}, el("tr", {}, el("td", { colspan: "8" }, "Totale (righe non rifiutate né annullate)"), el("td", { class: "num" }, el("strong", {}, formatta.importo(p.totale))), el("td", {}), el("td", {}))))
      : el("p", { class: "subtle" }, "Nessuna riga: aggiungi gli impianti del cliente.");
    const azioniRighe = el("div", { class: "actions" });
    const statoSelezionate = (stato, testo) => S.azione(testo, "small", async () => {
      if (!scelte.size) throw new Error("Seleziona le righe con la casella a sinistra.");
      let evidenza_accettazione = p.evidenza_accettazione || "";
      if (stato === "accettata") {
        const evidenza = f.area(evidenza_accettazione, {placeholder: "Riferimento al preventivo controfirmato oppure all'email di conferma, con data/collocazione"});
        if (!await GAD.modale("Evidenza dell'accettazione", [
          (p.allegati || []).some((a) => !a.rimosso) ? el("p", { class: "notice ok" }, "C'è già il file dell'accettazione o dell'ordine: il testo è facoltativo.")
            : el("p", { class: "notice avviso" }, "Manca il file: è consigliato caricarlo nella linguetta «Accettazione e ordine». Se non c'è (es. accettato per telefono), scrivi qui il riferimento."),
          campo("Conferma scritta", evidenza)], [{testo:"Annulla",valore:false},{testo:"Registra",valore:true,classe:"primary"}])) return;
        evidenza_accettazione = evidenza.value;
      }
      await api("POST", `/api/preventivi/${p.id}/righe/stato`, { righe: [...scelte], stato, versione: p.versione, evidenza_accettazione });
      ricarica("Stato delle righe aggiornato.");
    });
    if (S.puo("preventivi.accettazione") && !["annullato", "sostituito"].includes(p.stato) && p.righe.length) {
      azioniRighe.append(statoSelezionate("accettata", "✓ Accetta"), statoSelezionate("rifiutata", "✕ Rifiuta"),
        statoSelezionate("annullata", "Annulla riga"), statoSelezionate("in_attesa", "Rimetti in attesa"),
        // R124 (0.12.8): l'accettazione si toglie solo con una revoca motivata
        S.azione("Revoca accettazione…", "small danger", async () => {
          if (!scelte.size) throw new Error("Seleziona le righe accettate da revocare.");
          const motivo = f.area("", { maxlength: "2000", placeholder: "Perché si revoca l'accettazione (es. il cliente ha ritirato l'ordine per questa attrezzatura)" });
          if (!await GAD.modale("Revocare l'accettazione?", [el("p", {}, "La riga torna «in attesa». Se la sua verifica (o l'incarico DM) è ancora «da assegnare» viene annullata con lo stesso motivo; se è già affidata, prima va annullata la verifica. Se poi la riga si riaccetta, serve un nuovo riesame del contratto."),
            campo("Motivo (obbligatorio)", motivo)], [{ testo: "Annulla", valore: false }, { testo: "Revoca", classe: "danger", valore: true }])) return;
          await api("POST", `/api/preventivi/${p.id}/righe/revoca`, { righe: [...scelte], motivo: motivo.value, versione: p.versione });
          ricarica("Accettazione revocata.");
        }));
    }
    // 0.12.9 (Federico, 12/10/2026, come Garda «Preventivi righe»): affidamento dalla scheda, su una o più righe
    const lavori = {};
    const dm = p.ambito === "DM";
    const puoAffidare = S.puo("verifiche.assegna", p.ambito);
    const affida = async (ids) => {
      const righeScelte = ids.map((id) => ({ ...(lavori[id] || {}), ordine: p.righe.find((r) => r.id === id)?.ordine, preventivo_etichetta: p.etichetta }));
      if (await S.affidaRighe(righeScelte, dm)) ricarica();
    };
    if (puoAffidare && p.righe.some((r) => r.stato === "accettata")) {
      azioniRighe.append(S.azione("👤 Affida le selezionate…", "small primary", () => affida([...scelte])));
    }
    (async () => {
      if (!p.righe.some((r) => r.stato === "accettata")) return;
      const x = await api("POST", `/api/griglie/${dm ? "righe_preventivi_dm" : "righe_preventivi"}/dati`,
        { contesto: {preventivo_id: p.id}, filtri: [], dimensione: 500 });
      for (const r of x.righe) lavori[r.id] = r;
      for (const r of p.righe) {
        const c = celleLavoro[r.id], w = lavori[r.id];
        if (!c || r.stato !== "accettata") continue;
        if (!w || !w.verifica_id) { c.replaceChildren(el("span", { class: "subtle", title: "Nasce dopo il riesame del contratto conforme" }, "dopo il riesame")); continue; }
        const aperta = !/^(Effettuata|Eseguita|Riesaminata|Annullata)/i.test(w.verifica_stato || "");
        c.replaceChildren(...[el("div", {}, w.verifica_stato || ""), el("div", { class: "subtle" }, w.verificatore || "nessun verificatore"),
          puoAffidare && aperta ? el("button", { class: "btn small", type: "button", title: "Affida a un verificatore (con più righe spuntate: a tutte)",
            onclick: () => affida(scelte.size && scelte.has(r.id) ? [...scelte] : [r.id]).catch(errore) }, "👤 Affida") : null].filter(Boolean));
      }
    })().catch(errore);
    if (mod) {
      azioniRighe.append(el("span", { class: "spazio" }),
        S.azione(p.ambito === "DM" ? "＋ Aggiungi attrezzature" : "＋ Aggiungi impianti", "small primary", () => p.ambito === "DM" ? aggiungiAttrezzature(p) : aggiungiImpianti(p)),
        p.ambito === "DPR" ? S.azione("＋ Voce / a corpo", "small", () => aggiungiVoce(p)) : null,
        S.azione("Togli selezionate", "small danger", async () => {
          if (!scelte.size) throw new Error("Seleziona le righe da togliere.");
          await salva({ righe_da_togliere: [...scelte] }); ricarica("Righe tolte.");
        }),
        S.azione("Ricalcola tariffe", "small", async () => { await api("POST", `/api/preventivi/${p.id}/ricalcola`, { versione: p.versione }); ricarica("Tariffe ricalcolate dal tariffario e dagli impianti."); }));
    }
    const elenco = g.tabella.getData().map((x) => x.id), qui = elenco.indexOf(p.id);
    const naviga = el("div", { class: "actions naviga-preventivi" },
      el("button", { class: "btn small", type: "button", disabled: qui <= 0, onclick: () => apri(elenco[qui - 1], linguettaAperta) }, "‹ Prec. preventivo"),
      el("button", { class: "btn small", type: "button", disabled: qui < 0 || qui >= elenco.length - 1, onclick: () => apri(elenco[qui + 1], linguettaAperta) }, "Succ. preventivo ›"),
      el("span", { class: "subtle" }, qui >= 0 ? `${qui + 1} di ${elenco.length} nell'elenco` : ""));
    const righe = el("div", {}, naviga, azioniRighe,
      p.ambito === "DPR" && !p.cliente_sconti_ammessi && mod ? el("p", { class: "subtle" }, "Sconti bloccati per questo cliente (D38).") : null,
      el("div", { class: "tabella-larga" }, tabellaRighe));

    // riesame
    const riesame = el("div");
    // R138 (0.16): file dell'accettazione o dell'ordine, visibili anche qui per chi fa il riesame del contratto
    const allegatiAttivi = (p.allegati || []).filter((a) => !a.rimosso);
    const linkAllegato = (a) => el("button", { class: "btn small", type: "button", onclick: () => scarica("GET", `/api/preventivi/${p.id}/allegati/${a.id}/file`, undefined, a.nome_file).catch(errore) }, `${a.tipo_testo}: ${a.nome_file}`);
    riesame.append(el("div", { class: "riquadro" }, el("strong", {}, "Evidenza dell'accettazione"),
      allegatiAttivi.length ? el("div", { class: "actions" }, ...allegatiAttivi.map(linkAllegato)) : el("p", { class: "subtle" }, "Nessun file caricato (linguetta «Accettazione e ordine»)."),
      p.evidenza_accettazione ? el("p", {}, p.evidenza_accettazione) : null));
    if (p.riesame) {
      const x = p.riesame;
      riesame.append(el("div", { class: "riquadro" }, el("strong", {}, `Ultimo riesame: ${x.esito_testo}`), ` — ${formatta.dataora(x.eseguito_il)}, ${x.eseguito_da}`,
        el("div", {}, ["requisiti_chiari", "competenza_strumenti", "imparzialita", "tempi"].map((k) => `${x[k] ? "✓" : "✕"} ${k.replace("_", " ")}`).join(" · ")),
        x.note ? el("div", {}, x.note) : null));
    }
    if ((p.riesami || []).length > 1) {  // R109: storico dei riesami (autore, data, esito, note)
      riesame.append(el("h3", {}, `Storico dei riesami (${p.riesami.length})`),
        ...p.riesami.map((r) => el("p", {}, `${formatta.dataora(r.eseguito_il)} · ${r.eseguito_da} · ${r.esito_testo}${r.note ? " · " + r.note : ""}`)));
    }
    if ((p.revoche || []).length) {  // R124
      riesame.append(el("h3", {}, `Revoche dell'accettazione (${p.revoche.length})`),
        ...p.revoche.map((x) => el("p", {}, `${formatta.dataora(x.revocata_il)} · ${x.revocata_da} · riga ${x.riga}: ${x.motivo}`
          + (x.verifica_id ? ` (annullata la verifica n. ${x.verifica_id})` : x.incarico_dm_id ? ` (annullato l'incarico DM n. ${x.incarico_dm_id})` : ""))));
    }
    if (["accettato_parzialmente", "accettato_totalmente"].includes(p.stato) && S.puo("preventivi.riesame", p.ambito) && !p.riesame_necessario) {
      riesame.append(el("p", { class: "subtle" }, "Il riesame conforme è registrato e da allora non è cambiato nulla: non serve ripeterlo. Torna necessario se si riaccetta una riga revocata."));
    }
    if (["accettato_parzialmente", "accettato_totalmente"].includes(p.stato) && S.puo("preventivi.riesame", p.ambito) && p.riesame_necessario) {
      const esito = f.scelta(Object.entries(valori.esiti_riesame).map(([k, v]) => ({ valore: k, testo: v })), "conforme");
      const punti = [["requisiti_chiari", "Requisiti del cliente chiari e documentati (impianti, tipo di verifica, sedi)"],
        ["competenza_strumenti", "Competenza degli ispettori e strumenti disponibili"], ["imparzialita", "Nessun rischio per l'imparzialità"],
        ["tempi", "Tempi di esecuzione sostenibili"]].map(([k, t]) => [k, f.casella(t, false)]);
      const tutti = f.casella("Seleziona tutti i requisiti", false);
      const aggiornaTutti = () => {
        const n = punti.filter(([, c]) => c.valore).length;
        tutti.input.checked = n === punti.length;
        tutti.input.indeterminate = n > 0 && n < punti.length;
      };
      tutti.input.addEventListener("change", () => {
        for (const [, c] of punti) c.input.checked = tutti.valore;
        aggiornaTutti();
      });
      for (const [, c] of punti) c.input.addEventListener("change", aggiornaTutti);
      const note = f.area("", { maxlength: "4000", placeholder: "Se non conforme: motivo e azione decisa" });
      riesame.append(el("h3", {}, "Nuovo riesame del contratto (ISO/IEC 17020, D17)"), tutti.el, ...punti.map(([, c]) => el("div", {}, c.el)),
        el("div", { class: "field-grid" }, campo("Esito", esito), campo("Note", note, { pieno: true })),
        el("div", { class: "actions" }, S.azione("Registra il riesame", "primary", async () => {
          await api("POST", `/api/preventivi/${p.id}/riesame`, { esito: esito.value, note: note.value, ...Object.fromEntries(punti.map(([k, c]) => [k, c.valore])) });
          ricarica(esito.value === "conforme" ? "Riesame registrato: le righe accettate sono diventate verifiche «da assegnare»." : "Riesame registrato.");
        })));
    } else if (!p.riesame) riesame.append(el("p", { class: "subtle" }, "Il riesame del contratto si fa dopo l'accettazione (anche parziale) del preventivo."));
    if (p.verifiche.length) {
      riesame.append(el("h3", {}, `Verifiche (${p.verifiche.length})`), el("p", { class: "subtle" }, "Nate dalle righe accettate dopo il riesame conforme (D61)."),
        S.tabella([{ titolo: "Verifica", valore: (v) => v.codice_verbale || `n. ${v.id}` }, { titolo: p.ambito === "DM" ? "Attrezzatura" : "Impianto", valore: (v) => `n. ${v.asset_id || v.impianto_id}` },
          { titolo: "Stato", valore: (v) => v.stato_testo }], p.verifiche, (v) => (location.href = `${p.ambito === "DM" ? "/incarichi-dm" : "/verifiche"}?apri=${v.id}`)));
    }

    // documenti e invii (0.7.0, D80: come i verbali — anteprima archiviata, ritocchi solo di impaginazione, invio del PDF approvato)
    const att = p.documento_attuale;
    const documenti = el("div", {},
      p.stato === "creato" && p.righe.length ? el("div", { class: "riquadro" },
        el("strong", {}, "Documento da inviare"),
        el("p", {}, att ? (att.approvato ? `Approvato da ${att.approvato_da} il ${formatta.dataora(att.approvato_il)}: è il PDF che si invia.`
          : "Preparato con i dati attuali ma non ancora approvato: apri «Controlla il documento» e approvalo.")
          : "Non ancora preparato con i dati attuali: apri «Controlla il documento»."),
        el("p", { class: "subtle" }, "Si invia solo il PDF controllato e approvato. Ritocchi di impaginazione: nella finestra del documento «Scarica il Word», " +
          "sistemalo in Word (solo margini, spazi, interruzioni di pagina) e «Carica il Word ritoccato»: il programma controlla che testo e importi " +
          "siano identici e rifà il PDF. Prezzi e righe si cambiano nel gestionale. Dopo l'invio il documento non cambia più (serve una revisione)."),
        el("div", { class: "actions" }, S.azione("👁 Controlla il documento", "primary", () => controlla(p)))) : null,
      p.stato !== "creato" && p.righe.length ? el("div", { class: "actions" }, S.azione("👁 Documento inviato", "", () => controlla(p))) : null,
      !valori.pdf_disponibile ? el("p", { class: "notice errore" }, "LibreOffice non trovato su questo PC: serve per preparare il PDF del preventivo.") : null,
      el("h3", {}, "Documenti"),
      S.tabella([{ titolo: "File", valore: (d) => el("span", {}, d.nome_file, d.ritoccato ? el("span", { class: "badge avviso" }, " ritoccato") : "",
          d.attuale ? el("span", { class: "badge" }, " attuale") : "") },
        { titolo: "Formato", valore: (d) => d.formato.toUpperCase() },
        { titolo: "Preparato", valore: (d) => `${formatta.dataora(d.creato_il)} · ${d.creato_da}` },
        { titolo: "Approvato", valore: (d) => d.approvato_il ? `${formatta.dataora(d.approvato_il)} · ${d.approvato_da}` : "" },
        { titolo: "", valore: (d) => el("button", { class: "btn small", type: "button", onclick: (ev) => { ev.stopPropagation(); scarica("GET", `/api/preventivi/${p.id}/documenti/${d.documento_id}`, undefined, d.nome_file).catch(errore); } }, "Scarica") }], p.documenti),
      el("h3", {}, "Invii email"),
      S.tabella([{ titolo: "Quando", valore: (i) => `${formatta.dataora(i.inviato_il)} · ${i.inviato_da}` }, { titolo: "A", valore: (i) => i.destinatari + (i.copia ? ` (cc ${i.copia})` : "") },
        { titolo: "Oggetto", valore: (i) => i.oggetto }, { titolo: "Esito", valore: (i) => i.esito }], p.invii));

    // R138 (0.16): linguetta «Accettazione e ordine» come la linguetta «Fattura» di Garda, più i file del cliente
    const accettazione = el("div");
    const puoAcc = S.puo("preventivi.accettazione") && !["annullato", "sostituito"].includes(p.stato);
    accettazione.append(...(p.avvisi_accettazione || []).map((a) => el("div", { class: "notice avviso" }, a)));
    accettazione.append(el("h3", {}, "File dell'accettazione o dell'ordine"),
      el("p", { class: "subtle" }, "Preventivo controfirmato, ordine del cliente, email salvata in PDF: restano in archivio con la loro impronta. Valgono come evidenza dell'accettazione."),
      (p.allegati || []).length ? S.tabella([
        { titolo: "Tipo", valore: (a) => a.tipo_testo }, { titolo: "File", valore: (a) => a.rimosso ? el("s", {}, a.nome_file) : linkAllegato(a) },
        { titolo: "Descrizione", valore: (a) => a.descrizione }, { titolo: "Caricato", valore: (a) => `${formatta.dataora(a.creato_il)} · ${a.creato_da}` },
        { titolo: "", valore: (a) => a.rimosso ? `tolto il ${formatta.dataora(a.rimosso_il)} · ${a.rimosso_da}` : puoAcc ? el("button", { class: "btn small", type: "button", onclick: async () => {
          if (!(await conferma("Togliere il file?", "Il file resta in archivio e nello storico, ma non vale più come evidenza."))) return;
          try { await api("POST", `/api/preventivi/${p.id}/allegati/${a.id}/togli`, {}); ricarica("File tolto."); } catch (e) { errore(e); } } }, "Togli") : "" },
      ], p.allegati) : el("p", { class: "subtle" }, "Nessun file."));
    if (puoAcc) {
      const file = el("input", { type: "file", accept: ".pdf,.png,.jpg,.jpeg,.eml,.msg" });
      const tipoAll = f.scelta(Object.entries(valori.tipi_allegato || {}).map(([k, v]) => ({ valore: k, testo: v })), "accettazione");
      const descr = f.testo("", { maxlength: "300", placeholder: "es. ordine n. 4500 del 02/09/2026" });
      accettazione.append(el("div", { class: "field-grid" }, campo("Tipo", tipoAll), campo("File (PDF, immagine, email)", file), campo("Descrizione", descr, { pieno: true })),
        el("div", { class: "actions" }, S.azione("⬆ Carica il file", "", async () => {
          if (!file.files[0]) throw new Error("Scegli il file.");
          const fd = new FormData(); fd.append("file", file.files[0]); fd.append("tipo", tipoAll.value); fd.append("descrizione", descr.value);
          await api("POST", `/api/preventivi/${p.id}/allegati`, fd); ricarica("File caricato.");
        })));
    }
    const nomiDoc = valori.tipi_documento || {};
    const righeDoc = [];
    const boxDoc = el("div");
    const aggDoc = (d = {}) => {
      const v = { tipo: f.scelta(Object.entries(nomiDoc).map(([k, t]) => ({ valore: k, testo: t })), d.tipo || "OrdineAcquisto"),
        numero: f.testo(d.numero || "", { maxlength: "20" }), data: f.data(d.data || ""), cig: f.testo(d.cig || "", { maxlength: "15" }),
        cup: f.testo(d.cup || "", { maxlength: "15" }), commessa: f.testo(d.commessa || "", { maxlength: "100" }), attivo: true };
      if (!puoAcc) for (const k of ["tipo", "numero", "data", "cig", "cup", "commessa"]) v[k].disabled = true;
      const riga = el("div", { class: "riquadro field-grid" }, campo("Tipo doc.", v.tipo), campo("N°", v.numero, { aiuto: "Obbligatorio perché esca in fattura" }),
        campo("Data", v.data, { aiuto: "Obbligatoria perché esca in fattura" }), campo("CIG", v.cig), campo("CUP", v.cup), campo("Commessa / Convenzione", v.commessa),
        puoAcc ? el("div", { class: "field" }, el("button", { class: "btn small", type: "button", onclick: () => { v.attivo = false; riga.remove(); } }, "Togli")) : null);
      righeDoc.push(v); boxDoc.append(riga);
    };
    (p.documenti_collegati || []).forEach(aggDoc);
    accettazione.append(el("h3", { class: "sezione-titolo" }, "Dati per la fattura elettronica"),
      el("p", { class: "subtle" }, "Come la linguetta «Fattura» di Garda: passano da soli nella fattura che nasce da questo preventivo. Se sono gli stessi per tutte le righe, in fattura compaiono una volta sola."),
      boxDoc, ...(!(p.documenti_collegati || []).length && !puoAcc ? [el("p", { class: "subtle" }, "Nessun documento.")] : []));
    if (puoAcc) accettazione.append(el("div", { class: "actions" },
      el("button", { class: "btn small", type: "button", onclick: () => aggDoc() }, "＋ Aggiungi documento"),
      S.azione("Salva i dati per la fattura", "primary", async () => {
        const documenti = righeDoc.filter((v) => v.attivo).map((v) => ({ tipo: v.tipo.value, numero: v.numero.value, data: v.data.value, cig: v.cig.value, cup: v.cup.value, commessa: v.commessa.value }));
        await api("PUT", `/api/preventivi/${p.id}/documenti-collegati`, { documenti, versione: p.versione }); ricarica("Dati per la fattura salvati.");
      })));
    const revisioni = S.tabella([{ titolo: "Preventivo", valore: (r) => r.etichetta }, { titolo: "Data", valore: (r) => formatta.data(r.data) }, { titolo: "Stato", valore: (r) => r.stato_testo }],
      p.revisioni, (r) => apri(r.id));
    const storico = el("div");
    const schede = [
      { titolo: "Preventivo", contenuto: testata }, { titolo: `Righe (${p.righe.length})`, contenuto: righe },
      { titolo: `Accettazione e ordine${(p.allegati || []).some((a) => !a.rimosso) ? " ✓" : ""}`, contenuto: accettazione },
      { titolo: "Riesame", contenuto: riesame }, { titolo: "Documenti e invii", contenuto: documenti },
      { titolo: `Revisioni (${p.revisioni.length})`, contenuto: revisioni },
      { titolo: "Storico", contenuto: storico, apri: async () => storico.replaceChildren(await S.storico("preventivo", p.id)) },
    ];
    for (const sc of schede) { const prima = sc.apri; sc.apri = async () => { linguettaAperta = sc.titolo.split(" (")[0]; if (prima) await prima(); }; }
    const corpo = el("div", {}, S.linguette(schede), S.traccia(p));
    // apre la linguetta richiesta
    setTimeout(() => { const b = [...corpo.querySelectorAll(".tabs button")].find((x) => x.textContent.startsWith(linguettaAperta)); if (b) b.click(); }, 0);

    function datiTestata() {
      return { data: m.data.value, rif_ordine: m.rif_ordine.value, data_ordine: m.data_ordine.value, modalita_pagamento: m.modalita_pagamento.value,
        termine_esecuzione: m.termine_esecuzione.value, note: m.note.value, commerciale_id: m.commerciale_id.value,
        ...(m.lic_gest ? {lic_gest:m.lic_gest.value==="si",prezzo_licenza:m.prezzo_licenza.value} : {}),
        righe: p.righe.map((r) => {
          const c = campiRiga[r.id];
          const x = { id: r.id, tipo_verifica: c.tipo.value, sconto: c.sconto.value || "0" };
          if (r.asset_id) {delete x.tipo_verifica;x.tipo_verifica_dm=c.tipo.value;if(c.gvr)x.tipo_verifica_gvr=c.gvr.value;}
          if (c.voce) x.voce_id = c.voce.value;
          if (c.quantita) x.quantita = c.quantita.value;
          if (c.descrizione) x.descrizione = c.descrizione.value;
          if (c.importo) x.importo = c.importo.value;
          return x;
        }) };
    }
    async function salva(extra = {}) { return api("PUT", `/api/preventivi/${p.id}`, { ...datiTestata(), ...extra, versione: p.versione }); }

    const pulsanti = [];
    if (p.stato === "creato" && !p.revisione && S.puo("preventivi.elimina_bozza")) {
      pulsanti.push(S.azione("Elimina", "danger", async () => {
        if (!(await conferma("Eliminare il preventivo?", `${p.etichetta} non è mai stato inviato: viene eliminato (resta nel registro). Il numero non viene riusato se ci sono numeri successivi.`, { pulsante: "Elimina", pericolo: true }))) return;
        await api("DELETE", `/api/preventivi/${p.id}`); pannello.chiudi(); g.ricarica(); toast("Preventivo eliminato.");
      }));
    }
    if (!["annullato", "sostituito"].includes(p.stato) && S.puo("preventivi.annulla")) {
      pulsanti.push(S.azione("Annulla…", "danger", async () => {
        const motivo = el("input", { maxlength: "500" });
        if (!(await modale("Annullare il preventivo?", [el("p", {}, "Il preventivo resta in archivio come «annullato»."), campo("Motivo", motivo)],
          [{ testo: "No", valore: false }, { testo: "Annulla il preventivo", classe: "danger", valore: true }]))) return;
        await api("POST", `/api/preventivi/${p.id}/annulla`, { motivo: motivo.value, versione: p.versione }); ricarica("Preventivo annullato.");
      }));
    }
    if (["inviato", "rifiutato"].includes(p.stato) && S.puo("preventivi.revisione")) {
      pulsanti.push(S.azione("Crea revisione", "", async () => {
        if (!(await conferma("Creare una revisione?", `Si crea ${p.codice} rev. ${p.revisione + 1} da modificare e reinviare; ${p.etichetta} resta com'era, «sostituito».`, { pulsante: "Crea revisione" }))) return;
        const n = await api("POST", `/api/preventivi/${p.id}/revisione`, { versione: p.versione }); g.ricarica(); apri(n.id, "Righe");
      }));
    }
    // O15: sconto chiesto dopo l'invio → revisione automatica con lo sconto (dopo l'accettazione il prezzo non si tocca)
    if (p.stato === "inviato" && (p.ambito === "DM" || p.cliente_sconti_ammessi) && S.puo("preventivi.revisione") && S.puo("preventivi.sconti_applica")) {
      pulsanti.push(S.azione("Sconto (con revisione)…", "", async () => {
        const campi = p.righe.filter((r) => r.stato !== "annullata").map((r) => {
          const i = el("input", { type: "text", inputmode: "decimal", value: String(r.sconto).replace(".", ","), class: "corto" });
          return { r, i, riga: campo(`${r.sede_nome || ""} – ${r.descrizione || r.tipologia || ""} (€ ${(r.tariffa_standard / 100).toFixed(2).replace(".", ",")})`, i) };
        });
        if (!(await modale("Sconto sul preventivo inviato", [
          el("p", {}, `Il prezzo inviato non cambia: si crea ${p.codice} rev. ${p.revisione + 1} con la data di oggi e lo sconto, da reinviare al cliente.`),
          ...campi.map((c) => c.riga)], [{ testo: "Annulla", valore: false }, { testo: "Crea la revisione con lo sconto", classe: "primary", valore: true }]))) return;
        const sconti = {};
        for (const c of campi) sconti[c.r.id] = c.i.value;
        const n = await api("POST", `/api/preventivi/${p.id}/sconto-revisione`, { versione: p.versione, sconti });
        g.ricarica(); apri(n.id, "Righe"); toast(`Creata ${n.etichetta} con lo sconto: ricordati di reinviarla.`);
      }));
    }
    if (p.stato === "creato" && S.puo("preventivi.invia") && p.righe.length) {
      const segna = async () => {
        const x = await api("GET", `/api/preventivi/${p.id}`);
        if (!(await conferma("Segnare come inviato?", `Usalo se l'hai inviato fuori dal programma (PEC, a mano…). Risulterà inviato il PDF approvato «${x.documento_attuale.nome_file}». Dopo, per modificarlo servirà una revisione.`, { pulsante: "Segna inviato" }))) return;
        await api("POST", `/api/preventivi/${p.id}/inviato`, { versione: x.versione }); ricarica("Segnato come inviato.");
      };
      pulsanti.push(S.azione("Segna come inviato", "", async () => {
        if (!datiInvariati() || !p.documento_attuale || !p.documento_attuale.approvato) {
          toast("Prima controlla e approva il documento: è quello che risulterà inviato.");
          return controlla(p, { salva: mod && !datiInvariati() ? salva : null, dopo: () => segna().catch(errore) });
        }
        await segna();
      }));
    }
    if (!["annullato", "sostituito"].includes(p.stato) && S.puo("preventivi.invia") && p.righe.length) {
      pulsanti.push(S.azione("✉ Invia email…", "", () => inviaEmail(p, mod ? salva : null, datiInvariati())));
    }
    if (p.righe.length) pulsanti.push(S.azione("👁 Anteprima", "", () => controlla(p, { salva: mod && !datiInvariati() ? salva : null })));
    if (p.righe.length) pulsanti.push(S.azione("🖨 Stampa", "", () => stampa(p, datiTestata, mod ? salva : null, () => apri(p.id, linguettaAperta))));
    pulsanti.push(el("span", { class: "spazio" }));
    if (S.puo("preventivi.modifica") && !["annullato", "sostituito"].includes(p.stato)) {
      pulsanti.push(S.azione("Salva", "primary", async () => { await salva(); ricarica("Preventivo salvato."); }));
    } else S.solaLettura(testata);
    pannello.apri(`Preventivo ${p.ambito} ${p.etichetta} · ${p.cliente}`, corpo, pulsanti, { largo: true });
    riaperture.set(p.id, () => apri(p.id, linguettaAperta));
    schedaIniziale.set(p.id, JSON.stringify(datiTestata()));
  }

  // ---------------------------------------------------------------- riga senza impianto (0.4.0)
  async function aggiungiVoce(p) {
    const scelta = f.scelta([...p.voci_manuali.map((v) => ({ valore: v.id, testo: `${v.codice} · ${v.nome}` })), { valore: "corpo", testo: "Importo a corpo (scritto a mano)" }], "", { vuota: "—" });
    const zona = el("div", { class: "field-grid" });
    let campi = {};
    const aggiorna = () => {
      const v = p.voci_manuali.find((x) => String(x.id) === scelta.value);
      campi = {};
      if (scelta.value === "corpo") { campi.descrizione = f.testo("", { maxlength: "300" }); campi.importo = f.numero("", { placeholder: "0,00" }); }
      else if (v && v.grandezza === "ore") campi.quantita = f.numero("", { placeholder: "ore" });
      else if (v && v.grandezza === "scelta") campi.quantita = f.scelta(v.opzioni, "", { vuota: "—" });
      zona.replaceChildren(
        campi.descrizione ? campo("Descrizione", campi.descrizione, { pieno: true }) : null,
        campi.importo ? campo("Importo (€)", campi.importo) : null,
        campi.quantita ? campo(v.grandezza === "ore" ? "Ore previste" : "Voce", campi.quantita, { pieno: v.grandezza === "scelta" }) : null);
    };
    scelta.addEventListener("change", aggiorna);
    const ok = await modale("Aggiungi una riga senza impianto", [
      el("p", { class: "subtle" }, "Trasferta, sopralluogo a vuoto, duplicato, strutture metalliche… oppure un importo a corpo."),
      campo("Voce del tariffario", scelta), zona], [{ testo: "Annulla", valore: false }, { testo: "Aggiungi", classe: "primary", valore: true }]);
    if (!ok || !scelta.value) return;
    const dati = { versione: p.versione };
    if (scelta.value === "corpo") { dati.descrizione = campi.descrizione.value; dati.importo = campi.importo.value; }
    else { dati.voce_id = scelta.value; if (campi.quantita) dati.quantita = campi.quantita.value; }
    try { await api("POST", `/api/preventivi/${p.id}/voci`, dati); toast("Riga aggiunta."); g.ricarica(); apri(p.id, "Righe"); } catch (e) { errore(e); }
  }

  // ---------------------------------------------------------------- aggiungere impianti del cliente
  async function aggiungiImpianti(p) {
    const elenco = await api("GET", `/api/clienti/${p.cliente_id}/impianti`);
    const presenti = new Set(p.righe.filter((r) => r.stato !== "annullata").map((r) => r.impianto_id));
    const scelte = new Set();
    const cerca = el("input", { placeholder: "Filtra per sede, comune, tipologia…" });
    const corpo = el("tbody");
    const disegna = () => {
      const t = cerca.value.trim().toLowerCase();
      corpo.replaceChildren(...elenco.filter((x) => !presenti.has(x.id) && !x.dismesso && (!t || `${x.sede} ${x.comune} ${x.tipologia} ${x.denominazione}`.toLowerCase().includes(t)))
        .map((x) => {
          const c = el("input", { type: "checkbox", onchange: (ev) => (ev.target.checked ? scelte.add(x.id) : scelte.delete(x.id)) });
          c.checked = scelte.has(x.id);
          return el("tr", {}, el("td", {}, c), el("td", {}, `n. ${x.id}`), el("td", {}, x.sede), el("td", {}, x.comune), el("td", {}, x.tipologia),
            el("td", { class: "num" }, formatta.numero(x.potenza_kw)), el("td", {}, formatta.data(x.prossima_verifica)));
        }));
    };
    cerca.addEventListener("input", disegna);
    disegna();
    const tipo = el("select", {}, ...Object.entries(valori.tipi_verifica).map(([k, v]) => el("option", { value: k }, v)));
    const ok = await modale("Aggiungi impianti del cliente", [el("p", { class: "subtle" }, "Impianti di tutte le sedi del cliente (D39); esclusi i dismessi e quelli già nel preventivo."),
      cerca, el("div", { class: "tabella-scorrevole" }, el("table", { class: "tabella-semplice" },
        el("thead", {}, el("tr", {}, ...["", "N.", "Sede", "Comune", "Tipologia", "kW", "Prossima"].map((x) => el("th", {}, x)))), corpo)),
      campo("Tipo di verifica", tipo)], [{ testo: "Annulla", valore: false }, { testo: "Aggiungi", classe: "primary", valore: true }]);
    if (!ok || !scelte.size) return;
    try {
      await api("POST", `/api/preventivi/${p.id}/impianti`, { impianti: [...scelte], versione: p.versione, tipo_verifica: tipo.value });
      g.ricarica(); apri(p.id, "Righe"); toast("Impianti aggiunti.");
    } catch (e) { errore(e); }
  }

  // ---------------------------------------------------------------- invio email
  // ---------------------------------------------------------------- stampa (D58)
  // Apre il PDF in una nuova scheda del browser: da lì si stampa. Se il preventivo è già inviato si stampa il PDF
  // inviato; altrimenti l'ultimo PDF se nulla è cambiato, oppure se ne genera uno nuovo (e resta archiviato).
  async function stampa(p, datiTestata, salva, riapri) {
    const iniziale = schedaIniziale.get(p.id);
    if (salva && !p.inviato_il && iniziale !== JSON.stringify(datiTestata())) {
      if (!(await conferma("Salvare le modifiche?", "Hai cambiato dei dati del preventivo: per stamparli vanno prima salvati.", { pulsante: "Salva e stampa" }))) return;
    } else salva = null;
    const finestra = window.open("", "_blank");  // subito, finché vale il clic (altrimenti il browser la blocca)
    if (finestra) finestra.document.title = "Preparazione del PDF…";
    try {
      if (salva) { await salva(); }
      const r = await api("POST", `/api/preventivi/${p.id}/stampa`);
      const indirizzo = `/api/preventivi/${p.id}/documenti/${r.documento_id}?in_linea=true`;
      if (finestra) finestra.location.href = indirizzo;
      else await scarica("GET", `/api/preventivi/${p.id}/documenti/${r.documento_id}`, undefined, r.nome_file);
      toast(r.motivo === "inviato" ? "Si stampa il PDF inviato al cliente." : r.motivo === "approvato" ? "Si stampa il PDF approvato." : r.motivo === "ricostruito" ? "Inviato prima della 0.7.0: si stampa il PDF ricostruito dai dati." : r.motivo === "ritoccato" ? "Si stampa la versione ritoccata (non ancora approvata)." : r.generato ? "PDF generato e archiviato." : "PDF pronto.");
      if (r.segnaposto_vuoti && r.segnaposto_vuoti.length) toast("Segnaposto senza valore nel modello: " + r.segnaposto_vuoti.join(", "), "errore");
      if (salva || r.generato) riapri();
    } catch (e) {
      if (finestra) finestra.close();
      errore(e);
    }
  }

  // ---------------------------------------------------------------- controllo del documento (0.7.0, D80: come i verbali)
  // «Anteprima» prepara e archivia Word e PDF con i dati attuali (o riapre quello già pronto); qui si controlla il PDF,
  // si scarica il Word per ritoccare l'impaginazione, si ricarica il Word ritoccato (il programma controlla che testo e
  // importi siano identici e rifà il PDF) e si APPROVA: si invia solo il PDF approvato.
  const riaperture = new Map();
  async function controlla(p, { salva = null, dopo = null } = {}) {
    try {
      if (salva) {
        if (!(await conferma("Salvare le modifiche?", "Hai cambiato dei dati del preventivo: per preparare il documento vanno prima salvati.", { pulsante: "Salva e prepara" }))) return;
        await salva();
      }
      toast("Preparazione del documento…");
      const r = await api("POST", `/api/preventivi/${p.id}/anteprima`);
      if (r.segnaposto_vuoti && r.segnaposto_vuoti.length) toast("Segnaposto senza valore nel modello: " + r.segnaposto_vuoti.join(", "), "errore");
      let doc = r.documento, cambiato = r.generato || !!salva;
      for (;;) {
        const scelta = await finestraDocumento(p, doc);
        if (scelta === "word") { await scarica("GET", `/api/preventivi/${p.id}/documenti/${doc.word_documento_id}`, undefined, doc.nome_word).catch(errore); continue; }
        if (scelta === "ritocco") { const n = await caricaRitocco(p); if (n) { doc = n; cambiato = true; } continue; }
        if (scelta === "approva") {
          const x = await api("POST", `/api/preventivi/${p.id}/documenti/${doc.pdf_documento_id}/approva`);
          toast("Documento approvato: è quello che si invia."); g.ricarica();
          if (riaperture.has(p.id)) riaperture.get(p.id)();
          if (dopo) await dopo(x);
          return;
        }
        break;
      }
      if (cambiato && riaperture.has(p.id)) riaperture.get(p.id)();
    } catch (e) { errore(e); }
  }

  function finestraDocumento(p, doc) {
    const puo = S.puo("preventivi.documenti");
    const info = el("div", { class: "info" },
      el("p", {}, el("strong", {}, doc.nome_file)),
      el("p", { class: "subtle" }, `Preparato il ${formatta.dataora(doc.creato_il)} da ${doc.creato_da}` + (doc.modello ? ` · modello ${doc.modello}` : "")),
      doc.ritoccato ? el("p", {}, el("span", { class: "badge avviso" }, "ritocco di impaginazione"), " contenuto controllato, PDF rifatto dal programma") : null,
      doc.ufficiale ? el("div", { class: "notice" }, "È il documento inviato al cliente: non cambia più. Per correggerlo serve una revisione.")
        : doc.approvato ? el("div", { class: "notice ok" }, `Approvato da ${doc.approvato_da} il ${formatta.dataora(doc.approvato_il)}: è il PDF che si invia.`)
        : el("div", { class: "notice" }, "Controlla contenuto e impaginazione. «Approvo questo documento» registra la tua presa visione: si invierà esattamente questo PDF."),
      !doc.ufficiale && puo ? el("p", { class: "subtle" }, "Impaginazione da sistemare? «Scarica il Word», correggi in Word solo margini, spazi e interruzioni di pagina, " +
        "poi «Carica il Word ritoccato». Testo e importi non si cambiano nel Word.") : null,
      el("p", {}, el("a", { href: doc.indirizzo, target: "_blank", rel: "noopener" }, "Apri il PDF in una nuova scheda (per stamparlo)")));
    const corpo = el("div", { class: "anteprima-doc" }, el("iframe", { src: doc.indirizzo, title: "Documento del preventivo" }), info);
    const azioni = [];
    if (!doc.ufficiale && puo && doc.word_documento_id) azioni.push({ testo: "Scarica il Word", valore: "word" }, { testo: "Carica il Word ritoccato…", valore: "ritocco" });
    azioni.push({ testo: "Chiudi", valore: null });
    if (doc.da_approvare && puo) azioni.push({ testo: "Approvo questo documento", classe: "primary", valore: "approva" });
    return modale(`Controlla il documento · ${p.etichetta}`, corpo, azioni, { largo: true });
  }

  async function caricaRitocco(p) {
    const fw = el("input", { type: "file", accept: ".docx" });
    const ok = await modale(`Word ritoccato · ${p.etichetta}`, [
      el("p", { class: "subtle" }, "Carica il Word scaricato dall'anteprima e sistemato in Word. Sono ammessi solo ritocchi di impaginazione: " +
        "se testo, numeri o immagini sono diversi il programma lo rifiuta. Il PDF lo rifà il programma; poi va approvato."),
      campo("Word ritoccato (.docx)", fw)], [{ testo: "Annulla", valore: false }, { testo: "Carica", classe: "primary", valore: true }]);
    if (!ok) return null;
    if (!fw.files[0]) { errore(new Error("Scegli il Word ritoccato.")); return null; }
    try {
      const attuale = await api("GET", `/api/preventivi/${p.id}`);
      const dati = new FormData();
      dati.append("word", fw.files[0]); dati.append("versione", attuale.versione);
      toast("Controllo del Word e preparazione del PDF…");
      const r = await api("POST", `/api/preventivi/${p.id}/documenti/ritoccati`, dati);
      toast("Ritocco accettato: controlla il PDF e approvalo.");
      return r.documento;
    } catch (e) { errore(e); return null; }
  }

  async function inviaEmail(p, salvaPrima, invariati = true) {
    if (salvaPrima && !invariati) { try { await salvaPrima(); } catch (e) { return errore(e); } }
    let b;
    try { b = await api("GET", `/api/preventivi/${p.id}/email`); } catch (e) { return errore(e); }
    if (!b.posta.configurata) return errore(new Error("Server di posta non impostato: vai in Sistema › Impostazioni email."));
    if (b.stato === "creato" && !b.allegato) {  // D80: si invia solo il PDF approvato
      toast("Prima controlla e approva il documento: si invia solo il PDF approvato.");
      return controlla(p, { dopo: () => inviaEmail(p, null) });
    }
    const a = f.testo(b.a, { maxlength: "500" }), cc = f.testo(b.cc, { maxlength: "500" }), oggetto = f.testo(b.oggetto, { maxlength: "300" });
    const testo = f.area(b.testo, { rows: "12" });
    const ok = await modale(`Invia ${p.etichetta}`, [el("div", { class: "field-grid" },
      campo("A", a, { pieno: true, aiuto: "Proposto: referente, poi email fatture/verbali del cliente. Più indirizzi separati da ;" }),
      campo("Copia", cc, { pieno: true }), campo("Oggetto", oggetto, { pieno: true }), campo("Testo", testo, { pieno: true })),
    el("p", { class: "subtle" }, b.allegato ? `In allegato: «${b.allegato.nome_file}»` + (b.allegato.inviato ? " (il PDF già inviato)." : `, approvato da ${b.allegato.approvato_da}.`) +
      (b.stato === "creato" ? " Il preventivo diventa «inviato»." : "") : "In allegato il PDF del preventivo.")],
    [{ testo: "Annulla", valore: false }, { testo: "Invia", classe: "primary", valore: true }]);
    if (!ok) return;
    try {
      toast("Invio in corso…");
      const r = await api("POST", `/api/preventivi/${p.id}/email`, { a: a.value, cc: cc.value, oggetto: oggetto.value, testo: testo.value });
      toast("Inviato: " + r.esito); g.ricarica(); apri(p.id, "Documenti e invii");
    } catch (e) { errore(e); }
  }

  S.apriDaIndirizzo(apri);
})().catch((e) => GAD.errore(e));
