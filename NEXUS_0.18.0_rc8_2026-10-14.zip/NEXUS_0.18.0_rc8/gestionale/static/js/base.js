/* NEXUS (gestionale integrato AD) — funzioni comuni a tutte le pagine.
   Regole: nessun HTML costruito con testo dell'utente (si usa sempre textContent), nessuno stile in linea. */
"use strict";

const GAD = (() => {
  const csrf = document.querySelector('meta[name="csrf"]')?.content || "";

  /** Crea un elemento: el("button", {class: "btn", onclick: f}, "Testo", altroElemento) */
  function el(tag, attributi = {}, ...figli) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attributi || {})) {
      if (v === null || v === undefined || v === false) continue;
      if (k.startsWith("on") && typeof v === "function") e.addEventListener(k.slice(2), v);
      else if (k === "class") e.className = v;
      else if (k === "dataset") Object.assign(e.dataset, v);
      else if (v === true) e.setAttribute(k, "");
      else e.setAttribute(k, v);
    }
    for (const f of figli.flat()) {
      if (f === null || f === undefined || f === false) continue;
      e.append(f instanceof Node ? f : document.createTextNode(String(f)));
    }
    return e;
  }

  /** Chiamata all'interfaccia JSON. In caso di errore lancia un Error con il messaggio in italiano. */
  async function api(metodo, url, corpo, opzioni = {}) {
    const intestazioni = { "X-CSRF-Token": csrf, Accept: "application/json" };
    let body;
    if (corpo instanceof FormData) body = corpo;
    else if (corpo !== undefined) { intestazioni["Content-Type"] = "application/json"; body = JSON.stringify(corpo); }
    let risposta;
    try {
      risposta = await fetch(url, { method: metodo, headers: intestazioni, body, credentials: "same-origin" });
    } catch (_) {
      throw new Error("Il programma non risponde: controlla che sia ancora avviato (finestra nera aperta) e riprova.");
    }
    if (risposta.status === 401) {
      location.href = "/accesso";
      throw new Error("Sessione scaduta: accedi di nuovo.");
    }
    if (opzioni.file && risposta.ok) return risposta;
    let dati = null;
    try { dati = await risposta.json(); } catch (_) { /* risposta vuota */ }
    if (!risposta.ok) throw new Error((dati && dati.errore) || `Errore ${risposta.status}: riprova.`);
    return dati;
  }

  let timerToast;
  function toast(messaggio, tipo = "") {
    const t = document.getElementById("toast");
    if (!t) return alert(messaggio);
    t.textContent = messaggio;
    t.className = "show " + tipo;
    clearTimeout(timerToast);
    timerToast = setTimeout(() => { t.className = ""; }, tipo === "errore" ? 7000 : 3500);
  }

  function errore(e) { toast(e.message || String(e), "errore"); }

  /** Finestra di dialogo. azioni: [{testo, classe, valore}] → restituisce il valore scelto (o null). */
  function modale(titolo, corpo, azioni = [{ testo: "Chiudi", valore: null }], { largo = false } = {}) {
    const d = document.getElementById("modale");
    d.classList.toggle("largo", largo);  // 0.7.0: finestra larga (es. controllo del PDF del preventivo)
    document.getElementById("modale-titolo").textContent = titolo;
    const c = document.getElementById("modale-corpo");
    c.replaceChildren(...(Array.isArray(corpo) ? corpo : [corpo]).map((x) => (x instanceof Node ? x : el("p", {}, x))));
    const a = document.getElementById("modale-azioni");
    return new Promise((risolvi) => {
      const chiudi = (valore) => { d.close(); risolvi(valore); };
      a.replaceChildren(...azioni.map((x) => el("button", { class: "btn " + (x.classe || ""), type: "button", onclick: () => chiudi(typeof x.valore === "function" ? x.valore() : x.valore) }, x.testo)));
      d.querySelector("[data-chiudi-modale]").onclick = () => chiudi(null);
      d.oncancel = (ev) => { ev.preventDefault(); chiudi(null); };
      d.showModal();
    });
  }

  /** Conferma. Con `testoRichiesto` l'utente deve scrivere una parola (es. RIPRISTINA). */
  async function conferma(titolo, testo, { pulsante = "Conferma", pericolo = false, testoRichiesto = null } = {}) {
    const parti = [el("p", {}, testo)];
    let campo = null;
    if (testoRichiesto) {
      campo = el("input", { class: "", autocomplete: "off" });
      parti.push(el("div", { class: "field" }, el("label", {}, `Per confermare scrivi ${testoRichiesto}`), campo));
    }
    const scelta = await modale(titolo, parti, [
      { testo: "Annulla", valore: false },
      { testo: pulsante, classe: pericolo ? "danger" : "primary", valore: () => (campo ? campo.value : true) },
    ]);
    if (testoRichiesto) return scelta && String(scelta).trim().toUpperCase() === testoRichiesto ? scelta : false;
    return !!scelta;
  }

  /** Scheda di dettaglio laterale. */
  const pannello = {
    // O7: durante «Salva e chiudi» il salvataggio non deve riaprire la scheda
    nonRiaprire: false,
    apri(titolo, corpo, azioni = [], { largo = false } = {}) {
      if (pannello.nonRiaprire) { pannello.nonRiaprire = false; return; }  // riapertura dopo il salvataggio: si salta una volta
      azioni = pannello.conChiudi(azioni.filter(Boolean));
      const p = document.getElementById("pannello");
      p.classList.toggle("largo", largo);
      pannello.dimensiona(largo);
      document.getElementById("pannello-titolo").textContent = titolo;
      document.getElementById("pannello-corpo").replaceChildren(...(Array.isArray(corpo) ? corpo : [corpo]));
      document.getElementById("pannello-azioni").replaceChildren(...azioni);
      p.hidden = false;
      p.querySelector("[data-chiudi-pannello]").onclick = () => pannello.chiudi();
    },
    chiudi() { document.getElementById("pannello").hidden = true; },
    // R130 (0.12.9): scheda ridimensionabile (maniglia a sinistra, «a tutto schermo»), larga in proporzione alla
    // finestra; la larghezza scelta a mano si ricorda per pagina (tipo di scheda) in questo browser.
    _chiave() { return "gad.pannello." + location.pathname; },
    _ricordata() { try { return JSON.parse(localStorage.getItem(pannello._chiave()) || "null"); } catch (e) { return null; } },
    _ricorda(v) { try { if (v === null) localStorage.removeItem(pannello._chiave()); else localStorage.setItem(pannello._chiave(), JSON.stringify(v)); } catch (e) { /* niente */ } },
    _applica(px) {
      const p = document.getElementById("pannello");
      const intero = px === "intero";
      p.classList.toggle("intero", intero);
      p.style.width = intero ? "100vw" : px ? `${Math.max(380, Math.min(px, window.innerWidth))}px` : "";
      const b = document.getElementById("pannello-schermo");
      if (b) { b.textContent = intero ? "⤡" : "⤢"; b.title = intero ? "Torna alla larghezza di prima" : "A tutto schermo"; }
    },
    dimensiona(largo) { pannello._largo = largo; pannello._applica(pannello._ricordata()); },
    _prima: null,
    schermo() {
      const ora = pannello._ricordata();
      if (ora === "intero") { pannello._ricorda(pannello._prima); pannello._applica(pannello._prima); }
      else { pannello._prima = ora; pannello._ricorda("intero"); pannello._applica("intero"); }
    },
    /** O7: accanto a «Salva» / «Crea …» (pulsante principale) aggiunge «Salva e chiudi» / «Crea e chiudi». */
    conChiudi(azioni) {
      const risultato = [];
      for (const b of azioni) {
        if (b && b._azione && b.classList && b.classList.contains("primary") && /^(Salva|Crea)/.test(b.textContent)) {
          const testo = b.textContent.startsWith("Crea") ? "Crea e chiudi" : "Salva e chiudi";
          risultato.push(el("button", { class: "btn", type: "button", onclick: async (ev) => {
            const x = ev.currentTarget; x.disabled = true; b.disabled = true; pannello.nonRiaprire = !b._senzaRiapertura;
            try {
              await b._azione();
              pannello.chiudi();
              setTimeout(() => { pannello.nonRiaprire = false; }, 3000);  // se la scheda non chiede di riaprirsi
            } catch (e) { pannello.nonRiaprire = false; errore(e); }
            finally { x.disabled = false; b.disabled = false; if (b._senzaRiapertura) pannello.nonRiaprire = false; }
          } }, testo));
        }
        risultato.push(b);
      }
      return risultato;
    },
  };
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !document.getElementById("modale")?.open) pannello.chiudi(); });
  (function maniglia() {
    const m = document.getElementById("pannello-maniglia"), b = document.getElementById("pannello-schermo");
    if (b) b.onclick = () => pannello.schermo();
    if (!m) return;
    m.addEventListener("dblclick", () => { pannello._ricorda(null); pannello._applica(null); });
    m.addEventListener("pointerdown", (ev) => {
      ev.preventDefault(); m.setPointerCapture(ev.pointerId); document.body.classList.add("trascino-pannello");
      const muovi = (e) => pannello._applica(window.innerWidth - e.clientX);
      const fine = (e) => {
        m.removeEventListener("pointermove", muovi); m.removeEventListener("pointerup", fine);
        document.body.classList.remove("trascino-pannello");
        pannello._ricorda(Math.max(380, Math.min(window.innerWidth - e.clientX, window.innerWidth)));
      };
      m.addEventListener("pointermove", muovi); m.addEventListener("pointerup", fine);
    });
  })();

  /** Campo di modulo con etichetta. */
  function campo(etichetta, input, { aiuto = "", pieno = false } = {}) {
    if (!input.id) input.id = "c-" + Math.random().toString(36).slice(2, 9);
    return el("div", { class: "field" + (pieno ? " full" : "") }, el("label", { for: input.id }, etichetta), input, aiuto ? el("div", { class: "aiuto" }, aiuto) : null);
  }

  const formatta = {
    dataora(iso) {
      if (!iso) return "";
      const d = new Date(iso);
      if (isNaN(d)) return iso;
      return d.toLocaleString("it-IT", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", timeZone: "Europe/Rome" });
    },
    data(iso) {
      if (!iso) return "";
      const [a, m, g] = iso.slice(0, 10).split("-");
      return `${g}/${m}/${a}`;
    },
    importo(centesimi) {
      if (centesimi === null || centesimi === undefined) return "";
      return (centesimi / 100).toLocaleString("it-IT", { style: "currency", currency: "EUR" });
    },
    numero(v) {
      if (v === null || v === undefined || v === "") return "";
      return Number(v).toLocaleString("it-IT", { maximumFractionDigits: 2 });
    },
    booleano(v) { return v === null || v === undefined ? "" : v ? "Sì" : "No"; },
  };

  /** Scarica un file restituito dal server (es. Excel). */
  async function scarica(metodo, url, corpo, nomePredefinito) {
    const r = await api(metodo, url, corpo, { file: true });
    const blob = await r.blob();
    const disp = r.headers.get("Content-Disposition") || "";
    const m = disp.match(/filename\*=UTF-8''([^;]+)/);
    const nome = m ? decodeURIComponent(m[1]) : nomePredefinito;
    const a = el("a", { href: URL.createObjectURL(blob), download: nome });
    document.body.append(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
  }

  // «Esci» e scelta dell'attività: static/js/barra.js (rc8), comune anche alla pagina del verbale

  return { el, api, toast, errore, modale, conferma, pannello, campo, formatta, scarica, csrf };
})();
