/* Clienti: elenco con tutte le colonne (D43), scheda con linguette, sedi collegate, sconti (D38), storico. */
"use strict";

(async () => {
  const { el, api, toast, errore, conferma, pannello, modale } = GAD;
  const S = GAD.schede;
  const { f, campo, sezione } = S;
  await S.me();
  const [valori, pagamenti, aliquote, commerciali] = await Promise.all([
    api("GET", "/api/anagrafica/valori"), api("GET", "/api/elenchi/modalita_pagamento"),
    api("GET", "/api/elenchi/aliquota_iva"), api("GET", "/api/commerciali"),
  ]);
  // 0.12.6: nel contesto AD_DM la scheda e i collegamenti portano alle pagine DM (attrezzature, scadenze, preventivi DM)
  const dm = document.documentElement.dataset.ambito === "DM";
  const collegamentiDM = [
    { testo: "Sedi operative ← Cliente", vai: (r) => S.filtro("sedi", "cliente_id", r.id, `sedi di ${r.ragione_sociale}`) },
    { testo: "Attrezzature GVR ← Cliente", vai: (r) => S.filtro("attrezzature-gvr", "cliente_id", r.id, `attrezzature GVR di ${r.ragione_sociale}`) },
    { testo: "Attrezzature SC/SP ← Cliente", vai: (r) => S.filtro("attrezzature-scsp", "cliente_id", r.id, `attrezzature SC/SP di ${r.ragione_sociale}`) },
    { testo: "Valvole di sicurezza ← Cliente", vai: (r) => S.filtro("valvole-sicurezza", "cliente_id", r.id, `valvole di ${r.ragione_sociale}`) },
    { testo: "Scadenze ← Cliente", vai: (r) => S.filtro("scadenze-tecniche", "cliente_id", r.id, `scadenze DM di ${r.ragione_sociale}`) },
    { testo: "Preventivi ← Cliente", vai: (r) => S.filtro("preventivi-dm", "cliente_id", r.id, `preventivi DM di ${r.ragione_sociale}`) },
  ];
  const collegamentiDPR = [
    { testo: "Sedi operative ← Cliente", vai: (r) => S.filtro("sedi", "cliente_id", r.id, `sedi di ${r.ragione_sociale}`) },
    { testo: "Impianti ← Cliente", vai: (r) => S.filtro("impianti", "cliente_id", r.id, `impianti di ${r.ragione_sociale}`) },
    { testo: "Scadenze ← Cliente", vai: (r) => S.filtro("scadenze", "cliente_id", r.id, `scadenze di ${r.ragione_sociale}`) },
    { testo: "Preventivi ← Cliente", vai: (r) => S.filtro("preventivi", "cliente_id", r.id, `preventivi di ${r.ragione_sociale}`) },
    ...(S.puo("verifiche.vedere_proprie", "DPR") ? [{ testo: "Verifiche ← Cliente", vai: (r) => S.filtro("verifiche", "cliente_id", r.id, `verifiche di ${r.ragione_sociale}`) }] : []),
  ];
  const btnDoppi = el("button", { class: "btn small", type: "button", title: "Clienti con la stessa partita IVA o lo stesso codice fiscale", onclick: () => doppi().catch(errore) }, "Possibili doppioni");
  const g = await GAD.griglia(document.getElementById("griglia"), "clienti", {
    pulsanti: [btnDoppi],
    suRiga: (r) => apri(r.id),
    azioni: {
      modifica: (r) => apri(r.id),
      elimina: S.puo("anagrafica.clienti") ? (r) => S.eliminaDaRiga(`/api/clienti/${r.id}`, `il cliente «${r.ragione_sociale}»`, g) : null,
      collegamenti: dm ? collegamentiDM : collegamentiDPR,
    },
  });
  const NOMI_AMBITI = { DPR: "AD_DPR", DM: "AD_DM", IEC: "I&C" };
  const provenienza = (o) => (o || []).map((x) => `${x.sistema.replace("garda_", "Garda ")} · ${x.tabella} ${x.id_origine}`).join("; ");

  // ---- clienti doppi (stessa P.IVA o CF): dopo ogni scelta l'elenco si rilegge dal server
  async function doppi() {
    const area = el("div", {}, el("p", { class: "subtle" }, "Caricamento…"));
    pannello.apri("Possibili doppioni di cliente", area, [], { largo: true });
    const descrivi = (x) => el("div", {}, el("strong", {}, x.ragione_sociale), el("br"),
      `P.IVA ${x.partita_iva || "—"} · CF ${x.codice_fiscale || "—"}${x.comune ? " · " + x.comune : ""}`, el("br"),
      el("span", { class: "subtle" }, `n. ${x.id} · ${x.ambiti.map((a) => NOMI_AMBITI[a]).join(", ") || "nessun ambito"} · ${x.sedi} sedi · ${x.preventivi} preventivi · ${x.fatture} fatture` +
        (x.origini.length ? ` · da ${provenienza(x.origini)}` : "") + (x.attivo ? "" : " · disattivato")));
    const unisci = async (o, d) => {
      if (!(await conferma("Unire i due clienti?", `Resta «${d.ragione_sociale}»: sedi, preventivi e incassi di «${o.ragione_sociale}» passano lì e «${o.ragione_sociale}» viene eliminato. I campi vuoti si completano; i dati diversi finiscono nelle note. Tutto resta nel registro.`, { pulsante: "Unisci" }))) return;
      await api("POST", `/api/clienti/${o.id}/unisci`, { destinazione_id: d.id }); toast("Clienti uniti."); g.ricarica(); await disegna();
    };
    async function disegna() {
      const elenco = await api("GET", "/api/clienti/doppioni");
      area.replaceChildren(el("p", { class: "subtle" }, `${elenco.length} coppie di clienti con la stessa partita IVA o lo stesso codice fiscale. Può essere lo stesso soggetto entrato due volte, oppure uffici diversi dello stesso ente: in quel caso «Sono clienti diversi».`),
        ...(elenco.length ? elenco.map((c) => el("div", { class: "riquadro" }, el("p", {}, "Stesso numero: ", el("strong", {}, c.numero)),
          el("div", { class: "field-grid" }, descrivi(c.a), descrivi(c.b)),
          S.puo("anagrafica.clienti") ? el("div", { class: "riga-campi" },
            S.azione(`Unisci: resta «${c.a.ragione_sociale.slice(0, 30)}»`, "small primary", () => unisci(c.b, c.a)),
            S.azione(`Unisci: resta «${c.b.ragione_sociale.slice(0, 30)}»`, "small", () => unisci(c.a, c.b)),
            S.azione("Sono clienti diversi", "small", async () => { await api("POST", "/api/clienti/doppioni/diversi", { a: c.a.id, b: c.b.id }); toast("Non verranno più proposti."); await disegna(); })) : null))
          : [el("p", {}, "Nessun possibile doppione.")]));
    }
    await disegna();
  }
  const opzioni = (elenco, attuale) => elenco.filter((x) => x.attivo || x.id === attuale).map((x) => ({ valore: x.id, testo: x.descrizione + (x.attivo ? "" : " (non più in uso)") }));

  function modulo(c) {
    c = c || { tipo: "privato", nazione: "IT" };
    const m = {
      ragione_sociale: f.testo(c.ragione_sociale, { maxlength: "250" }),
      tipo: f.scelta(Object.entries(valori.tipi_cliente).map(([k, v]) => ({ valore: k, testo: v })), c.tipo),
      nazione: f.testo(c.nazione || "IT", { maxlength: "2" }),
      partita_iva: f.testo(c.partita_iva, { maxlength: "20" }),
      codice_fiscale: f.testo(c.codice_fiscale, { maxlength: "20" }),
      email_verbali: f.testo(c.email_verbali, { maxlength: "500" }),
      email_fatture: f.testo(c.email_fatture, { maxlength: "500" }),
      pec: f.testo(c.pec, { maxlength: "200" }),
      codice_sdi: f.testo(c.codice_sdi, { maxlength: "7" }),
      riferimento_amministrazione: f.testo(c.riferimento_amministrazione, { maxlength: "20" }),
      modalita_pagamento_id: f.scelta(opzioni(pagamenti, c.modalita_pagamento_id), c.modalita_pagamento_id, { vuota: "—" }),
      aliquota_iva_id: f.scelta(opzioni(aliquote, c.aliquota_iva_id), c.aliquota_iva_id, { vuota: "—" }),
      ritenuta_percentuale: f.numero(c.ritenuta_percentuale, { placeholder: "es. 4" }),
      sconto_dm: f.numero(c.sconto_dm || "", { placeholder: "es. 15" }),
      termine_esecuzione: f.testo(c.termine_esecuzione, { maxlength: "300", placeholder: "es. entro 60 giorni dall'accettazione" }),
      banca: f.testo(c.banca, { maxlength: "120" }),
      iban: f.testo(c.iban, { maxlength: "34" }),
      dichiarazione_numero: f.testo(c.dichiarazione_numero, { maxlength: "60" }),
      dichiarazione_data: f.data(c.dichiarazione_data),
      commerciale_id: f.scelta(commerciali.filter((x) => (x.attivo && (!x.ambiti || x.ambiti.includes(document.documentElement.dataset.ambito || "DPR"))) || x.id === c.commerciale_id).map((x) => ({ valore: x.id, testo: x.nome })), c.commerciale_id, { vuota: "—" }),
      referente_nome: f.testo(c.referente_nome, { maxlength: "120" }),
      referente_email: f.testo(c.referente_email, { maxlength: "200" }),
      referente_telefono: f.testo(c.referente_telefono, { maxlength: "60" }),
      note: f.area(c.note, { maxlength: "8000" }),
      avvisi: f.area(c.avvisi, { maxlength: "8000" }),
      codice_esterno: f.testo(c.codice_esterno, { maxlength: "40" }),
    };
    const dichiarazione = f.casella("Il cliente ha una dichiarazione d'intento", c.dichiarazione_intento);
    const amb = S.ambiti(c.id ? c.ambiti : null);
    const ind = S.indirizzo(c);
    const uguale = el("button", { class: "btn small", type: "button", onclick: () => { m.email_fatture.value = m.email_verbali.value; } }, "= email verbali");
    const generali = el("div", { class: "field-grid" },
      campo("Ragione sociale (o nome e cognome)", m.ragione_sociale, { pieno: true }),
      campo("Tipo di cliente", m.tipo, { aiuto: "Pubblica amministrazione: split payment e codice ufficio di 6 caratteri." }),
      campo("Nazione", m.nazione, { aiuto: "IT per l'Italia; per l'estero i controlli di P.IVA e CF non si applicano." }),
      campo("Ambiti di lavoro", amb.el, { pieno: true, aiuto: "Valgono per il cliente e per tutte le sue sedi operative (R137). Gli elenchi di ogni attività mostrano solo i suoi. Si accendono da soli quando entra un impianto, un'attrezzatura o un preventivo; si tolgono solo se nessuna sede ha più impianti o attrezzature di quell'ambito." }),
      sezione("Sede legale"), ...ind.elementi,
      sezione("Dati fiscali"),
      campo("Partita IVA", m.partita_iva, { aiuto: "11 cifre: il programma controlla la cifra di controllo." }),
      campo("Codice fiscale", m.codice_fiscale, { aiuto: "16 caratteri per le persone, 11 cifre per società ed enti." }));
    const fatturazione = el("div", { class: "field-grid" },
      sezione("Invio documenti (D41)"),
      campo("Email per i verbali", m.email_verbali, { pieno: true, aiuto: "Più indirizzi separati da ; — le sedi possono avere destinatari propri." }),
      campo("Email per le fatture", el("div", { class: "riga-campi" }, m.email_fatture, uguale), { pieno: true }),
      sezione("Fattura elettronica"),
      campo("Codice destinatario SDI", m.codice_sdi, { aiuto: "7 caratteri (privati) o 6 (PA). Vuoto se si usa la PEC." }),
      campo("PEC", m.pec),
      campo("Riferimento amministrazione", m.riferimento_amministrazione),
      sezione("Pagamento e IVA"),
      campo("Modalità di pagamento", m.modalita_pagamento_id), campo("Aliquota IVA", m.aliquota_iva_id),
      campo("Termine di esecuzione (proposto nei preventivi)", m.termine_esecuzione, { pieno: true, aiuto: "Modalità di pagamento e termine di esecuzione si propongono nei preventivi e lì si possono cambiare." }),
      campo("Ritenuta d'acconto %", m.ritenuta_percentuale, { aiuto: "Es. condomìni. Vuoto se non si applica." }),
      campo("Sconto predefinito AD_DM %", m.sconto_dm, { aiuto: "Proposto nelle righe dei preventivi AD_DM (come lo «sconto predefinito» di Garda); si cambia riga per riga." }),
      campo("Banca del cliente", m.banca), campo("IBAN del cliente", m.iban, { pieno: true, aiuto: "Serve per le Ri.Ba." }),
      sezione("Dichiarazione d'intento"),
      el("div", { class: "field full" }, dichiarazione.el),
      campo("Numero", m.dichiarazione_numero), campo("Data", m.dichiarazione_data));
    const contatti = el("div", { class: "field-grid" },
      campo("Commerciale AD di riferimento (D35)", m.commerciale_id, { pieno: true }),
      sezione("Referente del cliente"),
      campo("Nome", m.referente_nome), campo("Telefono", m.referente_telefono), campo("Email", m.referente_email, { pieno: true }),
      sezione("Note"),
      campo("Note", m.note, { pieno: true }),
      campo("Da controllare", m.avvisi, { pieno: true, aiuto: "Segnalazioni (es. dall'importazione): svuota quando hai sistemato." }),
      campo("Riferimento nel gestionale attuale", m.codice_esterno));
    return {
      generali, fatturazione, contatti, campi: m,
      valori: () => ({
        ...Object.fromEntries(Object.entries(m).map(([k, x]) => [k, x.value])),
        ...ind.valori(), dichiarazione_intento: dichiarazione.valore, ambiti: amb.valore,
      }),
    };
  }

  async function nuovo() {
    const m = modulo(null);
    const salva = S.azione("Crea cliente", "primary", async () => {
      const c = await api("POST", "/api/clienti", m.valori());
      toast("Cliente creato."); g.ricarica(); apri(c.id);
    });
    pannello.apri("Nuovo cliente", [S.linguette([
      { titolo: "Dati generali", contenuto: m.generali }, { titolo: "Fatturazione", contenuto: m.fatturazione },
      { titolo: "Contatti e note", contenuto: m.contatti }])], [salva], { largo: true });
  }

  async function apri(id) {
    let c;
    try { c = await api("GET", `/api/clienti/${id}`); } catch (e) { return errore(e); }
    const m = modulo(c);
    const sedi = el("div", {}, el("p", { class: "subtle" }, "Caricamento…"));
    const caricaSedi = async () => {
      const elenco = await api("GET", `/api/clienti/${c.id}/sedi`);
      sedi.replaceChildren(
        S.tabella([
          { titolo: "Sede", valore: (r) => r.denominazione }, { titolo: "Comune", valore: (r) => `${r.comune} ${r.provincia ? "(" + r.provincia + ")" : ""}` },
          dm ? { titolo: "Attrezzature", num: true, valore: (r) => String(r.n_attrezzature) } : { titolo: "Impianti", num: true, valore: (r) => String(r.n_impianti) },
          { titolo: "Ambiti", valore: (r) => (r.ambiti || []).map((a) => ({ DPR: "AD_DPR", DM: "AD_DM", IEC: "I&C" })[a]).join(", ") },
          { titolo: "Attiva", valore: (r) => (r.attiva ? "Sì" : "No") },
        ], elenco, (r) => { location.href = `/sedi?apri=${r.id}`; }),
        S.puo("anagrafica.sedi") && c.attivo ? el("p", {}, el("a", { class: "btn small", href: `/sedi?nuovo=1&cliente_id=${c.id}` }, "＋ Nuova sede per questo cliente")) : null,
        dm ? el("p", {}, el("a", { href: S.filtro("attrezzature-gvr", "cliente_id", c.id, `attrezzature GVR di ${c.ragione_sociale}`), class: "subtle" }, "Attrezzature GVR del cliente"), " · ",
          el("a", { href: S.filtro("attrezzature-scsp", "cliente_id", c.id, `attrezzature SC/SP di ${c.ragione_sociale}`), class: "subtle" }, "Attrezzature SC/SP del cliente"), ` (${c.n_attrezzature} in tutto)`)
          : el("p", {}, el("a", { href: S.filtro("impianti", "cliente_id", c.id, `impianti di ${c.ragione_sociale}`), class: "subtle" }, `Tutti gli impianti del cliente (${c.n_impianti})`)));
    };
    caricaSedi().catch(errore);
    const storico = el("div");
    const testata = [];
    if (!c.attivo) testata.push(el("div", { class: "notice" }, "Cliente disattivato: resta in archivio ma non si usa per nuove sedi e preventivi."));
    const av = S.avvisi(c.avvisi, m.campi.avvisi);
    if (av) testata.push(av);
    testata.push(el("div", { class: "riquadro" }, el("div", { class: "numeri" },
      el("span", {}, el("strong", {}, String(c.n_sedi)), " sedi"),
      ...(dm ? [el("span", {}, el("strong", {}, String(c.n_attrezzature)), " attrezzature")] : []),
      ...(!dm || c.n_impianti ? [el("span", {}, el("strong", {}, String(c.n_impianti)), " impianti")] : []),
      ...(dm || !c.n_attrezzature ? [] : [el("span", {}, el("strong", {}, String(c.n_attrezzature)), " attrezzature")]),
      el("span", {}, "Sconti: ", el("strong", {}, c.sconti_ammessi ? `ammessi (${c.sconti_motivo})` : "bloccati")))));
    const corpo = el("div", {}, ...testata, S.linguette([
      { titolo: "Dati generali", contenuto: m.generali }, { titolo: "Fatturazione", contenuto: m.fatturazione },
      { titolo: "Contatti e note", contenuto: el("div", {}, m.contatti, c.origini && c.origini.length ? el("p", { class: "subtle" }, "Provenienza: " + provenienza(c.origini)) : null) },
      { titolo: `Sedi (${c.n_sedi})`, contenuto: sedi },
      { titolo: "Storico", contenuto: storico, apri: async () => storico.replaceChildren(await S.storico("cliente", c.id)) },
    ]), S.traccia(c));
    const pulsanti = [];
    if (S.puo("preventivi.sconti_sblocca")) {
      pulsanti.push(S.azione(c.sconti_ammessi ? "Blocca sconti" : "Sblocca sconti…", "", async () => {
        let motivo = "";
        if (!c.sconti_ammessi) {
          const campoMotivo = el("input", { maxlength: "300", placeholder: "es. pubblica amministrazione" });
          const ok = await modale("Sbloccare gli sconti?", [el("p", {}, "Chi ha il permesso «applicare sconti» potrà mettere uno sconto % sulle righe dei preventivi di questo cliente (D38)."),
            campo("Motivo (resta nel registro)", campoMotivo)], [{ testo: "Annulla", valore: false }, { testo: "Sblocca", classe: "primary", valore: true }]);
          if (!ok) return;
          motivo = campoMotivo.value;
        }
        await api("POST", `/api/clienti/${c.id}/sconti`, { ammessi: !c.sconti_ammessi, motivo, versione: c.versione });
        toast(c.sconti_ammessi ? "Sconti bloccati." : "Sconti sbloccati."); g.ricarica(); apri(c.id);
      }));
    }
    if (S.puo("anagrafica.disattiva")) {
      pulsanti.push(S.azione(c.attivo ? "Disattiva" : "Riattiva", c.attivo ? "danger" : "", async () => {
        if (c.attivo && !(await conferma("Disattivare il cliente?", `«${c.ragione_sociale}» resta in archivio con sedi e impianti, ma non si potranno aggiungere sedi né fare preventivi.`, { pulsante: "Disattiva", pericolo: true }))) return;
        await api("POST", `/api/clienti/${c.id}/attivo`, { attivo: !c.attivo, versione: c.versione });
        toast(c.attivo ? "Cliente disattivato." : "Cliente riattivato."); g.ricarica(); apri(c.id);
      }));
    }
    if (S.puo("anagrafica.clienti") && !c.n_sedi) {
      pulsanti.push(S.azione("Elimina", "danger", async () => {
        if (!(await conferma("Eliminare il cliente?", `«${c.ragione_sociale}» non ha sedi: viene eliminato (i suoi dati restano nel registro delle operazioni).`, { pulsante: "Elimina", pericolo: true }))) return;
        await api("DELETE", `/api/clienti/${c.id}`); toast("Cliente eliminato."); pannello.chiudi(); g.ricarica();
      }));
    }
    pulsanti.push(el("span", { class: "spazio" }));
    if (S.puo("anagrafica.clienti")) {
      pulsanti.push(S.azione("Salva", "primary", async () => {
        await api("PUT", `/api/clienti/${c.id}`, { ...m.valori(), versione: c.versione });
        toast("Modifiche salvate."); g.ricarica(); apri(c.id);
      }));
    } else S.solaLettura(corpo);
    pannello.apri(c.ragione_sociale, corpo, pulsanti, { largo: true });
  }

  document.getElementById("nuovo")?.addEventListener("click", nuovo);
  S.apriDaIndirizzo(apri);
})().catch((e) => GAD.errore(e));
