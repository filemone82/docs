/* Impostazioni email: server di posta (password in posta.json, fuori dal database e dai backup) e testi standard dei preventivi. */
"use strict";

(async () => {
  const { el, api, toast, errore } = GAD;
  const S = GAD.schede;
  const { f, campo, sezione } = S;
  const box = document.getElementById("impostazioni");
  // C15 (0.16): una configurazione per attività; si modifica quella dell'attività scelta in alto
  const att = ["DPR", "DM", "IEC"].includes(document.documentElement.dataset.ambito) ? document.documentElement.dataset.ambito : "DPR";
  async function disegna() {
    const d = await api("GET", `/api/impostazioni/posta?attivita=${att}`);
    const p = d.posta;
    const m = { server: f.testo(p.server), porta: f.numero(p.porta), utente: f.testo(p.utente), password: el("input", { type: "password", autocomplete: "new-password",
      placeholder: p.password_impostata ? "(impostata: lascia vuoto per non cambiarla)" : "" }), mittente: f.testo(p.mittente), nome_mittente: f.testo(p.nome_mittente),
      copia_ufficio: f.testo(p.copia_ufficio), sicurezza: f.scelta([{ valore: "ssl", testo: "SSL (porta 465)" }, { valore: "starttls", testo: "STARTTLS (porta 587)" }, { valore: "nessuna", testo: "Nessuna (solo prove)" }], p.sicurezza) };
    const t = { oggetto: f.testo(d.testi.oggetto, { maxlength: "300" }), testo: f.area(d.testi.testo, { rows: "10" }), firma: f.area(d.testi.firma, { rows: "3" }) };
    const prova = f.testo(p.copia_ufficio);
    box.replaceChildren(
      el("div", { class: "panel" }, el("h3", {}, `Server di posta · ${p.nome_attivita}`),
        el("p", { class: "subtle" }, `Vale per gli invii di ${p.nome_attivita} (preventivi, verbali). Le altre attività hanno la loro configurazione: si cambiano scegliendo l'attività in alto.`),
        el("div", { class: p.configurata ? "notice ok" : "notice" }, p.configurata ? "Posta impostata." : "Posta non ancora impostata: serve la password della casella.",
          ` Le impostazioni stanno nel file ${p.file} (fuori dal database e dai backup).`),
        el("div", { class: "field-grid" }, campo("Server (SMTP)", m.server), campo("Porta", m.porta), campo("Sicurezza", m.sicurezza), campo("Utente", m.utente),
          campo("Password", m.password, { aiuto: "Non viene mai mostrata." }), campo("Mittente", m.mittente), campo("Nome del mittente", m.nome_mittente),
          campo("Copia per l'ufficio", m.copia_ufficio, { aiuto: "Proposta in copia a ogni invio." })),
        el("div", { class: "actions" }, S.azione("Salva il server di posta", "primary", async () => {
          await api("PUT", `/api/impostazioni/posta?attivita=${att}`, Object.fromEntries(Object.entries(m).map(([k, v]) => [k, v.value]))); toast("Salvato."); disegna();
        }), el("span", { class: "spazio" }), prova, S.azione("Invia una email di prova", "", async () => {
          const r = await api("POST", `/api/impostazioni/posta/prova?attivita=${att}`, { a: prova.value }); toast(r.esito);
        }))),
      el("div", { class: "panel" }, el("h3", {}, "Testo standard delle email dei preventivi"),
        el("p", { class: "subtle" }, "Campi utilizzabili: ", ...d.campi.map((c) => el("span", { class: "badge grigio", title: c.descrizione }, `{${c.campo}}`))),
        el("div", { class: "field-grid" }, campo("Oggetto", t.oggetto, { pieno: true }), campo("Testo", t.testo, { pieno: true }), campo("Firma", t.firma, { pieno: true })),
        el("div", { class: "actions" }, S.azione("Salva i testi", "primary", async () => {
          await api("PUT", "/api/impostazioni/testi-preventivi", Object.fromEntries(Object.entries(t).map(([k, v]) => [k, v.value]))); toast("Testi salvati.");
        }))),
      el("div", { class: "panel" }, el("h3", {}, "PDF"),
        el("p", {}, d.pdf_disponibile ? `LibreOffice trovato: ${d.libreoffice}` : "LibreOffice non trovato: senza LibreOffice si genera solo il Word e non si possono inviare preventivi. Installalo (gratuito, libreoffice.org) oppure indica il percorso di soffice.exe in config.json alla voce «libreoffice».")),
    );
  }
  disegna().catch(errore);
})();
