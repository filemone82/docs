/* Backup e integrità: crea, carica, verifica, scarica, ripristina; controllo di integrità. */
"use strict";

(async () => {
  const { el, api, toast, errore, modale, conferma, pannello, formatta } = GAD;

  const g = await GAD.griglia(document.getElementById("griglia-backup"), "backup", { suRiga: (r) => apri(r) });

  async function conAttesa(pulsante, fn) {
    const testo = pulsante.textContent;
    pulsante.disabled = true;
    pulsante.textContent = "Attendere…";
    try { await fn(); } catch (e) { errore(e); } finally { pulsante.disabled = false; pulsante.textContent = testo; }
  }

  document.getElementById("crea-backup").addEventListener("click", (ev) => conAttesa(ev.target, async () => {
    const r = await api("POST", "/api/backup");
    toast(`Backup creato: ${r.nome}`);
    g.ricarica();
  }));

  const file = document.getElementById("file-backup");
  document.getElementById("carica-backup").addEventListener("click", () => file.click());
  file.addEventListener("change", () => conAttesa(document.getElementById("carica-backup"), async () => {
    if (!file.files.length) return;
    const dati = new FormData();
    dati.append("file", file.files[0]);
    file.value = "";
    const r = await api("POST", "/api/backup/carica", dati);
    toast(`Backup caricato e verificato: ${r.nome}`);
    g.ricarica();
  }));

  function esitoVoce(titolo, ok, dettaglio) {
    return el("li", {}, el("span", { class: "badge " + (ok ? "ok" : "errore") }, ok ? "OK" : "PROBLEMA"), ` ${titolo}`, dettaglio ? el("span", { class: "subtle" }, ` — ${dettaglio}`) : null);
  }

  document.getElementById("controllo-integrita").addEventListener("click", (ev) => conAttesa(ev.target, async () => {
    const r = await api("POST", "/api/backup/integrita");
    const d = r.documenti;
    document.getElementById("esito-integrita").replaceChildren(el("div", { class: "panel" },
      el("h3", {}, r.tutto_ok ? "Controllo di integrità: tutto in ordine" : "Controllo di integrità: problemi rilevati"),
      el("ul", { class: "roadmap" },
        esitoVoce("Database", r.database.integro, r.database.integro ? "" : r.database.dettaglio),
        esitoVoce("Collegamenti tra i dati", r.collegamenti.integri, r.collegamenti.integri ? "" : `${r.collegamenti.problemi} collegamenti rotti`),
        esitoVoce("Registro delle operazioni", r.registro.integro, r.registro.integro ? `${formatta.numero(r.registro.righe_controllate)} righe controllate` : `alterazione alla riga ${r.registro.prima_riga_alterata}`),
        esitoVoce("Documenti", d.integri, d.integri ? `${formatta.numero(d.controllati)} documenti controllati` : `${d.mancanti.length} mancanti, ${d.alterati.length} alterati`)),
      r.tutto_ok ? null : el("p", { class: "notice errore" }, "Non modificare nulla e avvisa la persona tecnica di riferimento: il ripristino da un backup verificato è la soluzione più sicura.")));
  }));

  function apri(b) {
    const azioni = [];
    const scarica = el("a", { class: "btn", href: `/api/backup/${encodeURIComponent(b.nome)}/scarica` }, "Scarica");
    const verifica = el("button", { class: "btn", type: "button" }, "Verifica");
    verifica.addEventListener("click", () => conAttesa(verifica, async () => {
      const r = await api("POST", `/api/backup/${encodeURIComponent(b.nome)}/verifica`);
      await modale(r.valido ? "Backup valido" : "Backup NON valido",
        r.valido ? [el("p", {}, `Tutti i ${r.file_controllati} file corrispondono alle impronte e il database è integro.`)]
          : r.problemi.map((p) => el("p", {}, "• " + p)));
    }));
    const ripristina = el("button", { class: "btn danger", type: "button" }, "Ripristina…");
    ripristina.addEventListener("click", async () => {
      const ok = await conferma("Ripristinare questo backup?",
        `Tutti i dati attuali verranno sostituiti con quelli del ${formatta.dataora(b.creato_il)}. Prima il programma verifica il backup e salva lo stato attuale in un backup «Prima di un ripristino», così si può tornare indietro. Dopo il ripristino tutti dovranno accedere di nuovo.`,
        { pulsante: "Ripristina", pericolo: true, testoRichiesto: "RIPRISTINA" });
      if (!ok) return;
      await conAttesa(ripristina, async () => {
        const r = await api("POST", `/api/backup/${encodeURIComponent(b.nome)}/ripristina`, { conferma: "RIPRISTINA" });
        await modale("Ripristino completato", [el("p", {}, `Lo stato precedente è salvato in ${r.backup_di_sicurezza}.`), el("p", {}, "Accedi di nuovo per continuare.")]);
        location.href = "/accesso";
      });
    });
    azioni.push(ripristina, el("span", { class: "spazio" }), verifica, scarica);
    pannello.apri("Backup", [el("dl", { class: "kv" },
      el("dt", {}, "File"), el("dd", {}, b.nome),
      el("dt", {}, "Creato il"), el("dd", {}, formatta.dataora(b.creato_il)),
      el("dt", {}, "Tipo"), el("dd", {}, b.tipo),
      el("dt", {}, "Dimensione"), el("dd", {}, `${formatta.numero(b.dimensione_mb)} MB`),
      el("dt", {}, "Documenti"), el("dd", {}, formatta.numero(b.documenti)),
      el("dt", {}, "Versione"), el("dd", {}, b.versione_programma))], azioni);
  }
})().catch((e) => GAD.errore(e));
