/* Commerciali di AD (D35): proposti nel cliente e poi nel preventivo. */
"use strict";

(async () => {
  const { el, api, toast, errore, pannello } = GAD;
  const S = GAD.schede;
  const { f, campo } = S;
  await S.me();
  const g = await GAD.griglia(document.getElementById("griglia"), "commerciali", {
    suRiga: (r) => apri(r.id),
    azioni: { modifica: (r) => apri(r.id), collegamenti: [{ testo: "Clienti ← Commerciale", vai: (r) => S.filtro("clienti", "commerciale", r.nome, `clienti di ${r.nome}`) }] },
  });

  function modulo(x) {
    x = x || { attivo: true };
    const m = { nome: f.testo(x.nome, { maxlength: "120" }), email: f.testo(x.email, { maxlength: "200" }),
      telefono: f.testo(x.telefono, { maxlength: "60" }), note: f.area(x.note, { maxlength: "4000" }) };
    const attivo = f.casella("Attivo (si può scegliere nei clienti)", x.attivo);
    const amb = S.ambiti(x.id ? x.ambiti : null);  // C16 (0.16): in quali attività lavora; nuovo = attività scelta in alto
    const griglia = el("div", { class: "field-grid" }, campo("Nome e cognome", m.nome, { pieno: true }), campo("Email", m.email), campo("Telefono", m.telefono),
      campo("Attività", amb.el, { pieno: true, aiuto: "Il commerciale si propone solo nei clienti delle sue attività." }),
      el("div", { class: "field full" }, attivo.el), campo("Note", m.note, { pieno: true }));
    return { griglia, valori: () => ({ ...Object.fromEntries(Object.entries(m).map(([k, v]) => [k, v.value])), attivo: attivo.valore, ambiti: amb.valore }) };
  }

  document.getElementById("nuovo")?.addEventListener("click", () => {
    const m = modulo(null);
    pannello.apri("Nuovo commerciale", m.griglia, [S.azione("Crea", "primary", async () => {
      const x = await api("POST", "/api/commerciali", m.valori()); toast("Commerciale creato."); g.ricarica(); apri(x.id);
    })]);
  });

  async function apri(id) {
    let x;
    try { x = await api("GET", `/api/commerciali/${id}`); } catch (e) { return errore(e); }
    const m = modulo(x);
    const storico = el("div");
    const corpo = el("div", {}, S.linguette([{ titolo: "Dati", contenuto: m.griglia },
      { titolo: "Storico", contenuto: storico, apri: async () => storico.replaceChildren(await S.storico("commerciale", x.id)) }]));
    const pulsanti = [];
    if (S.puo("anagrafica.commerciali")) {
      pulsanti.push(S.azione("Salva", "primary", async () => {
        await api("PUT", `/api/commerciali/${x.id}`, { ...m.valori(), versione: x.versione }); toast("Salvato."); g.ricarica(); apri(x.id);
      }));
    } else S.solaLettura(corpo);
    pannello.apri(x.nome, corpo, pulsanti);
  }
  S.apriDaIndirizzo(apri);
})().catch((e) => GAD.errore(e));
