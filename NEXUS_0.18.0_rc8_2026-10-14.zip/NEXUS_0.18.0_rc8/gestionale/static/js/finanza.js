/* Nucleo economico AD DPR. Tutti i testi dei dati usano textContent. */
"use strict";
(async () => {
  const {el,api,campo,modale,toast,errore}=GAD;
  const euros=n=>new Intl.NumberFormat("it-IT",{style:"currency",currency:"EUR"}).format(n/100);
  const oggiLocale=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;};
  const val=await api("GET","/api/finanza/valori").catch(errore); if(!val)return;
  const so=val.societa.find(x=>x.codice==="AD"), perm=val.permessi;
  const input=(v="",type="text")=>el("input",{type,value:v});
  const select=(rows,v)=>{const s=el("select",{},...rows.map(r=>el("option",{value:r[0]},r[1])));if(v!=null)s.value=v;return s;};
  const clientes=v=>select(val.clienti.map(c=>[c.id,c.ragione_sociale]),v);
  const btn=(t,f,cls="")=>el("button",{type:"button",class:"btn "+cls,onclick:async()=>{try{await f();}catch(e){errore(e);}}},t);
  const table=(headers,rows)=>el("table",{class:"finance-table"},el("thead",{},el("tr",{},...headers.map(t=>el("th",{},t)))),el("tbody",{},...rows.map(row=>el("tr",{},...row.map(x=>el("td",{},x))))));
  let fatture=[],incassi=[],grigliaFatture=null;
  const ambito=document.documentElement.dataset.ambito==="DM"?"DM":"DPR";  // 0.12.10: Fatture AD_DPR o AD_DM
  async function aggiorna(){
    const q=document.getElementById("ricerca-fatture").value;
    // 0.12.10 (doc. 30, § 9): elenco sulla griglia standard, con la stampa rapida del PDF di cortesia
    if(!grigliaFatture){
      // 0.14: XML delle fatture spuntate in un solo ZIP (Garda «genera XML» in blocco) e ricevute SdI
      const zip=btn("⬇ XML delle selezionate (ZIP)",async()=>{
        const ids=grigliaFatture.selezionate().map(r=>r.id);if(!ids.length)return toast("Spunta almeno una fattura emessa.");
        const r=await fetch("/api/fatture/xml-zip",{method:"POST",headers:{"Content-Type":"application/json","X-CSRF-Token":document.querySelector('meta[name="csrf"]')?.content||""},body:JSON.stringify({ids})});
        if(!r.ok)throw new Error((await r.json().catch(()=>({}))).errore||"Errore nello scaricamento.");
        const a=el("a",{href:URL.createObjectURL(await r.blob()),download:(r.headers.get("Content-Disposition")||"").split('"')[1]||"fatture_xml.zip"});document.body.append(a);a.click();a.remove();});
      const ric=btn("⬆ Carica ricevute SdI…",()=>ricevute());ric.hidden=!perm["fatture.esiti"];
      grigliaFatture=await GAD.griglia(document.getElementById("griglia-fatture"),"fatture",{
        selezione:true,pulsanti:[zip,ric],
        suRiga:(r)=>apri(r.id).catch(errore),
        azioni:{modifica:(r)=>apri(r.id).catch(errore),extra:[{testo:"🖨",titolo:"PDF di cortesia",fn:(r)=>window.open(`/api/fatture/${r.id}/pdf`,"_blank")}]},
      });
    } else grigliaFatture.ricarica();
    fatture=await api("GET","/api/fatture?ambito="+ambito+"&q="+encodeURIComponent(q)+"&scadute="+document.getElementById("solo-scadute").checked);
    document.getElementById("riepilogo-finanza").textContent=`Residuo da incassare (${ambito}): ${euros(fatture.filter(f=>f.tipo!=="TD04"&&!['bozza','scartata'].includes(f.stato)).reduce((a,f)=>a+f.residuo,0))}`;
    if(perm["incassi.vedere"]){
      incassi=await api("GET","/api/incassi");
      document.getElementById("lista-incassi").replaceChildren(table(["Data","Pagatore","Importo","Associazioni","Stato",""],incassi.map(x=>[
        x.data,x.cliente,euros(x.importo),x.allocazioni.map(a=>a.codice+" "+euros(a.importo)).join("; ")||"Da associare",x.stornato?"Stornato":"Registrato",btn("Apri",()=>apriIncasso(x))])));
    } else document.getElementById("lista-incassi").textContent="Per consultare gli incassi serve il relativo permesso.";
  }
  async function nuovo(originale){
    const c=clientes(originale?.cliente_id),t=select(Object.entries(val.tipi),originale?"TD04":"TD01"),data=input(new Date().toLocaleDateString("en-CA"),"date");
    // ISO locale senza dipendere dal formato del browser.
    const oggi=new Date();data.value=`${oggi.getFullYear()}-${String(oggi.getMonth()+1).padStart(2,"0")}-${String(oggi.getDate()).padStart(2,"0")}`;
    if(originale){t.disabled=true;c.disabled=true;}
    const ok=await modale(originale?"Nuova nota di credito":"Nuovo documento",el("div",{class:"field-grid"},campo("Tipo",t),campo("Data",data),campo("Intestatario fattura",c)),[{testo:"Annulla",valore:null},{testo:"Crea bozza",valore:true,classe:"primary"}]);
    if(!ok)return;
    let f=await api("POST","/api/fatture",{societa_id:so.id,ambito,cliente_id:Number(c.value),tipo:t.value,data:data.value,...(originale?{originale_id:originale.id}: {})});
    if(originale){
      const az=await modale("Nota totale o parziale",el("p",{},"Per una nota totale copia tutte le righe; per una parziale aggiungi dalla fattura originaria solo gli importi da rettificare."),[{testo:"Parziale",valore:"parziale"},{testo:"Copia tutte le righe",valore:"totale"}]);
      if(az==="totale")for(const r of originale.righe){f=await api("POST",`/api/fatture/${f.id}/righe`,{versione:f.versione,origine_credito_id:r.id,descrizione:r.descrizione,prezzo:(r.importo/100).toFixed(2),quantita:"1",aliquota:r.aliquota/100,natura:r.natura,esigibilita:r.esigibilita,riferimento_normativo:r.riferimento_normativo});}
    }
    await aggiorna();await apri(f.id);
  }
  async function nuovaRiga(f){
    let disponibili=[];
    if(f.originale_id){const orig=await api("GET",`/api/fatture/${f.originale_id}`);disponibili=orig.righe.map(r=>({id:r.id,descrizione:r.descrizione,disponibile:r.importo,credito:true,aliquota:r.aliquota,natura:r.natura,esigibilita:r.esigibilita}));}
    else disponibili=await api("GET","/api/fatture/fatturabili");
    disponibili=disponibili.filter(x=>f.tipo!=="TD01"||x.saldo_consentito);
    const origine=select([["","Riga libera"],...disponibili.map(r=>[r.id,(r.preventivo||"Fattura originaria")+" · "+r.descrizione+" · "+euros(r.disponibile)])]);
    const descr=input(),q=input("1"),prezzo=input("0.00"),ali=select(val.aliquote.map((r,i)=>[i,r.descrizione]));
    const standard=val.aliquote.findIndex(x=>x.aliquota===22&&x.esigibilita==="I"); if(standard>=0)ali.value=standard;
    if(!val.aliquote.length)throw new Error("Configura le aliquote IVA negli elenchi di valori.");
    origine.addEventListener("change",()=>{const r=disponibili.find(x=>String(x.id)===origine.value);if(r){descr.value=r.descrizione;prezzo.value=(r.disponibile/100).toFixed(2);q.value="1";if(r.credito){const i=val.aliquote.findIndex(x=>x.aliquota===r.aliquota/100&&x.natura===r.natura&&x.esigibilita===r.esigibilita);if(i>=0)ali.value=i;}}});
    const norm=input();
    const ok=await modale("Aggiungi prestazione",el("div",{class:"field-grid"},campo("Origine (facoltativa)",origine),campo("Descrizione",descr),campo("Quantità",q),campo("Prezzo unitario €",prezzo),campo("IVA",ali),campo("Riferimento normativo (IVA zero)",norm)),[{testo:"Annulla",valore:null},{testo:"Aggiungi",valore:true,classe:"primary"}]);
    if(!ok)return;
    const iva=val.aliquote[Number(ali.value)],r=disponibili.find(x=>String(x.id)===origine.value);
    await api("POST",`/api/fatture/${f.id}/righe`,{versione:f.versione,descrizione:descr.value,quantita:q.value,prezzo:prezzo.value,aliquota:iva.aliquota,natura:iva.natura,esigibilita:iva.esigibilita,riferimento_normativo:norm.value,...(r?{[r.credito?"origine_credito_id":"riga_preventivo_id"]:r.id}: {})});
    await aggiorna();await apri(f.id);
  }
  async function testa(f){
    const c=clientes(f.cliente_id),data=input(f.data,"date"),o=f.opzioni;
    const fields={causale:"Causale",iban:"IBAN (se diverso dalla società)",bollo:"Bollo €",ritenuta_percentuale:"Ritenuta %",ritenuta_tipo:"Tipo ritenuta",ritenuta_causale:"Causale ritenuta",dichiarazione_protocollo:"Protocollo dichiarazione di intento",dichiarazione_data:"Data dichiarazione di intento"};
    const inputs={};const corpo=el("div",{class:"field-grid"},campo("Intestatario fattura",c),campo("Data",data));
    // 0.14: modalità di pagamento (vuota = dal preventivo, poi dal cliente, poi la predefinita, come Garda)
    const mod=select([["","Automatica: preventivo → cliente → predefinita"],...val.modalita.filter(m=>m.attivo).map(m=>[m.id,m.descrizione])],o.modalita_pagamento_id||"");
    corpo.append(campo("Modalità di pagamento",mod,{pieno:true}));
    for(const [k,t] of Object.entries(fields)){inputs[k]=input(o[k]||"",k.startsWith("data_")||k==="dichiarazione_data"?"date":"text");corpo.append(campo(t,inputs[k]));}
    // 0.14 (Garda «documento emesso in seguito a»): ordini, contratti, convenzioni… con CIG, CUP e commessa
    const docs=[...(o.documenti||[]),...(o.ordine||o.cig||o.cup?[{tipo:"OrdineAcquisto",numero:o.ordine||"",data:o.data_ordine||"",cig:o.cig||"",cup:o.cup||""}]:[])];
    const nomiTipo={OrdineAcquisto:"Ordine d'acquisto",Contratto:"Contratto",Convenzione:"Convenzione",Ricezione:"Ricezione",FattureCollegate:"Fattura collegata",DDT:"Doc. di trasporto",FatturaPrincipale:"Fattura principale"};
    const righeDoc=el("div",{}),voci=[];
    const aggDoc=(d={})=>{const v={tipo:select(val.tipi_documento.map(x=>[x,nomiTipo[x]||x]),d.tipo||"OrdineAcquisto"),numero:input(d.numero||""),data:input(d.data||"","date"),cig:input(d.cig||""),cup:input(d.cup||""),commessa:input(d.commessa||""),attivo:true};
      const r=el("div",{class:"field-grid"},campo("Tipo",v.tipo),campo("Numero",v.numero),campo("Data",v.data),campo("CIG",v.cig),campo("CUP",v.cup),campo("Commessa / convenzione",v.commessa));
      r.append(btn("Togli",()=>{v.attivo=false;r.remove();}));voci.push(v);righeDoc.append(r);};
    docs.forEach(aggDoc);
    const sezioneDoc=el("div",{class:"riquadro"},el("h4",{},"Documento emesso in seguito a"),righeDoc,btn("Aggiungi documento",()=>aggDoc()));
    if(await modale("Dati del documento",el("div",{},corpo,sezioneDoc),[{testo:"Annulla",valore:null},{testo:"Salva",valore:true,classe:"primary"}])){
      const opzioni=Object.fromEntries(Object.entries(inputs).filter(([,v])=>v.value).map(([k,v])=>[k,v.value]));
      if(mod.value)opzioni.modalita_pagamento_id=mod.value;
      opzioni.documenti=voci.filter(v=>v.attivo&&v.numero.value).map(v=>({tipo:v.tipo.value,numero:v.numero.value,data:v.data.value,cig:v.cig.value,cup:v.cup.value,commessa:v.commessa.value}));
      await api("PUT",`/api/fatture/${f.id}`,{versione:f.versione,cliente_id:Number(c.value),data:data.value,opzioni});await aggiorna();await apri(f.id);
    }
  }
  async function scadenze(f){
    const wrap=el("div",{}),righe=el("div",{});let entries=[],ver=f.versione;
    const aggiungi=(d="",imp="",m="MP05")=>{const date=input(d,"date"),amount=input(imp),mode=select(MP,m),row=el("div",{class:"field-grid"},campo("Data",date),campo("Importo €",amount),campo("Modalità",mode));const e={date,amount,mode,active:true};entries.push(e);row.append(btn("Rimuovi",()=>{e.active=false;row.remove();}));righe.append(row);};
    const carica=(xs)=>{entries.forEach(e=>{e.active=false;});entries=[];righe.replaceChildren();xs.forEach(x=>aggiungi(x.data,(x.importo/100).toFixed(2),x.modalita));};
    carica(f.scadenze);
    if(f.tipo!=="TD04")wrap.append(el("p",{class:"subtle"},"Modalità: "+(f.modalita_pagamento?.descrizione||"—")+" ("+(f.modalita_pagamento?.provenienza||"")+")"),
      btn("Calcola dalla modalità di pagamento",async()=>{const g=await api("POST",`/api/fatture/${f.id}/scadenze/calcola`,{versione:ver});ver=g.versione;carica(g.scadenze);}));
    wrap.append(righe,btn("Aggiungi scadenza",()=>aggiungi(f.data)));
    if(await modale("Scadenze di pagamento",wrap,[{testo:"Annulla",valore:null},{testo:"Salva",valore:true,classe:"primary"}])){
      await api("PUT",`/api/fatture/${f.id}/scadenze`,{versione:ver,scadenze:entries.filter(e=>e.active).map(e=>({data:e.date.value,importo:e.amount.value,modalita:e.mode.value}))});
    }
    await aggiorna();await apri(f.id);
  }
  const MP=[["MP01","MP01 Contanti"],["MP02","MP02 Assegno"],["MP03","MP03 Assegno circolare"],["MP05","MP05 Bonifico"],["MP06","MP06 Vaglia cambiario"],["MP07","MP07 Bollettino bancario"],["MP08","MP08 Carta di pagamento"],["MP09","MP09 RID"],["MP10","MP10 RID utenze"],["MP11","MP11 RID veloce"],["MP12","MP12 RIBA"],["MP13","MP13 MAV"],["MP14","MP14 Quietanza erario"],["MP15","MP15 Giroconto su conti di contabilità speciale"],["MP16","MP16 Domiciliazione bancaria"],["MP17","MP17 Domiciliazione postale"],["MP18","MP18 Bollettino di c/c postale"],["MP19","MP19 SEPA Direct Debit"],["MP20","MP20 SEPA Direct Debit CORE"],["MP21","MP21 SEPA Direct Debit B2B"],["MP22","MP22 Trattenuta su somme già riscosse"],["MP23","MP23 PagoPA"]];
  async function ricevute(){
    const f=el("input",{type:"file",multiple:true,accept:".xml,.zip"});
    const ok=await modale("Ricevute dello SdI",el("div",{},el("p",{},"Scegli le ricevute scaricate da Aruba (XML o ZIP): consegna, scarto, mancata consegna, esito della PA, decorrenza termini. Ogni ricevuta aggiorna la sua fattura; la stessa ricevuta caricata due volte non cambia nulla."),f),[{testo:"Annulla",valore:null},{testo:"Carica",valore:true,classe:"primary"}]);
    if(!ok||!f.files.length)return;
    const fd=new FormData();for(const x of f.files)fd.append("file",x);
    const r=await fetch("/api/fatture/esiti/importa",{method:"POST",body:fd,headers:{"X-CSRF-Token":document.querySelector('meta[name="csrf"]')?.content||""}});
    const d=await r.json();if(!r.ok)throw new Error(d.errore||"Errore nel caricamento.");
    await modale("Esito del caricamento",table(["File","Fattura","Esito","Stato","Motivo"],d.risultati.map(x=>[x.file,x.fattura||"",x.esito||"",x.stato,x.motivo||""])),[{testo:"Chiudi",valore:true,classe:"primary"}]);
    await aggiorna();
  }
  async function apri(id){
    const f=await api("GET",`/api/fatture/${id}`),bozza=f.stato==="bozza",azioni=el("div",{class:"actions"});
    const run=async(path,d={})=>{await api("POST",`/api/fatture/${id}/${path}`,{versione:f.versione,...d});await aggiorna();await apri(id);};
    // C6 (0.16): numero e data sempre visibili (gg/mm/aaaa), prezzo, IVA e totale per riga, e cosa manca per emettere
    const dataIt=GAD.formatta.data(f.data);
    const corpo=el("div",{},el("h3",{},f.cliente),
      el("p",{},el("strong",{},`${val.tipi[f.tipo]} Nr. ${f.codice||"BOZZA"} del ${dataIt}`),` · ${f.stato}`),
      el("p",{},`Imponibile ${euros(f.imponibile)} · IVA ${euros(f.iva)} · Totale ${euros(f.totale)} · Da pagare ${euros(f.dovuto)}`),
      // rc8 (punto 6): l'avviso dice se mancano dati della società emittente o del cliente e porta alla sezione giusta
      ...((bozza&&f.mancanti&&f.mancanti.length)?[el("div",{class:"notice errore"},el("strong",{},"Prima di emettere manca: "),...(f.mancanti_dettaglio||f.mancanti.map(m=>({testo:m,url:""}))).map(m=>el("div",{class:"riga-mancante"},"• "+m.testo+" ",
        m.chi==="emittente"?(perm["sistema.impostazioni"]?el("a",{class:"btn small",href:m.url},"Completa i dati della società →"):el("span",{class:"subtle"},"(chiedi a chi gestisce la Configurazione di completarli)")):
        m.chi==="cliente"?el("a",{class:"btn small",href:m.url},"Apri la scheda del cliente →"):"")))]:[]),
      table(["Descrizione","Qtà","Prezzo","Importo","IVA",""],f.righe.map(r=>[r.descrizione,String(Number(r.quantita)).replace(".",","),"€ "+String(r.prezzo).replace(".",","),euros(r.importo),r.natura||((r.aliquota/100)+"%"),bozza&&perm["fatture.genera"]?btn("Elimina",()=>run(`righe/${r.id}/elimina`)):""])),
      ...(f.avvisi||[]).map(a=>el("div",{class:"notice"},a)),
      bozza&&f.tipo!=="TD04"?el("p",{class:"subtle"},"Pagamento: "+(f.modalita_pagamento?.descrizione||"rimessa diretta")+" ("+(f.modalita_pagamento?.provenienza||"")+")"+(f.scadenze.length?" · scadenze: "+f.scadenze.map(q=>q.data+" "+euros(q.importo)).join(", "):" · le scadenze si calcolano all'emissione")):"",
      azioni);
    if(perm["fatture.genera"] && bozza){azioni.append(btn("Dati documento",()=>testa(f)),btn("Aggiungi riga",()=>nuovaRiga(f)),btn("Scadenze",()=>scadenze(f)),btn(f.numero?"Riemetti XML":"Emetti e genera XML",async()=>{if(f.mancanti&&f.mancanti.length)throw new Error("Prima di emettere manca: "+f.mancanti.join("; ")+".");if(await GAD.conferma("Emettere il documento?","Il numero e la fotografia fiscale saranno conservati."))await run("emetti");},"primary"));}
    if(f.stato==="scartata"&&perm["fatture.genera"])azioni.append(btn("Correggi scarto",()=>run("correggi-scarto")));
    if(!['bozza','scartata'].includes(f.stato)&&f.tipo!=="TD04"&&perm["fatture.genera"])azioni.append(btn("Nota di credito",()=>nuovo(f)));
    azioni.append(el("a",{class:"btn",href:`/api/fatture/${f.id}/pdf`,target:"_blank",rel:"noopener"},"PDF di cortesia"));
    for(const e of f.esportazioni){corpo.append(el("p",{},el("a",{href:`/api/fatture/${f.id}/xml/${e.revisione}`,class:"btn"},"Scarica XML · tentativo "+e.revisione),(e.nome_file?" · "+e.nome_file:"")+" · "+(e.esiti.map(x=>x.esito+": "+x.messaggio).join("; ")||"nessuna ricevuta")));}
    GAD.pannello.apri(f.codice||"Bozza n. "+f.id,corpo,[],{largo:true});
  }
  async function movimento(x){
    const c=clientes(x?.cliente_id),d=input(x?.data||oggiLocale(),"date"),imp=input(x?(x.importo/100).toFixed(2):""),causale=input(x?.causale||""),wrap=el("div",{}),entries=[];
    const docs=await api("GET","/api/fatture");
    if(x){c.disabled=true;d.disabled=true;imp.disabled=true;causale.disabled=true;}
    const add=(fid=null,a="")=>{const choices=docs.filter(f=>f.cliente_id===Number(c.value)&&f.tipo!=="TD04"&&!['bozza','scartata'].includes(f.stato));if(!choices.length){toast("Nessuna fattura emessa per l'intestatario selezionato.");return;}const s=select(choices.map(f=>[f.id,f.codice+" · "+euros(f.residuo)]),fid),amount=input(a),row=el("div",{class:"field-grid"},campo("Fattura",s),campo("Importo associato €",amount));const e={s,amount,active:true};entries.push(e);row.append(btn("Rimuovi",()=>{e.active=false;row.remove();}));wrap.append(row);};
    c.addEventListener("change",()=>{entries.forEach(e=>{e.active=false;});wrap.replaceChildren();});
    if(x)x.allocazioni.forEach(a=>add(a.fattura_id,(a.importo/100).toFixed(2)));
    const corpo=el("div",{},campo("Pagatore / intestatario",c),campo("Data",d),campo("Importo movimento €",imp),campo("Causale",causale),wrap,btn("Associa una fattura",()=>add()));
    const ok=await modale(x?"Ripartisci incasso":"Registra incasso",corpo,[{testo:"Annulla",valore:null},{testo:"Salva",valore:true,classe:"primary"}]);if(!ok)return;
    const allocazioni=entries.filter(e=>e.active).map(e=>({fattura_id:Number(e.s.value),importo:e.amount.value}));
    if(x)await api("PUT",`/api/incassi/${x.id}/allocazioni`,{versione:x.versione,allocazioni});
    else await api("POST","/api/incassi",{societa_id:so.id,cliente_id:Number(c.value),data:d.value,importo:imp.value,causale:causale.value,allocazioni});
    toast("Incasso registrato.");await aggiorna();
  }
  async function apriIncasso(x){
    const body=el("div",{},el("p",{},`${x.data} · ${x.cliente} · ${euros(x.importo)} · ${x.causale}`),el("p",{},"Non associato: "+euros(x.non_associato)));
    if(!x.stornato&&perm["incassi.gestire"]){body.append(btn("Modifica ripartizione",()=>movimento(x)));const motivo=input();body.append(campo("Motivo dello storno",motivo),btn("Storna registrazione",async()=>{if(await GAD.conferma("Stornare l'incasso?","Le fatture torneranno aperte per gli importi associati.")){await api("POST",`/api/incassi/${x.id}/storna`,{versione:x.versione,motivo:motivo.value});await aggiorna();GAD.pannello.chiudi();}}));}
    GAD.pannello.apri("Incasso n. "+x.id,body);
  }
  async function configura(){
    const valori=await api("GET","/api/finanza/valori"),s=valori.societa.find(x=>x.codice==="AD"),fields={ragione_sociale:"Ragione sociale",partita_iva:"Partita IVA",codice_fiscale:"Codice fiscale",indirizzo:"Indirizzo",cap:"CAP",comune:"Comune",provincia:"Provincia",nazione:"Nazione",regime_fiscale:"Regime fiscale (RF01)",iban:"IBAN",banca:"Banca",id_trasmittente:"Identificativo trasmittente",rea_ufficio:"REA · ufficio (sigla provincia)",rea_numero:"REA · numero",capitale_sociale:"Capitale sociale €",socio_unico:"Socio unico (SU) o più soci (SM)",stato_liquidazione:"Liquidazione: LN no, LS sì",telefono:"Telefono",fax:"Fax",email:"Email"},inputs={},body=el("div",{class:"field-grid"});
    for(const [k,t] of Object.entries(fields)){inputs[k]=input(s.dati[k]||({nazione:"IT",regime_fiscale:"RF01",stato_liquidazione:"LN"}[k]||""));body.append(campo(t,inputs[k]));}
    if(await modale("Dati fiscali AD",body,[{testo:"Annulla",valore:null},{testo:"Salva",valore:true,classe:"primary"}])){await api("PUT",`/api/societa/${s.id}`,{versione:s.versione,dati:Object.fromEntries(Object.entries(inputs).map(([k,v])=>[k,v.value]))});toast("Dati salvati.");}
  }
  async function modalita(){
    const v=await api("GET","/api/finanza/valori");
    const lista=el("div",{},...v.modalita.map(m=>{const r=m.regole;return el("div",{class:"riquadro"},el("strong",{},m.descrizione+(r.predefinito?" · predefinita":"")),
      el("p",{class:"subtle"},`${r.mp} · rate: ${r.rate.map(q=>q.giorni+" gg"+(q.fine_mese?" f.m.":"")+" "+q.percentuale+"%").join(", ")}${r.fm_paga_dopo?" · paga il "+r.fm_paga_dopo+" del mese dopo":""}${r.sposta_scadenze?" · 31/8 e 31/12 → 10 del mese dopo":""}${r.salda_subito?" · salda subito":""}`),
      btn("Modifica",()=>regola(m)));}));
    await modale("Modalità di pagamento",el("div",{},el("p",{},"Come i «tipi di pagamento» di Garda: codice FatturaPA e rate. Le scadenze della fattura si calcolano dalla modalità del preventivo, poi del cliente, poi dalla predefinita."),lista),[{testo:"Chiudi",valore:true}]);
  }
  async function regola(m){
    const r=m.regole,mp=select(MP,r.mp),fm=input(r.fm_paga_dopo||"","number"),sp=el("input",{type:"checkbox"}),ss=el("input",{type:"checkbox"}),pr=el("input",{type:"checkbox"});
    sp.checked=!!r.sposta_scadenze;ss.checked=!!r.salda_subito;pr.checked=!!r.predefinito;
    const rate=el("div",{}),voci=[];
    const agg=(q={giorni:30,percentuale:"100",fine_mese:false})=>{const v={g:input(q.giorni,"number"),p:input(q.percentuale),f:el("input",{type:"checkbox"}),attivo:true};v.f.checked=!!q.fine_mese;const riga=el("div",{class:"field-grid"},campo("Giorni",v.g),campo("% del totale",v.p),el("label",{class:"check"},v.f,"Fine mese"));riga.append(btn("Togli",()=>{v.attivo=false;riga.remove();}));voci.push(v);rate.append(riga);};
    r.rate.forEach(agg);
    const corpo=el("div",{},el("div",{class:"field-grid"},campo("Codice FatturaPA",mp),campo("Con «fine mese» paga il giorno del mese dopo (vuoto = ultimo del mese)",fm)),
      ...[[sp,"Sposta le scadenze del 31/8 e del 31/12 al 10 del mese dopo"],[ss,"Salda subito il documento con questo pagamento (es. contanti, carta)"],[pr,"Predefinita (quando preventivo e cliente non ne indicano una)"]].map(([c,t])=>el("div",{},el("label",{class:"check"},c,t))),
      el("h4",{},"Rate"),rate,btn("Aggiungi rata",()=>agg({giorni:60,percentuale:"",fine_mese:true})));
    if(!await modale(m.descrizione,corpo,[{testo:"Annulla",valore:null},{testo:"Salva",valore:true,classe:"primary"}]))return;
    await api("PUT",`/api/finanza/modalita/${m.id}/regole`,{versione:m.versione,regole:{mp:mp.value,fm_paga_dopo:fm.value||null,sposta_scadenze:sp.checked,salda_subito:ss.checked,predefinito:pr.checked,rate:voci.filter(v=>v.attivo).map(v=>({giorni:Number(v.g.value||0),percentuale:v.p.value,fine_mese:v.f.checked}))}});
    toast("Regole salvate.");Object.assign(val,await api("GET","/api/finanza/valori"));
  }
  for(const [id,allowed,fn] of [["nuova-fattura",perm["fatture.genera"],()=>nuovo()],["nuovo-incasso",perm["incassi.gestire"],()=>movimento()],["configura-societa",false,configura],["modalita-pagamento",false,modalita]]){const b=document.getElementById(id);if(!b)continue;b.hidden=!allowed;b.onclick=()=>fn().catch(errore);}
  document.getElementById("ricarica-finanza").onclick=()=>aggiorna().catch(errore);
  document.getElementById("solo-scadute").onchange=()=>aggiorna().catch(errore);
  document.getElementById("ricerca-fatture").onkeydown=e=>{if(e.key==="Enter")aggiorna().catch(errore);};
  await aggiorna();
  // N7 (0.12.8): /fatture?apri=<id> apre la fattura (es. la bozza appena creata dalle righe dei preventivi)
  const daAprire=new URLSearchParams(location.search).get("apri");
  if(daAprire&&/^\d+$/.test(daAprire)){history.replaceState(null,"",location.pathname);await apri(Number(daAprire));}
})().catch(GAD.errore);
