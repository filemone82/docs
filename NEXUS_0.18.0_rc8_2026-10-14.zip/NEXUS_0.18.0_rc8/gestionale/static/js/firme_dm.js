/* Firme dei verificatori (rc8, punto 3): una sola pagina per AD_DPR e AD_DM. Per ogni verificatore: dati del tecnico,
   firma DPR (archivio dei verbali, la usa il verbale DPR) e firma DM (la usa il verbale DM).
   Prima della rc8 le firme DPR erano in VerbalizzAI (Configurazione › Firme dei verificatori) e queste solo DM (C16, 0.16). */
"use strict";

(async () => {
  const { el, api, errore } = GAD;
  const S = GAD.schede;
  await S.me();
  const box = document.getElementById("griglia");
  const elenco = new Map();
  const aggiungi = (lista, attivita) => { for (const v of lista || []) elenco.set(v.id, { ...v, attivita: [...(elenco.get(v.id)?.attivita || []), attivita] }); };
  try { aggiungi((await api("GET", "/api/verifiche/valori")).verificatori, "DPR"); } catch (_) { /* nessun permesso DPR */ }
  try { aggiungi((await api("GET", "/api/dm/incarichi/valori")).verificatori, "DM"); } catch (_) { /* nessun permesso DM */ }
  if (!elenco.size) { box.replaceChildren(el("p", { class: "notice" }, "Nessun verificatore: assegna un ruolo di verificatore DPR o DM in Gestione › Utenti e permessi.")); return; }
  box.replaceChildren(el("p", { class: "subtle" }, "Ogni verificatore: dati stampati nei verbali, firma DPR e firma DM. Senza la firma della sua attività il verbale non si emette."));
  for (const v of [...elenco.values()].sort((a, b) => a.nome.localeCompare(b.nome))) {
    const riquadro = el("details", { class: "riquadro" }, el("summary", {}, `${v.nome} · ${v.attivita.join(" e ")}`));
    riquadro.addEventListener("toggle", async () => {
      if (!riquadro.open || riquadro.dataset.caricato) return;
      riquadro.dataset.caricato = "1";
      try { riquadro.append(await S.datiTecnico(v.id)); } catch (e) { errore(e); }
    });
    box.append(riquadro);
  }
})().catch((e) => GAD.errore(e));
