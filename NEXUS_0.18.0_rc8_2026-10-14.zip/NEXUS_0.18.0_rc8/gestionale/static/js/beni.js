"use strict";
(async () => {
  const {el, api, campo, errore, toast, pannello, formatta, conferma} = GAD;
  const root = document.getElementById("parco");
  const puo = {gestire: root.dataset.gestire === "si", date: root.dataset.date === "si", dismetti: root.dataset.dismetti === "si"};
  let catalogo, pagina = 1, totale = 0;
  const labelComp = {funzionamento: "Funzionamento", integrita: "Integrità", interna: "Visita interna", cnd: "CND", scsp: "Verifica SC/SP", supplementare: "Indagine supplementare", taratura: "Taratura", dpr: "Verifica DPR"};
  function input(tipo, valore = "") { const x = el("input", {type: tipo}); x.value = valore ?? ""; return x; }
  function select(voci, valore = "", vuoto = "Non indicato") {
    const x = el("select", {}, el("option", {value: ""}, vuoto), ...voci.map(v => el("option", {value: v.id ?? v}, v.testo ?? v)));
    x.value = valore ?? ""; return x;
  }
  function bottone(testo, f, classe = "btn") { return el("button", {type: "button", class: classe, onclick: async (e) => {
    const b = e.currentTarget; b.disabled = true; try { await f(); } catch (ex) { errore(ex); } finally { b.disabled = false; }
  }}, testo); }
  function tabella(titoli, righe) { return el("table", {class: "tabella-semplice"}, el("thead", {}, el("tr", {}, titoli.map(x => el("th", {}, x)))), el("tbody", {}, righe.map(xs => el("tr", {}, xs.map(x => el("td", {}, x)))))); }
  let griglia = null;  // 0.12.5: «Attrezzature» e «Valvole di sicurezza» sono elenchi come gli altri (R117)
  async function carica() {
    if (root.dataset.griglia) {
      if (griglia) return griglia.ricarica();
      griglia = await GAD.griglia(document.getElementById("griglia"), root.dataset.griglia, {suRiga: (r) => apri(r.id).catch(errore)});
      return;
    }
    const par = new URLSearchParams({q: document.getElementById("ricerca-beni").value, gruppo: document.getElementById("gruppo-beni").value,
      solo_attivi: document.getElementById("attivi-beni").checked, pagina});
    const d = await api("GET", "/api/beni?" + par); totale = d.totale;
    document.getElementById("riepilogo-beni").textContent = `${totale} beni · pagina ${pagina}`;
    document.getElementById("lista-beni").replaceChildren(tabella(["Gruppo", "Bene / matricola", "Cliente", "Sede", "Stato", ""],
      d.righe.map(a => [a.gruppo, [a.denominazione, a.matricola].filter(Boolean).join(" · ") || `Impianto ${a.id}`, a.cliente, a.sede,
        a.dismesso ? "Dismesso" : a.attivo ? "Attivo" : "Sede/cliente inattivo", bottone("Apri", () => apri(a.id))])));
    document.getElementById("pagina-prima").disabled = pagina <= 1;
    document.getElementById("pagina-dopo").disabled = pagina * 50 >= totale;
  }
  async function mostraRisultato(a) { toast("Salvato"); await carica(); await apri(a.id); }
  function storico(id) { return bottone("Storico", async () => {
    const d = await api("GET", `/api/storico/asset/${id}`);
    await GAD.modale("Storico del bene", tabella(["Quando", "Utente", "Operazione"], d.map(x => [formatta.dataora(x.quando), x.utente, x.descrizione])));
  }); }
  async function apri(id) {
    const a = await api("GET", `/api/beni/${id}`);
    const corpo = el("div", {}, el("p", {}, `${a.gruppo} · ${a.cliente} · ${a.sede}`),
      el("p", {}, `${a.denominazione} · ${a.matr_informale || ""}`), el("p", {}, a.dismesso ? "Bene dismesso" : "Bene attivo"));
    const azioni = [storico(a.id)];
    if (a.gruppo === "DPR") {
      corpo.append(el("p", {}, "Questo impianto si gestisce dalla scheda DPR. I dati qui si aggiornano automaticamente."));
      azioni.push(bottone("Apri impianto DPR", () => {location.href = `/impianti?apri=${a.impianto_dpr_id}`;}));
    } else {
      const tipo = catalogo.tipi_attrezzature.find(x => x.id === a.tipo_attr_id), spec = catalogo.id_specifiche.find(x => x.id === a.id_spec_id);
      corpo.append(...a.avvisi.map(t=>el("p",{class:"notice avviso"},t)));
      corpo.append(el("p", {}, "Apparecchi all. 7: " + (tipo ? `${tipo.codice} · ${tipo.descrizione}` : "Non indicato")),
        el("p", {}, "ID specifica: " + (spec ? `${spec.codice} · ${spec.descrizione}` : "Non indicata")), el("p", {}, a.note || ""));
      if (puo.gestire) azioni.push(bottone("Modifica scheda", () => modifica(a)));
      if (puo.dismetti) azioni.push(bottone(a.dismesso ? "Riattiva" : "Dismetti", async () => {
        const motivo = input("text");
        const ok = await GAD.modale(a.dismesso ? "Riattiva bene" : "Dismetti bene", campo("Motivo", motivo), [{testo:"Annulla", valore:false},{testo:"Conferma",valore:true,classe:"primary"}]);
        if (ok) await mostraRisultato(await api("POST", `/api/beni/${a.id}/dismesso`, {versione:a.versione, dismesso:!a.dismesso, motivo:motivo.value}));
      }));
    }
    corpo.append(el("h2", {}, "Date tecniche"), tabella(["Attività", "Ultima", "Prossima", "Report / verbale", "Fonte", ""], a.scadenze.map(x => [labelComp[x.componente], formatta.data(x.data_ultima), formatta.data(x.data_prossima), x.numero_report, x.fonte,
      a.gruppo !== "DPR" && puo.date ? bottone("Modifica", () => modificaData(a, x)) : ""])));
    if (a.gruppo !== "DPR" && puo.date) corpo.append(bottone("Registra data tecnica", () => modificaData(a)));
    if (a.gruppo === "GVR") {
      corpo.append(el("h2", {}, "Camere e tubazioni"), el("p", {}, `Volume totale: ${a.volume_totale_litri} L · i DN sono esclusi dalla somma.`),
        tabella(["Identificazione", "N. fabbrica", "Volume / DN", ""], a.camere.map(x => [x.identificazione, x.num_fabbrica, `${x.valore} ${x.unita === "DN" ? "DN (mm)" : "L"}`, puo.gestire ? bottone("Modifica", () => modificaCamera(a, x)) : ""])));
      if (puo.gestire) corpo.append(bottone("Aggiungi camera / tubazione", () => modificaCamera(a)));
      corpo.append(el("h2", {}, "Valvole associate"), el("p", {}, `Taratura accessori: ultima ${formatta.data(a.taratura_accessori.data_ultima) || "—"} · prossima ${formatta.data(a.taratura_accessori.data_prossima) || "—"}`),
        tabella(["Matricola", ""], a.accessori.map(x => [bottone(x.matricola, () => apri(x.id)), puo.gestire ? bottone("Rimuovi associazione", async () => {
          if (await conferma("Rimuovi associazione", "Rimuovere questa valvola dall’attrezzatura? La scheda della valvola rimane.")) await mostraRisultato(await api("DELETE", `/api/beni/${a.id}/accessori`, {versione:a.versione,accessorio_id:x.id}));
        }) : ""])));
      if (puo.gestire) corpo.append(bottone("Associa valvola esistente", () => associa(a)),
        bottone("＋ Nuovo accessorio per questa attrezzatura", () => modificaAccessorio(null, {sede_id: a.sede_id, protegge: a.id, dopo: async () => { await carica(); await apri(a.id); }})));
    }
    if(a.gruppo!=="DPR") {
      const ident=el("div"),cls=el("div"),caratt=el("div"),date=el("div"),altro=el("div");
      let target=ident;
      for(const node of [...corpo.children]) {
        if(node.tagName==="H2") {if(node.textContent==="Date tecniche")target=date;else target=caratt;}
        if(node.tagName==="P" && (node.textContent.startsWith("Apparecchi all. 7:")||node.textContent.startsWith("ID specifica:"))) {cls.append(node);continue;}
        target.append(node);
      }
      for(const cfg of a.campi_dm) {
        const v=a.attributi[cfg.nome];
        if(v===undefined||v===null||v==="")continue;
        const txt=cfg.tipo==="enum" ? cfg.valori[v] : cfg.tipo==="booleano" ? (v ? "Sì":"No") : String(v);
        (cfg.nome==="tipo_attr_verbale" ? cls : ["cf_costr","descr_attr","reparto","rif_interno","marcatura_ce","esente_verifiche","tipo_prox_verifica"].includes(cfg.nome) ? ident : caratt).append(el("p",{},el("strong",{},cfg.etichetta+": "),txt));
      }
      for(const [k,label] of Object.entries({num_fabbrica:"Numero fabbrica",costruttore:"Costruttore",modello:"Modello",anno_costruzione:"Anno costruzione"}))ident.append(el("p",{},`${label}: ${a[k]??"—"}`));
      if(a.gruppo!=="PSV")ident.append(el("p",{},`Matricola: ${a.anno_matricola}/${a.cod_att_matricola}/${a.num_matricola}/${a.prov_immatr}`));
      else ident.append(el("h3",{},"Protegge"),a.protegge.length?tabella(["Attrezzatura GVR",""],a.protegge.map(x=>[[x.matricola,x.denominazione].filter(Boolean).join(" · "),bottone("Apri",()=>apri(x.id))])):el("p",{class:"subtle"},"Nessuna attrezzatura collegata: si collega dalla scheda dell'attrezzatura GVR («Associa valvola esistente»)."));
      const fam=catalogo.famiglie_gvr.find(x=>x.id===a.tipo_attr_gvr_id);
      cls.append(el("p",{},`Codici INAIL: all.7 ${catalogo.tipi_attrezzature.find(x=>x.id===a.tipo_attr_id)?.codice||"—"} · famiglia ${fam?.codice||"—"} · ID specifica ${catalogo.id_specifiche.find(x=>x.id===a.id_spec_id)?.codice||"—"}`));
      altro.append(el("p",{},a.note||"Nessuna nota"));
      // 0.13.0 (R123): dati del verbale che sono attributi dell'attrezzatura, con provenienza, correzione e storico
      const datiVerbale=el("div",{},el("p",{class:"subtle"},"Caricamento…"));
      const caricaDatiVerbale=async()=>{
        const x=await api("GET",`/api/dm/attrezzature/${a.id}/dati-verbale`);
        const def=x.definizioni, valore=(k,v)=>def[k]?.tipo==="boolean"?(v?"Sì":"No"):(v===null||v===undefined||v===""?"—":String(v));
        const origine=(v)=>!v?"Nessun verbale precedente: si compila nel prossimo verbale.":v.origine==="manuale"
          ?`Corretto a mano il ${formatta.data(v.data)}${v.da?` da ${v.da}`:""}${v.nota?` · ${v.nota}`:""}`
          :`Dal verbale ${v.codice||"n. "+v.incarico_id} del ${formatta.data(v.data)}`;
        datiVerbale.replaceChildren(el("p",{class:"subtle"},"Ogni nuovo verbale riparte da qui, solo nelle parti pertinenti alle attività verificate. Breve descrizione e camere sono in «Caratt. GVR». Pes, Tes, prove eseguite, esito e date restano nel singolo verbale."),
          ...x.gruppi.filter(g=>g.pertinente).map(g=>el("div",{class:"riquadro"},el("h3",{},g.titolo),el("p",{class:"subtle"},origine(g.valore)),
            ...g.campi.map(k=>el("p",{},el("strong",{},(def[k]?.etichetta||k)+": "),valore(k,g.valore?.campi?.[k]))),
            puo.gestire||puo.date?bottone("Correggi",()=>correggiDatiVerbale(a,g,def).then(caricaDatiVerbale)):null)),
          x.storico.length?el("details",{},el("summary",{},`Storico delle correzioni (${x.storico.length})`),tabella(["Quando","Chi","Parte","Riferimento","Nota"],
            x.storico.map(r=>[formatta.dataora(r.il),r.da,(x.gruppi.find(g=>g.codice===r.gruppo)||{}).titolo||r.gruppo,formatta.data(r.data),r.nota||""]))):null);
      };
      if(a.gruppo==="PSV"){corpo.append(GAD.schede.linguette([{titolo:"Accessorio",contenuto:ident},{titolo:"Taratura",contenuto:date},{titolo:"Altro",contenuto:altro}]));pannello.apri(`Accessorio ${a.matr_informale||a.id}`,corpo,azioni,{largo:true});return;}
      corpo.append(GAD.schede.linguette([{titolo:"Identificazione",contenuto:ident},{titolo:"Class. INAIL",contenuto:cls},{titolo:a.gruppo==="GVR" ? "Caratt. GVR":"Caratt. SC/SP",contenuto:caratt},{titolo:a.gruppo==="GVR" ? "Verifiche GVR":"Verifiche SC/SP",contenuto:date},{titolo:"Dati del verbale",contenuto:datiVerbale,apri:()=>caricaDatiVerbale().catch(errore)},{titolo:"Altro",contenuto:altro}]));
    }
    pannello.apri(`${a.gruppo} ${a.matr_informale||a.id}`, corpo, azioni, {largo:true});
  }
  async function correggiDatiVerbale(a,g,def){
    const campi={};
    const righe=g.campi.map(k=>{const v=g.valore?.campi?.[k];const d=def[k]||{};
      const x=d.tipo==="boolean"?el("input",{type:"checkbox"}):d.area?el("textarea",{rows:"3"}):el("input",{type:"text"});
      if(d.tipo==="boolean")x.checked=!!v;else x.value=v??"";campi[k]=x;return campo(d.etichetta||k,x);});
    const oggi=new Date(),rif=input("date",`${oggi.getFullYear()}-${String(oggi.getMonth()+1).padStart(2,"0")}-${String(oggi.getDate()).padStart(2,"0")}`),nota=input("text");
    const ok=await GAD.modale(`Correggi · ${g.titolo}`,[el("p",{class:"subtle"},"La correzione vale per i prossimi verbali, finché un verbale più recente della data di riferimento non la aggiorna. Resta nello storico."),...righe,campo("Data di riferimento",rif),campo("Nota (facoltativa)",nota)],
      [{testo:"Annulla",valore:false},{testo:"Salva",valore:true,classe:"primary"}]);
    if(!ok)return;
    await api("PUT",`/api/dm/attrezzature/${a.id}/dati-verbale/${g.codice}`,{campi:Object.fromEntries(Object.entries(campi).map(([k,x])=>[k,x.type==="checkbox"?x.checked:x.value])),data_riferimento:rif.value,nota:nota.value});
    toast("Dati del verbale corretti.");
  }
  // C10 (0.16): un solo campo «Sede» con suggerimenti mentre si scrive; prima le sedi AD_DM, se nessuna tutte
  function sceltaSede(scelta) {
    return GAD.schede.ricerca({
      cerca: async (t) => { const q = encodeURIComponent(t); const dm = await api("GET", `/api/sedi/cerca?ambito=DM&q=${q}`); return dm.length ? dm : api("GET", `/api/sedi/cerca?q=${q}`); },
      mostra: (s) => [s.denominazione, [s.cliente, s.comune].filter(Boolean).join(" · ")],
      scelto: scelta, segnaposto: "Scrivi il nome della sede, del cliente o il comune…",
    });
  }
  // C7 (0.16): da un elenco filtrato per sede (o dalla scheda di un'attrezzatura) la sede è già scelta
  async function sedeIniziale(id) {
    id = id || GAD.schede.daFiltro("sede_id");
    if (!id) return null;
    try { const s = await api("GET", `/api/sedi/${id}`); return { id: s.id, denominazione: s.denominazione, cliente: s.cliente, comune: s.comune }; }
    catch (e) { return null; }
  }
  const famigliaConInterna = (id) => ["a2", "a3"].includes(catalogo.famiglie_gvr.find(x => x.id === Number(id))?.codice);
  // R142 (0.16): alla registrazione la prossima verifica è obbligatoria, così l'attrezzatura entra nelle Scadenze
  function sezioneDate() {
    const box = el("div", {class: "riquadro"}), righe = {};
    function disegna(gruppo, famigliaId, tipoId) {
      const t = catalogo.tipi_attrezzature.find(x => x.id === Number(tipoId)), prevista = (v) => !t || !["", "N.A.", "NA", "N.A"].includes(String(v ?? "").trim().toUpperCase());
      const comp = gruppo === "GVR" ? [...(prevista(t?.tipo_ver_gvr_1) ? ["funzionamento"] : []), ...(prevista(t?.tipo_ver_gvr_2) ? ["integrita"] : []), ...(famigliaConInterna(famigliaId) ? ["interna"] : [])] : ["SC", "SP"].includes(gruppo) ? ["scsp"] : [];
      const vecchi = Object.fromEntries(Object.entries(righe).map(([k, r]) => [k, {u: r.u.value, p: r.p.value, n: r.n.value}]));
      for (const k of Object.keys(righe)) delete righe[k];
      box.replaceChildren(el("h3", {}, "Ultima e prossima verifica"),
        el("p", {class: "subtle"}, comp.length ? "La prossima verifica è obbligatoria: senza, l'attrezzatura non compare nelle Scadenze. Ultima data e riferimento sono facoltativi. Dal primo verbale emesso in NEXUS le date si aggiornano da sole." : "Scegli prima il gruppo."));
      for (const c of comp) {
        const r = {u: input("date", vecchi[c]?.u), p: input("date", vecchi[c]?.p), n: input("text", vecchi[c]?.n)};
        r.n.placeholder = "es. verbale 123/24 di AD, altro organismo, INAIL"; r.p.required = true;
        righe[c] = r;
        box.append(el("div", {class: "field-grid"}, campo(`${labelComp[c]} · ultima`, r.u), campo(`${labelComp[c]} · riferimento`, r.n), campo(`${labelComp[c]} · prossima *`, r.p)));
      }
    }
    return {el: box, disegna, valori: () => Object.fromEntries(Object.entries(righe).map(([c, r]) => [c, {data_ultima: r.u.value || null, data_prossima: r.p.value || null, numero_report: r.n.value}]))};
  }
  async function modifica(a = null, opz = {}) {
    if ((a?.gruppo || opz.gruppo || root.dataset.gruppo) === "PSV") return modificaAccessorio(a, opz);
    const nuovo = !a, form = el("div", {class:"field-grid"}), classificazione=el("div",{class:"field-grid"}),tecnici=el("div",{class:"field-grid"}),altro=el("div",{class:"field-grid"}),identExtra=el("div",{class:"field-grid"}),clsExtra=el("div",{class:"field-grid"});
    // C9 (0.16): dalla sezione GVR il gruppo è GVR; da SC/SP si sceglie fra SC e SP; le PSV hanno la loro maschera
    const modo = opz.gruppo || root.dataset.gruppo || "";
    const ammessi = modo === "GVR" ? ["GVR"] : modo === "SCSP" ? ["SC", "SP"] : ["GVR", "SC", "SP"];
    const gruppo = select(ammessi.map(g => ({id: g, testo: g === "GVR" ? "GVR · attrezzature a pressione" : g === "SC" ? "SC · sollevamento cose" : "SP · sollevamento persone"})),
      a?.gruppo ?? (ammessi.length === 1 ? ammessi[0] : ""), "Scegli SC o SP");
    if (a) gruppo.replaceChildren(el("option", {value: a.gruppo}, a.gruppo));
    gruppo.value = a?.gruppo ?? (ammessi.length === 1 ? ammessi[0] : "");
    gruppo.disabled = !nuovo || ammessi.length === 1;
    const sede = sceltaSede(a ? {id: a.sede_id, denominazione: a.sede, cliente: a.cliente} : await sedeIniziale(opz.sede_id));
    form.append(campo("Gruppo", gruppo), campo("Sede operativa", sede.el, {pieno: true}));
    const campi={};
    for (const [key,nome] of Object.entries({denominazione:"Denominazione",matr_informale:"Matricola informale",anno_matricola:"Anno matricola",cod_att_matricola:"Attività matricola",num_matricola:"Numero matricola",prov_immatr:"Provincia matricola",num_fabbrica:"Numero fabbrica",costruttore:"Costruttore",modello:"Modello",anno_costruzione:"Anno costruzione"})) {
      campi[key]=input(key==="anno_costruzione" ? "number" : "text",a?.[key]);form.append(campo(nome,campi[key]));
    }
    const famiglia=select([],a?.tipo_attr_gvr_id),tipo=select([],a?.tipo_attr_id),spec=select([],a?.id_spec_id);
    const messa=select([{id:"si",testo:"Sì · soggetta (art. 4 D.M. 329/04)"},{id:"no",testo:"No · non soggetta (art. 5 D.M. 329/04)"}],a?.soggetto_messa_servizio===true ? "si" : a?.soggetto_messa_servizio===false ? "no" : "");
    const fm=campo("Famiglia GVR",famiglia), ms=campo("Soggetta a messa in servizio (D.M. 329/04)",messa), ft=campo("Apparecchi all. 7",tipo), fs=campo("ID specifica",spec);
    classificazione.append(ft,fm,fs);tecnici.append(ms);famiglia.disabled=true;
    const date = nuovo ? sezioneDate() : null;
    function opzioni(x,rows,corrente) { x.replaceChildren(el("option", {value:""},"Non indicato"), ...rows.map(v=>el("option",{value:v.id},`${v.codice} · ${v.descrizione}`)));x.value=corrente ?? ""; }
    function aggiornaSpec() {
      if(gruppo.value==="GVR") famiglia.value=catalogo.tipi_attrezzature.find(x=>x.id===Number(tipo.value))?.famiglia_gvr_id??"";
      const allowed=catalogo.compatibilita.filter(x=>x.gruppo===gruppo.value && (gruppo.value==="GVR" ? x.famiglia_gvr_id===Number(famiglia.value) : x.tipo_attr_id===Number(tipo.value))).map(x=>x.id_spec_id);
      opzioni(spec,catalogo.id_specifiche.filter(x=>allowed.includes(x.id)),spec.value);
      date?.disegna(gruppo.value, famiglia.value, tipo.value);
    }
    function aggiornaTipo() {
      opzioni(tipo,catalogo.tipi_attrezzature.filter(x=>x.gruppo===gruppo.value),tipo.value);
      aggiornaSpec();
    }
    const datiDM={};
    function disegnaDM() {
      identExtra.replaceChildren();clsExtra.replaceChildren();tecnici.replaceChildren(ms);
      for(const k of Object.keys(datiDM))delete datiDM[k];
      for(const d of catalogo.schede_dm[gruppo.value]||[]) {
        const value=a?.attributi?.[d.nome] ?? (d.nome==="esente_verifiche" ? "F":"");
        const x=d.tipo==="enum" ? select(Object.entries(d.valori).map(([k,v])=>({id:k,testo:v})),value) : d.tipo==="booleano" ? select([{id:"si",testo:"Sì"},{id:"no",testo:"No"}],value===true ? "si" : value===false ? "no":"") : d.tipo==="area" ? el("textarea",{}) : input(d.tipo==="intero" ? "number":"text",value);
        if(d.tipo==="area")x.value=value;
        if(d.massimo)x.maxLength=d.massimo;
        datiDM[d.nome]={x,d};
        (d.nome==="tipo_attr_verbale" ? clsExtra : ["cf_costr","descr_attr","reparto","rif_interno","marcatura_ce","esente_verifiche","tipo_prox_verifica"].includes(d.nome) ? identExtra : tecnici).append(campo(d.etichetta,x));
      }
      if (date) identExtra.append(el("div", {class: "pieno"}, date.el));
    }
    function aggiornaGruppo() {
      disegnaDM();
      fm.hidden=ms.hidden=gruppo.value!=="GVR";
      opzioni(famiglia,catalogo.famiglie_gvr,famiglia.value);aggiornaTipo();
    }
    gruppo.onchange=aggiornaGruppo;famiglia.onchange=aggiornaTipo;tipo.onchange=aggiornaSpec;
    aggiornaGruppo();famiglia.value=a?.tipo_attr_gvr_id??"";aggiornaTipo();tipo.value=a?.tipo_attr_id??"";aggiornaSpec();spec.value=a?.id_spec_id??"";
    const note=el("textarea",{});note.value=a?.note||"";altro.append(campo("Note",note,{pieno:true}));
    const contenuto=GAD.schede.linguette([{titolo:"Identificazione",contenuto:el("div",{},form,identExtra)},{titolo:"Class. INAIL",contenuto:el("div",{},classificazione,clsExtra)},{titolo:"Caratteristiche",contenuto:tecnici},{titolo:"Altro",contenuto:altro}]);
    const titolo = nuovo ? (ammessi.length === 1 ? "Nuova attrezzatura GVR" : modo === "SCSP" ? "Nuova attrezzatura SC/SP" : "Nuova attrezzatura") : `Modifica ${a.gruppo} ${a.matr_informale}`;
    pannello.apri(titolo,contenuto,[bottone("Salva",async()=>{
      if (!sede.valore) throw new Error("Scegli la sede operativa.");
      const d={gruppo:gruppo.value,sede_id:sede.valore.id,note:note.value};for(const [k,x] of Object.entries(campi))d[k]=x.value;
      d.tipo_attr_id=tipo.value;d.id_spec_id=spec.value;
      if (gruppo.value==="GVR") {d.tipo_attr_gvr_id=famiglia.value;d.soggetto_messa_servizio=messa.value==="si" ? true : messa.value==="no" ? false : null;}
      if(Object.keys(datiDM).length) {d.dati_dm={};for(const [k,{x,d:cfg}] of Object.entries(datiDM))d.dati_dm[k]=cfg.tipo==="booleano" ? (x.value==="si" ? true : x.value==="no" ? false:null) : x.value;}
      if (date) d.date_iniziali = date.valori();
      if(a)d.versione=a.versione;
      await mostraRisultato(await api(nuovo ? "POST" : "PUT",nuovo ? "/api/beni" : `/api/beni/${a.id}`,d));
    },"btn primary")],{largo:true});
  }
  // R141 (0.16): accessori di sicurezza (PSV, dischi di rottura, valvole di intercettazione) con maschera propria,
  // senza matricola INAIL; protegge una o più attrezzature GVR della stessa sede
  async function modificaAccessorio(a = null, opz = {}) {
    const nuovo = !a, cfg = Object.fromEntries((catalogo.schede_dm.PSV || []).map(d => [d.nome, d]));
    const sede = sceltaSede(a ? {id: a.sede_id, denominazione: a.sede, cliente: a.cliente} : await sedeIniziale(opz.sede_id));
    const v = (k) => a?.attributi?.[k] ?? "";
    const tip = select(Object.entries(cfg.tip_accessorio?.valori || {}).map(([k, t]) => ({id: k, testo: t})), v("tip_accessorio") || (nuovo ? "valvola di sicurezza" : ""), "Scegli la tipologia");
    const ident = input("text", a?.matr_informale), costr = input("text", a?.costruttore), mod = input("text", a?.modello);
    const dn = input("text", v("dn")), diam = input("text", v("diametro")), area = input("text", v("area")), ptar = input("text", v("ptar"));
    const note = el("textarea", {}); note.value = a?.note || "";
    const corpo = el("div", {class: "field-grid"}, campo("Sede operativa", sede.el, {pieno: true}), campo("Tipologia", tip),
      campo("Identificativo (n. di serie o targhetta)", ident), campo("Costruttore", costr), campo("Modello", mod),
      campo("DN", dn), campo("Diametro", diam), campo("Area", area), campo("Pressione di taratura (Ptar)", ptar), campo("Note", note, {pieno: true}));
    corpo.prepend(el("p", {class: "subtle pieno"}, "Gli accessori di sicurezza non hanno matricola INAIL: appartengono alla sede e proteggono una o più attrezzature GVR."));
    let tarU, tarP, scelteGvr = null;
    if (nuovo) {
      tarU = input("date"); tarP = input("date");
      corpo.append(campo("Taratura · ultima", tarU), campo("Taratura · prossima", tarP));
      const boxGvr = el("div", {class: "pieno"});
      scelteGvr = new Map();
      const caricaGvr = async () => {
        scelteGvr.clear();
        if (!sede.valore) { boxGvr.replaceChildren(el("p", {class: "subtle"}, "Scegli la sede per vedere le sue attrezzature GVR.")); return; }
        const d = await api("GET", `/api/beni?gruppo=GVR&sede_id=${sede.valore.id}&per_pagina=500`);
        boxGvr.replaceChildren(el("strong", {}, "Protegge le attrezzature GVR"), ...(d.righe.length ? d.righe.filter(r => !r.dismesso).map(r => {
          const c = el("input", {type: "checkbox"}); c.checked = Number(opz.protegge) === r.id; scelteGvr.set(r.id, c);
          return el("label", {class: "check-row"}, c, ` ${r.matricola || ""} · ${r.denominazione || ""}`);
        }) : [el("p", {class: "subtle"}, "Nessuna attrezzatura GVR in questa sede.")]));
      };
      corpo.append(boxGvr);
      const pronta = sede.el.querySelector("input"); sede.el.addEventListener("click", () => setTimeout(() => caricaGvr().catch(errore), 300));
      pronta?.addEventListener("blur", () => setTimeout(() => caricaGvr().catch(errore), 300));
      await caricaGvr();
    }
    pannello.apri(nuovo ? "Nuovo accessorio di sicurezza" : `Modifica accessorio ${a.matr_informale}`, corpo, [bottone("Salva", async () => {
      if (!sede.valore) throw new Error("Scegli la sede operativa.");
      const d = {gruppo: "PSV", sede_id: sede.valore.id, matr_informale: ident.value, costruttore: costr.value, modello: mod.value, note: note.value,
        dati_dm: {tip_accessorio: tip.value, dn: dn.value, diametro: diam.value, area: area.value, ptar: ptar.value}};
      if (nuovo) {
        d.date_iniziali = {taratura: {data_ultima: tarU.value || null, data_prossima: tarP.value || null}};
        d.protegge = [...scelteGvr].filter(([, c]) => c.checked).map(([id]) => id);
      } else { d.versione = a.versione; delete d.gruppo; }
      const x = await api(nuovo ? "POST" : "PUT", nuovo ? "/api/beni" : `/api/beni/${a.id}`, d);
      if (opz.dopo) { toast("Salvato"); await opz.dopo(x); } else await mostraRisultato(x);
    }, "btn primary")], {largo: true});
  }
  async function modificaData(a,x=null) {
    const comp=select(a.componenti.map(c=>({id:c,testo:labelComp[c]})),x?.componente,"Scegli attività");comp.disabled=!!x;
    const ultima=input("date",x?.data_ultima),prossima=input("date",x?.data_prossima),num=input("text",x?.numero_report),nota=el("textarea",{});nota.value=x?.nota||"";
    const corpo=el("div",{class:"field-grid"},campo("Attività",comp),campo("Numero report / riferimento",num),campo("Ultima data",ultima),campo("Prossima data",prossima),campo("Note e fonte della data iniziale",nota,{pieno:true}));
    corpo.append(el("p",{},"Questi valori sono dichiarati: il salvataggio non genera un verbale e non calcola automaticamente nuove date."));
    const az=[bottone("Salva",async()=>mostraRisultato(await api("PUT",`/api/beni/${a.id}/scadenze`,{versione:a.versione,componente:comp.value,data_ultima:ultima.value,data_prossima:prossima.value,numero_report:num.value,nota:nota.value})),"btn primary")];
    if(x)az.push(bottone("Elimina data dichiarata",async()=>{
      if(await conferma("Elimina data dichiarata","Rimuovere questa coppia di date? L’operazione resta nello storico."))await mostraRisultato(await api("DELETE",`/api/beni/${a.id}/scadenze/${x.componente}`,{versione:a.versione}));
    }));
    pannello.apri("Data tecnica",corpo,az,{largo:true});
  }
  async function modificaCamera(a,x=null) {
    const ident=input("text",x?.identificazione),nf=input("text",x?.num_fabbrica),unita=select([{id:"L",testo:"Volume (L)"},{id:"DN",testo:"DN (mm)"}],x?.unita||"L"),val=input("text",x?.valore);
    const corpo=el("div",{class:"field-grid"},campo("Identificazione",ident),campo("N. fabbrica",nf),campo("Unità",unita),campo("Valore (massimo un decimale)",val));
    const attrs={};for(const cfg of catalogo.camera_dm) {attrs[cfg.nome]=input("text",x?.attributi?.[cfg.nome]);corpo.append(campo(cfg.etichetta,attrs[cfg.nome]));}
    const az=[bottone("Salva",async()=>mostraRisultato(await api(x ? "PUT" : "POST",`/api/beni/${a.id}/camere`+(x?`/${x.id}`:""),{versione:a.versione,identificazione:ident.value,num_fabbrica:nf.value,unita:unita.value,valore:val.value,dati_tecnici:Object.fromEntries(Object.entries(attrs).map(([k,v])=>[k,v.value]))})),"btn primary")];
    if(x)az.push(bottone("Elimina camera",async()=>{if(await conferma("Elimina camera","Rimuovere questa camera dalla scheda corrente?"))await mostraRisultato(await api("DELETE",`/api/beni/${a.id}/camere/${x.id}`,{versione:a.versione}));}));
    pannello.apri("Camera / tubazione",corpo,az);
  }
  async function associa(a) {
    const ricerca=input("search"),scelta=select([],"","Cerca e scegli valvola"),esito=el("p",{class:"subtle"});
    const cerca=bottone("Cerca valvola",async()=>{
      const d=await api("GET","/api/beni?gruppo=PSV&per_pagina=500&q="+encodeURIComponent(ricerca.value));
      scelta.replaceChildren(el("option",{value:""},"Scegli valvola"),...d.righe.map(x=>el("option",{value:x.id},`${x.matricola} · ${x.cliente} · ${x.sede}`)));
      esito.textContent=d.totale>500 ? "Affina la ricerca: sono visualizzate le prime 500 valvole." : `${d.totale} valvole`;
    });
    pannello.apri("Associa valvola",el("div",{},campo("Cerca matricola o cliente",ricerca),cerca,esito,campo("Valvola",scelta)),[bottone("Associa",async()=>mostraRisultato(await api("POST",`/api/beni/${a.id}/accessori`,{versione:a.versione,accessorio_id:scelta.value})),"btn primary")]);
  }
  document.getElementById("nuovo-bene")?.addEventListener("click",()=>modifica().catch(errore));
  // R142 (0.16): richiamo delle attrezzature senza prossima verifica (fuori dallo scadenziario)
  if (root.dataset.gruppo !== "PSV") api("GET","/api/beni/senza-prossima").then(r=>{
    const mie=r.filter(x=>root.dataset.gruppo==="GVR"?x.gruppo==="GVR":root.dataset.gruppo==="SCSP"?x.gruppo!=="GVR":true);
    if(!mie.length)return;
    const box=el("div",{class:"notice avviso"},`${mie.length} attrezzature senza prossima verifica: non compaiono nelle Scadenze. `,
      el("button",{class:"btn small",type:"button",onclick:()=>GAD.modale("Attrezzature senza prossima verifica",tabella(["Gruppo","Matricola","Sede","Cliente","Manca",""],
        mie.map(x=>[x.gruppo,x.matricola,x.sede,x.cliente,x.mancano.join(", "),bottone("Apri",()=>apri(x.id))])),[{testo:"Chiudi",valore:true}])},"Vedi elenco"));
    root.prepend(box);
  }).catch(()=>{});
  if (!root.dataset.griglia) {
    document.getElementById("cerca-beni").onclick=()=>{pagina=1;carica().catch(errore);};
    document.getElementById("pagina-prima").onclick=()=>{pagina--;carica().catch(errore);};
    document.getElementById("pagina-dopo").onclick=()=>{pagina++;carica().catch(errore);};
    document.getElementById("ricerca-beni").addEventListener("keydown",e=>{if(e.key==="Enter"){pagina=1;carica().catch(errore);}});
  }
  try {catalogo=await api("GET","/api/beni/cataloghi");await carica();const par=new URLSearchParams(location.search), id=par.get("scheda")||par.get("apri");if(id)await apri(Number(id));} catch(ex) {errore(ex);}
})();
