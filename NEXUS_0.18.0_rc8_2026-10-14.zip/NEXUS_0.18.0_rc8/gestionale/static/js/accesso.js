/* Pagine di accesso e primo avvio (non usano base.js: qui non c'è ancora una sessione). */
"use strict";

(() => {
  const errore = document.getElementById("errore");

  async function invia(url, dati, pulsante) {
    errore.textContent = "";
    pulsante.disabled = true;
    try {
      const r = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify(dati),
        credentials: "same-origin",
      });
      const corpo = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(corpo.errore || "Accesso non riuscito: riprova.");
      location.href = "/";
    } catch (e) {
      errore.textContent = e.message === "Failed to fetch" ? "Il programma non risponde: controlla che sia avviato." : e.message;
      pulsante.disabled = false;
    }
  }

  const accesso = document.getElementById("modulo-accesso");
  if (accesso) {
    accesso.addEventListener("submit", (ev) => {
      ev.preventDefault();
      const f = new FormData(accesso);
      invia("/api/accesso", { username: f.get("username"), password: f.get("password") }, accesso.querySelector("button"));
    });
  }

  const primo = document.getElementById("modulo-primo-avvio");
  if (primo) {
    primo.addEventListener("submit", (ev) => {
      ev.preventDefault();
      const f = new FormData(primo);
      if (f.get("password") !== f.get("ripeti")) {
        errore.textContent = "Le due password non coincidono.";
        return;
      }
      invia("/api/primo-avvio", { nome: f.get("nome"), username: f.get("username"), password: f.get("password") }, primo.querySelector("button"));
    });
  }
})();
