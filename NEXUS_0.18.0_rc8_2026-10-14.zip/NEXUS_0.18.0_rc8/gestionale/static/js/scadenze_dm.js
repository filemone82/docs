/* Scadenze AD_DM (0.12.6): una riga per attività di ogni attrezzatura o accessorio non dismesso, con sede e cliente.
   0.12.8 (N8, Federico 11/10/2026: «è da scadenza che in garda generiamo i preventivi (righe)»): si spuntano le scadenze e
   «Prepara preventivo DM…» crea le righe, una per scadenza (mai combinate in automatico: la combinazione GVR si sceglie a
   mano sulla riga), un preventivo per sede, come «Crea preventivo da scadenze» di Garda. */
"use strict";

(async () => {
  const { el, api, toast, errore, modale } = GAD;
  const S = GAD.schede;
  const { f, campo } = S;
  await S.me();
  const puoPreventivare = S.puo("preventivi.modifica");
  const filtro = (testo, filtri) => el("button", { class: "btn small", type: "button", onclick: () => {
    g.tabella.clearHeaderFilter(); for (const [c, v] of Object.entries(filtri)) g.filtra(c, v); } }, testo);

  async function preventiva() {
    const scelte = g.selezionate();
    if (!scelte.length) throw new Error("Spunta le scadenze da preventivare (casella a sinistra di ogni riga).");
    // R129 (0.12.9): nel preventivo DM solo le verifiche dell'allegato VII; il resto è EX
    const ex = scelte.filter((r) => r.regime === "EX");
    if (ex.length) {
      throw new Error(`${ex.length} scadenze sono attività EX (CND, indagini supplementari, efficienza valvole, regime volontario ISO 17020 `
        + `o attrezzatura esente) e non vanno nel preventivo DM. Togli la spunta a: ${ex.slice(0, 6).map((r) => `${r.matr_informale} · ${r.componente}`).join(", ")}.`);
    }
    const gia = scelte.filter((r) => r.da_preventivare !== "Sì");
    if (gia.length) {
      throw new Error(`${gia.length} scadenze sono già in un preventivo DM: togli la spunta a `
        + `${gia.slice(0, 6).map((r) => `${r.matr_informale} · ${r.componente} (${r.preventivo})`).join(", ")}.`);
    }
    const sedi = [...new Set(scelte.map((r) => r.sede_id))];
    const oggi = new Date();
    const data = el("input", { type: "date", value: `${oggi.getFullYear()}-${String(oggi.getMonth() + 1).padStart(2, "0")}-${String(oggi.getDate()).padStart(2, "0")}` });
    const numero = f.testo("", { maxlength: "40", placeholder: "vuoto = nuovo preventivo" });
    const ok = await modale(`Preventivare ${scelte.length} scadenze?`, [
      el("p", {}, `Una riga per scadenza (${sedi.length > 1 ? `${sedi.length} sedi: un preventivo per sede` : "una sede"}). `
        + "Prima periodica o successiva si propone dalla scheda dell'attrezzatura; la combinazione di più attività GVR in una riga si sceglie poi a mano, modificando la riga."),
      campo("Data del preventivo", data),
      campo("Preventivo", numero, { aiuto: "Vuoto: nuovo preventivo. Con un numero (es. 12 o 12/2026) le righe si aggiungono a quel preventivo DM della stessa sede, se è ancora «creato»." }),
    ], [{ testo: "Annulla", valore: false }, { testo: "Crea le righe", classe: "primary", valore: true }]);
    if (!ok) return;
    const r = await api("POST", "/api/dm/preventivi/da-scadenze", { scadenze: scelte.map((x) => x.id), data: data.value, preventivo: numero.value });
    toast(r.preventivi.map((p) => `Preventivo DM ${p.codice}: ${p.righe} righe`).join(" · "));
    if (r.preventivi.length === 1) location.href = `/preventivi-dm?apri=${r.preventivi[0].id}`;
    else g.ricarica();
  }

  const g = await GAD.griglia(document.getElementById("griglia"), "scadenze_dm", {
    selezione: puoPreventivare,
    suRiga: puoPreventivare ? null : (r) => { location.href = `/attrezzature?scheda=${r.asset_id}`; },
    pulsanti: [
      filtro("Scadute", { stato_scadenza: "Scaduta" }), filtro("Entro 30 giorni", { stato_scadenza: "Entro 30 giorni" }),
      filtro("Entro 90 giorni", { stato_scadenza: "Entro 90 giorni" }),
      filtro("Da preventivare DM", { da_preventivare: "Sì" }),
      filtro("Attività EX", { regime: "EX" }),
      // viste predefinite di Garda (preset «! GVR», «! SC/SP», «! Taratura valvole di sicurezza»)
      filtro("GVR", { gruppo: "GVR" }), filtro("SC/SP", { componente: "Verifica SC/SP" }), filtro("Tarature", { componente: "Taratura" }),
      filtro("Tutte", {}),
      puoPreventivare ? el("button", { class: "btn small primary", type: "button", onclick: () => preventiva().catch(errore) }, "Prepara preventivo DM…") : null,
      // R129: i preventivi EX (sezionale EX) non esistono ancora, né in Garda né qui: si progettano sull'architettura di iec
      puoPreventivare ? el("button", { class: "btn small", type: "button", onclick: () => modale("Preventivo EX", [
        el("p", {}, "I preventivi EX (CND, indagini supplementari, efficienza delle valvole di sicurezza, verifiche in regime volontario ISO/IEC 17020) "
          + "non sono ancora disponibili: Garda non li prevede e verranno realizzati prendendo spunto dal gestionale I&C."),
        el("p", {}, "Intanto il filtro «Attività EX» mostra le scadenze che ci finiranno.")],
      [{ testo: "Chiudi", valore: true }]).catch(errore) }, "Prepara preventivo EX…") : null,
    ].filter(Boolean),
    azioni: {
      modifica: (r) => { location.href = `/attrezzature?scheda=${r.asset_id}`; },
      collegamenti: [
        { testo: "Attrezzatura → scheda", vai: (r) => `/attrezzature?scheda=${r.asset_id}` },
        { testo: "Sede → scheda", vai: (r) => `/sedi?apri=${r.sede_id}` },
        { testo: "Cliente → scheda", vai: (r) => `/clienti?apri=${r.cliente_id}` },
        { testo: "Preventivi DM ← Cliente", vai: (r) => S.filtro("preventivi-dm", "cliente_id", r.cliente_id, `preventivi DM di ${r.cliente_ragione_sociale}`) },
      ],
    },
  });
})().catch((e) => GAD.errore(e));
