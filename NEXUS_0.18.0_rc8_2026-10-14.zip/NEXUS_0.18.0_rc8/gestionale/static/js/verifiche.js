/* Verifiche (fase 5, documento 10): da assegnare → assegnata → programmata → registrata (numero del verbale) →
   eseguita (verbale Word di VerbalizzAI caricato) → riesaminata dal RT (da fatturare). */
"use strict";

(async () => {
  const { el, api, toast, errore, conferma, pannello, modale, formatta, scarica } = GAD;
  const S = GAD.schede;
  const { f, campo, sezione } = S;
  const io = await S.me();
  const valori = await api("GET", "/api/verifiche/valori");
  const filtro = (testo, filtri) => el("button", { class: "btn small", type: "button", onclick: () => {
    g.tabella.clearHeaderFilter();
    for (const [c, v] of Object.entries(filtri)) g.filtra(c, v);
  } }, testo);
  const pulsanti = [
    S.puo("verifiche.assegna", "DPR") ? filtro("Da assegnare", { stato: "Da assegnare" }) : null,
    S.puo("verifiche.esegui", "DPR") ? filtro("Le mie", { verificatore_id: String(io.id) }) : null,
    filtro("Da registrare", { stato: "Assegnata" }), filtro("Programmate", { stato: "Programmata" }),
    filtro("Verbale da compilare", { stato: "Registrata" }),
    S.puo("verifiche.riesame", "DPR") ? filtro("Da riesaminare", { stato: "Eseguita (verbale emesso)" }) : null,
    filtro("Da fatturare", { da_fatturare: "Sì" }), filtro("Tutte", {}),
    // R139 (0.16): si fattura anche da qui (oltre che dalle righe dei preventivi, come in Garda)
    S.puo("fatture.genera") ? el("button", { class: "btn small primary", type: "button", onclick: () => fatturaSelezionate().catch(errore) }, "Fattura le selezionate…") : null,
    S.puo("verifiche.assegna", "DPR") ? el("button", { class: "btn small primary", type: "button", onclick: () => assegnaInBlocco().catch(errore) }, "👤 Affida le selezionate…") : null,
  ].filter(Boolean);
  // O17: più verifiche allo stesso verificatore (caselle a sinistra delle righe); 0.12.9: stessa finestra di Righe dei
  // preventivi, della scheda del preventivo e delle Verifiche DM
  async function assegnaInBlocco() {
    const scelte = g.selezionate().map((x) => ({ verifica_id: x.id, verificatore: x.verificatore, ordine: x.id, preventivo_etichetta: x.preventivo }));
    if (await S.affidaRighe(scelte, false)) g.ricarica();
  }
  async function fatturaSelezionate() {
    const scelte = g.selezionate();
    if (!scelte.length) throw new Error("Spunta le verifiche da fatturare (casella a sinistra di ogni riga).");
    const no = scelte.filter((r) => r.da_fatturare !== "Sì");
    if (no.length) throw new Error(`${no.length} verifiche non sono da fatturare (non riesaminate o già fatturate): togli la spunta.`);
    await S.fatturaLavori({ verifiche: scelte.map((r) => r.id) });
  }
  const g = await GAD.griglia(document.getElementById("griglia"), "verifiche", {
    selezione: S.puo("verifiche.assegna", "DPR") || S.puo("fatture.genera"),
    suRiga: (r) => apri(r.id),
    pulsanti,
    azioni: {
      modifica: (r) => apri(r.id),
      collegamenti: [
        { testo: "Impianto → scheda", vai: (r) => `/impianti?apri=${r.impianto_id}` },
        { testo: "Preventivo → scheda", vai: (r) => `/preventivi?apri=${r.preventivo_id}` },
        { testo: "Cliente → scheda", vai: (r) => `/clienti?apri=${r.cliente_id}` },
        { testo: "Verifiche ← Impianto", vai: (r) => S.filtro("verifiche", "impianto_id", r.impianto_id, `verifiche dell'impianto n. ${r.impianto_id}`) },
        { testo: "Verifiche ← Cliente", vai: (r) => S.filtro("verifiche", "cliente_id", r.cliente_id, `verifiche di ${r.cliente_ragione_sociale}`) },
      ],
    },
  });

  const badge = (stato, testo) => el("span", { class: "badge " + ({ riesaminata: "ok", eseguita: "ok", registrata: "avviso", programmata: "avviso",
    assegnata: "grigio", da_assegnare: "errore", annullata: "grigio" }[stato] || "grigio") }, testo);

  // ---------------------------------------------------------------- scheda
  async function apri(id, linguettaIniziale) {
    let v;
    try { v = await api("GET", `/api/verifiche/${id}`); } catch (e) { return errore(e); }
    const mia = v.verificatore_id === io.id;
    const puoEseguire = S.puo("verifiche.assegna", "DPR") || (S.puo("verifiche.esegui", "DPR") && mia);
    const ricarica = (msg) => { if (msg) toast(msg); g.ricarica(); apri(v.id, linguettaAperta); };
    let linguettaAperta = linguettaIniziale || "Verifica";
    const post = (azione, dati) => api("POST", `/api/verifiche/${v.id}/${azione}`, { ...dati, versione: v.versione });

    // percorso
    const passi = ["da_assegnare", "assegnata", "programmata", "registrata", "eseguita", "riesaminata"];
    const indice = passi.indexOf(v.stato);
    const percorso = el("div", { class: "percorso" }, ...passi.map((p, i) => el("span", { class: "passo" + (i < indice ? " fatto" : i === indice ? " attuale" : "") },
      valori.stati[p].replace(/ \(.*\)/, ""))));

    // Dichiarazione preimpostata, escludibile: server blocca l'esecuzione.
    // azione del passo attuale
    const passo = el("div", { class: "riquadro" });
    const aggiungi = (...x) => passo.append(...x.filter(Boolean));
    if (puoEseguire && ["assegnata", "programmata", "registrata", "sospesa"].includes(v.stato)) {
      // R119: la dichiara il verificatore a cui è affidata (anche se è il RT); con «No» torna al RT da riassegnare
      if (v.verificatore_id === io.id && ["assegnata", "programmata"].includes(v.stato)) {
        const indip = el("input", {type: "checkbox"}); indip.checked = v.indipendenza;
        indip.addEventListener("change", async () => {
          try {
            if (!indip.checked && !(await conferma("Dichiari di NON essere indipendente?", "La verifica torna al responsabile tecnico, che la riassegnerà a un altro verificatore. La tua dichiarazione resta registrata.", { pulsante: "Non sono indipendente", pericolo: true }))) { indip.checked = true; return; }
            await post("indipendenza", {indipendenza: indip.checked});
            if (indip.checked) ricarica("Indipendenza confermata."); else { toast("Verifica restituita al responsabile tecnico."); pannello.chiudi(); g.ricarica(); }
          } catch(e) { GAD.errore(e); indip.checked = v.indipendenza; }
        });
        aggiungi(el("label", {}, indip, " Dichiaro la mia indipendenza per questa verifica"));
      } else {
        aggiungi(el("p", { class: "subtle" }, `Indipendenza: ${v.indipendenza ? "Sì" : "No"} · la dichiara il verificatore a cui è affidata la verifica.`));
      }
      if (v.stato === "sospesa") {
        aggiungi(el("p", {}, "Sospesa: " + v.motivo_sospensione), S.azione("Riprendi", "primary", async () => {await post("riprendi", {}); ricarica();}));
      } else {
        const motivo = f.testo("", {placeholder: "Motivo della sospensione"});
        aggiungi(motivo, S.azione("Sospendi", "", async () => {await post("sospendi", {motivo: motivo.value}); ricarica();}));
      }
    }
    if (v.stato === "da_assegnare" && v.indipendenza_esclusa) aggiungi(el("div", { class: "notice errore" }, v.indipendenza_esclusa));
    if (v.stato === "annullata") {
      aggiungi(el("div", { class: "notice errore" }, "Annullata: " + v.motivo_annullamento));
    } else if (["da_assegnare", "assegnata", "programmata", "registrata", "sospesa"].includes(v.stato) && S.puo("verifiche.assegna", "DPR")) {
      const chi = f.scelta(valori.verificatori.map((x) => ({ valore: x.id, testo: x.nome })), v.verificatore_id || "", { vuota: "—" });
      aggiungi(el("h3", {}, v.verificatore_id ? "Cambia verificatore" : "Assegna la verifica (RT)"), el("div", { class: "field-grid" },
        campo("Verificatore", chi), el("div", { class: "actions" }, S.azione(v.verificatore_id ? "Riassegna" : "Assegna", "primary", async () => {
          await post("assegna", { verificatore_id: chi.value }); ricarica("Verifica assegnata.");
        }))));
    }
    if (["assegnata", "programmata"].includes(v.stato) && puoEseguire) {
      const prevista = f.data(v.data_programmata);
      const esecuzione = f.data(v.data_programmata || "");
      aggiungi(el("h3", {}, "Programma (facoltativo, consigliato)"), el("div", { class: "field-grid" }, campo("Data prevista", prevista),
        el("div", { class: "actions" }, S.azione("Programma", "", async () => { await post("programma", { data_programmata: prevista.value }); ricarica("Verifica programmata."); }))),
      el("h3", {}, "Registra: prende il numero del verbale"), el("p", { class: "subtle" },
        `Il numero (${v.tipo_verifica === "straordinaria" ? "VS" : "VP"}/nnn/aa) è annuale, un solo sezionale per VP e VS. Il verbale compilato nel gestionale lo riporta da solo.`),
      el("div", { class: "field-grid" }, campo("Data di esecuzione", esecuzione),
        el("div", { class: "actions" }, S.azione("Registra e prendi il numero", "primary", async () => {
          if (!esecuzione.value) throw new Error("Scrivi la data di esecuzione.");
          if (!(await conferma("Registrare la verifica?", "Il numero del verbale viene assegnato adesso e non si riusa, anche se poi la verifica venisse annullata.", { pulsante: "Registra" }))) return;
          await post("registra", { data_esecuzione: esecuzione.value }); ricarica("Verifica registrata: numero del verbale assegnato.");
        }))));
    }
    if (v.stato === "registrata" && puoEseguire) {
      const fw = el("input", { type: "file", accept: ".docx" }), fp = el("input", { type: "file", accept: ".pdf,application/pdf" });
      // 0.12.6: il verbale precedente (Word) si carica da qui, così la bozza riparte dal suo contenuto come in VerbalizzAI
      const infoPrec = el("p", { class: "subtle" }, "Verbale precedente: verifica in corso…");
      const fPrec = el("input", { type: "file", accept: ".docx" });
      aggiungi(el("h3", {}, "Verbale precedente"), infoPrec,
        el("div", { class: "field-grid" }, campo("Word dell'ultimo verbale (.docx)", fPrec),
          el("div", { class: "actions" }, S.azione("Carica il verbale precedente", "", async () => {
            if (!fPrec.files.length) throw new Error("Scegli il Word dell'ultimo verbale.");
            if (v.verbale_id && !(await conferma("Rifare la bozza?", "La bozza già aperta verrà rifatta partendo dal verbale precedente: quello che hai scritto finora nella bozza si perde.", { pulsante: "Carica e rifai la bozza", pericolo: true }))) return;
            const fd = new FormData(); fd.append("file", fPrec.files[0]);
            const r = await api("POST", `/api/verifiche/${v.id}/verbale/precedente`, fd);
            for (const n of r.note || []) toast(n);
            ricarica(r.precedente ? `Verbale precedente ${r.precedente.numero} collegato: «Compila il verbale» parte da lì.` : "Caricato.");
          }))));
      api("GET", `/api/verifiche/${v.id}/verbale/precedente`).then(({ precedente: p }) => {
        infoPrec.textContent = p
          ? `La bozza parte dal verbale ${p.numero || "senza numero"} del ${p.data || "?"}${p.storico ? " (Word importato" + (p.file ? ": " + p.file : "") + ")" : " (emesso nel programma)"}. Se non è l'ultimo, carica qui il Word giusto.`
          : "Nessun verbale precedente per questo impianto: la bozza partirebbe vuota. Se hai il Word dell'ultimo verbale, caricalo qui prima di compilare.";
      }).catch(() => { infoPrec.textContent = ""; });
      aggiungi(el("h3", {}, `Compila il verbale ${v.codice_verbale}`),
        el("p", { class: "subtle" }, "Il verbale si compila qui nel gestionale (VerbalizzAI): numero, data, cliente, impianto e verificatore sono già inseriti. " +
          "Quando lo emetti, la verifica diventa «eseguita» da sola."),
        el("div", { class: "actions" }, S.azione(v.verbale_id ? "Riprendi il verbale" : "Compila il verbale", "primary", async () => {
          const r = await api("POST", `/api/verifiche/${v.id}/verbale/bozza`, {});
          location.href = r.url;
        })));
      aggiungi(el("h3", {}, `Oppure carica il verbale ${v.codice_verbale} già fatto in Word`),
        v.riesame_esito === "non_conforme" ? el("div", { class: "notice errore" }, "Riesame non conforme: ", v.riesame_note) : null,
        el("p", { class: "subtle" }, `Il Word emesso con VerbalizzAI (modulo ${v.modulo_atteso}), con il numero ${v.codice_verbale}. Il PDF è facoltativo. ` +
          "Il programma legge esito, prossima verifica e caratteristiche dell'impianto e aggiorna l'impianto."),
        el("div", { class: "field-grid" }, campo("Verbale Word (.docx)", fw), campo("PDF (facoltativo)", fp),
          el("div", { class: "actions" }, S.azione("Carica il verbale", "", async () => {
            if (!fw.files[0]) throw new Error("Scegli il verbale Word.");
            const dati = new FormData();
            dati.append("word", fw.files[0]); if (fp.files[0]) dati.append("pdf_file", fp.files[0]); dati.append("versione", v.versione);
            const r = await api("POST", `/api/verifiche/${v.id}/verbale`, dati);
            ricarica("Verbale caricato: verifica eseguita." + (r.note_scheda && r.note_scheda.length ? " " + r.note_scheda.join(" ") : ""));
          }))));
    }
    if (v.stato === "eseguita" && S.puo("verifiche.riesame", "DPR") && !mia) {
      const esito = f.scelta(Object.entries(valori.esiti_riesame).map(([k, t]) => ({ valore: k, testo: t })), "conforme");
      const note = f.area("", { maxlength: "4000", placeholder: "Se non conforme: cosa va corretto nel verbale" });
      aggiungi(el("h3", {}, "Riesame del verbale (RT)"), el("p", { class: "subtle" }, "Conforme: la verifica è pronta per la fatturazione. Non conforme: torna «registrata» per correggere il verbale (con «Compila il verbale» si apre la revisione del verbale emesso)."),
        el("div", { class: "field-grid" }, campo("Esito", esito), campo("Note", note, { pieno: true })),
        el("div", { class: "actions" }, S.azione("Registra il riesame", "primary", async () => { await post("riesame", { esito: esito.value, note: note.value }); ricarica("Riesame registrato."); })));
    }
    if (v.stato === "eseguita" && S.puo("verifiche.riesame", "DPR") && mia)
      aggiungi(el("p", {class: "notice"}, "Non puoi riesaminare il tuo verbale: serve un altro responsabile tecnico abilitato."));
    // R139 (0.16): dalla verifica riesaminata si fattura direttamente; dopo, la scheda mostra la fattura
    if (v.stato === "riesaminata" && v.fattura) {
      aggiungi(el("p", {}, "Fatturata: ", el("a", { href: `/fatture?apri=${v.fattura.id}` }, v.fattura.codice ? `fattura ${v.fattura.codice}` : `bozza n. ${v.fattura.id}`), v.fattura.stato === "bozza" ? " (bozza da emettere)" : ""));
    } else if (v.stato === "riesaminata" && S.puo("fatture.genera")) {
      aggiungi(el("p", { class: "subtle" }, "Verbale riesaminato: la verifica è da fatturare."), el("div", { class: "actions" }, S.azione("Fattura questa verifica…", "primary", () => S.fatturaLavori({ verifiche: [v.id] }))));
    }
    if (!passo.childNodes.length) aggiungi(el("p", { class: "subtle" }, v.stato === "riesaminata" ? "Verbale riesaminato: la verifica è da fatturare." : "Nessuna azione per te in questo passo."));

    const scheda = el("div", {}, percorso,
      el("div", { class: "riquadro" }, el("div", { class: "numeri" },
        el("span", {}, "Stato: ", badge(v.stato, v.stato_testo)),
        v.codice_verbale ? el("span", {}, "Verbale: ", el("strong", {}, v.codice_verbale)) : null,
        v.esito ? el("span", {}, "Esito: ", el("strong", {}, v.esito_testo)) : null,
        v.prossima_verifica ? el("span", {}, "Prossima verifica: ", formatta.data(v.prossima_verifica)) : null)),
      el("div", { class: "field-grid" },
        campo("Cliente", el("a", { href: `/clienti?apri=${v.cliente_id}` }, v.cliente), { pieno: true }),
        campo("Sede", el("div", {}, el("a", { href: `/sedi?apri=${v.sede_id}` }, v.sede), el("div", { class: "subtle" }, v.sede_indirizzo)), { pieno: true }),
        campo("Impianto", el("a", { href: `/impianti?apri=${v.impianto_id}` }, `n. ${v.impianto_id} · ${v.impianto_tipologia}${v.impianto_denominazione ? " · " + v.impianto_denominazione : ""}`)),
        campo("Preventivo", el("a", { href: `/preventivi?apri=${v.preventivo_id}` }, v.preventivo)),
        campo("Tipo di verifica", el("div", {}, v.tipo_testo)),
        campo("Verificatore", el("div", {}, v.verificatore || "—", v.assegnata_il ? el("div", { class: "subtle" }, `assegnata il ${formatta.dataora(v.assegnata_il)} da ${v.assegnata_da}`) : null)),
        campo("Data prevista", el("div", {}, v.data_programmata ? formatta.data(v.data_programmata) : "—")),
        campo("Data di esecuzione", el("div", {}, v.data_esecuzione ? formatta.data(v.data_esecuzione) : "—"))),
      passo);

    // verbale
    const d = v.dati_verbale;
    const verbale = el("div", {},
      !d ? el("p", { class: "subtle" }, "Il verbale non è ancora stato caricato.") : el("div", {},
        ...v.avvisi_verbale.map((a) => el("div", { class: "notice" }, "⚠ " + a)),
        el("p", {}, `Letto il ${formatta.dataora(v.eseguita_il)} (caricato da ${v.caricata_da}) · modulo ${d.modulo} · verbale ${d.numero_scritto}` +
          (d.verificatori ? ` · verificatori: ${d.verificatori}` : "")),
        sezione("Caratteristiche dell'impianto lette dal verbale"),
        S.tabella([{ titolo: "Voce", valore: (x) => x.etichetta }, { titolo: "Valore", valore: (x) => x.valore }], d.caratteristiche || []),
        d.n_elementi ? el("p", { class: "subtle" }, `${d.n_elementi} elementi provati (quadri, differenziali…) riportati nella scheda dell'impianto.`) : null,
        v.riesame_esito ? el("p", {}, `Riesame: ${v.riesame_esito_testo} — ${formatta.dataora(v.riesame_il)}, ${v.riesame_da}${v.riesame_note ? " · " + v.riesame_note : ""}`) : null),
      el("h3", {}, "File del verbale"),
      S.tabella([{ titolo: "File", valore: (x) => x.in_uso ? x.nome_file : el("span", { class: "subtle" }, x.nome_file + " (sostituito)") },
        { titolo: "Caricato", valore: (x) => `${formatta.dataora(x.creato_il)} · ${x.creato_da}` },
        { titolo: "", valore: (x) => el("button", { class: "btn small", type: "button", onclick: (ev) => {
          ev.stopPropagation();
          if (x.formato === "pdf") window.open(`/api/verifiche/${v.id}/documenti/${x.documento_id}?in_linea=true`, "_blank");
          else scarica("GET", `/api/verifiche/${v.id}/documenti/${x.documento_id}`, undefined, x.nome_file).catch(errore);
        } }, x.formato === "pdf" ? "Apri" : "Scarica") }], v.documenti));

    if (v.storico_riesami?.length) {
      passo.append(el("h3", {}, "Storico dei riesami"), ...v.storico_riesami.map(r => el("p", {},
        `${formatta.dataora(r.eseguito_il)} · ${r.eseguito_da} · ${r.esito} · ${r.note || ""}`)));
    }
    const note = f.area(v.note, { maxlength: "4000" });
    const altro = el("div", {}, campo("Note", note, { pieno: true }),
      el("div", { class: "actions" }, S.azione("Salva le note", "", async () => { await api("PUT", `/api/verifiche/${v.id}/note`, { note: note.value, versione: v.versione }); ricarica("Note salvate."); })));
    const storico = el("div");
    const schede = [
      { titolo: "Verifica", contenuto: scheda }, { titolo: "Verbale", contenuto: verbale }, { titolo: "Note", contenuto: altro },
      ...(S.puo("verifiche.vedere_tutte", "DPR") ? [{ titolo: "Storico", contenuto: storico, apri: async () => storico.replaceChildren(await S.storico("verifica", v.id)) }] : []),
    ];
    for (const sc of schede) { const prima = sc.apri; sc.apri = async () => { linguettaAperta = sc.titolo; if (prima) await prima(); }; }
    const corpo = el("div", {}, S.linguette(schede), S.traccia(v));
    setTimeout(() => { const b = [...corpo.querySelectorAll(".tabs button")].find((x) => x.textContent.startsWith(linguettaAperta)); if (b) b.click(); }, 0);
    const pulsanti = [];
    if (["da_assegnare", "assegnata", "programmata", "registrata"].includes(v.stato) && S.puo("verifiche.annulla", "DPR")) {
      pulsanti.push(S.azione("Annulla la verifica…", "danger", async () => {
        const motivo = el("input", { maxlength: "500" });
        if (!(await modale("Annullare la verifica?", [el("p", {}, v.codice_verbale ? `Il numero ${v.codice_verbale} resta usato (non si riassegna).` : "La verifica resta in archivio come «annullata»."),
          campo("Motivo", motivo)], [{ testo: "No", valore: false }, { testo: "Annulla la verifica", classe: "danger", valore: true }]))) return;
        await post("annulla", { motivo: motivo.value }); ricarica("Verifica annullata.");
      }));
    }
    if (v.verbale_id && ["eseguita", "riesaminata"].includes(v.stato)) {
      pulsanti.push(S.azione("Apri il verbale", "", async () => { location.href = "/verbali?apri=" + encodeURIComponent(v.verbale_id); }));
    }
    pannello.apri(`Verifica n. ${v.id}${v.codice_verbale ? " · " + v.codice_verbale : ""} · ${v.cliente}`, corpo, pulsanti, { largo: true });
  }

  S.apriDaIndirizzo(apri);
})().catch((e) => GAD.errore(e));
