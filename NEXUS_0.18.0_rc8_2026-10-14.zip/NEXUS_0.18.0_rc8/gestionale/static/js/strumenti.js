/* Strumenti di misura AD_DM e I&C (C16, 0.16): elenco, scheda, tarature. Quelli AD_DPR sono nel registro di VerbalizzAI. */
"use strict";

(async () => {
  const { el, api, toast, errore, pannello } = GAD;
  const S = GAD.schede;
  const { f, campo } = S;
  await S.me();
  const att = document.documentElement.dataset.ambito;
  const box = document.getElementById("griglia");
  if (!["DM", "IEC"].includes(att)) {
    box.replaceChildren(el("div", { class: "notice" }, "Gli strumenti di misura AD_DPR sono nel registro di VerbalizzAI: ",
      el("a", { href: "/verbali?vista=instruments" }, "apri gli strumenti AD_DPR"), ". Per AD_DM o I&C scegli l'attività in alto."));
    document.getElementById("nuovo")?.remove();
    return;
  }
  const nome = { DM: "AD_DM", IEC: "I&C" }[att];
  const g = await GAD.griglia(box, "strumenti_misura", { suRiga: (r) => apri(r.id), azioni: { modifica: (r) => apri(r.id) } });

  function modulo(x) {
    x = x || { attivo: true };
    const m = { denominazione: f.testo(x.denominazione, { maxlength: "200" }), costruttore: f.testo(x.costruttore, { maxlength: "120" }),
      modello: f.testo(x.modello, { maxlength: "120" }), matricola: f.testo(x.matricola, { maxlength: "120" }),
      campo_misura: f.testo(x.campo_misura, { maxlength: "200" }), ente_taratura: f.testo(x.ente_taratura, { maxlength: "200" }),
      certificato: f.testo(x.certificato, { maxlength: "120" }), data_taratura: el("input", { type: "date", value: x.data_taratura || "" }),
      scadenza_taratura: el("input", { type: "date", value: x.scadenza_taratura || "" }), note: f.area(x.note, { maxlength: "4000" }) };
    const attivo = f.casella("In uso", x.attivo);
    const griglia = el("div", { class: "field-grid" }, campo("Strumento", m.denominazione, { pieno: true, aiuto: "Es. «Spessimetro a ultrasuoni», «Manometro campione»." }),
      campo("Costruttore", m.costruttore), campo("Modello", m.modello), campo("Matricola", m.matricola), campo("Campo di misura", m.campo_misura),
      campo("Ente di taratura", m.ente_taratura), campo("Certificato", m.certificato), campo("Data di taratura", m.data_taratura),
      campo("Scadenza della taratura", m.scadenza_taratura), el("div", { class: "field full" }, attivo.el), campo("Note", m.note, { pieno: true }));
    return { griglia, valori: () => ({ ...Object.fromEntries(Object.entries(m).map(([k, v]) => [k, v.value])), attivo: attivo.valore }) };
  }

  document.getElementById("nuovo")?.addEventListener("click", () => {
    const m = modulo(null);
    pannello.apri(`Nuovo strumento ${nome}`, m.griglia, [S.azione("Crea", "primary", async () => {
      const x = await api("POST", `/api/strumenti/${att}`, m.valori()); toast("Strumento creato."); g.ricarica(); apri(x.id);
    })]);
  });

  async function apri(id) {
    let x;
    try { x = await api("GET", `/api/strumenti/${att}/${id}`); } catch (e) { return errore(e); }
    const m = modulo(x);
    const storico = el("div");
    const corpo = el("div", {}, S.linguette([{ titolo: "Strumento", contenuto: m.griglia },
      { titolo: "Storico", contenuto: storico, apri: async () => storico.replaceChildren(await S.storico("strumento", x.id)) }]));
    const pulsanti = [];
    if (S.puo("strumenti.gestire")) {
      pulsanti.push(S.azione("Salva", "primary", async () => {
        await api("PUT", `/api/strumenti/${att}/${x.id}`, { ...m.valori(), versione: x.versione }); toast("Salvato."); g.ricarica(); apri(x.id);
      }));
    } else S.solaLettura(corpo);
    pannello.apri(x.denominazione, corpo, pulsanti);
  }
})().catch((e) => GAD.errore(e));
