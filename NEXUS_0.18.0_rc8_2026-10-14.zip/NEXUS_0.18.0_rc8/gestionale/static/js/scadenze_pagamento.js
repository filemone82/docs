/* 0.14 · Scadenze di pagamento (Garda «pagamenti»): una riga per rata delle fatture emesse, con lo stato
   (scaduta, da incassare, saldata) e il residuo della fattura. Il clic apre la fattura. */
"use strict";

(async () => {
  const { el, errore } = GAD;
  const dm = document.documentElement.dataset.ambito === "DM";
  const filtro = (testo, valore) => el("button", { class: "btn small", type: "button", onclick: () => { g.tabella.clearHeaderFilter(); if (valore) g.filtra("stato_rata", valore); } }, testo);
  const apri = (r) => { location.href = `${dm ? "/fatture-dm" : "/fatture"}?apri=${r.fattura_id}`; };
  const g = await GAD.griglia(document.getElementById("griglia"), "scadenze_pagamento", {
    suRiga: apri,
    pulsanti: [filtro("Scadute", "Scaduta"), filtro("Da incassare", "Da incassare"), filtro("Saldate", "Saldata"), filtro("Tutte", "")],
    azioni: { modifica: apri },
  });
  g.filtra("stato_rata", "Scaduta");
})().catch(GAD.errore);
