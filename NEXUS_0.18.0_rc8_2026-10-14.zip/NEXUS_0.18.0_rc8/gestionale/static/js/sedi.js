/* Sedi operative: elenco con i dati del cliente (D43), scheda, impianti collegati, storico. */
"use strict";

(async () => {
  const { el, api, toast, errore, conferma, pannello, modale } = GAD;
  const S = GAD.schede;
  const { f, campo, sezione } = S;
  await S.me();
  const dm = document.documentElement.dataset.ambito === "DM";
  const btnDoppioni = el("button", { class: "btn small", type: "button", title: "Sedi dello stesso cliente nello stesso comune: unirle o dichiararle diverse (R116)", onclick: () => doppioni().catch(errore) }, "Possibili doppioni");
  const g = await GAD.griglia(document.getElementById("griglia"), "sedi", {
    pulsanti: [btnDoppioni],
    suRiga: (r) => apri(r.id),
    azioni: {
      modifica: (r) => apri(r.id),
      elimina: S.puo("anagrafica.sedi") ? (r) => S.eliminaDaRiga(`/api/sedi/${r.id}`, `la sede «${r.denominazione}»`, g) : null,
      collegamenti: [
        { testo: "Cliente → scheda", vai: (r) => `/clienti?apri=${r.cliente_id}` },
        { testo: "Altre sedi dello stesso cliente", vai: (r) => S.filtro("sedi", "cliente_id", r.cliente_id, `sedi di ${r.cliente_ragione_sociale}`) },
        ...(dm ? [  // 0.12.6: nel contesto AD_DM si resta nelle pagine DM
          // C8 (0.16): GVR e SC/SP sono due elenchi distinti (documento 30); accanto il numero di attrezzature
          { testo: (r) => `Attrezzature GVR ← Sede (${r.n_gvr ?? 0})`, vai: (r) => S.filtro("attrezzature-gvr", "sede_id", r.id, `attrezzature GVR della sede ${r.denominazione}`) },
          { testo: (r) => `Attrezzature SC/SP ← Sede (${r.n_scsp ?? 0})`, vai: (r) => S.filtro("attrezzature-scsp", "sede_id", r.id, `attrezzature SC/SP della sede ${r.denominazione}`) },
          { testo: (r) => `Accessori · PSV ← Sede (${r.n_psv ?? 0})`, vai: (r) => S.filtro("valvole-sicurezza", "sede_id", r.id, `accessori della sede ${r.denominazione}`) },
          { testo: "Scadenze ← Sede", vai: (r) => S.filtro("scadenze-tecniche", "sede_id", r.id, `scadenze DM della sede ${r.denominazione}`) },
        ] : [
          { testo: "Impianti ← Sede", vai: (r) => S.filtro("impianti", "sede_id", r.id, `impianti della sede ${r.denominazione}`) },
          { testo: "Scadenze ← Sede", vai: (r) => S.filtro("scadenze", "sede_id", r.id, `scadenze della sede ${r.denominazione}`) },
        ]),
      ],
    },
  });

  function sceltaCliente(cliente) {
    return S.ricerca({
      cerca: (t) => api("GET", "/api/clienti/cerca?q=" + encodeURIComponent(t)),
      mostra: (c) => [c.ragione_sociale, [c.comune, c.partita_iva].filter(Boolean).join(" · ")],
      scelto: cliente, segnaposto: "Cerca il cliente per nome o partita IVA…",
    });
  }

  function modulo(x, cliente) {
    x = x || {};
    const cli = sceltaCliente(cliente);
    const m = {
      denominazione: f.testo(x.denominazione, { maxlength: "300" }),
      referente_nome: f.testo(x.referente_nome, { maxlength: "120" }),
      referente_email: f.testo(x.referente_email, { maxlength: "200" }),
      referente_telefono: f.testo(x.referente_telefono, { maxlength: "60" }),
      email_verbali: f.testo(x.email_verbali, { maxlength: "500" }),
      email_verbali_cc: f.testo(x.email_verbali_cc, { maxlength: "500" }),
      note_accesso: f.area(x.note_accesso, { maxlength: "4000" }),
      note: f.area(x.note, { maxlength: "8000" }),
      avvisi: f.area(x.avvisi, { maxlength: "8000" }),
      codice_esterno: f.testo(x.codice_esterno, { maxlength: "40" }),
    };
    let ind = S.indirizzo(x);
    // R137 (0.16): l'ambito è del cliente e vale per tutte le sue sedi; qui si vede soltanto
    const NOMI_AMB = { DPR: "AD_DPR", DM: "AD_DM", IEC: "I&C" };
    const amb = el("div", { class: "subtle" }, x.id ? ((x.ambiti || []).map((a) => NOMI_AMB[a]).join(", ") || "nessuno") + " · dal cliente" : "Dal cliente");
    const bloccoIndirizzo = el("div", { class: "field-grid" }, ...ind.elementi);
    const copia = S.azione("Copia l'indirizzo della sede legale", "small", async () => {
      if (!cli.valore) throw new Error("Scegli prima il cliente.");
      const c = await api("GET", `/api/clienti/${cli.valore.id}`);
      ind = S.indirizzo(c);
      bloccoIndirizzo.replaceChildren(...ind.elementi);
      if (!m.denominazione.value) m.denominazione.value = c.ragione_sociale;
    });
    const dati = el("div", { class: "field-grid" },
      campo("Cliente", cli.el, { pieno: true }),
      campo("Denominazione della sede operativa", m.denominazione, { pieno: true, aiuto: "Es. «Stabilimento di Volpiano», «Scuola media Via Roma»." }),
      campo("Ambito", amb, { pieno: true, aiuto: "AD_DPR, AD_DM e I&C si impostano nella scheda del cliente e valgono per tutte le sue sedi." }),
      sezione("Indirizzo della sede"), el("div", { class: "field full" }, copia), el("div", { class: "field full" }, bloccoIndirizzo),
      campo("Note di accesso", m.note_accesso, { pieno: true, aiuto: "Orari, chiavi, persona da chiamare all'arrivo…" }));
    const contatti = el("div", { class: "field-grid" },
      sezione("Referente della sede"),
      campo("Nome", m.referente_nome), campo("Telefono", m.referente_telefono), campo("Email", m.referente_email, { pieno: true }),
      sezione("Invio dei verbali (D41)"),
      campo("Destinatari dei verbali", m.email_verbali, { pieno: true, aiuto: x.email_verbali_cliente ? `Se vuoto si usa l'email verbali del cliente: ${x.email_verbali_cliente}` : "Se vuoto si usa l'email verbali del cliente." }),
      campo("In copia", m.email_verbali_cc, { pieno: true }),
      sezione("Note"), campo("Note", m.note, { pieno: true }),
      campo("Da controllare", m.avvisi, { pieno: true }), campo("Riferimento nel gestionale attuale", m.codice_esterno));
    return { dati, contatti, campi: m, valori: () => ({ ...Object.fromEntries(Object.entries(m).map(([k, v]) => [k, v.value])), ...ind.valori(), cliente_id: cli.valore ? cli.valore.id : null }) };
  }

  async function nuova(clienteId) {
    let cliente = null;
    if (clienteId) { try { cliente = await api("GET", `/api/clienti/${clienteId}`); } catch (e) { errore(e); } }
    const m = modulo(null, cliente);
    const salva = S.azione("Crea sede", "primary", async () => {
      const x = await api("POST", "/api/sedi", m.valori());
      toast("Sede creata."); g.ricarica(); apri(x.id);
    });
    pannello.apri("Nuova sede operativa", S.linguette([{ titolo: "Dati e indirizzo", contenuto: m.dati }, { titolo: "Contatti e verbali", contenuto: m.contatti }]), [salva], { largo: true });
  }

  async function apri(id) {
    let x;
    try { x = await api("GET", `/api/sedi/${id}`); } catch (e) { return errore(e); }
    const m = modulo(x, { id: x.cliente_id, ragione_sociale: x.cliente });
    const impianti = el("div", { class: "subtle" }, "Caricamento…");
    const attrezzature = el("div", { class: "subtle" }, "Caricamento…");
    if (dm || x.n_attrezzature) api("GET", `/api/beni?sede_id=${x.id}&per_pagina=500`).then((d) => attrezzature.replaceChildren(
      S.tabella([
        { titolo: "Gruppo", valore: (r) => r.gruppo }, { titolo: "Attrezzatura", valore: (r) => [r.denominazione, r.matricola].filter(Boolean).join(" · ") },
        { titolo: "Stato", valore: (r) => (r.dismesso ? "Dismessa" : "In servizio") },
      ], d.righe.filter((r) => r.gruppo !== "DPR"), (r) => { location.href = `/attrezzature?scheda=${r.id}`; }),
      el("p", {}, el("a", { class: "subtle", href: S.filtro("attrezzature-gvr", "sede_id", x.id, `attrezzature GVR della sede ${x.denominazione}`) }, "Attrezzature GVR della sede"),
        " · ", el("a", { class: "subtle", href: S.filtro("attrezzature-scsp", "sede_id", x.id, `attrezzature SC/SP della sede ${x.denominazione}`) }, "Attrezzature SC/SP della sede"),
        " · ", el("a", { class: "subtle", href: S.filtro("valvole-sicurezza", "sede_id", x.id, `accessori della sede ${x.denominazione}`) }, "Accessori · PSV"),
        " · ", el("a", { class: "subtle", href: S.filtro("scadenze-tecniche", "sede_id", x.id, `scadenze DM della sede ${x.denominazione}`) }, "Scadenze della sede")))).catch(errore);
    api("GET", `/api/sedi/${x.id}/impianti`).then((elenco) => impianti.replaceChildren(
      S.tabella([
        { titolo: "N.", valore: (r) => String(r.id) }, { titolo: "Tipologia", valore: (r) => r.tipologia },
        { titolo: "Denominazione", valore: (r) => r.denominazione }, { titolo: "kW", num: true, valore: (r) => GAD.formatta.numero(r.potenza_kw) },
        { titolo: "Prossima verifica", valore: (r) => GAD.formatta.data(r.prossima_verifica) }, { titolo: "Dismesso", valore: (r) => (r.dismesso ? "Sì" : "") },
      ], elenco, (r) => { location.href = `/impianti?apri=${r.id}`; }),
      S.puo("anagrafica.impianti") && x.attiva ? el("p", {}, el("a", { class: "btn small", href: `/impianti?nuovo=1&sede_id=${x.id}` }, "＋ Nuovo impianto in questa sede")) : null)).catch(errore);
    const storico = el("div");
    const testata = [el("div", { class: "riquadro" }, "Cliente: ", el("a", { href: `/clienti?apri=${x.cliente_id}` }, x.cliente), x.cliente_attivo ? "" : " (cliente disattivato)",
      dm ? ` · ${x.n_attrezzature} attrezzature` + (x.n_impianti ? ` · ${x.n_impianti} impianti` : "") : ` · ${x.n_impianti} impianti` + (x.n_attrezzature ? ` · ${x.n_attrezzature} attrezzature` : ""),
      x.origini && x.origini.length ? el("div", { class: "subtle" }, "Provenienza: " + x.origini.map((o) => `${o.sistema.replace("garda_", "Garda ")} · ${o.tabella} ${o.id_origine}`).join("; ")) : null)];
    if (!x.attiva) testata.unshift(el("div", { class: "notice" }, "Sede chiusa: resta in archivio con i suoi impianti."));
    const av = S.avvisi(x.avvisi, m.campi.avvisi);
    if (av) testata.unshift(av);
    const corpo = el("div", {}, ...testata, S.linguette([
      { titolo: "Dati e indirizzo", contenuto: m.dati }, { titolo: "Contatti e verbali", contenuto: m.contatti },
      ...(dm ? [{ titolo: `Attrezzature (${x.n_attrezzature})`, contenuto: attrezzature }] : []),
      ...(!dm || x.n_impianti ? [{ titolo: `Impianti (${x.n_impianti})`, contenuto: impianti }] : []),
      ...(!dm && x.n_attrezzature ? [{ titolo: `Attrezzature (${x.n_attrezzature})`, contenuto: attrezzature }] : []),
      { titolo: "Storico", contenuto: storico, apri: async () => storico.replaceChildren(await S.storico("sede", x.id)) },
    ]), S.traccia(x));
    const pulsanti = [];
    if (S.puo("anagrafica.disattiva")) {
      pulsanti.push(S.azione(x.attiva ? "Segna come chiusa" : "Riapri", x.attiva ? "danger" : "", async () => {
        if (x.attiva && !(await conferma("Segnare la sede come chiusa?", "La sede resta in archivio con i suoi impianti; non si potranno aggiungere impianti nuovi.", { pulsante: "Chiudi la sede", pericolo: true }))) return;
        await api("POST", `/api/sedi/${x.id}/attiva`, { attiva: !x.attiva, versione: x.versione });
        toast("Fatto."); g.ricarica(); apri(x.id);
      }));
    }
    if (S.puo("anagrafica.sedi") && !x.n_impianti) {
      pulsanti.push(S.azione("Elimina", "danger", async () => {
        if (!(await conferma("Eliminare la sede?", `«${x.denominazione}» non ha impianti: viene eliminata (i dati restano nel registro).`, { pulsante: "Elimina", pericolo: true }))) return;
        await api("DELETE", `/api/sedi/${x.id}`); toast("Sede eliminata."); pannello.chiudi(); g.ricarica();
      }));
    }
    if (S.puo("anagrafica.sedi")) pulsanti.push(S.azione("Unisci con…", "", () => unisciCon(x)));
    pulsanti.push(el("span", { class: "spazio" }));
    if (S.puo("anagrafica.sedi")) {
      pulsanti.push(S.azione("Salva", "primary", async () => {
        await api("PUT", `/api/sedi/${x.id}`, { ...m.valori(), versione: x.versione });
        toast("Modifiche salvate."); g.ricarica(); apri(x.id);
      }));
    } else S.solaLettura(corpo);
    pannello.apri(x.denominazione, corpo, pulsanti, { largo: true });
  }

  // ---- sedi doppie (R116): stesso stabilimento entrato due volte (es. da ingecert e da adsrl)
  const NOMI_AMBITI = { DPR: "AD_DPR", DM: "AD_DM", IEC: "I&C" };
  const descriviSede = (x) => el("div", {},
    el("strong", {}, x.denominazione), el("br"), `${x.indirizzo}, ${x.comune}`, el("br"),
    el("span", { class: "subtle" }, `n. ${x.id}${x.codice_esterno ? " · rif. " + x.codice_esterno : ""} · ${x.ambiti.map((a) => NOMI_AMBITI[a]).join(", ") || "nessun ambito"} · ${x.impianti} impianti · ${x.attrezzature} attrezzature${x.attiva ? "" : " · chiusa"}`));

  async function unisci(origine, destinazione) {
    if (!(await conferma("Unire le due sedi?", `Resta «${destinazione.denominazione}»: impianti, attrezzature, accessori e preventivi di «${origine.denominazione}» passano lì e la sede «${origine.denominazione}» viene eliminata. I campi vuoti si completano; i dati diversi (referente, email, denominazione…) finiscono nelle note. Tutto resta nel registro.`, { pulsante: "Unisci" }))) return false;
    await api("POST", `/api/sedi/${origine.id}/unisci`, { destinazione_id: destinazione.id });
    toast("Sedi unite."); g.ricarica();
    return true;
  }

  async function doppioni() {
    // revisione dell'11/10/2026: dopo ogni scelta l'elenco si rilegge dal server (una sede unita può comparire in più coppie)
    let tutte = false;
    const area = el("div", {}, el("p", { class: "subtle" }, "Caricamento…"));
    pannello.apri("Possibili doppioni di sede", area, [], { largo: true });
    const disegna = async () => {
      const elenco = await api("GET", "/api/sedi/doppioni");
      const mostrate = elenco.filter((c) => tutte || c.punteggio >= 0.6);
      const righe = mostrate.map((c) => {
        const riga = el("div", { class: "riquadro" },
          el("p", {}, el("strong", {}, c.cliente), " · ", c.stesso_indirizzo ? el("strong", {}, "stesso indirizzo") : `somiglianza dell'indirizzo ${Math.round(c.punteggio * 100)}%`),
          el("div", { class: "field-grid" }, descriviSede(c.a), descriviSede(c.b)));
        if (S.puo("anagrafica.sedi")) {
          riga.append(el("div", { class: "riga-campi" },
            S.azione(`Unisci: resta «${c.a.denominazione.slice(0, 30)}»`, "small primary", async () => { if (await unisci(c.b, c.a)) await disegna(); }),
            S.azione(`Unisci: resta «${c.b.denominazione.slice(0, 30)}»`, "small", async () => { if (await unisci(c.a, c.b)) await disegna(); }),
            S.azione("Sono sedi diverse", "small", async () => { await api("POST", "/api/sedi/doppioni/diverse", { a: c.a.id, b: c.b.id }); toast("Non verranno più proposte."); await disegna(); })));
        }
        return riga;
      });
      const altre = elenco.length - mostrate.length;
      area.replaceChildren(
        el("p", { class: "subtle" }, `Sedi dello stesso cliente nello stesso comune, una AD_DPR e l'altra AD_DM. ${mostrate.length} coppie probabili` + (altre ? `, ${altre} meno probabili (indirizzo diverso).` : ".")),
        altre && !tutte ? el("p", {}, el("button", { class: "btn small", type: "button", onclick: () => { tutte = true; disegna().catch(errore); } }, `Mostra anche le altre ${altre}`)) : null,
        ...(righe.length ? righe : [el("p", {}, "Nessun possibile doppione.")]));
    };
    await disegna();
  }

  async function unisciCon(x) {
    const altre = (await api("GET", `/api/clienti/${x.cliente_id}/sedi`)).filter((y) => y.id !== x.id);
    if (!altre.length) return errore(new Error("Il cliente non ha altre sedi."));
    const scelta = S.f.scelta(altre.map((y) => ({ valore: y.id, testo: `${y.denominazione} · ${y.indirizzo}, ${y.comune}` })), altre[0].id);
    const ok = await modale("Unisci questa sede con un'altra", [el("p", {}, `La sede «${x.denominazione}» verrà unita in quella scelta, che resta.`), S.campo("Sede che resta", scelta)],
      [{ testo: "Annulla", valore: false }, { testo: "Avanti", classe: "primary", valore: true }]);
    if (!ok) return;
    const dest = altre.find((y) => String(y.id) === scelta.value);
    if (await unisci(x, dest)) { pannello.chiudi(); location.href = `/sedi?apri=${dest.id}`; }
  }

  document.getElementById("nuovo")?.addEventListener("click", () => nuova(S.daFiltro("cliente_id")));  // O5
  const richiesta = S.apriDaIndirizzo(apri);
  if (richiesta && richiesta.nuovo) nuova(richiesta.cliente_id);
})().catch((e) => GAD.errore(e));
