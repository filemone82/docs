/* Tipi e tariffe (0.12.8): i cataloghi di Garda in una schermata con le linguette — tipi di attrezzature, tipi GVR,
   ID specifiche, tipi attr./ID specifiche, tariffe SC/SP e GVR. In sola lettura (R117). */
"use strict";

(async () => {
  const linguette = [...document.querySelectorAll("[data-catalogo]")];
  const contenitore = document.getElementById("griglia");
  async function mostra(b) {
    for (const x of linguette) x.classList.toggle("active", x === b);
    contenitore.replaceChildren();
    history.replaceState(null, "", `/cataloghi?scheda=${b.dataset.nome}`);
    await GAD.griglia(contenitore, b.dataset.catalogo, {});
  }
  for (const b of linguette) b.addEventListener("click", () => mostra(b).catch(GAD.errore));
  const scelta = new URLSearchParams(location.search).get("scheda");
  await mostra(linguette.find((b) => b.dataset.nome === scelta) || linguette[0]);
})().catch((e) => GAD.errore(e));
