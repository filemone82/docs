/* Pagina iniziale: stato in breve. */
"use strict";

(async () => {
  const { el, api, formatta } = GAD;
  const ambito = document.documentElement.dataset.ambito;
  const schede = document.getElementById("schede-stato");
  const io = await api("GET", "/api/io");
  const elenco = [el("div", { class: "stat" }, el("strong", {}, io.nome), el("span", {}, `Ruolo: ${io.ruolo} · ${io.permessi.length} permessi`))];
  if (ambito === "DPR" && io.permessi.includes("scadenze.vedere")) {
    try {
      const conta = async (filtri) => (await api("POST", "/api/griglie/scadenze/dati", { pagina: 1, dimensione: 25, filtri })).totale;
      const [scadute, mese] = await Promise.all([conta([{ campo: "stato_scadenza", valore: "Scaduta" }]), conta([{ campo: "stato_scadenza", valore: "Entro 30 giorni" }])]);
      elenco.push(el("div", { class: "stat" }, el("strong", {}, `${formatta.numero(scadute)} scadute · ${formatta.numero(mese)} entro 30 giorni`),
        el("span", {}, "Verifiche periodiche (impianti non dismessi)")));
    } catch (_) { /* nessun dato */ }
  }
  if (io.permessi.includes("anagrafica.vedere")) {
    try {
      const c = await api("POST", "/api/griglie/clienti/dati", { pagina: 1, dimensione: 25 });
      elenco.push(el("div", { class: "stat" }, el("strong", {}, `${formatta.numero(c.totale)} clienti`), el("span", {}, "Anagrafica condivisa")));
    } catch (_) { /* nessun dato */ }
  }
  if (io.permessi.includes("sistema.backup")) {
    try {
      const r = await api("POST", "/api/griglie/backup/dati", { pagina: 1, dimensione: 25 });
      const ultimo = r.righe[0];
      elenco.push(el("div", { class: "stat" },
        el("strong", {}, ultimo ? formatta.dataora(ultimo.creato_il) : "Nessun backup"),
        el("span", {}, ultimo ? `Ultimo backup (${ultimo.tipo}) · ${r.totale} backup in archivio` : "Crea il primo da «Backup e integrità»")));
    } catch (_) { /* nessun dato */ }
  }
  if (io.permessi.includes("sistema.registro")) {
    try {
      const r = await api("POST", "/api/griglie/registro/dati", { pagina: 1, dimensione: 25 });
      elenco.push(el("div", { class: "stat" }, el("strong", {}, formatta.numero(r.totale)), el("span", {}, "Operazioni nel registro")));
    } catch (_) { /* nessun dato */ }
  }
  schede.replaceChildren(...elenco);
})();
