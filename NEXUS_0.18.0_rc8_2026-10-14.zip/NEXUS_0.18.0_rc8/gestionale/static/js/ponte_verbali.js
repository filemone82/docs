// Verbali nel gestionale (0.5.0): apre il verbale indicato nell'indirizzo (/verbali?apri=<id>).
// VerbalizzAI riapre da solo l'ultimo verbale salvato in sessionStorage («ad_open»).
// 0.12.7 (R122): /verbali?scheda=<impianto di VerbalizzAI>&modulo=M01 apre la «Scheda impianto» (la scheda tecnica unica).
(function () {
  "use strict";
  var q = new URLSearchParams(location.search);
  var id = q.get("apri");
  if (id && /^[A-Za-z0-9_-]{1,64}$/.test(id)) {
    try { sessionStorage.setItem("ad_open", JSON.stringify({ id: id })); } catch (e) { /* niente */ }
  }
  var scheda = q.get("scheda"), modulo = q.get("modulo") || "M01";
  if (scheda && /^[A-Za-z0-9_-]{1,64}$/.test(scheda) && /^M0[123]$/.test(modulo)) {
    try { sessionStorage.removeItem("ad_open"); } catch (e) { /* niente */ }
    var tentativi = 0;
    var attesa = setInterval(function () {
      tentativi += 1;
      // `summary` e `openPlantState` sono di app.js (VerbalizzAI, non modificato): pronti dopo il caricamento dell'archivio
      var pronto = false;
      try { pronto = typeof summary !== "undefined" && !!summary && typeof openPlantState === "function"; } catch (e) { pronto = false; }
      if (pronto) {
        clearInterval(attesa);
        openPlantState(scheda, modulo).catch(function (err) { if (typeof toastModal === "function") toastModal(err.message); });
      } else if (tentativi > 300) clearInterval(attesa);
    }, 100);
  }
  // 0.12.8: /verbali?vista=templates|signatures|instruments (da Gestione › Configurazione) apre quella sezione di VerbalizzAI
  var vista = q.get("vista");
  if (vista && /^(templates|signatures|instruments|reports|drafts|archive)$/.test(vista)) {
    try { sessionStorage.removeItem("ad_open"); } catch (e) { /* niente */ }
    var prove = 0;
    var attendi = setInterval(function () {
      prove += 1;
      var b = document.querySelector('nav button[data-view="' + vista + '"]');
      var pronto = false;
      try { pronto = typeof summary !== "undefined" && !!summary; } catch (e) { pronto = false; }
      if (pronto && b && !b.hidden) { clearInterval(attendi); b.click(); }
      else if (prove > 300) clearInterval(attendi);
    }, 100);
  }
  if (q.has("apri") || q.has("scheda") || q.has("vista")) history.replaceState(null, "", location.pathname);
})();

// rc8 (B2, Federico 14/10/2026): il numero del verbale lo assegna NEXUS (registrazione della verifica) e segue la data
// del verbale: cambiando l'anno, al salvataggio arriva il primo numero libero di quell'anno. Il campo non si scrive a mano;
// dopo ogni salvataggio la pagina mostra il numero restituito dal server. VerbalizzAI non è modificato (R111).
(function () {
  "use strict";
  var originale = window.fetch;
  window.fetch = function (url) {
    var promessa = originale.apply(this, arguments);
    var percorso = typeof url === "string" ? url.split("?")[0] : "";
    if (/\/api\/draft\/save$/.test(percorso)) {
      promessa.then(function (r) {
        if (!r.ok) return;
        r.clone().json().then(function (x) {
          try {
            var h = x && x.item && x.item.data && x.item.data.header;
            // `item` e `composeNumber` sono di app.js (VerbalizzAI)
            if (!h || typeof item === "undefined" || !item || item.id !== x.item.id) return;
            if (item.data.header.number === h.number && String(item.data.header.number_seq) === String(h.number_seq)) return;
            item.data.header.number = h.number;
            item.data.header.number_seq = h.number_seq;
            var campo = document.getElementById("num-seq");
            if (campo) campo.value = h.number_seq || "";
            if (typeof composeNumber === "function") composeNumber();
            if (typeof toast === "function") toast("Numero del verbale assegnato da NEXUS: " + h.number);
          } catch (e) { /* niente: al prossimo caricamento la pagina mostra il numero giusto */ }
        }).catch(function () { /* risposta non JSON */ });
      }).catch(function () { /* errore di rete: lo gestisce VerbalizzAI */ });
    }
    return promessa;
  };
  function blocca() {
    var campo = document.getElementById("num-seq");
    if (!campo || campo.readOnly) return;
    campo.readOnly = true;
    campo.classList.add("numero-nexus");
    campo.title = "Numero assegnato da NEXUS alla registrazione della verifica";
    var riga = campo.closest(".numrow");
    if (riga && !riga.parentNode.querySelector(".nota-numero-nexus")) {
      var nota = document.createElement("div");
      nota.className = "old-value nota-numero-nexus";
      nota.textContent = "Numero assegnato da NEXUS: se cambi l'anno della data del verbale, al salvataggio riceve il primo numero libero di quell'anno.";
      riga.parentNode.insertBefore(nota, riga.nextSibling);
    }
  }
  new MutationObserver(blocca).observe(document.documentElement, { childList: true, subtree: true });
})();

// rc8 (D3, Federico 14/10/2026): un solo percorso NEXUS. La striscia sotto la barra mostra
// - con un verbale aperto: la verifica da cui nasce, il suo stato, il passo successivo e «← Torna alla verifica»
//   (dopo l'emissione il ritorno diventa il pulsante principale);
// - altrimenti: le viste dei verbali (Verbali emessi, Bozze, Clienti e impianti), che sostituiscono il menu laterale
//   di VerbalizzAI nascosto. Le viste di configurazione (template, firme, strumenti) si aprono da Gestione › Configurazione.
// Usa `view` e `item` di app.js (VerbalizzAI, non modificato) in sola lettura.
(function () {
  "use strict";
  var striscia = document.getElementById("nexus-contesto");
  if (!striscia) return;
  var VISTE = [["reports", "Verbali emessi"], ["drafts", "Bozze"], ["archive", "Clienti e impianti"]];
  var cache = {}, ultimo = "", emesso = {};
  function vistaCorrente() { try { return typeof view !== "undefined" ? view : ""; } catch (e) { return ""; } }
  function verbaleAperto() { try { return vistaCorrente() === "editor" && item && item.id ? item : null; } catch (e) { return null; } }
  function el(tag, attr, testo) {
    var x = document.createElement(tag);
    Object.keys(attr || {}).forEach(function (k) { x.setAttribute(k, attr[k]); });
    if (testo != null) x.textContent = testo;
    return x;
  }
  function linguette() {
    var box = el("div", { class: "nc-linguette", role: "tablist" });
    VISTE.forEach(function (v) {
      var b = el("button", { type: "button", "data-vista": v[0] }, v[1]);
      if (vistaCorrente() === v[0]) b.className = "attiva";
      b.addEventListener("click", function () {
        var nascosto = document.querySelector('.sidebar [data-view="' + v[0] + '"]');
        if (nascosto) nascosto.click();
      });
      box.appendChild(b);
    });
    return box;
  }
  function mostraVerifica(x, appenaEmesso) {
    striscia.textContent = "";
    var ritorno = el("a", { class: "nc-ritorno" + (appenaEmesso ? " primario" : ""), href: x.url }, appenaEmesso ? "Verbale emesso · Torna alla verifica →" : "← Torna alla verifica");
    striscia.appendChild(ritorno);
    striscia.appendChild(el("span", { class: "nc-titolo" }, "Verifica n. " + x.id + " · " + (x.codice_verbale || "")));
    striscia.appendChild(el("span", { class: "nc-tenue" }, [x.cliente, x.sede].filter(Boolean).join(" · ")));
    striscia.appendChild(el("span", { class: "nc-stato" }, x.stato_testo));
    if (x.prossimo) {
      var p = el("span", { class: "nc-prossimo" }, "Passo successivo: ");
      p.appendChild(el("b", {}, x.prossimo));
      striscia.appendChild(p);
    }
    striscia.hidden = false;
  }
  function aggiorna(forza) {
    var it = verbaleAperto();
    var chiave = it ? "v:" + it.id + ":" + (emesso[it.id] ? 1 : 0) : "l:" + vistaCorrente();
    if (chiave === ultimo && !forza) return;
    ultimo = chiave;
    if (!it) {
      striscia.textContent = "";
      striscia.appendChild(linguette());
      striscia.hidden = false;
      return;
    }
    var id = it.id;
    var promessa = (!forza && cache[id]) ? Promise.resolve(cache[id]) :
      fetch("/api/verbali/" + encodeURIComponent(id) + "/verifica", { credentials: "same-origin" }).then(function (r) { return r.ok ? r.json() : { verifica: null }; });
    promessa.then(function (x) {
      cache[id] = x;
      if (ultimo !== chiave) return;
      if (x && x.verifica) mostraVerifica(x.verifica, !!emesso[id]);
      else { striscia.textContent = ""; striscia.hidden = true; }
    }).catch(function () { striscia.hidden = true; });
  }
  // dopo l'emissione la verifica cambia stato: si rilegge e il ritorno diventa il pulsante principale
  var originale = window.fetch;
  window.fetch = function (url, opzioni) {
    var promessa = originale.apply(this, arguments);
    var percorso = typeof url === "string" ? url.split("?")[0] : "";
    if (/\/api\/(review|inspection)\/issue$/.test(percorso)) {
      promessa.then(function (r) {
        if (!r.ok) return;
        try { var id = JSON.parse((opzioni && opzioni.body) || "{}").id; if (id) { emesso[id] = true; delete cache[id]; setTimeout(function () { aggiorna(true); }, 300); } }
        catch (e) { /* niente */ }
      }).catch(function () { /* niente */ });
    }
    return promessa;
  };
  setInterval(aggiorna, 500);
})();
