/* Destinazioni dei documenti (rc8, punto 5 · D2, Federico 14/10/2026): una cartella del server per categoria.
   NEXUS gira sul server (VPS Ubuntu): il percorso è del server o di uno spazio condiviso montato lì, non del PC. */
"use strict";

(async () => {
  const { el, api, toast, errore } = GAD;
  const S = GAD.schede;
  const box = document.getElementById("impostazioni");
  async function disegna() {
    const { destinazioni } = await api("GET", "/api/impostazioni/destinazioni");
    const campi = {};
    const righe = destinazioni.map((d) => {
      const input = el("input", { type: "text", value: d.percorso || "", placeholder: "/srv/nexus/documenti/" + d.categoria, spellcheck: "false" });
      campi[d.categoria] = input;
      const esito = el("div", { class: "subtle esito-prova" });
      const proviamo = S.azione("Prova", "", async () => {
        const r = await api("POST", "/api/impostazioni/destinazioni/prova", { percorso: input.value });
        esito.className = "esito-prova notice " + (r.esito === "ok" ? "ok" : "avviso");
        esito.textContent = r.messaggio;
      });
      const stato = d.copia_attiva ? "Copia automatica attiva all'emissione" : "Copia automatica non ancora attiva (destinazione già impostabile)";
      return el("div", { class: "riga-destinazione" },
        el("div", { class: "rd-nome" }, el("strong", {}, d.nome), el("div", { class: "subtle" }, stato),
          d.da_config ? el("div", { class: "subtle" }, "Valore preso da config.json (cartella_verbali_dm): salvandolo qui vale questo.") : null),
        el("div", { class: "rd-campo" }, input, proviamo), esito);
    });
    box.replaceChildren(
      el("div", { class: "panel" }, el("h3", {}, "Cartelle del server per le copie dei documenti definitivi"),
        el("p", { class: "subtle" }, "NEXUS salva una copia dei documenti definitivi in queste cartelle del server (o di uno spazio condiviso montato sul server). " +
          "Non sono cartelle del tuo PC: sul PC i documenti si scaricano dal browser. La copia non sostituisce l'archivio del gestionale né il backup. " +
          "Lascia vuoto per non salvare copie. Le schede tecniche DM senza destinazione propria vanno con i verbali DM."),
        ...righe,
        el("div", { class: "actions" }, S.azione("Salva le destinazioni", "primary", async () => {
          await api("PUT", "/api/impostazioni/destinazioni", Object.fromEntries(Object.entries(campi).map(([k, v]) => [k, v.value])));
          toast("Destinazioni salvate."); disegna();
        }))));
  }
  disegna().catch(errore);
})();
