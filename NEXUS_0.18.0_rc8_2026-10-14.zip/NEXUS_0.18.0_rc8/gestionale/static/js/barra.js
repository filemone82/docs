// rc8 (D3, Federico 14/10/2026): comportamento della barra di NEXUS in alto. File autonomo: lo usano le pagine del
// gestionale (con GAD di base.js) e la pagina del verbale (senza GAD, con lo stile di VerbalizzAI).
// - tendine: una alla volta, si chiudono con un clic fuori o con Esc; il gruppo della pagina è solo evidenziato;
// - «☰ Menu» su finestre strette;
// - scelta dell'attività (navigazione, non permessi: li controlla il server) ed «Esci».
(() => {
  "use strict";
  const barra = document.getElementById("barra-nexus");
  if (!barra) return;
  const csrf = document.querySelector('meta[name="csrf"]')?.content || "";
  // GAD (base.js) è una costante globale: c'è nelle pagine del gestionale, non nella pagina del verbale
  const gad = typeof GAD !== "undefined" ? GAD : null;
  async function chiama(metodo, url, dati) {
    if (gad) return gad.api(metodo, url, dati);
    const r = await fetch(url, { method: metodo, credentials: "same-origin", headers: { "Content-Type": "application/json", "X-CSRF-Token": csrf, Accept: "application/json" },
      body: dati === undefined ? undefined : JSON.stringify(dati) });
    const x = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(x.errore || "Operazione non riuscita.");
    return x;
  }
  const conferma = (titolo, testo) => (gad ? gad.conferma(titolo, testo) : Promise.resolve(window.confirm(titolo + "\n\n" + testo)));
  const errore = (e) => (gad ? gad.errore(e) : window.alert(e.message || e));

  const tendine = [...barra.querySelectorAll("details.nav-gruppo, details.nav-utente")];
  const chiudi = (tranne) => { for (const d of tendine) if (d !== tranne && d.open) d.open = false; };
  for (const d of tendine) d.addEventListener("toggle", () => { if (d.open) chiudi(d); });
  const pulsante = document.getElementById("menu-apri");
  const apriMenu = (aperto) => {
    barra.classList.toggle("menu-aperto", aperto);
    pulsante?.setAttribute("aria-expanded", String(aperto));
  };
  pulsante?.addEventListener("click", () => apriMenu(!barra.classList.contains("menu-aperto")));
  document.addEventListener("click", (e) => {
    if (barra.contains(e.target)) return;
    chiudi(null);
    apriMenu(false);
  });
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    if (tendine.some((d) => d.open) || barra.classList.contains("menu-aperto")) { chiudi(null); apriMenu(false); }
  });

  document.getElementById("esci")?.addEventListener("click", async () => {
    try { await chiama("POST", "/api/uscita"); } catch (_) { /* si esce comunque */ }
    location.href = "/accesso";
  });

  const selettore = document.getElementById("ambito-attivo");
  selettore?.addEventListener("change", async () => {
    if (!await conferma("Cambiare attività?", "Le modifiche non salvate nella pagina corrente verranno abbandonate.")) {
      selettore.value = selettore.dataset.attuale;
      return;
    }
    selettore.disabled = true;
    try {
      const scelta = await chiama("POST", "/api/ambito-attivo", { ambito: selettore.value });
      location.assign(scelta.url);
    } catch (e) {
      selettore.value = selettore.dataset.attuale;
      selettore.disabled = false;
      errore(e);
    }
  });
})();
