/* Righe dei preventivi (DPR e DM): una riga per impianto o attrezzatura preventivati, con lo stato di accettazione,
   la verifica (o l'incarico DM) nata dalla riga e i dati di sede e cliente.
   0.12.6 (Federico, 11/10/2026): dalle righe accettate si affida l'incarico di verifica, come in Garda. */
"use strict";

(async () => {
  const { el, api, toast, errore, modale } = GAD;
  const S = GAD.schede;
  const { f, campo } = S;
  await S.me();
  const dm = location.pathname === "/righe-preventivi-dm";
  const scheda = dm ? "/preventivi-dm" : "/preventivi";
  const url = new URLSearchParams(location.search);
  const preventivoId = Number(url.get("preventivo_id") || (url.get("campo") === "preventivo_id" ? url.get("valore") : 0));
  if (!Number.isInteger(preventivoId) || preventivoId <= 0) {
    document.getElementById("griglia").replaceChildren(el("div", {class: "notice"},
      "Apri le righe dagli elementi collegati di un singolo preventivo. ", el("a", {href: scheda}, "Vai ai preventivi")));
    return;
  }
  const preventivo = await api("GET", `/api/preventivi/${preventivoId}`);
  if (preventivo.ambito !== (dm ? "DM" : "DPR")) throw new Error("Preventivo di un'altra attività.");
  const filtro = (testo, filtri) => el("button", { class: "btn small", type: "button", onclick: () => {
    g.tabella.clearHeaderFilter();
    for (const [c, v] of Object.entries(filtri)) g.filtra(c, v);
  } }, testo);
  const puoAffidare = S.puo("verifiche.assegna", dm ? "DM" : "DPR");
  const puoFatturare = S.puo("fatture.genera");
  const pulsanti = [
    filtro("Accettate (da organizzare)", { stato_riga: "Accettata" }),
    puoAffidare ? filtro("Da affidare", { stato_riga: "Accettata", verifica_stato: "Da assegnare" }) : null,
    filtro("Da fatturare", { da_fatturare: "Sì" }),
    filtro("In attesa", { stato_riga: "In attesa" }), filtro("Tutte", {}),
    puoAffidare ? el("button", { class: "btn small primary", type: "button", onclick: () => affida().catch(errore) }, "Affida le selezionate…") : null,
    puoFatturare ? el("button", { class: "btn small primary", type: "button", onclick: () => fattura().catch(errore) }, "Fattura le selezionate…") : null,
  ].filter(Boolean);

  // N7 / R125 (0.12.8): come «Genera fattura cliente» di Garda, una bozza con tutte le righe selezionate
  async function fattura() {
    const scelte = g.selezionate();
    if (!scelte.length) throw new Error("Spunta le righe da fatturare (casella a sinistra di ogni riga).");
    const no = scelte.filter((r) => r.da_fatturare !== "Sì");
    if (no.length) throw new Error(`${no.length} righe non sono da fatturare (lavoro non concluso o non riesaminato, oppure già fatturate): togli la spunta.`);
    await S.fatturaRighe({ righe: scelte.map((r) => r.id), clienti: [...new Set(scelte.map((r) => r.cliente_id))], dm,
      totale: scelte.reduce((t, r) => t + (r.tariffa_applicata || 0), 0) });
  }

  async function affida() {
    if (await S.affidaRighe(g.selezionate(), dm)) g.ricarica();
  }

  const g = await GAD.griglia(document.getElementById("griglia"), dm ? "righe_preventivi_dm" : "righe_preventivi", {
    contesto: {preventivo_id: preventivoId},
    etichettaContesto: `Righe del preventivo ${preventivo.etichetta || preventivo.codice}`,
    selezione: puoAffidare || puoFatturare,
    suRiga: puoAffidare || puoFatturare ? null : (r) => { location.href = `${scheda}?apri=${r.preventivo_id}`; },
    pulsanti,
    azioni: {
      modifica: (r) => { location.href = `${scheda}?apri=${r.preventivo_id}`; },
      collegamenti: [
        { testo: "Preventivo → scheda", vai: (r) => `${scheda}?apri=${r.preventivo_id}` },
        dm ? { testo: "Verifica → scheda", vai: (r) => (r.verifica_id ? `/incarichi-dm?apri=${r.verifica_id}` : `${scheda}?apri=${r.preventivo_id}`) }
          : { testo: "Verifica → scheda", vai: (r) => (r.verifica_id ? `/verifiche?apri=${r.verifica_id}` : `${scheda}?apri=${r.preventivo_id}`) },
        dm ? { testo: "Attrezzatura → scheda", vai: (r) => `/attrezzature?scheda=${r.asset_id}` }
          : { testo: "Impianto → scheda", vai: (r) => `/impianti?apri=${r.impianto_id}` },
        { testo: "Cliente → scheda", vai: (r) => `/clienti?apri=${r.cliente_id}` },

      ].filter(Boolean),
    },
  });
})().catch((e) => GAD.errore(e));
