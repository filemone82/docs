"use strict";
(() => {
  const {el,api,errore,formatta} = GAD;
  let pagina=1;
  async function carica() {
    const par=new URLSearchParams({q:document.getElementById("ricerca-date").value,gruppo:document.getElementById("gruppo-date").value,solo_attivi:document.getElementById("attivi-date").checked,pagina});
    const d=await api("GET","/api/beni/scadenze?"+par);
    document.getElementById("riepilogo-date").textContent=`${d.totale} date tecniche · pagina ${pagina}`;
    document.getElementById("lista-date").replaceChildren(el("table",{class:"tabella-semplice"},
      el("thead",{},el("tr",{},["Gruppo","Cliente / sede","Bene","Attività","Ultima","Prossima","Report / verbale","Fonte"].map(t=>el("th",{},t)))),
      el("tbody",{},d.righe.map(x=>el("tr",{},[x.gruppo,`${x.cliente} · ${x.sede}`,el("a",{href:`/attrezzature?scheda=${x.asset_id}`},x.bene),x.componente,formatta.data(x.data_ultima),formatta.data(x.data_prossima),x.numero_report,x.fonte].map(t=>el("td",{},t)))))));
    document.getElementById("date-prima").disabled=pagina<=1;document.getElementById("date-dopo").disabled=pagina*100>=d.totale;
  }
  document.getElementById("cerca-date").onclick=()=>{pagina=1;carica().catch(errore);};
  document.getElementById("date-prima").onclick=()=>{pagina--;carica().catch(errore);};
  document.getElementById("date-dopo").onclick=()=>{pagina++;carica().catch(errore);};
  carica().catch(errore);
})();
