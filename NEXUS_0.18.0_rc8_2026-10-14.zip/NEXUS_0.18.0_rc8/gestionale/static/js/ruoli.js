/* Ruoli e permessi: elenco dei ruoli (creabili, D37) e tabella dei permessi a grana fine (D24). */
"use strict";

(async () => {
  const { el, api, toast, errore, conferma, pannello, campo } = GAD;

  // ---- schede
  for (const b of document.querySelectorAll("[data-scheda]")) {
    b.addEventListener("click", () => {
      for (const x of document.querySelectorAll("[data-scheda]")) x.classList.toggle("active", x === b);
      for (const s of document.querySelectorAll("[data-sezione]")) s.hidden = s.dataset.sezione !== b.dataset.scheda;
      if (b.dataset.scheda === "permessi") caricaMatrice();
    });
  }

  const g = await GAD.griglia(document.getElementById("griglia-ruoli"), "ruoli", { suRiga: (r) => apri(r.id), ...(document.getElementById("permessi") ? { altezza: "30vh" } : {}) });

  async function elencoRuoli() { return api("GET", "/api/ruoli"); }

  function modulo(r, tutti) {
    const nome = el("input", { maxlength: "80", value: r ? r.nome : "" });
    const descrizione = el("textarea", { maxlength: "500" }, r ? r.descrizione : "");
    const attivo = el("input", { type: "checkbox" });
    attivo.checked = r ? r.attivo : true;
    const parti = [campo("Nome del ruolo", nome, { pieno: true }), campo("Descrizione", descrizione, { pieno: true })];
    // R132: attività dei permessi tecnici (verifiche, verbali, strumenti, firme, riesami). Nessuna = ruolo comune.
    const att = { DPR: el("input", { type: "checkbox" }), DM: el("input", { type: "checkbox" }) };
    att.DPR.checked = !!(r && (r.attivita || []).includes("DPR"));
    att.DM.checked = !!(r && (r.attivita || []).includes("DM"));
    parti.push(campo("Attività", el("div", { class: "check-row" },
      el("label", { class: "check" }, att.DPR, "AD_DPR"), el("label", { class: "check" }, att.DM, "AD_DM")), { pieno: true,
      aiuto: "Per RT e verificatori: verifiche, verbali e riesami valgono solo nelle attività spuntate. L'RT ne ha una sola; " +
             "un verificatore può averle tutte e due. Nessuna spunta = ruolo comune (segreteria): i permessi tecnici valgono ovunque." }));
    let copia = null;
    if (!r) {
      copia = el("select", {}, el("option", { value: "" }, "Nessuno: parto senza permessi"), ...tutti.map((x) => el("option", { value: x.id }, x.nome)));
      parti.push(campo("Copia i permessi da", copia, { pieno: true, aiuto: "Comodo per creare un ruolo simile a uno esistente." }));
    } else {
      parti.push(el("label", { class: "check" }, attivo, "Ruolo attivo"));
    }
    return { nodo: el("div", { class: "field-grid" }, ...parti), valori: () => ({ nome: nome.value, descrizione: descrizione.value, attivo: attivo.checked, copia_da: copia && copia.value ? Number(copia.value) : null,
      attivita: ["DPR", "DM"].filter((k) => att[k].checked) }) };
  }

  document.getElementById("nuovo-ruolo").addEventListener("click", async () => {
    let tutti = [];
    try { tutti = await elencoRuoli(); } catch (e) { return errore(e); }
    const m = modulo(null, tutti);
    const salva = el("button", { class: "btn primary", type: "button" }, "Crea ruolo");
    salva.addEventListener("click", async () => {
      salva.disabled = true;
      try {
        await api("POST", "/api/ruoli", m.valori());
        toast("Ruolo creato. Assegna i permessi dalla scheda «Permessi per ruolo».");
        pannello.chiudi(); g.ricarica(); matriceCaricata = false;
      } catch (e) { errore(e); } finally { salva.disabled = false; }
    });
    pannello.apri("Nuovo ruolo", [m.nodo], [salva]);
  });

  async function apri(id) {
    let r;
    try { r = (await elencoRuoli()).find((x) => x.id === id); } catch (e) { return errore(e); }
    if (!r) return;
    if (r.di_sistema) {
      return pannello.apri(r.nome, [el("p", {}, r.descrizione), el("div", { class: "notice" }, "È il ruolo di sistema: ha sempre tutti i permessi e non si modifica. Deve sempre esserci almeno un utente attivo con questo ruolo.")]);
    }
    const m = modulo(r);
    const elimina = el("button", { class: "btn danger", type: "button" }, "Elimina");
    elimina.addEventListener("click", async () => {
      if (!(await conferma("Eliminare il ruolo?", `Si può eliminare solo un ruolo mai assegnato a nessun utente; altrimenti disattivalo.`, { pulsante: "Elimina", pericolo: true }))) return;
      try { await api("DELETE", `/api/ruoli/${r.id}`); toast("Ruolo eliminato."); pannello.chiudi(); g.ricarica(); matriceCaricata = false; } catch (e) { errore(e); }
    });
    const salva = el("button", { class: "btn primary", type: "button" }, "Salva");
    salva.addEventListener("click", async () => {
      try { await api("PUT", `/api/ruoli/${r.id}`, { ...m.valori(), versione: r.versione }); toast("Ruolo salvato."); g.ricarica(); matriceCaricata = false; apri(r.id); } catch (e) { errore(e); }
    });
    pannello.apri(r.nome, [m.nodo], [elimina, el("span", { class: "spazio" }), salva]);
  }

  // ---- matrice dei permessi
  let matriceCaricata = false;
  let dati = null;
  const modificati = new Map(); // ruolo_id -> Set(codici)
  const btnSalva = document.getElementById("salva-permessi");
  const statoTesto = document.getElementById("stato-permessi");

  function compresi(codici) {
    const mappa = Object.fromEntries(dati.permessi.map((p) => [p.codice, p.comprende]));
    const risultato = new Map(); // codice compreso -> codice che lo comprende
    const coda = [...codici];
    while (coda.length) {
      const c = coda.pop();
      for (const x of mappa[c] || []) if (!risultato.has(x)) { risultato.set(x, c); coda.push(x); }
    }
    return risultato;
  }

  function insiemeDi(ruolo) { return modificati.get(ruolo.id) || new Set(ruolo.permessi); }

  function disegna() {
    const ruoli = dati.ruoli.filter((r) => r.attivo || r.di_sistema);
    const nomi = Object.fromEntries(dati.permessi.map((p) => [p.codice, p.descrizione]));
    const intestazione = el("tr", {}, el("th", {}, "Operazione"), ...ruoli.map((r) => el("th", {}, r.nome)));
    const righe = [];
    let area = "";
    const compresiPerRuolo = Object.fromEntries(ruoli.map((r) => [r.id, compresi(insiemeDi(r))]));
    for (const p of dati.permessi) {
      if (p.area !== area) { area = p.area; righe.push(el("tr", { class: "area" }, el("td", { colspan: String(ruoli.length + 1) }, area))); }
      const celle = ruoli.map((r) => {
        const casella = el("input", { type: "checkbox", title: `${r.nome}: ${p.descrizione}` });
        const insieme = insiemeDi(r);
        const comprendente = compresiPerRuolo[r.id].get(p.codice);
        if (p.attivita && r.attivita?.length && !r.attivita.includes(p.attivita)) {
          casella.checked = false; casella.disabled = true;
          return el("td", {class: "casella"}, casella, el("div", {class: "compreso"}, "altra attività"));
        }
        if (r.di_sistema) { casella.checked = true; casella.disabled = true; }
        else if (comprendente && !insieme.has(p.codice)) {
          casella.checked = true; casella.disabled = true;
          return el("td", { class: "casella" }, casella, el("div", { class: "compreso", title: `Compreso in «${nomi[comprendente]}»` }, "compreso"));
        } else {
          casella.checked = insieme.has(p.codice);
          casella.addEventListener("change", () => {
            const nuovo = new Set(insiemeDi(r));
            casella.checked ? nuovo.add(p.codice) : nuovo.delete(p.codice);
            modificati.set(r.id, nuovo);
            aggiornaStato();
            disegna();
          });
        }
        return el("td", { class: "casella" }, casella);
      });
      const cambiata = ruoli.some((r) => modificati.has(r.id) && modificati.get(r.id).has(p.codice) !== r.permessi.includes(p.codice));
      righe.push(el("tr", { class: cambiata ? "modificata" : "" },
        el("td", {}, p.descrizione, p.disponibile ? null : el("span", { class: "in-arrivo", title: "Funzione delle prossime fasi" }, "in arrivo")),
        ...celle));
    }
    document.getElementById("matrice").replaceChildren(el("table", { class: "matrice" }, el("thead", {}, intestazione), el("tbody", {}, ...righe)));
  }

  function aggiornaStato() {
    const n = [...modificati.entries()].filter(([id, s]) => {
      const r = dati.ruoli.find((x) => x.id === id);
      return r && (s.size !== r.permessi.length || r.permessi.some((c) => !s.has(c)));
    }).length;
    btnSalva.disabled = n === 0;
    statoTesto.textContent = n ? `Modifiche non salvate su ${n} ruoli.` : "";
  }

  async function caricaMatrice(forza = false) {
    if (matriceCaricata && !forza) return;
    try {
      dati = await api("GET", "/api/permessi/matrice");
      modificati.clear();
      matriceCaricata = true;
      aggiornaStato();
      disegna();
    } catch (e) { errore(e); }
  }

  btnSalva.addEventListener("click", async () => {
    btnSalva.disabled = true;
    try {
      for (const [id, insieme] of modificati) {
        const r = dati.ruoli.find((x) => x.id === id);
        await api("PUT", "/api/permessi/ruolo", { ruolo_id: id, permessi: [...insieme], versione: r.versione });
      }
      toast("Permessi salvati. Valgono subito per gli utenti di quei ruoli.");
      await caricaMatrice(true);
    } catch (e) { errore(e); await caricaMatrice(true); }
  });

  // 0.12.8: nella pagina unica «Utenti e permessi» (come VerbalizzAI) la matrice si mostra subito
  if (!document.querySelector("[data-scheda]")) caricaMatrice();

  window.addEventListener("beforeunload", (e) => { if (!btnSalva.disabled) { e.preventDefault(); e.returnValue = ""; } });
})().catch((e) => GAD.errore(e));
