/* Strumenti comuni delle schede di dettaglio (versione 0.2): campi, schede a linguette, ricerca del comune,
   ricerca di cliente e sede, storico delle modifiche, apertura di una scheda da un'altra pagina. */
"use strict";

(() => {
  const { el, api, errore, formatta } = GAD;

  let io = null;
  /** Utente collegato e permessi (una sola richiesta per pagina). */
  async function me() {
    if (!io) io = await api("GET", "/api/io");
    GAD.utenteId = io.id;
    return io;
  }
  const puo = (codice, attivita = null) => {
    if (!io) return false;
    const a = attivita || ({"anagrafica.impianti": "DPR", "anagrafica.dismetti": "DPR",
      "beni.gestire": "DM", "beni.scadenze": "DM", "beni.dismetti": "DM"})[codice]
      || (document.documentElement.dataset.ambito === "DM" ? "DM" : "DPR");
    return (io.permessi_per_attivita?.[a] || io.permessi).includes(codice);
  };

  // ---------------------------------------------------------------- campi
  const f = {
    testo(valore = "", attr = {}) { return el("input", { value: valore ?? "", ...attr }); },
    area(valore = "", attr = {}) { const t = el("textarea", attr); t.value = valore ?? ""; return t; },
    data(iso = "", attr = {}) { return el("input", { type: "date", value: (iso || "").slice(0, 10), ...attr }); },
    numero(valore = "", attr = {}) {
      const v = valore === null || valore === undefined ? "" : String(valore).replace(".", ",");
      return el("input", { inputmode: "decimal", value: v, ...attr });
    },
    scelta(opzioni, valore = "", { vuota = null } = {}) {
      const s = el("select", {}, vuota !== null ? el("option", { value: "" }, vuota) : null,
        ...opzioni.map((o) => el("option", { value: o.valore }, o.testo)));
      s.value = valore === null || valore === undefined ? "" : String(valore);
      return s;
    },
    casella(etichetta, valore = false) {
      const c = el("input", { type: "checkbox" });
      c.checked = !!valore;
      return { el: el("label", { class: "check" }, c, etichetta), input: c, get valore() { return c.checked; } };
    },
  };

  /** Ambiti di lavoro di clienti e sedi (R114). Per un cliente o una sede nuovi: l'attività scelta in alto. */
  function ambiti(attuali) {
    const pagina = document.documentElement.dataset.ambito || "DPR";
    const scelti = new Set(Array.isArray(attuali) ? attuali : [pagina]);
    const caselle = Object.entries({ DPR: "AD_DPR", DM: "AD_DM", IEC: "I&C" }).map(([k, nome]) => [k, f.casella(nome, scelti.has(k))]);
    return { el: el("div", { class: "riga-campi" }, ...caselle.map(([, c]) => c.el)),
      get valore() { return caselle.filter(([, c]) => c.valore).map(([k]) => k); } };
  }

  /** Campo con etichetta; opzioni: aiuto, pieno (tutta la riga), due (due colonne). */
  function campo(etichetta, input, { aiuto = "", pieno = false, due = false } = {}) {
    if (input instanceof HTMLElement && !input.id) input.id = "c-" + Math.random().toString(36).slice(2, 9);
    const classi = "field" + (pieno ? " full" : "") + (due ? " due" : "");
    return el("div", { class: classi }, el("label", { for: input.id }, etichetta), input, aiuto ? el("div", { class: "aiuto" }, aiuto) : null);
  }

  const sezione = (titolo) => el("div", { class: "sezione-titolo" }, titolo);

  /** Linguette: [{titolo, contenuto}] → elemento. */
  function linguette(schede) {
    const pulsanti = schede.map((s, i) => el("button", { type: "button", class: i === 0 ? "active" : "" }, s.titolo));
    const corpi = schede.map((s, i) => { const c = el("div", { class: "scheda-tab" }, s.contenuto); c.hidden = i !== 0; return c; });
    pulsanti.forEach((b, i) => b.addEventListener("click", () => {
      pulsanti.forEach((x, j) => x.classList.toggle("active", i === j));
      corpi.forEach((x, j) => { x.hidden = i !== j; });
      if (schede[i].apri) schede[i].apri();
    }));
    return el("div", {}, el("div", { class: "tabs" }, ...pulsanti), ...corpi);
  }

  // ---------------------------------------------------------------- ricerca con suggerimenti
  /** Campo di ricerca con elenco di risultati. cerca(testo) → [{...}]; mostra(r) → [testo, sottotesto]. */
  function ricerca({ cerca, mostra, scelto = null, segnaposto = "Scrivi per cercare…", alCambio = () => {} }) {
    let valore = scelto;
    const input = el("input", { placeholder: segnaposto, autocomplete: "off" });
    const risultati = el("div", { class: "cerca-risultati", hidden: true });
    const nome = el("span", { class: "nome" });
    const cambia = el("button", { class: "btn small", type: "button" }, "Cambia");
    const riquadro = el("div", { class: "scelto" }, nome, cambia);
    const wrap = el("div", { class: "cerca-wrap" }, riquadro, input, risultati);
    function disegna() {
      riquadro.hidden = !valore;
      input.hidden = !!valore;
      if (valore) { const [a, b] = mostra(valore); nome.replaceChildren(a, b ? el("span", { class: "sotto" }, b) : ""); }
    }
    let attesa;
    let elenco = [];
    input.addEventListener("input", () => {
      clearTimeout(attesa);
      attesa = setTimeout(async () => {
        try { elenco = await cerca(input.value.trim()); } catch (e) { return errore(e); }
        risultati.replaceChildren(...(elenco.length ? elenco.map((r) => {
          const [a, b] = mostra(r);
          return el("button", { type: "button", onclick: () => { valore = r; risultati.hidden = true; input.value = ""; disegna(); alCambio(valore); } },
            a, b ? el("span", { class: "sotto" }, b) : "");
        }) : [el("div", { class: "subtle", style: null }, "  Nessun risultato")]));
        risultati.hidden = false;
      }, 250);
    });
    input.addEventListener("blur", () => setTimeout(() => { risultati.hidden = true; }, 200));
    cambia.addEventListener("click", () => { valore = null; disegna(); input.focus(); alCambio(null); });
    disegna();
    return { el: wrap, get valore() { return valore; }, imposta(v) { valore = v; disegna(); } };
  }

  // ---------------------------------------------------------------- indirizzo con ricerca del comune ISTAT (D49)
  /* Un solo campo «Comune»: scrivendo compaiono i suggerimenti dell'elenco ISTAT; scegliendone uno si
     compilano provincia, regione e CAP (per i comuni con più CAP si sceglie dall'elenco del campo CAP).
     Se si scrive il nome senza scegliere, all'uscita dal campo il comune viene riconosciuto da solo.
     Provincia e regione restano sempre visibili e modificabili (comuni esteri o non in elenco). */
  let numeroElenco = 0;
  function indirizzo(o = {}) {
    const via = f.testo(o.indirizzo, { maxlength: "200", placeholder: "Via e numero civico" });
    const comune = f.testo(o.comune, { maxlength: "100", placeholder: "Scrivi le prime lettere del comune…", autocomplete: "off" });
    const idElenco = "elenco-cap-" + (++numeroElenco);
    const elencoCap = el("datalist", { id: idElenco });
    const cap = f.testo(o.cap, { maxlength: "5", list: idElenco, placeholder: "CAP", autocomplete: "off" });
    const prov = f.testo(o.provincia, { maxlength: "2", placeholder: "es. TO" });
    const regione = f.testo(o.regione, { maxlength: "60" });
    const stato = el("div", { class: "aiuto" });
    const risultati = el("div", { class: "cerca-risultati", hidden: true });
    let codice = o.comune_istat || null;

    function mostraStato() {
      stato.textContent = codice ? "✓ Comune dell'elenco ISTAT" : (comune.value.trim() ? "Comune non trovato nell'elenco ISTAT: va bene per l'estero, altrimenti scegli dai suggerimenti." : "Scrivi le prime lettere e scegli dai suggerimenti.");
      stato.classList.toggle("ok-istat", !!codice);
    }
    function scegli(c) {
      codice = c.codice_istat;
      comune.value = c.nome; prov.value = c.sigla; regione.value = c.regione;
      elencoCap.replaceChildren(...c.cap.map((x) => el("option", { value: x })));
      if (c.cap.length === 1) cap.value = c.cap[0];
      else if (!c.cap.includes(cap.value)) { cap.value = ""; cap.placeholder = `scegli tra ${c.cap.length} CAP`; }
      risultati.hidden = true;
      mostraStato();
    }
    let attesa;
    let ultimi = [];
    comune.addEventListener("input", () => {
      if (codice) { prov.value = ""; regione.value = ""; elencoCap.replaceChildren(); }  // si cambia comune: via i dati del precedente
      codice = null; mostraStato();
      clearTimeout(attesa);
      const testo = comune.value.trim();
      if (testo.length < 2) { risultati.hidden = true; return; }
      attesa = setTimeout(async () => {
        try { ultimi = await api("GET", "/api/comuni?q=" + encodeURIComponent(testo)); } catch (e) { return errore(e); }
        risultati.replaceChildren(...(ultimi.length ? ultimi.map((c) => el("button", { type: "button", onmousedown: (ev) => { ev.preventDefault(); scegli(c); } },
          c.nome, el("span", { class: "sotto" }, `(${c.sigla}) ${c.regione}`))) : [el("div", { class: "vuoto" }, "Nessun comune con questo nome")]));
        risultati.hidden = false;
      }, 200);
    });
    comune.addEventListener("blur", async () => {
      setTimeout(() => { risultati.hidden = true; }, 150);
      const testo = comune.value.trim().toLowerCase();
      if (codice || !testo) return;
      try {
        const r = ultimi.length ? ultimi : await api("GET", "/api/comuni?q=" + encodeURIComponent(testo));
        const uguali = r.filter((c) => c.nome.toLowerCase() === testo && (!prov.value || c.sigla === prov.value.toUpperCase()));
        if (uguali.length === 1) scegli(uguali[0]);
      } catch (_) { /* resta come scritto */ }
    });
    // CAP dei comuni già scelti (per i comuni con più CAP)
    if (codice && o.comune) {
      api("GET", "/api/comuni?q=" + encodeURIComponent(o.comune)).then((r) => {
        const c = r.find((x) => x.codice_istat === codice);
        if (c) elencoCap.replaceChildren(...c.cap.map((x) => el("option", { value: x })));
      }).catch(() => {});
    }
    mostraStato();
    const blocco = [
      campo("Indirizzo", via, { pieno: true }),
      el("div", { class: "field" }, el("label", {}, "Comune"), el("div", { class: "cerca-wrap" }, comune, risultati), stato),
      campo("CAP", el("div", {}, cap, elencoCap)),
      campo("Provincia (sigla)", prov), campo("Regione", regione),
    ];
    return {
      elementi: blocco,
      valori: () => ({ indirizzo: via.value, comune_istat: codice || "", comune: comune.value.trim(), cap: cap.value.trim(),
        provincia: prov.value.trim().toUpperCase(), regione: regione.value.trim() }),
    };
  }

  // ---------------------------------------------------------------- avvisi «da controllare» e storico
  function avvisi(testo, campoArea) {
    if (!testo) return null;
    const svuota = el("button", { class: "btn small", type: "button", onclick: () => { campoArea.value = ""; box.replaceChildren(el("span", {}, "Segnalazioni tolte: salva la scheda per confermare.")); } }, "Ho controllato: togli le segnalazioni");
    const box = el("div", { class: "notice" }, el("strong", {}, "Da controllare"), el("div", {}, ...testo.split("\n").map((r) => el("div", {}, "• " + r.replace(/^Importazione: /, "")))), el("div", {}, svuota));
    return box;
  }

  function testoValore(v) {
    if (v === null || v === undefined || v === "") return "vuoto";
    if (Array.isArray(v)) return v.join(", ") || "vuoto";
    if (v === true) return "sì";
    if (v === false) return "no";
    return String(v);
  }

  async function storico(tipo, id) {
    const box = el("div", { class: "storico" }, el("p", { class: "subtle" }, "Caricamento…"));
    try {
      const righe = await api("GET", `/api/storico/${tipo}/${id}`);
      box.replaceChildren(...(righe.length ? righe.map((r) => {
        const modifiche = r.dettagli && r.dettagli.modifiche ? Object.entries(r.dettagli.modifiche).map(([campo, [prima, dopo]]) =>
          el("div", { class: "modifica" }, campo.replaceAll("_", " "), ": ", el("del", {}, testoValore(prima)), " → ", el("ins", {}, testoValore(dopo)))) : [];
        return el("div", { class: "voce" }, el("div", { class: "quando" }, `${formatta.dataora(r.quando)} · ${r.utente}`), el("div", {}, r.descrizione), ...modifiche);
      }) : [el("p", { class: "subtle" }, "Nessuna operazione registrata.")]));
    } catch (e) { box.replaceChildren(el("p", { class: "subtle" }, e.message)); }
    return box;
  }

  function traccia(x) {
    return el("p", { class: "subtle" }, `Creato il ${formatta.dataora(x.creato_il)} da ${x.creato_da || "—"} · ultima modifica ${formatta.dataora(x.modificato_il)} da ${x.modificato_da || "—"} · versione ${x.versione}`);
  }

  /** Pulsante d'azione che si disattiva durante l'operazione e mostra gli errori. */
  function azione(testo, classe, fn) {
    const pulsante = el("button", { class: "btn " + (classe || ""), type: "button", onclick: async (ev) => {
      const b = ev.currentTarget; b.disabled = true;
      try { await fn(); } catch (e) { errore(e); } finally { b.disabled = false; }
    } }, testo);
    pulsante._azione = fn;  // per «Salva e chiudi» (O7)
    return pulsante;
  }

  /** Tabella semplice di elementi collegati (sedi di un cliente, impianti di una sede…). */
  function tabella(colonne, righe, suRiga) {
    if (!righe.length) return el("p", { class: "subtle" }, "Nessun elemento.");
    return el("table", { class: "tabella-semplice" },
      el("thead", {}, el("tr", {}, ...colonne.map((c) => el("th", { class: c.num ? "num" : "" }, c.titolo)))),
      el("tbody", {}, ...righe.map((r) => el("tr", { class: suRiga ? "cliccabile" : "", onclick: suRiga ? () => suRiga(r) : null },
        ...colonne.map((c) => el("td", { class: c.num ? "num" : "" }, c.valore(r)))))));
  }

  /** Apre la scheda indicata nell'indirizzo (?apri=12), usato dai collegamenti tra pagine. */
  function apriDaIndirizzo(apri) {
    const p = new URLSearchParams(location.search);
    const id = Number(p.get("apri"));
    if (id) { history.replaceState(null, "", location.pathname); apri(id); }
    if (p.get("nuovo")) { history.replaceState(null, "", location.pathname); return Object.fromEntries(p); }
    return null;
  }

  /** Indirizzo di un elenco filtrato su una colonna (azioni «collegati», D50). */
  function filtro(pagina, campo, valore, etichetta) {
    return `/${pagina}?campo=${encodeURIComponent(campo)}&valore=${encodeURIComponent(valore)}&etichetta=${encodeURIComponent(etichetta)}`;
  }

  /** O5: valore del filtro dell'indirizzo su un campo (es. elenco «Sedi ← Cliente» → id del cliente), per precompilare «Nuovo». */
  function daFiltro(campo) {
    const f = GAD.filtroCollegato;  // impostato dalla griglia, che toglie il filtro dall'indirizzo
    if (f && f.campo === campo && f.valore) return f.valore;
    const p = new URLSearchParams(location.search);
    return p.get("campo") === campo && p.get("valore") ? p.get("valore") : null;
  }

  /** Elimina dalla riga dell'elenco (con conferma); il server rifiuta se ci sono dati collegati. */
  async function eliminaDaRiga(url, cosa, griglia) {
    if (!(await GAD.conferma(`Eliminare ${cosa}?`, "Si elimina solo se non ha dati collegati; i dati restano nel registro delle operazioni. Se è collegato ad altro, disattivalo dalla scheda.", { pulsante: "Elimina", pericolo: true }))) return;
    try { await api("DELETE", url); GAD.toast("Eliminato."); griglia.ricarica(); } catch (e) { errore(e); }
  }

  /** Rende la scheda di sola lettura (utente senza permesso di modifica). */
  function solaLettura(contenitore) {
    contenitore.querySelectorAll("input, select, textarea").forEach((x) => { x.disabled = true; });
    contenitore.querySelectorAll(".scelto button, .elenco-pod button, .notice button").forEach((x) => { x.hidden = true; });
  }

  /** 0.12.9: affidamento dell'incarico di verifica a un verificatore, per una o più righe di preventivo (come in Garda:
   *  icona nelle azioni della riga o selezione multipla). `righe`: oggetti con verifica_id, verifica_versione,
   *  verificatore, preventivo_etichetta/ordine (dalla griglia «righe_preventivi(_dm)»). Restituisce il numero affidato. */
  async function affidaRighe(righe, dm) {
    await me();
    if (!puo("verifiche.assegna", dm ? "DM" : "DPR")) throw new Error("Non puoi affidare incarichi in questa attività.");
    if (!righe.length) throw new Error("Spunta le righe da affidare (casella a sinistra di ogni riga).");
    const senza = righe.filter((r) => !r.verifica_id);
    if (senza.length) {
      throw new Error(`${senza.length} righe non hanno ancora ${dm ? "l'incarico" : "la verifica"}: nasce quando la riga è accettata e il riesame del contratto `
        + `è conforme (righe ${senza.map((r) => `${r.preventivo_etichetta || r.preventivo_id || ""}/${r.ordine}`).slice(0, 8).join(", ")}). Togli la spunta o fai prima il riesame.`);
    }
    const valori = await api("GET", dm ? "/api/dm/incarichi/valori" : "/api/verifiche/valori");
    const chi = f.scelta(valori.verificatori.map((x) => ({ valore: x.id, testo: x.nome })), "", { vuota: "— scegli —" });
    const gia = righe.filter((r) => r.verificatore).length;
    const ok = await GAD.modale(righe.length === 1 ? `Affidare ${dm ? "l'incarico" : "la verifica"}?` : `Affidare ${righe.length} ${dm ? "incarichi" : "verifiche"}?`, [
      gia ? el("p", {}, `${gia} hanno già un verificatore: cambiano verificatore.`) : null,
      el("p", { class: "subtle" }, "Tutte o nessuna: se una non si può affidare (es. già eseguita), non cambia nulla."),
      el("p", {class: "notice"}, "Compaiono solo utenti attivi con un ruolo attivo e il permesso di eseguire verifiche " +
        (dm ? "AD_DM" : "AD_DPR") + ". Se manca un verificatore importato, controlla e riattiva la sua scheda in Utenti e permessi; l'importazione lascia gli utenti disattivati."),
      campo("Verificatore", chi)].filter(Boolean),
    [{ testo: "Annulla", valore: false }, { testo: "Affida", classe: "primary", valore: true }]);
    if (!ok) return 0;
    if (!chi.value) throw new Error("Scegli il verificatore.");
    const r = dm
      ? await api("POST", "/api/dm/incarichi/assegna-in-blocco", { verificatore_id: chi.value, incarichi: righe.map((x) => ({ id: x.verifica_id, versione: x.verifica_versione })) })
      : await api("POST", "/api/verifiche/assegna-in-blocco", { verifiche: righe.map((x) => x.verifica_id), verificatore_id: chi.value });
    GAD.toast(`${r.assegnate} ${dm ? "incarichi affidati" : "verifiche affidate"}.`);
    return r.assegnate;
  }

  /** 0.12.9: riquadro «Dati del tecnico» (nome, cognome, qualifica, codice fiscale stampati nei verbali DM), nella scheda
   *  dell'utente e nel proprio profilo: si inseriscono una volta per tutte, non nell'incarico. */
  async function datiTecnico(utenteId, {suVersione = () => {}, esegui = (fn) => fn(), versioneAttesa = null} = {}) {
    const p = await api("GET", `/api/dm/tecnici/${utenteId}/profilo`);
    const etichette = { nome: "Nome", cognome: "Cognome", qualifica: "Qualifica", codice_fiscale: "Codice fiscale" };
    const campi = Object.fromEntries(Object.keys(etichette).map((k) => [k, f.testo(p[k] || "", { maxlength: k === "codice_fiscale" ? "16" : "120" })]));
    let versione = versioneAttesa ?? p.versione;
    const aggiornaVersione = (v) => {versione = v; suVersione(v);};
    const valori = () => Object.fromEntries(Object.entries(campi).map(([k, c]) => [k, c.value]));
    // 0.13.0 (Federico, 12/10/2026): firma DPR e firma DM separate; rc8: gestite entrambe qui
    const firma = el("div", { class: "firma-dm" });
    const disegnaFirma = (c) => {
      const file = el("input", { type: "file", accept: "image/png,image/jpeg", "aria-label": "Immagine della firma DM" });
      file.onchange = async () => {
        if (!file.files[0]) return;
        const scelto = file.files[0];
        try { await esegui(async () => {
          const fd = new FormData(); fd.append("file", scelto); fd.append("versione", versione);
          const x = await api("POST", `/api/dm/tecnici/${utenteId}/firma`, fd);
          aggiornaVersione(x.versione); GAD.toast("Firma DM caricata."); disegnaFirma(true);
        }); }
        catch (e) { errore(e); }
      };
      firma.replaceChildren(...[el("h4", {}, "Firma grafica per i verbali DM"),
        c ? el("img", { src: `/api/dm/tecnici/${utenteId}/firma?t=${Date.now()}`, alt: "Firma DM", class: "firma-anteprima" })
          : el("p", { class: "notice avviso" }, "Firma DM non caricata: i verbali DM uscirebbero senza firma grafica."),
        el("p", { class: "subtle" }, "PNG o JPG, minimo 50 × 20 pixel; consigliata una scansione di almeno 300 × 100. È diversa dalla firma DPR, qui accanto."),
        campo(c ? "Sostituisci la firma DM" : "Carica la firma DM", file),
        c ? azione("Togli la firma DM", "danger", () => esegui(async () => { const x = await api("DELETE", `/api/dm/tecnici/${utenteId}/firma?versione=${versione}`); aggiornaVersione(x.versione); disegnaFirma(false); })) : null].filter(Boolean));
    };
    disegnaFirma(p.firma_dm);
    // rc8 (punto 3): la firma DPR accanto alla firma DM, nello stesso riquadro (prima stava solo in VerbalizzAI)
    const firmaDpr = el("div", { class: "firma-dm firma-dpr" });
    const disegnaFirmaDpr = (stato) => {
      if (!stato.tecnico_dpr && !stato.presente) { firmaDpr.replaceChildren(); return; }
      const file = el("input", { type: "file", accept: "image/png,image/jpeg", "aria-label": "Immagine della firma DPR" });
      file.onchange = async () => {
        if (!file.files[0]) return;
        try { await esegui(async () => {
          const fd = new FormData(); fd.append("file", file.files[0]);
          await api("POST", `/api/firme/dpr/${utenteId}`, fd);
          GAD.toast("Firma DPR caricata: vale per i verbali emessi da ora in poi."); disegnaFirmaDpr({ ...stato, presente: true });
        }); }
        catch (e) { errore(e); }
      };
      const c = stato.presente;
      firmaDpr.replaceChildren(...[el("h4", {}, "Firma grafica per i verbali DPR"),
        c ? el("img", { src: `/api/firme/dpr/${utenteId}/immagine?t=${Date.now()}`, alt: "Firma DPR", class: "firma-anteprima" })
          : el("p", { class: "notice avviso" }, "Firma DPR non caricata: senza firma il verbale DPR non si emette."),
        el("p", { class: "subtle" }, "PNG o JPG, minimo 50 × 20 pixel; consigliata una scansione di almeno 300 × 100. I verbali già emessi conservano la firma con cui sono stati emessi."),
        campo(c ? "Sostituisci la firma DPR" : "Carica la firma DPR", file),
        c ? azione("Togli la firma DPR", "danger", () => esegui(async () => { await api("DELETE", `/api/firme/dpr/${utenteId}`); disegnaFirmaDpr({ ...stato, presente: false }); })) : null].filter(Boolean));
    };
    api("GET", `/api/firme/dpr/${utenteId}`).then(disegnaFirmaDpr).catch(() => firmaDpr.replaceChildren());
    const nodo = el("div", { class: "riquadro" }, el("h3", {}, "Dati del tecnico e firme"),
      el("p", { class: "subtle" }, "Dati stampati nei verbali come verificatore (DM) e firme grafiche: si inseriscono qui una volta per tutte. Ogni verbale usa la firma della sua attività."),
      el("div", { class: "field-grid" }, ...Object.entries(etichette).map(([k, t]) => campo(t, campi[k]))),
      azione("Salva dati del tecnico", "", () => esegui(async () => {
        const x = await api("PUT", `/api/dm/tecnici/${utenteId}/profilo`, { versione, ...valori() });
        aggiornaVersione(x.versione); GAD.toast("Dati del tecnico salvati.");
      })), el("div", { class: "firme-tecnico" }, firmaDpr, firma));
    nodo.valori = valori;
    nodo.impostaVersione = aggiornaVersione;
    return nodo;
  }

  /** R125 (0.12.8) e R139 (0.16): finestra «Fattura…» comune a righe dei preventivi, verifiche DPR e incarichi DM.
   *  `righe`: id delle righe di preventivo; `clienti`: committenti; `dm`: attività; `testo`: cosa si fattura. */
  async function fatturaRighe({ righe, clienti, dm, totale = 0, testo = "" }) {
    if (!righe.length) throw new Error("Niente da fatturare.");
    if (clienti.length > 1) throw new Error("Le righe selezionate sono di clienti diversi: una fattura riguarda un solo cliente.");
    const valori = await api("GET", "/api/finanza/valori");
    const intest = f.scelta(valori.clienti.map((c) => ({ valore: c.id, testo: c.ragione_sociale })), clienti[0]);
    const oggi = new Date();
    const data = el("input", { type: "date", value: `${oggi.getFullYear()}-${String(oggi.getMonth() + 1).padStart(2, "0")}-${String(oggi.getDate()).padStart(2, "0")}` });
    const bozze = await api("GET", `/api/bozze-fatture?cliente_id=${clienti[0]}&ambito=${dm ? "DM" : "DPR"}`);
    const dove = f.scelta([{ valore: "", testo: "Nuova fattura" }, ...bozze.map((b) => ({ valore: b.id, testo: "Aggiungi a: " + b.testo }))], "");
    const ok = await GAD.modale(`Fatturare ${righe.length} righe?`, [
      el("p", {}, `${testo}Si crea una bozza di fattura con una riga per ogni riga del preventivo (totale imponibile circa ${GAD.formatta.importo(totale)}). La bozza si controlla e si emette dalla pagina Fatture.`),
      campo("Fattura", dove), campo("Intestatario", intest), campo("Data", data)],
    [{ testo: "Annulla", valore: false }, { testo: "Crea la bozza", classe: "primary", valore: true }]);
    if (!ok) return null;
    const x = await api("POST", "/api/fatture/da-righe", { righe, cliente_id: Number(intest.value), data: data.value, ...(dove.value ? { fattura_id: Number(dove.value) } : {}) });
    GAD.toast("Bozza di fattura pronta.");
    location.href = `${dm ? "/fatture-dm" : "/fatture"}?apri=${x.id}`;
    return x;
  }

  /** R139 (0.16): dalle verifiche DPR (`verifiche`) o dagli incarichi DM (`incarichi`) alla finestra «Fattura…». */
  async function fatturaLavori({ verifiche = [], incarichi = [] }) {
    const r = await api("POST", "/api/fatture/righe-da-lavori", { verifiche, incarichi });
    const n = verifiche.length + incarichi.length;
    return fatturaRighe({ righe: r.righe, clienti: r.clienti, dm: incarichi.length > 0, totale: r.totale,
      testo: `${n === 1 ? "Una verifica" : n + " verifiche"}` + (r.voci ? ` più ${r.voci} voci del preventivo (trasferta, a corpo) non ancora fatturate. ` : ". ") });
  }

  GAD.schede = { me, puo, fatturaRighe, fatturaLavori, f, campo, datiTecnico, ambiti, sezione, linguette, ricerca, indirizzo, avvisi, storico, traccia, azione, tabella, apriDaIndirizzo, solaLettura, filtro, daFiltro, eliminaDaRiga, affidaRighe };
})();
