/* Elenco dei comuni ISTAT (D49): consultazione e correzioni da menu. */
"use strict";

(async () => {
  const { el, api, toast, errore, pannello } = GAD;
  const S = GAD.schede;
  const { f, campo } = S;
  await S.me();
  const g = await GAD.griglia(document.getElementById("griglia"), "comuni", { suRiga: (r) => apri(r.codice_istat) });
  const puo = S.puo("sistema.impostazioni");

  function modulo(c) {
    c = c || { attivo: true, cap: [] };
    const m = {
      codice_istat: f.testo(c.codice_istat, { maxlength: "6" }), nome: f.testo(c.nome, { maxlength: "100" }),
      sigla: f.testo(c.sigla, { maxlength: "2" }), provincia: f.testo(c.provincia, { maxlength: "80" }),
      regione: f.testo(c.regione, { maxlength: "60" }), cap: f.testo((c.cap || []).join(", "), { maxlength: "600" }),
      codice_catastale: f.testo(c.codice_catastale, { maxlength: "4" }),
    };
    if (c.codice_istat) m.codice_istat.readOnly = true;
    const attivo = f.casella("In elenco (proposto nella ricerca del comune)", c.attivo);
    const griglia = el("div", { class: "field-grid" },
      campo("Codice ISTAT", m.codice_istat, { aiuto: "6 cifre; non si cambia." }), campo("Codice catastale", m.codice_catastale),
      campo("Comune", m.nome, { pieno: true }), campo("Sigla provincia", m.sigla), campo("Provincia", m.provincia),
      campo("Regione", m.regione), campo("CAP", m.cap, { aiuto: "Uno o più, separati da virgola." }),
      el("div", { class: "field full" }, attivo.el));
    return { griglia, valori: () => ({ ...Object.fromEntries(Object.entries(m).map(([k, v]) => [k, v.value])), attivo: attivo.valore }) };
  }

  async function apri(codice) {
    let c;
    try { c = await api("GET", `/api/comuni/${codice}`); } catch (e) { return errore(e); }
    const m = modulo(c);
    const storico = el("div");
    const corpo = el("div", {}, S.linguette([{ titolo: "Dati", contenuto: m.griglia },
      { titolo: "Storico", contenuto: storico, apri: async () => storico.replaceChildren(await S.storico("comune", c.codice_istat)) }]));
    const pulsanti = [el("span", { class: "spazio" })];
    if (puo) pulsanti.push(S.azione("Salva", "primary", async () => { await api("PUT", `/api/comuni/${c.codice_istat}`, m.valori()); toast("Salvato."); g.ricarica(); apri(c.codice_istat); }));
    else S.solaLettura(corpo);
    pannello.apri(`${c.nome} (${c.sigla})`, corpo, pulsanti);
  }

  document.getElementById("nuovo")?.addEventListener("click", () => {
    const m = modulo(null);
    pannello.apri("Nuovo comune", m.griglia, [S.azione("Crea", "primary", async () => {
      const c = await api("POST", "/api/comuni", m.valori()); toast("Comune aggiunto."); g.ricarica(); apri(c.codice_istat);
    })]);
  });
})().catch((e) => GAD.errore(e));
