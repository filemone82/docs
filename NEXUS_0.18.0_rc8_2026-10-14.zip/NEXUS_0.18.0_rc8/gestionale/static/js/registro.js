/* Registro delle operazioni: elenco e dettaglio di ogni riga. */
"use strict";

(async () => {
  const { el, api, errore, pannello, formatta } = GAD;

  function valore(v) {
    if (v === null || v === undefined || v === "") return "—";
    if (typeof v === "boolean") return v ? "Sì" : "No";
    if (typeof v === "object") return JSON.stringify(v, null, 1);
    return String(v);
  }

  function dettagli(d) {
    const chiavi = Object.keys(d || {});
    if (!chiavi.length) return el("p", { class: "subtle" }, "Nessun dettaglio aggiuntivo.");
    if (d.modifiche) {
      const righe = Object.entries(d.modifiche).map(([campo, [prima, dopo]]) => el("tr", {}, el("td", {}, campo), el("td", {}, valore(prima)), el("td", {}, valore(dopo))));
      return el("table", { class: "matrice" }, el("thead", {}, el("tr", {}, el("th", {}, "Campo"), el("th", {}, "Prima"), el("th", {}, "Dopo"))), el("tbody", {}, ...righe));
    }
    if (d.dopo && typeof d.dopo === "object") {
      const kv = el("dl", { class: "kv" });
      for (const [k, v] of Object.entries(d.dopo)) kv.append(el("dt", {}, k), el("dd", {}, valore(v)));
      const resto = Object.fromEntries(Object.entries(d).filter(([k]) => k !== "dopo"));
      return [kv, Object.keys(resto).length ? el("div", { class: "json" }, JSON.stringify(resto, null, 2)) : null].filter(Boolean);
    }
    return el("div", { class: "json" }, JSON.stringify(d, null, 2));
  }

  async function apri(id) {
    let r;
    try { r = await api("GET", `/api/registro/${id}`); } catch (e) { return errore(e); }
    pannello.apri(`Operazione n. ${r.id}`, [
      el("dl", { class: "kv" },
        el("dt", {}, "Data e ora"), el("dd", {}, formatta.dataora(r.quando)),
        el("dt", {}, "Utente"), el("dd", {}, r.utente || "—"),
        el("dt", {}, "Azione"), el("dd", {}, r.azione),
        el("dt", {}, "Oggetto"), el("dd", {}, [r.oggetto_tipo, r.oggetto_id].filter(Boolean).join(" ") || "—"),
        el("dt", {}, "Descrizione"), el("dd", {}, r.descrizione)),
      el("h3", {}, "Dettagli"),
      ...[dettagli(r.dettagli)].flat(),
      el("p", { class: "subtle" }, "Impronta: ", el("code", {}, r.impronta)),
    ]);
  }

  await GAD.griglia(document.getElementById("griglia-registro"), "registro", { suRiga: (r) => apri(r.id) });
})().catch((e) => GAD.errore(e));
