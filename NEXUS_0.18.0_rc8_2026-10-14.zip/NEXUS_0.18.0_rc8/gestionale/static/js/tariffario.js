/* Tariffario da menu (D11, D29): voci con criterio di calcolo; importi in versioni con data di validità. */
"use strict";

(async () => {
  const { el, api, toast, errore, pannello, modale, formatta } = GAD;
  const S = GAD.schede;
  const { f, campo } = S;
  await S.me();
  const [valori, anag] = await Promise.all([api("GET", "/api/tariffario/valori"), api("GET", "/api/anagrafica/valori")]);
  const g = await GAD.griglia(document.getElementById("griglia"), "tariffario", { suRiga: (r) => apri(r.id) });
  const euro = (c) => (c === null || c === undefined ? "" : (c / 100).toFixed(2).replace(".", ","));
  const oggi = new Date().toISOString().slice(0, 10);

  function moduloVoce(v) {
    v = v || { criterio: "scaglioni", grandezza: "potenza_kw", automatica: true, attiva: true, tipologie: [], ordine: 0 };
    const m = {
      codice: f.testo(v.codice, { maxlength: "30" }), nome: f.testo(v.nome, { maxlength: "150" }),
      criterio: f.scelta(Object.entries(valori.criteri).map(([k, t]) => ({ valore: k, testo: t })), v.criterio),
      grandezza: f.scelta(Object.entries(valori.grandezze).map(([k, t]) => ({ valore: k, testo: t })), v.grandezza, { vuota: "—" }),
      ordine: f.numero(v.ordine), note: f.area(v.note, { maxlength: "4000" }),
    };
    if (v.id && v.versioni.length) m.criterio.disabled = true;
    const tip = Object.entries(anag.tipologie).map(([k, t]) => ({ k, c: f.casella(t, v.tipologie.includes(k)) }));
    const automatica = f.casella("Automatica: si somma da sola quando l'impianto ha il dato", v.automatica);
    const attiva = f.casella("Attiva", v.attiva);
    const agg = () => { m.grandezza.disabled = m.criterio.value === "fisso"; };
    m.criterio.addEventListener("change", agg); agg();
    const griglia = el("div", { class: "field-grid" },
      campo("Codice", m.codice, { aiuto: "Breve, es. TERRA-KW, ASTA, GABBIA." }), campo("Ordine", m.ordine),
      campo("Nome della voce", m.nome, { pieno: true }),
      campo("Si applica a", el("div", { class: "caselle" }, ...tip.map((x) => x.c.el)), { pieno: true }),
      campo("Criterio di calcolo", m.criterio, { aiuto: v.id && v.versioni.length ? "Non si cambia su una voce con importi: crea una voce nuova." : "" }),
      campo("Calcolata su", m.grandezza),
      el("div", { class: "field full" }, automatica.el), el("div", { class: "field full" }, attiva.el),
      campo("Note", m.note, { pieno: true }));
    return { griglia, valori: () => ({ codice: m.codice.value, nome: m.nome.value, criterio: m.criterio.value, grandezza: m.grandezza.value,
      ordine: m.ordine.value, note: m.note.value, tipologie: tip.filter((x) => x.c.valore).map((x) => x.k), automatica: automatica.valore, attiva: attiva.valore }) };
  }

  /** Editor degli importi di una versione (scaglioni oppure prezzo). */
  function editorImporti(voce, base) {
    const valida = f.data(base && base.valida_dal > oggi ? base.valida_dal : "");
    const note = f.testo(base && base.valida_dal > oggi ? base.note : "", { maxlength: "2000" });
    if (voce.criterio !== "scaglioni") {
      const prezzo = f.numero(base ? euro(base.prezzo) : "");
      const minimo = f.numero(base && base.minimo ? euro(base.minimo) : "", { placeholder: "nessuno" });
      const unitario = voce.criterio === "unitario";
      return { el: el("div", { class: "field-grid" }, campo("Valida dal", valida),
        campo(voce.criterio === "fisso" ? "Prezzo fisso (€)" : voce.grandezza === "ore" ? "Prezzo all'ora (€)" : "Prezzo unitario (€)", prezzo),
        unitario ? campo("Importo minimo (€)", minimo, { aiuto: "Facoltativo: se il calcolo dà meno, vale il minimo (es. € 50 sotto 3 kW)." }) : null,
        campo("Note", note, { pieno: true })),
        valori: () => ({ valida_dal: valida.value, prezzo: prezzo.value, minimo: unitario ? minimo.value : "", note: note.value }) };
    }
    const corpo = el("tbody");
    const scelta = voce.grandezza === "scelta";  // elenco a scelta (es. trasferta): «fino a» non serve
    const riga = (fino = "", importo = "", etichetta = "") => {
      const a = f.numero(fino === null ? "" : fino, { placeholder: "vuoto = oltre" });
      const b = f.numero(importo);
      const c = f.testo(etichetta, { maxlength: "200", placeholder: scelta ? "descrizione della voce" : "avviso (facoltativo)" });
      const r = el("tr", {}, scelta ? null : el("td", {}, a), el("td", {}, b), el("td", {}, c), el("td", {}, el("button", { class: "btn small", type: "button", onclick: () => r.remove() }, "×")));
      r._campi = { a, b, c };
      return r;
    };
    (base ? base.scaglioni : [{ fino_a: null, importo: null }]).forEach((s) => corpo.append(riga(s.fino_a ?? "", euro(s.importo), s.etichetta || "")));
    const aggiungi = el("button", { class: "btn small", type: "button", onclick: () => corpo.lastElementChild ? corpo.lastElementChild.before(riga()) : corpo.append(riga()) }, "＋ Scaglione");
    return {
      el: el("div", {}, el("div", { class: "field-grid" }, campo("Valida dal", valida), campo("Note", note)),
        el("p", { class: "subtle" }, scelta ? "Elenco a scelta: una riga per voce, con descrizione e importo; nel preventivo si sceglie la voce."
          : `Scaglioni su «${valori.grandezze[voce.grandezza] || voce.grandezza}»: «fino a» compreso; l'ultimo resta vuoto («oltre»). L'avviso, se scritto, compare nella riga del preventivo.`),
        el("table", { class: "tabella-semplice" }, el("thead", {}, el("tr", {}, scelta ? null : el("th", {}, "Fino a"), el("th", {}, "Importo (€)"),
          el("th", {}, scelta ? "Descrizione" : "Avviso"), el("th", {}, ""))), corpo), aggiungi),
      valori: () => ({ valida_dal: valida.value, note: note.value,
        scaglioni: [...corpo.querySelectorAll("tr")].map((r) => ({ fino_a: scelta ? "" : r._campi.a.value, importo: r._campi.b.value, etichetta: r._campi.c.value })) }),
    };
  }

  function vistaVersione(voce, ver) {
    const stato = ver.id === voce.versione_in_vigore ? el("span", { class: "badge ok" }, "in vigore") : ver.modificabile ? el("span", { class: "badge avviso" }, "futura") : el("span", { class: "badge grigio" }, "superata");
    const contenuto = voce.criterio === "scaglioni"
      ? S.tabella([...(voce.grandezza === "scelta" ? [] : [{ titolo: "Fino a", valore: (s) => (s.fino_a === null ? "oltre" : formatta.numero(s.fino_a)) }]),
        { titolo: "Importo", num: true, valore: (s) => formatta.importo(s.importo) },
        { titolo: voce.grandezza === "scelta" ? "Voce" : "Avviso", valore: (s) => s.etichetta || "" }], ver.scaglioni)
      : el("p", {}, `${voce.criterio === "fisso" ? "Prezzo fisso" : voce.grandezza === "ore" ? "Prezzo all'ora" : "Prezzo unitario"}: `, el("strong", {}, formatta.importo(ver.prezzo)),
        ver.minimo ? ` · minimo ${formatta.importo(ver.minimo)}` : "");
    return el("div", { class: "panel" }, el("div", {}, el("strong", {}, `Dal ${formatta.data(ver.valida_dal)} `), stato,
      el("span", { class: "subtle" }, ` · inserita da ${ver.creata_da || "—"} il ${formatta.dataora(ver.creata_il)}`)),
      ver.note ? el("p", { class: "subtle" }, ver.note) : null, contenuto,
      ver.modificabile && S.puo("tariffario.gestire") ? el("div", { class: "actions" },
        el("button", { class: "btn small", type: "button", onclick: () => editaVersione(voce, ver) }, "Correggi"),
        S.azione("Elimina", "small danger", async () => { await api("DELETE", `/api/tariffario/versioni/${ver.id}`); toast("Versione eliminata."); g.ricarica(); apri(voce.id); })) : null);
  }

  async function editaVersione(voce, ver) {
    const base = ver || voce.versioni.find((x) => x.id === voce.versione_in_vigore) || voce.versioni[0];
    const ed = editorImporti(voce, base);
    const ok = await modale(ver ? "Correggi la versione futura" : "Nuova versione degli importi", [
      el("p", { class: "subtle" }, "Gli importi già in vigore non si cambiano: si aggiunge una versione con la data da cui valgono i nuovi importi. I preventivi già fatti conservano i loro prezzi."), ed.el],
    [{ testo: "Annulla", valore: false }, { testo: "Salva", classe: "primary", valore: true }]);
    if (!ok) return;
    try {
      if (ver) await api("PUT", `/api/tariffario/versioni/${ver.id}`, ed.valori());
      else await api("POST", `/api/tariffario/voci/${voce.id}/versioni`, ed.valori());
      toast("Importi salvati."); g.ricarica(); apri(voce.id);
    } catch (e) { errore(e); }
  }

  async function apri(id) {
    let v;
    try { v = await api("GET", `/api/tariffario/voci/${id}`); } catch (e) { return errore(e); }
    const m = moduloVoce(v);
    const storico = el("div");
    const importi = el("div", {}, S.puo("tariffario.gestire") ? el("p", {}, el("button", { class: "btn small primary", type: "button", onclick: () => editaVersione(v, null) }, "＋ Nuova versione degli importi")) : null,
      ...(v.versioni.length ? v.versioni.map((x) => vistaVersione(v, x)) : [el("p", { class: "subtle" }, "Nessun importo: aggiungi la prima versione.")]));
    const corpo = el("div", {}, S.linguette([{ titolo: "Importi", contenuto: importi }, { titolo: "Voce", contenuto: m.griglia },
      { titolo: "Storico", contenuto: storico, apri: async () => storico.replaceChildren(await S.storico("tariffa_voce", v.id)) }]));
    const pulsanti = [el("span", { class: "spazio" })];
    if (S.puo("tariffario.gestire")) {
      pulsanti.push(S.azione("Salva la voce", "primary", async () => { await api("PUT", `/api/tariffario/voci/${v.id}`, { ...m.valori(), versione: v.versione }); toast("Voce salvata."); g.ricarica(); apri(v.id); }));
    } else S.solaLettura(m.griglia);
    pannello.apri(`${v.codice} · ${v.nome}`, corpo, pulsanti, { largo: true });
  }

  document.getElementById("nuovo")?.addEventListener("click", () => {
    const m = moduloVoce(null);
    pannello.apri("Nuova voce del tariffario", [el("p", { class: "subtle" }, "Dopo aver creato la voce aggiungi gli importi (versione con data di validità)."), m.griglia],
      [S.azione("Crea voce", "primary", async () => { const v = await api("POST", "/api/tariffario/voci", m.valori()); toast("Voce creata."); g.ricarica(); apri(v.id); })], { largo: true });
  });

  document.getElementById("prova")?.addEventListener("click", async () => {
    const tip = f.scelta(Object.entries(anag.tipologie).map(([k, t]) => ({ valore: k, testo: t })), "terra_bt");
    const pot = f.numero(""), cab = f.numero(""), aste = f.numero("");
    const fascia = f.scelta(Object.entries(anag.fasce_gabbia).map(([k, t]) => ({ valore: k, testo: t })), "", { vuota: "nessuna gabbia" });
    const zone = anag.zone.map((z) => f.casella(z, false));
    const giorno = f.data(oggi);
    const esito = el("div", { class: "riquadro" }, "Compila e premi «Calcola».");
    const calcola = el("button", { class: "btn primary", type: "button", onclick: async () => {
      try {
        const r = await api("POST", "/api/tariffario/prova", { tipologia: tip.value, potenza_kw: pot.value, cabine_mt_bt: cab.value, numero_aste: aste.value,
          asta: !!aste.value, gabbia: !!fascia.value, gabbia_fascia: fascia.value, zone: anag.zone.filter((_z, i) => zone[i].valore), giorno: giorno.value });
        esito.replaceChildren(el("strong", { class: "grande" }, r.totale === null ? "non calcolabile" : formatta.importo(r.totale)),
          ...r.voci.map((x) => el("div", {}, `${x.voce}: ${formatta.importo(x.importo)} (${x.spiegazione}, importi dal ${formatta.data(x.valida_dal)})`)),
          ...r.problemi.map((p) => el("div", { class: "subtle" }, "⚠ " + p)));
      } catch (e) { errore(e); }
    } }, "Calcola");
    await modale("Prova il calcolo della tariffa", [el("div", { class: "field-grid" }, campo("Tipologia", tip), campo("Giorno del calcolo", giorno),
      campo("Potenza kW", pot), campo("Cabine MT/BT", cab), campo("Numero di aste", aste), campo("Gabbia", fascia),
      campo("Zone", el("div", { class: "caselle" }, ...zone.map((z) => z.el)), { pieno: true })), el("p", {}, calcola), esito], [{ testo: "Chiudi", valore: null }]);
  });
  S.apriDaIndirizzo(apri);
})().catch((e) => GAD.errore(e));
