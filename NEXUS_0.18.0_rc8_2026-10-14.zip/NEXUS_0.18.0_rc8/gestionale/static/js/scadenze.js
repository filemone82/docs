/* Scadenze: impianti non dismessi per prossima verifica, con il preventivo collegato.
   ⚡ crea un preventivo nuovo o aggiunge a uno aperto dello stesso cliente (D19), anche con più impianti (D39). */
"use strict";

(async () => {
  const { el, api, errore, modale } = GAD;
  const S = GAD.schede;
  await S.me();
  const puoPreventivare = S.puo("preventivi.modifica");
  const filtro = (testo, campo, valore) => el("button", { class: "btn small", type: "button", onclick: () => {
    g.tabella.clearHeaderFilter();
    for (const [c, v] of Object.entries(campo)) g.filtra(c, v);
  } }, testo);
  const pulsanti = [
    filtro("Da preventivare", { in_preventivo: "no" }), filtro("Scadute", { stato_scadenza: "Scaduta" }),
    filtro("Entro 90 giorni", { stato_scadenza: "Entro 90 giorni" }), filtro("Tutte", {}),
  ];

  async function preventiva(righe) {
    if (!righe.length) return errore(new Error("Seleziona una o più scadenze (clicca sulle righe)."));
    const clienti = [...new Set(righe.map((r) => r.cliente_id))];
    if (clienti.length > 1) return errore(new Error("Le scadenze selezionate sono di clienti diversi: un preventivo riguarda un solo cliente (le sedi possono essere diverse)."));
    const gia = righe.filter((r) => r.in_preventivo);
    let aperti = [];
    try { aperti = await api("GET", `/api/preventivi/aperti?cliente_id=${clienti[0]}`); } catch (e) { return errore(e); }
    // O12: come nel gestionale attuale — data precompilata, numero del preventivo vuoto = nuovo
    const oggi = new Date();
    const data = el("input", { type: "date", value: `${oggi.getFullYear()}-${String(oggi.getMonth() + 1).padStart(2, "0")}-${String(oggi.getDate()).padStart(2, "0")}` });
    const numero = el("input", { maxlength: "30", placeholder: "vuoto = nuovo preventivo" });
    const tipo = el("select", {}, el("option", { value: "periodica" }, "Periodica"), el("option", { value: "straordinaria" }, "Straordinaria"));
    const suggerimenti = aperti.length ? el("div", { class: "subtle" }, "Preventivi aperti di questo cliente: ",
      ...aperti.map((p, i) => [i ? " · " : "", el("a", { href: "#", onclick: (ev) => { ev.preventDefault(); numero.value = p.codice; } },
        `${p.etichetta} – ${p.stato_testo}`)]).flat()) : null;
    const scelta = modale("⚡ Preventivo", [
      el("p", {}, `Cliente: `, el("strong", {}, righe[0].cliente_ragione_sociale), ` · impianti: ${righe.length}`),
      gia.length ? el("div", { class: "notice" }, `${gia.length} impianti hanno già una verifica periodica preventivata. Per la periodica occorre usare il preventivo esistente o annullare prima la prestazione. `,
        ...[...new Map(gia.map((r) => [r.preventivo_id, r])).values()].map((r) => el("a", { href: `/preventivi?apri=${r.preventivo_id}` }, `${r.preventivo} `))) : null,
      el("div", { class: "field-grid" },
        S.campo("Data preventivo", data),
        S.campo("Preventivo", numero, { aiuto: "Vuoto: nuovo preventivo. Con un numero (es. 12 o P_012_26) le righe si aggiungono a quel preventivo del cliente; se è già inviato si crea una revisione. Mai su un preventivo accettato." }),
        S.campo("Tipo di verifica", tipo)),
      suggerimenti,
    ], [{ testo: "Annulla", valore: false }, { testo: "Procedi", classe: "primary", valore: true }]);
    const procedi = document.getElementById("modale-azioni").lastElementChild;
    const aggiornaBlocco = () => { procedi.disabled = tipo.value === "periodica" && gia.length > 0; };
    tipo.addEventListener("change", aggiornaBlocco);
    aggiornaBlocco();
    const ok = await scelta;
    if (!ok) return;
    if (tipo.value === "periodica" && gia.length) return errore(new Error("La scadenza è già preventivata: apri il preventivo esistente oppure annulla prima la prestazione."));
    try {
      const p = await api("POST", "/api/preventivi/da-scadenze", { impianti: righe.map((r) => r.id), data: data.value, preventivo: numero.value, tipo_verifica: tipo.value });
      location.href = `/preventivi?apri=${p.id}`;
    } catch (e) { errore(e); }
  }

  const g = await GAD.griglia(document.getElementById("griglia"), "scadenze", {
    selezione: true,
    pulsanti,
    azioni: {
      modifica: (r) => { location.href = `/impianti?apri=${r.id}`; },
      extra: puoPreventivare ? [{ testo: "⚡", titolo: "Preventivo per questo impianto", fn: (r) => preventiva([r]) }] : [],
      collegamenti: [
        { testo: "Impianto → scheda", vai: (r) => `/impianti?apri=${r.id}` },
        { testo: "Preventivo → scheda", vai: (r) => (r.preventivo_id ? `/preventivi?apri=${r.preventivo_id}` : "#") },
        { testo: "Sede operativa → scheda", vai: (r) => `/sedi?apri=${r.sede_id}` },
        { testo: "Cliente → scheda", vai: (r) => `/clienti?apri=${r.cliente_id}` },
        { testo: "Scadenze ← Cliente", vai: (r) => S.filtro("scadenze", "cliente_id", r.cliente_id, `scadenze di ${r.cliente_ragione_sociale}`) },
      ],
    },
  });
  document.getElementById("preventiva")?.addEventListener("click", () => preventiva(g.selezionate()));
})().catch((e) => GAD.errore(e));
