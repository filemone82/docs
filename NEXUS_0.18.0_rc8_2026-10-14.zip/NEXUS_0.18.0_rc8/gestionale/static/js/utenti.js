/* Utenti: elenco, nuovo, modifica, password provvisoria, sblocco, disattivazione. */
"use strict";

(async () => {
  const { el, api, toast, errore, modale, conferma, pannello, campo } = GAD;
  let ruoli = [];
  try { ruoli = await api("GET", "/api/ruoli"); } catch (e) { errore(e); }

  const g = await GAD.griglia(document.getElementById("griglia-utenti"), "utenti", {
    suRiga: (r) => apri(r.id),
    // 0.12.8: sotto c'è la matrice dei permessi (come VerbalizzAI): elenco più basso
    ...(document.getElementById("permessi") ? { altezza: "34vh" } : {}),
  });

  function selettoreRuolo(attuale) {
    const s = el("select", {}, ...ruoli.filter((r) => r.attivo || r.id === attuale).map((r) => el("option", { value: r.id }, r.nome + (r.attivo ? "" : " (disattivato)"))));
    if (attuale) s.value = attuale;
    return s;
  }

  async function mostraPassword(utente, password) {
    await modale("Password provvisoria", [
      el("p", {}, `Comunica a ${utente.nome} questa password provvisoria. Al primo accesso il programma gli chiederà di sceglierne una sua.`),
      el("p", {}, "Nome utente: ", el("strong", {}, utente.username)),
      el("p", {}, el("span", { class: "codice" }, password)),
      el("p", { class: "subtle" }, "La password non viene più mostrata dopo aver chiuso questa finestra."),
    ], [{ testo: "Ho preso nota", classe: "primary", valore: null }]);
  }

  function modulo(u) {
    const username = el("input", { maxlength: "60", value: u ? u.username : "", autocomplete: "off" });
    if (u) username.readOnly = true;
    const nome = el("input", { maxlength: "120", value: u ? u.nome : "" });
    const email = el("input", { maxlength: "200", type: "email", value: u ? u.email : "" });
    // 0.16 (Federico, 12/10/2026): più ruoli a caselle, es. «RT DPR» + «Verificatore DM». Ogni permesso vale nell'attività
    // del ruolo che lo dà. Il principale (mostrato negli elenchi) è il primo spuntato, o quello che l'utente aveva già.
    const scelti = new Set(u ? (u.ruoli_id || [u.ruolo_id]) : []);
    const caselle = ruoli.filter((r) => r.attivo || scelti.has(r.id)).map((r) => {
      const c = el("input", { type: "checkbox", value: r.id }); c.checked = scelti.has(r.id);
      return { r, c, riga: el("label", { class: "check-row" }, c, ` ${r.nome}${r.attivo ? "" : " (disattivato)"}`) };
    });
    const ruoliBox = el("div", { class: "ruoli-caselle" }, ...caselle.map((x) => x.riga));
    const griglia = el("div", { class: "field-grid" },
      campo("Nome e cognome", nome, { pieno: true }),
      campo("Nome utente", username, { aiuto: u ? "Non si modifica." : "Minuscolo, senza spazi (es. mario.rossi)." }),
      campo("Email", email),
      campo("Ruoli", ruoliBox, { pieno: true, aiuto: "Si possono spuntare più ruoli: ogni permesso vale nell'attività del ruolo che lo dà (es. RT DPR + Verificatore DM: RT nel DPR, verificatore nel DM)." }));
    function valori() {
      const ids = caselle.filter((x) => x.c.checked).map((x) => x.r.id);
      if (!ids.length) throw new Error("Spunta almeno un ruolo.");
      const principale = u && ids.includes(u.ruolo_id) ? u.ruolo_id : ids[0];
      return { username: username.value, nome: nome.value, email: email.value, ruolo_id: principale, altri_ruoli: ids.filter((i) => i !== principale) };
    }
    return { griglia, valori };
  }

  document.getElementById("nuovo-utente").addEventListener("click", () => {
    const m = modulo(null);
    const salva = el("button", { class: "btn primary", type: "button" }, "Crea utente");
    salva.addEventListener("click", async () => {
      salva.disabled = true;
      try {
        const u = await api("POST", "/api/utenti", m.valori());
        pannello.chiudi();
        g.ricarica();
        await mostraPassword(u, u.password_provvisoria);
      } catch (e) { errore(e); } finally { salva.disabled = false; }
    });
    pannello.apri("Nuovo utente", [el("p", { class: "subtle" }, "Il programma genera una password provvisoria da comunicare all'utente."), m.griglia], [salva]);
  });

  async function apri(id) {
    let u;
    try { u = await api("GET", `/api/utenti/${id}`); } catch (e) { return errore(e); }
    const m = modulo(u);
    let coda = Promise.resolve();
    const esegui = (fn) => {const lavoro = coda.then(fn); coda = lavoro.catch(() => {}); return lavoro;};
    let salvataggio = null;
    let tecnico = null;
    const avvisi = [];
    if (!u.attivo) avvisi.push(el("div", { class: "notice" }, "Utente disattivato: non può accedere."));
    if (u.bloccato_minuti) avvisi.push(el("div", { class: "notice" }, `Utente bloccato per troppi tentativi sbagliati (ancora ${u.bloccato_minuti} minuti).`));
    if (u.cambio_password_richiesto) avvisi.push(el("div", { class: "notice" }, "Ha una password provvisoria non ancora cambiata."));

    const azione = (testo, classe, fn) => Object.assign(el("button", { class: "btn " + classe, type: "button", onclick: async (ev) => {
      ev.target.disabled = true;
      try { await fn(); } catch (e) { errore(e); } finally { ev.target.disabled = false; }
    } }, testo), { _azione: fn });  // _azione: «Salva e chiudi» (O7)

    const pulsanti = [
      azione("Nuova password provvisoria", "", async () => {
        if (!(await conferma("Nuova password provvisoria", `La password attuale di ${u.nome} smetterà di funzionare e le sue sessioni aperte verranno chiuse.`, { pulsante: "Genera" }))) return;
        const r = await api("POST", `/api/utenti/${u.id}/password`);
        await mostraPassword(u, r.password_provvisoria);
        apri(u.id);
      }),
    ];
    if (u.bloccato_minuti) pulsanti.push(azione("Sblocca", "", async () => { await api("POST", `/api/utenti/${u.id}/sblocca`); toast("Utente sbloccato."); g.ricarica(); apri(u.id); }));
    pulsanti.push(u.attivo
      ? azione("Disattiva", "danger", async () => {
        if (!(await conferma("Disattivare l'utente?", `${u.nome} non potrà più accedere. Resta nell'elenco e nel registro; si può riattivare in ogni momento.`, { pulsante: "Disattiva", pericolo: true }))) return;
        await api("POST", `/api/utenti/${u.id}/disattiva`, { versione: u.versione }); toast("Utente disattivato."); g.ricarica(); apri(u.id);
      })
      : azione("Riattiva", "", async () => { await api("POST", `/api/utenti/${u.id}/riattiva`, { versione: u.versione }); toast("Utente riattivato."); g.ricarica(); apri(u.id); }));
    pulsanti.push(el("span", { class: "spazio" }));
    const salvaScheda = () => {
      if (salvataggio) return salvataggio;
      const dati = {...m.valori(), ...(tecnico ? {dati_tecnici: tecnico.valori()} : {})};
      salvataggio = esegui(async () => {
        const x = await api("PUT", `/api/utenti/${u.id}`, {...dati, versione: u.versione});
        u.versione = x.versione;
        if (tecnico) tecnico.impostaVersione(x.versione);
        toast("Modifiche salvate.");
        await g.ricarica();
      }).finally(() => {salvataggio = null;});
      return salvataggio;
    };
    const salva = azione("Salva", "primary", salvaScheda); salva._senzaRiapertura = true;
    pulsanti.push(salva);
    // 0.12.9: i dati del tecnico per i verbali si inseriscono qui (non più nell'incarico)
    try { tecnico = await GAD.schede.datiTecnico(u.id, {esegui, versioneAttesa: u.versione,
      suVersione: (v) => {u.versione = v;}}); } catch (e) { tecnico = null; }
    pannello.apri(u.nome, [...avvisi, m.griglia, tecnico].filter(Boolean), pulsanti);
  }
})().catch((e) => GAD.errore(e));
