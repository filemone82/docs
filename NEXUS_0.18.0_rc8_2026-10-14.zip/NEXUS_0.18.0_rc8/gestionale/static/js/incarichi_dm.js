"use strict";
(async () => {
  const {el,api,errore,toast,pannello,modale,conferma,formatta}=GAD;
  const S=GAD.schede, {f,campo}=S, io=await S.me();
  const valori=await api("GET","/api/dm/incarichi/valori");
  // 0.12.9 (Federico, 12/10/2026): elenco sulla griglia standard — «seleziona tutte», filtri per colonna, Excel —
  // con affidamento e riesame sulle righe selezionate, come Righe dei preventivi e Verifiche DPR.
  const tabella=(titoli,rows)=>el("table",{class:"tabella-semplice"},el("thead",{},el("tr",{},...titoli.map(t=>el("th",{},t)))),
    el("tbody",{},...rows.map(r=>el("tr",{},...r.map(x=>el("td",{},x))))));
  const btn=(t,fun,cls="")=>S.azione(t,cls,fun);
  const sceltaTecnico=v=>f.scelta(valori.verificatori.map(x=>({valore:x.id,testo:x.nome})),v??"",{vuota:"Scegli tecnico"});
  const filtro=(testo,filtri)=>el("button",{class:"btn small",type:"button",onclick:()=>{g.tabella.clearHeaderFilter();for(const [c,x] of Object.entries(filtri))g.filtra(c,x);}},testo);
  const puoAffidare=S.puo("verifiche.assegna", "DM"), puoRiesame=S.puo("verifiche.riesame", "DM");
  const pulsanti=[
    filtro("Da assegnare",{stato:"Da assegnare"}), filtro("Assegnate a me",{verificatore_id:String(io.id)}),
    filtro("Da registrare",{stato:"Assegnata"}), filtro("Registrate",{stato:"Registrata"}),
    filtro("Da riesaminare",{da_riesaminare:"Sì"}), filtro("Da fatturare",{da_fatturare:"Sì"}), filtro("Tutte",{}),
    S.puo("fatture.genera")?el("button",{class:"btn small primary",type:"button",onclick:()=>fatturaSelezionate().catch(errore)},"Fattura le selezionate…"):null,   // R139 (0.16)
    puoAffidare?el("button",{class:"btn small primary",type:"button",onclick:()=>affida().catch(errore)},"👤 Affida le selezionate…"):null,
    S.puo("verifiche.esegui", "DM")?el("button",{class:"btn small",type:"button",onclick:()=>registraBlocco().catch(errore)},"Registra le selezionate…"):null,   // doc. 28 p. 13 (0.16)
    puoRiesame?el("button",{class:"btn small",type:"button",onclick:()=>riesameBlocco().catch(errore)},"Riesamina le selezionate…"):null,
  ].filter(Boolean);
  async function fatturaSelezionate(){
    const scelte=g.selezionate();
    if(!scelte.length)throw new Error("Spunta gli incarichi da fatturare (casella a sinistra di ogni riga).");
    const no=scelte.filter(r=>r.da_fatturare!=="Sì");
    if(no.length)throw new Error(`${no.length} incarichi non sono da fatturare (non riesaminati o già fatturati): togli la spunta.`);
    await S.fatturaLavori({incarichi:scelte.map(r=>r.id)});
  }
  async function affida(){
    const scelte=g.selezionate().map(r=>({verifica_id:r.id,verifica_versione:r.versione,verificatore:r.verificatore,ordine:r.id,preventivo_etichetta:"incarico"}));
    if(await S.affidaRighe(scelte,true))g.ricarica();
  }
  // Documento 28, punto 13 (deciso 12/10, 11:13): stessa data di rilascio e stesse prossime date per più incarichi;
  // il numero del verbale si assegna alla registrazione; tutto o niente
  async function registraBlocco(){
    const scelte=g.selezionate();
    if(!scelte.length)throw new Error("Spunta gli incarichi da registrare (casella a sinistra di ogni riga).");
    const gvr=scelte.some(r=>r.gruppo==="GVR"), scsp=scelte.some(r=>r.gruppo!=="GVR");
    const oggi=new Date(), iso=`${oggi.getFullYear()}-${String(oggi.getMonth()+1).padStart(2,"0")}-${String(oggi.getDate()).padStart(2,"0")}`;
    const rilascio=el("input",{type:"date",value:iso}), esito=f.scelta([{valore:"Positivo",testo:"Positivo"},{valore:"Negativo",testo:"Negativo"},{valore:"Sospeso",testo:"Sospeso"}],"Positivo");
    const date={funz:el("input",{type:"date"}),integrita:el("input",{type:"date"}),interna:el("input",{type:"date"}),scsp:el("input",{type:"date"})};
    const corpo=el("div",{},el("p",{},`${scelte.length===1?"1 incarico":scelte.length+" incarichi"}: tutti o nessuno. Si registrano solo gli incarichi affidati a te, già pronti (indipendenza dichiarata). Il numero del verbale si assegna adesso, in ordine.`),
      campo("Data di rilascio del verbale",rilascio),campo("Esito (se non già scritto nella scheda)",esito),
      gvr?el("div",{class:"field-grid"},campo("GVR · prossimo funzionamento",date.funz),campo("GVR · prossima integrità",date.integrita),campo("GVR · prossima visita interna",date.interna)):null,
      scsp?campo("SC/SP · prossima verifica",date.scsp):null,
      el("p",{class:"subtle"},"Ogni data vale solo per gli incarichi con quella attività. Vuota: si usa quella già scritta nella scheda, altrimenti si calcola dalla periodicità del catalogo."));
    if(!await modale(`Registrare ${scelte.length===1?"l'incarico":scelte.length+" incarichi"}?`,corpo,[{testo:"Annulla",valore:false},{testo:"Registra",valore:true,classe:"primary"}]))return;
    const r=await api("POST","/api/dm/incarichi/registra-in-blocco",{data_rilascio:rilascio.value,esito:esito.value,
      date:Object.fromEntries(Object.entries(date).filter(([,x])=>x.value).map(([k,x])=>[k,x.value])),incarichi:scelte.map(v=>({id:v.id,versione:v.versione}))});
    toast(`${r.registrati.length} incarichi registrati: ${r.registrati.map(x=>x.codice_verbale).join(", ")}`);g.ricarica();
  }
  async function riesameBlocco(){
    const scelte=g.selezionate();
    if(!scelte.length)throw new Error("Spunta gli incarichi da riesaminare.");
    const esito=f.scelta([{valore:"C",testo:"Conforme"},{valore:"N",testo:"Non conforme"}],"C"),nota=f.area("");
    if(!await modale(`Riesame di ${scelte.length} incarichi`,el("div",{},campo("Esito",esito),campo("Nota",nota)),
      [{testo:"Annulla",valore:false},{testo:"Registra riesame",valore:true,classe:"primary"}]))return;
    await api("POST","/api/dm/incarichi/riesame-in-blocco",{esito:esito.value,nota:nota.value,incarichi:scelte.map(v=>({id:v.id,versione:v.versione}))});
    toast("Riesami registrati.");g.ricarica();
  }
  const g=await GAD.griglia(document.getElementById("griglia"),document.getElementById("griglia").dataset.griglia||"incarichi_dm",{
    selezione:puoAffidare||puoRiesame||S.puo("fatture.genera")||S.puo("verifiche.esegui", "DM"),
    suRiga:puoAffidare||puoRiesame||S.puo("fatture.genera")||S.puo("verifiche.esegui", "DM")?null:(r)=>apri(r.id),
    pulsanti,
    azioni:{
      modifica:(r)=>apri(r.id),
      collegamenti:[
        {testo:"Attrezzatura → scheda",vai:(r)=>`/attrezzature?scheda=${r.asset_id}`},
        {testo:"Preventivo → scheda",vai:(r)=>`/preventivi-dm?apri=${r.preventivo_id}`},
        {testo:"Cliente → scheda",vai:(r)=>`/clienti?apri=${r.cliente_id}`},
      ],
    },
  });
  const carica=async()=>g.ricarica();
  async function apri(id,tab="Incarico") {
    const v=await api("GET",`/api/dm/incarichi/${id}`), d=v.bozza;
    const aperta=["assegnata","programmata","registrata"].includes(v.stato);
    const esecutore=S.puo("verifiche.assegna", "DM")||(S.puo("verifiche.esegui", "DM")&&io.id===v.verificatore_id);
    const refresh=async(t="Salvato",dest=tab)=>{toast(t);await apri(v.id,dest);await carica();};
    const post=(nome,dati)=>api("POST",`/api/dm/incarichi/${id}/${nome}`,{...dati,versione:v.versione});
    const lavoro=el("div",{},el("div",{class:"notice"},v.stato_testo,v.codice_verbale?` · ${v.codice_verbale}`:""),
      el("div",{class:"field-grid"},campo("Cliente",el("a",{href:`/clienti?apri=${v.cliente_id}`},v.cliente)),
      campo("Sede",el("a",{href:`/sedi?apri=${v.sede_id}`},v.sede)),campo("Attrezzatura",el("a",{href:`/attrezzature?scheda=${v.asset_id}`},`${v.gruppo} · ${v.matricola}`)),
      campo("Preventivo",el("a",{href:`/preventivi-dm?apri=${v.preventivo_id}`},v.preventivo)),campo("Prestazione",el("div",{},v.tipo_testo,el("div",{},v.combinazione_testo)))));
    if(v.stato==="annullata")lavoro.append(el("p",{},v.motivo_annullamento));
    // R108/R109: dopo un riesame non conforme il tecnico vede subito la nota del RT sulla propria verifica.
    if(v.stato==="registrata"&&v.riesame.fatto&&v.riesame.esito==="N")lavoro.append(el("div",{class:"notice errore"},
      `Riesame non conforme (${formatta.dataora(v.riesame.data)}, ${v.riesame.utente}): `,v.riesame.nota,
      el("div",{},"Correggi la scheda o ripeti l’attività, rigenera o ricarica il PDF e richiudi: servirà un nuovo riesame.")));
    if(["da_assegnare","assegnata","programmata","registrata","sospesa"].includes(v.stato)&&S.puo("verifiche.assegna", "DM")){
      const chi=sceltaTecnico(v.verificatore_id);
      lavoro.append(campo("Tecnico",chi),btn(v.verificatore_id?"Riassegna":"Assegna",async()=>{await post("assegna",{verificatore_id:chi.value});await refresh("Assegnato");},"primary"));
    } else lavoro.append(campo("Tecnico",el("div",{},v.verificatore||"—")));
    if(v.profilo_tecnico){
      // 0.12.9 (Federico, 12/10/2026): i dati del tecnico si inseriscono una volta per tutte in Gestione › Utenti e
      // permessi (o nel proprio profilo); qui si vedono soltanto
      const p=v.profilo_tecnico, mancano=["nome","cognome","qualifica","codice_fiscale"].filter(k=>!(p[k]||"").trim());
      const dove=S.puo("sistema.utenti")?el("a",{href:"/firme-dm"},"Configurazione › Firme dei verificatori"):el("a",{href:"/profilo"},"Il mio profilo");
      lavoro.append(el("div",{class:"riquadro"},el("h3",{},"Dati del tecnico"),
        el("p",{},[p.nome,p.cognome].filter(Boolean).join(" ")||"—",p.qualifica?` · ${p.qualifica}`:"",p.codice_fiscale?` · ${p.codice_fiscale}`:""),
        mancano.length?el("div",{class:"notice avviso"},`Mancano ${mancano.map(k=>k.replace("_"," ")).join(", ")}: servono nel verbale. Si completano in `,dove,"."):null,
        p.firma_dm?null:el("div",{class:"notice avviso"},"Manca la firma grafica DM del tecnico: il verbale uscirebbe senza firma. Si carica in ",dove,".")));
    }
    if(v.stato==="da_assegnare"&&v.indipendenza_esclusa)lavoro.append(el("div",{class:"notice errore"},v.indipendenza_esclusa));
    if(esecutore&&aperta){
      // R119: la dichiara il tecnico a cui è affidato l'incarico; con «No» torna al RT da riassegnare
      if(v.verificatore_id===io.id&&["assegnata","programmata"].includes(v.stato)){
        const indip=f.casella("Dichiaro la mia indipendenza per questo incarico",v.indipendenza);
        lavoro.append(el("div",{class:"riquadro"},indip.el,btn("Salva la dichiarazione",async()=>{
          if(!indip.valore&&!(await GAD.conferma("Dichiari di NON essere indipendente?","L'incarico torna al responsabile tecnico, che lo riassegnerà. La tua dichiarazione resta registrata.",{pulsante:"Non sono indipendente",pericolo:true})))return;
          await post("indipendenza",{indipendenza:indip.valore});
          if(indip.valore)await refresh("Indipendenza confermata");else{toast("Incarico restituito al responsabile tecnico.");pannello.chiudi();await carica();}
        })));
      }else lavoro.append(el("p",{class:"subtle"},`Indipendenza: ${v.indipendenza?"Sì":"No"} · la dichiara il tecnico a cui è affidato l'incarico.`));
      if(["assegnata","programmata"].includes(v.stato)){
        const data=f.data(v.data_programmata);
        lavoro.append(campo("Data prevista (facoltativa)",data),btn("Programma",async()=>{await post("programma",{data_programmata:data.value});await refresh("Programmato");}));
      }
      const motivo=f.area("",{placeholder:"Motivo della sospensione"});
      lavoro.append(campo("Sospendi il lavoro",motivo),btn("Sospendi",async()=>{await post("sospendi",{motivo:motivo.value});await refresh("Sospeso");}));
    }
    if(esecutore&&v.stato==="sospesa")lavoro.append(el("p",{},`Sospeso: ${v.motivo_sospensione}`),btn("Riprendi",async()=>{await post("riprendi",{});await refresh("Ripreso");}));
    // R134 (0.16): revisione del verbale emesso (stesso numero, rev. N+1, motivo), come nel DPR
    if(v.revisioni&&v.revisioni.length)lavoro.append(el("h3",{},`Revisioni del verbale (${v.revisioni.length})`),
      ...v.revisioni.map(x=>el("p",{},`rev. ${x.revisione} · ${formatta.dataora(x.il)} · ${x.da} · ${x.motivo}`)));
    if(v.stato==="effettuata"&&(S.puo("verifiche.revisione", "DM")||v.verificatore_id===io.id)){
      const motivoRev=f.area("",{placeholder:"Motivo della revisione (es. errore nella matricola del generatore)"});
      lavoro.append(campo("Revisione del verbale emesso",motivoRev),btn(`Crea revisione (rev. ${(v.revisione||0)+1})`,async()=>{
        if(!await conferma("Creare una revisione del verbale?","Il verbale torna «registrato» con lo stesso numero: correggi, rigenera l'anteprima ed emetti di nuovo. Il verbale emesso resta in archivio come sostituito.",{pulsante:"Crea revisione"}))return;
        await post("revisione",{motivo:motivoRev.value});await refresh("Revisione aperta");}));
    }
    // R135 (0.16): annulla l'RT oppure il verificatore a cui è affidato; il numero resta occupato
    if((S.puo("verifiche.annulla", "DM")||v.verificatore_id===io.id)&&v.stato!=="annullata"){
      const motivo=f.area("",{placeholder:"Motivo dell’annullamento"});
      lavoro.append(campo("Annullamento",motivo),btn("Annulla incarico",async()=>{if(!await conferma("Annullare l’incarico?","Il numero già assegnato rimane riservato.",{pulsante:"Annulla incarico"}))return;await post("annulla",{motivo:motivo.value});await refresh("Annullato");},"danger"));
    }
    const tecnica=el("div",{},el("p",{class:"subtle"},"Configurazione dalla scheda corrente. I campi dei precedenti sono riproposti finché i dati del verbale non vengono salvati."));
    const fonti=Object.entries(d.provenienza_precedenti||{});
    if(fonti.length)tecnica.append(el("details",{},el("summary",{},"Dati riproposti dai precedenti"),tabella(["Campo","Verbale","Data"],
      fonti.map(([k,x])=>[v.campi.find(c=>c.nome===k)?.etichetta||k,el("a",{href:`/incarichi-dm?apri=${x.incarico_id}`},x.codice),formatta.data(x.data_rilascio)]))));
    if(v.stato==="da_assegnare")tecnica.append(el("p",{},"Assegna l’incarico per iniziare il verbale."));
    else {
      const edit=esecutore&&aperta;
      const attributi={},tipo=f.testo(d.tipo_attr),esito=f.scelta(["Positivo","Negativo","Sospeso","A vuoto"].map(x=>({valore:x,testo:x})),d.esito),
        regime=f.scelta([{valore:"A1",testo:"Affidamento INAIL"},{valore:"A2",testo:"Affidamento datore di lavoro"}],d.regime,{vuota:"Scegli regime"}),
        rilascio=f.data(d.data_rilascio),sosp=f.area(d.motivazione_sospensione);
      regime.disabled=!edit||v.tipo==="V2";[tipo,esito,rilascio,sosp].forEach(x=>x.disabled=!edit);
      tecnica.append(el("div",{class:"field-grid"},campo("Tipo attrezzatura verbale",tipo,{aiuto:"Codice/descrizione manuale Garda; il salvataggio aggiorna anche la scheda del bene."}),campo("Esito",esito),campo("Regime",regime),campo("Data rilascio",rilascio),campo("Motivazione esito sospeso",sosp)));
      const date={};const gruppoDate=el("div",{class:"field-grid"});
      for(const [k,label]of Object.entries({funz:"Funzionamento",integrita:"Integrità",interna:"Visita interna",scsp:"SC/SP"})) {
        if(!v.componenti.includes(k))continue;
        date[k]=f.data(d.date[k]);date[k].disabled=!edit;gruppoDate.append(campo(`Prossima ${label}`,date[k]));
      }
      tecnica.append(el("h3",{},"Prossime date della prestazione"),gruppoDate);
      const affiancamento=sceltaTecnico(v.affiancamento_id);affiancamento.disabled=!edit;
      tecnica.append(campo("Tecnico in affiancamento (facoltativo)",affiancamento));
      const scCnd=d.scheda_corrente?.scadenze?.find(x=>x.componente==="cnd");
      const conCnd=v.gruppo==="GVR"&&v.componenti.includes("integrita")&&(scCnd?.data_ultima||scCnd?.data_prossima);
      const cnd={ultima:f.data(d.cnd?.ultima),prossima:f.data(d.cnd?.prossima),numero_report:f.testo(d.cnd?.numero_report)};
      if(conCnd){
        for(const x of Object.values(cnd))x.disabled=!edit;
        tecnica.append(el("h3",{},"CND della verifica"),el("div",{class:"field-grid"},campo("Data CND",cnd.ultima),
          campo("Prossimi CND",cnd.prossima),campo("Numero report",cnd.numero_report)));
      }
      if(v.data_pvp)tecnica.append(el("p",{},`Data riepilogativa: ${formatta.data(v.data_pvp)} · Contributo: ${formatta.importo(v.contributo)}`));
      const gruppoCampi=el("div",{class:"field-grid"});
      for(const field of v.campi){
        const val=d.campi[field.nome];let x;
        if(field.tipo==="boolean"){x=f.casella(field.etichetta,val);x.input.disabled=!edit;gruppoCampi.append(x.el);}
        else {x=field.tipo==="date"?f.data(val):field.area?f.area(val):f.testo(val);x.disabled=!edit;gruppoCampi.append(campo(field.etichetta,x,{pieno:field.area}));}
        const row=gruppoCampi.lastChild;
        attributi[field.nome]={x,field,row};
      }
      function visibilitaCampi(){
        for(const [k,{field,row}]of Object.entries(attributi)) {
          row.hidden=(k==="esito_motivi"&&esito.value!=="Negativo")||(field.conduttore&&!attributi.gvr_check_conduttore?.x.valore);
        }
        sosp.parentElement.hidden=esito.value!=="Sospeso";
      }
      esito.onchange=visibilitaCampi;
      if(attributi.gvr_check_conduttore)attributi.gvr_check_conduttore.x.input.onchange=visibilitaCampi;
      visibilitaCampi();
      tecnica.append(el("h3",{},"Compilazione tecnica"),gruppoCampi);
      // Camere del master: PS/TS/fluidi; Pes/Tes esclusivamente in questa verifica.
      const camere=(d.camere||[]).map(c=>({...c,attributi:{...c.attributi}}));
      const listaCamere=el("div",{class:"tabella-larga"});
      const cinput=(c,k,raw=false)=>{const x=f.testo(raw?c.attributi[k]:c[k],{"aria-label":`${k} — ${c.identificazione||"nuova camera"}`});x.disabled=!edit||(k==="gvr_pes"||k==="gvr_tes")&&!v.componenti.includes("funz");x.oninput=()=>raw?c.attributi[k]=x.value:c[k]=x.value;return x;};
      function disegnaCamere(){listaCamere.replaceChildren(tabella(["Camera / n.f.","Unità / valore","PS / TS","Pes / Tes","Fluido (natura / stato / gruppo)",""],camere.map((c,i)=>[
        el("div",{},cinput(c,"identificazione"),cinput(c,"num_fabbrica")),
        el("div",{},(()=>{const x=f.scelta(["L","DN"].map(x=>({valore:x,testo:x==="L"?"Litri":"DN (mm)"})),c.unita);x.disabled=!edit;x.onchange=()=>c.unita=x.value;return x;})(),cinput(c,"valore")),
        el("div",{},cinput(c,"gvr_ps",true),cinput(c,"gvr_ts",true)),el("div",{},cinput(c,"gvr_pes"),cinput(c,"gvr_tes"),(()=>{const p=(d.pes_tes_precedenti||{})[c.chiave];  // 0.13.0: confronto con il funzionamento precedente
          return p?el("div",{class:"subtle",title:`Verbale ${p.codice} del ${formatta.data(p.data)}`},`prec.: ${p.gvr_pes||"—"} bar · ${p.gvr_tes||"—"} °C`):null;})()),
        el("div",{},cinput(c,"gvr_nat",true),cinput(c,"gvr_stt",true),cinput(c,"gvr_grp",true)),
        edit?btn("Rimuovi",async()=>{if(!await conferma("Rimuovere la camera?","La configurazione aggiornerà anche la scheda dell’attrezzatura al salvataggio."))return;camere.splice(i,1);disegnaCamere();}):""
      ])));}
      if(v.gruppo==="GVR"){
        disegnaCamere();tecnica.append(el("h3",{},`Camere · volume attuale ${d.volume_totale_litri||"0"} L (DN esclusi)`),listaCamere);
        if(edit)tecnica.append(btn("Aggiungi camera",async()=>{camere.push({identificazione:"",num_fabbrica:"",unita:"L",valore:"0",attributi:{},gvr_pes:"",gvr_tes:""});disegnaCamere();}));
      }
      if(edit){
        const datiScheda=()=>{
          const dati={versione:v.versione,asset_versione:v.asset_versione,tipo_attr:tipo.value,esito:esito.value,regime:regime.value,
            affiancamento_id:affiancamento.value||null,
            data_rilascio:rilascio.value,motivazione_sospensione:sosp.value,date:Object.fromEntries(Object.entries(date).map(([k,x])=>[k,x.value])),
            campi:Object.fromEntries(Object.entries(attributi).map(([k,{x,field}])=>[k,field.tipo==="boolean"?x.valore:x.value]))};
          if(conCnd)dati.cnd=Object.fromEntries(Object.entries(cnd).map(([k,x])=>[k,x.value]));
          if(v.gruppo==="GVR")dati.camere=camere.map(c=>({id:c.id,identificazione:c.identificazione,num_fabbrica:c.num_fabbrica,unita:c.unita,valore:c.valore,
            dati_tecnici:Object.fromEntries(["gvr_ps","gvr_ts","gvr_nat","gvr_stt","gvr_grp"].map(k=>[k,c.attributi[k]||""])),gvr_pes:c.gvr_pes||"",gvr_tes:c.gvr_tes||""}));
          return dati;
        };
        const salva=()=>api("PUT",`/api/dm/incarichi/${id}/bozza`,datiScheda());
        tecnica.append(el("div",{class:"actions"},btn("Salva i dati del verbale",async()=>{await salva();await refresh("Dati del verbale salvati","Verbale");},"primary"),
          btn(v.stato==="registrata"?"Aggiorna registrazione":"Salva e registra",async()=>{
            if(!await conferma("Registrare la verifica?","Il numero annuale viene assegnato in base alla data di rilascio. Il cambio di anno assegna un nuovo numero.",{pulsante:"Registra"}))return;
            await api("POST",`/api/dm/incarichi/${id}/registra`,{versione:v.versione,bozza:datiScheda()});await refresh("Verifica registrata","Verbale");
          })));
      }
      if(v.stato==="registrata")tecnica.append(el("div",{class:"notice"},"La scheda è registrata. Apri Documenti per preparare e controllare il verbale."));
    }
    const documenti=el("div",{}),editDocumenti=esecutore&&v.stato==="registrata";
    const currentPdf=v.documenti.find(x=>x.attuale&&x.tipo==="verbale"&&x.formato==="pdf");
    if(editDocumenti){
      // 0.15: anteprima come in VerbalizzAI: spazio della firma riservato, riquadro firme intero in fondo alla pagina
      if(!v.profilo_tecnico?.firma_dm)documenti.append(el("div",{class:"notice"},"Il tecnico non ha ancora la firma DM: caricala in «Il mio profilo» (o in Gestione › Utenti). Senza firma DM non si genera l'anteprima e non si emette."));
      documenti.append(btn("Genera anteprima PDF",async()=>{await api("POST",`/api/dm/incarichi/${id}/documenti/genera`,{versione:v.versione});await refresh("Anteprima generata: controllala","Documenti");},"primary"));
      const file=el("input",{type:"file",accept:".pdf,.docx","aria-label":"Verbale o scheda tecnica"}),
        tipo=f.scelta([{valore:"verbale",testo:"Verbale"},{valore:"scheda_tecnica",testo:"Scheda tecnica V1"}],"verbale");
      documenti.append(el("div",{class:"riquadro"},campo("Documento da caricare",file),campo("Tipo",tipo),
        el("p",{class:"subtle"},"Ritocco: scarica il Word dell'anteprima, cambia solo l'impaginazione (lascia il riquadro tratteggiato della firma) e ricaricalo. Puoi anche caricare un PDF già firmato preparato a parte. Per la prima periodica allega anche la scheda tecnica PDF."),
        btn("Carica documento",async()=>{
          if(!file.files.length)throw new Error("Scegli un file.");
          const fd=new FormData();fd.append("file",file.files[0]);fd.append("versione",String(v.versione));fd.append("tipo",tipo.value);
          await api("POST",`/api/dm/incarichi/${id}/documenti/carica`,fd);await refresh("Documento caricato","Documenti");
        })));
    }
    if(v.documenti.length)documenti.append(tabella(["Documento","Versione","Origine",""],v.documenti.map(x=>[
      x.nome,x.definitivo?"Definitivo":x.attuale?"Corrente":"Sostituito",x.origine,
      el("a",{href:x.url,target:"_blank",rel:"noopener"},x.formato==="pdf"?"Apri PDF":"Scarica Word")])));
    else documenti.append(el("p",{},"Nessun documento caricato."));
    if(currentPdf){
      const frame=el("iframe",{src:currentPdf.url+"?in_linea=true",title:"PDF del verbale da controllare",width:"100%",height:"600"});
      const anteprima=["anteprima","word_ritoccato"].includes(currentPdf.origine);
      documenti.append(el("h3",{},currentPdf.definitivo?"PDF definitivo":anteprima?"Controlla l'anteprima (BOZZA)":"Controlla il PDF"),frame);
      if(editDocumenti)documenti.append(btn(anteprima?"Firma ed emetti il verbale":"Conferma PDF e chiudi verifica",async()=>{
        // 0.15: presa visione dell'anteprima, poi la firma DM entra nello spazio riservato (stesse pagine) e il verbale è emesso
        const aggiorna=el("input",{type:"radio",name:"dati-verbale",value:"aggiorna",checked:true}),conserva=el("input",{type:"radio",name:"dati-verbale",value:"conserva"});
        const corpo=el("div",{},el("p",{},anteprima?"Hai controllato l'anteprima: la firma DM del tecnico prende il posto del riquadro tratteggiato, senza cambiare le pagine. Il verbale diventa definitivo e si aggiornano le scadenze.":"Questo documento diventa il PDF definitivo della verifica e si aggiornano le scadenze."),
          el("h4",{},"Dati del verbale per le verifiche successive"),
          el("div",{},el("label",{class:"check"},aggiorna,"Aggiorna i dati dell'attrezzatura con questo verbale (accessori, osservazioni…)")),
          el("div",{},el("label",{class:"check"},conserva,"Conserva i dati attuali dell'attrezzatura (questo verbale ha dati validi solo per sé)")));
        if(!await modale(anteprima?"Firma ed emissione":"Confermare questo PDF?",corpo,[{testo:"Annulla",valore:null},{testo:anteprima?"Firma ed emetti":"Conferma e chiudi",valore:true,classe:"primary"}]))return;
        const result=await post("effettuata",{documento_id:currentPdf.id,impronta_pdf:currentPdf.impronta,dati_verbale:conserva.checked?"conserva":"aggiorna"});
        if(result.avvisi?.length)toast(result.avvisi.join(" "));
        await refresh("Verifica effettuata","Documenti");
      },"primary"));
    }
    if(v.stato==="effettuata"&&S.puo("verifiche.invia", "DM"))documenti.append(btn("Invia PDF definitivo",async()=>{
      const b=await api("GET",`/api/dm/incarichi/${id}/email`),a=f.testo(b.a),cc=f.testo(b.cc),oggetto=f.testo(b.oggetto),testo=f.area(b.testo);
      if(!await modale("Invia i documenti definitivi",el("div",{},campo("A",a),campo("Cc",cc),campo("Oggetto",oggetto),campo("Testo",testo),
        el("p",{},"Allegati: "+b.allegati.map(x=>x.nome).join("; "))),
        [{testo:"Annulla",valore:false},{testo:"Invia email",valore:true,classe:"primary"}]))return;
      await api("POST",`/api/dm/incarichi/${id}/email`,{versione:b.versione,a:a.value,cc:cc.value,oggetto:oggetto.value,testo:testo.value,allegati:b.allegati.map(x=>x.id)});
      await refresh("PDF inviato","Documenti");
    }));
    if(v.invii.length)documenti.append(el("h3",{},"Invii registrati"),tabella(["Data","Destinatari","Esito"],v.invii.map(x=>[formatta.dataora(x.data),x.destinatari,x.esito])));
    const riesame=el("div",{},el("p",{},v.riesame.fatto?`Ultimo riesame: ${v.riesame.esito==="C"?"Conforme":"Non conforme"} · ${v.riesame.utente}`:"Riesame non ancora registrato."));
    if(S.puo("verifiche.riesame", "DM") && v.verificatore_id!==io.id){
      const fatto=f.casella("Riesame effettuato",v.riesame.fatto),esito=f.scelta([{valore:"C",testo:"Conforme"},{valore:"N",testo:"Non conforme"}],v.riesame.esito,{vuota:"Scegli esito"}),nota=f.area(v.riesame.nota);
      riesame.append(fatto.el,campo("Esito",esito),campo("Nota",nota),btn("Registra riesame",async()=>{await post("riesame",{fatto:fatto.valore,esito:esito.value,nota:nota.value});await refresh("Riesame registrato","Riesame");},"primary"));
    }
    if(S.puo("verifiche.riesame", "DM") && v.verificatore_id===io.id)
      riesame.append(el("p", {class:"notice"}, "Non puoi riesaminare il tuo verbale: serve un altro responsabile tecnico abilitato."));
    // R139 (0.16): incarico effettuato e riesaminato conforme → si fattura da qui; poi si vede la fattura
    if(v.fattura)riesame.append(el("p",{},"Fatturato: ",el("a",{href:`/fatture-dm?apri=${v.fattura.id}`},v.fattura.codice?`fattura ${v.fattura.codice}`:`bozza n. ${v.fattura.id}`),v.fattura.stato==="bozza"?" (bozza da emettere)":""));
    else if(v.stato==="effettuata"&&v.riesame.fatto&&v.riesame.esito==="C"&&S.puo("fatture.genera"))riesame.append(el("div",{class:"actions"},btn("Fattura questo incarico…",()=>S.fatturaLavori({incarichi:[v.id]}),"primary")));
    if(v.riesami.length)riesame.append(tabella(["Data","Utente","Esito","Nota"],v.riesami.map(x=>[formatta.dataora(x.data),x.utente,x.fatto?(x.esito==="C"?"Conforme":"Non conforme"):"Non effettuato",x.nota])));
    const storico=el("div",{},btn("Mostra operazioni",async()=>{const rows=await api("GET",`/api/storico/incarico_dm/${id}`);storico.replaceChildren(tabella(["Quando","Utente","Operazione"],rows.map(r=>[formatta.dataora(r.quando),r.utente,r.descrizione])));}));
    const tabs=S.linguette([{titolo:"Incarico",contenuto:lavoro},{titolo:"Verbale",contenuto:tecnica},{titolo:"Documenti",contenuto:documenti},{titolo:"Riesame",contenuto:riesame},{titolo:"Operazioni",contenuto:storico}]);
    pannello.apri(`Incarico DM ${v.codice_verbale||id}`,tabs,[],{largo:true});
    const t=[...tabs.querySelectorAll(".tabs button")].find(x=>x.textContent===tab);if(t)t.click();
  }
  const id=new URLSearchParams(location.search).get("apri");if(id)await apri(Number(id));
})().catch(GAD.errore);
