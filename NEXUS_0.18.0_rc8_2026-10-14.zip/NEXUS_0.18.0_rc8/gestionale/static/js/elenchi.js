/* Elenchi di valori modificabili da menu: modalità di pagamento, aliquote IVA. */
"use strict";

(async () => {
  const { el, api, toast, errore, modale } = GAD;
  const S = GAD.schede;
  const { f, campo } = S;
  const contenitore = document.getElementById("elenchi");
  const { elenchi } = await api("GET", "/api/anagrafica/valori");

  async function modifica(elenco, x) {
    x = x || { attivo: true, ordine: 0 };
    const m = { descrizione: f.testo(x.descrizione, { maxlength: "200" }), codice: f.testo(x.codice, { maxlength: "20" }),
      ordine: f.numero(x.ordine), percentuale: f.numero(x.percentuale), natura: f.testo(x.natura, { maxlength: "10" }) };
    const attivo = f.casella("In uso (proposto nelle schede)", x.attivo);
    const split = f.casella("Scissione dei pagamenti (split payment)", x.scissione_pagamenti);
    const iva = elenco === "aliquota_iva";
    const ok = await modale(x.id ? "Modifica valore" : "Nuovo valore", [el("div", { class: "field-grid" },
      campo("Descrizione", m.descrizione, { pieno: true }), campo("Codice", m.codice), campo("Ordine", m.ordine),
      iva ? campo("Aliquota %", m.percentuale) : null, iva ? campo("Natura IVA (fattura elettronica)", m.natura, { aiuto: "Solo per non imponibili/esenti, es. N3.5" }) : null,
      iva ? el("div", { class: "field full" }, split.el) : null, el("div", { class: "field full" }, attivo.el))],
    [{ testo: "Annulla", valore: false }, { testo: "Salva", classe: "primary", valore: true }]);
    if (!ok) return;
    const dati = { elenco, ...Object.fromEntries(Object.entries(m).map(([k, v]) => [k, v.value])), attivo: attivo.valore, scissione_pagamenti: split.valore, versione: x.versione };
    try {
      if (x.id) await api("PUT", `/api/elenchi/${x.id}`, dati); else await api("POST", "/api/elenchi", dati);
      toast("Salvato."); disegna();
    } catch (e) { errore(e); }
  }

  async function disegna() {
    const pannelli = [];
    const solo = contenitore.dataset.solo;  // 0.12.5: «Tipi di pagamento» e «Aliquote IVA» hanno una voce di menu ciascuno
    for (const [codice, titolo] of Object.entries(elenchi).filter(([k]) => !solo || k === solo)) {
      const valori = await api("GET", `/api/elenchi/${codice}`);
      pannelli.push(el("div", { class: "panel" }, el("div", { class: "actions" }, el("h3", {}, titolo), el("span", { class: "spazio" }),
        el("button", { class: "btn small primary", type: "button", onclick: () => modifica(codice, null) }, "＋ Aggiungi")),
      S.tabella([
        { titolo: "Descrizione", valore: (x) => x.descrizione }, { titolo: "Codice", valore: (x) => x.codice },
        ...(codice === "aliquota_iva" ? [{ titolo: "%", num: true, valore: (x) => (x.percentuale ?? "") + "" }, { titolo: "Split payment", valore: (x) => (x.scissione_pagamenti ? "Sì" : "") }] : []),
        { titolo: "In uso", valore: (x) => (x.attivo ? "Sì" : "No") },
      ], valori, (x) => modifica(codice, x))));
    }
    contenitore.replaceChildren(...pannelli);
  }
  disegna();
})().catch((e) => GAD.errore(e));
