/* Griglia comune (decisioni D18, D33, D34) costruita sulla libreria Tabulator.
   Filtri, ordinamento, paginazione e totali li calcola il server: il browser riceve solo le righe visibili.
   Uso: const g = await GAD.griglia(contenitore, "utenti", { suRiga: (riga) => ..., pulsanti: [elementi],
          azioni: { modifica: (r) => ..., elimina: async (r) => ..., collegamenti: [{ testo, vai: (r) => url }] } });
   Azioni sulla riga (D50): icone modifica / elimina e menu «collegati» che apre un altro elenco già filtrato.
   Filtro dall'indirizzo: /impianti?campo=cliente_id&valore=12&etichetta=Cliente%20Rossi */
"use strict";


(() => {
  const { el, api, toast, errore, modale, formatta, scarica } = GAD;
  const SCALA_COLONNE = 1.15 * (parseFloat(getComputedStyle(document.documentElement).fontSize) || 16) / 16;

  const LINGUA = {
    it: {
      data: { loading: "Caricamento…", error: "Errore nel caricamento" },
      pagination: {
        page_size: "Righe per pagina", page_title: "Mostra pagina", first: "«", first_title: "Prima pagina",
        last: "»", last_title: "Ultima pagina", prev: "‹", prev_title: "Pagina precedente", next: "›", next_title: "Pagina successiva",
        all: "Tutte", counter: { showing: "Righe", of: "di", rows: "", pages: "pagine" },
      },
      headerFilters: { default: "filtra…" },
      groups: { item: "riga nella pagina", items: "righe nella pagina" },
    },
  };

  const SUGGERIMENTO = {
    testo: "contiene…", elenco: "", booleano: "",
    numero: "es. >10 o 5..20", importo: "es. >100 o 50..200",
    data: "es. 04/10/2026 o 2026", dataora: "es. 04/10/2026 o >01/09/2026",
  };

  function testoCella(colonna, v) {
    switch (colonna.tipo) {
      case "dataora": return formatta.dataora(v);
      case "data": return formatta.data(v);
      case "importo": return formatta.importo(v);
      case "numero": return formatta.numero(v);
      case "booleano": return formatta.booleano(v);
      default: return v === null || v === undefined ? "" : String(v);
    }
  }

  function formattatore(colonna) {
    // Restituisce sempre un nodo di testo: mai HTML costruito con i dati (sicurezza).
    return (cella) => {
      const v = cella.getValue();
      if (colonna.tipo === "booleano" && v !== null && v !== undefined) {
        return el("span", { class: v ? "cella-si" : "cella-no" }, v ? "Sì" : "No");
      }
      return document.createTextNode(testoCella(colonna, v));
    };
  }

  function etichettaFiltro(v) {
    if (!v || typeof v !== "object") return v || "";
    if (v.operatore === "vuoto") return "Non valorizzato";
    if (v.operatore === "intervallo") return `${v.da || "…"} → ${v.a || "…"}`;
    return `${({contiene: "Contiene", inizia: "Inizia con", finisce: "Finisce con", uguale: "Uguale a"})[v.operatore]}: ${v.valore || ""}`;
  }

  function filtroInput(cella, _parametri, successo) {
    const v = cella.getValue();
    const input = el("input", {type: "search", placeholder: "filtra…", value: etichettaFiltro(v)});
    input.addEventListener("input", () => successo(input.value));
    return input;
  }

  async function scegliFiltro(colonna, c) {
    const tabella = colonna.getTable(), attuale = tabella.getHeaderFilterValue(c.campo);
    const vuoto = el("input", {type: "checkbox"});
    vuoto.checked = attuale === "vuoto" || attuale?.operatore === "vuoto";
    const parti = [el("label", {class: "check"}, vuoto, "Non valorizzato")];
    let valore;
    if (c.tipo === "testo") {
      const op = el("select", {}, ...Object.entries({contiene: "Contiene", inizia: "Inizia con", finisce: "Finisce con", uguale: "Uguale a"})
        .map(([v, t]) => el("option", {value: v}, t)));
      op.value = typeof attuale === "object" ? attuale.operatore || "contiene" : "contiene";
      const t = el("input", {value: typeof attuale === "object" ? attuale.valore || "" : attuale === "vuoto" ? "" : attuale || ""});
      parti.push(el("label", {}, "Confronto", op), el("label", {}, "Testo", t));
      valore = () => vuoto.checked ? {operatore: "vuoto"} : {operatore: op.value, valore: t.value.trim()};
    } else if (["data", "dataora"].includes(c.tipo)) {
      const da = el("input", {type: "date", value: attuale?.da || ""}), a = el("input", {type: "date", value: attuale?.a || ""});
      const preset = el("select", {}, ...["Personalizzato", "Ieri", "Oggi", "Domani", "Mese scorso", "Questo mese", "Mese prossimo", "Anno scorso", "Questo anno", "Anno prossimo", "Ultimi 8 giorni", "Prossimi 8 giorni"]
        .map(t => el("option", {value: t}, t)));
      preset.addEventListener("change", () => {
        const oggi = new Intl.DateTimeFormat("en-CA", {timeZone: "Europe/Rome", year:"numeric", month:"2-digit", day:"2-digit"}).format(new Date());
        const [y, m, d] = oggi.split("-").map(Number), iso = (data) => data.toISOString().slice(0, 10);
        let inizio, fine;
        if (["Ieri", "Oggi", "Domani"].includes(preset.value)) {
          inizio = new Date(Date.UTC(y, m - 1, d + ({Ieri:-1, Oggi:0, Domani:1})[preset.value])); fine = inizio;
        } else if (["Mese scorso", "Questo mese", "Mese prossimo"].includes(preset.value)) {
          const mese = m - 1 + ({"Mese scorso":-1,"Questo mese":0,"Mese prossimo":1})[preset.value];
          inizio = new Date(Date.UTC(y, mese, 1)); fine = new Date(Date.UTC(y, mese + 1, 0));
        } else if (["Anno scorso", "Questo anno", "Anno prossimo"].includes(preset.value)) {
          const anno = y + ({"Anno scorso":-1,"Questo anno":0,"Anno prossimo":1})[preset.value];
          inizio = new Date(Date.UTC(anno, 0, 1)); fine = new Date(Date.UTC(anno, 11, 31));
        }
        if (preset.value === "Ultimi 8 giorni" || preset.value === "Prossimi 8 giorni") {
          inizio = new Date(Date.UTC(y,m-1,d-(preset.value === "Ultimi 8 giorni" ? 7 : 0)));
          fine = new Date(Date.UTC(y,m-1,d+(preset.value === "Prossimi 8 giorni" ? 7 : 0)));
        }
        if (inizio) {da.value = iso(inizio); a.value = iso(fine); vuoto.checked = false;}
      });
      parti.push(el("label", {}, "Periodo", preset), el("label", {}, "Da (compreso)", da), el("label", {}, "A (compreso)", a),
        el("p", {class: "subtle"}, "Puoi lasciare vuoto uno dei limiti. Il filtro comprende l'intera giornata, anche per data e ora."));
      valore = () => vuoto.checked ? {operatore: "vuoto"} : {operatore: "intervallo", da: da.value, a: a.value};
    } else {
      const input = ["elenco", "booleano"].includes(c.tipo)
        ? el("select", {}, el("option", {value:""}, "Tutti"), ...
          (c.tipo === "booleano" ? ["sì", "no"] : c.opzioni).map(v => el("option", {value:v}, v)))
        : el("input", {value: typeof attuale === "object" ? "" : attuale || "", placeholder:SUGGERIMENTO[c.tipo] || ""});
      if (input.tagName === "SELECT") input.value = typeof attuale === "string" && attuale !== "vuoto" ? attuale : "";
      parti.push(el("label", {}, "Valore", input));
      valore = () => vuoto.checked ? "vuoto" : input.value;
    }
    if (await modale(`Filtro: ${c.etichetta}`, parti, [{testo:"Annulla", valore:false}, {testo:"Applica", classe:"primary", valore:true}]))
      tabella.setHeaderFilterValue(c.campo, valore());
  }

  function colonnaTabulator(c, cfg) {
    const def = {
      title: c.etichetta,
      field: c.campo,
      visible: cfg ? cfg.visibile !== false : c.visibile,
      headerSort: c.ordinabile,
      formatter: formattatore(c),
      headerTooltip: c.descrizione || c.etichetta,
      hozAlign: ["numero", "importo"].includes(c.tipo) ? "right" : "left",
      minWidth: 100,
    };
    // le larghezze predefinite crescono con la misura del testo (D57); quelle salvate in una vista restano come sono
    const larghezza = (cfg && cfg.larghezza) || (c.larghezza && Math.round(c.larghezza * SCALA_COLONNE));
    if (larghezza) def.width = Math.max(larghezza, 100);
    def.titleFormatter = (cella) => {
      const col = cella.getColumn();
      const btn = (testo, titolo, fn) => el("button", {type:"button", class:"colonna-comando", title:titolo, "aria-label":`${titolo}: ${c.etichetta}`,
        onclick: (e) => {e.stopPropagation(); fn();}}, testo);
      return el("span", {class:"colonna-titolo"}, el("span", {}, c.etichetta), el("span", {class:"colonna-comandi"},
        c.filtrabile ? btn("⚲", "Filtra", () => scegliFiltro(col, c)) : null,
        c.filtrabile ? btn("×", "Cancella filtro", () => col.getTable().setHeaderFilterValue(c.campo, "")) : null,
        btn("◫", "Nascondi colonna", () => col.hide())));
    };
    if (c.filtrabile) {
      def.headerFilterEmptyCheck = (v) => !v || (typeof v === "object" && v.operatore !== "vuoto" &&
        (v.operatore === "intervallo" ? !v.da && !v.a : !v.valore));
      if (c.tipo === "booleano") {
        def.headerFilter = "list";
        def.headerFilterParams = { values: { "": "Tutti", sì: "Sì", no: "No" } };
      } else if (c.tipo === "elenco") {
        const valori = { "": "Tutti" };
        for (const o of c.opzioni) valori[o] = o;
        def.headerFilter = "list";
        def.headerFilterParams = { values: valori };
      } else {
        def.headerFilter = filtroInput;
        def.headerFilterPlaceholder = SUGGERIMENTO[c.tipo] || "";
      }
    }
    return def;
  }

  // ---- menu delle entità collegate (uno solo per pagina)
  const menuRiga = el("div", { class: "menu menu-riga", hidden: true });
  document.body.append(menuRiga);
  document.addEventListener("click", (e) => { if (!menuRiga.contains(e.target)) menuRiga.hidden = true; });
  document.addEventListener("scroll", () => { menuRiga.hidden = true; }, true);

  function colonnaAzioni(azioni) {
    return {
      title: "Azioni", field: "_azioni", headerSort: false, frozen: true, width: 52 + 34 * ((azioni.modifica ? 1 : 0) + (azioni.elimina ? 1 : 0) + (azioni.extra || []).length) + (azioni.collegamenti ? 10 : -34), minWidth: 60,
      resizable: false, hozAlign: "left", headerHozAlign: "left",
      formatter: (cella) => {
        const r = cella.getRow().getData();
        const pulsante = (testo, titolo, classe, fn) => el("button", { type: "button", class: "azione-riga " + classe, title: titolo,
          onclick: (ev) => { ev.stopPropagation(); fn(ev); } }, testo);
        const parti = [];
        if (azioni.modifica) parti.push(pulsante("✎", "Apri / modifica", "modifica", () => azioni.modifica(r)));
        if (azioni.elimina) parti.push(pulsante("🗑", "Elimina", "elimina", () => azioni.elimina(r)));
        for (const x of azioni.extra || []) parti.push(pulsante(x.testo, x.titolo, "extra", () => x.fn(r)));
        if (azioni.collegamenti && azioni.collegamenti.length) {
          parti.push(pulsante("⇄▾", "Vai agli elementi collegati", "collegati", (ev) => {
            menuRiga.replaceChildren(...azioni.collegamenti.map((c) => el("div", { class: "voce" },
              el("button", { class: "nome", type: "button", onclick: () => { menuRiga.hidden = true; location.href = c.vai(r); } }, typeof c.testo === "function" ? c.testo(r) : c.testo))));
            const b = ev.currentTarget.getBoundingClientRect();
            menuRiga.style.left = `${b.left + window.scrollX}px`;
            menuRiga.style.top = `${b.bottom + window.scrollY + 4}px`;
            menuRiga.hidden = false;
          }));
        }
        return el("span", { class: "azioni-riga" }, ...parti);
      },
    };
  }

  async function griglia(contenitore, codice, opzioni = {}) {
    const [def, configurazioni] = await Promise.all([
      api("GET", `/api/griglie/${codice}/definizione`),
      api("GET", `/api/griglie/${codice}/configurazioni`),
    ]);
    let elencoConfigurazioni = configurazioni;
    const predefinita = elencoConfigurazioni.find((c) => c.predefinita);
    let stato = predefinita ? predefinita.dati : null;
    // 0.12.10: senza una configurazione predefinita dell'utente vale la vista di partenza della griglia (per attività)
    if (!stato && def.viste_predefinite) {
      const att = document.documentElement.dataset.ambito || "";
      const vp = def.viste_predefinite[att] || def.viste_predefinite[""];
      if (vp) {
        const visibili = vp.colonne.filter((c) => def.colonne.some((x) => x.campo === c));
        stato = { colonne: [...visibili.map((c) => ({ campo: c, visibile: true })),
          ...def.colonne.filter((c) => !visibili.includes(c.campo)).map((c) => ({ campo: c.campo, visibile: false }))],
        raggruppa: vp.raggruppa || "", filtri: vp.filtri || [] };
        if (vp.raggruppa && !def.gruppi_per_scadenza) stato.ordinamenti = [{ campo: vp.raggruppa, direzione: "asc" }, ...def.ordine_predefinito.filter((o) => o.campo !== vp.raggruppa)];
      }
    }
    let ricerca = (stato && stato.ricerca) || "";
    let raggruppa = (stato && stato.raggruppa) || "";
    let richieste = 0;
    let somme = {};

    // ---- barra degli strumenti
    const cerca = el("input", { class: "cerca", type: "search", placeholder: "Cerca in tutte le colonne di testo…", value: ricerca });
    const selRaggruppa = el("select", { title: "Raggruppa le righe della pagina per colonna" },
      el("option", { value: "" }, "Nessun raggruppamento"),
      ...(def.raggruppamenti || []).map((campo) => {
        const c = def.colonne.find(x => x.campo === campo);
        return el("option", {value: campo}, `Raggruppa per: ${c.etichetta}`);
      }));
    const assicuraGruppo = (campo) => {
      if (campo && def.colonne.some(c => c.campo === campo && c.ordinabile) && ![...selRaggruppa.options].some(o => o.value === campo))
        selRaggruppa.append(el("option", {value:campo}, `Raggruppa per: ${def.colonne.find(c=>c.campo===campo).etichetta} (vista salvata)`));
    };
    assicuraGruppo(raggruppa);
    selRaggruppa.value = raggruppa;
    const btnColonne = el("button", { class: "btn small", type: "button" }, "Colonne");
    const btnConfig = el("button", { class: "btn small", type: "button" }, "Configurazioni ▾");
    const menuConfig = el("div", { class: "menu", hidden: true });
    const btnAzzera = el("button", { class: "btn small", type: "button", title: "Toglie filtri, ricerca e raggruppamento" }, "Azzera filtri");
    const btnEsporta = def.puo_esportare ? el("button", { class: "btn small", type: "button", title: "Esporta in Excel le colonne visibili con i filtri applicati" }, "Esporta Excel") : null;
    const btnAggiorna = el("button", { class: "btn small", type: "button" }, "Aggiorna");
    // Ambito di lavoro (R114): clienti e sedi dell'attività scelta in alto; con un clic si vedono tutti
    const ambitoPagina = def.filtra_ambito ? (document.documentElement.dataset.ambito || "") : "";
    const opzioneAmbito = ambitoPagina ? document.querySelector(`#ambito-attivo option[value="${ambitoPagina}"]`) : null;
    const nomeAmbito = opzioneAmbito ? opzioneAmbito.textContent.trim() : ambitoPagina;
    let soloAmbito = !!ambitoPagina;
    try { if (ambitoPagina && localStorage.getItem(`gad_tutti_${codice}`) === "1") soloAmbito = false; } catch (_e) { /* preferenza non disponibile */ }
    const btnAmbito = ambitoPagina ? el("button", { class: "btn small", type: "button",
      title: "Anagrafica unica: qui per comodità solo i clienti/sedi dell'attività scelta in alto. Clic per vederli tutti." }) : null;
    const mostraAmbito = () => {
      if (!btnAmbito) return;
      btnAmbito.textContent = soloAmbito ? `Solo ${nomeAmbito} ✓` : "Tutti gli ambiti";
      btnAmbito.classList.toggle("primary", soloAmbito);
    };
    mostraAmbito();
    const tuttiPulsanti = opzioni.pulsanti || [];
    const azioniSelezione = tuttiPulsanti.filter(b => /selezionat/i.test(b.textContent));
    azioniSelezione.sort((a,b) => {
      const peso = t => /Affida/.test(t) ? 0 : /Registra/.test(t) ? 1 : /Riesamina/.test(t) ? 2 : /Fattura/.test(t) ? 3 : 4;
      return peso(a.textContent) - peso(b.textContent);
    });
    const filtriRapidi = tuttiPulsanti.filter(b => !azioniSelezione.includes(b));
    const personali = filtriRapidi.filter(b => /^(Le mie|Assegnate a me)$/.test(b.textContent));
    const barraFiltri = el("div", {class:"griglia-filtri", "aria-label":"Filtri di lavoro"},
      ...filtriRapidi.filter(b => !personali.includes(b)), personali.length ?
        el("span", {class:"filtri-personali"}, el("span", {class:"subtle"}, "Personali: "), ...personali) : null);
    const selezioneInfo = el("span", {class:"selezione-conteggio"}, "0 selezionate");
    const barraAzioni = el("div", {class:"griglia-azioni", "aria-label":"Azioni sulle righe selezionate"}, selezioneInfo, ...azioniSelezione);
    const barra = el("div", { class: "griglia-barra" }, btnAmbito, cerca, selRaggruppa, btnColonne,
      el("div", { class: "menu-tendina" }, btnConfig, menuConfig), btnAzzera,
      el("details", {class:"strumenti-secondari"}, el("summary", {}, "Altri strumenti"), btnEsporta, btnAggiorna));
    const aiuto = el("div", { class: "griglia-aiuto" },
      "Ogni colonna: ⚲ filtro · × cancella filtro · ◫ nascondi. Testo: contiene, inizia, finisce, uguale. Date: periodo da/a e scelte rapide. Trascina i titoli per spostare le colonne.");
    const area = el("div");
    const piede = el("div", { class: "griglia-piede" });
    contenitore.replaceChildren(el("div", { class: "griglia" }, barraFiltri, barra, azioniSelezione.length ? barraAzioni : null, aiuto, area, piede));
    const contesto = opzioni.contesto || null;
    if (contesto) contenitore.querySelector(".griglia").prepend(el("div", {class:"notice contesto-preventivo"},
      opzioni.etichettaContesto || "Righe del preventivo", " · questo riferimento resta attivo quando cambi filtri o vista."));

    // ---- colonne nell'ordine salvato
    const perCampo = Object.fromEntries(def.colonne.map((c) => [c.campo, c]));
    let ordine = def.colonne.map((c) => c.campo);
    const cfgColonne = {};
    if (stato && Array.isArray(stato.colonne)) {
      const salvati = stato.colonne.map((c) => c.campo).filter((c) => perCampo[c]);
      ordine = [...salvati, ...ordine.filter((c) => !salvati.includes(c))];
      for (const c of stato.colonne) cfgColonne[c.campo] = c;
    }

    // ---- filtro arrivato dall'indirizzo (da un'altra pagina: «Impianti ← Cliente»)
    const daIndirizzo = new URLSearchParams(location.search);
    const filtroIndirizzo = perCampo[daIndirizzo.get("campo")] ? { campo: daIndirizzo.get("campo"), valore: daIndirizzo.get("valore") || "", etichetta: daIndirizzo.get("etichetta") || "" } : null;
    const filtriIniziali = ((stato && stato.filtri) || []).filter((f) => perCampo[f.campo]);
    if (filtroIndirizzo && !contesto) {
      // l'indirizzo si ripulisce, ma il filtro resta noto alla pagina per precompilare «Nuovo» (O5, corretto nella 0.6.1)
      GAD.filtroCollegato = { campo: filtroIndirizzo.campo, valore: filtroIndirizzo.valore };
      history.replaceState(null, "", location.pathname);
      cfgColonne[filtroIndirizzo.campo] = { ...(cfgColonne[filtroIndirizzo.campo] || {}), campo: filtroIndirizzo.campo, visibile: true };
      filtriIniziali.splice(0, filtriIniziali.length, { campo: filtroIndirizzo.campo, valore: filtroIndirizzo.valore });
      soloAmbito = false; mostraAmbito();  // arrivando da un collegamento si vede tutto quello che il collegamento indica
      const togli = el("button", { class: "btn small", type: "button", onclick: () => { tabella.clearHeaderFilter(); avvisoFiltro.remove(); GAD.filtroCollegato = null; } }, "Togli il filtro");
      const avvisoFiltro = el("div", { class: "notice filtro-collegato" }, "Elenco filtrato: ", el("strong", {}, filtroIndirizzo.etichetta || `${perCampo[filtroIndirizzo.campo].etichetta} = ${filtroIndirizzo.valore}`), " ", togli);
      contenitore.querySelector(".griglia").prepend(avvisoFiltro);
    }
    const colonneTabulator = ordine.map((c) => colonnaTabulator(perCampo[c], cfgColonne[c]));
    if (opzioni.azioni) colonneTabulator.unshift(colonnaAzioni(opzioni.azioni));
    if (opzioni.selezione) {  // caselle per scegliere più righe (es. scadenze → un solo preventivo)
      colonneTabulator.unshift({ formatter: "rowSelection", titleFormatter: "rowSelection", field: "_sel", hozAlign: "center", headerSort: false,
        width: 42, frozen: true, resizable: false, cellClick: (_e, cella) => cella.getRow().toggleSelect() });
    }

    const tabella = new Tabulator(area, {
      layout: "fitDataStretch",
      locale: "it",
      langs: LINGUA,
      placeholder: "Nessun elemento trovato con questi filtri",
      movableColumns: true,
      // Testo intero al passaggio del mouse, solo quando la cella è tagliata (D57)
      columnDefaults: {
        headerTooltip: true,
        tooltip: (_e, cella) => {
          const elemento = cella.getElement();
          if (String(cella.getField() || "").startsWith("_") || elemento.scrollWidth <= elemento.clientWidth) return "";  // niente suggerimento
          return el("div", {}, elemento.textContent);  // come testo, mai come HTML
        },
      },
      selectableRows: opzioni.selezione ? (opzioni.suRiga ? "highlight" : true) : false,  // con suRiga il clic apre la scheda: si sceglie con la casella
      selectableRowsPersistence: false,
      height: opzioni.altezza || "62vh",
      columns: colonneTabulator,
      pagination: true,
      paginationMode: "remote",
      paginationSize: (stato && stato.dimensione) || 25,
      paginationSizeSelector: def.dimensioni_pagina,
      paginationCounter: "rows",
      sortMode: "remote",
      filterMode: "remote",
      headerFilterLiveFilterDelay: 600,
      initialSort: (stato && stato.ordinamenti ? stato.ordinamenti : def.ordine_predefinito)
        .filter((o) => perCampo[o.campo]).map((o) => ({ column: o.campo, dir: o.direzione })),
      initialHeaderFilter: filtriIniziali.map((f) => ({ field: f.campo, value: f.valore })),
      groupBy: raggruppa || false,
      ajaxURL: `/api/griglie/${codice}/dati`,
      ajaxRequestFunc: (_url, _config, p) => {
        const n = ++richieste;  // le risposte possono arrivare in disordine: il piede segue solo l'ultima richiesta
        return api("POST", `/api/griglie/${codice}/dati`, {
          pagina: p.page, dimensione: p.size, ricerca, ambito: soloAmbito ? ambitoPagina : "", contesto, raggruppa,
          filtri: (p.filter || []).map((f) => ({ campo: f.field, valore: f.value })),
          ordinamenti: (p.sort || []).map((s) => ({ campo: s.field, direzione: s.dir })),
        }).then((r) => { if (n === richieste) { somme = r.somme || {}; mostraSomme(r.totale); } return r; })
          .catch((e) => { errore(e); throw e; });
      },
      ajaxResponse: (_url, _p, r) => ({ last_page: r.pagine, last_row: r.totale, data: r.righe }),
    });

    function aggiornaSelezione() {
      const righe = tabella.getSelectedData();
      selezioneInfo.textContent = righe.length === 1 ? "1 selezionata" : `${righe.length} selezionate`;
      for (const b of azioniSelezione) {
        let motivo = !righe.length ? "Seleziona almeno una riga." : "";
        if (!motivo && /Fattura/.test(b.textContent) && righe.some(r => r.da_fatturare !== "Sì"))
          motivo = "Seleziona solo lavori conclusi, riesaminati conformi e ancora da fatturare.";
        if (!motivo && /Riesamina/.test(b.textContent) && righe.some(r => r.verificatore_id === GAD.utenteId))
          motivo = "Non puoi riesaminare il tuo verbale: togli la selezione dai tuoi incarichi.";
        if (!motivo && /Affida/.test(b.textContent)) {
          const aperti = ["Da assegnare", "Assegnata", "Programmata", "Registrata", "Sospesa"];
          if (righe.some(r => !aperti.includes(r.verifica_stato || r.stato)))
            motivo = "Seleziona solo verifiche già nate e ancora affidabili.";
        }
        if (!motivo && /Registra/.test(b.textContent) && righe.some(r => r.verificatore_id !== GAD.utenteId || !["Assegnata", "Programmata"].includes(r.stato)))
          motivo = "Seleziona soltanto i tuoi incarichi assegnati o programmati.";
        b.disabled = !!motivo; b.title = motivo || "Applica alle righe selezionate.";
      }
    }
    tabella.on("rowSelectionChanged", aggiornaSelezione);
    tabella.on("dataLoaded", aggiornaSelezione);
    aggiornaSelezione();

    function mostraSomme(totale) {
      const parti = [el("span", {}, "Trovati: ", el("strong", {}, formatta.numero(totale)))];
      for (const [campo, valore] of Object.entries(somme)) {
        const c = perCampo[campo];
        parti.push(el("span", {}, `${/^totale\b/i.test(c.etichetta) ? c.etichetta : "Totale " + c.etichetta}: `, el("strong", {}, testoCella(c, valore))));
      }
      piede.replaceChildren(...parti);
    }

    if (opzioni.suRiga) tabella.on("rowClick", (_e, riga) => opzioni.suRiga(riga.getData()));

    // ---- stato corrente (per configurazioni ed esportazione); la colonna «Azioni» non è un dato
    const colonneDati = () => tabella.getColumns().filter((c) => perCampo[c.getField()]);
    function statoCorrente() {
      return {
        colonne: colonneDati().map((c) => ({ campo: c.getField(), visibile: c.isVisible(), larghezza: Math.round(c.getWidth()) })),
        filtri: tabella.getHeaderFilters().map((f) => ({ campo: f.field, valore: f.value })),
        ordinamenti: tabella.getSorters().map((s) => ({ campo: s.field, direzione: s.dir })),
        raggruppa, ricerca, dimensione: tabella.getPageSize(),
      };
    }

    function applica(dati) {
      const campiOrdinati = (dati.colonne || []).map((c) => c.campo).filter((c) => perCampo[c]);
      for (const col of colonneDati()) {
        const salvato = (dati.colonne || []).find((c) => c.campo === col.getField());
        if (salvato) {
          salvato.visibile ? col.show() : col.hide();
          if (salvato.larghezza) col.setWidth(salvato.larghezza);
        } else perCampo[col.getField()].visibile ? col.show() : col.hide();
      }
      for (let i = campiOrdinati.length - 1; i > 0; i--) tabella.moveColumn(campiOrdinati[i], campiOrdinati[i - 1], true);
      ricerca = dati.ricerca || "";
      cerca.value = ricerca;
      raggruppa = dati.raggruppa || "";
      assicuraGruppo(raggruppa);
      selRaggruppa.value = raggruppa;
      tabella.setGroupBy(raggruppa || false);
      tabella.clearHeaderFilter();
      for (const f of dati.filtri || []) if (perCampo[f.campo]) tabella.setHeaderFilterValue(f.campo, f.valore);
      tabella.setSort((dati.ordinamenti || []).filter((o) => perCampo[o.campo]).map((o) => ({ column: o.campo, dir: o.direzione })));
      if (dati.dimensione) tabella.setPageSize(dati.dimensione);
    }

    function richiestaCorrente() {
      const s = statoCorrente();
      return { ricerca, filtri: s.filtri, ordinamenti: s.ordinamenti, ambito: soloAmbito ? ambitoPagina : "", contesto, raggruppa };
    }

    // ---- eventi della barra
    let attesa;
    cerca.addEventListener("input", () => {
      clearTimeout(attesa);
      attesa = setTimeout(() => { ricerca = cerca.value.trim(); tabella.setData(); }, 500);
    });
    selRaggruppa.addEventListener("change", () => {
      raggruppa = selRaggruppa.value;
      if (raggruppa && !def.gruppi_per_scadenza) {
        const altri = tabella.getSorters().filter(x => x.field !== raggruppa).map(x => ({column:x.field, dir:x.dir}));
        tabella.setSort([{ column: raggruppa, dir: "asc" }, ...altri]);
      } else tabella.setData();
      tabella.setGroupBy(raggruppa || false);
      if (raggruppa) toast("Raggruppamento applicato alle righe della pagina (aumenta «Righe per pagina» per vederne di più).");
    });
    btnAzzera.addEventListener("click", () => {
      ricerca = ""; cerca.value = ""; raggruppa = ""; selRaggruppa.value = "";
      tabella.setGroupBy(false);
      tabella.clearHeaderFilter();
      tabella.setData();
    });
    btnAggiorna.addEventListener("click", () => tabella.setData());
    if (btnAmbito) btnAmbito.addEventListener("click", () => {
      soloAmbito = !soloAmbito; mostraAmbito();
      try { localStorage.setItem(`gad_tutti_${codice}`, soloAmbito ? "0" : "1"); } catch (_e) { /* preferenza non disponibile */ }
      tabella.setData();
    });

    btnColonne.addEventListener("click", () => {
      const voci = colonneDati().map((col) => {
        const casella = el("input", { type: "checkbox" });
        casella.checked = col.isVisible();
        casella.addEventListener("change", () => (casella.checked ? col.show() : col.hide()));
        return el("label", { class: "check" }, casella, perCampo[col.getField()].etichetta);
      });
      modale("Colonne visibili", [
        el("p", { class: "subtle" }, "Scegli le colonne da mostrare (e da esportare in Excel). Per cambiare l'ordine trascina i titoli delle colonne nella griglia."),
        el("div", { class: "elenco-colonne" }, ...voci),
      ], [{ testo: "Fatto", classe: "primary", valore: null }]);
    });

    if (btnEsporta) btnEsporta.addEventListener("click", async () => {
      const colonne = colonneDati().filter((c) => c.isVisible()).map((c) => c.getField());
      btnEsporta.disabled = true;
      try {
        await scarica("POST", `/api/griglie/${codice}/esporta`, { ...richiestaCorrente(), colonne }, `${def.titolo}.xlsx`);
        toast("Esportazione completata.");
      } catch (e) { errore(e); } finally { btnEsporta.disabled = false; }
    });

    // ---- configurazioni salvate
    function disegnaMenu() {
      const voci = elencoConfigurazioni.map((c) => el("div", { class: "voce" },
        el("button", { class: "nome", type: "button", onclick: () => { applica(c.dati); menuConfig.hidden = true; toast(`Configurazione «${c.nome}» applicata.`); } }, c.nome),
        c.predefinita ? el("span", { class: "stella", title: "Si apre in automatico" }, "★ predefinita") : null,
        el("button", { class: "btn small", type: "button", title: "Elimina", onclick: async () => {
          try {
            await api("DELETE", `/api/griglie/${codice}/configurazioni/${c.id}`);
            elencoConfigurazioni = elencoConfigurazioni.filter((x) => x.id !== c.id);
            disegnaMenu();
          } catch (e) { errore(e); }
        } }, "×")));
      menuConfig.replaceChildren(
        el("div", { class: "voce" }, el("button", { class: "nome", type: "button", onclick: salvaConfigurazione }, "＋ Salva la vista attuale…")),
        el("div", {class:"voce"}, el("button", {class:"nome", type:"button", onclick: () => {
          const att = document.documentElement.dataset.ambito || "";
          const vp = def.viste_predefinite?.[att] || def.viste_predefinite?.[""];
          applica(vp ? {colonne:def.colonne.map(c=>({campo:c.campo,visibile:vp.colonne.includes(c.campo)}))
            .sort((a,b)=> (vp.colonne.indexOf(a.campo)<0?999:vp.colonne.indexOf(a.campo))-(vp.colonne.indexOf(b.campo)<0?999:vp.colonne.indexOf(b.campo))),
            raggruppa:vp.raggruppa || "", filtri:vp.filtri || [], ordinamenti:def.ordine_predefinito}
            : {colonne:def.colonne.map(c=>({campo:c.campo,visibile:c.visibile})),ordinamenti:def.ordine_predefinito});
          menuConfig.hidden = true;
        }}, "Vista iniziale della versione corrente")),
        el("div", { class: "separatore" }),
        ...(voci.length ? voci : [el("div", { class: "vuoto" }, "Nessuna configurazione salvata")]),
      );
    }

    async function salvaConfigurazione() {
      menuConfig.hidden = true;
      const nome = el("input", { maxlength: "80", placeholder: "es. Utenti attivi" });
      const pred = el("input", { type: "checkbox" });
      const ok = await modale("Salva la vista attuale", [
        el("p", { class: "subtle" }, "Salva colonne visibili e loro ordine, filtri, ordinamento, raggruppamento e righe per pagina. Se il nome esiste già, viene aggiornata."),
        el("div", { class: "field" }, el("label", {}, "Nome"), nome),
        el("label", { class: "check" }, pred, "Apri questa vista in automatico"),
      ], [{ testo: "Annulla", valore: false }, { testo: "Salva", classe: "primary", valore: true }]);
      if (!ok) return;
      try {
        const salvata = await api("POST", `/api/griglie/${codice}/configurazioni`, { nome: nome.value.trim() || "Senza nome", dati: statoCorrente(), predefinita: pred.checked });
        elencoConfigurazioni = elencoConfigurazioni.filter((c) => c.id !== salvata.id).map((c) => ({ ...c, predefinita: salvata.predefinita ? false : c.predefinita }));
        elencoConfigurazioni.push(salvata);
        elencoConfigurazioni.sort((a, b) => a.nome.localeCompare(b.nome));
        disegnaMenu();
        toast(`Vista «${salvata.nome}» salvata.`);
      } catch (e) { errore(e); }
    }

    btnConfig.addEventListener("click", (e) => { e.stopPropagation(); disegnaMenu(); menuConfig.hidden = !menuConfig.hidden; });
    document.addEventListener("click", (e) => { if (!menuConfig.contains(e.target)) menuConfig.hidden = true; });

    return { tabella, ricarica: () => tabella.setData(), definizione: def, selezionate: () => tabella.getSelectedData(),
      filtra: (campo, valore) => tabella.setHeaderFilterValue(campo, valore) };
  }

  GAD.griglia = griglia;
})();
