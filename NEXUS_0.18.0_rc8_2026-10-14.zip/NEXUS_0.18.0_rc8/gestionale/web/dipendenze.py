"""Controlli comuni a ogni richiesta: chi è l'utente, ha il permesso, il codice anti-contraffazione è giusto.

Il server controlla SEMPRE il permesso (convenzione 03 § 3): l'interfaccia nasconde i pulsanti, ma
anche una richiesta costruita a mano viene rifiutata.
"""

from __future__ import annotations

import hmac
from collections.abc import Callable
from urllib.parse import urlparse

from fastapi import Depends, Request

from ..core.db import Archivio
from ..core.errori import ErroreUtente, PermessoNegato
from ..moduli.utenti import accesso
from ..moduli.utenti.accesso import UtenteCorrente

COOKIE_SESSIONE = "gad_sessione"
METODI_SICURI = {"GET", "HEAD", "OPTIONS"}
# Con la password provvisoria si può solo cambiarla (o uscire).
PERCORSI_CON_PASSWORD_PROVVISORIA = {"/api/io", "/api/io/password", "/api/uscita"}


def archivio(request: Request) -> Archivio:
    return request.app.state.archivio


def controlla_origine(request: Request) -> None:
    """Rifiuta richieste di modifica partite da altri siti (difesa in più oltre al cookie SameSite)."""
    origine = request.headers.get("origin") or request.headers.get("referer")
    if not origine:
        return
    if urlparse(origine).netloc != request.headers.get("host", ""):
        raise PermessoNegato("Richiesta rifiutata: proviene da un'altra pagina web.")


def utente(request: Request) -> UtenteCorrente:
    u = accesso.leggi_sessione(archivio(request), request.cookies.get(COOKIE_SESSIONE))
    if request.method not in METODI_SICURI:
        controlla_origine(request)
        inviato = request.headers.get("x-csrf-token", "")
        if not hmac.compare_digest(inviato, u.csrf):
            raise PermessoNegato("Richiesta non valida (codice di sicurezza mancante o scaduto): ricarica la pagina e riprova.")
    if u.cambio_password_richiesto and request.url.path.startswith("/api/") and request.url.path not in PERCORSI_CON_PASSWORD_PROVVISORIA:
        raise ErroreUtente("Devi cambiare la password provvisoria prima di continuare (pagina «Il mio profilo»).", 403)
    request.state.utente = u
    return u


def richiede(codice: str, attivita: str | None = None) -> Callable[..., UtenteCorrente]:
    """Dipendenza: l'utente deve avere il permesso `codice`."""

    def _controllo(u: UtenteCorrente = Depends(utente)) -> UtenteCorrente:
        if not u.puo(codice, attivita):
            raise PermessoNegato()
        return u

    return _controllo


def ip(request: Request) -> str:
    return request.client.host if request.client else ""
