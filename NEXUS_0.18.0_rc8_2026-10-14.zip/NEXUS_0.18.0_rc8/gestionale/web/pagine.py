"""Pagine HTML. Il contenuto vero arriva dall'interfaccia JSON; qui si controlla solo l'accesso.

Nessuno script o stile scritto dentro le pagine (regole di sicurezza del browser): ogni pagina
carica il proprio file JavaScript da /static/js e riceve i dati iniziali come attributi `data-`.
"""

from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

from .. import VERSIONE
from ..core.errori import ErroreUtente, NonAutenticato
from ..moduli.utenti import accesso, servizio as utenti
from .dipendenze import COOKIE_SESSIONE, utente

templates = Jinja2Templates(directory=str(Path(__file__).resolve().parents[1] / "templates"))
router = APIRouter()

# Voci del menu (R117, 11/10/2026): per ogni attività le sezioni dei gestionali di Garda, nello stesso ordine —
# Clienti, (Impianti | Attrezzature), Scadenze, Preventivi, Verifiche, Fatture, Gestione. Le voci con `fase` sono
# «in arrivo»: si vedono ma non si aprono ancora.
def _v(titolo: str, icona: str, url: str | None, permesso: str | None = None, fase: str | None = None) -> dict:
    v = {"titolo": titolo, "icona": icona, "url": url}
    if permesso:
        v["permesso"] = permesso
    if fase:
        v["fase"] = fase
    return v


# 0.12.8 (Federico, 11/10/2026): menu a gruppi richiudibili sulle voci principali —
# Clienti (clienti, sedi operative) · Impianti o Attrezzature · Scadenze · Preventivi · Verifiche · Fatture ·
# Gestione (utenti e permessi, configurazione, comuni). Tipi di pagamento, aliquote, commerciali, modelli, firme,
# strumenti, email, importazioni, registro e backup stanno in Gestione › Configurazione; i cataloghi DM in una schermata.
CLIENTI = ("Clienti", [
    _v("Clienti", "▤", "/clienti", "anagrafica.vedere"),
    _v("Sedi operative", "⌂", "/sedi", "anagrafica.vedere"),
])


def _gestione(*extra: dict) -> tuple[str, list[dict]]:
    return ("Gestione", [
        _v("Utenti e permessi", "☺︎", "/utenti", "sistema.utenti"),
        _v("Configurazione", "⚙︎", "/configurazione"),
        _v("Comuni (ISTAT)", "⌖", "/comuni", "anagrafica.vedere"),
        *extra,
    ])


MENU_PER_AMBITO = {
    "DPR": [
        CLIENTI,
        ("Impianti", [_v("Impianti", "⚡︎", "/impianti", "anagrafica.vedere"), _v("Tariffario", "€", "/tariffario", "tariffario.vedere")]),
        ("Scadenze", [_v("Scadenze", "◷", "/scadenze", "scadenze.vedere")]),
        ("Preventivi", [_v("Preventivi", "✎", "/preventivi", "preventivi.vedere")]),
        ("Verifiche", [_v("Verifiche", "✓", "/verifiche", "verifiche.vedere_proprie"), _v("Verbali", "✎", "/verbali", "verifiche.vedere_proprie")]),
        ("Fatture", [_v("Fatture e incassi", "▧", "/fatture", "fatture.vedere"), _v("Scadenze di pagamento", "◷", "/scadenze-pagamento", "incassi.vedere")]),
        _gestione(),
    ],
    "DM": [
        CLIENTI,
        ("Attrezzature", [
            _v("Attrezzature GVR", "▦", "/attrezzature-gvr", "beni.vedere"),   # 0.12.10 (doc. 30): due elenchi distinti
            _v("Attrezzature SC/SP", "▤", "/attrezzature-scsp", "beni.vedere"),
            _v("Accessori · PSV", "◎", "/valvole-sicurezza", "beni.vedere"),
            # 0.16 (Federico, 12/10/2026, 18:05): «Tipi e tariffe» è configurazione → Gestione › Configurazione
        ]),
        ("Scadenze", [_v("Scadenze", "◷", "/scadenze-tecniche", "scadenze.vedere")]),
        ("Preventivi", [_v("Preventivi", "✎", "/preventivi-dm", "preventivi.vedere")]),
        ("Verifiche", [_v("Verifiche GVR", "✓", "/verifiche-gvr", "verifiche.vedere_proprie"),   # 0.12.10 (doc. 30)
                       _v("Verifiche SC/SP", "✓", "/verifiche-scsp", "verifiche.vedere_proprie")]),
        ("Fatture", [_v("Fatture", "▧", "/fatture-dm", "fatture.vedere"),   # 0.12.10 (doc. 30, § 9)
                     _v("Scadenze di pagamento", "◷", "/scadenze-pagamento", "incassi.vedere")]),
        _gestione(),
    ],
    "IEC": [
        CLIENTI,
        ("I&C", [_v("Attività I&C", "▦", None, fase="E")]),
        _gestione(),
    ],
}


# Preferenza di navigazione: non entra nei controlli di autorizzazione o nei documenti.
AMBITI = {"DPR": "AD_DPR", "DM": "AD_DM", "IEC": "I&C S.r.l."}
COOKIE_AMBITO = "gad_ambito"
PERCORSI_DM = {"/ad-dm", "/preventivi-dm", "/righe-preventivi-dm", "/incarichi-dm", "/verifiche-gvr", "/verifiche-scsp", "/fatture-dm", "/attrezzature", "/attrezzature-gvr", "/attrezzature-scsp", "/valvole-sicurezza", "/scadenze-tecniche",
               "/cataloghi", "/firme-dm"}
PERCORSI_DPR = {"/ad-dpr", "/impianti", "/scadenze", "/tariffario", "/preventivi", "/righe-preventivi",
                "/verifiche", "/verbali", "/fatture", "/verbali-importa"}


def _ambito(request: Request) -> str:
    if request.url.path in PERCORSI_DM or request.url.path.startswith("/cataloghi/"):
        return "DM"
    if request.url.path in PERCORSI_DPR:
        return "DPR"
    if request.url.path == "/iec":
        return "IEC"
    preferito = request.cookies.get(COOKIE_AMBITO, "DPR")
    return preferito if preferito in AMBITI else "DPR"


def _cookie_ambito(response, request: Request, ambito: str) -> None:
    response.set_cookie(COOKIE_AMBITO, ambito, max_age=365 * 24 * 3600,
                        httponly=True, samesite="lax", secure=request.url.scheme == "https")


@router.post("/api/ambito-attivo")
def cambia_ambito(request: Request, dati: dict, u: accesso.UtenteCorrente = Depends(utente)):
    ambito = dati.get("ambito")
    if not isinstance(ambito, str) or ambito not in AMBITI:
        raise ErroreUtente("Scegli AD_DPR, AD_DM oppure I&C.")
    if ambito not in _ambiti_di(u):
        raise ErroreUtente(f"Il tuo ruolo non lavora in {AMBITI[ambito]}.")
    response = JSONResponse({"ambito": ambito, "url": {"DPR": "/ad-dpr", "DM": "/ad-dm", "IEC": "/iec"}[ambito]})
    _cookie_ambito(response, request, ambito)
    return response


# Pagine raggiunte da Configurazione o dai cataloghi: il menu evidenzia la voce che le contiene
MADRE = {"/incarichi-dm": "/verifiche-gvr", "/ruoli": "/utenti", "/elenchi": "/configurazione", "/tipi-pagamento": "/configurazione", "/aliquote-iva": "/configurazione", "/termini-esecuzione": "/configurazione",
         "/commerciali": "/configurazione", "/impostazioni-email": "/configurazione", "/destinazioni-documenti": "/configurazione", "/dati-societari": "/configurazione", "/modelli": "/configurazione",
         "/strumenti-misura": "/configurazione", "/firme-dm": "/configurazione", "/firme": "/configurazione",
         "/importa": "/configurazione", "/verbali-importa": "/configurazione", "/registro": "/configurazione", "/backup": "/configurazione"}


def _att(ambito: str) -> str | None:
    """Attività dei permessi tecnici per l'ambito della pagina (R132): I&C non ha ancora ruoli propri."""
    return ambito if ambito in ("DPR", "DM") else None


def _ambiti_di(u: accesso.UtenteCorrente) -> dict:
    """R132: chi ha un ruolo tecnico di una sola attività vede solo quella; ruoli comuni e amministratore tutte."""
    return {k: v for k, v in AMBITI.items() if not u.attivita or k in u.attivita}


def _menu_per(u: accesso.UtenteCorrente, attiva: str, ambito: str) -> list:
    attiva = "/configurazione" if attiva.startswith("/cataloghi") else MADRE.get(attiva, attiva)
    sezioni = []
    for titolo, voci in MENU_PER_AMBITO[ambito]:
        visibili = [v | {"attiva": v.get("url") == attiva} for v in voci if "permesso" not in v or u.puo(v["permesso"], _att(ambito))]
        if visibili:
            sezioni.append({"titolo": titolo, "voci": visibili, "aperta": any(v["attiva"] for v in visibili)})
    return sezioni


def barra_html(u: accesso.UtenteCorrente, percorso: str = "/verbali", ambito: str = "DPR") -> str:
    """rc8 (D3): la barra di NEXUS per pagine che non usano base.html (la pagina del verbale, moduli/verbali/api.py)."""
    ambiti = _ambiti_di(u)
    return templates.get_template("_barra.html").render(
        utente=u, versione=VERSIONE, menu=_menu_per(u, percorso, ambito), ambito=ambito,
        ambiti=ambiti if ambito in ambiti else {ambito: AMBITI[ambito], **ambiti}, ambito_nome=AMBITI[ambito])


def _pagina(request: Request, modello: str, titolo: str, permesso: str | None = None, script: str | None = None,
            sopratitolo: str = "NEXUS", **extra) -> HTMLResponse | RedirectResponse:
    arc = request.app.state.archivio
    try:
        u = accesso.leggi_sessione(arc, request.cookies.get(COOKIE_SESSIONE))
    except NonAutenticato:
        with arc.lettura() as s:
            primo = utenti.primo_avvio_necessario(s)
        return RedirectResponse("/primo-avvio" if primo else "/accesso", status_code=303)
    percorso = request.url.path
    if u.cambio_password_richiesto and percorso != "/profilo":
        return RedirectResponse("/profilo", status_code=303)
    ambito = _ambito(request)
    ambiti = _ambiti_di(u)
    if ambito not in ambiti and request.url.path not in PERCORSI_DM | PERCORSI_DPR:
        ambito = next(iter(ambiti))      # preferenza salvata di un'attività non sua: la prima delle sue
    negato = permesso is not None and not u.puo(permesso, _att(ambito))
    response = templates.TemplateResponse(request, "negato.html" if negato else modello, {
        "utente": u, "csrf": u.csrf, "versione": VERSIONE, "menu": _menu_per(u, percorso, ambito),
        "ambito": ambito, "ambiti": ambiti if ambito in ambiti else {ambito: AMBITI[ambito], **ambiti}, "ambito_nome": AMBITI[ambito],
        "titolo": titolo, "sopratitolo": sopratitolo, "script": None if negato else script, **extra,
    })
    # Un collegamento diretto a un modulo rende coerente la navigazione successiva.
    if request.cookies.get(COOKIE_AMBITO) != ambito:
        _cookie_ambito(response, request, ambito)
    return response


def _pagina_pubblica(request: Request, modello: str, script: str) -> HTMLResponse:
    return templates.TemplateResponse(request, modello, {"versione": VERSIONE, "script": script})


@router.get("/accesso", response_class=HTMLResponse)
def pagina_accesso(request: Request):  # noqa: ANN201
    with request.app.state.archivio.lettura() as s:
        if utenti.primo_avvio_necessario(s):
            return RedirectResponse("/primo-avvio", status_code=303)
    return _pagina_pubblica(request, "accesso.html", "accesso.js")


@router.get("/primo-avvio", response_class=HTMLResponse)
def pagina_primo_avvio(request: Request):  # noqa: ANN201
    with request.app.state.archivio.lettura() as s:
        if not utenti.primo_avvio_necessario(s):
            return RedirectResponse("/accesso", status_code=303)
    return _pagina_pubblica(request, "primo_avvio.html", "accesso.js")


@router.get("/ad-dpr", response_class=HTMLResponse)
@router.get("/ad-dm", response_class=HTMLResponse)
@router.get("/iec", response_class=HTMLResponse)
@router.get("/", response_class=HTMLResponse)
def inizio(request: Request):  # noqa: ANN201
    from ..app import archivio_vuoto

    arc = request.app.state.archivio
    return _pagina(request, "inizio.html", "Benvenuto", script="inizio.js", vuoto=archivio_vuoto(arc), cartella_dati=str(arc.cfg.cartella_dati))


@router.get("/profilo", response_class=HTMLResponse)
def profilo(request: Request):  # noqa: ANN201
    return _pagina(request, "profilo.html", "Il mio profilo", script="profilo.js")


@router.get("/utenti", response_class=HTMLResponse)
def pagina_utenti(request: Request):  # noqa: ANN201
    """0.12.8 (Federico: «i permessi andrebbero gestiti come in VerbalizzAI»): una pagina sola, utenti in alto e
    «Permessi per ruolo» sotto, con i ruoli in colonna e una casella per permesso."""
    return _pagina(request, "utenti.html", "Utenti e permessi", "sistema.utenti", "utenti.js", "GESTIONE")


@router.get("/ruoli", response_class=HTMLResponse)
def pagina_ruoli(request: Request):  # noqa: ANN201
    return RedirectResponse("/utenti#permessi", status_code=303)


@router.get("/configurazione", response_class=HTMLResponse)
def pagina_configurazione(request: Request):  # noqa: ANN201
    """0.12.8: Gestione › Configurazione raccoglie modelli (verbali, preventivi), firme, strumenti di misura, email,
    elenchi di valori, commerciali, importazioni, registro e backup. Ogni riquadro si vede con il suo permesso."""
    return _pagina(request, "configurazione.html", "Configurazione", None, None, "GESTIONE")


@router.get("/strumenti-misura", response_class=HTMLResponse)
def pagina_strumenti(request: Request):  # noqa: ANN201
    """C16 (0.16): strumenti di misura dell'attività scelta (AD_DM, I&C); quelli AD_DPR sono nel registro di VerbalizzAI."""
    return _elenco(request, "Strumenti di misura", "strumenti.vedere", "strumenti.js", [("nuovo", "＋ Nuovo strumento", "strumenti.gestire")],
                   sopratitolo="GESTIONE")


@router.get("/firme", response_class=HTMLResponse)
@router.get("/firme-dm", response_class=HTMLResponse)
def pagina_firme_dm(request: Request):  # noqa: ANN201
    """C16 (0.16) e rc8 (punto 3): una sola pagina per le firme dei verificatori, DPR e DM, con i dati del tecnico.
    «/firme-dm» resta come indirizzo precedente."""
    return _pagina(request, "elenco.html", "Firme dei verificatori", "firme.vedere", "firme_dm.js", "GESTIONE", pulsanti=[], nota="")


@router.get("/cataloghi", response_class=HTMLResponse)
def pagina_cataloghi(request: Request):  # noqa: ANN201
    """0.12.8: i sei cataloghi di Garda in una schermata, con le linguette."""
    return _pagina(request, "cataloghi.html", "Tipi e tariffe", "beni.vedere", "catalogo.js", "GESTIONE", cataloghi=CATALOGHI)


@router.get("/registro", response_class=HTMLResponse)
def pagina_registro(request: Request):  # noqa: ANN201
    return _pagina(request, "registro.html", "Registro operazioni", "sistema.registro", "registro.js", "GESTIONE")


@router.get("/backup", response_class=HTMLResponse)
def pagina_backup(request: Request):  # noqa: ANN201
    return _pagina(request, "backup.html", "Backup e integrità", "sistema.backup", "backup.js", "GESTIONE")


# ---------------------------------------------------------------- versione 0.2.0: anagrafica, tariffario, scadenze


def _elenco(request: Request, titolo: str, permesso: str, script: str, azioni: list[tuple[str, str, str | None]],
            sopratitolo: str = "", nota: str = "") -> HTMLResponse | RedirectResponse:
    """Pagina con una griglia; `azioni` = (id del pulsante, testo, permesso necessario o None)."""
    arc = request.app.state.archivio
    try:
        u = accesso.leggi_sessione(arc, request.cookies.get(COOKIE_SESSIONE))
        pulsanti = [{"id": i, "testo": testo} for i, testo, p in azioni if p is None or u.puo(p)]
    except NonAutenticato:
        pulsanti = []
    sopratitolo = sopratitolo or SOPRATITOLI.get(request.url.path, "NEXUS")
    return _pagina(request, "elenco.html", titolo, permesso, script, sopratitolo, pulsanti=pulsanti, nota=nota)


# Sopratitolo = sezione del menu in cui sta la pagina (R117)
SOPRATITOLI = {"/clienti": "CLIENTI", "/sedi": "CLIENTI", "/commerciali": "CLIENTI", "/impianti": "IMPIANTI", "/tariffario": "IMPIANTI",
               "/scadenze": "SCADENZE", "/preventivi": "PREVENTIVI", "/righe-preventivi": "PREVENTIVI", "/verifiche": "VERIFICHE"}


@router.get("/clienti", response_class=HTMLResponse)
def pagina_clienti(request: Request):  # noqa: ANN201
    return _elenco(request, "Clienti", "anagrafica.vedere", "clienti.js", [("nuovo", "＋ Nuovo cliente", "anagrafica.clienti")])


@router.get("/sedi", response_class=HTMLResponse)
def pagina_sedi(request: Request):  # noqa: ANN201
    return _elenco(request, "Sedi operative", "anagrafica.vedere", "sedi.js", [("nuovo", "＋ Nuova sede", "anagrafica.sedi")])


@router.get("/impianti", response_class=HTMLResponse)
def pagina_impianti(request: Request):  # noqa: ANN201
    return _elenco(request, "Impianti", "anagrafica.vedere", "impianti.js", [("nuovo", "＋ Nuovo impianto", "anagrafica.impianti")])


@router.get("/scadenze", response_class=HTMLResponse)
def pagina_scadenze(request: Request):  # noqa: ANN201
    return _elenco(request, "Scadenze", "scadenze.vedere", "scadenze.js", [("preventiva", "⚡ Preventivo con le selezionate", "preventivi.modifica")],
                   nota="Impianti non dismessi con la prossima verifica (ultima verifica + periodicità − 1 giorno). Clicca sulle righe per "
                        "selezionarle (anche più impianti dello stesso cliente) e premi «⚡ Preventivo»: nuovo preventivo o aggiunta a uno aperto (D19).")


@router.get("/tariffario", response_class=HTMLResponse)
def pagina_tariffario(request: Request):  # noqa: ANN201
    return _elenco(request, "Tariffario", "tariffario.vedere", "tariffario.js",
                   [("prova", "Prova il calcolo", None), ("nuovo", "＋ Nuova voce", "tariffario.gestire")])


@router.get("/commerciali", response_class=HTMLResponse)
def pagina_commerciali(request: Request):  # noqa: ANN201
    return _elenco(request, "Commerciali", "anagrafica.vedere", "commerciali.js", [("nuovo", "＋ Nuovo commerciale", "anagrafica.commerciali")])


@router.get("/elenchi", response_class=HTMLResponse)
def pagina_elenchi(request: Request):  # noqa: ANN201
    return _pagina(request, "elenchi.html", "Elenchi di valori", "sistema.impostazioni", "elenchi.js", "GESTIONE")


@router.get("/importa", response_class=HTMLResponse)
def pagina_importa(request: Request):  # noqa: ANN201
    return _pagina(request, "importa.html", "Importazione dati", "anagrafica.importa", "importa.js", "GESTIONE")


@router.get("/comuni", response_class=HTMLResponse)
def pagina_comuni(request: Request):  # noqa: ANN201
    return _elenco(request, "Comuni (ISTAT)", "anagrafica.vedere", "comuni.js", [("nuovo", "＋ Nuovo comune", "sistema.impostazioni")],
                   sopratitolo="GESTIONE", nota="Elenco ISTAT usato per compilare comune, CAP, provincia e regione. Si possono correggere i dati, "
                   "aggiungere comuni nuovi e togliere dall'elenco quelli soppressi (non vengono più proposti, le schede che li usano restano come sono).")


@router.get("/verifiche", response_class=HTMLResponse)
def pagina_verifiche(request: Request):  # noqa: ANN201
    return _elenco(request, "Verifiche", "verifiche.vedere_proprie", "verifiche.js", [],
                   nota="Le verifiche nascono dalle righe accettate dei preventivi dopo il riesame del contratto conforme. Percorso: da assegnare "
                        "(il RT sceglie il verificatore) → programmata (data prevista, facoltativa) → registrata (prende il numero del verbale) → "
                        "eseguita (quando il verbale compilato qui viene emesso) → riesaminata dal RT (da fatturare).")


@router.get("/preventivi", response_class=HTMLResponse)
def pagina_preventivi(request: Request):  # noqa: ANN201
    return _elenco(request, "Preventivi", "preventivi.vedere", "preventivi.js", [("nuovo", "＋ Nuovo preventivo", "preventivi.modifica")])


@router.get("/righe-preventivi", response_class=HTMLResponse)
def pagina_righe(request: Request):  # noqa: ANN201
    return _elenco(request, "Righe dei preventivi", "preventivi.vedere", "righe_preventivi.js", [],
                   nota="Una riga per impianto preventivato, con lo stato di accettazione e la verifica. Dalle righe accettate (dopo il "
                        "riesame del contratto conforme) si affida la verifica: spunta le righe e premi «Affida le selezionate…».")


@router.get("/righe-preventivi-dm", response_class=HTMLResponse)
def pagina_righe_dm(request: Request):  # noqa: ANN201
    return _elenco(request, "Righe dei preventivi", "preventivi.vedere", "righe_preventivi.js", [], sopratitolo="PREVENTIVI",
                   nota="Una riga per attrezzatura preventivata. Dalle righe accettate (dopo il riesame del contratto conforme) "
                        "si affida l'incarico: spunta le righe e premi «Affida le selezionate…».")


@router.get("/impostazioni-email", response_class=HTMLResponse)
def pagina_email(request: Request):  # noqa: ANN201
    return _pagina(request, "impostazioni_email.html", "Impostazioni email", "sistema.impostazioni", "impostazioni_email.js", "GESTIONE")


@router.get("/dati-societari", response_class=HTMLResponse)
def pagina_dati_societari(request: Request):  # noqa: ANN201
    """rc8 (punto 6, decisione del 14/10/2026): dati fiscali della società emittente, modalità di pagamento e regole
    generali delle scadenze in Configurazione (prima erano pulsanti della pagina Fatture)."""
    return _pagina(request, "impostazioni_email.html", "Dati della società e pagamenti", "sistema.impostazioni", "dati_societari.js", "GESTIONE")


@router.get("/destinazioni-documenti", response_class=HTMLResponse)
def pagina_destinazioni(request: Request):  # noqa: ANN201
    """rc8 (punto 5, D2): cartelle del server in cui NEXUS salva una copia dei documenti definitivi, per categoria."""
    return _pagina(request, "impostazioni_email.html", "Destinazioni dei documenti", "sistema.impostazioni", "destinazioni.js", "GESTIONE")


@router.get("/modelli", response_class=HTMLResponse)
def pagina_modelli(request: Request):  # noqa: ANN201
    return _pagina(request, "modelli.html", "Modelli Word", "sistema.modelli", "modelli.js", "GESTIONE")


@router.get("/fatture", response_class=HTMLResponse)
def pagina_fatture(request: Request):
    return _pagina(request, "finanza.html", "Fatture e incassi", "fatture.vedere", "finanza.js")


@router.get("/scadenze-pagamento", response_class=HTMLResponse)
def pagina_scadenze_pagamento(request: Request):
    """0.14: rate delle fatture emesse con stato e residuo (Garda «pagamenti»), per l'attività scelta in alto."""
    return _elenco(request, "Scadenze di pagamento", "incassi.vedere", "scadenze_pagamento.js", [], "FATTURE",
                   "Una riga per rata. Gli incassi coprono le rate in ordine di scadenza; il clic apre la fattura.")


@router.get("/fatture-dm", response_class=HTMLResponse)
def pagina_fatture_dm(request: Request):
    return _pagina(request, "finanza.html", "Fatture e incassi AD_DM", "fatture.vedere", "finanza.js", "FATTURE")


@router.get("/beni", response_class=HTMLResponse)
def pagina_beni(request: Request):
    """Vecchio indirizzo del parco (fino alla 0.12.4): porta ad «Attrezzature», conservando ?scheda=."""
    return RedirectResponse("/attrezzature" + (f"?{request.url.query}" if request.url.query else ""), status_code=303)


@router.get("/attrezzature", response_class=HTMLResponse)
def pagina_attrezzature(request: Request):
    return _pagina(request, "beni.html", "Attrezzature", "beni.vedere", "beni.js", "ATTREZZATURE",
                   griglia="attrezzature", nuovo_testo="＋ Nuova attrezzatura")


@router.get("/attrezzature-gvr", response_class=HTMLResponse)
def pagina_attrezzature_gvr(request: Request):
    return _pagina(request, "beni.html", "Attrezzature GVR", "beni.vedere", "beni.js", "ATTREZZATURE",
                   griglia="attrezzature_gvr", gruppo="GVR", nuovo_testo="＋ Nuova attrezzatura GVR")


@router.get("/attrezzature-scsp", response_class=HTMLResponse)
def pagina_attrezzature_scsp(request: Request):
    return _pagina(request, "beni.html", "Attrezzature SC/SP", "beni.vedere", "beni.js", "ATTREZZATURE",
                   griglia="attrezzature_scsp", gruppo="SCSP", nuovo_testo="＋ Nuova attrezzatura SC/SP")


@router.get("/valvole-sicurezza", response_class=HTMLResponse)
def pagina_valvole(request: Request):
    return _pagina(request, "beni.html", "Accessori · PSV", "beni.vedere", "beni.js", "ATTREZZATURE",
                   griglia="valvole", gruppo="PSV", nuovo_testo="＋ Nuovo accessorio (PSV)")


CATALOGHI = {
    "tipi-attrezzature": ("cat_tipi_attrezzature", "Tipi di attrezzature"),
    "tipi-gvr": ("cat_tipi_gvr", "Tipi attrezzature GVR"),
    "id-specifiche": ("cat_id_specifiche", "ID specifiche"),
    "compatibilita": ("cat_compatibilita", "Tipi attr. / ID specifiche"),
    "tariffe-scsp": ("cat_tariffe_scsp", "Tariffe SC/SP"),
    "tariffe-gvr": ("cat_tariffe_gvr", "Tariffe GVR"),
}


@router.get("/cataloghi/{nome}", response_class=HTMLResponse)
def pagina_catalogo(request: Request, nome: str):
    if nome not in CATALOGHI:
        return RedirectResponse("/cataloghi", status_code=303)
    return RedirectResponse(f"/cataloghi?scheda={nome}", status_code=303)


@router.get("/tipi-pagamento", response_class=HTMLResponse)
def pagina_tipi_pagamento(request: Request):
    return _pagina(request, "elenchi.html", "Tipi di pagamento", "sistema.impostazioni", "elenchi.js", "CLIENTI", solo="modalita_pagamento")


@router.get("/termini-esecuzione", response_class=HTMLResponse)
def pagina_termini(request: Request):
    return _pagina(request, "elenchi.html", "Termini di esecuzione", "sistema.impostazioni", "elenchi.js", "CLIENTI", solo="termine_esecuzione")


@router.get("/aliquote-iva", response_class=HTMLResponse)
def pagina_aliquote(request: Request):
    return _pagina(request, "elenchi.html", "Aliquote IVA", "sistema.impostazioni", "elenchi.js", "CLIENTI", solo="aliquota_iva")


@router.get("/scadenze-tecniche", response_class=HTMLResponse)
def pagina_date_tecniche(request: Request):
    return _elenco(request, "Scadenze", "scadenze.vedere", "scadenze_dm.js", [], sopratitolo="SCADENZE",
                   nota="Una riga per attività (funzionamento, integrità, visita interna, CND, SC/SP, supplementare, taratura) di ogni "
                        "attrezzatura o accessorio non dismesso. Clic sulla riga: scheda dell'attrezzatura.")


@router.get("/preventivi-dm", response_class=HTMLResponse)
def pagina_preventivi_dm(request: Request):
    return _elenco(request, "Preventivi", "preventivi.vedere", "preventivi.js", [("nuovo", "＋ Nuovo preventivo DM", "preventivi.modifica")],
                   sopratitolo="PREVENTIVI", nota="Cliente e sede operativa in testata; attrezzature della sede nelle righe. Incarichi generati dopo accettazione e riesame conforme.")


@router.get("/incarichi-dm", response_class=HTMLResponse)
def pagina_incarichi_dm(request: Request):
    return _pagina(request, "incarichi_dm.html", "Verifiche", "verifiche.vedere_proprie", "incarichi_dm.js", "VERIFICHE",
                   griglia="incarichi_dm")


@router.get("/verifiche-gvr", response_class=HTMLResponse)
def pagina_verifiche_gvr(request: Request):
    return _pagina(request, "incarichi_dm.html", "Verifiche GVR", "verifiche.vedere_proprie", "incarichi_dm.js", "VERIFICHE",
                   griglia="incarichi_gvr")


@router.get("/verifiche-scsp", response_class=HTMLResponse)
def pagina_verifiche_scsp(request: Request):
    return _pagina(request, "incarichi_dm.html", "Verifiche SC/SP", "verifiche.vedere_proprie", "incarichi_dm.js", "VERIFICHE",
                   griglia="incarichi_scsp")
