"""Archivio documentale DPR nel medesimo PostgreSQL di NEXUS.

I testi JSON e le date ISO sono conservati senza conversioni: il backup
VerbalizzAI resta verificabile e reimportabile senza cambiare identificatori.
"""
import sqlalchemy as sa
from alembic import op

revision = "0029"
down_revision = "0028"
branch_labels = None
depends_on = None


def upgrade():
    if op.get_bind().dialect.name != "postgresql":
        return
    op.execute(sa.text("CREATE SCHEMA verbali"))
    op.execute(sa.text("""CREATE TABLE verbali.meta (
        key text PRIMARY KEY, value text NOT NULL)"""))
    op.execute(sa.text("""CREATE TABLE verbali.objects (
        id text PRIMARY KEY, kind text NOT NULL, data text NOT NULL,
        revision integer NOT NULL CHECK (revision > 0), updated_at text NOT NULL,
        updated_by text NOT NULL DEFAULT '')"""))
    op.execute(sa.text("""CREATE TABLE verbali.documents (
        sha text PRIMARY KEY, filename text NOT NULL, data bytea NOT NULL,
        created_at text NOT NULL, CONSTRAINT sha256_documento CHECK (length(sha) = 64))"""))
    op.execute(sa.text("""CREATE TABLE verbali.events (
        id text PRIMARY KEY, object_id text NOT NULL, action text NOT NULL,
        previous text, created_at text NOT NULL, "user" text NOT NULL DEFAULT '')"""))
    # Solo storico della copia standalone: l'accesso attivo resta in utenti NEXUS.
    op.execute(sa.text("""CREATE TABLE verbali.users (
        username text PRIMARY KEY, name text NOT NULL, role text NOT NULL,
        salt text NOT NULL, hash text NOT NULL, active integer NOT NULL,
        created_at text NOT NULL)"""))
    op.execute(sa.text("CREATE INDEX object_kind ON verbali.objects (kind)"))
    op.execute(sa.text("CREATE INDEX ev_obj ON verbali.events (object_id, created_at)"))
    for name, key in (("obj_plant", "plant_id"), ("obj_source", "source_sha"),
                      ("obj_insp", "inspection_id")):
        op.execute(sa.text(f"CREATE INDEX {name} ON verbali.objects (kind, ((data::jsonb ->> '{key}')))"))


def downgrade():
    if op.get_bind().dialect.name == "postgresql":
        raise RuntimeError("Non eliminare i verbali: ripristinare una copia precedente del database.")
