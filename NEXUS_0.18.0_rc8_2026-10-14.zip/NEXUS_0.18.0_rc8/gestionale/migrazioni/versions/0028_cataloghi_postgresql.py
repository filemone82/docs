"""Recupera cataloghi e tariffe omessi dalla baseline PostgreSQL 0027.

Snapshot congelato dei dati inseriti dalle migrazioni SQLite 0011 e 0012.
Non aggiorna le tariffe personalizzate né le descrizioni già presenti.
"""
import json
from pathlib import Path

from alembic import op
import sqlalchemy as sa

revision = "0028"
down_revision = "0027"
branch_labels = None
depends_on = None

IDENTITA = {
    "cls_tipi_attrezzature_gvr": ("codice",),
    "cls_tipi_attrezzature": ("gruppo", "codice", "famiglia_gvr_id"),
    "cls_id_specifiche": ("gruppo", "codice"),
    "cls_tipi_attr_id_specifiche": ("gruppo", "tipo_attr_id", "famiglia_gvr_id", "id_spec_id"),
    "dm_tariffe": ("gruppo", "id_spec_id", "compatibilita_id", "tipo"),
}


def integra(conn):
    dati = json.loads(Path(__file__).with_name("0028_cataloghi_dm.json").read_text(encoding="utf-8"))
    meta = sa.MetaData()
    for nome, righe in dati.items():
        tabella = sa.Table(nome, meta, autoload_with=conn)
        presenti = {r["id"]: r for r in conn.execute(sa.select(tabella)).mappings()}
        for riga in righe:
            if riga["id"] in presenti and any(presenti[riga["id"]][c] != riga[c] for c in IDENTITA[nome]):
                raise RuntimeError(f"Catalogo {nome}, ID {riga['id']}: identità diversa dallo snapshot; aggiornamento annullato.")
        mancanti = [r for r in righe if r["id"] not in presenti]
        if mancanti:
            conn.execute(tabella.insert(), mancanti)
        if conn.dialect.name == "postgresql":
            # Gli ID importati sono espliciti: avanzare la sequenza senza arretrarla.
            sequenza = conn.scalar(sa.text("SELECT pg_get_serial_sequence(:tabella, 'id')"), {"tabella": nome})
            if sequenza:
                ultimo = conn.scalar(sa.text("""SELECT last_value FROM pg_sequences
                    WHERE to_regclass(format('%I.%I', schemaname, sequencename)) = CAST(:seq AS regclass)"""),
                    {"seq": sequenza})
                massimo = conn.scalar(sa.select(sa.func.max(tabella.c.id))) or 1
                conn.execute(sa.text("SELECT setval(CAST(:seq AS regclass), :valore, true)"),
                             {"seq": sequenza, "valore": max(massimo, ultimo or 1)})


def upgrade():
    conn = op.get_bind()
    if conn.dialect.name == "postgresql":
        # I testi Garda arrivano fino a 36 caratteri. La baseline 0027
        # conservava il vecchio limite SQLite di 20 (non applicato da SQLite).
        # Adeguare la colonna prima del caricamento, senza troncare i valori.
        for nome in ("tipo_ver_gvr_1", "tipo_ver_gvr_2", "tipo_ver_gvr_3"):
            op.alter_column("cls_tipi_attrezzature", nome,
                            existing_type=sa.String(length=20), type_=sa.Text(), existing_nullable=True)
        integra(conn)


def downgrade():
    if op.get_bind().dialect.name == "postgresql":
        raise RuntimeError("Ripristinare il backup pre-aggiornamento: i cataloghi possono essere referenziati dai dati operativi.")
