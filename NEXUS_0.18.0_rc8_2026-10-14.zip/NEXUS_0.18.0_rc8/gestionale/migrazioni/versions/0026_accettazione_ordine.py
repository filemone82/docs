"""NEXUS 0.16: accettazione e ordine del cliente sul preventivo (R138)

Revisione: 0026
Precedente: 0025
Creata il: 2026-10-12

Federico, 12/10/2026, 17:19 e 17:28: caricare il PDF del preventivo accettato / dell'ordine e registrare i dati per la
fattura elettronica come la linguetta «Fattura» di Garda.
- `preventivi.documenti_collegati`: tipo doc. (ordine, contratto, convenzione, ricezione, fattura collegata, DDT,
  fattura principale), numero, data, CIG, CUP, commessa/convenzione. Vuoto per i preventivi esistenti: il riferimento
  all'ordine già scritto (`rif_ordine`) resta e continua a passare in fattura come prima.
- `preventivi_allegati`: file dell'accettazione o dell'ordine (nell'archivio documenti, con impronta).
"""

import sqlalchemy as sa
from alembic import op

revision = '0026'
down_revision = '0025'
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table('preventivi') as b:
        b.add_column(sa.Column('documenti_collegati', sa.Text(), nullable=False, server_default='[]'))
    op.create_table(
        'preventivi_allegati',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('preventivo_id', sa.Integer(), sa.ForeignKey('preventivi.id', name=op.f('fk_preventivi_allegati_preventivo_id_preventivi'), ondelete='RESTRICT'), nullable=False),
        sa.Column('documento_id', sa.Integer(), sa.ForeignKey('documenti.id', name=op.f('fk_preventivi_allegati_documento_id_documenti'), ondelete='RESTRICT'), nullable=False),
        sa.Column('tipo', sa.String(20), nullable=False),
        sa.Column('nome_file', sa.String(255), nullable=False),
        sa.Column('descrizione', sa.String(300), nullable=False),
        sa.Column('rimosso', sa.Boolean(), nullable=False, server_default='0'),
        sa.Column('rimosso_il', sa.DateTime(), nullable=True),
        sa.Column('rimosso_da', sa.String(120), nullable=False, server_default=''),
        sa.Column('creato_il', sa.DateTime(), nullable=False),
        sa.Column('creato_da', sa.String(120), nullable=False),
        sa.CheckConstraint("tipo IN ('accettazione','ordine','email','altro')", name=op.f('ck_preventivi_allegati_tipo')),
    )
    op.create_index('ix_preventivi_allegati_preventivo_id', 'preventivi_allegati', ['preventivo_id'])


def downgrade() -> None:
    op.drop_index('ix_preventivi_allegati_preventivo_id', 'preventivi_allegati')
    op.drop_table('preventivi_allegati')
    with op.batch_alter_table('preventivi') as b:
        b.drop_column('documenti_collegati')
