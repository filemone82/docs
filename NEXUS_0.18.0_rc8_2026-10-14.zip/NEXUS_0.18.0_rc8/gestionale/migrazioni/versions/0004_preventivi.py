"""Preventivi, riesami, documenti e invii, modelli Word, termine di esecuzione del cliente (versione 0.3.0)

Revisione: 0004
Precedente: 0003
Creata il: 2026-10-04 21:45:07.573075
"""

from alembic import op
import sqlalchemy as sa


revision = '0004'
down_revision = '0003'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table('modelli_documento',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('tipo', sa.String(length=30), nullable=False),
    sa.Column('codice', sa.String(length=60), nullable=False),
    sa.Column('revisione', sa.String(length=20), nullable=False),
    sa.Column('descrizione', sa.Text(), nullable=False),
    sa.Column('documento_id', sa.Integer(), nullable=False),
    sa.Column('in_uso', sa.Boolean(), nullable=False),
    sa.Column('caricato_il', sa.DateTime(), nullable=False),
    sa.Column('caricato_da', sa.String(length=120), nullable=False),
    sa.ForeignKeyConstraint(['documento_id'], ['documenti.id'], name=op.f('fk_modelli_documento_documento_id_documenti'), ondelete='RESTRICT'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_modelli_documento'))
    )
    with op.batch_alter_table('modelli_documento', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_modelli_documento_tipo'), ['tipo'], unique=False)

    op.create_table('preventivi',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('anno', sa.Integer(), nullable=False),
    sa.Column('numero', sa.Integer(), nullable=False),
    sa.Column('revisione', sa.Integer(), nullable=False),
    sa.Column('codice', sa.String(length=30), nullable=False),
    sa.Column('data', sa.Date(), nullable=False),
    sa.Column('cliente_id', sa.Integer(), nullable=False),
    sa.Column('commerciale_id', sa.Integer(), nullable=True),
    sa.Column('modalita_pagamento', sa.String(length=200), nullable=False),
    sa.Column('termine_esecuzione', sa.String(length=300), nullable=False),
    sa.Column('stato', sa.String(length=30), nullable=False),
    sa.Column('inviato_il', sa.DateTime(), nullable=True),
    sa.Column('rif_ordine', sa.String(length=120), nullable=False),
    sa.Column('data_ordine', sa.Date(), nullable=True),
    sa.Column('motivo_annullamento', sa.String(length=500), nullable=False),
    sa.Column('revisione_di_id', sa.Integer(), nullable=True),
    sa.Column('note', sa.Text(), nullable=False),
    sa.Column('totale_standard', sa.Integer(), nullable=False),
    sa.Column('totale', sa.Integer(), nullable=False),
    sa.Column('versione', sa.Integer(), nullable=False),
    sa.Column('creato_il', sa.DateTime(), nullable=False),
    sa.Column('creato_da', sa.String(length=120), nullable=False),
    sa.Column('modificato_il', sa.DateTime(), nullable=False),
    sa.Column('modificato_da', sa.String(length=120), nullable=False),
    sa.CheckConstraint("stato IN ('creato', 'inviato', 'accettato_parzialmente', 'accettato_totalmente', 'rifiutato', 'annullato', 'sostituito')", name=op.f('ck_preventivi_stato')),
    sa.ForeignKeyConstraint(['cliente_id'], ['clienti.id'], name=op.f('fk_preventivi_cliente_id_clienti'), ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['commerciale_id'], ['commerciali.id'], name=op.f('fk_preventivi_commerciale_id_commerciali'), ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['revisione_di_id'], ['preventivi.id'], name=op.f('fk_preventivi_revisione_di_id_preventivi'), ondelete='RESTRICT'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_preventivi')),
    sa.UniqueConstraint('anno', 'numero', 'revisione', name=op.f('uq_preventivi_anno'))
    )
    with op.batch_alter_table('preventivi', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_preventivi_anno'), ['anno'], unique=False)
        batch_op.create_index(batch_op.f('ix_preventivi_cliente_id'), ['cliente_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_preventivi_codice'), ['codice'], unique=False)
        batch_op.create_index(batch_op.f('ix_preventivi_stato'), ['stato'], unique=False)

    op.create_table('preventivi_documenti',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('preventivo_id', sa.Integer(), nullable=False),
    sa.Column('formato', sa.String(length=10), nullable=False),
    sa.Column('documento_id', sa.Integer(), nullable=False),
    sa.Column('modello_id', sa.Integer(), nullable=True),
    sa.Column('nome_file', sa.String(length=255), nullable=False),
    sa.Column('creato_il', sa.DateTime(), nullable=False),
    sa.Column('creato_da', sa.String(length=120), nullable=False),
    sa.ForeignKeyConstraint(['documento_id'], ['documenti.id'], name=op.f('fk_preventivi_documenti_documento_id_documenti'), ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['modello_id'], ['modelli_documento.id'], name=op.f('fk_preventivi_documenti_modello_id_modelli_documento'), ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['preventivo_id'], ['preventivi.id'], name=op.f('fk_preventivi_documenti_preventivo_id_preventivi'), ondelete='RESTRICT'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_preventivi_documenti'))
    )
    with op.batch_alter_table('preventivi_documenti', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_preventivi_documenti_preventivo_id'), ['preventivo_id'], unique=False)

    op.create_table('preventivi_invii',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('preventivo_id', sa.Integer(), nullable=False),
    sa.Column('destinatari', sa.String(length=1000), nullable=False),
    sa.Column('copia', sa.String(length=1000), nullable=False),
    sa.Column('oggetto', sa.String(length=300), nullable=False),
    sa.Column('testo', sa.Text(), nullable=False),
    sa.Column('allegati', sa.Text(), nullable=False),
    sa.Column('esito', sa.String(length=300), nullable=False),
    sa.Column('inviato_il', sa.DateTime(), nullable=False),
    sa.Column('inviato_da', sa.String(length=120), nullable=False),
    sa.ForeignKeyConstraint(['preventivo_id'], ['preventivi.id'], name=op.f('fk_preventivi_invii_preventivo_id_preventivi'), ondelete='RESTRICT'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_preventivi_invii'))
    )
    with op.batch_alter_table('preventivi_invii', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_preventivi_invii_preventivo_id'), ['preventivo_id'], unique=False)

    op.create_table('preventivi_riesami',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('preventivo_id', sa.Integer(), nullable=False),
    sa.Column('esito', sa.String(length=20), nullable=False),
    sa.Column('requisiti_chiari', sa.Boolean(), nullable=False),
    sa.Column('competenza_strumenti', sa.Boolean(), nullable=False),
    sa.Column('imparzialita', sa.Boolean(), nullable=False),
    sa.Column('tempi', sa.Boolean(), nullable=False),
    sa.Column('note', sa.Text(), nullable=False),
    sa.Column('eseguito_il', sa.DateTime(), nullable=False),
    sa.Column('eseguito_da', sa.String(length=120), nullable=False),
    sa.ForeignKeyConstraint(['preventivo_id'], ['preventivi.id'], name=op.f('fk_preventivi_riesami_preventivo_id_preventivi'), ondelete='RESTRICT'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_preventivi_riesami'))
    )
    with op.batch_alter_table('preventivi_riesami', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_preventivi_riesami_preventivo_id'), ['preventivo_id'], unique=False)

    op.create_table('preventivi_righe',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('preventivo_id', sa.Integer(), nullable=False),
    sa.Column('ordine', sa.Integer(), nullable=False),
    sa.Column('impianto_id', sa.Integer(), nullable=False),
    sa.Column('tipo_verifica', sa.String(length=20), nullable=False),
    sa.Column('sede_nome', sa.String(length=300), nullable=False),
    sa.Column('sede_indirizzo', sa.String(length=200), nullable=False),
    sa.Column('sede_comune', sa.String(length=160), nullable=False),
    sa.Column('tipologia', sa.String(length=80), nullable=False),
    sa.Column('descrizione', sa.String(length=200), nullable=False),
    sa.Column('tariffa_standard', sa.Integer(), nullable=False),
    sa.Column('dettaglio_tariffa', sa.Text(), nullable=False),
    sa.Column('sconto', sa.Integer(), nullable=False),
    sa.Column('tariffa_applicata', sa.Integer(), nullable=False),
    sa.Column('stato', sa.String(length=20), nullable=False),
    sa.Column('stato_il', sa.DateTime(), nullable=True),
    sa.Column('stato_da', sa.String(length=120), nullable=False),
    sa.Column('note', sa.String(length=500), nullable=False),
    sa.CheckConstraint("stato IN ('in_attesa', 'accettata', 'rifiutata', 'annullata')", name=op.f('ck_preventivi_righe_stato')),
    sa.CheckConstraint("tipo_verifica IN ('periodica', 'straordinaria')", name=op.f('ck_preventivi_righe_tipo_verifica')),
    sa.CheckConstraint('sconto >= 0 AND sconto <= 10000', name=op.f('ck_preventivi_righe_sconto')),
    sa.ForeignKeyConstraint(['impianto_id'], ['impianti.id'], name=op.f('fk_preventivi_righe_impianto_id_impianti'), ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['preventivo_id'], ['preventivi.id'], name=op.f('fk_preventivi_righe_preventivo_id_preventivi'), ondelete='CASCADE'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_preventivi_righe'))
    )
    with op.batch_alter_table('preventivi_righe', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_preventivi_righe_impianto_id'), ['impianto_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_preventivi_righe_preventivo_id'), ['preventivo_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_preventivi_righe_stato'), ['stato'], unique=False)

    # ADD COLUMN semplice: la tabella clienti non va ricreata (è richiamata da sedi e preventivi)
    op.add_column('clienti', sa.Column('termine_esecuzione', sa.String(length=300), server_default='', nullable=False))



def downgrade() -> None:
    op.drop_column('clienti', 'termine_esecuzione')

    with op.batch_alter_table('preventivi_righe', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_preventivi_righe_stato'))
        batch_op.drop_index(batch_op.f('ix_preventivi_righe_preventivo_id'))
        batch_op.drop_index(batch_op.f('ix_preventivi_righe_impianto_id'))

    op.drop_table('preventivi_righe')
    with op.batch_alter_table('preventivi_riesami', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_preventivi_riesami_preventivo_id'))

    op.drop_table('preventivi_riesami')
    with op.batch_alter_table('preventivi_invii', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_preventivi_invii_preventivo_id'))

    op.drop_table('preventivi_invii')
    with op.batch_alter_table('preventivi_documenti', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_preventivi_documenti_preventivo_id'))

    op.drop_table('preventivi_documenti')
    with op.batch_alter_table('preventivi', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_preventivi_stato'))
        batch_op.drop_index(batch_op.f('ix_preventivi_codice'))
        batch_op.drop_index(batch_op.f('ix_preventivi_cliente_id'))
        batch_op.drop_index(batch_op.f('ix_preventivi_anno'))

    op.drop_table('preventivi')
    with op.batch_alter_table('modelli_documento', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_modelli_documento_tipo'))

    op.drop_table('modelli_documento')
