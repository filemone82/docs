"""incarichi DM assegnazione bozza registrazione

Revisione: 0013
Precedente: 0012
Creata il: 2026-10-09 20:33:44.432695
"""

from alembic import op
import sqlalchemy as sa


revision = '0013'
down_revision = '0012'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table('dm_contatori',
    sa.Column('gruppo', sa.String(length=8), nullable=False),
    sa.Column('anno', sa.Integer(), nullable=False),
    sa.Column('ultimo', sa.Integer(), nullable=False),
    sa.CheckConstraint("gruppo IN ('GVR','SC-SP')", name=op.f('ck_dm_contatori_gruppo')),
    sa.PrimaryKeyConstraint('gruppo', 'anno', name=op.f('pk_dm_contatori'))
    )
    with op.batch_alter_table('dm_incarichi', schema=None) as batch_op:
        batch_op.drop_constraint(op.f('ck_dm_incarichi_stato'), type_='check')
        batch_op.create_check_constraint('stato', "stato IN ('da_assegnare','assegnata','programmata','registrata','sospesa','annullata')")
        batch_op.add_column(sa.Column('verificatore_id', sa.Integer(), nullable=True))
        batch_op.add_column(sa.Column('assegnata_il', sa.DateTime(), nullable=True))
        batch_op.add_column(sa.Column('assegnata_da', sa.String(length=120), server_default='', nullable=False))
        batch_op.add_column(sa.Column('data_programmata', sa.Date(), nullable=True))
        batch_op.add_column(sa.Column('indipendenza', sa.Boolean(), server_default='1', nullable=False))
        batch_op.add_column(sa.Column('bozza_json', sa.Text(), server_default='{}', nullable=False))
        batch_op.add_column(sa.Column('bozza_salvata', sa.Boolean(), server_default='0', nullable=False))
        batch_op.add_column(sa.Column('gruppo_contatore', sa.String(length=8), nullable=True))
        batch_op.add_column(sa.Column('anno', sa.Integer(), nullable=True))
        batch_op.add_column(sa.Column('numero', sa.Integer(), nullable=True))
        batch_op.add_column(sa.Column('codice_verbale', sa.String(length=30), server_default='', nullable=False))
        batch_op.add_column(sa.Column('data_rilascio', sa.Date(), nullable=True))
        batch_op.add_column(sa.Column('data_pvp', sa.Date(), nullable=True))
        batch_op.add_column(sa.Column('contributo', sa.Integer(), server_default='0', nullable=False))
        batch_op.add_column(sa.Column('stato_prima_sospensione', sa.String(length=20), server_default='', nullable=False))
        batch_op.add_column(sa.Column('motivo_sospensione', sa.Text(), server_default='', nullable=False))
        batch_op.add_column(sa.Column('motivo_annullamento', sa.Text(), server_default='', nullable=False))
        batch_op.create_index(batch_op.f('ix_dm_incarichi_verificatore_id'), ['verificatore_id'], unique=False)
        batch_op.create_unique_constraint('uq_dm_incarichi_numero', ['gruppo_contatore', 'anno', 'numero'])
        batch_op.create_foreign_key(batch_op.f('fk_dm_incarichi_verificatore_id_utenti'), 'utenti', ['verificatore_id'], ['id'], ondelete='RESTRICT')

    # ### end Alembic commands ###


def downgrade() -> None:
    conn = op.get_bind()
    if conn.execute(sa.text("SELECT 1 FROM dm_incarichi WHERE stato<>'da_assegnare' OR bozza_json<>'{}' LIMIT 1")).first() or conn.execute(sa.text("SELECT 1 FROM dm_contatori LIMIT 1")).first():
        raise RuntimeError("Ritorno alla 0.10 impedito: dati tecnici DM presenti. Ripristinare un backup della 0.10 in un archivio separato.")
    with op.batch_alter_table('dm_incarichi', schema=None) as batch_op:
        batch_op.drop_constraint(op.f('ck_dm_incarichi_stato'), type_='check')
        batch_op.create_check_constraint('stato', "stato='da_assegnare'")
        batch_op.drop_constraint(batch_op.f('fk_dm_incarichi_verificatore_id_utenti'), type_='foreignkey')
        batch_op.drop_constraint('uq_dm_incarichi_numero', type_='unique')
        batch_op.drop_index(batch_op.f('ix_dm_incarichi_verificatore_id'))
        batch_op.drop_column('motivo_annullamento')
        batch_op.drop_column('motivo_sospensione')
        batch_op.drop_column('stato_prima_sospensione')
        batch_op.drop_column('contributo')
        batch_op.drop_column('data_pvp')
        batch_op.drop_column('data_rilascio')
        batch_op.drop_column('codice_verbale')
        batch_op.drop_column('numero')
        batch_op.drop_column('anno')
        batch_op.drop_column('gruppo_contatore')
        batch_op.drop_column('bozza_salvata')
        batch_op.drop_column('bozza_json')
        batch_op.drop_column('indipendenza')
        batch_op.drop_column('data_programmata')
        batch_op.drop_column('assegnata_da')
        batch_op.drop_column('assegnata_il')
        batch_op.drop_column('verificatore_id')

    op.drop_table('dm_contatori')
    # ### end Alembic commands ###
