"""Comuni: indicatore «attivo» per togliere dall'elenco i comuni soppressi (D49, versione 0.2.2)

Revisione: 0003
Precedente: 0002
"""

import sqlalchemy as sa
from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ADD COLUMN semplice, SENZA ricreare la tabella: clienti e sedi la richiamano con «ON DELETE SET NULL»
    # e ricrearla (modalità batch) cancellerebbe il collegamento al comune di tutte le schede.
    op.add_column("comuni", sa.Column("attivo", sa.Boolean(), nullable=False, server_default="1"))


def downgrade() -> None:
    with op.batch_alter_table("comuni", schema=None) as batch_op:
        batch_op.drop_column("attivo")
