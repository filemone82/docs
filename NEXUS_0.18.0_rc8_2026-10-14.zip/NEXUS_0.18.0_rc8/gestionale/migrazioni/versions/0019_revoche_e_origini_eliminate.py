"""revoche dell'accettazione delle righe (R124) e origini di oggetti eliminati (AD-REV-005)

Revisione: 0019
Precedente: 0018
Creata il: 2026-10-11

- `preventivi_righe_revoche`: ogni revoca dell'accettazione di una riga di preventivo, con motivo, autore, data,
  stato precedente e la verifica (DPR) o l'incarico (DM) annullati insieme. Nessuna revoca sovrascrive la precedente.
- `origini.eliminato_il`: quando un oggetto importato viene eliminato la sua corrispondenza con Garda resta, marcata
  come eliminata, e non si riferisce più a un oggetto nuovo che riusasse lo stesso identificativo.
- `clienti.sconto_dm`: sconto predefinito delle righe dei preventivi AD_DM (Garda adsrl `clienti.sconto_def`, regola
  AD-13 trovata nella rilettura del codice di Garda dell'11/10/2026).
- `verifiche.riga_id` e `dm_incarichi.riga_id`: non più unici in assoluto, ma una sola verifica (o incarico) **non
  annullata** per riga (indice unico parziale). Dopo una revoca R124 e una nuova accettazione nasce un lavoro nuovo;
  quello annullato resta nello storico.
Il ritorno alla 0018 toglie tabella e colonna e ripristina l'unicità assoluta (bloccato se una riga ha già più lavori).
"""

import sqlalchemy as sa
from alembic import op

revision = '0019'
down_revision = '0018'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'preventivi_righe_revoche',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('riga_id', sa.Integer(), nullable=False),
        sa.Column('preventivo_id', sa.Integer(), nullable=False),
        sa.Column('motivo', sa.Text(), nullable=False),
        sa.Column('stato_prima', sa.String(length=20), nullable=False),
        sa.Column('verifica_id', sa.Integer(), nullable=True),
        sa.Column('incarico_dm_id', sa.Integer(), nullable=True),
        sa.Column('revocata_il', sa.DateTime(), nullable=False),
        sa.Column('revocata_da', sa.String(length=120), nullable=False),
        sa.ForeignKeyConstraint(['riga_id'], ['preventivi_righe.id'], name=op.f('fk_preventivi_righe_revoche_riga_id_preventivi_righe'), ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['preventivo_id'], ['preventivi.id'], name=op.f('fk_preventivi_righe_revoche_preventivo_id_preventivi'), ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id', name=op.f('pk_preventivi_righe_revoche')),
    )
    with op.batch_alter_table('preventivi_righe_revoche', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_preventivi_righe_revoche_riga_id'), ['riga_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_preventivi_righe_revoche_preventivo_id'), ['preventivo_id'], unique=False)
    with op.batch_alter_table('origini', schema=None) as batch_op:
        batch_op.add_column(sa.Column('eliminato_il', sa.DateTime(), nullable=True))
    with op.batch_alter_table('clienti', schema=None) as batch_op:
        batch_op.add_column(sa.Column('sconto_dm', sa.Integer(), server_default='0', nullable=False))
    with op.batch_alter_table('verifiche', schema=None) as batch_op:
        batch_op.drop_constraint('uq_verifiche_riga_id', type_='unique')
        batch_op.create_index('ix_verifiche_riga_id', ['riga_id'], unique=False)
    op.create_index('uq_verifiche_riga_attiva', 'verifiche', ['riga_id'], unique=True,
                    sqlite_where=sa.text("stato != 'annullata'"), postgresql_where=sa.text("stato != 'annullata'"))
    with op.batch_alter_table('dm_incarichi', schema=None) as batch_op:
        batch_op.drop_constraint('uq_dm_incarichi_riga_id', type_='unique')
        batch_op.create_index('ix_dm_incarichi_riga_id', ['riga_id'], unique=False)
    op.create_index('uq_dm_incarichi_riga_attiva', 'dm_incarichi', ['riga_id'], unique=True,
                    sqlite_where=sa.text("stato != 'annullata'"), postgresql_where=sa.text("stato != 'annullata'"))


def downgrade() -> None:
    conn = op.get_bind()
    for tabella in ('verifiche', 'dm_incarichi'):
        if conn.execute(sa.text(f"SELECT riga_id FROM {tabella} GROUP BY riga_id HAVING COUNT(*) > 1 LIMIT 1")).first():
            raise RuntimeError(f"Ritorno alla 0018 non possibile: in {tabella} una riga di preventivo ha più lavori (revoca R124).")
    op.drop_index('uq_dm_incarichi_riga_attiva', table_name='dm_incarichi')
    with op.batch_alter_table('dm_incarichi', schema=None) as batch_op:
        batch_op.drop_index('ix_dm_incarichi_riga_id')
        batch_op.create_unique_constraint('uq_dm_incarichi_riga_id', ['riga_id'])
    op.drop_index('uq_verifiche_riga_attiva', table_name='verifiche')
    with op.batch_alter_table('verifiche', schema=None) as batch_op:
        batch_op.drop_index('ix_verifiche_riga_id')
        batch_op.create_unique_constraint('uq_verifiche_riga_id', ['riga_id'])
    with op.batch_alter_table('clienti', schema=None) as batch_op:
        batch_op.drop_column('sconto_dm')
    with op.batch_alter_table('origini', schema=None) as batch_op:
        batch_op.drop_column('eliminato_il')
    with op.batch_alter_table('preventivi_righe_revoche', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_preventivi_righe_revoche_preventivo_id'))
        batch_op.drop_index(batch_op.f('ix_preventivi_righe_revoche_riga_id'))
    op.drop_table('preventivi_righe_revoche')
