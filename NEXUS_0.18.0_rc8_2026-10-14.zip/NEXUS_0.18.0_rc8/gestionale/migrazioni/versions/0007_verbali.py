"""Verifiche: collegamento al verbale compilato nel gestionale (D67) — versione 0.5.0

Revisione: 0007
Precedente: 0006
"""

import sqlalchemy as sa
from alembic import op

revision = "0007"
down_revision = "0006"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("verifiche", sa.Column("verbale_id", sa.String(length=40), nullable=False, server_default=""))
    op.create_index("ix_verifiche_verbale_id", "verifiche", ["verbale_id"])


def downgrade() -> None:
    op.drop_index("ix_verifiche_verbale_id", table_name="verifiche")
    with op.batch_alter_table("verifiche", schema=None) as batch_op:
        batch_op.drop_column("verbale_id")
