"""Versione 0.4.0: tariffario M03-RG01 rev. 01 (minimo, avvisi, elenchi a scelta), righe del preventivo a ore / senza impianto,
versione ritoccata dei documenti (D60), caratteristiche tecniche ed elementi degli impianti, verifiche (fase 5).

Revisione: 0006
Precedente: 0005
"""

import sqlalchemy as sa
from alembic import op

revision = "0006"
down_revision = "0005"
branch_labels = None
depends_on = None

RIGHE = """CREATE TABLE preventivi_righe (
	id INTEGER NOT NULL,
	preventivo_id INTEGER NOT NULL,
	ordine INTEGER NOT NULL,
	impianto_id INTEGER,
	voce_id INTEGER,
	quantita FLOAT,
	tipo_verifica VARCHAR(20) NOT NULL,
	sede_nome VARCHAR(300) NOT NULL,
	sede_indirizzo VARCHAR(200) NOT NULL,
	sede_comune VARCHAR(160) NOT NULL,
	tipologia VARCHAR(80) NOT NULL,
	descrizione VARCHAR(200) NOT NULL,
	tariffa_standard INTEGER NOT NULL,
	dettaglio_tariffa TEXT NOT NULL,
	sconto INTEGER NOT NULL,
	tariffa_applicata INTEGER NOT NULL,
	stato VARCHAR(20) NOT NULL,
	stato_il DATETIME,
	stato_da VARCHAR(120) NOT NULL,
	note VARCHAR(500) NOT NULL,
	CONSTRAINT pk_preventivi_righe PRIMARY KEY (id),
	CONSTRAINT ck_preventivi_righe_stato CHECK (stato IN ('in_attesa', 'accettata', 'rifiutata', 'annullata')),
	CONSTRAINT ck_preventivi_righe_tipo_verifica CHECK (tipo_verifica IN ('periodica', 'straordinaria')),
	CONSTRAINT ck_preventivi_righe_sconto CHECK (sconto >= 0 AND sconto <= 10000),
	CONSTRAINT fk_preventivi_righe_impianto_id_impianti FOREIGN KEY(impianto_id) REFERENCES impianti (id) ON DELETE RESTRICT,
	CONSTRAINT fk_preventivi_righe_voce_id_tariffe_voci FOREIGN KEY(voce_id) REFERENCES tariffe_voci (id) ON DELETE RESTRICT,
	CONSTRAINT fk_preventivi_righe_preventivo_id_preventivi FOREIGN KEY(preventivo_id) REFERENCES preventivi (id) ON DELETE CASCADE
)"""
COLONNE = ("id, preventivo_id, ordine, impianto_id, tipo_verifica, sede_nome, sede_indirizzo, sede_comune, tipologia, descrizione, "
           "tariffa_standard, dettaglio_tariffa, sconto, tariffa_applicata, stato, stato_il, stato_da, note")


def upgrade() -> None:
    # Colonne aggiunte con ADD COLUMN semplice (le tabelle sono richiamate da altre: niente ricreazione)
    op.add_column("tariffe_versioni", sa.Column("minimo", sa.Integer(), nullable=True))
    op.add_column("tariffe_scaglioni", sa.Column("etichetta", sa.String(length=200), server_default="", nullable=False))
    op.add_column("impianti", sa.Column("caratteristiche", sa.Text(), server_default="", nullable=False))
    op.add_column("preventivi_documenti", sa.Column("ritoccato", sa.Boolean(), server_default="0", nullable=False))
    # Righe del preventivo: impianto facoltativo, voce e quantità. La tabella non è ancora richiamata da altre
    # (le verifiche sono create sotto), quindi si ricrea copiando i dati, con gli stessi vincoli di prima.
    op.execute("ALTER TABLE preventivi_righe RENAME TO preventivi_righe_0005")
    op.execute(RIGHE)
    op.execute(f"INSERT INTO preventivi_righe ({COLONNE}) SELECT {COLONNE} FROM preventivi_righe_0005")
    op.execute("DROP TABLE preventivi_righe_0005")
    op.create_index("ix_preventivi_righe_impianto_id", "preventivi_righe", ["impianto_id"], unique=False)
    op.create_index("ix_preventivi_righe_preventivo_id", "preventivi_righe", ["preventivo_id"], unique=False)
    op.create_index("ix_preventivi_righe_stato", "preventivi_righe", ["stato"], unique=False)
    # Tabelle nuove: elementi degli impianti, verifiche e loro documenti
    op.create_table('impianti_elementi',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('impianto_id', sa.Integer(), nullable=False),
    sa.Column('tipo', sa.String(length=20), nullable=False),
    sa.Column('quadro', sa.String(length=200), nullable=False),
    sa.Column('nome', sa.String(length=300), nullable=False),
    sa.Column('occorrenza', sa.Integer(), nullable=False),
    sa.Column('attributi', sa.Text(), nullable=False),
    sa.Column('attivo', sa.Boolean(), nullable=False),
    sa.Column('dal_verbale', sa.String(length=20), nullable=False),
    sa.Column('aggiornato_il', sa.DateTime(), nullable=False),
    sa.ForeignKeyConstraint(['impianto_id'], ['impianti.id'], name=op.f('fk_impianti_elementi_impianto_id_impianti'), ondelete='CASCADE'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_impianti_elementi')),
    sa.UniqueConstraint('impianto_id', 'tipo', 'quadro', 'nome', 'occorrenza', name=op.f('uq_impianti_elementi_impianto_id'))
    )
    op.create_index(op.f('ix_impianti_elementi_impianto_id'), 'impianti_elementi', ['impianto_id'], unique=False)
    op.create_table('verifiche',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('riga_id', sa.Integer(), nullable=False),
    sa.Column('preventivo_id', sa.Integer(), nullable=False),
    sa.Column('impianto_id', sa.Integer(), nullable=False),
    sa.Column('tipo_verifica', sa.String(length=20), nullable=False),
    sa.Column('stato', sa.String(length=20), nullable=False),
    sa.Column('verificatore_id', sa.Integer(), nullable=True),
    sa.Column('assegnata_il', sa.DateTime(), nullable=True),
    sa.Column('assegnata_da', sa.String(length=120), nullable=False),
    sa.Column('data_programmata', sa.Date(), nullable=True),
    sa.Column('anno', sa.Integer(), nullable=True),
    sa.Column('numero', sa.Integer(), nullable=True),
    sa.Column('codice_verbale', sa.String(length=20), nullable=False),
    sa.Column('data_esecuzione', sa.Date(), nullable=True),
    sa.Column('registrata_il', sa.DateTime(), nullable=True),
    sa.Column('registrata_da', sa.String(length=120), nullable=False),
    sa.Column('modulo', sa.String(length=5), nullable=False),
    sa.Column('esito', sa.String(length=20), nullable=False),
    sa.Column('prossima_verifica', sa.Date(), nullable=True),
    sa.Column('dati_verbale', sa.Text(), nullable=False),
    sa.Column('avvisi_verbale', sa.Text(), nullable=False),
    sa.Column('eseguita_il', sa.DateTime(), nullable=True),
    sa.Column('caricata_da', sa.String(length=120), nullable=False),
    sa.Column('riesame_esito', sa.String(length=20), nullable=False),
    sa.Column('riesame_note', sa.Text(), nullable=False),
    sa.Column('riesame_il', sa.DateTime(), nullable=True),
    sa.Column('riesame_da', sa.String(length=120), nullable=False),
    sa.Column('motivo_annullamento', sa.String(length=500), nullable=False),
    sa.Column('note', sa.Text(), nullable=False),
    sa.Column('versione', sa.Integer(), nullable=False),
    sa.Column('creato_il', sa.DateTime(), nullable=False),
    sa.Column('creato_da', sa.String(length=120), nullable=False),
    sa.Column('modificato_il', sa.DateTime(), nullable=False),
    sa.Column('modificato_da', sa.String(length=120), nullable=False),
    sa.CheckConstraint("stato IN ('da_assegnare', 'assegnata', 'programmata', 'registrata', 'eseguita', 'riesaminata', 'annullata')", name=op.f('ck_verifiche_stato')),
    sa.ForeignKeyConstraint(['impianto_id'], ['impianti.id'], name=op.f('fk_verifiche_impianto_id_impianti'), ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['preventivo_id'], ['preventivi.id'], name=op.f('fk_verifiche_preventivo_id_preventivi'), ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['riga_id'], ['preventivi_righe.id'], name=op.f('fk_verifiche_riga_id_preventivi_righe'), ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['verificatore_id'], ['utenti.id'], name=op.f('fk_verifiche_verificatore_id_utenti'), ondelete='RESTRICT'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_verifiche')),
    sa.UniqueConstraint('anno', 'numero', name='uq_verifiche_numero_verbale'),
    sa.UniqueConstraint('riga_id', name=op.f('uq_verifiche_riga_id'))
    )
    op.create_index(op.f('ix_verifiche_codice_verbale'), 'verifiche', ['codice_verbale'], unique=False)
    op.create_index(op.f('ix_verifiche_impianto_id'), 'verifiche', ['impianto_id'], unique=False)
    op.create_index(op.f('ix_verifiche_preventivo_id'), 'verifiche', ['preventivo_id'], unique=False)
    op.create_index(op.f('ix_verifiche_stato'), 'verifiche', ['stato'], unique=False)
    op.create_index(op.f('ix_verifiche_verificatore_id'), 'verifiche', ['verificatore_id'], unique=False)
    op.create_table('verifiche_documenti',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('verifica_id', sa.Integer(), nullable=False),
    sa.Column('formato', sa.String(length=10), nullable=False),
    sa.Column('documento_id', sa.Integer(), nullable=False),
    sa.Column('nome_file', sa.String(length=255), nullable=False),
    sa.Column('in_uso', sa.Boolean(), nullable=False),
    sa.Column('creato_il', sa.DateTime(), nullable=False),
    sa.Column('creato_da', sa.String(length=120), nullable=False),
    sa.ForeignKeyConstraint(['documento_id'], ['documenti.id'], name=op.f('fk_verifiche_documenti_documento_id_documenti'), ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['verifica_id'], ['verifiche.id'], name=op.f('fk_verifiche_documenti_verifica_id_verifiche'), ondelete='RESTRICT'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_verifiche_documenti'))
    )
    op.create_index(op.f('ix_verifiche_documenti_verifica_id'), 'verifiche_documenti', ['verifica_id'], unique=False)


def downgrade() -> None:
    raise NotImplementedError("Per tornare indietro si ripristina il backup fatto prima dell'aggiornamento.")
