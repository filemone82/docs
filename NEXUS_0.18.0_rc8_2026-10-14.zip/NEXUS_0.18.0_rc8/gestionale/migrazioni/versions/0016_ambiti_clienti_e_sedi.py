"""ambiti di lavoro di clienti e sedi (R114)

Revisione: 0016
Precedente: 0015
Creata il: 2026-10-11

Anagrafica unica, tre indicatori per cliente e per sede: AD_DPR, AD_DM, I&C. Negli archivi esistenti si
ricavano da quello che c'è: impianti → DPR; attrezzature/accessori SC, SP, GVR, PSV → DM; preventivi → il loro
ambito. Un cliente che non ha ancora nulla diventa AD_DPR (fino alla 0.12.3 gli archivi erano di AD_DPR); una sede
ancora vuota prende gli ambiti del suo cliente.
Il ritorno alla 0015 toglie solo gli indicatori (nessun altro dato cambia).
"""

import sqlalchemy as sa
from alembic import op

revision = '0016'
down_revision = '0015'
branch_labels = None
depends_on = None

TABELLE = ('clienti', 'sedi')
CAMPI = ('ambito_dpr', 'ambito_dm', 'ambito_iec')
DM = "('SC','SP','GVR','PSV')"


def upgrade() -> None:
    for tabella in TABELLE:
        with op.batch_alter_table(tabella, schema=None) as batch_op:
            for campo in CAMPI:
                batch_op.add_column(sa.Column(campo, sa.Boolean(), server_default='0', nullable=False))
                batch_op.create_index(batch_op.f(f'ix_{tabella}_{campo}'), [campo], unique=False)
    for sql in (
        "UPDATE sedi SET ambito_dpr=1 WHERE EXISTS (SELECT 1 FROM impianti i WHERE i.sede_id=sedi.id)",
        f"UPDATE sedi SET ambito_dm=1 WHERE EXISTS (SELECT 1 FROM asset a WHERE a.sede_id=sedi.id AND a.gruppo IN {DM})",
        "UPDATE sedi SET ambito_dpr=1 WHERE EXISTS (SELECT 1 FROM preventivi p WHERE p.sede_id=sedi.id AND p.ambito='DPR')",
        "UPDATE sedi SET ambito_dm=1 WHERE EXISTS (SELECT 1 FROM preventivi p WHERE p.sede_id=sedi.id AND p.ambito='DM')",
        ("UPDATE clienti SET ambito_dpr=1 WHERE EXISTS (SELECT 1 FROM sedi s WHERE s.cliente_id=clienti.id AND s.ambito_dpr=1)"
         " OR EXISTS (SELECT 1 FROM preventivi p WHERE p.cliente_id=clienti.id AND p.ambito='DPR')"),
        ("UPDATE clienti SET ambito_dm=1 WHERE EXISTS (SELECT 1 FROM sedi s WHERE s.cliente_id=clienti.id AND s.ambito_dm=1)"
         " OR EXISTS (SELECT 1 FROM preventivi p WHERE p.cliente_id=clienti.id AND p.ambito='DM')"),
        "UPDATE clienti SET ambito_dpr=1 WHERE ambito_dpr=0 AND ambito_dm=0 AND ambito_iec=0",
        # una sede ancora vuota prende gli ambiti del suo cliente
        ("UPDATE sedi SET ambito_dpr=(SELECT c.ambito_dpr FROM clienti c WHERE c.id=sedi.cliente_id),"
         " ambito_dm=(SELECT c.ambito_dm FROM clienti c WHERE c.id=sedi.cliente_id)"
         " WHERE ambito_dpr=0 AND ambito_dm=0 AND ambito_iec=0"),
    ):
        op.execute(sql)


def downgrade() -> None:
    for tabella in reversed(TABELLE):
        with op.batch_alter_table(tabella, schema=None) as batch_op:
            for campo in reversed(CAMPI):
                batch_op.drop_index(batch_op.f(f'ix_{tabella}_{campo}'))
                batch_op.drop_column(campo)
