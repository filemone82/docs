"""NEXUS 0.16: più ruoli per utente (R143)

Revisione: 0023
Precedente: 0022
Creata il: 2026-10-12

- `utenti_ruoli`: ruoli aggiuntivi di un utente, oltre al principale `utenti.ruolo_id` (Federico, 12/10/2026, 17:58:
  «RT (e verificatore) DPR ma anche verificatore DM … flag su scelta multipla»). Ogni permesso vale nell'attività del
  ruolo che lo dà. Gli utenti esistenti non cambiano: hanno solo il ruolo principale.
"""

import sqlalchemy as sa
from alembic import op

revision = '0023'
down_revision = '0022'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'utenti_ruoli',
        sa.Column('utente_id', sa.Integer(), sa.ForeignKey('utenti.id', ondelete='CASCADE'), primary_key=True),
        sa.Column('ruolo_id', sa.Integer(), sa.ForeignKey('ruoli.id', ondelete='RESTRICT'), primary_key=True),
    )
    op.create_index('ix_utenti_ruoli_ruolo_id', 'utenti_ruoli', ['ruolo_id'])


def downgrade() -> None:
    bind = op.get_bind()
    if bind.execute(sa.text("select count(*) from utenti_ruoli")).scalar():
        raise RuntimeError("Ci sono utenti con più ruoli: togli i ruoli aggiuntivi prima di tornare alla versione precedente.")
    op.drop_index('ix_utenti_ruoli_ruolo_id', 'utenti_ruoli')
    op.drop_table('utenti_ruoli')
