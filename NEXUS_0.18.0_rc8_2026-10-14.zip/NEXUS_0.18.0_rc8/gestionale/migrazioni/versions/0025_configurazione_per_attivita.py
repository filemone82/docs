"""NEXUS 0.16: configurazione per attività (C16)

Revisione: 0025
Precedente: 0024
Creata il: 2026-10-12

Federico, 12/10/2026, 18:31: configurazione diversa in AD_DPR, AD_DM e I&C; «idem commerciali», «idem strumenti di
misura».
- `commerciali.ambito_dpr/_dm/_iec`: le attività del commerciale. Quelli esistenti prendono le attività dei clienti
  che seguono; se non ne seguono nessuno restano AD_DPR (sono quelli importati da ingecert).
- `strumenti_misura`: strumenti di misura AD_DM e I&C (quelli AD_DPR restano nel registro di VerbalizzAI).
"""

import sqlalchemy as sa
from alembic import op

revision = '0025'
down_revision = '0024'
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table('commerciali') as b:
        for c in ('ambito_dpr', 'ambito_dm', 'ambito_iec'):
            b.add_column(sa.Column(c, sa.Boolean(), nullable=False, server_default='0'))
    for c in ('ambito_dpr', 'ambito_dm', 'ambito_iec'):
        op.execute(f"UPDATE commerciali SET {c} = 1 WHERE EXISTS (SELECT 1 FROM clienti WHERE clienti.commerciale_id = commerciali.id "
                   f"AND clienti.{c} = 1)")
    op.execute("UPDATE commerciali SET ambito_dpr = 1 WHERE ambito_dpr = 0 AND ambito_dm = 0 AND ambito_iec = 0")
    op.create_table(
        'strumenti_misura',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('attivita', sa.String(4), nullable=False),
        sa.Column('denominazione', sa.String(200), nullable=False),
        sa.Column('costruttore', sa.String(120), nullable=False, server_default=''),
        sa.Column('modello', sa.String(120), nullable=False, server_default=''),
        sa.Column('matricola', sa.String(120), nullable=False, server_default=''),
        sa.Column('campo_misura', sa.String(200), nullable=False, server_default=''),
        sa.Column('ente_taratura', sa.String(200), nullable=False, server_default=''),
        sa.Column('certificato', sa.String(120), nullable=False, server_default=''),
        sa.Column('data_taratura', sa.Date()),
        sa.Column('scadenza_taratura', sa.Date()),
        sa.Column('attivo', sa.Boolean(), nullable=False, server_default='1'),
        sa.Column('note', sa.Text(), nullable=False, server_default=''),
        sa.Column('versione', sa.Integer(), nullable=False, server_default='1'),
        sa.Column('creato_il', sa.DateTime(), nullable=False),
        sa.Column('creato_da', sa.String(120), nullable=False, server_default=''),
        sa.Column('modificato_il', sa.DateTime(), nullable=False),
        sa.Column('modificato_da', sa.String(120), nullable=False, server_default=''),
        sa.CheckConstraint("attivita IN ('DM','IEC')", name=op.f('ck_strumenti_misura_attivita')),
    )
    op.create_index('ix_strumenti_misura_attivita', 'strumenti_misura', ['attivita'])
    op.create_index('ix_strumenti_misura_scadenza_taratura', 'strumenti_misura', ['scadenza_taratura'])


def downgrade() -> None:
    op.drop_index('ix_strumenti_misura_scadenza_taratura', 'strumenti_misura')
    op.drop_index('ix_strumenti_misura_attivita', 'strumenti_misura')
    op.drop_table('strumenti_misura')
    with op.batch_alter_table('commerciali') as b:
        for c in ('ambito_dpr', 'ambito_dm', 'ambito_iec'):
            b.drop_column(c)
