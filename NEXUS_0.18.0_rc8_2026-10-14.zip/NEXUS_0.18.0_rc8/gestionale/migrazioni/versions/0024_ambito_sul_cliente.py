"""NEXUS 0.16: ambito solo sul cliente (R137)

Revisione: 0024
Precedente: 0023
Creata il: 2026-10-12

Federico, 12/10/2026, 17:15: il flag AD_DPR / AD_DM / I&C «deve essere presente in cliente ed estendersi alle sedi
operative del cliente». Le colonne `ambito_*` delle sedi restano come copia di quelle del cliente (le aggiorna il
programma a ogni scrittura). Qui si allineano i dati esistenti, senza perdere nulla:
1. il cliente prende anche gli ambiti accesi solo su qualche sua sede;
2. ogni sede prende gli ambiti del suo cliente.
Il ritorno alla 0023 lascia i dati come sono (sono comunque coerenti).
"""

from alembic import op

revision = '0024'
down_revision = '0023'
branch_labels = None
depends_on = None

CAMPI = ("ambito_dpr", "ambito_dm", "ambito_iec")


def upgrade() -> None:
    for c in CAMPI:
        op.execute(f"UPDATE clienti SET {c} = 1 WHERE {c} = 0 AND EXISTS "
                   f"(SELECT 1 FROM sedi s WHERE s.cliente_id = clienti.id AND s.{c} = 1)")
        op.execute(f"UPDATE sedi SET {c} = (SELECT c.{c} FROM clienti c WHERE c.id = sedi.cliente_id)")


def downgrade() -> None:
    pass
