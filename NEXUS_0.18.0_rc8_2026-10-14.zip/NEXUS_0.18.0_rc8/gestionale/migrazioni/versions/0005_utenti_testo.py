"""Utenti: misura del testo scelta da ciascuno (D57); documenti dei preventivi: versione del preventivo (D58) — versione 0.3.1

Revisione: 0005
Precedente: 0004
"""

import sqlalchemy as sa
from alembic import op

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ADD COLUMN semplice, senza ricreare la tabella: sessioni e ruoli/registro la richiamano.
    op.add_column("utenti", sa.Column("testo", sa.String(length=10), nullable=False, server_default="normale"))
    op.add_column("preventivi_documenti", sa.Column("versione_preventivo", sa.Integer(), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table("preventivi_documenti", schema=None) as batch_op:
        batch_op.drop_column("versione_preventivo")
    with op.batch_alter_table("utenti", schema=None) as batch_op:
        batch_op.drop_column("testo")
