"""sedi indicate come diverse (R116)

Revisione: 0017
Precedente: 0016
Creata il: 2026-10-11

Coppie di sedi dello stesso cliente e dello stesso comune che l'utente ha indicato come sedi DIVERSE: non si
propongono più fra i possibili doppioni. Il ritorno alla 0016 toglie solo questa tabella.
"""

import sqlalchemy as sa
from alembic import op

revision = '0017'
down_revision = '0016'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'sedi_doppioni_esclusi',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('sede_a_id', sa.Integer(), nullable=False),
        sa.Column('sede_b_id', sa.Integer(), nullable=False),
        sa.Column('creato_il', sa.DateTime(), nullable=False),
        sa.Column('creato_da', sa.String(length=120), nullable=False),
        sa.ForeignKeyConstraint(['sede_a_id'], ['sedi.id'], name=op.f('fk_sedi_doppioni_esclusi_sede_a_id_sedi'), ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['sede_b_id'], ['sedi.id'], name=op.f('fk_sedi_doppioni_esclusi_sede_b_id_sedi'), ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id', name=op.f('pk_sedi_doppioni_esclusi')),
        sa.UniqueConstraint('sede_a_id', 'sede_b_id', name='uq_sedi_doppioni_esclusi'),
    )
    with op.batch_alter_table('sedi_doppioni_esclusi', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_sedi_doppioni_esclusi_sede_a_id'), ['sede_a_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_sedi_doppioni_esclusi_sede_b_id'), ['sede_b_id'], unique=False)


def downgrade() -> None:
    with op.batch_alter_table('sedi_doppioni_esclusi', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_sedi_doppioni_esclusi_sede_b_id'))
        batch_op.drop_index(batch_op.f('ix_sedi_doppioni_esclusi_sede_a_id'))
    op.drop_table('sedi_doppioni_esclusi')
