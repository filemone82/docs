"""dati del verbale DM come attributi dell'attrezzatura (R123, documento 24 § 4.1)

Revisione: 0020
Precedente: 0019
Creata il: 2026-10-12

- `dm_schede_verbale`: versioni dei gruppi della scheda dei dati del verbale di un'attrezzatura DM (generale GVR,
  accessori, esercizio a2, conservazione, osservazioni per componente, testi SC/SP). Righe solo aggiunte: le
  correzioni a mano e le scelte all'emissione restano nello storico. Se manca, il gruppo si ricava dai verbali
  effettuati con la regola di Garda: nessun dato da migrare.
"""

import sqlalchemy as sa
from alembic import op

revision = '0020'
down_revision = '0019'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'dm_schede_verbale',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('asset_id', sa.Integer(), nullable=False),
        sa.Column('gruppo', sa.String(length=30), nullable=False),
        sa.Column('campi_json', sa.Text(), nullable=False),
        sa.Column('origine', sa.String(length=20), nullable=False),
        sa.Column('incarico_id', sa.Integer(), nullable=True),
        sa.Column('data_riferimento', sa.Date(), nullable=False),
        sa.Column('nota', sa.Text(), server_default='', nullable=False),
        sa.Column('creato_il', sa.DateTime(), nullable=False),
        sa.Column('creato_da', sa.String(length=120), nullable=False),
        sa.ForeignKeyConstraint(['asset_id'], ['asset.id'], name=op.f('fk_dm_schede_verbale_asset_id_asset'), ondelete='RESTRICT'),
        sa.ForeignKeyConstraint(['incarico_id'], ['dm_incarichi.id'], name=op.f('fk_dm_schede_verbale_incarico_id_dm_incarichi'),
                                ondelete='RESTRICT'),
        sa.PrimaryKeyConstraint('id', name=op.f('pk_dm_schede_verbale')),
    )
    with op.batch_alter_table('dm_schede_verbale', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_dm_schede_verbale_asset_id'), ['asset_id'], unique=False)


def downgrade() -> None:
    with op.batch_alter_table('dm_schede_verbale', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_dm_schede_verbale_asset_id'))
    op.drop_table('dm_schede_verbale')
