"""fatture DPR complete pari a Garda (0.14)

Revisione: 0022
Precedente: 0021
Creata il: 2026-10-12

- `elenchi_valori.regole_json`: regole delle modalità di pagamento (codice MP, rate, fine mese, «paga il giorno del
  mese dopo», spostamento delle scadenze di agosto e dicembre, «salda subito», predefinita), come i `tipi_pagamento`
  di Garda. Vuoto = regole ricavate dal nome finché non si salvano.
- `fatture_esportazioni.nome_file`: nome del file per lo SdI con progressivo di 5 caratteri. Le esportazioni
  precedenti restano con il nome di allora (vuoto = ricostruito come prima).
Nessun dato esistente cambia.
"""

import sqlalchemy as sa
from alembic import op

revision = '0022'
down_revision = '0021'
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table('elenchi_valori') as b:
        b.add_column(sa.Column('regole_json', sa.Text(), nullable=False, server_default='{}'))
    with op.batch_alter_table('fatture_esportazioni') as b:
        b.add_column(sa.Column('nome_file', sa.String(length=60), nullable=False, server_default=''))
    op.create_index('ix_fatture_esportazioni_nome_file', 'fatture_esportazioni', ['nome_file'])


def downgrade() -> None:
    op.drop_index('ix_fatture_esportazioni_nome_file', 'fatture_esportazioni')
    with op.batch_alter_table('fatture_esportazioni') as b:
        b.drop_column('nome_file')
    with op.batch_alter_table('elenchi_valori') as b:
        b.drop_column('regole_json')
