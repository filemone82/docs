"""Documenti dei preventivi come i verbali: gruppo Word/PDF, impronta dei dati, approvazione (D80) — versione 0.7.0

Revisione: 0008
Precedente: 0007
"""

import sqlalchemy as sa
from alembic import op

revision = "0008"
down_revision = "0007"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("preventivi_documenti", schema=None) as batch_op:
        batch_op.add_column(sa.Column("gruppo", sa.String(length=32), nullable=False, server_default=""))
        batch_op.add_column(sa.Column("impronta_dati", sa.String(length=64), nullable=False, server_default=""))
        batch_op.add_column(sa.Column("approvato_il", sa.DateTime(), nullable=True))
        batch_op.add_column(sa.Column("approvato_da", sa.String(length=120), nullable=False, server_default=""))
        batch_op.create_index("ix_preventivi_documenti_gruppo", ["gruppo"])


def downgrade() -> None:
    with op.batch_alter_table("preventivi_documenti", schema=None) as batch_op:
        batch_op.drop_index("ix_preventivi_documenti_gruppo")
        batch_op.drop_column("approvato_da")
        batch_op.drop_column("approvato_il")
        batch_op.drop_column("impronta_dati")
        batch_op.drop_column("gruppo")
