"""Evidenza della conferma scritta (R38), senza ricostruire prove storiche ignote."""

import sqlalchemy as sa
from alembic import op

revision = "0010"
down_revision = "0009"
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table("preventivi") as b:
        b.add_column(
            sa.Column(
                "evidenza_accettazione", sa.Text(), nullable=False, server_default=""
            )
        )


def downgrade():
    raise RuntimeError("Ripristinare il backup verificato pre-aggiornamento.")
