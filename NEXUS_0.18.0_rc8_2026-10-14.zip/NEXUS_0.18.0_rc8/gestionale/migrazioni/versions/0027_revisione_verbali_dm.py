"""NEXUS 0.16: revisione dei verbali DM emessi (R134)

Revisione: 0027
Precedente: 0026
Creata il: 2026-10-12

Federico, 12/10/2026, 17:02: «revisione ok come proposto e già praticato per dpr». Stesso numero del verbale,
rev. N+1, motivo; lo storico delle revisioni resta nell'incarico.
"""

import sqlalchemy as sa
from alembic import op

revision = '0027'
down_revision = '0026'
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table('dm_incarichi') as b:
        b.add_column(sa.Column('revisione', sa.Integer(), nullable=False, server_default='0'))
        b.add_column(sa.Column('revisioni_json', sa.Text(), nullable=False, server_default='[]'))


def downgrade() -> None:
    with op.batch_alter_table('dm_incarichi') as b:
        b.drop_column('revisioni_json')
        b.drop_column('revisione')
