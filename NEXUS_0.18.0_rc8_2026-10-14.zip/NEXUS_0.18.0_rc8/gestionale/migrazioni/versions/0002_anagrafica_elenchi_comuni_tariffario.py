"""Anagrafica (clienti, sedi, impianti, POD, commerciali), elenchi di valori, comuni ISTAT, tariffario;
indice del registro per lo storico delle schede (versione 0.2.0)

Revisione: 0002
Precedente: 0001
Creata il: 2026-10-04 16:23:49.159175
"""

from alembic import op
import sqlalchemy as sa


revision = '0002'
down_revision = '0001'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # indice semplice (senza ricreare la tabella: il registro ha i trigger che lo rendono non modificabile)
    op.create_index('ix_registro_operazioni_oggetto', 'registro_operazioni', ['oggetto_tipo', 'oggetto_id'], unique=False)

    op.create_table('comuni',
    sa.Column('codice_istat', sa.String(length=6), nullable=False),
    sa.Column('nome', sa.String(length=100), nullable=False),
    sa.Column('sigla', sa.String(length=2), nullable=False),
    sa.Column('provincia', sa.String(length=80), nullable=False),
    sa.Column('regione', sa.String(length=60), nullable=False),
    sa.Column('cap', sa.String(length=600), nullable=False),
    sa.Column('codice_catastale', sa.String(length=4), nullable=False),
    sa.PrimaryKeyConstraint('codice_istat', name=op.f('pk_comuni'))
    )
    with op.batch_alter_table('comuni', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_comuni_nome'), ['nome'], unique=False)

    op.create_table('elenchi_valori',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('elenco', sa.String(length=40), nullable=False),
    sa.Column('codice', sa.String(length=20), nullable=False),
    sa.Column('descrizione', sa.String(length=200), nullable=False),
    sa.Column('percentuale', sa.Integer(), nullable=True),
    sa.Column('scissione_pagamenti', sa.Boolean(), nullable=False),
    sa.Column('natura', sa.String(length=10), nullable=False),
    sa.Column('ordine', sa.Integer(), nullable=False),
    sa.Column('attivo', sa.Boolean(), nullable=False),
    sa.Column('versione', sa.Integer(), nullable=False),
    sa.Column('creato_il', sa.DateTime(), nullable=False),
    sa.Column('creato_da', sa.String(length=120), nullable=False),
    sa.Column('modificato_il', sa.DateTime(), nullable=False),
    sa.Column('modificato_da', sa.String(length=120), nullable=False),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_elenchi_valori')),
    sa.UniqueConstraint('elenco', 'descrizione', name=op.f('uq_elenchi_valori_elenco'))
    )
    with op.batch_alter_table('elenchi_valori', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_elenchi_valori_elenco'), ['elenco'], unique=False)

    op.create_table('tariffe_voci',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('codice', sa.String(length=30), nullable=False),
    sa.Column('nome', sa.String(length=150), nullable=False),
    sa.Column('tipologie', sa.String(length=100), nullable=False),
    sa.Column('criterio', sa.String(length=20), nullable=False),
    sa.Column('grandezza', sa.String(length=30), nullable=False),
    sa.Column('automatica', sa.Boolean(), nullable=False),
    sa.Column('attiva', sa.Boolean(), nullable=False),
    sa.Column('ordine', sa.Integer(), nullable=False),
    sa.Column('note', sa.Text(), nullable=False),
    sa.Column('versione', sa.Integer(), nullable=False),
    sa.Column('creato_il', sa.DateTime(), nullable=False),
    sa.Column('creato_da', sa.String(length=120), nullable=False),
    sa.Column('modificato_il', sa.DateTime(), nullable=False),
    sa.Column('modificato_da', sa.String(length=120), nullable=False),
    sa.CheckConstraint("criterio IN ('scaglioni', 'unitario', 'fisso')", name=op.f('ck_tariffe_voci_criterio')),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_tariffe_voci')),
    sa.UniqueConstraint('codice', name=op.f('uq_tariffe_voci_codice'))
    )
    op.create_table('tariffe_versioni',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('voce_id', sa.Integer(), nullable=False),
    sa.Column('valida_dal', sa.Date(), nullable=False),
    sa.Column('prezzo', sa.Integer(), nullable=True),
    sa.Column('note', sa.Text(), nullable=False),
    sa.Column('creata_il', sa.DateTime(), nullable=False),
    sa.Column('creata_da', sa.String(length=120), nullable=False),
    sa.ForeignKeyConstraint(['voce_id'], ['tariffe_voci.id'], name=op.f('fk_tariffe_versioni_voce_id_tariffe_voci'), ondelete='CASCADE'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_tariffe_versioni')),
    sa.UniqueConstraint('voce_id', 'valida_dal', name=op.f('uq_tariffe_versioni_voce_id'))
    )
    with op.batch_alter_table('tariffe_versioni', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_tariffe_versioni_voce_id'), ['voce_id'], unique=False)

    op.create_table('commerciali',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('nome', sa.String(length=120), nullable=False),
    sa.Column('email', sa.String(length=200), nullable=False),
    sa.Column('telefono', sa.String(length=60), nullable=False),
    sa.Column('utente_id', sa.Integer(), nullable=True),
    sa.Column('attivo', sa.Boolean(), nullable=False),
    sa.Column('note', sa.Text(), nullable=False),
    sa.Column('versione', sa.Integer(), nullable=False),
    sa.Column('creato_il', sa.DateTime(), nullable=False),
    sa.Column('creato_da', sa.String(length=120), nullable=False),
    sa.Column('modificato_il', sa.DateTime(), nullable=False),
    sa.Column('modificato_da', sa.String(length=120), nullable=False),
    sa.ForeignKeyConstraint(['utente_id'], ['utenti.id'], name=op.f('fk_commerciali_utente_id_utenti'), ondelete='SET NULL'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_commerciali')),
    sa.UniqueConstraint('nome', name=op.f('uq_commerciali_nome'))
    )
    op.create_table('tariffe_scaglioni',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('versione_id', sa.Integer(), nullable=False),
    sa.Column('ordine', sa.Integer(), nullable=False),
    sa.Column('fino_a', sa.Float(), nullable=True),
    sa.Column('importo', sa.Integer(), nullable=False),
    sa.ForeignKeyConstraint(['versione_id'], ['tariffe_versioni.id'], name=op.f('fk_tariffe_scaglioni_versione_id_tariffe_versioni'), ondelete='CASCADE'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_tariffe_scaglioni'))
    )
    with op.batch_alter_table('tariffe_scaglioni', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_tariffe_scaglioni_versione_id'), ['versione_id'], unique=False)

    op.create_table('clienti',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('ragione_sociale', sa.String(length=250), nullable=False),
    sa.Column('tipo', sa.String(length=20), nullable=False),
    sa.Column('nazione', sa.String(length=2), nullable=False),
    sa.Column('partita_iva', sa.String(length=20), nullable=False),
    sa.Column('codice_fiscale', sa.String(length=20), nullable=False),
    sa.Column('email_verbali', sa.String(length=500), nullable=False),
    sa.Column('email_fatture', sa.String(length=500), nullable=False),
    sa.Column('pec', sa.String(length=200), nullable=False),
    sa.Column('codice_sdi', sa.String(length=7), nullable=False),
    sa.Column('riferimento_amministrazione', sa.String(length=20), nullable=False),
    sa.Column('commerciale_id', sa.Integer(), nullable=True),
    sa.Column('referente_nome', sa.String(length=120), nullable=False),
    sa.Column('referente_email', sa.String(length=200), nullable=False),
    sa.Column('referente_telefono', sa.String(length=60), nullable=False),
    sa.Column('banca', sa.String(length=120), nullable=False),
    sa.Column('iban', sa.String(length=34), nullable=False),
    sa.Column('dichiarazione_intento', sa.Boolean(), nullable=False),
    sa.Column('dichiarazione_numero', sa.String(length=60), nullable=False),
    sa.Column('dichiarazione_data', sa.Date(), nullable=True),
    sa.Column('ritenuta_percentuale', sa.Integer(), nullable=True),
    sa.Column('modalita_pagamento_id', sa.Integer(), nullable=True),
    sa.Column('aliquota_iva_id', sa.Integer(), nullable=True),
    sa.Column('sconti_ammessi', sa.Boolean(), nullable=False),
    sa.Column('sconti_motivo', sa.String(length=300), nullable=False),
    sa.Column('attivo', sa.Boolean(), nullable=False),
    sa.Column('note', sa.Text(), nullable=False),
    sa.Column('avvisi', sa.Text(), nullable=False),
    sa.Column('codice_esterno', sa.String(length=40), nullable=False),
    sa.Column('indirizzo', sa.String(length=200), nullable=False),
    sa.Column('comune_istat', sa.String(length=6), nullable=True),
    sa.Column('comune', sa.String(length=100), nullable=False),
    sa.Column('cap', sa.String(length=10), nullable=False),
    sa.Column('provincia', sa.String(length=2), nullable=False),
    sa.Column('regione', sa.String(length=60), nullable=False),
    sa.Column('versione', sa.Integer(), nullable=False),
    sa.Column('creato_il', sa.DateTime(), nullable=False),
    sa.Column('creato_da', sa.String(length=120), nullable=False),
    sa.Column('modificato_il', sa.DateTime(), nullable=False),
    sa.Column('modificato_da', sa.String(length=120), nullable=False),
    sa.CheckConstraint("tipo IN ('privato', 'pa', 'condominio', 'persona_fisica')", name=op.f('ck_clienti_tipo')),
    sa.ForeignKeyConstraint(['aliquota_iva_id'], ['elenchi_valori.id'], name=op.f('fk_clienti_aliquota_iva_id_elenchi_valori'), ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['commerciale_id'], ['commerciali.id'], name=op.f('fk_clienti_commerciale_id_commerciali'), ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['comune_istat'], ['comuni.codice_istat'], name=op.f('fk_clienti_comune_istat_comuni'), ondelete='SET NULL'),
    sa.ForeignKeyConstraint(['modalita_pagamento_id'], ['elenchi_valori.id'], name=op.f('fk_clienti_modalita_pagamento_id_elenchi_valori'), ondelete='RESTRICT'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_clienti'))
    )
    with op.batch_alter_table('clienti', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_clienti_codice_fiscale'), ['codice_fiscale'], unique=False)
        batch_op.create_index(batch_op.f('ix_clienti_commerciale_id'), ['commerciale_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_clienti_partita_iva'), ['partita_iva'], unique=False)
        batch_op.create_index(batch_op.f('ix_clienti_ragione_sociale'), ['ragione_sociale'], unique=False)

    op.create_table('sedi',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('cliente_id', sa.Integer(), nullable=False),
    sa.Column('denominazione', sa.String(length=300), nullable=False),
    sa.Column('referente_nome', sa.String(length=120), nullable=False),
    sa.Column('referente_email', sa.String(length=200), nullable=False),
    sa.Column('referente_telefono', sa.String(length=60), nullable=False),
    sa.Column('email_verbali', sa.String(length=500), nullable=False),
    sa.Column('email_verbali_cc', sa.String(length=500), nullable=False),
    sa.Column('note_accesso', sa.Text(), nullable=False),
    sa.Column('attiva', sa.Boolean(), nullable=False),
    sa.Column('note', sa.Text(), nullable=False),
    sa.Column('avvisi', sa.Text(), nullable=False),
    sa.Column('codice_esterno', sa.String(length=40), nullable=False),
    sa.Column('indirizzo', sa.String(length=200), nullable=False),
    sa.Column('comune_istat', sa.String(length=6), nullable=True),
    sa.Column('comune', sa.String(length=100), nullable=False),
    sa.Column('cap', sa.String(length=10), nullable=False),
    sa.Column('provincia', sa.String(length=2), nullable=False),
    sa.Column('regione', sa.String(length=60), nullable=False),
    sa.Column('versione', sa.Integer(), nullable=False),
    sa.Column('creato_il', sa.DateTime(), nullable=False),
    sa.Column('creato_da', sa.String(length=120), nullable=False),
    sa.Column('modificato_il', sa.DateTime(), nullable=False),
    sa.Column('modificato_da', sa.String(length=120), nullable=False),
    sa.ForeignKeyConstraint(['cliente_id'], ['clienti.id'], name=op.f('fk_sedi_cliente_id_clienti'), ondelete='RESTRICT'),
    sa.ForeignKeyConstraint(['comune_istat'], ['comuni.codice_istat'], name=op.f('fk_sedi_comune_istat_comuni'), ondelete='SET NULL'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_sedi'))
    )
    with op.batch_alter_table('sedi', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_sedi_cliente_id'), ['cliente_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_sedi_denominazione'), ['denominazione'], unique=False)

    op.create_table('impianti',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('sede_id', sa.Integer(), nullable=False),
    sa.Column('tipologia', sa.String(length=20), nullable=False),
    sa.Column('denominazione', sa.String(length=300), nullable=False),
    sa.Column('dismesso', sa.Boolean(), nullable=False),
    sa.Column('matricola_anno', sa.String(length=4), nullable=False),
    sa.Column('matricola_attivita', sa.String(length=10), nullable=False),
    sa.Column('matricola_numero', sa.String(length=20), nullable=False),
    sa.Column('matricola_provincia', sa.String(length=2), nullable=False),
    sa.Column('potenza_kw', sa.Float(), nullable=True),
    sa.Column('cabine_mt_bt', sa.Integer(), nullable=True),
    sa.Column('sottostazioni_at_mt', sa.Integer(), nullable=True),
    sa.Column('pod_note', sa.Text(), nullable=False),
    sa.Column('asta', sa.Boolean(), nullable=False),
    sa.Column('numero_aste', sa.Integer(), nullable=True),
    sa.Column('gabbia', sa.Boolean(), nullable=False),
    sa.Column('gabbia_fascia', sa.String(length=20), nullable=False),
    sa.Column('gas', sa.Boolean(), nullable=False),
    sa.Column('polveri', sa.Boolean(), nullable=False),
    sa.Column('zone', sa.String(length=30), nullable=False),
    sa.Column('periodicita_anni', sa.Integer(), nullable=True),
    sa.Column('ultima_verifica_data', sa.Date(), nullable=True),
    sa.Column('ultima_verifica_numero', sa.String(length=40), nullable=False),
    sa.Column('prossima_verifica', sa.Date(), nullable=True),
    sa.Column('prossima_calcolata', sa.Boolean(), nullable=False),
    sa.Column('note', sa.Text(), nullable=False),
    sa.Column('avvisi', sa.Text(), nullable=False),
    sa.Column('codice_esterno', sa.String(length=40), nullable=False),
    sa.Column('versione', sa.Integer(), nullable=False),
    sa.Column('creato_il', sa.DateTime(), nullable=False),
    sa.Column('creato_da', sa.String(length=120), nullable=False),
    sa.Column('modificato_il', sa.DateTime(), nullable=False),
    sa.Column('modificato_da', sa.String(length=120), nullable=False),
    sa.CheckConstraint("gabbia_fascia = '' OR gabbia_fascia IN ('fino_100', 'da_101_a_350', 'oltre_350')", name=op.f('ck_impianti_gabbia_fascia')),
    sa.CheckConstraint("tipologia IN ('terra_bt', 'terra_at', 'scariche', 'esplosione')", name=op.f('ck_impianti_tipologia')),
    sa.CheckConstraint('periodicita_anni IS NULL OR periodicita_anni IN (2, 5)', name=op.f('ck_impianti_periodicita')),
    sa.CheckConstraint('potenza_kw IS NULL OR potenza_kw >= 0', name=op.f('ck_impianti_potenza')),
    sa.ForeignKeyConstraint(['sede_id'], ['sedi.id'], name=op.f('fk_impianti_sede_id_sedi'), ondelete='RESTRICT'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_impianti'))
    )
    with op.batch_alter_table('impianti', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_impianti_codice_esterno'), ['codice_esterno'], unique=False)
        batch_op.create_index(batch_op.f('ix_impianti_dismesso'), ['dismesso'], unique=False)
        batch_op.create_index(batch_op.f('ix_impianti_prossima_verifica'), ['prossima_verifica'], unique=False)
        batch_op.create_index(batch_op.f('ix_impianti_sede_id'), ['sede_id'], unique=False)

    op.create_table('impianti_pod',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('impianto_id', sa.Integer(), nullable=False),
    sa.Column('pod', sa.String(length=20), nullable=False),
    sa.Column('ordine', sa.Integer(), nullable=False),
    sa.ForeignKeyConstraint(['impianto_id'], ['impianti.id'], name=op.f('fk_impianti_pod_impianto_id_impianti'), ondelete='CASCADE'),
    sa.PrimaryKeyConstraint('id', name=op.f('pk_impianti_pod')),
    sa.UniqueConstraint('impianto_id', 'pod', name=op.f('uq_impianti_pod_impianto_id'))
    )
    with op.batch_alter_table('impianti_pod', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_impianti_pod_impianto_id'), ['impianto_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_impianti_pod_pod'), ['pod'], unique=False)



def downgrade() -> None:
    with op.batch_alter_table('impianti_pod', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_impianti_pod_pod'))
        batch_op.drop_index(batch_op.f('ix_impianti_pod_impianto_id'))

    op.drop_table('impianti_pod')
    with op.batch_alter_table('impianti', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_impianti_sede_id'))
        batch_op.drop_index(batch_op.f('ix_impianti_prossima_verifica'))
        batch_op.drop_index(batch_op.f('ix_impianti_dismesso'))
        batch_op.drop_index(batch_op.f('ix_impianti_codice_esterno'))

    op.drop_table('impianti')
    with op.batch_alter_table('sedi', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_sedi_denominazione'))
        batch_op.drop_index(batch_op.f('ix_sedi_cliente_id'))

    op.drop_table('sedi')
    with op.batch_alter_table('clienti', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_clienti_ragione_sociale'))
        batch_op.drop_index(batch_op.f('ix_clienti_partita_iva'))
        batch_op.drop_index(batch_op.f('ix_clienti_commerciale_id'))
        batch_op.drop_index(batch_op.f('ix_clienti_codice_fiscale'))

    op.drop_table('clienti')
    with op.batch_alter_table('tariffe_scaglioni', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_tariffe_scaglioni_versione_id'))

    op.drop_table('tariffe_scaglioni')
    op.drop_table('commerciali')
    with op.batch_alter_table('tariffe_versioni', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_tariffe_versioni_voce_id'))

    op.drop_table('tariffe_versioni')
    op.drop_table('tariffe_voci')
    with op.batch_alter_table('elenchi_valori', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_elenchi_valori_elenco'))

    op.drop_table('elenchi_valori')
    with op.batch_alter_table('comuni', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_comuni_nome'))

    op.drop_table('comuni')
    op.drop_index('ix_registro_operazioni_oggetto', table_name='registro_operazioni')
