"""ruoli distinti per attività (R132)

Revisione: 0021
Precedente: 0020
Creata il: 2026-10-12

- `ruoli.attivita`: "DPR", "DM", "DPR,DM" oppure "" (ruolo comune: amministratore, segreteria).
- Archivi esistenti: i ruoli di base «Responsabile tecnico» e «Verificatore» diventano quelli AD_DPR (oggi in uso solo
  per il D.P.R. 462/01); il nome cambia solo se è ancora quello di partenza. Si aggiungono «RT DM», «Verificatore DM» e
  «Verificatore DM e DPR» con gli stessi permessi dei corrispondenti DPR. Gli utenti restano sul loro ruolo:
  l'amministratore assegna i ruoli DM a chi serve. Su un archivio nuovo (nessun ruolo) non si fa nulla: i ruoli
  nascono all'avvio dai valori di partenza.
"""

import sqlalchemy as sa
from alembic import op

revision = '0021'
down_revision = '0020'
branch_labels = None
depends_on = None

NUOVI = (
    # codice, nome, descrizione, attività, copia i permessi da
    ('responsabile_tecnico_dm', 'RT DM', 'Responsabile tecnico AD_DM: affida gli incarichi, esegue verifiche, riesamina '
     'contratti e verbali del D.M. 11.04.2011.', 'DM', 'responsabile_tecnico'),
    ('tecnico_dm', 'Verificatore DM', 'Esegue le verifiche AD_DM che gli sono assegnate: indipendenza, programmazione, '
     'registrazione, verbale.', 'DM', 'tecnico'),
    ('tecnico_dm_dpr', 'Verificatore DM e DPR', 'Verificatore abilitato a entrambe le attività.', 'DPR,DM', 'tecnico'),
)


def upgrade() -> None:
    with op.batch_alter_table('ruoli') as b:
        b.add_column(sa.Column('attivita', sa.String(length=20), nullable=False, server_default=''))
    c = op.get_bind()
    ruoli = {r.codice: r for r in c.execute(sa.text('SELECT id, codice, nome FROM ruoli'))}
    if 'responsabile_tecnico' not in ruoli and 'tecnico' not in ruoli:
        return
    for codice, vecchio, nuovo in (('responsabile_tecnico', 'Responsabile tecnico', 'RT DPR'),
                                   ('tecnico', 'Verificatore', 'Verificatore DPR')):
        if codice in ruoli:
            c.execute(sa.text("UPDATE ruoli SET attivita = 'DPR' WHERE codice = :c"), {'c': codice})
            if ruoli[codice].nome == vecchio and not any(r.nome == nuovo for r in ruoli.values()):
                c.execute(sa.text('UPDATE ruoli SET nome = :n WHERE codice = :c'), {'n': nuovo, 'c': codice})
    nomi = {r.nome.lower() for r in c.execute(sa.text('SELECT nome FROM ruoli'))}
    for codice, nome, descrizione, attivita, da in NUOVI:
        if codice in ruoli or da not in ruoli:
            continue
        if nome.lower() in nomi:
            nome = nome + ' (nuovo)'
        c.execute(sa.text("INSERT INTO ruoli (codice, nome, descrizione, attivo, di_sistema, attivita, creato_il, versione) "
                          "VALUES (:codice, :nome, :descrizione, 1, 0, :attivita, CURRENT_TIMESTAMP, 1)"),
                  {'codice': codice, 'nome': nome, 'descrizione': descrizione, 'attivita': attivita})
        nuovo_id = c.execute(sa.text('SELECT id FROM ruoli WHERE codice = :c'), {'c': codice}).scalar()
        c.execute(sa.text('INSERT INTO ruoli_permessi (ruolo_id, permesso_codice) '
                          'SELECT :n, permesso_codice FROM ruoli_permessi WHERE ruolo_id = :v'),
                  {'n': nuovo_id, 'v': ruoli[da].id})


def downgrade() -> None:
    c = op.get_bind()
    usati = c.execute(sa.text(
        "SELECT COUNT(*) FROM utenti u JOIN ruoli r ON r.id = u.ruolo_id WHERE r.codice IN "
        "('responsabile_tecnico_dm', 'tecnico_dm', 'tecnico_dm_dpr')")).scalar()
    if usati:
        raise RuntimeError('Ritorno alla 0020 bloccato: ci sono utenti con ruoli DM (R132). Riassegnali prima.')
    c.execute(sa.text("DELETE FROM ruoli_permessi WHERE ruolo_id IN (SELECT id FROM ruoli WHERE codice IN "
                      "('responsabile_tecnico_dm', 'tecnico_dm', 'tecnico_dm_dpr'))"))
    c.execute(sa.text("DELETE FROM ruoli WHERE codice IN ('responsabile_tecnico_dm', 'tecnico_dm', 'tecnico_dm_dpr')"))
    with op.batch_alter_table('ruoli') as b:
        b.drop_column('attivita')
