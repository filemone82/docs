"""corrispondenze con Garda, clienti diversi, esclusione dell'indipendenza (R119, R120)

Revisione: 0018
Precedente: 0017
Creata il: 2026-10-11

- `origini`: identificativo del gestionale di provenienza → oggetto del gestionale integrato. Negli archivi esistenti
  si ricavano clienti, sedi e impianti dal «Rif. gestionale attuale» (numero = ingecert, «dm:N» = adsrl) e, per i
  clienti fusi con adsrl, dalla nota «adsrl codice N». Preventivi, righe e verifiche si registrano dalle prossime
  importazioni (prima non se ne conservava l'id di Garda).
- `clienti_doppioni_esclusi`: clienti indicati come diversi pur con la stessa partita IVA o lo stesso codice fiscale.
- `verifiche.indipendenza_esclusa`, `dm_incarichi.indipendenza_esclusa`: chi ha dichiarato di non essere indipendente.
Il ritorno alla 0017 toglie tabelle e colonne.
"""

import re

import sqlalchemy as sa
from alembic import op

revision = '0018'
down_revision = '0017'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'origini',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('sistema', sa.String(length=30), nullable=False),
        sa.Column('tabella', sa.String(length=60), nullable=False),
        sa.Column('id_origine', sa.String(length=60), nullable=False),
        sa.Column('entita', sa.String(length=30), nullable=False),
        sa.Column('entita_id', sa.Integer(), nullable=False),
        sa.Column('creato_il', sa.DateTime(), nullable=False),
        sa.Column('nota', sa.String(length=300), nullable=False),
        sa.PrimaryKeyConstraint('id', name=op.f('pk_origini')),
        sa.UniqueConstraint('sistema', 'tabella', 'id_origine', name='uq_origini_sistema_tabella_id'),
    )
    with op.batch_alter_table('origini', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_origini_entita'), ['entita'], unique=False)
        batch_op.create_index(batch_op.f('ix_origini_entita_id'), ['entita_id'], unique=False)
    op.create_table(
        'clienti_doppioni_esclusi',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('cliente_a_id', sa.Integer(), nullable=False),
        sa.Column('cliente_b_id', sa.Integer(), nullable=False),
        sa.Column('creato_il', sa.DateTime(), nullable=False),
        sa.Column('creato_da', sa.String(length=120), nullable=False),
        sa.ForeignKeyConstraint(['cliente_a_id'], ['clienti.id'], name=op.f('fk_clienti_doppioni_esclusi_cliente_a_id_clienti'), ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['cliente_b_id'], ['clienti.id'], name=op.f('fk_clienti_doppioni_esclusi_cliente_b_id_clienti'), ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id', name=op.f('pk_clienti_doppioni_esclusi')),
        sa.UniqueConstraint('cliente_a_id', 'cliente_b_id', name='uq_clienti_doppioni_esclusi'),
    )
    with op.batch_alter_table('clienti_doppioni_esclusi', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_clienti_doppioni_esclusi_cliente_a_id'), ['cliente_a_id'], unique=False)
        batch_op.create_index(batch_op.f('ix_clienti_doppioni_esclusi_cliente_b_id'), ['cliente_b_id'], unique=False)
    for tabella in ('verifiche', 'dm_incarichi'):
        with op.batch_alter_table(tabella, schema=None) as batch_op:
            batch_op.add_column(sa.Column('indipendenza_esclusa', sa.Text(), server_default='', nullable=False))
    _recupera_origini()


def _recupera_origini() -> None:
    conn = op.get_bind()
    righe = []

    def aggiungi(sistema, tabella, id_origine, entita, entita_id, nota):
        righe.append({'sistema': sistema, 'tabella': tabella, 'id_origine': str(id_origine), 'entita': entita,
                      'entita_id': entita_id, 'nota': nota})

    for tabella_gi, tabella_dm, entita, sql in (
            ('clienti', 'clienti', 'cliente', "SELECT id, codice_esterno, note FROM clienti"),
            ('clienti_sedi_operative', 'clienti_sedi_operative', 'sede', "SELECT id, codice_esterno, '' FROM sedi"),
            ('impianti', None, 'impianto', "SELECT id, codice_esterno, '' FROM impianti")):
        for i, codice, note in conn.execute(sa.text(sql)):
            for parte in (p.strip() for p in str(codice or '').split('·')):
                if re.fullmatch(r'\d+', parte):
                    aggiungi('garda_ingecert', tabella_gi, parte, entita, i, 'recuperata dal «Rif. gestionale attuale» (0018)')
                elif tabella_dm and re.fullmatch(r'dm:\d+', parte):
                    aggiungi('garda_adsrl', tabella_dm, parte[3:], entita, i, 'recuperata dal «Rif. gestionale attuale» (0018)')
            if entita == 'cliente':
                for n in re.findall(r'adsrl codice (\d+)', note or ''):
                    aggiungi('garda_adsrl', 'clienti', n, entita, i, 'cliente fuso con adsrl, recuperata dalle note (0018)')
    visti = set()
    for r in righe:
        k = (r['sistema'], r['tabella'], r['id_origine'])
        if k in visti:
            continue
        visti.add(k)
        conn.execute(sa.text("INSERT INTO origini (sistema, tabella, id_origine, entita, entita_id, creato_il, nota) "
                             "VALUES (:sistema, :tabella, :id_origine, :entita, :entita_id, CURRENT_TIMESTAMP, :nota)"), r)


def downgrade() -> None:
    for tabella in ('dm_incarichi', 'verifiche'):
        with op.batch_alter_table(tabella, schema=None) as batch_op:
            batch_op.drop_column('indipendenza_esclusa')
    with op.batch_alter_table('clienti_doppioni_esclusi', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_clienti_doppioni_esclusi_cliente_b_id'))
        batch_op.drop_index(batch_op.f('ix_clienti_doppioni_esclusi_cliente_a_id'))
    op.drop_table('clienti_doppioni_esclusi')
    with op.batch_alter_table('origini', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_origini_entita_id'))
        batch_op.drop_index(batch_op.f('ix_origini_entita'))
    op.drop_table('origini')
