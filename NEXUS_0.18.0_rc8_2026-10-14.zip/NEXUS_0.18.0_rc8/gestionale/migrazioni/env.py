"""Ambiente delle migrazioni (Alembic). Le migrazioni si applicano da sole all'avvio del programma,
dopo un backup automatico (vedi core/migrazioni.py). Su SQLite si usa la modalità «batch»."""

from alembic import context
from sqlalchemy import create_engine

from gestionale.modelli import Base

config = context.config
target_metadata = Base.metadata


def run_migrations_online() -> None:
    connessione = config.attributes.get("connessione")
    if connessione is not None:
        context.configure(connection=connessione, target_metadata=target_metadata, render_as_batch=True)
        with context.begin_transaction():
            context.run_migrations()
        return
    motore = create_engine(config.get_main_option("sqlalchemy.url"))
    with motore.connect() as conn:
        context.configure(connection=conn, target_metadata=target_metadata, render_as_batch=True)
        with context.begin_transaction():
            context.run_migrations()


run_migrations_online()
