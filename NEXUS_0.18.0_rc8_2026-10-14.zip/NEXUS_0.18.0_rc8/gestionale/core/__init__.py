"""Servizi di base comuni a tutti i moduli: configurazione, database, sicurezza, permessi, registro, griglie."""
