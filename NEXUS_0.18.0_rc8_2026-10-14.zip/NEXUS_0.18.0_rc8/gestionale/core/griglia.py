"""Motore comune delle griglie (decisioni D18, D33, D34).

Ogni elenco del programma è una `Griglia`: colonne con tipo, filtro e ordinamento. Il browser
(libreria Tabulator) chiede una pagina alla volta; filtri, ordinamento, conteggio e totali li fa
SEMPRE il server, così anche con 10 anni di dati si muovono solo le righe visibili.

Sintassi dei filtri per colonna (uguale per tutte le griglie, spiegata anche nell'interfaccia):
- testo: parte del testo, maiuscole/minuscole indifferenti;
- numeri e importi: `100`, `>100`, `>=100`, `<50`, `<=50`, `10..20` (da 10 a 20); virgola decimale ammessa;
- date: `04/10/2026`, `10/2026` (mese), `2026` (anno), `>04/10/2026`, `<=31/12/2025`, `01/01/2026..31/03/2026`;
- sì/no ed elenchi: scelta dal menu a tendina;
- `vuoto` trova i campi non compilati.
"""

from __future__ import annotations

import io
import operator
import re
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Any
from collections.abc import Callable

from sqlalchemy import and_, func, or_, select
from sqlalchemy.orm import Session

from .date import formatta_dataora, locale_a_utc, utc_a_locale
from .errori import ErroreUtente

TIPI = ("testo", "numero", "importo", "data", "dataora", "booleano", "elenco")
DIMENSIONI_PAGINA = (25, 50, 100, 250, 500)
MASSIMO_RIGHE_ESPORTAZIONE = 500_000


@dataclass
class Colonna:
    campo: str
    etichetta: str
    tipo: str = "testo"
    espressione: Any = None                  # espressione SQL (griglie da database)
    filtrabile: bool = True
    ordinabile: bool = True
    visibile: bool = True                    # visibile all'inizio (l'utente può cambiarlo)
    larghezza: int | None = None
    somma: bool = False                      # totale in fondo (importi e numeri)
    opzioni: tuple[str, ...] = ()            # valori per il menu a tendina dei tipi «elenco»
    descrizione: str = ""
    calcolata: bool = False                  # valore calcolato dal programma riga per riga (non filtrabile né ordinabile)

    def __post_init__(self) -> None:
        if self.tipo not in TIPI:
            raise ValueError(f"Tipo di colonna sconosciuto: {self.tipo}")
        if self.calcolata:
            self.filtrabile = self.ordinabile = False

    def per_interfaccia(self) -> dict:
        return {"campo": self.campo, "etichetta": self.etichetta, "tipo": self.tipo, "filtrabile": self.filtrabile,
                "ordinabile": self.ordinabile, "visibile": self.visibile, "larghezza": self.larghezza,
                "somma": self.somma, "opzioni": list(self.opzioni), "descrizione": self.descrizione}


@dataclass
class Griglia:
    codice: str
    titolo: str
    colonne: list[Colonna]
    permesso: str                                            # serve per vedere la griglia
    ordine_predefinito: list[tuple[str, str]] = field(default_factory=list)
    chiave: str = "id"
    # Griglie da database: tabella/join di partenza e condizione eventuale (es. «solo i miei incarichi»)
    da: Callable[[], Any] | None = None
    condizione: Callable[[Any], Any] | None = None           # riceve l'utente corrente
    # Griglie da elenco in memoria (pochi elementi, es. i file di backup)
    righe: Callable[[Any, Any], list[dict]] | None = None    # riceve (archivio, utente)
    # Colonne «calcolate»: riceve (sessione, righe della pagina) e aggiunge i valori (es. tariffa proposta)
    arricchisci: Callable[[Session, list[dict]], None] | None = None
    # Ambito di lavoro (R114): riceve «DPR», «DM» o «IEC» e restituisce la condizione «solo quelli di quell'ambito»
    ambito: Callable[[str], Any] | None = None
    # 0.12.10 (doc. 30, maschere di Federico): vista di partenza per attività («DM», «DPR», «» = tutte), usata quando
    # l'utente non ha una configurazione predefinita: {"colonne": [campi visibili, in ordine], "raggruppa": campo,
    # "filtri": [(campo, valore)]}. L'utente cambia tutto e salva le sue configurazioni come prima.
    viste_predefinite: dict[str, dict] = field(default_factory=dict)

    contesto_campo: str = ""  # C23: elenco obbligatoriamente relativo a un solo preventivo
    gruppi_per_scadenza: str = ""  # data che determina l'urgenza dell'intero gruppo filtrato
    raggruppamenti: list[str] = field(default_factory=list)

    def campi_raggruppamento(self) -> list[str]:
        if self.raggruppamenti:
            return self.raggruppamenti
        preferiti = [c.campo for c in self.colonne if c.campo in
                     ("cliente_ragione_sociale", "sede_operativa", "sede_denominazione")]
        altri = [c.campo for c in self.colonne if c.visibile and c.ordinabile
                 and c.tipo in ("testo", "elenco", "booleano") and c.campo not in preferiti]
        return preferiti + altri

    def colonna(self, campo: str) -> Colonna:
        for c in self.colonne:
            if c.campo == campo:
                return c
        raise ErroreUtente(f"Colonna sconosciuta «{campo}»: ricarica la pagina.")

    def per_interfaccia(self) -> dict:
        return {"codice": self.codice, "titolo": self.titolo, "chiave": self.chiave,
                "colonne": [c.per_interfaccia() for c in self.colonne],
                "ordine_predefinito": [{"campo": c, "direzione": d} for c, d in self.ordine_predefinito],
                "dimensioni_pagina": list(DIMENSIONI_PAGINA), "filtra_ambito": self.ambito is not None,
                "contesto_campo": self.contesto_campo, "raggruppamenti": self.campi_raggruppamento(),
                "gruppi_per_scadenza": self.gruppi_per_scadenza,
                "viste_predefinite": {k: {"colonne": list(v.get("colonne", [])), "raggruppa": v.get("raggruppa", ""),
                                          "filtri": [{"campo": c, "valore": x} for c, x in v.get("filtri", [])]}
                                      for k, v in self.viste_predefinite.items()}}


REGISTRO_GRIGLIE: dict[str, Griglia] = {}


def registra(g: Griglia) -> Griglia:
    REGISTRO_GRIGLIE[g.codice] = g
    return g


# ---------------------------------------------------------------- interpretazione dei filtri


@dataclass
class Condizione:
    tipo: str                # contiene | confronto | tra | vuoto
    operatore: str = "="
    valore: Any = None
    fino: Any = None


OPERATORI = {"=": operator.eq, ">": operator.gt, ">=": operator.ge, "<": operator.lt, "<=": operator.le}
RE_CONFRONTO = re.compile(r"^(>=|<=|>|<|=)\s*(.+)$")


def _numero(testo: str, colonna: Colonna) -> float | int:
    t = testo.strip().replace("€", "").replace(" ", "")
    if "," in t:
        t = t.replace(".", "").replace(",", ".")
    try:
        v = float(t)
    except ValueError:
        raise ErroreUtente(f"Filtro non valido nella colonna «{colonna.etichetta}»: scrivi un numero, ad esempio 100, >100, 10..20.") from None
    return int(round(v * 100)) if colonna.tipo == "importo" else v


def _intervallo_data(testo: str, colonna: Colonna) -> tuple[date, date]:
    """Da «gg/mm/aaaa», «mm/aaaa» o «aaaa» all'intervallo [inizio, fine) di giorni."""
    t = testo.strip()
    try:
        if re.fullmatch(r"\d{1,2}/\d{1,2}/\d{4}", t):
            g = datetime.strptime(t, "%d/%m/%Y").date()
            return g, g + timedelta(days=1)
        if re.fullmatch(r"\d{1,2}/\d{4}", t):
            m = datetime.strptime("01/" + t, "%d/%m/%Y").date()
            fine = date(m.year + (m.month // 12), m.month % 12 + 1, 1)
            return m, fine
        if re.fullmatch(r"\d{4}", t):
            a = int(t)
            return date(a, 1, 1), date(a + 1, 1, 1)
    except ValueError:
        pass
    raise ErroreUtente(f"Filtro non valido nella colonna «{colonna.etichetta}»: scrivi una data come 04/10/2026, 10/2026 o 2026 (anche con > < oppure 01/01/2026..31/03/2026).")


def interpreta(colonna: Colonna, testo: Any) -> Condizione | None:
    if testo is None:
        return None
    if isinstance(testo, dict):
        op = testo.get("operatore")
        if op == "vuoto":
            return Condizione("vuoto")
        if colonna.tipo == "testo" and op in ("contiene", "inizia", "finisce", "uguale"):
            valore = str(testo.get("valore") or "").strip()
            return Condizione(op, valore=valore) if valore else None
        if colonna.tipo in ("data", "dataora") and op == "intervallo":
            a, b = testo.get("da"), testo.get("a")
            if not a and not b:
                return None
            def giorno(v):
                try:
                    return date.fromisoformat(str(v))
                except ValueError:
                    raise ErroreUtente(f"Data non valida nel filtro «{colonna.etichetta}».") from None
            da = giorno(a) if a else None
            try:
                fino = giorno(b) + timedelta(days=1) if b else None
            except OverflowError:
                raise ErroreUtente("La data finale supera il limite consentito.") from None
            if da and fino and da >= fino:
                raise ErroreUtente("La data iniziale deve precedere o coincidere con quella finale.")
            if da and fino:
                return Condizione("tra", valore=da, fino=fino)
            return Condizione("confronto", ">=" if da else "<", da or fino)
        raise ErroreUtente(f"Operatore non valido nel filtro «{colonna.etichetta}».")
    if isinstance(testo, bool):
        return Condizione("confronto", "=", testo)
    t = str(testo).strip()
    if not t:
        return None
    if t.lower() == "vuoto":
        return Condizione("vuoto")
    if colonna.tipo == "testo":
        return Condizione("contiene", valore=t)
    if colonna.tipo == "elenco":
        return Condizione("confronto", "=", t)
    if colonna.tipo == "booleano":
        vero = t.lower() in ("sì", "si", "true", "1", "vero", "s")
        return Condizione("confronto", "=", vero)
    if colonna.tipo in ("numero", "importo"):
        if ".." in t:
            a, b = t.split("..", 1)
            return Condizione("tra", valore=_numero(a, colonna), fino=_numero(b, colonna))
        m = RE_CONFRONTO.match(t)
        if m:
            return Condizione("confronto", m.group(1), _numero(m.group(2), colonna))
        return Condizione("confronto", "=", _numero(t, colonna))
    # date: si lavora per giorni interi
    if ".." in t:
        a, b = t.split("..", 1)
        return Condizione("tra", valore=_intervallo_data(a, colonna)[0], fino=_intervallo_data(b, colonna)[1])
    m = RE_CONFRONTO.match(t)
    op, resto = (m.group(1), m.group(2)) if m else ("=", t)
    inizio, fine = _intervallo_data(resto, colonna)
    if op == "=":
        return Condizione("tra", valore=inizio, fino=fine)
    if op == ">":
        return Condizione("confronto", ">=", fine)
    if op == ">=":
        return Condizione("confronto", ">=", inizio)
    if op == "<":
        return Condizione("confronto", "<", inizio)
    return Condizione("confronto", "<", fine)  # <=


def _limite_data(colonna: Colonna, giorno: date) -> Any:
    """Per le colonne data/ora (salvate in UTC) il giorno italiano va convertito in UTC."""
    if colonna.tipo == "dataora":
        return locale_a_utc(datetime(giorno.year, giorno.month, giorno.day))
    return giorno


def _escape_like(t: str) -> str:
    return t.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def condizione_sql(colonna: Colonna, c: Condizione) -> Any:
    e = colonna.espressione
    if c.tipo == "vuoto":
        return or_(e.is_(None), e == "") if colonna.tipo in ("testo", "elenco") else e.is_(None)
    if c.tipo in ("contiene", "inizia", "finisce", "uguale"):
        t = _escape_like(c.valore.lower())
        if c.tipo == "uguale":
            return func.lower(e) == c.valore.lower()
        modello = {"contiene": f"%{t}%", "inizia": f"{t}%", "finisce": f"%{t}"}[c.tipo]
        return func.lower(e).like(modello, escape="\\")
    valore, fino = c.valore, c.fino
    if colonna.tipo in ("data", "dataora"):
        valore = _limite_data(colonna, valore)
        fino = _limite_data(colonna, fino) if fino is not None else None
        if c.tipo == "tra":
            return and_(e >= valore, e < fino)
    if c.tipo == "tra":
        return and_(e >= valore, e <= fino)
    if colonna.tipo == "booleano":
        return e.is_(True) if valore else or_(e.is_(False), e.is_(None))
    return OPERATORI[c.operatore](e, valore)  # solo l'operatore scelto (con sì/no gli altri non sono ammessi)


def _confronta(v: Any, op: str, x: Any) -> bool:
    if v is None:
        return False
    return {"=": v == x, ">": v > x, ">=": v >= x, "<": v < x, "<=": v <= x}[op]


def condizione_lista(colonna: Colonna, c: Condizione) -> Callable[[dict], bool]:
    campo = colonna.campo

    def valore_di(riga: dict) -> Any:
        v = riga.get(campo)
        if colonna.tipo == "dataora" and isinstance(v, datetime):
            return v  # già in UTC come nel database
        return v

    if c.tipo == "vuoto":
        return lambda r: valore_di(r) in (None, "")
    if c.tipo in ("contiene", "inizia", "finisce", "uguale"):
        cercato = c.valore.lower()
        def confronta_testo(r):
            v = valore_di(r)
            if v is None:
                return False
            t = str(v).lower()
            return {"contiene": lambda: cercato in t, "inizia": lambda: t.startswith(cercato),
                    "finisce": lambda: t.endswith(cercato), "uguale": lambda: t == cercato}[c.tipo]()
        return confronta_testo
    valore, fino = c.valore, c.fino
    if colonna.tipo in ("data", "dataora"):
        valore = _limite_data(colonna, valore)
        fino = _limite_data(colonna, fino) if fino is not None else None
        if c.tipo == "tra":
            return lambda r: valore_di(r) is not None and valore <= valore_di(r) < fino
    if c.tipo == "tra":
        return lambda r: valore_di(r) is not None and valore <= valore_di(r) <= fino
    return lambda r: _confronta(valore_di(r), c.operatore, valore)


# ---------------------------------------------------------------- richiesta


@dataclass
class Richiesta:
    pagina: int = 1
    dimensione: int = 25
    ricerca: str = ""
    filtri: dict[str, Any] = field(default_factory=dict)
    ordinamenti: list[tuple[str, str]] = field(default_factory=list)
    ambito: str = ""   # vuoto = tutti
    contesto: int | None = None
    raggruppa: str = ""

    @classmethod
    def da_json(cls, g: Griglia, dati: dict) -> "Richiesta":
        dimensione = int(dati.get("dimensione") or 25)
        if dimensione not in DIMENSIONI_PAGINA:
            dimensione = 25
        filtri = {}
        for f in dati.get("filtri") or []:
            col = g.colonna(str(f.get("campo")))
            if col.filtrabile and f.get("valore") not in (None, ""):
                filtri[col.campo] = f.get("valore")
        contesto = None
        if g.contesto_campo:
            oggetto = dati.get("contesto") or {}
            if not isinstance(oggetto, dict):
                raise ErroreUtente("Il riferimento al preventivo non è valido.")
            raw = oggetto.get(g.contesto_campo)
            if raw is None:  # collegamenti della 0.16: accettati solo con identificativo esatto
                raw = filtri.get(g.contesto_campo)
            try:
                if isinstance(raw, bool) or str(int(raw)) != str(raw) or int(raw) <= 0:
                    raise ValueError
                contesto = int(raw)
            except (ValueError, TypeError):
                raise ErroreUtente("Apri le righe dagli elementi collegati di un singolo preventivo.") from None
        raggruppa = str(dati.get("raggruppa") or "")
        if raggruppa and not g.colonna(raggruppa).ordinabile:
            raise ErroreUtente("Raggruppamento non disponibile per questo elenco.")
        ordinamenti = []
        for o in dati.get("ordinamenti") or []:
            col = g.colonna(str(o.get("campo")))
            if col.ordinabile:
                ordinamenti.append((col.campo, "desc" if o.get("direzione") == "desc" else "asc"))
        return cls(pagina=max(1, int(dati.get("pagina") or 1)), dimensione=dimensione,
                   ricerca=str(dati.get("ricerca") or "").strip()[:200], filtri=filtri, contesto=contesto, raggruppa=raggruppa,
                   ordinamenti=ordinamenti or list(g.ordine_predefinito),
                   ambito=str(dati.get("ambito") or "") if g.ambito is not None and dati.get("ambito") in ("DPR", "DM", "IEC") else "")


# ---------------------------------------------------------------- esecuzione


def _valore_json(colonna: Colonna, v: Any) -> Any:
    if v is None:
        return None
    if colonna.tipo == "dataora" and isinstance(v, datetime):
        return utc_a_locale(v).isoformat(timespec="seconds")
    if colonna.tipo == "data" and isinstance(v, (date, datetime)):
        return v.isoformat()
    if colonna.tipo == "booleano":
        return bool(v)
    return v


def _query_sql(g: Griglia, utente: Any, r: Richiesta):  # noqa: ANN202
    condizioni = []
    if g.contesto_campo:
        if r.contesto is None:
            raise ErroreUtente("Manca il preventivo di riferimento.")
        condizioni.append(g.colonna(g.contesto_campo).espressione == r.contesto)
    if g.condizione is not None:
        condizioni.append(g.condizione(utente))
    if r.ambito and g.ambito is not None:
        condizioni.append(g.ambito(r.ambito))
    for campo, testo in r.filtri.items():
        col = g.colonna(campo)
        cond = interpreta(col, testo)
        if cond is not None:
            condizioni.append(condizione_sql(col, cond))
    if r.ricerca:
        testuali = [c for c in g.colonne if c.tipo in ("testo", "elenco") and c.filtrabile and not c.calcolata]
        cercato = f"%{_escape_like(r.ricerca.lower())}%"
        condizioni.append(or_(*[func.lower(c.espressione).like(cercato, escape="\\") for c in testuali]))
    return condizioni


def _ordina_sql(g: Griglia, r: Richiesta) -> list:
    clausole = []
    if r.raggruppa and g.gruppi_per_scadenza:
        gruppo = g.colonna(r.raggruppa).espressione
        scadenza = g.colonna(g.gruppi_per_scadenza).espressione
        prima = func.min(scadenza).over(partition_by=gruppo)
        # Il minimo è calcolato sull'intero risultato filtrato, prima della paginazione.
        clausole.extend([prima.is_(None), prima.asc(), gruppo.is_(None), gruppo.asc(),
                         scadenza.is_(None), scadenza.asc()])
    for campo, direzione in r.ordinamenti:
        e = g.colonna(campo).espressione
        if getattr(e, "nullable", True):  # i vuoti in fondo (solo se la colonna può essere vuota: così si usano gli indici)
            clausole.append(e.is_(None))
        clausole.append(e.desc() if direzione == "desc" else e.asc())
    chiave = g.colonna(g.chiave).espressione if any(c.campo == g.chiave for c in g.colonne) else None
    if chiave is not None:
        clausole.append(chiave.desc())
    return clausole


def _da_database(g: Griglia, colonne: list[Colonna]) -> list[Colonna]:
    """Colonne da leggere nel database: quelle non calcolate, più la chiave se servono colonne calcolate."""
    scelte = [c for c in colonne if not c.calcolata]
    if any(c.calcolata for c in colonne) and all(c.campo != g.chiave for c in scelte):
        scelte.append(g.colonna(g.chiave))
    return scelte


def _seleziona(g: Griglia, colonne: list[Colonna]):  # noqa: ANN202
    return select(*[c.espressione.label(c.campo) for c in _da_database(g, colonne)]).select_from(g.da())


def _righe_lista(g: Griglia, archivio: Any, utente: Any, r: Richiesta) -> list[dict]:
    righe = g.righe(archivio, utente)
    for campo, testo in r.filtri.items():
        col = g.colonna(campo)
        cond = interpreta(col, testo)
        if cond is not None:
            pred = condizione_lista(col, cond)
            righe = [x for x in righe if pred(x)]
    if r.ricerca:
        cercato = r.ricerca.lower()
        testuali = [c.campo for c in g.colonne if c.tipo in ("testo", "elenco")]
        righe = [x for x in righe if any(cercato in str(x.get(c) or "").lower() for c in testuali)]
    for campo, direzione in reversed(r.ordinamenti):  # ordinamento stabile, dal criterio meno importante
        pieni = [x for x in righe if x.get(campo) is not None]
        vuoti = [x for x in righe if x.get(campo) is None]  # i vuoti sempre in fondo
        pieni.sort(key=lambda x: x[campo], reverse=(direzione == "desc"))
        righe = pieni + vuoti
    return righe


def dati(g: Griglia, s: Session, archivio: Any, utente: Any, r: Richiesta) -> dict:
    """Una pagina di righe, il totale delle righe trovate e i totali delle colonne «somma»."""
    if g.righe is not None:
        tutte = _righe_lista(g, archivio, utente, r)
        totale = len(tutte)
        pagina = tutte[(r.pagina - 1) * r.dimensione: r.pagina * r.dimensione]
        righe = [{c.campo: _valore_json(c, x.get(c.campo)) for c in g.colonne} for x in pagina]
        somme = {c.campo: sum((x.get(c.campo) or 0) for x in tutte) for c in g.colonne if c.somma}
    else:
        condizioni = _query_sql(g, utente, r)
        conteggio = select(func.count()).select_from(g.da())
        if condizioni:
            conteggio = conteggio.where(*condizioni)
        totale = s.execute(conteggio).scalar() or 0
        q = _seleziona(g, g.colonne)
        if condizioni:
            q = q.where(*condizioni)
        q = q.order_by(*_ordina_sql(g, r)).limit(r.dimensione).offset((r.pagina - 1) * r.dimensione)
        grezze = [dict(riga._mapping) for riga in s.execute(q)]
        if g.arricchisci is not None and grezze:
            g.arricchisci(s, grezze)
        righe = [{c.campo: _valore_json(c, x.get(c.campo)) for c in g.colonne} for x in grezze]
        somme = {}
        da_sommare = [c for c in g.colonne if c.somma]
        if da_sommare:
            qs = select(*[func.coalesce(func.sum(c.espressione), 0).label(c.campo) for c in da_sommare]).select_from(g.da())
            if condizioni:
                qs = qs.where(*condizioni)
            riga = s.execute(qs).one()
            somme = {c.campo: getattr(riga, c.campo) for c in da_sommare}
    pagine = max(1, -(-totale // r.dimensione))
    return {"righe": righe, "totale": totale, "pagine": pagine, "pagina": min(r.pagina, pagine), "somme": somme}


# ---------------------------------------------------------------- esportazione Excel (D34)


def _valore_excel(colonna: Colonna, v: Any) -> Any:
    if v is None:
        return None
    if colonna.tipo == "dataora" and isinstance(v, datetime):
        return utc_a_locale(v).replace(tzinfo=None)
    if colonna.tipo == "importo":
        return v / 100
    if colonna.tipo == "booleano":
        return "Sì" if v else "No"
    return v


def esporta(g: Griglia, s: Session, archivio: Any, utente: Any, r: Richiesta, campi_visibili: list[str]) -> tuple[bytes, int]:
    """Excel della vista corrente: solo le colonne visibili, nell'ordine mostrato, con i filtri applicati."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    colonne = [g.colonna(c) for c in campi_visibili]
    if not colonne:
        raise ErroreUtente("Nessuna colonna visibile da esportare: mostra almeno una colonna.")
    wb = Workbook()
    ws = wb.active
    ws.title = g.titolo[:31]
    ws.append([c.etichetta for c in colonne])
    for cella in ws[1]:
        cella.font = Font(bold=True, color="FFFFFF")
        cella.fill = PatternFill("solid", fgColor="101F38")
        cella.alignment = Alignment(vertical="center")
    n = 0
    if g.righe is not None:
        sorgente = ({c.campo: x.get(c.campo) for c in colonne} for x in _righe_lista(g, archivio, utente, r))
    else:
        condizioni = _query_sql(g, utente, r)
        q = _seleziona(g, colonne)
        if condizioni:
            q = q.where(*condizioni)
        q = q.order_by(*_ordina_sql(g, r)).limit(MASSIMO_RIGHE_ESPORTAZIONE)
        sorgente = _righe_esportazione(g, s, q, colonne)
    for riga in sorgente:
        ws.append([_valore_excel(c, riga.get(c.campo)) for c in colonne])
        n += 1
        if n >= MASSIMO_RIGHE_ESPORTAZIONE:
            break
    for i, c in enumerate(colonne, start=1):
        lettera = get_column_letter(i)
        ws.column_dimensions[lettera].width = max(12, min(60, len(c.etichetta) + 4, (c.larghezza or 160) // 7))
        formato = {"dataora": "DD/MM/YYYY HH:MM", "data": "DD/MM/YYYY", "importo": '#,##0.00 "€"'}.get(c.tipo)
        if formato:
            for (cella,) in ws.iter_rows(min_row=2, min_col=i, max_col=i):
                cella.number_format = formato
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    buffer = io.BytesIO()
    wb.save(buffer)
    return buffer.getvalue(), n


def _righe_esportazione(g: Griglia, s: Session, q: Any, colonne: list[Colonna]):  # noqa: ANN202
    calcolate = g.arricchisci is not None and any(c.calcolata for c in colonne)
    blocco: list[dict] = []
    for riga in s.execute(q).yield_per(2000):
        blocco.append(dict(riga._mapping))
        if len(blocco) >= 2000:
            if calcolate:
                g.arricchisci(s, blocco)
            yield from blocco
            blocco = []
    if blocco:
        if calcolate:
            g.arricchisci(s, blocco)
        yield from blocco


def descrivi_filtri(g: Griglia, r: Richiesta) -> str:
    parti = [f"{g.colonna(c).etichetta}: {v}" for c, v in r.filtri.items()]
    if r.contesto is not None:
        parti.insert(0, f"{g.colonna(g.contesto_campo).etichetta}: {r.contesto} (contesto obbligatorio)")
    if r.raggruppa:
        parti.insert(0, f"raggruppamento: {g.colonna(r.raggruppa).etichetta}")
    if r.ambito:
        parti.insert(0, f"solo ambito {r.ambito}")
    if r.ricerca:
        parti.insert(0, f"ricerca: {r.ricerca}")
    return "; ".join(parti) or "nessun filtro"


__all__ = ["Colonna", "Griglia", "Richiesta", "registra", "dati", "esporta", "REGISTRO_GRIGLIE", "formatta_dataora"]
