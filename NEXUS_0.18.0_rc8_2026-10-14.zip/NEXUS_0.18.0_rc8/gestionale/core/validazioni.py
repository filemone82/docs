"""Controlli di formato dei dati italiani (partita IVA, codice fiscale, SDI, IBAN, POD, email, CAP).

Ogni funzione `normalizza_*` restituisce il valore ripulito (maiuscolo, senza spazi) oppure solleva
ErroreUtente con un messaggio che dice cosa correggere. Le funzioni `*_valida` rispondono sì/no e
servono all'importazione, che segnala i problemi invece di fermarsi.
"""

from __future__ import annotations

import re

from .errori import ErroreUtente

RE_EMAIL = re.compile(r"^[^@\s;,]+@[^@\s;,]+\.[A-Za-z]{2,}$")
RE_POD = re.compile(r"^IT\d{3}E[0-9A-Z]{7,9}$")
RE_CF_PERSONA = re.compile(r"^[A-Z]{6}[0-9LMNPQRSTUV]{2}[ABCDEHLMPRST][0-9LMNPQRSTUV]{2}[A-Z][0-9LMNPQRSTUV]{3}[A-Z]$")

_DISPARI = {**{str(i): v for i, v in enumerate([1, 0, 5, 7, 9, 13, 15, 17, 19, 21])},
            **dict(zip("ABCDEFGHIJKLMNOPQRSTUVWXYZ",
                       [1, 0, 5, 7, 9, 13, 15, 17, 19, 21, 2, 4, 18, 20, 11, 3, 6, 8, 12, 14, 16, 10, 22, 25, 24, 23]))}


def numero_italiano(v: object) -> float:
    """«1.234,5» → 1234.5; «1.000» → 1000; «12.5» → 12.5. Solleva ValueError se non è un numero."""
    if isinstance(v, (int, float)):
        return float(v)
    t = str(v).strip().replace("€", "").replace(" ", "")
    if "," in t:
        t = t.replace(".", "").replace(",", ".")
    elif re.fullmatch(r"-?\d{1,3}(\.\d{3})+", t):
        t = t.replace(".", "")
    return float(t)


def _pulisci(v: object) -> str:
    return re.sub(r"\s+", "", str(v or "")).upper()


# ---------------------------------------------------------------- partita IVA e codice fiscale


def partita_iva_valida(p: str) -> bool:
    if not re.fullmatch(r"\d{11}", p or ""):
        return False
    totale = 0
    for i, c in enumerate(p[:10]):
        d = int(c)
        if i % 2:
            d *= 2
            if d > 9:
                d -= 9
        totale += d
    return (10 - totale % 10) % 10 == int(p[10])


def codice_fiscale_valido(cf: str) -> bool:
    """Codice fiscale di persona (16 caratteri) o numerico di società/ente (11 cifre, come la P.IVA)."""
    if re.fullmatch(r"\d{11}", cf or ""):
        return partita_iva_valida(cf)
    if not RE_CF_PERSONA.fullmatch(cf or ""):
        return False
    pari = {**{str(i): i for i in range(10)}, **{c: i for i, c in enumerate("ABCDEFGHIJKLMNOPQRSTUVWXYZ")}}
    somma = sum(_DISPARI[c] if i % 2 == 0 else pari[c] for i, c in enumerate(cf[:15]))
    return chr(ord("A") + somma % 26) == cf[15]


def recupera_numero(v: object, cifre: int = 11) -> str:
    """Rimette gli zeri iniziali persi da Excel (es. 1234567890 → 01234567890)."""
    if v is None or v == "":
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    t = _pulisci(v)
    if t.isdigit() and len(t) < cifre:
        t = t.zfill(cifre)
    return t


def normalizza_partita_iva(v: object, nazione: str = "IT") -> str:
    p = _pulisci(v)
    if p.startswith("IT") and nazione == "IT":
        p = p[2:]
    if not p:
        return ""
    if nazione != "IT":
        return p[:20]
    if p.isdigit() and len(p) < 11:
        p = p.zfill(11)
    if not partita_iva_valida(p):
        raise ErroreUtente(f"Partita IVA «{p}» non valida: deve avere 11 cifre e l'ultima cifra di controllo deve tornare. Ricontrolla sul documento del cliente.")
    return p


def normalizza_codice_fiscale(v: object, nazione: str = "IT") -> str:
    c = _pulisci(v)
    if not c:
        return ""
    if nazione != "IT":
        return c[:20]
    if c.isdigit() and len(c) < 11:
        c = c.zfill(11)
    if not codice_fiscale_valido(c):
        raise ErroreUtente(f"Codice fiscale «{c}» non valido: 16 caratteri per le persone, 11 cifre per società ed enti. Ricontrolla.")
    return c


# ---------------------------------------------------------------- fattura elettronica


def normalizza_sdi(v: object) -> str:
    """Codice destinatario: 7 caratteri per i privati, 6 (codice ufficio) per la PA; «0000000» = nessuno."""
    s = _pulisci(v)
    if s in ("", "0", "NAN"):
        return ""
    if not re.fullmatch(r"[A-Z0-9]{6,7}", s):
        raise ErroreUtente(f"Codice destinatario SDI «{s}» non valido: 7 caratteri (privati) o 6 (codice ufficio della PA).")
    return s


def normalizza_iban(v: object) -> str:
    i = _pulisci(v)
    if not i:
        return ""
    if not re.fullmatch(r"[A-Z]{2}\d{2}[A-Z0-9]{10,30}", i):
        raise ErroreUtente(f"IBAN «{i}» non valido: controlla lettere e numeri.")
    numero = "".join(str(int(c, 36)) for c in i[4:] + i[:4])
    if int(numero) % 97 != 1:
        raise ErroreUtente(f"IBAN «{i}» non valido: le cifre di controllo non tornano. Ricontrolla.")
    if i.startswith("IT") and len(i) != 27:
        raise ErroreUtente(f"IBAN italiano «{i}» non valido: deve avere 27 caratteri.")
    return i


# ---------------------------------------------------------------- contatti e indirizzi


def dividi_email(v: object) -> list[str]:
    return [x.strip() for x in re.split(r"[;,\s]+", str(v or "")) if x.strip()]


def normalizza_email(v: object, etichetta: str = "Email", multipla: bool = True) -> str:
    """Uno o più indirizzi separati da «;» (D41: i verbali possono andare a più destinatari)."""
    indirizzi = dividi_email(v)
    if not multipla and len(indirizzi) > 1:
        raise ErroreUtente(f"{etichetta}: scrivi un solo indirizzo.")
    for e in indirizzi:
        if not RE_EMAIL.match(e):
            raise ErroreUtente(f"{etichetta}: «{e}» non è un indirizzo valido (forma nome@dominio.it).")
    return "; ".join(indirizzi)


def email_valide(v: object) -> bool:
    try:
        normalizza_email(v)
        return True
    except ErroreUtente:
        return False


def normalizza_cap(v: object) -> str:
    c = recupera_numero(v, 5)
    if c and not re.fullmatch(r"\d{5}", c):
        raise ErroreUtente(f"CAP «{c}» non valido: 5 cifre.")
    return c


def normalizza_telefono(v: object) -> str:
    """Telefono così come scritto; se è un numero fisso che ha perso lo zero iniziale lo rimette."""
    if v is None:
        return ""
    if isinstance(v, (int, float)):
        t = str(int(v))
        return t if t.startswith("3") else "0" + t
    return str(v).strip()[:60]


# ---------------------------------------------------------------- POD


def normalizza_pod(v: object) -> str:
    p = _pulisci(v)
    if not RE_POD.fullmatch(p):
        raise ErroreUtente(f"Codice POD «{p}» non valido: ha la forma IT + 3 cifre + E + 8 cifre (es. IT001E12345678).")
    return p


def estrai_pod(testo: object) -> tuple[list[str], str]:
    """Da un campo scritto a mano separa i POD validi dal resto (es. numeri cliente), che finisce nelle note."""
    t = str(testo or "").upper()
    trovati = []
    for m in re.finditer(r"IT\s?\d{3}\s?E\s?[0-9A-Z]{7,9}", t):
        pod = _pulisci(m.group(0))
        if RE_POD.fullmatch(pod) and pod not in trovati:
            trovati.append(pod)
    resto = re.sub(r"IT\s?\d{3}\s?E\s?[0-9A-Z]{7,9}", "", str(testo or ""), flags=re.I)
    resto = re.sub(r"^[\s\-–,;/]+|[\s\-–,;/]+$", "", resto).strip()
    return trovati, resto
