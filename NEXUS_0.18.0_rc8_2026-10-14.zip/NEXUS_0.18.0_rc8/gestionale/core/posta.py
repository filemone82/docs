"""Invio email (ripreso da VerbalizzAI 0.3.24, solo libreria standard).

Le impostazioni del server di posta stanno nel file `posta.json` nella cartella dei dati, FUORI dal
database e quindi fuori dai backup (contiene la password della casella, convenzione 03 § 3). La password
non viene mai rimandata al browser. I testi standard delle email stanno nelle impostazioni del database.
"""

from __future__ import annotations

import json
import os
import re
import smtplib
import socket
import ssl
from email.message import EmailMessage
from email.utils import formataddr, formatdate, make_msgid
from pathlib import Path

from .errori import ErroreUtente

PREDEFINITE = {"server": "smtps.aruba.it", "porta": 465, "sicurezza": "ssl", "utente": "elettrico@adsrl.net", "password": "",
               "mittente": "elettrico@adsrl.net", "nome_mittente": "AD S.r.l.", "copia_ufficio": "elettrico@adsrl.net"}
SICUREZZA = ("ssl", "starttls", "nessuna")
INDIRIZZO = re.compile(r"^[A-Za-z0-9._%+\-']+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")


def dividi_indirizzi(testo: str) -> list[str]:
    risultato: list[str] = []
    for parte in re.split(r"[;,\s]+", str(testo or "")):
        parte = parte.strip().strip("<>")
        if not parte:
            continue
        if not INDIRIZZO.match(parte):
            raise ErroreUtente(f"Indirizzo email non valido: {parte}")
        if parte.lower() not in [x.lower() for x in risultato]:
            risultato.append(parte)
    return risultato


ATTIVITA = ("DPR", "DM", "IEC")
NOMI_ATTIVITA = {"DPR": "AD_DPR", "DM": "AD_DM", "IEC": "I&C"}


class ImpostazioniPosta:
    """C15 (0.16, Federico 12/10/2026: «impostazioni email vanno distinte per dm, dpr e iec»): una configurazione per
    attività nello stesso `posta.json` ({"attivita": {"DPR": {...}, "DM": {...}, "IEC": {...}}}). Un file delle
    versioni precedenti (una sola configurazione) vale per tutte e tre finché non se ne salva una."""

    def __init__(self, cartella: Path, attivita: str = "DPR") -> None:
        self.percorso = Path(cartella) / "posta.json"
        self.attivita = attivita if attivita in ATTIVITA else "DPR"

    def _file(self) -> dict:
        if self.percorso.exists():
            try:
                d = json.loads(self.percorso.read_text("utf-8"))
                return d if isinstance(d, dict) else {}
            except (OSError, ValueError):
                return {}
        return {}

    def _proprie(self, d: dict, attivita: str) -> dict:
        if isinstance(d.get("attivita"), dict):
            return dict(d["attivita"].get(attivita) or {})
        return {k: v for k, v in d.items() if k in PREDEFINITE}  # file della 0.15 o precedenti: vale per tutte

    def leggi(self) -> dict:
        cfg = dict(PREDEFINITE)
        cfg.update(self._proprie(self._file(), self.attivita))
        for nome in (f"GESTIONALE_SMTP_PASSWORD_{self.attivita}", "GESTIONALE_SMTP_PASSWORD"):
            if os.environ.get(nome):
                cfg["password"] = os.environ[nome]
                break
        return cfg

    def pubbliche(self) -> dict:
        cfg = self.leggi()
        pub = {k: cfg[k] for k in PREDEFINITE if k != "password"}
        pub["password_impostata"] = bool(cfg.get("password"))
        pub["configurata"] = bool(cfg["server"] and cfg["mittente"] and (cfg["password"] or cfg["sicurezza"] == "nessuna"))
        pub["file"] = str(self.percorso)
        pub["attivita"] = self.attivita
        pub["nome_attivita"] = NOMI_ATTIVITA[self.attivita]
        return pub

    def salva(self, dati: dict) -> dict:
        attuale = self.leggi()
        nuovo = {"server": str(dati.get("server") or "").strip(), "sicurezza": dati.get("sicurezza") if dati.get("sicurezza") in SICUREZZA else "ssl",
                 "utente": str(dati.get("utente") or "").strip(), "nome_mittente": str(dati.get("nome_mittente") or "").strip()[:80]}
        try:
            nuovo["porta"] = int(dati.get("porta"))
        except (TypeError, ValueError):
            raise ErroreUtente("Porta del server di posta non valida (465 per SSL, 587 per STARTTLS).") from None
        if not re.fullmatch(r"[A-Za-z0-9.\-]+", nuovo["server"]):
            raise ErroreUtente("Server di posta non valido: es. smtps.aruba.it")
        for chiave, etichetta in (("mittente", "mittente"), ("copia_ufficio", "copia per l'ufficio")):
            v = dividi_indirizzi(dati.get(chiave))
            if len(v) != 1:
                raise ErroreUtente(f"Indica un solo indirizzo {etichetta}.")
            nuovo[chiave] = v[0]
        nuovo["password"] = str(dati["password"]) if dati.get("password") else ("" if dati.get("cancella_password") else attuale.get("password", ""))
        d = self._file()
        tutte = {a: self._proprie(d, a) for a in ATTIVITA}
        tutte[self.attivita] = nuovo
        provvisorio = self.percorso.with_suffix(".tmp")
        provvisorio.write_text(json.dumps({"attivita": tutte}, ensure_ascii=False, indent=1), "utf-8")
        try:
            os.chmod(provvisorio, 0o600)
        except OSError:
            pass
        os.replace(provvisorio, self.percorso)
        return self.pubbliche()


def componi(cfg: dict, a: list[str], cc: list[str], oggetto: str, testo: str, allegati: list[tuple[str, bytes, str]]) -> EmailMessage:
    msg = EmailMessage()
    msg["From"] = formataddr((cfg.get("nome_mittente") or "", cfg["mittente"]))
    msg["To"] = ", ".join(a)
    if cc:
        msg["Cc"] = ", ".join(cc)
    msg["Reply-To"] = cfg["mittente"]
    msg["Subject"] = oggetto
    msg["Date"] = formatdate(localtime=True)
    msg["Message-ID"] = make_msgid(domain=cfg["mittente"].split("@")[-1])
    msg.set_content(testo)
    for nome, dati, tipo in allegati:
        principale, secondario = tipo.split("/", 1)
        msg.add_attachment(dati, maintype=principale, subtype=secondario, filename=nome)
    return msg


def invia(cfg: dict, msg: EmailMessage, tempo: int = 40) -> str:
    if not cfg.get("server"):
        raise ErroreUtente("Server di posta non impostato: vai in Sistema › Impostazioni email.")
    destinatari = [x for h in ("To", "Cc", "Bcc") for x in re.split(r"\s*,\s*", msg.get(h, "")) if x]
    try:
        if cfg["sicurezza"] == "ssl":
            s = smtplib.SMTP_SSL(cfg["server"], cfg["porta"], timeout=tempo, context=ssl.create_default_context())
        else:
            s = smtplib.SMTP(cfg["server"], cfg["porta"], timeout=tempo)
        with s:
            s.ehlo()
            if cfg["sicurezza"] == "starttls":
                s.starttls(context=ssl.create_default_context())
                s.ehlo()
            if cfg.get("utente") and cfg.get("password"):
                s.login(cfg["utente"], cfg["password"])
            rifiutati = s.send_message(msg, from_addr=cfg["mittente"], to_addrs=destinatari)
            if rifiutati:
                raise ErroreUtente("Il server ha rifiutato alcuni destinatari: " + ", ".join(rifiutati))
            return "Accettato dal server " + cfg["server"]
    except smtplib.SMTPAuthenticationError:
        raise ErroreUtente("Accesso alla casella non riuscito: controlla utente e password in Sistema › Impostazioni email.") from None
    except smtplib.SMTPRecipientsRefused as e:
        raise ErroreUtente("Il server ha rifiutato i destinatari: " + ", ".join(e.recipients)) from None
    except smtplib.SMTPException as e:
        raise ErroreUtente("Il server di posta ha risposto con un errore: " + str(e)[:300]) from None
    except ssl.SSLError as e:
        raise ErroreUtente(f"Connessione sicura non riuscita ({str(e)[:120]}): controlla porta e sicurezza (465 = SSL, 587 = STARTTLS).") from None
    except (socket.timeout, TimeoutError):
        raise ErroreUtente("Il server di posta non risponde (tempo scaduto): controlla server e porta.") from None
    except OSError as e:
        raise ErroreUtente(f"Server di posta non raggiungibile ({str(e)[:120]}): controlla nome del server, porta e connessione.") from None


def compila_testo(testo: str, valori: dict) -> str:
    """Sostituisce {campo}; i campi sconosciuti restano come scritti."""
    return re.sub(r"\{(\w+)\}", lambda m: str(valori[m.group(1)]) if m.group(1) in valori else m.group(0), testo or "")
