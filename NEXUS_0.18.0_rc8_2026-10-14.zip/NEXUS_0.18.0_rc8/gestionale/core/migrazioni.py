"""Migrazioni numerate dello schema dei dati (decisione D30).

All'avvio: se il database esiste ed è indietro rispetto al programma, prima si fa un backup
«pre_aggiornamento», poi si applicano le migrazioni. Se il database è PIÙ NUOVO del programma
(es. backup di una versione futura) ci si ferma: non si rischia di rovinare i dati.
"""

from __future__ import annotations

from pathlib import Path
import json

from alembic import command
from alembic.config import Config as ConfigAlembic
from alembic.runtime.migration import MigrationContext
from alembic.script import ScriptDirectory
from sqlalchemy import Engine, inspect, text

CARTELLA_MIGRAZIONI = Path(__file__).resolve().parents[1] / "migrazioni"


def config_alembic(url: str | None = None) -> ConfigAlembic:
    cfg = ConfigAlembic()
    cfg.set_main_option("script_location", str(CARTELLA_MIGRAZIONI))
    if url:
        cfg.set_main_option("sqlalchemy.url", url)
    return cfg


def revisione_programma() -> str:
    return ScriptDirectory.from_config(config_alembic()).get_current_head()


def revisione_database(motore: Engine) -> str | None:
    with motore.connect() as conn:
        return MigrationContext.configure(conn).get_current_revision()


def revisioni_note() -> set[str]:
    return {r.revision for r in ScriptDirectory.from_config(config_alembic()).walk_revisions()}


def aggiorna(motore: Engine) -> None:
    cfg = config_alembic()
    with motore.connect() as conn:
        cfg.attributes["connessione"] = conn
        if conn.dialect.name == "postgresql":
            with conn.begin():
                conn.execute(text("SELECT pg_advisory_xact_lock(:chiave)"), {"chiave": 462810180})
                corrente = MigrationContext.configure(conn).get_current_revision()
                if corrente is None:
                    # Nuovo backend: baseline 0027 congelata. Le migrazioni
                    # 0001–0027 ricostruiscono la storia SQLite e non vengono falsamente
                    # presentate come una catena PostgreSQL provata.
                    inspector = inspect(conn)
                    presenti = set()
                    for schema in inspector.get_schema_names():
                        if schema == "information_schema" or schema.startswith("pg_"):
                            continue
                        for t in inspector.get_table_names(schema=schema):
                            if t != "alembic_version" or schema != inspector.default_schema_name:
                                presenti.add(schema + "." + t)
                    if presenti:
                        raise RuntimeError("PostgreSQL contiene tabelle senza versione Nexus: usare un database dedicato vuoto.")
                    baseline = json.loads((CARTELLA_MIGRAZIONI / "baseline_postgresql_0027.json").read_text())
                    for statement in baseline["statements"]:
                        conn.exec_driver_sql(statement)
                    conn.execute(text("""CREATE FUNCTION nexus_registro_immutabile() RETURNS trigger
                        LANGUAGE plpgsql AS $$ BEGIN
                        RAISE EXCEPTION 'Il registro delle operazioni non può essere modificato o cancellato';
                        END; $$"""))
                    conn.execute(text("""CREATE TRIGGER registro_operazioni_immutabile
                        BEFORE UPDATE OR DELETE ON registro_operazioni
                        FOR EACH ROW EXECUTE FUNCTION nexus_registro_immutabile()"""))
                    command.stamp(cfg, "0027")
                command.upgrade(cfg, "head")
            return
        if conn.dialect.name != "sqlite":
            raise RuntimeError("Motore database non supportato.")
        # Alembic ricrea le tabelle per cambiare i vincoli su SQLite. I riferimenti
        # delle tabelle figlie devono restare intatti durante questa sostituzione.
        # Il programma non ha ancora avviato richieste o altri scrittori.
        fk = conn.exec_driver_sql("PRAGMA foreign_keys").scalar()
        conn.commit()
        conn.exec_driver_sql("PRAGMA foreign_keys=OFF")
        conn.commit()
        try:
            with conn.begin():
                # BEGIN esplicito rende transazionali anche i DDL del driver SQLite.
                conn.exec_driver_sql("BEGIN IMMEDIATE")
                command.upgrade(cfg, "head")
                if conn.exec_driver_sql("PRAGMA foreign_key_check").first():
                    raise RuntimeError("Aggiornamento annullato: collegamenti del database non integri.")
        finally:
            conn.exec_driver_sql(f"PRAGMA foreign_keys={'ON' if fk else 'OFF'}")
            conn.commit()
