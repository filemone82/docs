"""Conversione Word → PDF con LibreOffice (gratuito), invisibile, una conversione alla volta.

Come in VerbalizzAI: cerca LibreOffice nel percorso indicato in config.json («libreoffice»), poi nel
PATH, poi nelle cartelle standard di Windows e Linux. Usa un profilo separato, così non disturba un
LibreOffice aperto dall'utente.
"""

from __future__ import annotations

import os
import logging
import shutil
import subprocess
import tempfile
import threading
from pathlib import Path

from .errori import ErroreUtente

_lucchetto = threading.Lock()
TEMPO_MASSIMO = 180
CANDIDATI = [
    r"C:\Program Files\LibreOffice\program\soffice.exe",
    r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
    "/usr/bin/soffice", "/usr/bin/libreoffice", "/usr/lib/libreoffice/program/soffice", "/opt/libreoffice/program/soffice",
]


def trova(configurato: str = "") -> str | None:
    if configurato and Path(configurato).is_file():
        return configurato
    for nome in ("soffice", "libreoffice"):
        p = shutil.which(nome)
        if p:
            return p
    return next((p for p in CANDIDATI if Path(p).is_file()), None)


def disponibile(configurato: str = "") -> bool:
    return trova(configurato) is not None


def da_word(docx: bytes, configurato: str = "") -> bytes:
    exe = trova(configurato)
    if not exe:
        raise ErroreUtente("LibreOffice non trovato: installalo (è gratuito, libreoffice.org) per avere il PDF, "
                           "oppure indica il percorso di soffice.exe in config.json alla voce «libreoffice». Il Word è stato creato comunque.")
    with _lucchetto, tempfile.TemporaryDirectory(prefix="gad_pdf_") as tmp:
        sorgente = Path(tmp) / "documento.docx"
        sorgente.write_bytes(docx)
        profilo = Path(tmp) / "profilo"
        comando = [exe, "-env:UserInstallation=" + profilo.resolve().as_uri(), "--headless", "--norestore", "--nologo",
                   "--convert-to", "pdf", "--outdir", tmp, str(sorgente)]
        opzioni = {"creationflags": 0x08000000} if os.name == "nt" else {}  # niente finestra su Windows
        try:
            risultato = subprocess.run(comando, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=TEMPO_MASSIMO, check=False, **opzioni)
        except subprocess.TimeoutExpired:
            raise ErroreUtente(f"Conversione in PDF troppo lenta (oltre {TEMPO_MASSIMO} secondi): riprova.") from None
        uscita = sorgente.with_suffix(".pdf")
        if not uscita.is_file() or uscita.stat().st_size == 0:
            raise ErroreUtente("LibreOffice non ha prodotto il PDF: chiudi eventuali finestre di LibreOffice bloccate e riprova.")
        raw = uscita.read_bytes()
        logging.getLogger(__name__).info("Conversione PDF: word_bytes=%s pdf_bytes=%s exit_code=%s",
                                        len(docx), len(raw), risultato.returncode)
        return raw
