"""Database: SQLite in modalità WAL con chiavi esterne attive (decisioni D5, D30).

Regole:
- tutte le scritture passano da `Archivio.scrittura()`: un solo scrittore alla volta (il programma gira
  in un solo processo), così il registro delle operazioni a catena resta coerente;
- ogni operazione è una transazione: o va a buon fine tutta o non cambia nulla;
- importi in centesimi interi, date/ore in UTC (mostrate in ora italiana dall'interfaccia).
"""

from __future__ import annotations

import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from collections.abc import Iterator

from sqlalchemy import Engine, MetaData, create_engine, event, text
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from .config import Config

# Nomi stabili per vincoli e indici: necessari perché le migrazioni su SQLite funzionino bene.
CONVENZIONE_NOMI = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    metadata = MetaData(naming_convention=CONVENZIONE_NOMI)


def adesso() -> datetime:
    """Data e ora attuali in UTC, senza fuso (formato usato nel database)."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


def crea_motore(percorso_db: str, database_url: str = "") -> Engine:
    if database_url:
        if not database_url.startswith(("postgresql://", "postgresql+psycopg://")):
            raise ValueError("Database non supportato.")
        url = database_url.replace("postgresql://", "postgresql+psycopg://", 1)
        return create_engine(url, pool_pre_ping=True, pool_size=5, max_overflow=5, isolation_level="READ COMMITTED",
                             connect_args={"connect_timeout": 15, "prepare_threshold": None})
    motore = create_engine(f"sqlite:///{percorso_db}", connect_args={"check_same_thread": False, "timeout": 15})

    @event.listens_for(motore, "connect")
    def _pragmi(conn, _record):  # noqa: ANN001
        conn.create_function("nexus_oggi", 0, lambda: datetime.now(ZoneInfo("Europe/Rome")).date().isoformat())
        cur = conn.cursor()
        cur.execute("PRAGMA foreign_keys=ON")
        cur.execute("PRAGMA journal_mode=WAL")
        cur.execute("PRAGMA synchronous=NORMAL")
        cur.execute("PRAGMA busy_timeout=15000")
        cur.close()

    return motore


class Archivio:
    """Tiene insieme configurazione, motore del database e lucchetto delle scritture."""

    def __init__(self, cfg: Config) -> None:
        self.cfg = cfg
        cfg.prepara_cartelle()
        self._lucchetto = threading.RLock()
        self.motore = crea_motore(str(cfg.percorso_database), cfg.database_url)
        self._locale = threading.local()
        self._fabbrica = sessionmaker(bind=self.motore, expire_on_commit=False)

    def sessione(self) -> Session:
        return self._fabbrica()

    @contextmanager
    def lettura(self) -> Iterator[Session]:
        connessione = getattr(self._locale, "esclusiva", None)
        s = Session(bind=connessione, expire_on_commit=False) if connessione is not None else self._fabbrica()
        try:
            yield s
        finally:
            s.close()

    @contextmanager
    def scrittura(self) -> Iterator[Session]:
        """Transazione di scrittura: un solo scrittore alla volta; commit alla fine, rollback se errore."""
        with self._lucchetto:
            connessione = getattr(self._locale, "esclusiva", None)
            s = Session(bind=connessione, expire_on_commit=False) if connessione is not None else self._fabbrica()
            try:
                if self.motore.dialect.name == "postgresql":
                    # Mantiene la politica del singolo scrittore, ora anche fra processi.
                    # Protegge insieme versioni, max(numero)+1 e catena del registro.
                    s.execute(text("SELECT pg_advisory_xact_lock(:chiave)"), {"chiave": 462810180})
                yield s
                s.commit()
            except BaseException:
                s.rollback()
                raise
            finally:
                s.close()

    @contextmanager
    def esclusivo(self) -> Iterator[None]:
        """Blocca tutte le scritture (usato da backup e ripristino)."""
        with self._lucchetto:
            if self.motore.dialect.name != "postgresql" or getattr(self._locale, "esclusiva", None) is not None:
                yield
                return
            with self.motore.connect() as conn:
                conn.execute(text("SELECT pg_advisory_lock(:chiave)"), {"chiave": 462810180})
                conn.commit()
                self._locale.esclusiva = conn
                try:
                    yield
                finally:
                    try:
                        conn.rollback()
                        conn.execute(text("SELECT pg_advisory_unlock(:chiave)"), {"chiave": 462810180})
                        conn.commit()
                    finally:
                        self._locale.esclusiva = None

    def riapri(self) -> None:
        """Chiude e riapre le connessioni (dopo un ripristino il file del database è cambiato)."""
        self.motore.dispose()
        self.motore = crea_motore(str(self.cfg.percorso_database), self.cfg.database_url)
        self._fabbrica = sessionmaker(bind=self.motore, expire_on_commit=False)

    def chiudi(self) -> None:
        self.motore.dispose()
