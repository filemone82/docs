"""Configurazione del programma.

Le impostazioni si leggono da `config.json` nella cartella del programma (se manca si usano i valori
predefiniti). Le password di servizi esterni (es. posta) NON stanno qui né nel database: arriveranno
da variabili d'ambiente quando servirà l'invio email (fase 4).
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

CARTELLA_PROGRAMMA = Path(__file__).resolve().parents[2]


@dataclass
class Config:
    # PostgreSQL: credenziali fornite dall'ambiente, mai salvate da fissa_cartella_dati.
    database_url: str = field(default="", repr=False)
    # Collaudo mirato: dopo importazione verificata, usa lo schema verbali dello
    # stesso PostgreSQL. La transizione rc3 non avviene mai implicitamente.
    verbali_postgresql: bool = False
    # Cartella dei dati: database, documenti, backup. Predefinita: «GestionaleAD_dati» accanto
    # alla cartella del programma, così una nuova versione scompattata accanto la ritrova da sola.
    cartella_dati: Path = field(default_factory=lambda: CARTELLA_PROGRAMMA.parent / "GestionaleAD_dati")
    indirizzo: str = "127.0.0.1"
    porta: int = 8462
    apri_browser: bool = True
    # Sicurezza dell'accesso
    https: bool = False                  # True sul VPS dietro HTTPS: i cookie diventano «Secure»
    minuti_inattivita: int = 60          # la sessione scade dopo questo tempo senza attività
    ore_durata_massima_sessione: int = 12
    tentativi_prima_del_blocco: int = 5
    minuti_blocco: int = 15
    lunghezza_minima_password: int = 10
    iterazioni_password: int = 600_000   # PBKDF2-SHA256 (valore raccomandato OWASP)
    # Backup automatici (decisione: uno al giorno all'avvio + uno ogni 4 ore di uso)
    backup_automatico: bool = True
    ore_tra_backup_automatici: int = 4
    backup_automatici_da_conservare: int = 30
    # Percorso di LibreOffice (soffice.exe) per i PDF; vuoto = cerca da solo
    libreoffice: str = ""
    # 0.13.0 (Federico, 12/10/2026): cartella in cui si salva una copia dei verbali DM definitivi, con il nome per
    # l'INAIL e con il nome «potabile», divisa in GVR | SC_SP / anno di emissione / sede operativa. Vuoto = non si salva.
    cartella_verbali_dm: str = ""

    @property
    def percorso_database(self) -> Path:
        return self.cartella_dati / "database.sqlite"

    @property
    def postgresql(self) -> bool:
        return self.database_url.startswith(("postgresql://", "postgresql+psycopg://"))

    @property
    def cartella_documenti(self) -> Path:
        return self.cartella_dati / "documenti"

    @property
    def cartella_backup(self) -> Path:
        return self.cartella_dati / "backup"

    @property
    def cartella_temporanea(self) -> Path:
        return self.cartella_dati / "temporanei"

    def prepara_cartelle(self) -> None:
        for cartella in (self.cartella_dati, self.cartella_documenti, self.cartella_backup, self.cartella_temporanea):
            cartella.mkdir(parents=True, exist_ok=True)


def carica_config(percorso: Path | None = None) -> Config:
    """Legge config.json (se esiste) e le variabili d'ambiente GESTIONALE_* (usate dai test)."""
    cfg = Config()
    percorso = percorso or Path(os.environ.get("GESTIONALE_CONFIG", CARTELLA_PROGRAMMA / "config.json"))
    if percorso.exists():
        dati = json.loads(percorso.read_text(encoding="utf-8"))
        for chiave, valore in dati.items():
            if chiave.startswith("_"):
                continue  # commenti nel file di esempio
            if not hasattr(cfg, chiave):
                raise ValueError(f"config.json: impostazione sconosciuta «{chiave}»")
            if chiave == "database_url" and valore:
                raise ValueError("La connessione PostgreSQL si imposta con GESTIONALE_DATABASE_URL, non in config.json.")
            if chiave == "cartella_dati":
                valore = Path(valore)
                if not valore.is_absolute():
                    valore = (CARTELLA_PROGRAMMA / valore).resolve()
            setattr(cfg, chiave, valore)
    if os.environ.get("GESTIONALE_CARTELLA_DATI"):
        cfg.cartella_dati = Path(os.environ["GESTIONALE_CARTELLA_DATI"])
    if os.environ.get("GESTIONALE_DATABASE_URL"):
        cfg.database_url = os.environ["GESTIONALE_DATABASE_URL"]
    if cfg.database_url and not cfg.postgresql:
        raise ValueError("GESTIONALE_DATABASE_URL deve indicare PostgreSQL; SQLite usa cartella_dati.")
    if os.environ.get("GESTIONALE_ITERAZIONI_PASSWORD"):
        cfg.iterazioni_password = int(os.environ["GESTIONALE_ITERAZIONI_PASSWORD"])
    return cfg


def fissa_cartella_dati(cfg: Config, percorso: Path | None = None) -> bool:
    """O16: scrive in config.json la cartella dei dati in uso (se manca), così la prossima versione la ritrova
    anche se scompattata altrove. Le altre impostazioni restano com'erano. Restituisce True se ha scritto.
    Non scrive nulla quando la cartella arriva da GESTIONALE_CARTELLA_DATI (ambiente di prova, archivio di prova):
    altrimenti il successivo AVVIA_WINDOWS.bat aprirebbe l'archivio di prova invece di quello vero (0.6.0)."""
    if os.environ.get("GESTIONALE_CARTELLA_DATI"):
        return False
    percorso = percorso or Path(os.environ.get("GESTIONALE_CONFIG", CARTELLA_PROGRAMMA / "config.json"))
    try:
        dati = json.loads(percorso.read_text(encoding="utf-8")) if percorso.exists() else {}
    except (OSError, ValueError):
        return False  # file illeggibile: non lo si tocca
    if dati.get("cartella_dati"):
        return False
    dati["cartella_dati"] = str(Path(cfg.cartella_dati).resolve())
    try:
        provvisorio = percorso.with_suffix(".tmp")
        provvisorio.write_text(json.dumps(dati, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        os.replace(provvisorio, percorso)
    except OSError:
        return False
    return True
