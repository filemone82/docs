"""Colonne comuni alle tabelle di lavoro: versione (modifiche concorrenti) e tracce di creazione/modifica."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import BigInteger, DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from .db import adesso

# SQLite INTEGER conserva 64 bit; PostgreSQL INTEGER ne avrebbe solo 32.
# Manteniamo il dominio dei centesimi senza cambiare lo schema SQLite esistente.
Centesimi = BigInteger().with_variant(Integer(), "sqlite")


class Tracciato:
    """Da aggiungere ai modelli: chi e quando ha creato/modificato, numero di versione (D30, documento 06).

    Il dettaglio di ogni modifica (prima/dopo) sta nel registro delle operazioni; qui solo l'ultima.
    """

    versione: Mapped[int] = mapped_column(Integer, default=1)
    creato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    creato_da: Mapped[str] = mapped_column(String(120), default="")
    modificato_il: Mapped[datetime] = mapped_column(DateTime, default=adesso)
    modificato_da: Mapped[str] = mapped_column(String(120), default="")
