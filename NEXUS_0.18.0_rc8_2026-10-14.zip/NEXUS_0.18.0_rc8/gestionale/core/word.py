"""Compilazione dei modelli Word (.docx) con segnaposto (D14; documento 03 § 2.5).

Sintassi (la stessa del gestionale attuale):
- `{{cli.rag_soc}}`, `{{p.data_preventivo}}`… sostituiti con il valore;
- `{{#r}} … {{/r}}` intorno a una o più righe di tabella: le righe si ripetono per ogni elemento
  dell'elenco «r», e dentro si usano `{{r.campo}}`.

Word spezza spesso il testo in più pezzi («run»): prima di sostituire, ogni segnaposto viene riunito
in un solo pezzo, mantenendo la formattazione del primo. Si lavora su documento, intestazioni e piè di
pagina; tutte le altre parti del file restano identiche. Il file è letto in modo sicuro (niente entità
esterne, niente macro eseguite).
"""

from __future__ import annotations

import copy
import io
import re
import zipfile

from lxml import etree

from .errori import ErroreUtente

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
XML_SPACE = "{http://www.w3.org/XML/1998/namespace}space"
RE_SEGNAPOSTO = re.compile(r"\{\{\s*([#/]?)\s*([\w.]+)\s*\}\}")
PARTI = re.compile(r"^word/(document|header\d*|footer\d*)\.xml$")
PARSER = etree.XMLParser(resolve_entities=False, no_network=True, huge_tree=False, remove_blank_text=False)


def _w(tag: str) -> str:
    return f"{{{W}}}{tag}"


def _apri(contenuto: bytes) -> zipfile.ZipFile:
    if len(contenuto) > 25 * 1024 * 1024:
        raise ErroreUtente("Il modello Word è troppo grande (massimo 25 MB).")
    try:
        z = zipfile.ZipFile(io.BytesIO(contenuto))
    except zipfile.BadZipFile:
        raise ErroreUtente("Il file non è un documento Word .docx valido.") from None
    if "word/document.xml" not in z.namelist():
        raise ErroreUtente("Il file non è un documento Word .docx (il vecchio formato .doc non è supportato: salvalo come .docx).")
    if sum(i.file_size for i in z.infolist()) > 150 * 1024 * 1024:
        raise ErroreUtente("Il modello Word è troppo esteso.")
    return z


def _leggi_xml(dati: bytes):  # noqa: ANN202
    if b"<!DOCTYPE" in dati or b"<!ENTITY" in dati:
        raise ErroreUtente("Il modello Word contiene parti non ammesse.")
    return etree.fromstring(dati, PARSER)


def _unisci_segnaposto(p) -> None:  # noqa: ANN001
    """Riunisce in un solo w:t i segnaposto spezzati su più pezzi di testo dello stesso paragrafo."""
    while True:
        nodi = p.findall(".//" + _w("t"))
        testi = [n.text or "" for n in nodi]
        intero = "".join(testi)
        if "{{" not in intero:
            return
        inizi, pos = [], 0
        for t in testi:
            inizi.append(pos)
            pos += len(t)

        def nodo_di(indice: int) -> int:
            for i, t in enumerate(testi):
                if inizi[i] <= indice < inizi[i] + len(t):
                    return i
            return len(nodi) - 1

        cambiato = False
        for m in re.finditer(r"\{\{.*?\}\}", intero):
            a, b = nodo_di(m.start()), nodo_di(m.end() - 1)
            if a == b:
                continue
            fine_b = m.end() - inizi[b]
            nodi[a].text = testi[a][: m.start() - inizi[a]] + m.group(0)
            nodi[a].set(XML_SPACE, "preserve")
            for i in range(a + 1, b):
                nodi[i].text = ""
            nodi[b].text = testi[b][fine_b:]
            nodi[b].set(XML_SPACE, "preserve")
            cambiato = True
            break
        if not cambiato:
            return


def _sostituisci(radice, valori: dict, mancanti: set) -> None:  # noqa: ANN001
    for n in radice.iter(_w("t")):
        if n.text and "{{" in n.text:
            def valore(m: re.Match) -> str:
                if m.group(1):
                    return ""  # marcatori di blocco rimasti: si tolgono
                chiave = m.group(2)
                if chiave not in valori:
                    mancanti.add(chiave)
                    return ""
                v = valori[chiave]
                return "" if v is None else str(v)
            n.text = RE_SEGNAPOSTO.sub(valore, n.text)
            n.set(XML_SPACE, "preserve")


def _testo(el) -> str:  # noqa: ANN001
    return "".join(n.text or "" for n in el.iter(_w("t")))


def _ripeti_righe(radice, nome: str, elementi: list[dict], mancanti: set) -> None:  # noqa: ANN001
    apertura, chiusura = "{{#" + nome + "}}", "{{/" + nome + "}}"
    while True:
        inizio = next((tr for tr in radice.iter(_w("tr")) if apertura in _testo(tr).replace(" ", "")), None)
        if inizio is None:
            return
        blocco = [inizio]
        corrente = inizio
        while chiusura not in _testo(corrente).replace(" ", ""):
            corrente = corrente.getnext()
            if corrente is None or corrente.tag != _w("tr"):
                raise ErroreUtente(f"Nel modello Word manca la chiusura {chiusura} nella stessa tabella dell'apertura {apertura}.")
            blocco.append(corrente)
        genitore = inizio.getparent()
        posizione = genitore.index(inizio)
        for el in blocco:
            genitore.remove(el)
        for i, elemento in enumerate(elementi):
            valori = {f"{nome}.{k}": v for k, v in elemento.items()}
            for el in blocco:
                copia = copy.deepcopy(el)
                _sostituisci(copia, valori, mancanti)
                genitore.insert(posizione + i * len(blocco) + blocco.index(el), copia)


def segnaposto(contenuto: bytes) -> list[str]:
    """Elenco dei segnaposto presenti nel modello (per controllarlo al caricamento)."""
    z = _apri(contenuto)
    trovati: list[str] = []
    for nome in z.namelist():
        if PARTI.match(nome):
            radice = _leggi_xml(z.read(nome))
            for p in radice.iter(_w("p")):
                _unisci_segnaposto(p)
            for m in RE_SEGNAPOSTO.finditer(_testo(radice)):
                k = m.group(1) + m.group(2)
                if k not in trovati:
                    trovati.append(k)
    return trovati


def condizionali(contenuto: bytes, condizioni: dict[str, bool]) -> bytes:
    """Blocchi di paragrafi opzionali dei modelli Garda, senza cambiarne lo stile."""
    uscita = io.BytesIO()
    with _apri(contenuto) as z, zipfile.ZipFile(uscita, "w", zipfile.ZIP_DEFLATED) as nuovo:
        for info in z.infolist():
            dati = z.read(info.filename)
            if PARTI.match(info.filename):
                root = _leggi_xml(dati)
                for nome, mostra in condizioni.items():
                    inizio, fine = "{{#" + nome + "}}", "{{/" + nome + "}}"
                    for parent in list(root.iter()):
                        dentro = False
                        for child in list(parent):
                            testo = _testo(child) if child.tag == _w("p") else ""
                            if inizio in testo:
                                if dentro:
                                    raise ErroreUtente("Blocco condizionale Word annidato non valido.")
                                dentro = True
                                parent.remove(child)
                            elif fine in testo:
                                if not dentro:
                                    raise ErroreUtente("Fine blocco condizionale Word senza inizio.")
                                dentro = False
                                parent.remove(child)
                            elif dentro and not mostra:
                                parent.remove(child)
                        if dentro:
                            raise ErroreUtente("Blocco condizionale Word non chiuso.")
                dati = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)
            nuovo.writestr(info, dati)
    return uscita.getvalue()


def compila(contenuto: bytes, valori: dict, elenchi: dict[str, list[dict]] | None = None) -> tuple[bytes, list[str]]:
    """Restituisce il .docx compilato e l'elenco dei segnaposto senza valore (rimasti vuoti)."""
    z = _apri(contenuto)
    mancanti: set = set()
    uscita = io.BytesIO()
    with zipfile.ZipFile(uscita, "w", zipfile.ZIP_DEFLATED) as nuovo:
        for info in z.infolist():
            dati = z.read(info.filename)
            if PARTI.match(info.filename):
                radice = _leggi_xml(dati)
                for p in radice.iter(_w("p")):
                    _unisci_segnaposto(p)
                for nome_elenco, elementi in (elenchi or {}).items():
                    _ripeti_righe(radice, nome_elenco, elementi, mancanti)
                _sostituisci(radice, valori, mancanti)
                dati = etree.tostring(radice, xml_declaration=True, encoding="UTF-8", standalone=True)
            nuovo.writestr(info, dati)
    return uscita.getvalue(), sorted(mancanti)


def aggiungi_scritta(contenuto: bytes, testo: str) -> bytes:
    """Scritta rossa in grassetto in cima al documento e in ogni intestazione (es. «ANTEPRIMA», O13)."""
    z = _apri(contenuto)
    uscita = io.BytesIO()
    with zipfile.ZipFile(uscita, "w", zipfile.ZIP_DEFLATED) as nuovo:
        for info in z.infolist():
            dati = z.read(info.filename)
            if re.match(r"^word/(document|header\d*)\.xml$", info.filename):
                radice = _leggi_xml(dati)
                contenitore = radice.find(_w("body")) if info.filename == "word/document.xml" else radice
                if contenitore is not None:
                    p = etree.SubElement(contenitore, _w("p"))
                    contenitore.remove(p)
                    contenitore.insert(0, p)
                    ppr = etree.SubElement(p, _w("pPr"))
                    etree.SubElement(ppr, _w("jc")).set(_w("val"), "center")
                    r = etree.SubElement(p, _w("r"))
                    rpr = etree.SubElement(r, _w("rPr"))
                    etree.SubElement(rpr, _w("b"))
                    etree.SubElement(rpr, _w("color")).set(_w("val"), "C00000")
                    etree.SubElement(rpr, _w("sz")).set(_w("val"), "28")
                    t = etree.SubElement(r, _w("t"))
                    t.text = testo
                    t.set(XML_SPACE, "preserve")
                    dati = etree.tostring(radice, xml_declaration=True, encoding="UTF-8", standalone=True)
            nuovo.writestr(info, dati)
    return uscita.getvalue()
