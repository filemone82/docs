"""Espressioni SQL comuni. La data odierna segue Europe/Rome in entrambi i motori."""
from sqlalchemy import Date, Integer, String
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.sql.functions import FunctionElement


class oggi_italiano(FunctionElement):
    type = Date()
    inherit_cache = True


@compiles(oggi_italiano, "sqlite")
def _oggi_sqlite(e, c, **kw):
    return "nexus_oggi()"


@compiles(oggi_italiano, "postgresql")
def _oggi_pg(e, c, **kw):
    return "CAST(timezone('Europe/Rome', CURRENT_TIMESTAMP) AS DATE)"


class data_tra_giorni(FunctionElement):
    type = Date()
    inherit_cache = True


@compiles(data_tra_giorni, "sqlite")
def _tra_sqlite(e, c, **kw):
    a, b = [c.process(x, **kw) for x in e.clauses]
    return f"date({a}, printf('%+d days', {b}))"


@compiles(data_tra_giorni, "postgresql")
def _tra_pg(e, c, **kw):
    a, b = [c.process(x, **kw) for x in e.clauses]
    return f"(CAST({a} AS DATE) + CAST({b} AS INTEGER))"


class anno_dopo(FunctionElement):
    type = Date()
    inherit_cache = True


@compiles(anno_dopo, "sqlite")
def _anno_sqlite(e, c, **kw):
    return f"date({c.process(list(e.clauses)[0], **kw)}, '+1 year')"


@compiles(anno_dopo, "postgresql")
def _anno_pg(e, c, **kw):
    a = "CAST(" + c.process(list(e.clauses)[0], **kw) + " AS DATE)"
    # Conserva il comportamento originario SQLite per il 29 febbraio.
    return (f"(make_date(CAST(EXTRACT(YEAR FROM {a}) AS INTEGER)+1, "
            f"CAST(EXTRACT(MONTH FROM {a}) AS INTEGER), 1) "
            f"+ CAST(EXTRACT(DAY FROM {a}) AS INTEGER)-1)")


class giorni_fra(FunctionElement):
    type = Integer()
    inherit_cache = True


@compiles(giorni_fra, "sqlite")
def _giorni_sqlite(e, c, **kw):
    a, b = [c.process(x, **kw) for x in e.clauses]
    return f"CAST(julianday({a}) - julianday({b}) AS INTEGER)"


@compiles(giorni_fra, "postgresql")
def _giorni_pg(e, c, **kw):
    a, b = [c.process(x, **kw) for x in e.clauses]
    return f"(CAST({a} AS DATE) - CAST({b} AS DATE))"


class testi_uniti(FunctionElement):
    type = String()
    inherit_cache = True


@compiles(testi_uniti, "sqlite")
def _uniti_sqlite(e, c, **kw):
    a, b = [c.process(x, **kw) for x in e.clauses]
    return f"group_concat({a}, {b})"


@compiles(testi_uniti, "postgresql")
def _uniti_pg(e, c, **kw):
    a, b = [c.process(x, **kw) for x in e.clauses]
    return f"string_agg(CAST({a} AS TEXT), {b})"


class json_testo(FunctionElement):
    type = String()
    inherit_cache = True


@compiles(json_testo, "sqlite")
def _json_sqlite(e, c, **kw):
    a, b = [c.process(x, **kw) for x in e.clauses]
    return f"json_extract({a}, '$.' || {b})"


@compiles(json_testo, "postgresql")
def _json_pg(e, c, **kw):
    a, b = [c.process(x, **kw) for x in e.clauses]
    return f"jsonb_extract_path_text(CAST({a} AS JSONB), {b})"
