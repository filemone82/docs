"""Errori mostrati all'utente: messaggi in italiano che dicono cosa fare (convenzione 03 § 3)."""

from __future__ import annotations


class ErroreUtente(Exception):
    """Errore previsto: l'utente può rimediare. `stato` è il codice HTTP."""

    stato = 400

    def __init__(self, messaggio: str, stato: int | None = None) -> None:
        super().__init__(messaggio)
        self.messaggio = messaggio
        if stato is not None:
            self.stato = stato


class NonAutenticato(ErroreUtente):
    stato = 401

    def __init__(self, messaggio: str = "Sessione scaduta: accedi di nuovo.") -> None:
        super().__init__(messaggio)


class PermessoNegato(ErroreUtente):
    stato = 403

    def __init__(self, messaggio: str = "Non hai il permesso per questa operazione. Chiedi all'amministratore.") -> None:
        super().__init__(messaggio)


class NonTrovato(ErroreUtente):
    stato = 404


class Conflitto(ErroreUtente):
    """Modifica concorrente: qualcun altro ha salvato prima."""

    stato = 409

    def __init__(self, messaggio: str = "Il dato è stato modificato da un altro utente mentre lo stavi modificando: ricarica la pagina e ripeti la modifica.") -> None:
        super().__init__(messaggio)
