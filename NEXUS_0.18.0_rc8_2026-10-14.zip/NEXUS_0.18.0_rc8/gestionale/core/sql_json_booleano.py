from sqlalchemy import Integer
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.sql.functions import FunctionElement


class json_booleano_intero(FunctionElement):
    """Campo JSON validato come booleano (scheda_dm), per colonne Sì/No."""
    type = Integer()
    inherit_cache = True


@compiles(json_booleano_intero, 'sqlite')
def _sqlite(e,c,**kw):
    a,b=[c.process(x,**kw) for x in e.clauses]
    return f"CAST(json_extract({a}, '$.' || {b}) AS INTEGER)"


@compiles(json_booleano_intero, 'postgresql')
def _pg(e,c,**kw):
    a,b=[c.process(x,**kw) for x in e.clauses]
    return f"CAST(CAST(jsonb_extract_path_text(CAST({a} AS JSONB), {b}) AS BOOLEAN) AS INTEGER)"
