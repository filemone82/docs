"""Password e codici casuali.

Password: PBKDF2-SHA256 con sale casuale e 600.000 iterazioni (libreria standard, nessuna dipendenza).
Formato salvato: «pbkdf2_sha256$iterazioni$sale_hex$impronta_hex». Se in futuro si alzano le
iterazioni, le password vecchie restano valide e si aggiornano al primo accesso.
"""

from __future__ import annotations

import hashlib
import hmac
import secrets


def hash_password(password: str, iterazioni: int) -> str:
    sale = secrets.token_bytes(16)
    impronta = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), sale, iterazioni)
    return f"pbkdf2_sha256${iterazioni}${sale.hex()}${impronta.hex()}"


def verifica_password(password: str, salvata: str) -> bool:
    try:
        schema, iterazioni, sale, impronta = salvata.split("$")
        if schema != "pbkdf2_sha256":
            return False
        calcolata = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(sale), int(iterazioni))
        return hmac.compare_digest(calcolata.hex(), impronta)
    except (ValueError, TypeError):
        return False


def da_aggiornare(salvata: str, iterazioni: int) -> bool:
    try:
        return int(salvata.split("$")[1]) < iterazioni
    except (IndexError, ValueError):
        return True


def codice_casuale(byte: int = 32) -> str:
    return secrets.token_urlsafe(byte)


def impronta_testo(testo: str) -> str:
    return hashlib.sha256(testo.encode("utf-8")).hexdigest()


def password_temporanea() -> str:
    """Password provvisoria leggibile (senza caratteri ambigui), da cambiare al primo accesso."""
    alfabeto = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "".join(secrets.choice(alfabeto) for _ in range(12))


def controlla_password_nuova(password: str, lunghezza_minima: int, username: str = "") -> str | None:
    """Restituisce un messaggio d'errore se la password non va bene, altrimenti None."""
    if len(password) < lunghezza_minima:
        return f"La password deve avere almeno {lunghezza_minima} caratteri (meglio una frase facile da ricordare)."
    if username and username.lower() in password.lower():
        return "La password non deve contenere il nome utente."
    if len(set(password)) < 4:
        return "La password è troppo ripetitiva: usa caratteri diversi."
    return None
