"""Catalogo delle micro-attività (decisione D24) e permessi di partenza dei ruoli (documento 07).

Regole:
- ogni operazione del programma corrisponde a un codice di questo elenco;
- l'elenco vive qui nel codice e all'avvio viene allineato alla tabella `permessi`
  (le voci nuove ricevono i valori di partenza nei ruoli predefiniti; quelle già presenti
  non vengono toccate, così le scelte dell'amministratore restano);
- `disponibile=False` indica una funzione «in arrivo» nelle prossime fasi: si può già assegnare;
- «gestire» comprende «vedere»: vedi INCLUDE.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Microattivita:
    codice: str
    area: str
    descrizione: str
    disponibile: bool
    partenza: tuple[str, ...]  # ruoli predefiniti che la ricevono al primo avvio (l'amministratore ha tutto)


RT, TEC, SEG = "responsabile_tecnico", "tecnico", "segreteria"
# R132 (12/10/2026, Federico: «ruoli distinti»): RT e verificatori sono per attività. I codici storici RT e TEC sono
# quelli AD_DPR; il verificatore può avere entrambe le attività, l'RT no. Segreteria e amministratore sono comuni.
RT_DM, TEC_DM, TEC_DM_DPR = "responsabile_tecnico_dm", "tecnico_dm", "tecnico_dm_dpr"
GEMELLI = {RT: (RT, RT_DM), TEC: (TEC, TEC_DM, TEC_DM_DPR)}   # i permessi di partenza valgono per tutte le varianti
ATTIVITA = ("DPR", "DM")
# C20, approvazione Federico 13/10/2026: oggetto e attività sono inseparabili.
GESTIONE_PER_ATTIVITA = {
    "anagrafica.impianti": "DPR", "anagrafica.dismetti": "DPR",
    "beni.gestire": "DM", "beni.scadenze": "DM", "beni.dismetti": "DM",
}


CATALOGO: tuple[Microattivita, ...] = (
    # Sistema (attive dalla 0.1.0; impostazioni dalla 0.2.0)
    Microattivita("sistema.utenti", "Sistema", "Gestire utenti", True, ()),
    Microattivita("sistema.ruoli", "Sistema", "Gestire ruoli e permessi", True, ()),
    Microattivita("sistema.impostazioni", "Sistema", "Impostazioni ed elenchi di valori (modalità di pagamento, aliquote IVA)", True, ()),
    Microattivita("sistema.backup", "Sistema", "Backup, verifica, ripristino e controllo di integrità", True, ()),
    Microattivita("sistema.registro", "Sistema", "Consultare il registro delle operazioni", True, (RT,)),
    Microattivita("sistema.esporta", "Sistema", "Esportare in Excel", True, ()),
    Microattivita("sistema.modelli", "Sistema", "Gestire i modelli Word", True, (RT,)),
    # Anagrafica (attive dalla 0.2.0)
    Microattivita("anagrafica.vedere", "Anagrafica", "Vedere clienti, sedi, impianti", True, (RT, TEC, SEG)),
    Microattivita("anagrafica.clienti", "Anagrafica", "Creare e modificare clienti", True, (RT, SEG)),
    Microattivita("anagrafica.sedi", "Anagrafica", "Creare e modificare sedi operative", True, (RT, SEG)),
    Microattivita("anagrafica.impianti", "Impianti (AD_DPR)", "Creare e modificare impianti AD_DPR", True, (RT, SEG)),
    Microattivita("anagrafica.dismetti", "Impianti (AD_DPR)", "Segnare un impianto AD_DPR come dismesso", True, (RT, SEG)),
    Microattivita("anagrafica.disattiva", "Anagrafica", "Disattivare clienti e sedi", True, (SEG,)),
    Microattivita("anagrafica.importa", "Anagrafica", "Importare anagrafiche (VerbalizzAI, gestionale attuale)", True, ()),
    Microattivita("anagrafica.commerciali", "Anagrafica", "Gestire i commerciali", True, (SEG,)),
    Microattivita("beni.vedere", "Attrezzature (AD_DM)", "Vedere parco beni e cataloghi SC/SP/GVR/PSV", True, (RT, TEC, SEG)),
    Microattivita("beni.gestire", "Attrezzature (AD_DM)", "Creare e modificare attrezzature, camere e associazioni accessori", True, (RT_DM, SEG)),
    Microattivita("beni.scadenze", "Attrezzature (AD_DM)", "Registrare e correggere date tecniche iniziali dichiarate", True, (RT_DM, SEG)),
    Microattivita("beni.dismetti", "Attrezzature (AD_DM)", "Dismettere e riattivare attrezzature e accessori", True, (RT_DM, SEG)),
    # Tariffario (attive dalla 0.2.0)
    Microattivita("tariffario.vedere", "Tariffario", "Vedere il tariffario", True, (RT, SEG)),
    Microattivita("tariffario.gestire", "Tariffario", "Gestire voci, criteri e versioni del tariffario", True, ()),
    # Scadenze (vedere: attiva dalla 0.2.0)
    Microattivita("scadenze.vedere", "Scadenze", "Vedere lo scadenziario", True, (RT, SEG)),
    Microattivita("scadenze.solleciti", "Scadenze", "Gestire solleciti", False, (SEG,)),
    # Preventivi (attivi dalla 0.3.0)
    Microattivita("preventivi.vedere", "Preventivi", "Vedere i preventivi", True, (RT, SEG)),
    Microattivita("preventivi.modifica", "Preventivi", "Creare e modificare preventivi (anche dallo scadenziario)", True, (SEG,)),
    Microattivita("preventivi.elimina_bozza", "Preventivi", "Eliminare un preventivo mai inviato", True, (SEG,)),
    Microattivita("preventivi.documenti", "Preventivi", "Generare Word/PDF", True, (SEG,)),
    Microattivita("preventivi.invia", "Preventivi", "Inviare al cliente", True, (SEG,)),
    Microattivita("preventivi.revisione", "Preventivi", "Creare una revisione", True, (SEG,)),
    Microattivita("preventivi.accettazione", "Preventivi", "Registrare accettazione/rifiuto delle righe e rif. ordine", True, (SEG,)),
    Microattivita("preventivi.sconti_applica", "Preventivi", "Applicare sconti (solo clienti sbloccati)", True, (SEG,)),
    Microattivita("preventivi.sconti_sblocca", "Preventivi", "Sbloccare gli sconti su un cliente", True, ()),
    Microattivita("preventivi.annulla", "Preventivi", "Annullare un preventivo (con motivo)", True, ()),
    Microattivita("preventivi.riesame", "Preventivi", "Fare il riesame del contratto", True, (RT, SEG)),
    # Verifiche (fase 5, attive dalla 0.4.0; documento 10)
    Microattivita("verifiche.vedere_tutte", "Verifiche", "Vedere tutte le verifiche", True, (RT, SEG)),
    Microattivita("verifiche.vedere_proprie", "Verifiche", "Vedere le proprie verifiche (quelle assegnate a sé)", True, (RT, TEC)),
    Microattivita("verifiche.assegna", "Verifiche", "Assegnare le verifiche ai verificatori (e cambiare l'assegnazione)", True, (RT,)),
    Microattivita("verifiche.esegui", "Verifiche", "Programmare, registrare (numero del verbale) e caricare il verbale delle proprie verifiche", True, (RT, TEC)),
    Microattivita("verifiche.riesame", "Verifiche", "Riesame del verbale prima della fatturazione", True, (RT,)),
    Microattivita("verifiche.invia", "Verifiche", "Inviare il PDF definitivo delle verifiche DM", True, (RT, TEC, SEG)),
    Microattivita("verifiche.annulla", "Verifiche", "Annullare una verifica non ancora eseguita (con motivo)", True, (RT,)),
    Microattivita("verifiche.revisione", "Verifiche", "Revisione di un verbale emesso (nuova versione con lo stesso numero)", True, (RT,)),
    # Strumenti e firme dei verbali (dalla 0.5.0)
    Microattivita("strumenti.vedere", "Strumenti e firme", "Vedere gli strumenti di misura", True, (RT, TEC)),
    Microattivita("strumenti.gestire", "Strumenti e firme", "Gestire gli strumenti di misura (tarature)", True, (RT,)),
    Microattivita("firme.vedere", "Strumenti e firme", "Vedere le firme dei verificatori", True, (RT, TEC)),
    Microattivita("firme.gestire", "Strumenti e firme", "Gestire le firme dei verificatori", True, (RT,)),
    # Stato tecnico degli impianti nei verbali (dalla 0.6.0, VerbalizzAI 0.3.30+)
    Microattivita("impianti.stato_tecnico", "Verifiche", "Confermare e correggere lo stato tecnico degli impianti (dati del verbale riproposti alla verifica successiva)", True, (RT, TEC)),
    # Fatture (fase 6)
    Microattivita("fatture.vedere", "Fatture", "Vedere le fatture", True, (SEG,)),
    Microattivita("fatture.genera", "Fatture", "Generare fatture e tracciato XML", True, (SEG,)),
    Microattivita("fatture.esiti", "Fatture", "Registrare esiti XML tramite integrazione", True, (SEG,)),
    Microattivita("incassi.vedere", "Fatture", "Vedere incassi e residui", True, (SEG,)),
    Microattivita("incassi.gestire", "Fatture", "Registrare, ripartire e stornare incassi", True, (SEG,)),
    Microattivita("dm.inail", "AD DM", "Rendicontazione INAIL e riesportazione dei lotti", True, (RT,)),
)

PER_CODICE = {m.codice: m for m in CATALOGO}

# «Gestire» comprende «vedere»: chi ha la chiave ha anche i valori.
INCLUDE: dict[str, tuple[str, ...]] = {
    "beni.gestire": ("beni.vedere",),
    "beni.scadenze": ("beni.vedere",),
    "beni.dismetti": ("beni.vedere",),
    "anagrafica.clienti": ("anagrafica.vedere",),
    "anagrafica.sedi": ("anagrafica.vedere",),
    "anagrafica.impianti": ("anagrafica.vedere",),
    "anagrafica.dismetti": ("anagrafica.vedere",),
    "anagrafica.disattiva": ("anagrafica.vedere",),
    "anagrafica.commerciali": ("anagrafica.vedere",),
    "tariffario.gestire": ("tariffario.vedere",),
    "scadenze.solleciti": ("scadenze.vedere",),
    "preventivi.modifica": ("preventivi.vedere",),
    "preventivi.riesame": ("preventivi.vedere",),
    "verifiche.vedere_tutte": ("verifiche.vedere_proprie",),
    "verifiche.assegna": ("verifiche.vedere_tutte",),
    "verifiche.riesame": ("verifiche.vedere_tutte",),
    "verifiche.invia": ("verifiche.vedere_proprie",),
    "verifiche.annulla": ("verifiche.vedere_tutte",),
    "verifiche.esegui": ("verifiche.vedere_proprie",),
    "verifiche.revisione": ("verifiche.vedere_tutte",),
    "strumenti.gestire": ("strumenti.vedere",),
    "firme.gestire": ("firme.vedere",),
    "fatture.genera": ("fatture.vedere",),
    "fatture.esiti": ("fatture.vedere",),
    "incassi.vedere": ("fatture.vedere",),
    "incassi.gestire": ("incassi.vedere",),
}

RUOLI_PREDEFINITI = (
    # codice, nome, descrizione, di_sistema, attività ("" = comune a tutte)
    ("amministratore", "Amministratore", "Tutti i permessi; gestisce utenti, ruoli, permessi e backup.", True, ""),
    # R121 (11/10/2026): ruoli di base; nomi, descrizioni e permessi si cambiano da Gestione › Ruoli e permessi,
    # e se ne creano di nuovi. Negli archivi già esistenti i nomi restano quelli scelti.
    # R132 (12/10/2026): RT e verificatori distinti per attività.
    (RT, "RT DPR", "Responsabile tecnico AD_DPR: affida gli incarichi, esegue verifiche, riesamina contratti e verbali del D.P.R. 462/01.", False, "DPR"),
    (RT_DM, "RT DM", "Responsabile tecnico AD_DM: affida gli incarichi, esegue verifiche, riesamina contratti e verbali del D.M. 11.04.2011.", False, "DM"),
    (TEC, "Verificatore DPR", "Esegue le verifiche AD_DPR che gli sono assegnate: indipendenza, programmazione, registrazione, verbale.", False, "DPR"),
    (TEC_DM, "Verificatore DM", "Esegue le verifiche AD_DM che gli sono assegnate: indipendenza, programmazione, registrazione, verbale.", False, "DM"),
    (TEC_DM_DPR, "Verificatore DM e DPR", "Verificatore abilitato a entrambe le attività.", False, "DPR,DM"),
    (SEG, "Segreteria", "Anagrafiche, preventivi e fatture di tutte le attività; riesame del contratto.", False, ""),
)

# Permessi tecnici: valgono solo nelle attività del ruolo (R132). La gestione degli oggetti è inoltre vincolata
# da GESTIONE_PER_ATTIVITA (C20); clienti, sedi, preventivi commerciali, fatture e sistema restano comuni.
TECNICI = frozenset({
    "verifiche.vedere_tutte", "verifiche.vedere_proprie", "verifiche.assegna", "verifiche.esegui", "verifiche.riesame",
    "verifiche.invia", "verifiche.annulla", "verifiche.revisione", "impianti.stato_tecnico", "strumenti.vedere",
    "strumenti.gestire", "firme.vedere", "firme.gestire", "dm.inail", "preventivi.riesame"})
# Chi ha questi permessi è un responsabile tecnico: una sola attività (Federico: «DM_e_DPR … verificatori, non RT»).
DA_RT = frozenset({"verifiche.assegna", "verifiche.riesame"})


def attivita_di(testo: str) -> frozenset[str]:
    """«DPR,DM» → {"DPR", "DM"}; vuoto = tutte (ruolo comune)."""
    return frozenset(x for x in (testo or "").split(",") if x in ATTIVITA)


def espandi(codici: set[str]) -> set[str]:
    """Aggiunge i permessi compresi (es. chi modifica i clienti li vede anche)."""
    risultato = set(codici)
    da_fare = list(codici)
    while da_fare:
        c = da_fare.pop()
        for compreso in INCLUDE.get(c, ()):
            if compreso not in risultato:
                risultato.add(compreso)
                da_fare.append(compreso)
    return risultato
