"""Date: nel database in UTC, a video in ora italiana e nel formato gg/mm/aaaa (convenzione 03 § 3)."""

from __future__ import annotations

from datetime import date, datetime, timezone
from zoneinfo import ZoneInfo

ROMA = ZoneInfo("Europe/Rome")


def utc_a_locale(valore: datetime | None) -> datetime | None:
    if valore is None:
        return None
    return valore.replace(tzinfo=timezone.utc).astimezone(ROMA)


def locale_a_utc(valore: datetime) -> datetime:
    """Da ora italiana (senza fuso) a UTC senza fuso, come nel database."""
    return valore.replace(tzinfo=ROMA).astimezone(timezone.utc).replace(tzinfo=None)


def formatta_dataora(valore: datetime | None) -> str:
    v = utc_a_locale(valore)
    return v.strftime("%d/%m/%Y %H:%M") if v else ""


def formatta_data(valore: date | datetime | None) -> str:
    if valore is None:
        return ""
    if isinstance(valore, datetime):
        valore = utc_a_locale(valore)
    return valore.strftime("%d/%m/%Y")


def iso_locale(valore: datetime | None) -> str | None:
    """Data/ora in formato ISO con fuso italiano, per l'interfaccia."""
    v = utc_a_locale(valore)
    return v.isoformat(timespec="seconds") if v else None


def oggi_italia() -> date:
    """Data civile dell’attività, indipendente dal fuso del server."""
    return datetime.now(ROMA).date()
