# Prova manuale del nuovo blocco tecnico DM

La 0.10.0-dev rimane la versione del primo giro già proposto. La 0.11.0-dev è un checkpoint separato: puoi terminare quella prova prima di provare questo incremento.

Estrarre il pacchetto in una nuova cartella Windows, installare le dipendenze e avviare `AVVIA_COLLAUDO_WINDOWS.bat`. Usa il suo archivio separato `Dati_Collaudo`. Per riutilizzare dati della 0.10, chiudi il programma e copia l’intera cartella dati nella nuova installazione; l’avvio applica 0013 con backup preliminare. Conserva l’originale per il confronto fra versioni.

Prima del giro tecnico prova **Attività → AD_DPR / AD_DM / I&C**. I menu devono cambiare, clienti e sedi devono rimanere gli stessi. I&C deve mostrare l’area ancora da realizzare, senza offrire fatture DPR. Prova gli ingressi `http://127.0.0.1:8462/ad-dpr`, `/ad-dm` e `/iec`: devono selezionare la rispettiva attività. Aprendo una pagina comune la scelta deve restare; aprendo una pagina operativa deve risultare il suo ambiente. Ripeti con un tecnico: lo switch non deve conferirgli funzioni amministrative.

1. Crea un bene GVR classificato, matricola completa, tipo verbale RG, camera 100 L e tubazione DN 80. Crea un’offerta DM V2 funzionamento+integrità. Genera l’anteprima con LibreOffice, approva, segna inviata, accetta con riferimento scritto e registra RC conforme. Deve comparire **un** incarico, non due.
2. Da DM → Incarichi DM assegna un tecnico. Controlla la vista con quell’utente e un secondo tecnico: il secondo non deve poter aprire/modificare il lavoro. Prova assegnazione multipla su due incarichi.
3. Programma una data prevista; in un secondo incarico salta la programmazione. Entrambi devono poter proseguire. Escludi l’indipendenza: programmazione/registrazione devono essere bloccate. Ripristina la dichiarazione. Prova sospensione con motivo e ripresa.
4. Nella scheda tecnica cambia PS della camera, Pes/Tes, tipo verbale da RG a RV e descrizione processo. Salva. La scheda del bene deve recepire PS/tipo/processo, mentre Pes/Tes restano nel lavoro. La somma deve restare 100 L, senza DN. Il preventivo già emesso deve mantenere i dati precedenti.
5. Apri il bene in un’altra finestra e cambia PS/volume della stessa camera. Riaprendo il lavoro, la configurazione deve aggiornarsi e Pes/Tes rimanere se la chiave è la stessa. Tentare il salvataggio della vecchia scheda deve segnalare conflitto; ricaricala. Prova anche aggiunta/rimozione di una camera.
6. Inserisci rilascio e prossime F/I differenti, salva e registra. Serve una sola numerazione GVR; data riepilogativa = minima F/I del lavoro. Una data CND o una scadenza non pertinente del bene non deve sostituirla. La data di rilascio non aggiorna ancora le ultime verifiche del bene.
7. Prova errori: prossima data mancante, entrambe le caselle attrezzatura/insieme selezionate, negativo senza motivazione, esame spessimetrico selezionato senza i relativi dati. **Salva e registra** deve lasciare tutto invariato quando fallisce. In V2 il regime deve restare A2; V1 deve permettere A1/A2.
8. Registra un SC e un SP: numeri consecutivi nella stessa serie annuale SC-SP, indipendenti da GVR e DPR. Cambia anno rilascio di un lavoro registrato e poi torna all’anno precedente: il numero precedente non deve essere riusato. Annulla con motivo e verifica traccia/numero preservati.
9. Esegui e verifica un backup; prova il ripristino sul collaudo e controlla stato, bozza, fotografia e contatore. Esegui un breve giro DPR già descritto per la 0.10.

Questa versione si ferma alla registrazione DM: non cercare ancora finalizzazione, riesame DM, fattura da lavoro DM o export INAIL. Segnala versione, passaggi, atteso e ottenuto; la presenza del menu non certifica la copertura del modulo.
