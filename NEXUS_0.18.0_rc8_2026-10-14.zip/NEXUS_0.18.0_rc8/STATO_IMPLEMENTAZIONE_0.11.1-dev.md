# Checkpoint interno 0.11.1-dev — VerbalizzAI aggiornato e perimetro di fedeltà

10 ottobre 2026. Base: checkpoint 0.11.0-dev allegato da Federico, conservato. Schema applicativo 0013 invariato. Questo pacchetto conserva lo sviluppo; non è ancora il gestionale completo DPR/DM/I&C richiesto.

## Cambiamenti effettivi

- VerbalizzAI incorporato aggiornato dalla 0.3.32.3 alla **1.0.1 rc2** fornita dall’utente. Copiati tutti i moduli del generatore, inclusa layout.py, gli statici e i tre modelli Word. I modelli sono identici alla precedente copia; adattamento dei sorgenti limitato agli import locali resi relativi.
- Strumento di aggiornamento corretto per import multipli, alias e import nelle funzioni. Validazione di sorgenti e presenza di modelli/statici prima della sostituzione; ripristino della precedente cartella se la sostituzione non riesce. Eseguire l’aggiornamento del codice con applicazione ferma.
- Vincoli del 10 ottobre recepiti nel quadro 1.94, registro R101–R106 e scheda di ripresa 1.9. Rapporto 25: percorso verso un’unica candidata completa con tutte le funzioni Garda compatibili. Rapporto 26: inventario iniziale delle 151 regole estratte e dei metadati, non attestato di parità.

Nessuna nuova migrazione, nessun nuovo flusso di dominio e nessuna modifica tacita alle logiche Garda introdotti da questo incremento. I cambiamenti funzionali del generatore sono quelli della versione autonoma aggiornata richiesta. Fonti/impronte in documentazione/evidenze/verbalizzai_101_origine.json.

## Verifiche eseguite

Ambiente Linux, Python 3.12.14, SQLite; dipendenze della requirements-sviluppo.txt installate nelle versioni previste.

| Verifica | Esito |
|---|---|
| Suite esistente sul checkpoint 0.11.0-dev prima dell’aggiornamento | 189 test passati. |
| Suite esistente dopo l’aggiornamento del generatore | 189 test passati; risultati pytest_finale_0.11.1-dev.xml/txt. |
| Nuove regressioni del raccordo e dello strumento di aggiornamento | 6 test passati; risultati pytest_integrazione_101.xml/txt. |
| Contratto ponte/permessi/archivio e aggiornamento, dopo i ritocchi finali | 11 test passati; sottoinsieme delle prove sopra. |
| Ruff E9/F sui file modificati dello strumento e sui nuovi test | Passato. |
| Sintassi JavaScript dell’interfaccia VerbalizzAI incorporata | Passata. |

Le sei nuove regressioni verificano import multipli e alias eseguibili, nessuna sostituzione parziale per sintassi/modelli mancanti, ripristino dopo un errore di cambio cartella, percorso Word ritoccato→PDF definitivo e controllo bloccante sul numero delle pagine. La conversione Word/PDF nei due nuovi test del generatore usa LibreOffice reale; il PDF consultato coincide con quello conservato. L’invio email è simulato e verifica il contenuto dell’allegato; nessun messaggio esterno è inviato. Le offerte nella suite ordinaria continuano a usare il convertitore simulato del collaudo preesistente.

La suite segnala una deprecazione del TestClient Starlette/httpx, senza fallimenti. Non sono state effettuate prove Windows o Microsoft Word, deploy sul VPS, migrazione completa dei tre dump o configurazione dei domini. Questi esiti verificano il raccordo aggiornato; non provano che ogni funzione Garda sia già realizzata.

## Limiti e lavoro aperto

DM arriva ancora alla registrazione degli incarichi. Precedenti, generatori GVR/SC/SP, schede V1, ciclo di emissione/riesame, aggiornamento delle scadenze da lavori effettuati, fatturazione collegata e INAIL restano da completare. I&C, dashboard DM, migrazione e importazione completa/incrementale restano nel perimetro. Nessuna omissione acquisita come autorizzata.

Il backend integrato conserva l’archivio SQLite dedicato di VerbalizzAI nel proprio insieme di dati e backup, con il raccordo già esistente verso il database principale. Non è stata effettuata qui un’unificazione fisica dei due archivi o una riscrittura del recupero dopo emissione. La scelta tecnica definitiva deve preservare identità, documenti e comportamenti.

## Ripresa

Leggere documentazione/25_Percorso_gestionale_completo_2026-10-10.md, quadro sezione 77 e rapporto 26; proseguire nella stessa base. I documenti di stato precedenti rimangono evidenza storica. Il traguardo di collaudo è il prodotto completo richiesto, non il checkpoint 0.11.1-dev. Nessun invito ad installarlo in produzione.
