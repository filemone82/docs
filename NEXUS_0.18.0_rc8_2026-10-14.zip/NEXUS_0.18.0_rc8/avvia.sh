#!/usr/bin/env bash
# Avvio su Linux (prove; sul VPS si userà un servizio di sistema, vedi LEGGIMI.md)
set -e
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then
  python3.12 -m venv .venv
  .venv/bin/pip install -r requirements.txt
fi
[ -f config.json ] || cp config.esempio.json config.json
exec .venv/bin/python -m gestionale
