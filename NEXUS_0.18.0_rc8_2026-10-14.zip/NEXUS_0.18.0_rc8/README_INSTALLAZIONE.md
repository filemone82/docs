> **NEXUS 0.18.0 rc3, collaudo PostgreSQL su Windows:** seguire `COLLAUDO_POSTGRESQL_RC3.md` e il launcher `AVVIA_NEXUS_POSTGRESQL_WINDOWS.bat`. Le istruzioni seguenti descrivono principalmente le versioni SQLite precedenti.

> Versione storica 0.17.0: leggere `MIGRAZIONE_0.17.0.md` solo per il precedente passaggio di versione.

# NEXUS 0.16.0 · gestionale integrato AD

12 ottobre 2026. Versione applicativa `0.16.0`, schema Alembic `0027`. Non è una candidata completa né una versione pronta per la produzione.

**Novità della 0.15.0** (`documentazione/42_Differenze_0.15.0_2026-10-12.md`), verbali DM come in VerbalizzAI:
- **anteprima PDF «BOZZA»** con lo spazio della firma riservato, riquadro firme intero e in fondo alla pagina, nessuna pagina bianca finale (i modelli M14 e M11 di AD non cambiano);
- **firma DM obbligatoria**: senza, niente anteprima né emissione;
- **«Firma ed emetti»**: la firma DM entra nello spazio riservato e il PDF firmato deve avere le stesse pagine dell'anteprima;
- **«Aggiorna / Conserva i dati del verbale»** all'emissione.

**Novità della 0.14.0** (`documentazione/41_Differenze_0.14.0_2026-10-12.md`), fatture DPR complete pari a Garda:
- **dati fiscali di AD** completi (REA, capitale, socio unico, contatti) nell'XML;
- **documento emesso in seguito a**: ordini, contratti, convenzioni… con CIG, CUP e commessa;
- **modalità di pagamento con le regole di Garda** (codice MP, rate, fine mese, spostamento 31/8 e 31/12, «salda subito», predefinita): le scadenze si calcolano dal preventivo, poi dal cliente, poi dalla predefinita;
- **nome del file SdI** con progressivo di 5 caratteri (prima, dalla fattura 4096, sarebbe stato scartato);
- **ricevute SdI** scaricate da Aruba caricate da file (anche ZIP): consegna, scarto, mancata consegna, esito PA, decorrenza termini;
- **XML delle fatture selezionate** in un solo ZIP;
- **Scadenze di pagamento** (menu Fatture) con rate scadute, da incassare e saldate; avvisi del bollo e della PA nella bozza.

**Novità della 0.13.1** (`documentazione/40_Differenze_0.13.1_2026-10-12.md`):
- il gestionale si chiama **NEXUS** (R133): logo nella schermata di accesso e nel menu, icona nella scheda del browser. File `.bat`, cartelle dei dati e `config.json` restano quelli di prima;
- **ruoli distinti per attività** (R132): RT DPR, RT DM, Verificatore DPR, Verificatore DM, Verificatore DM e DPR; amministratore e segreteria comuni. Dopo l'aggiornamento gli utenti restano sul loro ruolo (ora DPR): **assegna i ruoli DM** in Gestione › Utenti e permessi;
- rilievi del revisore: osservazioni del verbale combinato dall'ultimo funzionamento (AD-REV-006), nome INAIL dei GVR con l'attività e nessuna sovrascrittura nella cartella dei verbali (AD-REV-007), limite della firma DM chiarito (AD-REV-008).

**Novità della 0.13.0** (`documentazione/39_Differenze_0.13.0_2026-10-12.md`), prima parte di VerbalizzAI_DM:
- nella scheda di un'attrezzatura GVR o SC/SP, linguetta **«Dati del verbale»**: i dati che passano da un verbale all'altro, con la provenienza, «Correggi» e lo storico; la bozza del verbale riparte da lì;
- nel verbale GVR, Pes e Tes del funzionamento precedente come confronto;
- **firma DM** di ogni tecnico, distinta dalla firma DPR di VerbalizzAI: si carica in Gestione › Utenti e permessi o in «Il mio profilo»;
- **copia dei verbali DM definitivi** nella cartella indicata in `config.json` (`cartella_verbali_dm`), con nome INAIL e nome leggibile.

**Novità della 0.12.10** (`documentazione/38_Differenze_0.12.10_2026-10-12.md`): le **maschere AD_DM** indicate da Federico — Clienti, Sedi, Attrezzature GVR e SC/SP (raggruppate per sede operativa, dismesse nascoste), Scadenze, Preventivi, Verifiche GVR e SC/SP, Fatture (anche AD_DM, con stampa rapida del PDF di cortesia). Le colonne di partenza si cambiano da «Colonne» e si salvano in «Configurazioni».

**Novità della 0.12.9** (`documentazione/37_Differenze_0.12.9_2026-10-12.md`):
- il **preventivo DM** prende solo le verifiche dell'allegato VII D.Lgs. 81/08 di attrezzature non esenti; in Scadenze la colonna «Regime» e il filtro «Attività EX» mostrano il resto (R129);
- **schede ridimensionabili**: maniglia sul bordo sinistro, ⤢ «a tutto schermo», larghezza in proporzione alla finestra (R130);
- **affidamento dalla scheda del preventivo**, linguetta «Righe»: 👤 «Affida» sulla riga o sulle righe spuntate, preventivo precedente/successivo;
- **Verifiche AD_DM** con la griglia standard e «seleziona tutte»;
- **dati del tecnico** in Gestione › Utenti e permessi (o «Il mio profilo»); nell'incarico DM la linguetta si chiama «Verbale»;
- **termini di esecuzione** configurabili in Gestione › Configurazione e proposti nel preventivo;
- correzione dei due residui del revisore AD-REV-002 e AD-REV-005.

**Novità della 0.12.8** (`documentazione/36_Differenze_0.12.8_2026-10-11.md`):
- **revoca dell'accettazione** di una riga di preventivo con motivo obbligatorio (R124); «Accetta» su righe già accettate non cambia nulla; colonna «Sel.» distinta da «Stato della riga»; il riesame conforme non si ripete se nulla è cambiato;
- **fatture dalle righe dei preventivi, come in Garda** (R125): filtro «Da fatturare» in Verifiche e nelle Righe dei preventivi, «Fattura le selezionate…» crea la bozza;
- **AD_DM**: in Scadenze si spuntano le scadenze e «Prepara preventivo DM…» crea una riga per scadenza (mai combinate); prima periodica proposta dalla scheda, blocco se manca «soggetta a messa in servizio» (art. 4/5 D.M. 329/04), colonna di tariffa V1–V4 visibile; sconto predefinito del cliente come in Garda;
- **menu richiudibile**; **Gestione › Configurazione** raccoglie modelli, firme, strumenti, elenchi, email, importazioni, registro e backup; in AD_DM i sei cataloghi in una schermata, **Tipi e tariffe**; **Utenti e permessi** in una pagina, come in VerbalizzAI;
- correzione dei cinque rilievi del revisore AD-REV-001…005 (registro aggiornato in `documentazione/Registro_rilievi_Gestionale_AD_0.12.8.txt`);
- uno ZIP di verbali caricato al posto del backup di VerbalizzAI dà un messaggio chiaro invece di «Errore imprevisto».

**Novità della 0.12.7** (`documentazione/35_Differenze_0.12.7_2026-10-11.md`):
- **una sola scheda tecnica per l'impianto** (R122): è quella di VerbalizzAI, da cui riparte il verbale successivo. Nell'impianto la linguetta «Scheda tecnica» la mostra e «Modifica scheda tecnica» la apre in VerbalizzAI. La copia del gestionale (offerte, ricerche) si riallinea da sola, anche quando all'emissione si sceglie «Conserva la scheda»;
- il **Word caricato a mano** su una verifica entra anche nell'archivio dei verbali e aggiorna la scheda: la bozza successiva riparte da lì.

**Novità della 0.12.6** (`documentazione/34_Differenze_0.12.6_2026-10-11.md`):
- **indipendenza** dichiarata solo dal verificatore assegnato (anche il RT, se è lui l'assegnatario); predefinita «Sì»; con «No» la verifica torna al RT da riassegnare (DPR e DM);
- **affidamento dell'incarico dalle righe dei preventivi** (DPR e DM), come in Garda;
- **verbale precedente**: dalla verifica si carica il Word dell'ultimo verbale e la bozza riparte dal suo contenuto; data di emissione uguale alla data del verbale; l'anteprima PDF dei verbali usa il LibreOffice indicato in `config.json`;
- **clienti**: fusione con adsrl solo se la corrispondenza è certa; «Possibili doppioni» anche per i clienti, con «Unisci» e «Sono clienti diversi»;
- **corrispondenze con Garda** in una tabella (id di Garda → cliente, sede, impianto, preventivo, riga, verifica), mostrate nelle schede come «Provenienza»;
- **schede Cliente e Sede nel contesto AD_DM** (attrezzature, scadenze, preventivi e righe DM); **Scadenze AD_DM** come elenco completo;
- correzione: «Possibili doppioni» di sede si rilegge dal server dopo ogni scelta;
- ruoli di base: Amministratore, Responsabile tecnico, Verificatore (nomi e permessi modificabili).

**Novità della 0.12.5** (`documentazione/33_Differenze_0.12.5_2026-10-11.md`):
- **menu come i gestionali di Garda**, per ogni attività: Clienti · Impianti (DPR) o Attrezzature (DM) · Scadenze · Preventivi · Verifiche · Fatture · Gestione. In AD_DM: Attrezzature e Valvole di sicurezza come elenchi completi (filtri, colonne, Excel), più i cataloghi di Garda (tipi di attrezzature, tipi GVR, ID specifiche, tipi/ID specifiche, tariffe SC/SP e GVR);
- **sedi doppie**: nell'importazione la sede adsrl con lo stesso indirizzo di una sede DPR dello stesso cliente si unisce a quella; le altre coppie probabili si confermano in Sedi operative › «Possibili doppioni» («Unisci» o «Sono sedi diverse»); «Unisci con…» nella scheda della sede;
- **preventivi solo nel proprio ambito**: nel nuovo preventivo DM solo sedi AD_DM, nel DPR solo clienti AD_DPR;
- **quadratura degli accoppiamenti** nel rapporto di importazione (sedi attese/presenti, ogni bene nella sede giusta, collegamenti).

**Novità della 0.12.4** (`documentazione/32_Differenze_0.12.4_2026-10-11.md`):
- **importazione dei dati veri di AD_dm** (database `adsrl` di Garda) nell'archivio di prova già creato da `ingecert`: clienti fusi per partita IVA o codice fiscale, sedi, attrezzature SC/SP/GVR con camere, accessori con tarature e collegamenti, date ultima/prossima per componente;
- **ambiti di lavoro** su clienti e sedi (AD_DPR, AD_DM, I&C): anagrafica unica, ma gli elenchi di Clienti e Sedi mostrano solo quelli dell'attività scelta in alto, con un pulsante per vederli tutti;
- campi degli accessori (tipologia, DN, diametro, area, pressione di taratura) nella scheda.

Cosa cambia rispetto alla 0.12.1-wip1 (passo A del documento 18): `documentazione/30_Differenze_0.12.2_2026-10-11.md`; correzioni della 0.12.3 dopo la prima prova su Windows: `documentazione/31_Differenze_0.12.3_2026-10-11.md`. In sintesi: indipendenza bloccante in DPR e DM (programmazione, registrazione, esecuzione); riesame negativo DM con nota in evidenza per il tecnico e date CND ripristinate alla riapertura; storico dei riesami del preventivo visibile; visita interna solo per generatori di vapore e di acqua surriscaldata; VerbalizzAI 1.0.1 rc2 incorporato identico a quello in produzione, con controllo automatico. Risultati delle prove: `report_collaudo/pytest_0.12.3.txt`.

## Installazione nuova di prova su Windows

Servono Python 3.12 a 64 bit con launcher e PATH, LibreOffice, un browser e connessione per scaricare le dipendenze.

1. Scompatta lo ZIP in una cartella nuova e apri `NEXUS_0.16.0`, dove si trovano `INSTALLA_WINDOWS.bat` e `gestionale`.
2. Copia `config.esempio.json` in `config.json` prima di installare; controlla che l'estensione non sia duplicata (`config.json.json`). L'esempio configura accesso locale sulla porta 8462.
3. Esegui `INSTALLA_WINDOWS.bat` e attendi il completamento senza errori. Non copiare l'ambiente `.venv` da un altro programma.
4. **Facoltativo ma consigliato:** esegui `ESEGUI_TEST_WINDOWS.bat`. Devono risultare 297 test passati (sul PC dell'ufficio richiedono circa un quarto d'ora); se qualcuno fallisce, mandami la finestra o il file di log.
5. Esegui `AVVIA_COLLAUDO_WINDOWS.bat`: usa `Dati_Collaudo` dentro la cartella del programma, separata dagli archivi operativi. In alternativa `AVVIA_TEST_WINDOWS.bat` crea un archivio di prova con utenti, clienti, impianti e verifiche finti.
6. Apri l'indirizzo stampato nella finestra; con l'esempio è `http://127.0.0.1:8462`. Su un archivio nuovo crea l'amministratore; su una copia usa le credenziali di quella copia.
7. Arresta con Ctrl+C nella finestra del server.

Se LibreOffice non viene trovato, indica in `config.json` la voce `libreoffice` con il percorso effettivo di `soffice.exe`, usando doppie barre inverse nel JSON, e riavvia.

## Provare con i dati veri di Garda (AD_dpr + AD_dm)

Crea un archivio di prova **separato** (`GestionaleAD_dati_GARDA`, accanto alla cartella del programma). I database di Garda non vengono toccati: si legge solo il file `.sql`. I dati restano sul tuo PC.

1. Se esiste già `GestionaleAD_dati_GARDA` da una prova precedente, chiudi il programma e cancella (o rinomina) quella cartella.
2. Doppio clic su `IMPORTA_DA_GARDA_WINDOWS.bat`:
   - trascina nella finestra `D:\backup_gestionale\ingecert\db\ingecert_2026-10-07.sql` e premi Invio;
   - poi trascina `D:\backup_gestionale\adsrl\db\adsrl_2026-10-07.sql` e premi Invio (solo Invio per saltarlo).
   Circa un minuto. Alla fine **scrivi la password provvisoria di `admin`**: è l'ultima cosa mostrata e non viene salvata.
3. Doppio clic su `AVVIA_GARDA_WINDOWS.bat`, accedi come `admin` e cambia la password.
4. In alto, «Attività»: con AD_DPR in Clienti e Sedi vedi i clienti con impianti, con AD_DM quelli con attrezzature. Il pulsante verde «Solo AD_DM ✓» sopra l'elenco li mostra tutti.
5. In Sedi operative › «Possibili doppioni» trovi le coppie di sedi (una AD_DPR, una AD_DM) dello stesso cliente e comune che l'importazione non ha unito da sola: per ciascuna «Unisci» oppure «Sono sedi diverse».
6. I rapporti sono in `GestionaleAD_dati_GARDA`: `importazione_garda.txt` (ingecert) e `importazione_garda_adsrl.txt` (adsrl, con la quadratura tabella per tabella e del volume delle camere).

Se hai già un archivio GARDA della 0.12.3 e vuoi solo aggiungere adsrl: `AGGIUNGI_ADSRL_WINDOWS.bat` (si fa una volta sola; la password resta quella di prima).

Cosa **non** entra ancora da adsrl: preventivi, verifiche/verbali e fatture AD_dm (passo D). Il database `iec` non si importa: il modulo I&C non c'è ancora.

## Aggiornare una copia della 0.14.0, 0.13.1, 0.13.0, 0.12.10, 0.12.9, 0.12.8, 0.12.7, 0.12.6, 0.12.5, 0.12.4, 0.12.3, 0.12.2, 0.12.1-wip1 o 0.12.0-dev

1. Crea e scarica un backup completo dal vecchio programma (Sistema › Backup e integrità), poi arrestalo.
2. Conserva programma e dati precedenti. Installa questa versione in una cartella nuova.
3. Prima di avviare copia l'intera cartella dei dati precedente in `Dati_Collaudo` della nuova cartella: database, documenti, archivio VerbalizzAI e altri file insieme.
4. Avvia `AVVIA_COLLAUDO_WINDOWS.bat`. Il programma crea il backup pre aggiornamento e applica le migrazioni mancanti fino alla `0027` (dalla 0.12.0-dev anche la `0015`). Dalla 0.16: la `0023` aggiunge i ruoli aggiuntivi degli utenti; la `0024` porta l'ambito sul cliente (le sedi lo ereditano; nessun ambito si perde); la `0025` aggiunge le attività dei commerciali (prese dai clienti che seguono, altrimenti AD_DPR) e gli strumenti di misura DM e I&C; la `0026` i dati per la fattura e i file dell'accettazione sul preventivo; la `0027` le revisioni dei verbali DM. La `0022` aggiunge le regole delle modalità di pagamento e il nome SdI dei file XML; non cambia i dati esistenti. La `0021` aggiunge l'attività ai ruoli: «Responsabile tecnico» e «Verificatore» diventano i ruoli DPR e nascono RT DM, Verificatore DM, Verificatore DM e DPR con gli stessi permessi. La `0020` aggiunge la tabella dei dati del verbale DM corretti a mano; non cambia i dati esistenti. La `0018` ricava le corrispondenze con Garda dai riferimenti già presenti. La `0019` aggiunge le revoche dell'accettazione, lo sconto predefinito AD_DM dei clienti (0 dove manca) e la data di eliminazione nelle provenienze; non cambia dati esistenti. La `0016` ricava gli ambiti da quello che c'è: impianti → AD_DPR, attrezzature → AD_DM; un cliente senza nulla diventa AD_DPR.
5. Per tornare indietro riapri i dati conservati con il vecchio programma; non collegarlo al database aggiornato.

## Cosa provare (5 minuti)

Novità della 0.16.0:
- **Attrezzature:** «＋ Nuova attrezzatura GVR» dall'elenco filtrato per sede: sede già scelta, gruppo GVR, sezione «Ultima e prossima verifica» (la prossima è obbligatoria); poi controlla che compaia in Scadenze.
- **Accessori · PSV:** «＋ Nuovo accessorio (PSV)», oppure dalla scheda di un GVR «＋ Nuovo accessorio per questa attrezzatura».
- **Clienti:** l'ambito si cambia solo nella scheda del cliente; la sede lo mostra «dal cliente».
- **Utenti:** spunta più ruoli (es. RT DPR + Verificatore DM).
- **Preventivo:** linguetta «Accettazione e ordine»: carica il PDF dell'ordine e i dati per la fattura (tipo doc., n°, data, CIG, CUP).
- **Fatture:** Verifiche › spunta le verifiche da fatturare › «Fattura le selezionate…»; apri la bozza: «Prima di emettere manca» e «PDF di cortesia».
- **Configurazione:** cambia attività in alto (AD_DPR, AD_DM): voci diverse; Impostazioni email per attività.
- **Verbali DM:** su un incarico effettuato «Crea revisione»; nelle Verifiche GVR «Registra le selezionate…». Modelli M14/M11 **rev. 03**: in Gestione › Configurazione › Modelli (AD_DM), «Metti in uso» dopo aver approvato i PDF di prova.

Novità della 0.15.0 (serve LibreOffice):
- carica la **firma DM** del tecnico («Il mio profilo» › Dati del tecnico);
- in un incarico DM registrato, linguetta **Documenti** › «Genera anteprima PDF»: controlla il riquadro firme in fondo alla pagina e il riquadro tratteggiato della firma;
- «**Firma ed emetti il verbale**», scegliendo «Aggiorna» o «Conserva» i dati del verbale.

Novità della 0.14.0:
- **Modalità di pagamento:** Fatture › «Modalità di pagamento»: controlla codice MP e rate di ognuna, scegli la predefinita.
- **Bozza:** «Dati documento» › «Documento emesso in seguito a» (ordine con CIG); poi «Scadenze» › «Calcola dalla modalità di pagamento».
- **Dati fiscali AD:** completa REA, capitale sociale, telefono ed email.
- **XML in blocco:** spunta alcune fatture emesse › «⬇ XML delle selezionate (ZIP)».
- **Scadenze di pagamento:** menu Fatture.

Novità della 0.13.1:
- **Ruoli:** Gestione › Utenti e permessi › Ruoli: colonna «Attività» e, nella scheda del ruolo, le caselle AD_DPR / AD_DM. Assegna a un utente «Verificatore DM»: in alto vede solo AD_DM, e nelle Verifiche DPR non entra.
- **Affidamento:** nella finestra «Affida» di un incarico DM compaiono solo i verificatori DM (e DM e DPR).

Novità della 0.13.0:
- **Cartella dei verbali DM:** in `config.json` metti `"cartella_verbali_dm": "D:\\VERBALI_DM_PROVA"` e riavvia.
- **Firma DM:** «Il mio profilo» › Dati del tecnico › «Carica la firma DM».
- **Dati del verbale:** Attrezzature GVR › scheda › «Dati del verbale» › «Correggi»; poi un nuovo incarico su quell'attrezzatura riparte dai dati corretti.

Novità della 0.12.9:
- **Scheda:** apri un preventivo, trascina il bordo sinistro della scheda o premi ⤢.
- **Affidamento:** in un preventivo accettato e riesaminato, linguetta «Righe»: spunta più righe e premi «👤 Affida le selezionate…», oppure 👤 «Affida» sulla singola riga.
- **Scadenze AD_DM:** filtro «Attività EX»; «Prepara preventivo DM…» rifiuta CND, tarature e attrezzature esenti.
- **Dati del tecnico:** Gestione › Utenti e permessi › scheda dell'utente.

Novità della 0.12.8:
- **Revoca:** in un preventivo accettato, linguetta «Righe», spunta una riga in «Sel.» e premi «Revoca accettazione…» con un motivo. La verifica «da assegnare» si annulla; riaccettando la riga, in «Riesame» ricompare il modulo del nuovo riesame.
- **Fatture:** Verifiche › «Da fatturare» → «Vai alle righe da fatturare →» → spunta le righe → «Fattura le selezionate…».
- **Scadenze AD_DM:** «Da preventivare», spunta alcune scadenze, «Prepara preventivo DM…».
- **Menu e Gestione:** apri e chiudi i gruppi del menu; Gestione › Configurazione; Gestione › Utenti e permessi; in AD_DM Attrezzature › Tipi e tariffe.

- **Indipendenza:** affida una verifica a un verificatore ed entra come lui: nella verifica trova «Dichiaro la mia indipendenza…» già spuntata. Togliendo la spunta (e confermando) la verifica torna «Da assegnare» con la nota in rosso per il RT. Il RT non può dichiarare al posto del verificatore.
- **Righe dei preventivi:** spunta righe accettate e premi «Affida le selezionate…».
- **Verbale precedente:** in una verifica registrata, «Verbale precedente» → carica il Word dell'ultimo verbale → «Compila il verbale».
- **Clienti doppi:** Clienti › «Possibili doppioni».

- **Menu:** scegli «Attività» AD_DM: Clienti, Attrezzature (attrezzature, valvole, tipi e tariffe), Scadenze, Preventivi, Verifiche, Fatture, Gestione. Con AD_DPR: Clienti, Impianti, Scadenze, Preventivi, Verifiche, Fatture, Gestione.
- **Sedi doppie:** Sedi operative › «Possibili doppioni»; oppure «Unisci con…» nella scheda di una sede.
- **Preventivo DM:** «Nuovo preventivo» propone solo sedi AD_DM; per una sede che non lo è, aggiungi AD_DM nella sua scheda e riprova.

- **Ambiti:** con «Attività» AD_DM apri Clienti: vedi solo quelli con attrezzature. Clic su «Solo AD_DM ✓» → «Tutti gli ambiti». Apri un cliente: in «Dati generali» ci sono le caselle AD_DPR, AD_DM, I&C. Prova a togliere AD_DPR a un cliente che ha impianti: deve rifiutare spiegando perché.

- **Indipendenza:** su una verifica DPR assegnata metti l'indipendenza a «No» e prova a programmarla o registrarla: deve rifiutare. Rimettila a «Sì»: funziona.
- **Riesame DM negativo:** nell'ambiente di prova entra come `responsabile`, apri AD_dm › Incarichi DM, l'incarico chiuso del serbatoio (V/GVR/0001/26) e registra un riesame «Non conforme» con nota; poi entra come `tecnico1`: in «Incarico» deve comparire il riquadro rosso con la nota e lo stato «Registrata».
- **Storico riesami preventivo:** su un preventivo accettato registra prima un riesame non conforme e poi uno conforme: nella linguetta «Riesame» devono comparire entrambi.
- **Visita interna:** su un recipiente GVR (famiglia a1) la visita interna non deve essere proposta né accettata in offerta; su un generatore di vapore sì.

## Avvio isolato su Linux

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
cp config.esempio.json config.json
GESTIONALE_CARTELLA_DATI="$PWD/Dati_Collaudo" .venv/bin/python -m gestionale
```

## Parti ancora sperimentali (API, senza schermate)

Fatturazione DM, PDF fiscali archiviati e lotti INAIL sono la bozza backend della 0.12.1-wip1, invariata: non usarli su archivi di produzione. Percorsi: `/api/fatture` e `/api/fatture/fatturabili` con ambito; `/api/fatture/{id}/pdf-archivia`, `/pdf-carica`, `/documenti/{documento_id}`; `/api/dm/inail/candidati`, `/anteprima`, `/lotti`, `/lotti/{id}/file`, `/reimposta`. Saranno completati e collaudati nel passo D.

