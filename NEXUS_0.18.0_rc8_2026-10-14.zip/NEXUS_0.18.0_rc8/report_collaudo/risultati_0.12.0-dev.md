# Collaudo osservato 0.12.0-dev

10 ottobre 2026, Linux/Python 3.12.14/SQLite. VerbalizzAI 1.0.1 rc2 incorporato, migrazione 0014.

| Prova | Esito |
|---|---|
| Suite generale `python -m pytest -q` | 213 passati, 1 avviso TestClient, 447,00 secondi. TXT/XML `pytest_finale_0.12.0-dev`. |
| Ultimo ampliamento CND: `pytest tests/test_dm_documenti.py::test_cnd_confronto_date_e_report_preservato -q` | 4 passati, 9,89 secondi, 1 avviso TestClient. Due scenari già nella suite e due aggiuntivi: prossima uguale e aggiornamento senza nuovo numero report. |
| Casi distinti eseguiti | 215, senza sommare nuovamente i sottoinsiemi. Raccolta finale della suite: 215 test. |
| DOM+HTTP JavaScript/backend reali | Passato fino a Word/PDF, conferma, chiusura e riesame. Convertitore simulato nel solo server di prova; risultato `ui_tecnico_0.12.0-dev.txt`. |
| PDF DM LibreOffice reale | Tre test, GVR/SC/SP, inclusi nei 213. Nessun conteggio aggiuntivo. |
| Ispezione visiva | Tutte le quattro pagine dei tre campioni sintetici renderizzate e ispezionate. Etichette, caselle, camere, firma, date e parti fisse controllate. |
| Ruff E9/F | Passato sui file DM e comuni interessati; `lint_0.12.0-dev.txt`. |
| Sintassi JavaScript | Passata per incarichi DM, modelli Word e prova DOM DM. |

Il numero di prove non dimostra la completezza Garda. SMTP simulato con confronto dell’allegato; nessuna email esterna. Offerte nella suite ordinaria con conversione simulata. Nessuna prova Windows/Microsoft Word, PostgreSQL, domini/VPS o import completo dei tre dump. Limiti e regole ancora aperte nel rapporto 27 e stato 0.12.

I due scenari CND sono stati aggiunti dopo la raccolta della suite generale e verificati separatamente; il suo XML registra quindi 213 casi. Per rieseguire tutti i 215 nella stessa invocazione usare la suite ordinaria corrente. L’avviso riguarda il TestClient di collaudo, non un test fallito.
