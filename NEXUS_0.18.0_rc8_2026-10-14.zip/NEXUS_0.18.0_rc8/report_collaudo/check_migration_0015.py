from pathlib import Path
import json, sys, tempfile
from alembic import command
from sqlalchemy import create_engine
from alembic.autogenerate import compare_metadata
from alembic.runtime.migration import MigrationContext
project_root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(project_root))
from gestionale.core import migrazioni
from gestionale.modelli import Base

temporary = tempfile.TemporaryDirectory(prefix='gestionale_migrazione_0015_')
target = Path(temporary.name) / 'cataloghi.sqlite'
command.upgrade(migrazioni.config_alembic('sqlite:///' + str(target)), '0014')
engine = create_engine('sqlite:///' + str(target))
assert migrazioni.revisione_database(engine) == '0014'
with engine.connect() as connection:
    old_tables = [x[0] for x in connection.exec_driver_sql("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]
    old_rows = {name: connection.exec_driver_sql('SELECT * FROM "' + name + '" ORDER BY rowid').fetchall() for name in old_tables if name not in ('alembic_version', 'dm_incarichi', 'fatture_righe')}
migrazioni.aggiorna(engine)
assert migrazioni.revisione_database(engine) == '0015'
with engine.connect() as connection:
    assert connection.exec_driver_sql('PRAGMA foreign_key_check').all() == []
    differences = compare_metadata(MigrationContext.configure(connection), Base.metadata)
    assert differences == [], differences
    for name, rows in old_rows.items():
        assert rows == connection.exec_driver_sql('SELECT * FROM "' + name + '" ORDER BY rowid').fetchall(), name
    for name, column in [('dm_incarichi', 'esportata_inail'), ('fatture_righe', 'prestazione_intera')]:
        assert any(row[1] == column for row in connection.exec_driver_sql('PRAGMA table_info("' + name + '")'))
    counts = {name: len(rows) for name, rows in old_rows.items() if rows}
result = {'result': 'PASS', 'source_schema': '0014', 'target_schema': '0015', 'schema_model_differences': 0, 'foreign_key_errors': 0, 'preserved_nonempty_tables': counts, 'limitation': 'Archivio sintetico di cataloghi; nessun incarico o riga fattura preesistente in questa prova specifica. Nessuna migrazione dei dump Garda.'}
print(json.dumps(result, ensure_ascii=False, indent=2))
engine.dispose()
temporary.cleanup()
