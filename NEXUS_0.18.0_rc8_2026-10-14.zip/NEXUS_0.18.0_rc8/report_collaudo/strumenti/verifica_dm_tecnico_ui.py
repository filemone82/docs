"""DOM/HTTP incarichi DM, archivio sintetico e conversione offerte simulata."""
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import tempfile
import time

import httpx

root=Path(__file__).resolve().parents[2]
strumenti=Path(__file__).resolve().parent
env=os.environ.copy();env['PYTHONPATH']=str(root)+os.pathsep+str(strumenti)+os.pathsep+env.get('PYTHONPATH','')
with tempfile.TemporaryDirectory(prefix='gad_dm_tecnico_ui_') as folder:
    env['GESTIONALE_TEST_UI_DATI']=folder
    p=subprocess.Popen([sys.executable,'-m','uvicorn','ui_server_tecnico:app','--host','127.0.0.1','--port','8468'],cwd=root,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    try:
        for _ in range(100):
            if p.poll() is not None:raise RuntimeError(p.stderr.read().decode())
            try:
                with socket.create_connection(('127.0.0.1',8468),timeout=.2):break
            except OSError:time.sleep(.1)
        else:raise RuntimeError('Server non avviato')
        with httpx.Client(base_url='http://127.0.0.1:8468',trust_env=False) as c:
            def call(method,url,data=None):
                r=c.request(method,url,json=data);assert r.status_code==200,r.text;return r.json()
            call('POST','/api/primo-avvio',{'username':'collaudo','nome':'Collaudo tecnico DM','password':'ProvaAmbiente9!Localmente'})
            csrf=re.search(r'name="csrf" content="([^"]+)"',c.get('/profilo').text).group(1);c.headers['X-CSRF-Token']=csrf
            cli=call('POST','/api/clienti',{'ragione_sociale':'Cliente UI DM','tipo':'privato','partita_iva':'01234567897','codice_fiscale':'01234567897','comune_istat':'001272'})
            sede=call('POST','/api/sedi',{'cliente_id':cli['id'],'denominazione':'Sede UI DM','comune_istat':'001272'})
            a=call('POST','/api/beni',{'gruppo':'GVR','sede_id':sede['id'],'matr_informale':'GVR-UI-TECNICO','denominazione':'Recipiente UI tecnico',
                'anno_matricola':'2020','cod_att_matricola':'A','num_matricola':'00001','prov_immatr':'TO','tipo_attr_id':18,'id_spec_id':40,
                'dati_dm':{'tipo_attr_verbale':'RG','esente_verifiche':'F','tipo_prox_verifica':'V2'}})
            for ident,unita,valore in [('Camera UI','L','100'),('Tubo UI','DN','80')]:
                a=call('POST',f"/api/beni/{a['id']}/camere",{'versione':a['versione'],'identificazione':ident,'num_fabbrica':ident,'unita':unita,'valore':valore,'dati_tecnici':{'gvr_ps':'10'}})
            of=call('POST','/api/preventivi',{'ambito':'DM','sede_id':sede['id'],'attrezzature':[{'asset_id':a['id'],'tipo_verifica_dm':'V2','tipo_verifica_gvr':'funz_integrita'}]})
            doc=call('POST',f"/api/preventivi/{of['id']}/anteprima")['documento']
            call('POST',f"/api/preventivi/{of['id']}/documenti/{doc['pdf_documento_id']}/approva")
            of=call('GET',f"/api/preventivi/{of['id']}")
            of=call('POST',f"/api/preventivi/{of['id']}/inviato",{'versione':of['versione']})
            call('POST',f"/api/preventivi/{of['id']}/righe/stato",{'versione':of['versione'],'righe':[of['righe'][0]['id']],'stato':'accettata','evidenza_accettazione':'Conferma scritta test UI'})
            call('POST',f"/api/preventivi/{of['id']}/riesame",{'esito':'conforme','requisiti_chiari':True,'competenza_strumenti':True,'imparzialita':True,'tempi':True})
            v=call('GET','/api/dm/incarichi')[0]
            fixture=Path(folder)/'fixture.json'
            fixture.write_text(json.dumps({'cookie':'; '.join(k+'='+v for k,v in c.cookies.items()),'base':str(c.base_url).rstrip('/'),
                'incarico_id':v['id'],'asset_id':a['id'],'tecnico_id':call('GET','/api/io')['id']}))
            env['GAD_UI_FIXTURE']=str(fixture)
            subprocess.run(['node',str(strumenti/'verifica_dm_tecnico_ui.cjs')],check=True,env=env)
    finally:
        p.terminate();p.wait(timeout=10)
