"""Server esclusivamente di prova: conversione offerte PDF simulata, non rilascio."""
import io
from pypdf import PdfWriter
from gestionale.core import pdf
def pdf_prova(docx, conf=''):
    stream = io.BytesIO()
    w = PdfWriter()
    w.add_blank_page(width=595, height=842)
    w.write(stream)
    return stream.getvalue()
pdf.da_word = pdf_prova
from ui_server_final import app  # noqa: E402,F401
