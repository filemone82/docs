from pathlib import Path
import os
from gestionale.app import crea_app
from gestionale.core.config import Config
app=crea_app(Config(cartella_dati=Path(os.environ['GESTIONALE_TEST_UI_DATI']),backup_automatico=False,iterazioni_password=1000,apri_browser=False))
