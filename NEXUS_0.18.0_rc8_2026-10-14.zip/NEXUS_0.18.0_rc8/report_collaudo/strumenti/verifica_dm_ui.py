import os,subprocess,sys,time,socket,tempfile,json,re
from pathlib import Path
import httpx
root=Path(__file__).resolve().parents[2]
project=root
strumenti=Path(__file__).resolve().parent
env=os.environ.copy();env['PYTHONPATH']=str(project)+os.pathsep+str(strumenti)
with tempfile.TemporaryDirectory(prefix='gad_b1_ui_') as d:
 env['GESTIONALE_TEST_UI_DATI']=d
 p=subprocess.Popen([sys.executable,'-m','uvicorn','ui_server_final:app','--host','127.0.0.1','--port','8468'],cwd=project,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
 try:
  for _ in range(100):
   if p.poll() is not None:raise RuntimeError(p.stderr.read().decode())
   try:
    with socket.create_connection(('127.0.0.1',8468),timeout=.2):break
   except OSError:time.sleep(.1)
  else:raise RuntimeError('Server non avviato')
  c=httpx.Client(base_url='http://127.0.0.1:8468',trust_env=False)
  r=c.post('/api/primo-avvio',json={'username':'collaudo','nome':'Collaudo B1','password':'ProvaAmbiente9!Localmente'});assert r.status_code==200,r.text
  csrf=re.search(r'name="csrf" content="([^"]+)"',c.get('/profilo').text).group(1);c.headers['X-CSRF-Token']=csrf
  r=c.post('/api/clienti',json={'ragione_sociale':'Cliente UI B1','tipo':'privato','partita_iva':'01234567897','codice_fiscale':'01234567897','comune_istat':'001272'});assert r.status_code==200,r.text
  cli=r.json()['id']
  r=c.post('/api/sedi',json={'cliente_id':cli,'denominazione':'Sede UI B1','comune_istat':'001272'});assert r.status_code==200,r.text
  sede=r.json()['id']
  r=c.post('/api/beni',json={'gruppo':'PSV','sede_id':sede,'matr_informale':'PSV-UI','denominazione':'Valvola UI'});assert r.status_code==200,r.text
  psv=r.json()
  r=c.put(f"/api/beni/{psv['id']}/scadenze",json={'versione':psv['versione'],'componente':'taratura','data_prossima':'2028-09-27'});assert r.status_code==200,r.text
  fixture=strumenti/'ui_b1_fixture.json';fixture.write_text(json.dumps({'cookie':'; '.join(k+'='+v for k,v in c.cookies.items()),'base':'http://127.0.0.1:8468','sede_id':sede}))
  try:subprocess.run(['node',str(strumenti/'verifica_dm_ui.cjs')],check=True,env=env)
  finally:fixture.unlink(missing_ok=True);c.close()
 finally:
  p.terminate();p.wait(timeout=10)
