# Ripetere la prova DOM + HTTP DM

Richiede le dipendenze Python del progetto, Node.js e jsdom (collaudato con la 26.1.0). La prova usa un archivio temporaneo con dati sintetici, server sulla porta 8468 e nessun invio email. Non è un collaudo grafico Windows.

Dalla cartella del programma, installare soltanto se si vuole ripetere questa verifica aggiuntiva:

```sh
npm install --prefix strumenti_ui jsdom@26.1.0
python report_collaudo/strumenti/verifica_dm_ui.py
```

La normale suite pytest non richiede Node/jsdom. Chiudere eventuali processi di prova sulla porta 8468 prima di eseguire. Il server viene terminato e l’archivio temporaneo eliminato al termine.

## Incarichi tecnici e documenti DM (0.12)

`python report_collaudo/strumenti/verifica_dm_tecnico_ui.py` esercita JavaScript e backend reali: assegnazione/programmazione, camere, registrazione, dati del tecnico, generazione Word/PDF, consultazione e conferma del PDF, chiusura e riesame. Il server dedicato `ui_server_tecnico.py` sostituisce soltanto il convertitore nel processo di prova: i PDF di offerte e verbali sono pagine bianche valide. I test `pdf_vero` della suite usano invece LibreOffice reale. Nessun invio email esterno o collaudo Windows.

Se jsdom è in un’altra cartella, impostare `GAD_JSDOM_PATH` al percorso assoluto di `node_modules/jsdom`. Per dipendenze Python in una cartella dedicata, `PYTHONPATH` viene conservato dal lanciatore.
