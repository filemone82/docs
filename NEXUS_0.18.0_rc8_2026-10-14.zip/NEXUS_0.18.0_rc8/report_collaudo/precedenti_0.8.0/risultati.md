# Collaudo osservato — AD_dpr 0.8.0

9 ottobre 2026, ora italiana. Ambiente effettivo: Linux, Python 3.12, dipendenze fissate dal pacchetto, SQLite e LibreOffice. Non è stata eseguita una prova su Windows.

- **121 test passati**, nessun fallimento e nessun test saltato; durata 101,55 secondi. Comando: `python -m pytest -q` dalla cartella del programma. Output integrale in `pytest_121_test.txt`.
- Un avviso di deprecazione di Starlette riguarda il client HTTP usato nei test; non è un fallimento. Le dipendenze restano fissate al set effettivamente provato.
- Controllo Ruff sui nuovi file economici, date, migrazioni, audit e test economici: nessun errore. Non è una dichiarazione di lint completo di tutto il codice ereditato o di terze parti.
- Conversione PDF reale con LibreOffice: copia di cortesia della fattura generata e verificata; conversioni degli altri test secondo i marker del progetto. Molti test operativi usano deliberatamente PDF sintetici per isolare le regole: non sono conteggiati come conversioni reali.
- DOM con backend HTTP e dati sintetici: apertura schermata, nuova bozza, riga da €100, emissione XML/IVA, incasso da €122 attribuito alla fattura, residuo zero, storno e riapertura del residuo. Test JavaScript eseguito con jsdom; non è un collaudo grafico in un browser Windows.
- Archivio nello schema 0008 con offerta, verifica e Word/PDF referenziati: migrazione a 0010, conservazione degli ID e dei collegamenti, importazione dello stesso RV corrente nello storico, backup pre-aggiornamento, controllo FK. Evidenze scritte mancanti negli archivi precedenti non inventate.
- Archivio deliberatamente malformato: la migrazione annulla anche i DDL, conserva revisione 0008 e righe precedenti e riattiva i vincoli. Gli errori non lasciano lo schema parzialmente aggiornato.
- Regole economiche provate: foto/XML immutabili, scarto e nuovo tentativo con stesso numero, split payment/ritenuta/scadenze, nota parziale e limite del credito, un incasso su due fatture, rollback della ripartizione errata e storno, permessi/CSRF/versione, RV negativo con storico e successiva fattura a terzo.
- Regole operative provate: sospensione/ripresa, indipendenza, accettazione con riferimento scritto, foto dell'offerta inviata, stato tecnico e VS senza spostamento della periodicità. La suite ereditata prova anche backup e ripristino e coerenza schema/modelli.

L'audit aggregato dei record ingecert è in `quadratura_ingecert.json`: 473 fatture, 1.123 righe, una negativa, una quadratura da chiarire, zero XML originali confrontati. Non sono stati importati gli incassi storici o scaricati originali S3.

La suite indipendente di VerbalizzAI citata nei materiali precedenti non è stata ricontata o rieseguita integralmente in questo giro. I 121 risultati riguardano la suite del gestionale contenuta nel pacchetto.

Restano da fare il collaudo Windows, quello dei casi reali aziendali e le integrazioni descritte in `STATO_IMPLEMENTAZIONE_0.8.0.md`. Non sono state inviate email, trasmesse fatture reali ad Aruba o cambiate basi dati operative.
