# Blocco del secondo preventivo sulla stessa verifica periodica

Versione 1.0 — 9 ottobre 2026. Requisito R98; correzione della base DPR 0.8.0 e della candidatura integrata 0.9.0.

## 1. Segnalazione e risultato

L’utente segnala che il nuovo gestionale permette due preventivi sulla stessa scadenza: dopo il primo preventivo non deve essere possibile crearne un altro senza annullare il precedente. Il controllo deve prevenire la duplicazione dell’attività, già dalla creazione e non soltanto all’accettazione.

Il difetto è stato riprodotto con richieste HTTP: creazione di P_001_26 per un impianto e successiva richiesta da scadenze producono realmente P_002_26 per lo stesso impianto. Prima della correzione il test restituisce HTTP 200 anziché il conflitto atteso. La scheda riportava un avviso, ma consentiva la seconda scrittura.

Sono disponibili due pacchetti corretti:

- **0.8.1:** aggiornamento circoscritto per chi sta collaudando la 0.8.0 DPR.
- **0.9.1:** stessa correzione nella base integrata da cui proseguire lo sviluppo. Non completa AD_DM/I&C e non modifica le loro maschere iniziali.

Non sono due gestionali da sviluppare parallelamente: la 0.8.1 è una manutenzione della versione precedente; la 0.9.1 è la base evolutiva del progetto unico.

## 2. Confronto con ingecert Garda

Fonte: `ingecert/codice/files/public_html/cust/_custom.php`, funzione `gi_preventivi_righe_save_before`, blocco intorno alle righe 569–583. La query cerca un’altra riga dello stesso impianto e tipo, **accettata**, con verifica assegnata/programmata/registrata oppure ancora assente; se la trova blocca il salvataggio e indica il preventivo. Il commento esplicita che una verifica preventivata e accettata non deve essere ripreventivabile, salvo annullamento.

La procedura `ricalcola_scadenze` dello stesso sorgente mantiene inoltre il legame fra scadenza, ultima verifica periodica e riga preventivo; non identifica il ciclo soltanto confrontando la data dell’offerta. Nel generatore batch `lavori_batch_cli.php`, funzione `gi_scadenze_preventivi_crea`, si trovano controlli e aggiornamento di `scadenze.preventivo_riga`. Questi riscontri statici non dimostrano un blocco uniforme Garda di ogni seconda bozza in tutti i canali.

**Differenza autorizzata dall’utente:** anticipare il controllo alla prima creazione della prestazione periodica, anche se la riga non è ancora accettata. È più restrittivo del controllo sulle sole righe accettate individuato in Garda. Non viene presentato come identico a tutto il comportamento storico.

## 3. Regola applicata

Per un impianto è bloccante una riga periodica il cui preventivo non sia annullato o sostituito, la cui riga non sia annullata e la cui verifica collegata non sia eseguita o riesaminata. Una riga ancora senza verifica è bloccante. Il rifiuto non viene assimilato all’annullamento, secondo l’indicazione “a meno che il primo venga annullato”. L’annullamento della singola prestazione libera quell’impianto senza imporre l’annullamento delle altre righe.

Una verifica eseguita/riesaminata ha completato la prestazione precedente e permette di preventivare la successiva. Un RV negativo riporta la verifica a registrata e torna a bloccare la duplicazione dell’attività da correggere. Non si cancellano fotografie o documenti precedenti.

Il controllo usa il legame fra riga e verifica, senza confrontare la data dell’offerta con l’ultima verifica: anche un preventivo retrodatato viene protetto e due attività successive nella stessa giornata non vengono confuse. Non si aggiunge un identificatore artificiale di scadenza e non si modifica lo schema.

Le VS restano prestazioni distinte: una straordinaria non occupa la scadenza periodica né viene usata per liberarla. I preventivi con righe libere/integrative per altre prestazioni restano ammessi. Questo incremento non introduce un nuovo criterio generale per identificare più VS indipendenti e non estende ancora il controllo alle componenti DM: il relativo raccordo appartiene al completamento dei flussi DM.

## 4. Punti protetti

| Operazione | Controllo |
|---|---|
| Creazione diretta e creazione da scadenze | Conflitto HTTP 409, con numero del preventivo esistente. |
| Aggiunta a preventivo esistente, anche indicandone il numero dalla maschera scadenze | Stesso blocco; un lotto parzialmente inserito viene interamente annullato nella transazione. |
| Cambio del tipo VS → VP su una bozza | Non consente di aggirare il blocco. |
| Revisione sostitutiva | Ammessa sul preventivo legittimo; la versione sostituita non viene contata come seconda offerta. Con duplicati preesistenti il conflitto va prima risolto. |
| Riattivazione/accettazione di righe | Le righe periodiche non annullate vengono ricontrollate. L’annullamento resta disponibile per risolvere un duplicato. |
| Generazione incarichi dopo RC | Controllo aggiuntivo prima di generare nuove verifiche, anche per due offerte già presenti in un vecchio archivio. |
| Scadenzario | Usa lo stesso criterio del backend; il filtro “Da preventivare” e il preventivo collegato sono coerenti. |
| Maschera scadenze | “Procedi” disabilitato per la periodica già coperta; collegamento all’offerta esistente. La scelta VS resta utilizzabile. |

Tutte le scritture continuano a passare dalla transazione e dal lucchetto dell’archivio locale, in un solo processo. Due richieste concorrenti creano una sola offerta. Questo non è una validazione di un futuro server PostgreSQL con più processi: quel modello richiederà un vincolo/controllo concorrente appropriato nel database.

## 5. Prove effettivamente eseguite

- Riproduzione prima della correzione: test fallito perché il secondo preventivo veniva realmente creato.
- **0.8.1: 135 test passati**, inclusi i 121 della base e 14 casi aggiuntivi; esecuzione completa 129,28 secondi.
- **0.9.1: 147 test passati**, inclusi 133 della base integrata e gli stessi 14 casi; esecuzione completa 162,09 secondi.
- Le 14 regressioni coprono i percorsi di creazione/aggiunta, rollback dei lotti, annullamento totale/per riga ed eliminazione della bozza ammessa, rifiuto, revisione, VS e cambio tipo, retrodatazione, concorrenza, completamento della verifica/RV negativo e duplicati già presenti.
- Dopo l’estensione dell’ultima prova ai duplicati preesistenti è stata rieseguita la suite specifica in entrambe le versioni: 14/14. La prova verifica anche il rifiuto dell’accettazione e il rollback dello stato.
- JavaScript effettivo `scadenze.js` eseguito in jsdom per entrambe: blocco del pulsante VP, nessuna POST duplicata, collegamento all’offerta esistente e riabilitazione per VS. Le API sono simulate nella prova DOM; il backend HTTP è verificato separatamente con TestClient.
- Ruff sui due nuovi file Python e controllo sintattico JavaScript riusciti.

Ambiente Linux, Python 3.12.14, SQLite. Non è stato provato il PC Windows dell’utente. I normali PDF della suite sono simulati come nella base; i casi `pdf_vero` conservano il loro comportamento e non costituiscono una nuova campagna di collaudo documentale DM.

I risultati pytest/XML e il resoconto DOM sono inclusi in `report_collaudo` dei pacchetti. Nessuna modifica al VPS o a VerbalizzAI autonomo; quello incorporato rimane 0.3.32.3.

## 6. Aggiornamento e dati già esistenti

Per continuare i test DPR della 0.8.0 usare la 0.8.1 su **una copia completa** della cartella dati. Per continuare lo sviluppo integrato usare la 0.9.1. Schema invariato rispetto alle rispettive basi: 0010 nella 0.8.1, 0011 nella 0.9.1. Il passaggio 0.8 → 0.9 comporta ancora la migrazione del nucleo comune e il relativo backup; questa correzione non la rende reversibile.

Le cartelle programma possono essere sostituite/versionate; gli archivi dati devono essere configurati esplicitamente. `AVVIA_COLLAUDO_WINDOWS.bat` usa `Dati_Collaudo` dentro la cartella del programma: estraendo in una cartella nuova non riutilizza automaticamente i dati del vecchio collaudo.

**Nessuna bonifica automatica:** gli eventuali duplicati prodotti dalla 0.8.0 restano nell’archivio per essere valutati e annullati con motivazione. La correzione non cancella offerte né incarichi già creati, non riscrive storici e non sceglie quale offerta conservare. Senza l’archivio dell’utente non è possibile inventariarne i duplicati effettivi. Se due incarichi sono già stati generati, il loro caso va risolto secondo stato e documenti, senza una cancellazione indiscriminata.

## 7. Seguito

Le schermate AD_DM ricevute e la critica alla 0.9.0 sono registrate nel rapporto 19. La 0.9.1 corregge il rischio DPR; **non** costituisce una risposta alle lacune della maschera attrezzatura DM. Il successivo incremento dovrà completare schede/campi/regole e organizzazione per gruppi secondo Garda, prima di dichiarare utilizzabile AD_DM.


Chiarimento successivo dell’utente (R99): il prossimo rilascio funzionale deve già integrare DPR e DM. Le correzioni qui documentate erano già realizzate; sono conservate come manutenzione e base tecnica, senza presentarle come il prossimo rilascio DM richiesto. Struttura cliente/sede delle offerte e importazione nel rapporto 21.
