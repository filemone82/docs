
CREATE TABLE cls_id_specifiche (
	id SERIAL NOT NULL, 
	gruppo VARCHAR(8) NOT NULL, 
	codice VARCHAR(20) NOT NULL, 
	descrizione TEXT NOT NULL, 
	origine_json TEXT NOT NULL, 
	CONSTRAINT pk_cls_id_specifiche PRIMARY KEY (id)
)

;

CREATE TABLE cls_tipi_attrezzature_gvr (
	id SERIAL NOT NULL, 
	codice VARCHAR(20) NOT NULL, 
	descrizione TEXT NOT NULL, 
	origine_json TEXT NOT NULL, 
	CONSTRAINT pk_cls_tipi_attrezzature_gvr PRIMARY KEY (id)
)

;

CREATE TABLE comuni (
	codice_istat VARCHAR(6) NOT NULL, 
	nome VARCHAR(100) NOT NULL, 
	sigla VARCHAR(2) NOT NULL, 
	provincia VARCHAR(80) NOT NULL, 
	regione VARCHAR(60) NOT NULL, 
	cap VARCHAR(600) NOT NULL, 
	codice_catastale VARCHAR(4) NOT NULL, 
	attivo BOOLEAN DEFAULT '1' NOT NULL, 
	CONSTRAINT pk_comuni PRIMARY KEY (codice_istat)
)

;
CREATE INDEX ix_comuni_nome ON comuni (nome);

CREATE TABLE dm_contatori (
	gruppo VARCHAR(8) NOT NULL, 
	anno INTEGER NOT NULL, 
	ultimo INTEGER NOT NULL, 
	CONSTRAINT pk_dm_contatori PRIMARY KEY (gruppo, anno), 
	CONSTRAINT ck_dm_contatori_gruppo CHECK (gruppo IN ('GVR','SC-SP'))
)

;

CREATE TABLE elenchi_valori (
	id SERIAL NOT NULL, 
	elenco VARCHAR(40) NOT NULL, 
	codice VARCHAR(20) NOT NULL, 
	descrizione VARCHAR(200) NOT NULL, 
	percentuale INTEGER, 
	scissione_pagamenti BOOLEAN NOT NULL, 
	natura VARCHAR(10) NOT NULL, 
	regole_json TEXT DEFAULT '{}' NOT NULL, 
	ordine INTEGER NOT NULL, 
	attivo BOOLEAN NOT NULL, 
	versione INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	modificato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	modificato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_elenchi_valori PRIMARY KEY (id), 
	CONSTRAINT uq_elenchi_valori_elenco UNIQUE (elenco, descrizione)
)

;
CREATE INDEX ix_elenchi_valori_elenco ON elenchi_valori (elenco);

CREATE TABLE origini (
	id SERIAL NOT NULL, 
	sistema VARCHAR(30) NOT NULL, 
	tabella VARCHAR(60) NOT NULL, 
	id_origine VARCHAR(60) NOT NULL, 
	entita VARCHAR(30) NOT NULL, 
	entita_id INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	nota VARCHAR(300) NOT NULL, 
	eliminato_il TIMESTAMP WITHOUT TIME ZONE, 
	CONSTRAINT pk_origini PRIMARY KEY (id), 
	CONSTRAINT uq_origini_sistema_tabella_id UNIQUE (sistema, tabella, id_origine)
)

;
CREATE INDEX ix_origini_entita ON origini (entita);
CREATE INDEX ix_origini_entita_id ON origini (entita_id);

CREATE TABLE permessi (
	codice VARCHAR(60) NOT NULL, 
	area VARCHAR(40) NOT NULL, 
	descrizione VARCHAR(200) NOT NULL, 
	ordine INTEGER NOT NULL, 
	disponibile BOOLEAN NOT NULL, 
	CONSTRAINT pk_permessi PRIMARY KEY (codice)
)

;

CREATE TABLE ruoli (
	id SERIAL NOT NULL, 
	codice VARCHAR(40) NOT NULL, 
	nome VARCHAR(80) NOT NULL, 
	descrizione TEXT NOT NULL, 
	attivo BOOLEAN NOT NULL, 
	di_sistema BOOLEAN NOT NULL, 
	attivita VARCHAR(20) DEFAULT '' NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	versione INTEGER NOT NULL, 
	CONSTRAINT pk_ruoli PRIMARY KEY (id), 
	CONSTRAINT uq_ruoli_codice UNIQUE (codice), 
	CONSTRAINT uq_ruoli_nome UNIQUE (nome)
)

;

CREATE TABLE societa (
	id SERIAL NOT NULL, 
	codice VARCHAR(12) NOT NULL, 
	dati TEXT NOT NULL, 
	versione INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	modificato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	modificato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_societa PRIMARY KEY (id), 
	CONSTRAINT uq_societa_codice UNIQUE (codice)
)

;

CREATE TABLE strumenti_misura (
	id SERIAL NOT NULL, 
	attivita VARCHAR(4) NOT NULL, 
	denominazione VARCHAR(200) NOT NULL, 
	costruttore VARCHAR(120) NOT NULL, 
	modello VARCHAR(120) NOT NULL, 
	matricola VARCHAR(120) NOT NULL, 
	campo_misura VARCHAR(200) NOT NULL, 
	ente_taratura VARCHAR(200) NOT NULL, 
	certificato VARCHAR(120) NOT NULL, 
	data_taratura DATE, 
	scadenza_taratura DATE, 
	attivo BOOLEAN NOT NULL, 
	note TEXT NOT NULL, 
	versione INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	modificato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	modificato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_strumenti_misura PRIMARY KEY (id), 
	CONSTRAINT ck_strumenti_misura_attivita CHECK (attivita IN ('DM','IEC'))
)

;
CREATE INDEX ix_strumenti_misura_attivita ON strumenti_misura (attivita);
CREATE INDEX ix_strumenti_misura_scadenza_taratura ON strumenti_misura (scadenza_taratura);

CREATE TABLE tariffe_voci (
	id SERIAL NOT NULL, 
	codice VARCHAR(30) NOT NULL, 
	nome VARCHAR(150) NOT NULL, 
	tipologie VARCHAR(100) NOT NULL, 
	criterio VARCHAR(20) NOT NULL, 
	grandezza VARCHAR(30) NOT NULL, 
	automatica BOOLEAN NOT NULL, 
	attiva BOOLEAN NOT NULL, 
	ordine INTEGER NOT NULL, 
	note TEXT NOT NULL, 
	versione INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	modificato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	modificato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_tariffe_voci PRIMARY KEY (id), 
	CONSTRAINT ck_tariffe_voci_criterio CHECK (criterio IN ('scaglioni', 'unitario', 'fisso')), 
	CONSTRAINT uq_tariffe_voci_codice UNIQUE (codice)
)

;

CREATE TABLE cls_tipi_attrezzature (
	id SERIAL NOT NULL, 
	gruppo VARCHAR(8) NOT NULL, 
	codice VARCHAR(20) NOT NULL, 
	descrizione TEXT NOT NULL, 
	famiglia_gvr_id INTEGER, 
	tipo_ver_gvr_1 VARCHAR(20), 
	tipo_ver_gvr_2 VARCHAR(20), 
	tipo_ver_gvr_3 VARCHAR(20), 
	origine_json TEXT NOT NULL, 
	CONSTRAINT pk_cls_tipi_attrezzature PRIMARY KEY (id), 
	CONSTRAINT fk_cls_tipi_attrezzature_famiglia_gvr_id_cls_tipi_attre_0702 FOREIGN KEY(famiglia_gvr_id) REFERENCES cls_tipi_attrezzature_gvr (id) ON DELETE RESTRICT
)

;

CREATE TABLE ruoli_permessi (
	ruolo_id INTEGER NOT NULL, 
	permesso_codice VARCHAR(60) NOT NULL, 
	CONSTRAINT pk_ruoli_permessi PRIMARY KEY (ruolo_id, permesso_codice), 
	CONSTRAINT fk_ruoli_permessi_ruolo_id_ruoli FOREIGN KEY(ruolo_id) REFERENCES ruoli (id) ON DELETE CASCADE, 
	CONSTRAINT fk_ruoli_permessi_permesso_codice_permessi FOREIGN KEY(permesso_codice) REFERENCES permessi (codice) ON DELETE CASCADE
)

;

CREATE TABLE tariffe_versioni (
	id SERIAL NOT NULL, 
	voce_id INTEGER NOT NULL, 
	valida_dal DATE NOT NULL, 
	prezzo BIGINT, 
	minimo BIGINT, 
	note TEXT NOT NULL, 
	creata_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creata_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_tariffe_versioni PRIMARY KEY (id), 
	CONSTRAINT uq_tariffe_versioni_voce_id UNIQUE (voce_id, valida_dal), 
	CONSTRAINT fk_tariffe_versioni_voce_id_tariffe_voci FOREIGN KEY(voce_id) REFERENCES tariffe_voci (id) ON DELETE CASCADE
)

;
CREATE INDEX ix_tariffe_versioni_voce_id ON tariffe_versioni (voce_id);

CREATE TABLE utenti (
	id SERIAL NOT NULL, 
	username VARCHAR(60) NOT NULL, 
	nome VARCHAR(120) NOT NULL, 
	email VARCHAR(200) NOT NULL, 
	ruolo_id INTEGER NOT NULL, 
	attivo BOOLEAN NOT NULL, 
	password_hash VARCHAR(300) NOT NULL, 
	cambio_password_richiesto BOOLEAN NOT NULL, 
	testo VARCHAR(10) DEFAULT 'normale' NOT NULL, 
	tentativi_falliti INTEGER NOT NULL, 
	bloccato_fino TIMESTAMP WITHOUT TIME ZONE, 
	ultimo_accesso TIMESTAMP WITHOUT TIME ZONE, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	versione INTEGER NOT NULL, 
	dati_tecnici_json TEXT DEFAULT '{}' NOT NULL, 
	CONSTRAINT pk_utenti PRIMARY KEY (id), 
	CONSTRAINT uq_utenti_username UNIQUE (username), 
	CONSTRAINT fk_utenti_ruolo_id_ruoli FOREIGN KEY(ruolo_id) REFERENCES ruoli (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_utenti_ruolo_id ON utenti (ruolo_id);

CREATE TABLE cls_tipi_attr_id_specifiche (
	id SERIAL NOT NULL, 
	gruppo VARCHAR(8) NOT NULL, 
	tipo_attr_id INTEGER, 
	famiglia_gvr_id INTEGER, 
	id_spec_id INTEGER NOT NULL, 
	origine_json TEXT NOT NULL, 
	CONSTRAINT pk_cls_tipi_attr_id_specifiche PRIMARY KEY (id), 
	CONSTRAINT fk_cls_tipi_attr_id_specifiche_tipo_attr_id_cls_tipi_at_be4d FOREIGN KEY(tipo_attr_id) REFERENCES cls_tipi_attrezzature (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_cls_tipi_attr_id_specifiche_famiglia_gvr_id_cls_tipi_9e6c FOREIGN KEY(famiglia_gvr_id) REFERENCES cls_tipi_attrezzature_gvr (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_cls_tipi_attr_id_specifiche_id_spec_id_cls_id_specifiche FOREIGN KEY(id_spec_id) REFERENCES cls_id_specifiche (id) ON DELETE RESTRICT
)

;

CREATE TABLE commerciali (
	id SERIAL NOT NULL, 
	nome VARCHAR(120) NOT NULL, 
	email VARCHAR(200) NOT NULL, 
	telefono VARCHAR(60) NOT NULL, 
	utente_id INTEGER, 
	attivo BOOLEAN NOT NULL, 
	note TEXT NOT NULL, 
	ambito_dpr BOOLEAN DEFAULT '0' NOT NULL, 
	ambito_dm BOOLEAN DEFAULT '0' NOT NULL, 
	ambito_iec BOOLEAN DEFAULT '0' NOT NULL, 
	versione INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	modificato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	modificato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_commerciali PRIMARY KEY (id), 
	CONSTRAINT uq_commerciali_nome UNIQUE (nome), 
	CONSTRAINT fk_commerciali_utente_id_utenti FOREIGN KEY(utente_id) REFERENCES utenti (id) ON DELETE SET NULL
)

;

CREATE TABLE configurazioni_griglie (
	id SERIAL NOT NULL, 
	utente_id INTEGER NOT NULL, 
	griglia VARCHAR(60) NOT NULL, 
	nome VARCHAR(80) NOT NULL, 
	dati TEXT NOT NULL, 
	predefinita BOOLEAN NOT NULL, 
	aggiornata_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	CONSTRAINT pk_configurazioni_griglie PRIMARY KEY (id), 
	CONSTRAINT uq_configurazioni_griglie_nome UNIQUE (utente_id, griglia, nome), 
	CONSTRAINT fk_configurazioni_griglie_utente_id_utenti FOREIGN KEY(utente_id) REFERENCES utenti (id) ON DELETE CASCADE
)

;
CREATE INDEX ix_configurazioni_griglie_utente_id ON configurazioni_griglie (utente_id);

CREATE TABLE documenti (
	id SERIAL NOT NULL, 
	impronta VARCHAR(64) NOT NULL, 
	nome_originale VARCHAR(255) NOT NULL, 
	tipo_mime VARCHAR(120) NOT NULL, 
	dimensione INTEGER NOT NULL, 
	descrizione TEXT NOT NULL, 
	caricato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	caricato_da INTEGER, 
	CONSTRAINT pk_documenti PRIMARY KEY (id), 
	CONSTRAINT uq_documenti_impronta UNIQUE (impronta), 
	CONSTRAINT fk_documenti_caricato_da_utenti FOREIGN KEY(caricato_da) REFERENCES utenti (id) ON DELETE RESTRICT
)

;

CREATE TABLE impostazioni (
	chiave VARCHAR(80) NOT NULL, 
	valore TEXT NOT NULL, 
	aggiornata_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	aggiornata_da INTEGER, 
	CONSTRAINT pk_impostazioni PRIMARY KEY (chiave), 
	CONSTRAINT fk_impostazioni_aggiornata_da_utenti FOREIGN KEY(aggiornata_da) REFERENCES utenti (id) ON DELETE RESTRICT
)

;

CREATE TABLE registro_operazioni (
	id SERIAL NOT NULL, 
	quando TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	utente_id INTEGER, 
	utente_nome VARCHAR(120) NOT NULL, 
	azione VARCHAR(60) NOT NULL, 
	oggetto_tipo VARCHAR(40) NOT NULL, 
	oggetto_id VARCHAR(60) NOT NULL, 
	descrizione TEXT NOT NULL, 
	dettagli TEXT NOT NULL, 
	impronta_precedente VARCHAR(64) NOT NULL, 
	impronta VARCHAR(64) NOT NULL, 
	CONSTRAINT pk_registro_operazioni PRIMARY KEY (id), 
	CONSTRAINT fk_registro_operazioni_utente_id_utenti FOREIGN KEY(utente_id) REFERENCES utenti (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_registro_operazioni_azione ON registro_operazioni (azione);
CREATE INDEX ix_registro_operazioni_oggetto ON registro_operazioni (oggetto_tipo, oggetto_id);
CREATE INDEX ix_registro_operazioni_quando ON registro_operazioni (quando);
CREATE INDEX ix_registro_operazioni_utente_id ON registro_operazioni (utente_id);

CREATE TABLE sessioni (
	impronta VARCHAR(64) NOT NULL, 
	utente_id INTEGER NOT NULL, 
	csrf VARCHAR(64) NOT NULL, 
	creata_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	ultima_attivita TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	scade_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	indirizzo_ip VARCHAR(60) NOT NULL, 
	CONSTRAINT pk_sessioni PRIMARY KEY (impronta), 
	CONSTRAINT fk_sessioni_utente_id_utenti FOREIGN KEY(utente_id) REFERENCES utenti (id) ON DELETE CASCADE
)

;
CREATE INDEX ix_sessioni_utente_id ON sessioni (utente_id);

CREATE TABLE tariffe_scaglioni (
	id SERIAL NOT NULL, 
	versione_id INTEGER NOT NULL, 
	ordine INTEGER NOT NULL, 
	fino_a FLOAT, 
	importo BIGINT NOT NULL, 
	etichetta VARCHAR(200) DEFAULT '' NOT NULL, 
	CONSTRAINT pk_tariffe_scaglioni PRIMARY KEY (id), 
	CONSTRAINT fk_tariffe_scaglioni_versione_id_tariffe_versioni FOREIGN KEY(versione_id) REFERENCES tariffe_versioni (id) ON DELETE CASCADE
)

;
CREATE INDEX ix_tariffe_scaglioni_versione_id ON tariffe_scaglioni (versione_id);

CREATE TABLE utenti_ruoli (
	utente_id INTEGER NOT NULL, 
	ruolo_id INTEGER NOT NULL, 
	CONSTRAINT pk_utenti_ruoli PRIMARY KEY (utente_id, ruolo_id), 
	CONSTRAINT fk_utenti_ruoli_utente_id_utenti FOREIGN KEY(utente_id) REFERENCES utenti (id) ON DELETE CASCADE, 
	CONSTRAINT fk_utenti_ruoli_ruolo_id_ruoli FOREIGN KEY(ruolo_id) REFERENCES ruoli (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_utenti_ruoli_ruolo_id ON utenti_ruoli (ruolo_id);

CREATE TABLE clienti (
	id SERIAL NOT NULL, 
	ragione_sociale VARCHAR(250) NOT NULL, 
	tipo VARCHAR(20) NOT NULL, 
	nazione VARCHAR(2) NOT NULL, 
	partita_iva VARCHAR(20) NOT NULL, 
	codice_fiscale VARCHAR(20) NOT NULL, 
	email_verbali VARCHAR(500) NOT NULL, 
	email_fatture VARCHAR(500) NOT NULL, 
	pec VARCHAR(200) NOT NULL, 
	codice_sdi VARCHAR(7) NOT NULL, 
	riferimento_amministrazione VARCHAR(20) NOT NULL, 
	commerciale_id INTEGER, 
	referente_nome VARCHAR(120) NOT NULL, 
	referente_email VARCHAR(200) NOT NULL, 
	referente_telefono VARCHAR(60) NOT NULL, 
	banca VARCHAR(120) NOT NULL, 
	iban VARCHAR(34) NOT NULL, 
	dichiarazione_intento BOOLEAN NOT NULL, 
	dichiarazione_numero VARCHAR(60) NOT NULL, 
	dichiarazione_data DATE, 
	ritenuta_percentuale INTEGER, 
	sconto_dm INTEGER DEFAULT '0' NOT NULL, 
	modalita_pagamento_id INTEGER, 
	aliquota_iva_id INTEGER, 
	termine_esecuzione VARCHAR(300) DEFAULT '' NOT NULL, 
	sconti_ammessi BOOLEAN NOT NULL, 
	sconti_motivo VARCHAR(300) NOT NULL, 
	attivo BOOLEAN NOT NULL, 
	note TEXT NOT NULL, 
	avvisi TEXT NOT NULL, 
	codice_esterno VARCHAR(40) NOT NULL, 
	ambito_dpr BOOLEAN DEFAULT '0' NOT NULL, 
	ambito_dm BOOLEAN DEFAULT '0' NOT NULL, 
	ambito_iec BOOLEAN DEFAULT '0' NOT NULL, 
	indirizzo VARCHAR(200) NOT NULL, 
	comune_istat VARCHAR(6), 
	comune VARCHAR(100) NOT NULL, 
	cap VARCHAR(10) NOT NULL, 
	provincia VARCHAR(2) NOT NULL, 
	regione VARCHAR(60) NOT NULL, 
	versione INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	modificato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	modificato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_clienti PRIMARY KEY (id), 
	CONSTRAINT ck_clienti_tipo CHECK (tipo IN ('privato', 'pa', 'condominio', 'persona_fisica')), 
	CONSTRAINT fk_clienti_commerciale_id_commerciali FOREIGN KEY(commerciale_id) REFERENCES commerciali (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_clienti_modalita_pagamento_id_elenchi_valori FOREIGN KEY(modalita_pagamento_id) REFERENCES elenchi_valori (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_clienti_aliquota_iva_id_elenchi_valori FOREIGN KEY(aliquota_iva_id) REFERENCES elenchi_valori (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_clienti_comune_istat_comuni FOREIGN KEY(comune_istat) REFERENCES comuni (codice_istat) ON DELETE SET NULL
)

;
CREATE INDEX ix_clienti_ambito_dm ON clienti (ambito_dm);
CREATE INDEX ix_clienti_ambito_dpr ON clienti (ambito_dpr);
CREATE INDEX ix_clienti_ambito_iec ON clienti (ambito_iec);
CREATE INDEX ix_clienti_codice_fiscale ON clienti (codice_fiscale);
CREATE INDEX ix_clienti_commerciale_id ON clienti (commerciale_id);
CREATE INDEX ix_clienti_partita_iva ON clienti (partita_iva);
CREATE INDEX ix_clienti_ragione_sociale ON clienti (ragione_sociale);

CREATE TABLE dm_esportazioni_inail (
	id SERIAL NOT NULL, 
	documento_id INTEGER NOT NULL, 
	manifest_json TEXT NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_dm_esportazioni_inail PRIMARY KEY (id), 
	CONSTRAINT fk_dm_esportazioni_inail_documento_id_documenti FOREIGN KEY(documento_id) REFERENCES documenti (id) ON DELETE RESTRICT
)

;

CREATE TABLE dm_tariffe (
	id SERIAL NOT NULL, 
	gruppo VARCHAR(8) NOT NULL, 
	id_spec_id INTEGER, 
	compatibilita_id INTEGER, 
	tipo VARCHAR(2) NOT NULL, 
	importo BIGINT NOT NULL, 
	origine_json TEXT NOT NULL, 
	CONSTRAINT pk_dm_tariffe PRIMARY KEY (id), 
	CONSTRAINT ck_dm_tariffe_gruppo CHECK (gruppo IN ('GVR','SCSP')), 
	CONSTRAINT ck_dm_tariffe_importo CHECK (importo > 0), 
	CONSTRAINT ck_dm_tariffe_chiave CHECK ((gruppo='GVR' AND id_spec_id IS NOT NULL AND compatibilita_id IS NULL) OR (gruppo='SCSP' AND compatibilita_id IS NOT NULL AND id_spec_id IS NULL)), 
	CONSTRAINT fk_dm_tariffe_id_spec_id_cls_id_specifiche FOREIGN KEY(id_spec_id) REFERENCES cls_id_specifiche (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_dm_tariffe_compatibilita_id_cls_tipi_attr_id_specifiche FOREIGN KEY(compatibilita_id) REFERENCES cls_tipi_attr_id_specifiche (id) ON DELETE RESTRICT
)

;

CREATE TABLE modelli_documento (
	id SERIAL NOT NULL, 
	tipo VARCHAR(30) NOT NULL, 
	codice VARCHAR(60) NOT NULL, 
	revisione VARCHAR(20) NOT NULL, 
	descrizione TEXT NOT NULL, 
	documento_id INTEGER NOT NULL, 
	in_uso BOOLEAN NOT NULL, 
	caricato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	caricato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_modelli_documento PRIMARY KEY (id), 
	CONSTRAINT fk_modelli_documento_documento_id_documenti FOREIGN KEY(documento_id) REFERENCES documenti (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_modelli_documento_tipo ON modelli_documento (tipo);

CREATE TABLE clienti_doppioni_esclusi (
	id SERIAL NOT NULL, 
	cliente_a_id INTEGER NOT NULL, 
	cliente_b_id INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_clienti_doppioni_esclusi PRIMARY KEY (id), 
	CONSTRAINT uq_clienti_doppioni_esclusi UNIQUE (cliente_a_id, cliente_b_id), 
	CONSTRAINT fk_clienti_doppioni_esclusi_cliente_a_id_clienti FOREIGN KEY(cliente_a_id) REFERENCES clienti (id) ON DELETE CASCADE, 
	CONSTRAINT fk_clienti_doppioni_esclusi_cliente_b_id_clienti FOREIGN KEY(cliente_b_id) REFERENCES clienti (id) ON DELETE CASCADE
)

;
CREATE INDEX ix_clienti_doppioni_esclusi_cliente_a_id ON clienti_doppioni_esclusi (cliente_a_id);
CREATE INDEX ix_clienti_doppioni_esclusi_cliente_b_id ON clienti_doppioni_esclusi (cliente_b_id);

CREATE TABLE fatture (
	id SERIAL NOT NULL, 
	societa_id INTEGER NOT NULL, 
	ambito VARCHAR(12) NOT NULL, 
	tipo VARCHAR(4) NOT NULL, 
	anno INTEGER NOT NULL, 
	numero INTEGER, 
	codice VARCHAR(40) NOT NULL, 
	stato VARCHAR(24) NOT NULL, 
	data DATE NOT NULL, 
	cliente_id INTEGER NOT NULL, 
	originale_id INTEGER, 
	opzioni TEXT NOT NULL, 
	fotografia TEXT NOT NULL, 
	imponibile BIGINT NOT NULL, 
	iva BIGINT NOT NULL, 
	totale BIGINT NOT NULL, 
	dovuto BIGINT NOT NULL, 
	revisione_xml INTEGER NOT NULL, 
	versione INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	modificato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	modificato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_fatture PRIMARY KEY (id), 
	CONSTRAINT uq_fatture_societa_id UNIQUE (societa_id, ambito, tipo, anno, numero), 
	CONSTRAINT ck_fatture_stato CHECK (stato IN ('bozza','emessa','scartata','consegnata','mancata_consegna','accettata_pa','rifiutata_pa')), 
	CONSTRAINT fk_fatture_societa_id_societa FOREIGN KEY(societa_id) REFERENCES societa (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_fatture_cliente_id_clienti FOREIGN KEY(cliente_id) REFERENCES clienti (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_fatture_originale_id_fatture FOREIGN KEY(originale_id) REFERENCES fatture (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_fatture_ambito ON fatture (ambito);
CREATE INDEX ix_fatture_cliente_id ON fatture (cliente_id);
CREATE INDEX ix_fatture_stato ON fatture (stato);

CREATE TABLE incassi (
	id SERIAL NOT NULL, 
	societa_id INTEGER NOT NULL, 
	cliente_id INTEGER NOT NULL, 
	data DATE NOT NULL, 
	importo BIGINT NOT NULL, 
	causale VARCHAR(500) NOT NULL, 
	metodo VARCHAR(60) NOT NULL, 
	stornato BOOLEAN NOT NULL, 
	motivo_storno VARCHAR(500) NOT NULL, 
	versione INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	modificato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	modificato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_incassi PRIMARY KEY (id), 
	CONSTRAINT ck_incassi_importo CHECK (importo > 0), 
	CONSTRAINT fk_incassi_societa_id_societa FOREIGN KEY(societa_id) REFERENCES societa (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_incassi_cliente_id_clienti FOREIGN KEY(cliente_id) REFERENCES clienti (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_incassi_cliente_id ON incassi (cliente_id);
CREATE INDEX ix_incassi_societa_id ON incassi (societa_id);

CREATE TABLE sedi (
	id SERIAL NOT NULL, 
	cliente_id INTEGER NOT NULL, 
	denominazione VARCHAR(300) NOT NULL, 
	referente_nome VARCHAR(120) NOT NULL, 
	referente_email VARCHAR(200) NOT NULL, 
	referente_telefono VARCHAR(60) NOT NULL, 
	email_verbali VARCHAR(500) NOT NULL, 
	email_verbali_cc VARCHAR(500) NOT NULL, 
	note_accesso TEXT NOT NULL, 
	attiva BOOLEAN NOT NULL, 
	note TEXT NOT NULL, 
	avvisi TEXT NOT NULL, 
	codice_esterno VARCHAR(40) NOT NULL, 
	ambito_dpr BOOLEAN DEFAULT '0' NOT NULL, 
	ambito_dm BOOLEAN DEFAULT '0' NOT NULL, 
	ambito_iec BOOLEAN DEFAULT '0' NOT NULL, 
	indirizzo VARCHAR(200) NOT NULL, 
	comune_istat VARCHAR(6), 
	comune VARCHAR(100) NOT NULL, 
	cap VARCHAR(10) NOT NULL, 
	provincia VARCHAR(2) NOT NULL, 
	regione VARCHAR(60) NOT NULL, 
	versione INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	modificato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	modificato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_sedi PRIMARY KEY (id), 
	CONSTRAINT fk_sedi_cliente_id_clienti FOREIGN KEY(cliente_id) REFERENCES clienti (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_sedi_comune_istat_comuni FOREIGN KEY(comune_istat) REFERENCES comuni (codice_istat) ON DELETE SET NULL
)

;
CREATE INDEX ix_sedi_ambito_dm ON sedi (ambito_dm);
CREATE INDEX ix_sedi_ambito_dpr ON sedi (ambito_dpr);
CREATE INDEX ix_sedi_ambito_iec ON sedi (ambito_iec);
CREATE INDEX ix_sedi_cliente_id ON sedi (cliente_id);
CREATE INDEX ix_sedi_denominazione ON sedi (denominazione);

CREATE TABLE asset (
	id SERIAL NOT NULL, 
	gruppo VARCHAR(8) NOT NULL, 
	classe_identita VARCHAR(20) NOT NULL, 
	sede_id INTEGER NOT NULL, 
	denominazione VARCHAR(300) NOT NULL, 
	matr_informale VARCHAR(100), 
	anno_matricola VARCHAR(4) NOT NULL, 
	cod_att_matricola VARCHAR(10) NOT NULL, 
	num_matricola VARCHAR(30) NOT NULL, 
	prov_immatr VARCHAR(2) NOT NULL, 
	num_fabbrica VARCHAR(100) NOT NULL, 
	costruttore VARCHAR(250) NOT NULL, 
	modello VARCHAR(150) NOT NULL, 
	anno_costruzione INTEGER, 
	tipo_attr_id INTEGER, 
	tipo_attr_gvr_id INTEGER, 
	id_spec_id INTEGER, 
	soggetto_messa_servizio BOOLEAN, 
	dismesso BOOLEAN NOT NULL, 
	note TEXT NOT NULL, 
	attributi_json TEXT NOT NULL, 
	versione INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	modificato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	modificato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_asset PRIMARY KEY (id), 
	CONSTRAINT ck_asset_gruppo CHECK (gruppo IN ('DPR','SC','SP','GVR','PSV')), 
	CONSTRAINT ck_asset_classe_identita CHECK (classe_identita IN ('dpr','attrezzatura','accessorio')), 
	CONSTRAINT uq_asset_matricola_sede UNIQUE (sede_id, classe_identita, matr_informale), 
	CONSTRAINT fk_asset_sede_id_sedi FOREIGN KEY(sede_id) REFERENCES sedi (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_asset_tipo_attr_id_cls_tipi_attrezzature FOREIGN KEY(tipo_attr_id) REFERENCES cls_tipi_attrezzature (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_asset_tipo_attr_gvr_id_cls_tipi_attrezzature_gvr FOREIGN KEY(tipo_attr_gvr_id) REFERENCES cls_tipi_attrezzature_gvr (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_asset_id_spec_id_cls_id_specifiche FOREIGN KEY(id_spec_id) REFERENCES cls_id_specifiche (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_asset_dismesso ON asset (dismesso);
CREATE INDEX ix_asset_gruppo ON asset (gruppo);
CREATE INDEX ix_asset_sede_id ON asset (sede_id);

CREATE TABLE fatture_documenti (
	id SERIAL NOT NULL, 
	fattura_id INTEGER NOT NULL, 
	documento_id INTEGER NOT NULL, 
	revisione INTEGER NOT NULL, 
	revisione_xml INTEGER NOT NULL, 
	fotografia_sha256 VARCHAR(64) NOT NULL, 
	nome_file VARCHAR(255) NOT NULL, 
	origine VARCHAR(30) NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_fatture_documenti PRIMARY KEY (id), 
	CONSTRAINT uq_fatture_documenti_fattura_id UNIQUE (fattura_id, revisione), 
	CONSTRAINT fk_fatture_documenti_fattura_id_fatture FOREIGN KEY(fattura_id) REFERENCES fatture (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_fatture_documenti_documento_id_documenti FOREIGN KEY(documento_id) REFERENCES documenti (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_fatture_documenti_fattura_id ON fatture_documenti (fattura_id);

CREATE TABLE fatture_esportazioni (
	id SERIAL NOT NULL, 
	fattura_id INTEGER NOT NULL, 
	revisione INTEGER NOT NULL, 
	nome_file VARCHAR(60) DEFAULT '' NOT NULL, 
	xml TEXT NOT NULL, 
	sha256 VARCHAR(64) NOT NULL, 
	fotografia TEXT NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_fatture_esportazioni PRIMARY KEY (id), 
	CONSTRAINT uq_fatture_esportazioni_fattura_id UNIQUE (fattura_id, revisione), 
	CONSTRAINT fk_fatture_esportazioni_fattura_id_fatture FOREIGN KEY(fattura_id) REFERENCES fatture (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_fatture_esportazioni_fattura_id ON fatture_esportazioni (fattura_id);
CREATE INDEX ix_fatture_esportazioni_nome_file ON fatture_esportazioni (nome_file);

CREATE TABLE fatture_scadenze (
	id SERIAL NOT NULL, 
	fattura_id INTEGER NOT NULL, 
	data DATE NOT NULL, 
	importo BIGINT NOT NULL, 
	modalita VARCHAR(4) NOT NULL, 
	CONSTRAINT pk_fatture_scadenze PRIMARY KEY (id), 
	CONSTRAINT ck_fatture_scadenze_importo CHECK (importo > 0), 
	CONSTRAINT fk_fatture_scadenze_fattura_id_fatture FOREIGN KEY(fattura_id) REFERENCES fatture (id) ON DELETE CASCADE
)

;
CREATE INDEX ix_fatture_scadenze_fattura_id ON fatture_scadenze (fattura_id);

CREATE TABLE incassi_allocazioni (
	id SERIAL NOT NULL, 
	incasso_id INTEGER NOT NULL, 
	fattura_id INTEGER NOT NULL, 
	importo BIGINT NOT NULL, 
	CONSTRAINT pk_incassi_allocazioni PRIMARY KEY (id), 
	CONSTRAINT uq_incassi_allocazioni_incasso_id UNIQUE (incasso_id, fattura_id), 
	CONSTRAINT ck_incassi_allocazioni_importo CHECK (importo > 0), 
	CONSTRAINT fk_incassi_allocazioni_incasso_id_incassi FOREIGN KEY(incasso_id) REFERENCES incassi (id) ON DELETE CASCADE, 
	CONSTRAINT fk_incassi_allocazioni_fattura_id_fatture FOREIGN KEY(fattura_id) REFERENCES fatture (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_incassi_allocazioni_fattura_id ON incassi_allocazioni (fattura_id);
CREATE INDEX ix_incassi_allocazioni_incasso_id ON incassi_allocazioni (incasso_id);

CREATE TABLE preventivi (
	id SERIAL NOT NULL, 
	ambito VARCHAR(8) DEFAULT 'DPR' NOT NULL, 
	serie VARCHAR(40) NOT NULL, 
	sede_id INTEGER, 
	anno INTEGER NOT NULL, 
	numero INTEGER NOT NULL, 
	revisione INTEGER NOT NULL, 
	codice VARCHAR(30) NOT NULL, 
	data DATE NOT NULL, 
	documento_fotografia TEXT DEFAULT '{}' NOT NULL, 
	cliente_fotografia TEXT DEFAULT '{}' NOT NULL, 
	cliente_id INTEGER NOT NULL, 
	commerciale_id INTEGER, 
	modalita_pagamento VARCHAR(200) NOT NULL, 
	termine_esecuzione VARCHAR(300) NOT NULL, 
	stato VARCHAR(30) NOT NULL, 
	inviato_il TIMESTAMP WITHOUT TIME ZONE, 
	evidenza_accettazione TEXT DEFAULT '' NOT NULL, 
	rif_ordine VARCHAR(120) NOT NULL, 
	documenti_collegati TEXT DEFAULT '[]' NOT NULL, 
	data_ordine DATE, 
	motivo_annullamento VARCHAR(500) NOT NULL, 
	revisione_di_id INTEGER, 
	note TEXT NOT NULL, 
	lic_gest BOOLEAN DEFAULT '0' NOT NULL, 
	prezzo_licenza BIGINT DEFAULT '0' NOT NULL, 
	totale_standard BIGINT NOT NULL, 
	totale BIGINT NOT NULL, 
	versione INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	modificato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	modificato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_preventivi PRIMARY KEY (id), 
	CONSTRAINT uq_preventivi_serie_numero UNIQUE (ambito, serie, numero, revisione), 
	CONSTRAINT ck_preventivi_ambito CHECK (ambito IN ('DPR','DM')), 
	CONSTRAINT ck_preventivi_stato CHECK (stato IN ('creato', 'inviato', 'accettato_parzialmente', 'accettato_totalmente', 'rifiutato', 'annullato', 'sostituito')), 
	CONSTRAINT fk_preventivi_sede_id_sedi FOREIGN KEY(sede_id) REFERENCES sedi (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_preventivi_cliente_id_clienti FOREIGN KEY(cliente_id) REFERENCES clienti (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_preventivi_commerciale_id_commerciali FOREIGN KEY(commerciale_id) REFERENCES commerciali (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_preventivi_revisione_di_id_preventivi FOREIGN KEY(revisione_di_id) REFERENCES preventivi (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_preventivi_ambito ON preventivi (ambito);
CREATE INDEX ix_preventivi_anno ON preventivi (anno);
CREATE INDEX ix_preventivi_cliente_id ON preventivi (cliente_id);
CREATE INDEX ix_preventivi_codice ON preventivi (codice);
CREATE INDEX ix_preventivi_stato ON preventivi (stato);

CREATE TABLE sedi_doppioni_esclusi (
	id SERIAL NOT NULL, 
	sede_a_id INTEGER NOT NULL, 
	sede_b_id INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_sedi_doppioni_esclusi PRIMARY KEY (id), 
	CONSTRAINT uq_sedi_doppioni_esclusi UNIQUE (sede_a_id, sede_b_id), 
	CONSTRAINT fk_sedi_doppioni_esclusi_sede_a_id_sedi FOREIGN KEY(sede_a_id) REFERENCES sedi (id) ON DELETE CASCADE, 
	CONSTRAINT fk_sedi_doppioni_esclusi_sede_b_id_sedi FOREIGN KEY(sede_b_id) REFERENCES sedi (id) ON DELETE CASCADE
)

;
CREATE INDEX ix_sedi_doppioni_esclusi_sede_a_id ON sedi_doppioni_esclusi (sede_a_id);
CREATE INDEX ix_sedi_doppioni_esclusi_sede_b_id ON sedi_doppioni_esclusi (sede_b_id);

CREATE TABLE asset_camere_gvr (
	id SERIAL NOT NULL, 
	asset_id INTEGER NOT NULL, 
	identificazione VARCHAR(150) NOT NULL, 
	num_fabbrica VARCHAR(100) NOT NULL, 
	chiave VARCHAR(260) NOT NULL, 
	unita VARCHAR(2) NOT NULL, 
	valore_decimi INTEGER NOT NULL, 
	attributi_json TEXT NOT NULL, 
	versione INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	modificato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	modificato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_asset_camere_gvr PRIMARY KEY (id), 
	CONSTRAINT uq_asset_camere_gvr_asset_id UNIQUE (asset_id, chiave), 
	CONSTRAINT ck_asset_camere_gvr_unita CHECK (unita IN ('L','DN')), 
	CONSTRAINT ck_asset_camere_gvr_valore_non_negativo CHECK (valore_decimi >= 0), 
	CONSTRAINT fk_asset_camere_gvr_asset_id_asset FOREIGN KEY(asset_id) REFERENCES asset (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_asset_camere_gvr_asset_id ON asset_camere_gvr (asset_id);

CREATE TABLE asset_origini (
	id SERIAL NOT NULL, 
	asset_id INTEGER NOT NULL, 
	sistema VARCHAR(40) NOT NULL, 
	tabella VARCHAR(80) NOT NULL, 
	id_origine VARCHAR(80) NOT NULL, 
	dati_origine_json TEXT NOT NULL, 
	CONSTRAINT pk_asset_origini PRIMARY KEY (id), 
	CONSTRAINT uq_asset_origini_sistema UNIQUE (sistema, tabella, id_origine), 
	CONSTRAINT fk_asset_origini_asset_id_asset FOREIGN KEY(asset_id) REFERENCES asset (id) ON DELETE CASCADE
)

;
CREATE INDEX ix_asset_origini_asset_id ON asset_origini (asset_id);

CREATE TABLE asset_relazioni (
	id SERIAL NOT NULL, 
	asset_id INTEGER NOT NULL, 
	accessorio_id INTEGER NOT NULL, 
	versione INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	modificato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	modificato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_asset_relazioni PRIMARY KEY (id), 
	CONSTRAINT uq_asset_relazioni_asset_id UNIQUE (asset_id, accessorio_id), 
	CONSTRAINT ck_asset_relazioni_beni_diversi CHECK (asset_id <> accessorio_id), 
	CONSTRAINT fk_asset_relazioni_asset_id_asset FOREIGN KEY(asset_id) REFERENCES asset (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_asset_relazioni_accessorio_id_asset FOREIGN KEY(accessorio_id) REFERENCES asset (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_asset_relazioni_accessorio_id ON asset_relazioni (accessorio_id);
CREATE INDEX ix_asset_relazioni_asset_id ON asset_relazioni (asset_id);

CREATE TABLE fatture_esiti (
	id SERIAL NOT NULL, 
	esportazione_id INTEGER NOT NULL, 
	esito VARCHAR(24) NOT NULL, 
	messaggio TEXT NOT NULL, 
	identificativo_origine VARCHAR(120) NOT NULL, 
	registrato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	registrato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_fatture_esiti PRIMARY KEY (id), 
	CONSTRAINT uq_fatture_esiti_identificativo_origine UNIQUE (identificativo_origine), 
	CONSTRAINT fk_fatture_esiti_esportazione_id_fatture_esportazioni FOREIGN KEY(esportazione_id) REFERENCES fatture_esportazioni (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_fatture_esiti_esportazione_id ON fatture_esiti (esportazione_id);

CREATE TABLE impianti (
	asset_id INTEGER NOT NULL, 
	id SERIAL NOT NULL, 
	sede_id INTEGER NOT NULL, 
	tipologia VARCHAR(20) NOT NULL, 
	denominazione VARCHAR(300) NOT NULL, 
	dismesso BOOLEAN NOT NULL, 
	matricola_anno VARCHAR(4) NOT NULL, 
	matricola_attivita VARCHAR(10) NOT NULL, 
	matricola_numero VARCHAR(20) NOT NULL, 
	matricola_provincia VARCHAR(2) NOT NULL, 
	potenza_kw FLOAT, 
	cabine_mt_bt INTEGER, 
	sottostazioni_at_mt INTEGER, 
	pod_note TEXT NOT NULL, 
	asta BOOLEAN NOT NULL, 
	numero_aste INTEGER, 
	gabbia BOOLEAN NOT NULL, 
	gabbia_fascia VARCHAR(20) NOT NULL, 
	gas BOOLEAN NOT NULL, 
	polveri BOOLEAN NOT NULL, 
	zone VARCHAR(30) NOT NULL, 
	caratteristiche TEXT DEFAULT '' NOT NULL, 
	periodicita_anni INTEGER, 
	ultima_verifica_data DATE, 
	ultima_verifica_numero VARCHAR(40) NOT NULL, 
	prossima_verifica DATE, 
	prossima_calcolata BOOLEAN NOT NULL, 
	note TEXT NOT NULL, 
	avvisi TEXT NOT NULL, 
	codice_esterno VARCHAR(40) NOT NULL, 
	versione INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	modificato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	modificato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_impianti PRIMARY KEY (id), 
	CONSTRAINT ck_impianti_tipologia CHECK (tipologia IN ('terra_bt', 'terra_at', 'scariche', 'esplosione')), 
	CONSTRAINT ck_impianti_periodicita CHECK (periodicita_anni IS NULL OR periodicita_anni IN (2, 5)), 
	CONSTRAINT ck_impianti_gabbia_fascia CHECK (gabbia_fascia = '' OR gabbia_fascia IN ('fino_100', 'da_101_a_350', 'oltre_350')), 
	CONSTRAINT ck_impianti_potenza CHECK (potenza_kw IS NULL OR potenza_kw >= 0), 
	CONSTRAINT uq_impianti_asset_id UNIQUE (asset_id), 
	CONSTRAINT fk_impianti_asset_id_asset FOREIGN KEY(asset_id) REFERENCES asset (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_impianti_sede_id_sedi FOREIGN KEY(sede_id) REFERENCES sedi (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_impianti_codice_esterno ON impianti (codice_esterno);
CREATE INDEX ix_impianti_dismesso ON impianti (dismesso);
CREATE INDEX ix_impianti_prossima_verifica ON impianti (prossima_verifica);
CREATE INDEX ix_impianti_sede_id ON impianti (sede_id);

CREATE TABLE preventivi_allegati (
	id SERIAL NOT NULL, 
	preventivo_id INTEGER NOT NULL, 
	documento_id INTEGER NOT NULL, 
	tipo VARCHAR(20) NOT NULL, 
	nome_file VARCHAR(255) NOT NULL, 
	descrizione VARCHAR(300) NOT NULL, 
	rimosso BOOLEAN DEFAULT '0' NOT NULL, 
	rimosso_il TIMESTAMP WITHOUT TIME ZONE, 
	rimosso_da VARCHAR(120) DEFAULT '' NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_preventivi_allegati PRIMARY KEY (id), 
	CONSTRAINT ck_preventivi_allegati_tipo CHECK (tipo IN ('accettazione','ordine','email','altro')), 
	CONSTRAINT fk_preventivi_allegati_preventivo_id_preventivi FOREIGN KEY(preventivo_id) REFERENCES preventivi (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_preventivi_allegati_documento_id_documenti FOREIGN KEY(documento_id) REFERENCES documenti (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_preventivi_allegati_preventivo_id ON preventivi_allegati (preventivo_id);

CREATE TABLE preventivi_documenti (
	id SERIAL NOT NULL, 
	preventivo_id INTEGER NOT NULL, 
	formato VARCHAR(10) NOT NULL, 
	documento_id INTEGER NOT NULL, 
	modello_id INTEGER, 
	nome_file VARCHAR(255) NOT NULL, 
	versione_preventivo INTEGER, 
	ritoccato BOOLEAN DEFAULT '0' NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	gruppo VARCHAR(32) DEFAULT '' NOT NULL, 
	impronta_dati VARCHAR(64) DEFAULT '' NOT NULL, 
	approvato_il TIMESTAMP WITHOUT TIME ZONE, 
	approvato_da VARCHAR(120) DEFAULT '' NOT NULL, 
	CONSTRAINT pk_preventivi_documenti PRIMARY KEY (id), 
	CONSTRAINT fk_preventivi_documenti_preventivo_id_preventivi FOREIGN KEY(preventivo_id) REFERENCES preventivi (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_preventivi_documenti_documento_id_documenti FOREIGN KEY(documento_id) REFERENCES documenti (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_preventivi_documenti_modello_id_modelli_documento FOREIGN KEY(modello_id) REFERENCES modelli_documento (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_preventivi_documenti_gruppo ON preventivi_documenti (gruppo);
CREATE INDEX ix_preventivi_documenti_preventivo_id ON preventivi_documenti (preventivo_id);

CREATE TABLE preventivi_invii (
	id SERIAL NOT NULL, 
	preventivo_id INTEGER NOT NULL, 
	destinatari VARCHAR(1000) NOT NULL, 
	copia VARCHAR(1000) NOT NULL, 
	oggetto VARCHAR(300) NOT NULL, 
	testo TEXT NOT NULL, 
	allegati TEXT NOT NULL, 
	esito VARCHAR(300) NOT NULL, 
	inviato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	inviato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_preventivi_invii PRIMARY KEY (id), 
	CONSTRAINT fk_preventivi_invii_preventivo_id_preventivi FOREIGN KEY(preventivo_id) REFERENCES preventivi (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_preventivi_invii_preventivo_id ON preventivi_invii (preventivo_id);

CREATE TABLE preventivi_riesami (
	id SERIAL NOT NULL, 
	preventivo_id INTEGER NOT NULL, 
	esito VARCHAR(20) NOT NULL, 
	requisiti_chiari BOOLEAN NOT NULL, 
	competenza_strumenti BOOLEAN NOT NULL, 
	imparzialita BOOLEAN NOT NULL, 
	tempi BOOLEAN NOT NULL, 
	note TEXT NOT NULL, 
	eseguito_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	eseguito_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_preventivi_riesami PRIMARY KEY (id), 
	CONSTRAINT fk_preventivi_riesami_preventivo_id_preventivi FOREIGN KEY(preventivo_id) REFERENCES preventivi (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_preventivi_riesami_preventivo_id ON preventivi_riesami (preventivo_id);

CREATE TABLE impianti_elementi (
	id SERIAL NOT NULL, 
	impianto_id INTEGER NOT NULL, 
	tipo VARCHAR(20) NOT NULL, 
	quadro VARCHAR(200) NOT NULL, 
	nome VARCHAR(300) NOT NULL, 
	occorrenza INTEGER NOT NULL, 
	attributi TEXT NOT NULL, 
	attivo BOOLEAN NOT NULL, 
	dal_verbale VARCHAR(20) NOT NULL, 
	aggiornato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	CONSTRAINT pk_impianti_elementi PRIMARY KEY (id), 
	CONSTRAINT uq_impianti_elementi_impianto_id UNIQUE (impianto_id, tipo, quadro, nome, occorrenza), 
	CONSTRAINT fk_impianti_elementi_impianto_id_impianti FOREIGN KEY(impianto_id) REFERENCES impianti (id) ON DELETE CASCADE
)

;
CREATE INDEX ix_impianti_elementi_impianto_id ON impianti_elementi (impianto_id);

CREATE TABLE impianti_pod (
	id SERIAL NOT NULL, 
	impianto_id INTEGER NOT NULL, 
	pod VARCHAR(20) NOT NULL, 
	ordine INTEGER NOT NULL, 
	CONSTRAINT pk_impianti_pod PRIMARY KEY (id), 
	CONSTRAINT uq_impianti_pod_impianto_id UNIQUE (impianto_id, pod), 
	CONSTRAINT fk_impianti_pod_impianto_id_impianti FOREIGN KEY(impianto_id) REFERENCES impianti (id) ON DELETE CASCADE
)

;
CREATE INDEX ix_impianti_pod_impianto_id ON impianti_pod (impianto_id);
CREATE INDEX ix_impianti_pod_pod ON impianti_pod (pod);

CREATE TABLE preventivi_righe (
	id SERIAL NOT NULL, 
	preventivo_id INTEGER NOT NULL, 
	ordine INTEGER NOT NULL, 
	impianto_id INTEGER, 
	asset_id INTEGER, 
	tipo_verifica_dm VARCHAR(2) DEFAULT '' NOT NULL, 
	tipo_verifica_gvr VARCHAR(30) DEFAULT '' NOT NULL, 
	asset_fotografia TEXT DEFAULT '{}' NOT NULL, 
	voce_id INTEGER, 
	quantita FLOAT, 
	tipo_verifica VARCHAR(20) NOT NULL, 
	sede_nome VARCHAR(300) NOT NULL, 
	sede_indirizzo VARCHAR(200) NOT NULL, 
	sede_comune VARCHAR(160) NOT NULL, 
	tipologia VARCHAR(80) NOT NULL, 
	descrizione VARCHAR(200) NOT NULL, 
	tariffa_standard BIGINT NOT NULL, 
	dettaglio_tariffa TEXT NOT NULL, 
	sconto INTEGER NOT NULL, 
	tariffa_applicata BIGINT NOT NULL, 
	stato VARCHAR(20) NOT NULL, 
	stato_il TIMESTAMP WITHOUT TIME ZONE, 
	stato_da VARCHAR(120) NOT NULL, 
	note VARCHAR(500) NOT NULL, 
	CONSTRAINT pk_preventivi_righe PRIMARY KEY (id), 
	CONSTRAINT ck_preventivi_righe_stato CHECK (stato IN ('in_attesa', 'accettata', 'rifiutata', 'annullata')), 
	CONSTRAINT ck_preventivi_righe_bene_unico CHECK (impianto_id IS NULL OR asset_id IS NULL), 
	CONSTRAINT ck_preventivi_righe_tipo_verifica CHECK (tipo_verifica IN ('periodica', 'straordinaria')), 
	CONSTRAINT ck_preventivi_righe_sconto CHECK (sconto >= 0 AND sconto <= 10000), 
	CONSTRAINT fk_preventivi_righe_preventivo_id_preventivi FOREIGN KEY(preventivo_id) REFERENCES preventivi (id) ON DELETE CASCADE, 
	CONSTRAINT fk_preventivi_righe_impianto_id_impianti FOREIGN KEY(impianto_id) REFERENCES impianti (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_preventivi_righe_asset_id_asset FOREIGN KEY(asset_id) REFERENCES asset (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_preventivi_righe_voce_id_tariffe_voci FOREIGN KEY(voce_id) REFERENCES tariffe_voci (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_preventivi_righe_asset_id ON preventivi_righe (asset_id);
CREATE INDEX ix_preventivi_righe_impianto_id ON preventivi_righe (impianto_id);
CREATE INDEX ix_preventivi_righe_preventivo_id ON preventivi_righe (preventivo_id);
CREATE INDEX ix_preventivi_righe_stato ON preventivi_righe (stato);

CREATE TABLE dm_incarichi (
	id SERIAL NOT NULL, 
	riga_id INTEGER NOT NULL, 
	asset_id INTEGER NOT NULL, 
	stato VARCHAR(20) NOT NULL, 
	fotografia_json TEXT NOT NULL, 
	verificatore_id INTEGER, 
	assegnata_il TIMESTAMP WITHOUT TIME ZONE, 
	assegnata_da VARCHAR(120) DEFAULT '' NOT NULL, 
	data_programmata DATE, 
	indipendenza BOOLEAN DEFAULT '1' NOT NULL, 
	indipendenza_esclusa TEXT DEFAULT '' NOT NULL, 
	bozza_json TEXT DEFAULT '{}' NOT NULL, 
	bozza_salvata BOOLEAN DEFAULT '0' NOT NULL, 
	gruppo_contatore VARCHAR(8), 
	anno INTEGER, 
	numero INTEGER, 
	codice_verbale VARCHAR(30) DEFAULT '' NOT NULL, 
	data_rilascio DATE, 
	data_pvp DATE, 
	contributo BIGINT DEFAULT '0' NOT NULL, 
	stato_prima_sospensione VARCHAR(20) DEFAULT '' NOT NULL, 
	motivo_sospensione TEXT DEFAULT '' NOT NULL, 
	motivo_annullamento TEXT DEFAULT '' NOT NULL, 
	affiancamento_id INTEGER, 
	effettuata_il TIMESTAMP WITHOUT TIME ZONE, 
	effettuata_da VARCHAR(120) DEFAULT '' NOT NULL, 
	riesame_fatto BOOLEAN DEFAULT '0' NOT NULL, 
	riesame_esito VARCHAR(1) DEFAULT '' NOT NULL, 
	riesame_nota TEXT DEFAULT '' NOT NULL, 
	riesame_il TIMESTAMP WITHOUT TIME ZONE, 
	riesame_da VARCHAR(120) DEFAULT '' NOT NULL, 
	esportata_inail BOOLEAN DEFAULT '0' NOT NULL, 
	revisione INTEGER DEFAULT '0' NOT NULL, 
	revisioni_json TEXT DEFAULT '[]' NOT NULL, 
	versione INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	modificato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	modificato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_dm_incarichi PRIMARY KEY (id), 
	CONSTRAINT uq_dm_incarichi_numero UNIQUE (gruppo_contatore, anno, numero), 
	CONSTRAINT ck_dm_incarichi_stato CHECK (stato IN ('da_assegnare','assegnata','programmata','registrata','effettuata','sospesa','annullata')), 
	CONSTRAINT fk_dm_incarichi_riga_id_preventivi_righe FOREIGN KEY(riga_id) REFERENCES preventivi_righe (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_dm_incarichi_asset_id_asset FOREIGN KEY(asset_id) REFERENCES asset (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_dm_incarichi_verificatore_id_utenti FOREIGN KEY(verificatore_id) REFERENCES utenti (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_dm_incarichi_affiancamento_id_utenti FOREIGN KEY(affiancamento_id) REFERENCES utenti (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_dm_incarichi_asset_id ON dm_incarichi (asset_id);
CREATE INDEX ix_dm_incarichi_esportata_inail ON dm_incarichi (esportata_inail);
CREATE INDEX ix_dm_incarichi_riga_id ON dm_incarichi (riga_id);
CREATE INDEX ix_dm_incarichi_verificatore_id ON dm_incarichi (verificatore_id);
CREATE UNIQUE INDEX uq_dm_incarichi_riga_attiva ON dm_incarichi (riga_id) WHERE stato != 'annullata';

CREATE TABLE fatture_righe (
	id SERIAL NOT NULL, 
	fattura_id INTEGER NOT NULL, 
	riga_preventivo_id INTEGER, 
	origine_credito_id INTEGER, 
	descrizione VARCHAR(1000) NOT NULL, 
	quantita VARCHAR(30) NOT NULL, 
	prezzo VARCHAR(30) NOT NULL, 
	importo BIGINT NOT NULL, 
	aliquota INTEGER NOT NULL, 
	natura VARCHAR(8) NOT NULL, 
	esigibilita VARCHAR(1) NOT NULL, 
	riferimento_normativo VARCHAR(200) NOT NULL, 
	riferimenti TEXT NOT NULL, 
	prestazione_intera BOOLEAN DEFAULT '0' NOT NULL, 
	CONSTRAINT pk_fatture_righe PRIMARY KEY (id), 
	CONSTRAINT ck_fatture_righe_importo CHECK (importo >= 0), 
	CONSTRAINT fk_fatture_righe_fattura_id_fatture FOREIGN KEY(fattura_id) REFERENCES fatture (id) ON DELETE CASCADE, 
	CONSTRAINT fk_fatture_righe_riga_preventivo_id_preventivi_righe FOREIGN KEY(riga_preventivo_id) REFERENCES preventivi_righe (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_fatture_righe_origine_credito_id_fatture_righe FOREIGN KEY(origine_credito_id) REFERENCES fatture_righe (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_fatture_righe_fattura_id ON fatture_righe (fattura_id);
CREATE INDEX ix_fatture_righe_riga_preventivo_id ON fatture_righe (riga_preventivo_id);

CREATE TABLE preventivi_righe_revoche (
	id SERIAL NOT NULL, 
	riga_id INTEGER NOT NULL, 
	preventivo_id INTEGER NOT NULL, 
	motivo TEXT NOT NULL, 
	stato_prima VARCHAR(20) NOT NULL, 
	verifica_id INTEGER, 
	incarico_dm_id INTEGER, 
	revocata_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	revocata_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_preventivi_righe_revoche PRIMARY KEY (id), 
	CONSTRAINT fk_preventivi_righe_revoche_riga_id_preventivi_righe FOREIGN KEY(riga_id) REFERENCES preventivi_righe (id) ON DELETE CASCADE, 
	CONSTRAINT fk_preventivi_righe_revoche_preventivo_id_preventivi FOREIGN KEY(preventivo_id) REFERENCES preventivi (id) ON DELETE CASCADE
)

;
CREATE INDEX ix_preventivi_righe_revoche_preventivo_id ON preventivi_righe_revoche (preventivo_id);
CREATE INDEX ix_preventivi_righe_revoche_riga_id ON preventivi_righe_revoche (riga_id);

CREATE TABLE verifiche (
	id SERIAL NOT NULL, 
	riga_id INTEGER NOT NULL, 
	preventivo_id INTEGER NOT NULL, 
	impianto_id INTEGER NOT NULL, 
	tipo_verifica VARCHAR(20) NOT NULL, 
	stato VARCHAR(20) NOT NULL, 
	verificatore_id INTEGER, 
	assegnata_il TIMESTAMP WITHOUT TIME ZONE, 
	assegnata_da VARCHAR(120) NOT NULL, 
	data_programmata DATE, 
	anno INTEGER, 
	numero INTEGER, 
	codice_verbale VARCHAR(20) NOT NULL, 
	verbale_id VARCHAR(40) DEFAULT '' NOT NULL, 
	data_esecuzione DATE, 
	registrata_il TIMESTAMP WITHOUT TIME ZONE, 
	registrata_da VARCHAR(120) NOT NULL, 
	modulo VARCHAR(5) NOT NULL, 
	esito VARCHAR(20) NOT NULL, 
	prossima_verifica DATE, 
	dati_verbale TEXT NOT NULL, 
	avvisi_verbale TEXT NOT NULL, 
	eseguita_il TIMESTAMP WITHOUT TIME ZONE, 
	caricata_da VARCHAR(120) NOT NULL, 
	riesame_esito VARCHAR(20) NOT NULL, 
	riesame_note TEXT NOT NULL, 
	riesame_il TIMESTAMP WITHOUT TIME ZONE, 
	riesame_da VARCHAR(120) NOT NULL, 
	indipendenza BOOLEAN DEFAULT '1' NOT NULL, 
	indipendenza_esclusa TEXT DEFAULT '' NOT NULL, 
	stato_prima_sospensione VARCHAR(20) DEFAULT '' NOT NULL, 
	motivo_sospensione VARCHAR(500) DEFAULT '' NOT NULL, 
	motivo_annullamento VARCHAR(500) NOT NULL, 
	note TEXT NOT NULL, 
	versione INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	modificato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	modificato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_verifiche PRIMARY KEY (id), 
	CONSTRAINT uq_verifiche_numero_verbale UNIQUE (anno, numero), 
	CONSTRAINT ck_verifiche_stato CHECK (stato IN ('da_assegnare', 'assegnata', 'programmata', 'registrata', 'eseguita', 'riesaminata', 'sospesa', 'annullata')), 
	CONSTRAINT fk_verifiche_riga_id_preventivi_righe FOREIGN KEY(riga_id) REFERENCES preventivi_righe (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_verifiche_preventivo_id_preventivi FOREIGN KEY(preventivo_id) REFERENCES preventivi (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_verifiche_impianto_id_impianti FOREIGN KEY(impianto_id) REFERENCES impianti (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_verifiche_verificatore_id_utenti FOREIGN KEY(verificatore_id) REFERENCES utenti (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_verifiche_codice_verbale ON verifiche (codice_verbale);
CREATE INDEX ix_verifiche_impianto_id ON verifiche (impianto_id);
CREATE INDEX ix_verifiche_preventivo_id ON verifiche (preventivo_id);
CREATE INDEX ix_verifiche_riga_id ON verifiche (riga_id);
CREATE INDEX ix_verifiche_stato ON verifiche (stato);
CREATE INDEX ix_verifiche_verbale_id ON verifiche (verbale_id);
CREATE INDEX ix_verifiche_verificatore_id ON verifiche (verificatore_id);
CREATE UNIQUE INDEX uq_verifiche_riga_attiva ON verifiche (riga_id) WHERE stato != 'annullata';

CREATE TABLE dm_documenti (
	id SERIAL NOT NULL, 
	incarico_id INTEGER NOT NULL, 
	documento_id INTEGER NOT NULL, 
	tipo VARCHAR(20) NOT NULL, 
	formato VARCHAR(4) NOT NULL, 
	gruppo VARCHAR(36) NOT NULL, 
	nome_file VARCHAR(255) NOT NULL, 
	attuale BOOLEAN NOT NULL, 
	impronta_dati VARCHAR(64) NOT NULL, 
	fotografia_json TEXT NOT NULL, 
	origine VARCHAR(30) NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	definitivo_il TIMESTAMP WITHOUT TIME ZONE, 
	CONSTRAINT pk_dm_documenti PRIMARY KEY (id), 
	CONSTRAINT ck_dm_documenti_tipo CHECK (tipo IN ('verbale','scheda_tecnica')), 
	CONSTRAINT ck_dm_documenti_formato CHECK (formato IN ('docx','pdf')), 
	CONSTRAINT fk_dm_documenti_incarico_id_dm_incarichi FOREIGN KEY(incarico_id) REFERENCES dm_incarichi (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_dm_documenti_documento_id_documenti FOREIGN KEY(documento_id) REFERENCES documenti (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_dm_documenti_incarico_id ON dm_documenti (incarico_id);

CREATE TABLE dm_esportazioni_inail_righe (
	id SERIAL NOT NULL, 
	esportazione_id INTEGER NOT NULL, 
	incarico_id INTEGER NOT NULL, 
	dati_json TEXT NOT NULL, 
	CONSTRAINT pk_dm_esportazioni_inail_righe PRIMARY KEY (id), 
	CONSTRAINT uq_dm_esportazioni_inail_righe_esportazione_id UNIQUE (esportazione_id, incarico_id), 
	CONSTRAINT fk_dm_esportazioni_inail_righe_esportazione_id_dm_espor_5990 FOREIGN KEY(esportazione_id) REFERENCES dm_esportazioni_inail (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_dm_esportazioni_inail_righe_incarico_id_dm_incarichi FOREIGN KEY(incarico_id) REFERENCES dm_incarichi (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_dm_esportazioni_inail_righe_esportazione_id ON dm_esportazioni_inail_righe (esportazione_id);
CREATE INDEX ix_dm_esportazioni_inail_righe_incarico_id ON dm_esportazioni_inail_righe (incarico_id);

CREATE TABLE dm_invii (
	id SERIAL NOT NULL, 
	incarico_id INTEGER NOT NULL, 
	destinatari TEXT NOT NULL, 
	copia TEXT NOT NULL, 
	oggetto VARCHAR(300) NOT NULL, 
	testo TEXT NOT NULL, 
	allegati_json TEXT NOT NULL, 
	esito VARCHAR(300) NOT NULL, 
	inviato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	inviato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_dm_invii PRIMARY KEY (id), 
	CONSTRAINT fk_dm_invii_incarico_id_dm_incarichi FOREIGN KEY(incarico_id) REFERENCES dm_incarichi (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_dm_invii_incarico_id ON dm_invii (incarico_id);

CREATE TABLE dm_riesami (
	id SERIAL NOT NULL, 
	incarico_id INTEGER NOT NULL, 
	documento_id INTEGER, 
	fatto BOOLEAN NOT NULL, 
	esito VARCHAR(1) NOT NULL, 
	nota TEXT NOT NULL, 
	eseguito_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	eseguito_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_dm_riesami PRIMARY KEY (id), 
	CONSTRAINT fk_dm_riesami_incarico_id_dm_incarichi FOREIGN KEY(incarico_id) REFERENCES dm_incarichi (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_dm_riesami_documento_id_documenti FOREIGN KEY(documento_id) REFERENCES documenti (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_dm_riesami_incarico_id ON dm_riesami (incarico_id);

CREATE TABLE dm_schede_verbale (
	id SERIAL NOT NULL, 
	asset_id INTEGER NOT NULL, 
	gruppo VARCHAR(30) NOT NULL, 
	campi_json TEXT NOT NULL, 
	origine VARCHAR(20) NOT NULL, 
	incarico_id INTEGER, 
	data_riferimento DATE NOT NULL, 
	nota TEXT DEFAULT '' NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_dm_schede_verbale PRIMARY KEY (id), 
	CONSTRAINT fk_dm_schede_verbale_asset_id_asset FOREIGN KEY(asset_id) REFERENCES asset (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_dm_schede_verbale_incarico_id_dm_incarichi FOREIGN KEY(incarico_id) REFERENCES dm_incarichi (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_dm_schede_verbale_asset_id ON dm_schede_verbale (asset_id);

CREATE TABLE scadenze_tecniche (
	id SERIAL NOT NULL, 
	asset_id INTEGER NOT NULL, 
	componente VARCHAR(20) NOT NULL, 
	data_ultima DATE, 
	data_prossima DATE, 
	numero_report VARCHAR(100) NOT NULL, 
	fonte VARCHAR(20) NOT NULL, 
	nota TEXT NOT NULL, 
	incarico_dm_id INTEGER, 
	dati_iniziali_json TEXT DEFAULT '{}' NOT NULL, 
	versione INTEGER NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	modificato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	modificato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_scadenze_tecniche PRIMARY KEY (id), 
	CONSTRAINT uq_scadenze_tecniche_asset_id UNIQUE (asset_id, componente), 
	CONSTRAINT ck_scadenze_tecniche_componente CHECK (componente IN ('dpr','funzionamento','integrita','interna','scsp','cnd','supplementare','taratura')), 
	CONSTRAINT ck_scadenze_tecniche_fonte CHECK (fonte IN ('dichiarata','dpr','dm')), 
	CONSTRAINT fk_scadenze_tecniche_asset_id_asset FOREIGN KEY(asset_id) REFERENCES asset (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_scadenze_tecniche_incarico_dm_id_dm_incarichi FOREIGN KEY(incarico_dm_id) REFERENCES dm_incarichi (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_scadenze_tecniche_asset_id ON scadenze_tecniche (asset_id);
CREATE INDEX ix_scadenze_tecniche_data_prossima ON scadenze_tecniche (data_prossima);

CREATE TABLE verifiche_documenti (
	id SERIAL NOT NULL, 
	verifica_id INTEGER NOT NULL, 
	formato VARCHAR(10) NOT NULL, 
	documento_id INTEGER NOT NULL, 
	nome_file VARCHAR(255) NOT NULL, 
	in_uso BOOLEAN NOT NULL, 
	creato_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	creato_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_verifiche_documenti PRIMARY KEY (id), 
	CONSTRAINT fk_verifiche_documenti_verifica_id_verifiche FOREIGN KEY(verifica_id) REFERENCES verifiche (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_verifiche_documenti_documento_id_documenti FOREIGN KEY(documento_id) REFERENCES documenti (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_verifiche_documenti_verifica_id ON verifiche_documenti (verifica_id);

CREATE TABLE verifiche_riesami (
	id SERIAL NOT NULL, 
	verifica_id INTEGER NOT NULL, 
	documento_id INTEGER, 
	verbale_id VARCHAR(40) NOT NULL, 
	esito VARCHAR(20) NOT NULL, 
	note TEXT NOT NULL, 
	eseguito_il TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	eseguito_da VARCHAR(120) NOT NULL, 
	CONSTRAINT pk_verifiche_riesami PRIMARY KEY (id), 
	CONSTRAINT fk_verifiche_riesami_verifica_id_verifiche FOREIGN KEY(verifica_id) REFERENCES verifiche (id) ON DELETE RESTRICT, 
	CONSTRAINT fk_verifiche_riesami_documento_id_documenti FOREIGN KEY(documento_id) REFERENCES documenti (id) ON DELETE RESTRICT
)

;
CREATE INDEX ix_verifiche_riesami_verifica_id ON verifiche_riesami (verifica_id);
