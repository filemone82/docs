# Collaudo 0.9.0

133 test passati (121 della base DPR e 12 nuovi del nucleo comune).

Suite completa: `pytest -q --junitxml=report_collaudo/pytest_0.9.0.xml`. Dodici test del nucleo anche eseguiti separatamente. Interfaccia provata con DOM jsdom + HTTP; nessuna prova Windows osservata. PDF ordinari con stub della suite, prove marcate `pdf_vero` secondo configurazione esistente.

Dettagli in `STATO_IMPLEMENTAZIONE_0.9.0.md`. I rapporti 0.8 restano nella sottocartella precedenti.

Dopo il controllo finale dei numeri italiani, rieseguiti i 12 test del nucleo: tutti passati, inclusa camera «1.000» = 1000 L. Report dedicato `pytest_beni_0.9.0.txt`/XML. Le regressioni DPR non usano questo parser.
