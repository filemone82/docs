# Controlli effettivi 0.12.1-wip1

11 ottobre 2026. Linux, Python 3.12, SQLite. Schema 0015.

| Controllo | Esito e limite |
|---|---|
| Regressione mirata dopo le modifiche: test_finanza.py, test_dm_tecnico.py, test_dm_documenti.py | 49 passati, 1 avviso, 76,19 secondi. Risultato osservato nella sessione; il log grezzo di questa invocazione non è stato conservato. Comprende i due test aggiornati, non un nuovo collaudo INAIL. |
| Suite completa del codice di lavoro: python -m pytest -q con rapporto JUnit | 215 passati, 1 avviso, 312,36 secondi. Log e XML pytest_0.12.1-wip1 in report_collaudo. Nessun nuovo test dedicato finanza DM/INAIL è stato aggiunto. |
| Prova diretta della migrazione 0014→0015 | Passata. Schema uguale ai modelli, zero errori di chiavi esterne; conservati 72 ID specifiche, 6 famiglie GVR, 31 tipi, 162 compatibilità e 314 tariffe. Archivio sintetico senza incarichi né righe fattura preesistenti. Log migrazione_0015_sintetica.txt e script di prova inclusi. |
| Ruff E9/F sui file applicativi nuovi o modificati e sulla 0015 | Passato dopo rimozione di tre import inutilizzati. Log ruff_0.12.1-wip1.txt. È un controllo statico, non una prova delle funzioni. |

215 è la raccolta della suite esistente, con due test modificati. Non sommare 49 e 215. Mancano test nuovi dedicati DM finanza e INAIL, prove delle nuove interfacce e installazione Windows. I report 0.12.0-dev restano storici. Nessuna attestazione di completezza o produzione.
