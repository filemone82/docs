> **0.12.0-dev è un checkpoint di sviluppo, non la candidata completa richiesta.** VerbalizzAI incorporato 1.0.1 rc2 e nuovo ciclo documentale DM; perimetro in STATO_IMPLEMENTAZIONE_0.12.0-dev.md. Conservare dati e installazioni operativi. Non occorre installare questo incremento intermedio. Le istruzioni storiche sotto servono a eventuali prove isolate; non attestano collaudo Windows o migrazione completa.

# Gestionale AD 0.11.0-dev — incremento di sviluppo DPR–DM

**Correzione attuale:** leggere prima `NOTE_CORREZIONE_PREVENTIVI.md` per il blocco dei duplicati e il riuso dei dati del collaudo.
Questa candidatura estende la base DPR 0.8.0 con le prime schede SC/SP/GVR/PSV, cataloghi Garda, camere/accessori e date tecniche condivise. Non è ancora il gestionale completo delle tre attività. Si aggiungono schede tecniche e preventivi DM sul nucleo comune; stato e prove in `STATO_IMPLEMENTAZIONE_0.11.0-dev.md`. Non è il rilascio completo R99.

## Installazione e avvio

1. Installa **Python 3.12 a 64 bit**, abilitando l'aggiunta al PATH, e **LibreOffice**. Il pacchetto contiene il sorgente; `INSTALLA_WINDOWS.bat` scarica le dipendenze fissate in `requirements.txt`.
2. Estrai lo ZIP in una cartella nuova, per esempio `C:\VerbalizzAI\Gestionale_AD_integrato_0.11.0-dev`. Mantieni le installazioni precedenti e i loro dati separati.
3. Esegui **`INSTALLA_WINDOWS.bat`**. Attendi il completamento senza chiudere la finestra.
4. Esegui **`AVVIA_COLLAUDO_WINDOWS.bat`**. Il browser apre `http://127.0.0.1:8462`; lascia aperta la finestra del programma. Se necessario apri questo indirizzo manualmente.
5. Crea il primo amministratore dalla pagina iniziale. Questo avvio usa **`Dati_Collaudo` dentro la nuova cartella**, separata dai dati precedenti. Riutilizzando il file di avvio ritrovi lo stesso archivio di prova.

Se LibreOffice non è nel percorso standard, configura `libreoffice` in `config.json`, per esempio `C:\Program Files\LibreOffice\program\soffice.exe` (nel JSON usa doppie barre inverse). La guida completa è in `LEGGIMI.md`.

`AVVIA_WINDOWS.bat` usa invece la normale configurazione della cartella dati. Per queste prime prove usa il file **COLLAUDO**, così non apri per errore l'archivio che usi con un'altra versione. Chiudi l'altro gestionale locale se sta già usando la porta 8462. Nessuna bozza offline o infrastruttura esterna è necessaria per questo collaudo.

## Primo giro consigliato

Usa un cliente e un impianto sintetici, chiaramente identificati come prova. Non configurare destinatari email reali per i test di invio.

1. Crea cliente, sede e impianto. Controlla il tariffario proposto; per ATEX imposta le ore preventivate.
2. Crea il preventivo, genera l'anteprima PDF e prova anche a scaricare, modificare e ricaricare il Word. Approva il documento corretto; usa **Segna come inviato** per simulare l'invio.
3. Accetta le righe pertinenti e indica il riferimento all'email o al preventivo controfirmato di prova. Il riferimento richiesto non archivia da solo l'allegato di accettazione.
4. Esegui il riesame dell'offerta, assegna il tecnico, registra la verifica. La programmazione è facoltativa. Prova sospensione e ripresa, verificando che il numero non cambi.
5. Compila il verbale nel modulo VerbalizzAI, controlla il PDF e finalizza. Esegui un RV negativo con nota: la verifica deve tornare a registrata. Correggi, finalizza nuovamente e registra un RV conforme; controlla lo storico.
6. Apri **Fatture e incassi** e configura **Dati fiscali AD** con valori di collaudo. Crea una bozza, aggiungi la riga da preventivo o una riga libera, controlla intestatario, IVA, eventuali CIG/CUP e scadenze. L'intestatario può essere un terzo, senza cambiare preventivo o verbale.
7. Genera XML e PDF di cortesia. In questo archivio si tratta di documenti di prova: il gestionale non trasmette l'XML ad Aruba. Prima di usare XML reali occorrono le verifiche fiscali elencate in `STATO_IMPLEMENTAZIONE_0.9.0.md`.
8. Registra un incasso e attribuiscilo alla fattura. Prova due fatture nello stesso movimento, una nota di credito parziale e lo storno di una registrazione errata; controlla i residui.
9. Esegui e verifica un backup dal menu Sistema. Il ripristino si prova sull'archivio di collaudo.

## Dati reali e aggiornamenti

Gli strumenti ereditati di importazione Garda lavorano su un **archivio distinto inizialmente vuoto**. Non importano ancora fatture, incassi o originali S3, né riallineano incrementalmente un archivio già usato. Il loro rapporto va esaminato prima di considerare attendibile ogni pratica importata.

Non è necessario fornire ora gli originali S3. Per le prime prove funzionali bastano i dati sintetici e i documenti prodotti nel collaudo. Le prove con allegati storici saranno una fase separata.

Su una copia di un archivio precedente, l'avvio applica le migrazioni fino alla 0013 dopo il backup pre-aggiornamento. Il ritorno alla versione precedente richiede il ripristino di quel backup con il programma corrispondente: non aprire con un programma vecchio il database aggiornato.

## Verifica automatica e segnalazioni

`ESEGUI_TEST_WINDOWS.bat` esegue i test. I test con conversione PDF reale richiedono LibreOffice; `pdftotext` non è necessario su Windows. Le verifiche già eseguite sono descritte nel rapporto incluso; l'installazione e la resa grafica su Windows devono ancora essere provate sul PC di destinazione.

Per una segnalazione indica versione, passaggi eseguiti, risultato atteso e risultato ottenuto; aggiungi uno screenshot o il messaggio della finestra del programma. Non servono credenziali o una copia indiscriminata dei dati reali.

## Prova del nuovo parco comune

Dopo avere creato cliente e sede di prova, apri **Parco comune → Attrezzature e accessori**. Usa **Nuovo bene**, scegli gruppo e sede, inserisci matricola informale e classificazione pertinente. Per GVR prova camere in litri/DN, associazioni PSV e date CND con numero report. Le date delle valvole sono condivise; i DN non entrano nel volume totale. **Date tecniche** permette di consultare le date dichiarate e quelle DPR.

Gli impianti DPR vengono inseriti nel parco automaticamente, mantenendo la loro scheda e i flussi esistenti. Per DM sono disponibili le offerte per sede con righe SC/SP/GVR, tariffazione, documenti e RC; gli incarichi sono assegnabili, programmabili e registrabili dalla nuova voce DM → Incarichi DM. Esecuzione/verbalizzazione DM, fatturazione DM collegata e INAIL non sono ancora disponibili. I&C resta da realizzare. Il modello operativo Excel sarà completato alla fine secondo quanto concordato.


## Prova del percorso commerciale DM di questo incremento

1. Nella scheda del bene scegliere matricola 4/1/5/2, all.7 e ID specifica compatibile, tipo prossima verifica ed esenzione. Per GVR compilare i parametri e la messa in servizio pertinente. I dati sono sintetici di collaudo.
2. Aprire **DM → Preventivi DM**, creare dalla sede di quel cliente e lasciare o scegliere la serie.
3. Aggiungere le attrezzature della sede; indicare prima/successiva e, per GVR, combinazione. Controllare tariffa e sconto. Le tubazioni non permettono interna.
4. Produrre Word/PDF con LibreOffice, controllare e approvare. Usare Segna come inviato, senza destinatari reali.
5. Accettare le righe indicando evidenza scritta e registrare RC conforme. Gli incarichi appaiono come **da assegnare** nella scheda del preventivo: è il limite attuale, non proseguire il flusso tecnico DM tramite schermate DPR.

Windows e conversione PDF DM reale restano da collaudare; il pacchetto salva il progresso per proseguire lo sviluppo.


## Nuovo percorso tecnico DM

Seguire `COLLAUDO_MANUALE_0.11.0-dev.md`: assegnazione, programmazione facoltativa, scheda tecnica/camere, registrazione, contatori GVR e SC-SP. La finalizzazione DM non è ancora implementata. Puoi terminare la prova della 0.10 usando la sua installazione/archivio e provare questo checkpoint separatamente.

## Ambienti operativi e indirizzi di accesso

Un backend e un database applicativo comuni, tre ambienti di navigazione: **AD_DPR**, **AD_DM** (GVR/SC/SP) e **I&C S.r.l.** Il selettore Attività mantiene le anagrafiche comuni, filtra il menu e non concede permessi. Le API continuano a controllare ruoli e titolarità dei lavori. La preferenza di navigazione non determina emittente, sezionale o contabilità.

Ingressi locali già disponibili: `/ad-dpr`, `/ad-dm`, `/iec`; selezionano direttamente l’ambiente, anche arrivando da un collegamento. Le pagine comuni conservano la scelta; le pagine operative DPR/DM la rendono coerente con il modulo aperto. I&C mostra una pagina esplicita di funzioni ancora da realizzare; non espone la fatturazione DPR come se fosse I&C. Nell’ambiente DM non viene presentata la fatturazione DPR come fatturazione DM.

**Chiarimento dell’utente:** nella versione definitiva vuole indirizzi distinti per i tre ambienti, o almeno un accesso AD_DPR/AD_DM e uno separato I&C. Questo è acquisito. Due o tre URL/nomi host sono configurazioni di ingresso della stessa applicazione, non tre gestionali da mantenere. La configurazione dei domini, del proxy e delle autorizzazioni per ambito in produzione è ancora da realizzare; gli ingressi locali non sono una prova di separazione dei domini o di isolamento dei dati. Il selettore è utile al collaudo e agli utenti autorizzati su più attività.

Sviluppo: una sola installazione/avvio, un archivio di prova, passaggio fra le attività senza riavviare. Collaudo e produzione usano archivi distinti. AD_DM e AD_DPR appartengono ad AD S.r.l.; I&C S.r.l. mantiene emittente/contabilità distinti. Nessuna fusione di preventivi o fatture DM/DPR introdotta da questa navigazione.
