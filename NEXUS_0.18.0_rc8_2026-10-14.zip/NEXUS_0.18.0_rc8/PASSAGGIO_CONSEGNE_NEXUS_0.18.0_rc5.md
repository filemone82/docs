# NEXUS 0.18.0 rc5 — ripresa e lavoro ancora necessario

14 ottobre 2026. Base: copia isolata di `NEXUS_0.18.0_rc4`; migrazione DB
invariata (`0029`). Questa è una versione **di collaudo**, non da usare con il
database `nexus_locale` o in produzione prima delle prove PostgreSQL native.

## Perimetro deciso

NEXUS DPR sostituirà ingecert per **tutte** le nuove attività, previste per
gennaio 2027, con l'intero archivio ingecert importato. VerbalizzAI resta
autonomo e scrive nel suo SQLite fino al taglio finale, poi il verbale è una
parte del percorso delle verifiche DPR nel PostgreSQL di NEXUS. L'interfaccia
e i tempi degli operatori fanno parte dei criteri di rilascio.

## Correzioni rc5

- `attivazione.py`: se esiste ancora il vecchio `archivio.sqlite`, l'avvio
  con `verbali_postgresql=true` richiede il marcatore di un'importazione
  verificata. Confronta ID e impronta di meta, oggetti, eventi, utenti e
  metadati documenti del vecchio SQLite con la sorgente del backup importato,
  leggendo SQLite in sola lettura. Blocca sia i soli modelli precaricati nel PG
  sia ulteriori scritture sul vecchio archivio. Senza un vecchio SQLite,
  l'avvio ex novo rimane consentito. Una sorgente diversa richiede valutazione
  esplicita; non spostare o cancellare il vecchio file per aggirare il blocco.
- `importa_postgresql.py`: dopo i confronti già presenti e la verifica del
  backup PG di ritorno registra nel PG ID, impronta della sorgente, SHA256 del
  backup e conteggi. Il marcatore non è scritto se la verifica fallisce.
- `app.py`: chiude la connessione al database gestionale se l'attivazione
  fallisce.
- `servizio.py`: `/api/verbali/riallinea` esamina anche i verbali emessi con
  `verifica_id` persistito nel verbale quando `Verifica.verbale_id` è vuoto;
  non riprende associazioni che puntano già a un altro verbale. Il caricamento
  del PDF è idempotente. Sono state aggiunte prove di interruzione e ripresa.

## Test eseguiti qui

`PYTHONPATH=../runtime_dependencies python -m pytest -q
tests/test_attivazione_verbali.py tests/test_verbali.py
tests/test_verbalizzai_identico.py tests/test_porting_postgresql.py
tests/postgresql/test_verbali_pg.py`: **26 passed, 5 skipped**. I cinque test
PG sono saltati perché non c'è un server PostgreSQL in questo ambiente.
`ruff check --select F` sui file modificati: superato. Non è stata ripetuta
la suite generale e non è stata provata una copia reale del backup.

## Limiti e prossimi lavori

1. Collaudare **i cinque test PG** su database temporanei Windows, inclusa
   l'attivazione dopo importazione; verificare `5 passed`, mai `skipped`.
   Provare anche backup e ripristino, i flussi dei verbali via API con ruoli
   distinti e un'interruzione fra emissione e registrazione della verifica.
2. Definire il raccordo fra lo storico dell'istanza autonoma VerbalizzAI e le
   verifiche importate da ingecert. Il marcatore confronta un eventuale SQLite
   incorporato locale con il backup importato: se non sono lo stesso archivio,
   l'avvio viene intenzionalmente bloccato. La procedura di cutover dovrà
   stabilire quale archivio è sorgente e come gestire ogni altra copia.
3. Avviare subito, in parallelo, l'importatore **ingecert MariaDB → PG** e
   l'inventario dei documenti. `strumenti/importa_da_garda.py` ora crea SQLite
   e rifiuta l'URL PG; la libreria legge clienti, sedi, impianti, preventivi,
   verifiche e altri cataloghi, ma non importa ancora le fatture storiche.
   I PDF dei verbali sono soltanto citati come nomi nell'archivio Garda/S3:
   non sono copie verificate nello storage NEXUS. Non chiamare completa questa
   migrazione senza censimento, corrispondenze e quadrature dei file e dei
   dati, e una decisione esplicita su fatture/stati amministrativi.
4. Eseguire prove operative con segreteria, tecnici, RT e amministrazione su
   una copia realistica dello storico; misurare tempo, passaggi, ricerche e
   trascrizioni manuali per ogni attività e ripetere le prove dopo i ritocchi.

Non mettere in funzione rc5 sul database locale esistente soltanto perché i
test senza PostgreSQL sono verdi. La versione rc4 rimane intatta nella sua
cartella: lavorare su questa copia oppure su un ramo Git, evitando che due
istanze scrivano negli stessi file.
