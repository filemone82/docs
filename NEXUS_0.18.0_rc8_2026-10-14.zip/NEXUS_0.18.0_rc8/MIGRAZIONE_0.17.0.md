# Aggiornamento 0.16.0 → 0.17.0

Versione applicativa **0.17.0**, schema Alembic **0027**, stessa catena 0001–0027, nessuna migrazione DDL aggiuntiva. Non è il passaggio a PostgreSQL e non è un'importazione completa Garda.

1. Chiudere NEXUS e verificare la cartella dati attualmente usata da `config.json` e dagli script di avvio.
2. Fare un backup completo di database, documenti e archivio VerbalizzAI. Lo schema è invariato: l'avvio non genera automaticamente un backup pre-migrazione per il solo cambio di codice; il backup prima dell'aggiornamento va quindi fatto esplicitamente.
3. Estrarre la 0.17 in una nuova cartella del programma. Conservare la 0.16 e il backup. Usare la stessa cartella dati senza sovrascriverla con un ambiente di prova e senza rifare l'importazione Garda.
4. Installare le dipendenze e avviare con la configurazione corrente. Il catalogo aggiorna etichette e descrizioni. Ruoli personalizzati, utenti, password e dati operativi non vengono ricreati.
5. Verificare RT DPR/RT DM, utenti attivi e ruoli, scadenze, un preventivo con righe collegate, salvataggio scheda e riesame tramite RT distinto dall'esecutore. Le assegnazioni degli utenti importati da Garda richiedono la riattivazione controllata; nessuna attivazione massiva automatica.
6. Le vecchie concessioni ai ruoli nell'altra attività possono restare memorizzate: il controllo effettivo della gestione impianti/attrezzature ora segue l'attività del ruolo che dà il permesso. La matrice indica «altra attività»; nessuna riscrittura massiva delle scelte dell'amministratore.
7. Le configurazioni personali restano valide. Per adottare i nuovi valori iniziali scegliere «Vista iniziale della versione corrente» e salvarla eventualmente come predefinita.

La 0.17 non cancella né invalida automaticamente i riesami precedenti eseguiti dall'autore del verbale: vanno individuati e gestiti separatamente sull'archivio operativo. Non fare downgrade dello schema. Tornare alla 0.16 ripristinando un backup coerente del precedente punto di lavoro, evitando di perdere le operazioni registrate dopo l'aggiornamento. La 0.16 consentirebbe nuovamente i comportamenti corretti dalla 0.17.
