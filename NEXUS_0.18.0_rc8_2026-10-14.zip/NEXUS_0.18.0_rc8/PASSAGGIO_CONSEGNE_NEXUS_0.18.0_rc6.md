# NEXUS rc6 — correzione dopo il primo test PostgreSQL nativo

Base: rc5. Il 14 ottobre 2026 il test nativo
`test_importazione_verbali_e_attivita_successiva` è fallito nel costruttore
`ArchivioPostgresql`, prima di importare dati, perché `_righe()` presupponeva
colonne anche nei comandi `BEGIN` e `ROLLBACK`. Il test nativo di rifiuto di
una copia senza documenti è passato (1 passed). Il traceback ricevuto non
contiene dati del database dell'utente.

In rc6 `_righe()` ammette `cursor.description=None`, mantenendo invariato il
formato delle righe delle query. Aggiunto `tests/test_righe_postgresql.py`.
Nel presente ambiente: **2 passed, 5 skipped** sulle prove mirate; i cinque
test PG restano da ripetere su Windows, poiché qui non c'è un server PG. Nessun
database dell'utente è stato modificato.

Per il collaudo rapido su Windows si può sostituire soltanto il file
`gestionale/moduli/verbali/postgresql.py` della rc5 con quello di rc6, con
NEXUS fermo, poi rilanciare il singolo test d'importazione. L'intera cartella
rc6 è inclusa separatamente per preservare una versione riproducibile. Se il
test rivela altri errori, conservare il traceback e correggere l'adattatore;
non abilitare ancora `verbali_postgresql` sui dati reali.

Il perimetro funzionale e gli altri limiti descritti nel passaggio di consegne
rc5 restano aperti, inclusa l'importazione completa di ingecert e relativi
documenti.
