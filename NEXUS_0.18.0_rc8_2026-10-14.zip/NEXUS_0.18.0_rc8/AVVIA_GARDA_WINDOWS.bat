@echo off
setlocal
set GESTIONALE_DATABASE_URL=
chcp 65001 >nul
cd /d "%~dp0"
title NEXUS - ARCHIVIO IMPORTATO DA GARDA (prova)
if not exist ".venv\Scripts\python.exe" (
  echo  Prima esegui INSTALLA_WINDOWS.bat
  pause
  exit /b 1
)
if not exist "..\GestionaleAD_dati_GARDA\database.sqlite" (
  echo  Archivio non ancora creato: esegui prima IMPORTA_DA_GARDA_WINDOWS.bat
  pause
  exit /b 1
)
set GESTIONALE_CARTELLA_DATI=%~dp0..\GestionaleAD_dati_GARDA
echo.
echo  ==============================================================
echo   ARCHIVIO IMPORTATO DA GARDA - prova, non ancora in uso
echo   Cartella: ..\GestionaleAD_dati_GARDA
echo   Utente admin con la password mostrata dall'importazione
echo   Apri il browser su  http://127.0.0.1:8462
echo  ==============================================================
echo.
".venv\Scripts\python.exe" -m gestionale
pause
