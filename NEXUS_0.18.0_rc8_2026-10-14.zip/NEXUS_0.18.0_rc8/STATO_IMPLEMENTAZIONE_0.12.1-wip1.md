# Stato della consegna 0.12.1-wip1

11 ottobre 2026. Codice in lavorazione; schema Alembic 0015. Il documento 29 contiene soltanto differenze rispetto alla 0.12.0-dev, risultati effettivi e limiti. README_INSTALLAZIONE.md è il riferimento per la prova isolata e l’aggiornamento di una copia. I vecchi documenti di stato sono evidenze storiche.

I&C, import completo dei tre Garda e dashboard non hanno un nuovo incremento applicativo recuperabile. Finanza DM e INAIL sono backend in lavorazione; non sono collaudati come cicli completi. 215 test esistenti passati non attestano queste parti nuove. Nessun rilascio in produzione.
