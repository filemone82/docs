# Primo incremento del nucleo comune — Gestionale AD 0.9.0

Versione 1.0 — 9 ottobre 2026. Attuazione iniziale di B1, denominata B1a per distinguere il codice consegnato dal blocco ancora da completare. La priorità resta R97: versione integrata DPR/DM/I&C completa da collaudare localmente. Il modello Excel è rinviato alla fase finale.

È disponibile codice Python eseguibile, derivato dalla candidatura 0.8.0, con nuove schede del parco beni, cataloghi Garda, camere/accessori e date tecniche. Questa consegna non attiva ancora preventivi/verifiche DM, attività I&C o rendicontazione INAIL.

## 1. Cosa contiene il pacchetto

`Gestionale_AD_v0.9.0_nucleo_comune_Windows_2026-10-09.zip` contiene sorgenti, avvii Windows, dipendenze fissate già usate nella 0.8.0, migrazione 0011, dodici test aggiuntivi, rapporti di collaudo e istruzioni. Non contiene un archivio operativo, gli originali S3 o i dump completi delle tre società. I quattro cataloghi DM del dump ricevuto sono inclusi come snapshot.

| Funzione | Implementazione effettiva |
|---|---|
| Parco comune | Tabella `asset`, identità del bene, sede, matricole, costruttore/modello/anno, gruppo DPR/SC/SP/GVR/PSV, note, versione e tracciamento. |
| Cataloghi | 6 famiglie GVR, 31 classificazioni all.7, 72 ID specifiche e 162 associazioni, tutte le 271 righe conservate con ID e copia JSON completa dei campi originari. |
| Classificazione | Scelta manuale; controllo di gruppo/famiglia e delle associazioni con ID specifica. Nessun cambio automatico per il superamento dei dieci anni. |
| Camere GVR | Identificazione e numero fabbrica, chiave normalizzata, unità litri o DN (mm), valore in decimi interi; somma dei soli litri. Modifica della stessa camera senza duplicarla. |
| Accessori | Schede PSV e associazioni correnti molti-a-molti con GVR; una valvola può essere condivisa. Le date della valvola sono lette da tutte le attrezzature collegate. |
| Date tecniche | Ultima/prossima data e riferimento al report per componente; registrazione iniziale dichiarata, senza creare verifiche o report fittizi e senza calcolare genericamente nuove periodicità. |
| Tubazioni | Famiglia GVR `a4`: visita interna esclusa dalle componenti e rifiutata dal backend, anche per richieste costruite a mano. |
| DPR | Migrazione degli impianti al riferimento comune; API/flussi DPR restano operativi e mantengono le proprie chiavi. Modifiche e date si proiettano sul parco nella stessa transazione. |
| Interfaccia | Nuove pagine Attrezzature e accessori / Date tecniche, ricerca e paginazione, schede/modifica, classificazioni, camere, PSV, date, dismissione e storico. |
| Protezioni | FK dichiarate, unicità della matricola nella sede per attrezzature/accessori, permessi backend, CSRF, versione obbligatoria nelle nuove modifiche e registro delle variazioni. |
| Backup | Le nuove tabelle sono nel database già salvato dal backup. Provato ripristino di camere, date, report, associazioni, origini DPR e dati precedenti. |

La lista delle date tecniche conserva anche record privi di una prossima data: mostra dati iniziali, non inventa una futura obbligazione. La data sintetica delle tarature sulla scheda GVR è `MAX(ultime)`/`MIN(prossime)` delle valvole correnti pertinenti, escludendo valvole dismesse o con sede inattiva. Non sostituisce ancora tutta la proiezione Garda delle righe di scadenzario collegate a preventivi e verifiche.

## 2. Migrazione e proprietà dei dati

La revisione applicativa **0011** aggiunge nove tabelle: `asset`, `asset_origini`, `asset_camere_gvr`, `asset_relazioni`, `scadenze_tecniche` e i quattro cataloghi `cls_*`. Aggiunge inoltre `impianti.asset_id`, unico, obbligatorio e con FK. L'applicazione esegue il backup pre-aggiornamento e applica la migrazione su un archivio precedente, come già previsto nella base.

Gli ID degli impianti DPR, le righe preventivo, le verifiche e i loro riferimenti non vengono rinumerati. Gli asset iniziali DPR ricevono lo stesso numero; i nuovi beni usano la propria chiave comune. Una seconda esecuzione dell'aggiornamento già applicato non ricrea beni o origini.

Per questa transizione, `impianti` resta proprietaria dei campi DPR; `asset` ne contiene una proiezione di sola lettura e il riferimento canonico. Un hook intercetta le scritture ORM del programma, compreso l'importer DPR, e aggiorna proiezione e data tecnica nella stessa transazione. Un rollback annulla entrambi. La scheda comune rifiuta modifiche dirette al DPR e rimanda alla scheda esistente, evitando due percorsi di modifica concorrenti. Non sono supportate scritture SQL esterne aggirando l'applicazione.

È un passaggio transitorio nel medesimo database, non il modello definitivo di proprietà di tutti i campi DPR. Il raccordo dei preventivi/incarichi al bene comune e la rimozione delle duplicazioni di proiezione vanno completati con i flussi. I beni DM e gli accessori invece nascono già come schede comuni: non vengono create copie DM e I&C.

`asset_origini` rende disponibili chiavi uniche sistema/tabella/ID sorgente; l'origine locale DPR è popolata. Ciò non costituisce un importer incrementale dei dump, né certifica già l'abbinamento delle tre anagrafiche. Nessuna deduplicazione per nomi/indirizzi o partita IVA è stata eseguita in questo incremento.

Il diagramma E-R v0.3 resta il progetto complessivo, non la descrizione di tutte le tabelle già applicate. La migrazione 0011 è un incremento compatibile della base, non l'applicazione integrale delle 85 tabelle proposte.

## 3. Riscontri Garda e decisioni preservate

| Regola | Riscontro e comportamento in questa consegna |
|---|---|
| R74 / R84 | Cataloghi e associazioni dal database `adsrl`; classificazione manuale e corrente. Le fotografie degli emessi non vengono riscritte dalla scheda. Il futuro INAIL dovrà leggere la classificazione corrente secondo l'analisi. |
| R80 | Le camere si identificano mediante descrizione/numero fabbrica; totale in litri, DN esclusi. Il matching dei batch Excel resta distinto ed è rinviato (IMP-02). |
| R35 / R95 | Associazioni correnti, senza nuovo storico montaggi; una data PSV comune viene letta da ogni bene associato, senza comando manuale di sincronizzazione. Il flusso attività I&C non è ancora innestato. |
| R85 / R86 | Numero di report registrabile con le date CND della scheda; nessun vincolo globale uno-a-uno report/attrezzatura imposto. L'integrazione del software tecnico esterno è successiva. |
| R94 | Esclusione della visita interna per tubazioni nella nuova scheda e nel servizio. Nessuna visita interna obbligatoria generata. |
| Identità e dismissione | Unicità sede+matricola informale per attrezzature; sede+matricola per accessori, in spazi distinti come nelle due tabelle Garda. Il gruppo non cambia nella modifica ordinaria. Beni dismessi conservati, esclusi dagli elenchi attivi. |
| Date Garda | Conservata la possibilità di uno stato iniziale senza verbale. Non sostituito il ricalcolo per ultima verifica effettuata/data rilascio con un automatismo ultima+anni. Quell'algoritmo DM sarà completato nel suo flusso. |
| R73 / R97 | Nessuna regola Garda dichiarata eliminata o derogata. Funzioni non ancora realizzate rimangono nel perimetro; non equivalgono a omissioni approvate. Excel alla fine. |

Fonti: quattro tabelle `tipi_attrezzature_gvr`, `tipi_attrezzature`, `id_specifiche`, `tipi_attr_id_specifiche` del dump `adsrl`; `cust/_custom.php` per hook/ricostruzione delle date e accessori; rapporti 07, 11, 12, 14–16; registro del documento quadro. Le descrizioni ministeriali sono lo snapshot ricevuto, non una verifica normativa aggiornata.

## 4. Prove eseguite

**133 test passati (121 della base DPR e 12 nuovi del nucleo comune).** Esecuzione su Linux, Python 3.12.14, SQLite, dipendenze della base; risultati XML/testo nel pacchetto. Una segnalazione di deprecazione FastAPI/Starlette già presente non è un fallimento. Non sono state cambiate dipendenze per questo incremento.

I nuovi test controllano: corrispondenza completa dei cataloghi con lo snapshot; classificazioni/associazioni e rollback su errore; unicità nella sede; tubazioni; date CND senza verifica fittizia; camere e somme litri/DN; valvola condivisa; permessi/CSRF/versioni; aggiornamento e cancellazione DPR; scritture ORM e rollback atomico; migrazione da 0010 con offerta/verifiche popolati; backup e ripristino del parco.

La suite completa comprende regressioni DPR di preventivi, documenti/riesami, verifiche e numerazione, VerbalizzAI, finanza/incassi, import, FK/schema, backup e migrazione da 0008. Nei test ordinari i PDF usano lo stub dichiarato dalla suite: non tutti i test producono PDF reali. Le prove marcate `pdf_vero` conservano il proprio comportamento; questo incremento non introduce un nuovo generatore DM né una campagna aggiuntiva di conversioni reali.

**Prova interfaccia DOM + backend HTTP riuscita:** nuovo GVR, ricerca/scelta sede, famiglia/all.7/ID disponibili, camera da 20,5 litri e tubazione DN100 con totale invariato, CND con numero report, associazione PSV e visualizzazione taratura condivisa, modifica della scheda preservando sede/catalogo, elenco delle date. È una prova funzionale con jsdom, non una prova grafica del browser Windows. I comandi `.bat` mantengono CRLF e caratteri compatibili e sono controllati dai test del pacchetto.

L'installazione, la resa grafica e l'uso sul PC Windows dell'utente restano da osservare. PostgreSQL/produzione e migrazione completa di dati reali DM/I&C non sono stati provati.

## 5. Come provarlo in locale

1. Estrarre il pacchetto in una cartella nuova `Gestionale_AD_v0.9.0`.
2. Eseguire `INSTALLA_WINDOWS.bat`, quindi `AVVIA_COLLAUDO_WINDOWS.bat`. Quest'ultimo usa `Dati_Collaudo` nella nuova cartella.
3. Creare un amministratore e una coppia cliente/sede di prova, oppure usare gli strumenti DPR esistenti nel loro archivio dedicato vuoto.
4. Nel menu Parco comune creare SC/SP/GVR o PSV e provare scheda, cataloghi, camere, date, numero report e associazioni. Le classificazioni complete si scelgono dalle voci Garda ricevute.
5. Controllare che un impianto creato dalla scheda DPR appaia nel parco e segua le sue modifiche/date. Gli impianti DPR qui si consultano; si modificano dalla loro scheda.
6. Provare backup e ripristino sull'archivio di collaudo. Per l'aggiornamento di un archivio 0.8 usare soltanto una copia, mantenendo gli allegati del suo backup. Un database 0011 non va riaperto con 0.8.

Questo giro di prove non sospende lo sviluppo del resto del gestionale. Non occorre fornire adesso gli originali S3.

## 6. Lavoro ancora da completare

B1 non è chiuso integralmente: mancano gli attributi tecnici specifici completi e le maschere equivalenti Garda (esenzioni, parametri/attributi SC/SP/GVR/PSV e campi ulteriori), classificazioni/cataloghi ulteriori pertinenti, l'acquisizione quadrata delle tre sorgenti e il raccordo completo delle anagrafiche/provenienze. Il JSON aggiuntivo disponibile nell'API non è una maschera completa di questi dati, né una prova della loro migrazione.

B2–B4 rimangono necessari: offerte DM/EX e tariffe ministeriali/composte; incarichi e aggiornamenti per componente con protezione delle date legate ai lavori; preventivi a punti/sottopunti e attività I&C; report; generatore DM e schede tecniche; INAIL trimestrale con nomi/allegati; raccordo economico e compensi I&C; import esiti Aruba. La finanza DPR esistente non dimostra il completamento degli altri due moduli.

N01–N14 restano invarianti da applicare quando si aggiungeranno i documenti DM/I&C; nessuna nuova convenzione introdotta ora. VerbalizzAI incorporato resta 0.3.32.3, il progetto autonomo/VPS non è stato modificato. L'adattatore dell'ultima versione consolidata resta successivo.

**Prossimo passo:** completare le schede tecniche comuni partendo dagli attributi Garda già mappati, quindi raccordare le righe preventivo e gli incarichi DM/I&C al bene e alle componenti condivise. Non ripartire dal modello Excel né dalle domande astratte IMP-01/02. COES-01 va chiusa prima della convivenza in produzione, senza bloccare le copie di collaudo.
