# NEXUS_DPR: verbali nello stesso PostgreSQL

Documento nato con la rc5 e valido fino alla rc8 (14/10/2026), che non cambia questa parte. È un
**incremento di collaudo**: non sostituisce l'installazione in uso finché i test nativi e una prova su una
copia dei dati non saranno superati.
L'applicazione autonoma verbalizzAI in produzione continua a usare SQLite.

## Confine delle responsabilità

| Funzione | Collocazione nel codice | Criterio |
| --- | --- | --- |
| Clienti, sedi, impianti | `anagrafica`, `beni` | Anagrafiche uniche NEXUS |
| Preventivi, ordini, incarichi, verifiche, riesami | `preventivi`, `verifiche` e moduli comuni | Processi condivisi DPR/DM con regole di ambito |
| Fatturazione, incassi, XML | `finanza` | Servizio unico, sezionali e titolarità configurati per attività |
| Compilazione, revisione, emissione, allegati dei verbali DPR | `verbali` | Regole documentali DPR conservate, utenti NEXUS |

La nuova migrazione `0029` aggiunge nel **medesimo database PostgreSQL** lo
schema `verbali`, con oggetti, documenti binari, cronologia e metadati. Il
formato dei backup `.adbackup.zip` resta leggibile; gli identificatori,
revisioni e documenti sono confrontati con la copia sorgente. Il registro
utenti VerbalizzAI viene conservato solo come storico: login e autorizzazioni
operativi restano quelli di NEXUS. Le copie immutabili dei documenti nella
cartella dati sono ausiliarie; il contenuto autoritativo è nel database.

I backup PostgreSQL includono lo schema `verbali` nel dump; nel collaudo con
questo backend il ripristino non applica nuovamente un backup separato dei
verbali. Con il backend SQLite rc3, il meccanismo precedente resta invariato.

## Test su Windows, senza toccare `nexus_locale`

1. Estrarre questa versione in una **cartella nuova**; non cancellare rc3 o
   i backup. In `config.json` lasciare `verbali_postgresql` assente o `false`.
2. Eseguire `INSTALLA_WINDOWS.bat`. Per i test aggiungere le dipendenze con
   `& ".\.venv\Scripts\python.exe" -m pip install -r requirements-sviluppo.txt`.
3. Aprire PowerShell nella cartella della versione e impostare
   `NEXUS_TEST_POSTGRESQL_ADMIN_URL` come nel collaudo rc3. La fixture crea
   database chiamati `nexustest_<uuid>` e li elimina alla fine.
4. Eseguire
   `& ".\.venv\Scripts\python.exe" -m pytest -vv tests/postgresql/test_verbali_pg.py --timeout=240`.
   Attendere l'esito finale: i cinque test devono risultare **passed**, non
   `skipped`. La sola comparsa di puntini non significa che siano finiti.

Il primo test migra un archivio fittizio completo, confronta oggetti,
documenti e cronologia, verifica che una seconda importazione sia bloccata,
scrive una revisione e controlla conflitto/rollback e backup. Il secondo
rifiuta copie senza documenti. Il terzo avvia NEXUS con backend PostgreSQL dei
verbali senza creare `archivio.sqlite`. Gli altri due verificano che i soli
modelli iniziali non autorizzino l'attivazione se esiste uno SQLite storico,
e che un archivio SQLite modificato dopo l'importazione blocchi l'avvio.

## Passaggio futuro dei dati reali

Fermare le scritture su verbalizzAI, esportare un **backup completo con
documenti**, conservare sia quello sia un backup NEXUS prima della prova.
Importare una sola volta nell'archivio PostgreSQL DPR ancora vuoto con
`python -m gestionale.moduli.verbali.importa_postgresql COPIA.adbackup.zip`.
Solo dopo i confronti, le prove operative e il ripristino collaudato attivare
`"verbali_postgresql": true` in una configurazione di prova. Non importare
nel database `nexus_locale` operativo durante il primo collaudo.

## Da completare prima della messa in produzione DPR

- Test nativi sul PostgreSQL Windows e sul backup dei dati reali in un
  database di prova; ripristino integrale e verifica di allegati, revisioni,
  numerazione, invio e riesame con utenti distinti.
- Congelamento del vecchio archivio alla migrazione finale e riconciliazione
  con le verifiche NEXUS (identificativi, PDF, stato e scadenze).
- Incorporare la compilazione dei verbali nel percorso della verifica DPR,
  eliminando la pagina separata `/verbali` solo dopo le prove funzionali.
- Rendere PostgreSQL dei verbali la configurazione predefinita dopo il
  collaudo; fino ad allora l'attivazione è esplicita.
