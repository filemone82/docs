# NEXUS 0.18.0 rc8: passaggio di consegne tecnico

**Data:** 14 ottobre 2026. **Base:** `NEXUS_0.18.0_rc7_2026-10-14.zip` (SHA-256 `3d43333a…7c1e`), schema Alembic **0029** invariato: la rc8 **non ha migrazioni**.
**Stato:** collaudo, non è una release per la produzione.
**Autore:** Claude, su decisioni di Federico. Il documento completo, con le decisioni in testo letterale, è `PASSAGGIO_INTEGRALE_NEXUS_DPR_2026-10-14_rev4.md`, presente in questo pacchetto: leggerlo per primo. Questo file elenca solo le modifiche tecniche.

## Regole valide per chi prosegue

- **Conferma preventiva** (Federico, 14/10/2026): prima di modificare codice o logiche esistenti, chiedere conferma con un esempio prima/dopo.
- **R111:** `gestionale/terzi/verbalizzai/` (motore VerbalizzAI 1.0.1) non si modifica; lo controlla `tests/test_verbalizzai_identico.py`. Tutte le integrazioni passano dal ponte: `moduli/verbali/{api,servizio,scheda}.py`, `static/js/ponte_verbali.js`, `static/css/ponte_verbali.css`.
- **Vincolo di Federico sul punto 4:** nessuna alterazione della generazione dei verbali né dello storico (verbali emessi, revisioni, fotografie).

## Modifiche (7 commit sulla rc7)

| # | Cosa | File principali | Test |
|---|---|---|---|
| 1 | **Barra di navigazione in alto** (D3) al posto del menu laterale. Stesse sezioni R117, tendine, attività e utente sempre visibili, «☰ Menu» sotto i 1180 px. Barra in un template e in uno stile autonomi, condivisi con la pagina del verbale. | `templates/_barra.html`, `templates/base.html`, `static/css/barra.css`, `static/js/barra.js` (tendine, attività, «Esci»; prima erano in `base.js`), `static/css/stile.css` | `tests/test_menu_attivita.py`: il gruppo della pagina ora è `data-attivo` senza `open` |
| B1 | **Anno della data registrata:** solo anno corrente, precedente o successivo (registrazione, programmazione, data del verbale DPR). Codice del verbale unico (VP e VS condividono il progressivo annuo). | `moduli/verifiche/servizio.py`: `anno_ammesso`, `_numero_libero` | `tests/test_numerazione_verbali_rc8.py` |
| B2 | **Numero del verbale assegnato da NEXUS:** nella bozza non si modifica a mano. A ogni salvataggio e a ogni riapertura torna quello della verifica. Se cambia l'anno della data del verbale, diventa il primo libero di quell'anno e il vecchio resta un buco annotato nel registro (`impostazioni`, chiave `verifiche.numeri_lasciati`). Periodica ↔ Straordinaria cambia solo il prefisso. Anteprima ed emissione sono bloccate se il numero non coincide o se l'anno non è ammesso. Le revisioni conservano il numero. | `verifiche/servizio.py`: `allinea_numero`; `verbali/servizio.py`: `numero_nella_bozza`, `allinea_bozza_in_salvataggio`, `controlla_numero_prima_di_emettere`; `verbali/api.py`: aggancio su `draft/save`, `review/preview`, emissione; `ponte_verbali.js`/`.css` | idem |
| 2 | **Pagina del verbale dentro NEXUS:** barra NEXUS in alto e menu laterale di VerbalizzAI nascosto. Una striscia mostra la verifica di provenienza, il suo stato, il passo successivo e «← Torna alla verifica»; dopo l'emissione il ritorno diventa il pulsante principale. Senza verbale aperto, la striscia mostra le viste «Verbali emessi · Bozze · Clienti e impianti». Nuovo endpoint `GET /api/verbali/{id}/verifica`. La voce di menu resta «Verbali» (scelta di Federico). | `verbali/api.py` (`_indice`, `pagina`, `verifica_del_verbale`), `web/pagine.py::barra_html`, `ponte_verbali.js`, `ponte_verbali.css` | `test_d3_pagina_del_verbale_dentro_nexus` |
| 3 | **Firme in un solo punto:** nella scheda del tecnico (profilo e Gestione › Firme dei verificatori, `/firme`; `/firme-dm` resta come indirizzo precedente) «Firma DPR» accanto a «Firma DM». La firma DPR si salva nell'archivio dei verbali con le funzioni del motore (`set_signature`/`remove_signature`/`signature_image`) e una traccia nel registro NEXUS. Il collegamento «Firme dei verificatori» di VerbalizzAI esce dalla Configurazione DPR. | `verbali/api.py` (`/api/firme/dpr/{utente_id}`…), `static/js/schede.js::datiTecnico`, `static/js/firme_dm.js`, `templates/configurazione.html`, `web/pagine.py` | `test_punto3_firma_dpr_nella_scheda_del_tecnico`, `tests/test_collaudo_016.py` aggiornato |
| 5 | **Destinazioni dei documenti** (D2) in Gestione › Configurazione: cinque percorsi **del server** (verbali DPR, verbali DM, schede DM, PDF fatture, XML fatture), salvati nel database con registro, con pulsante «Prova» (esistenza e scrittura). La copia automatica è attiva solo per il DM (come prima), ora dalle destinazioni; le schede DM vanno nella loro destinazione se impostata. `cartella_verbali_dm` di config.json resta il valore iniziale. DPR, PDF e XML: destinazione impostabile, copia **non ancora attiva**. | `moduli/documenti/destinazioni.py`, `destinazioni_api.py`, `dm/documenti.py::salva_in_cartella`, `static/js/destinazioni.js`, `app.py`, `web/pagine.py` | `tests/test_rc8_configurazione.py` |
| 6 | **Dati della società e pagamenti** in Configurazione (`/dati-societari`): dati fiscali dell'emittente e modalità di pagamento con le regole delle scadenze, tolti dalla pagina Fatture. Gli avvisi della bozza dicono «Società emittente AD» o «Cliente», con pulsante verso la sezione giusta (`mancanti_dettaglio`) e ritorno alla bozza (`?ritorno=/fatture?apri=N`). Chi non ha `sistema.impostazioni` vede «chiedi a chi gestisce la Configurazione». | `finanza/servizio.py::mancanti_dettaglio`, `static/js/finanza.js`, `templates/finanza.html`, `static/js/dati_societari.js` | `tests/test_collaudo_016.py` aggiornato, `test_punto6_…` |
| 4 | **Attributi dell'impianto NEXUS nella bozza** (D1): potenza, POD, cabine e sottostazioni (M01, messa a terra) entrano dall'impianto NEXUS **solo nella bozza nuova**, come già cliente, sede e indirizzo. Dopo l'emissione con «Aggiorna la scheda», oltre alla potenza tornano a NEXUS anche cabine e sottostazioni; il POD solo se l'impianto non ne ha e non è di un altro impianto. Bozze aperte, revisioni e verbali emessi non vengono toccati. | `verbali/servizio.py::attributi_nexus`, `verbali/scheda.py::_altri_attributi` | `test_punto4_*` (3 test, compreso il non-regressione su bozze aperte e archivio) |

## Prove eseguite davvero

Ambiente cloud Linux, Python 3.13, librerie installate senza rete dal pacchetto `librerie_linux.zip` fornito da Federico (stesse versioni di `requirements-sviluppo.txt`), PostgreSQL **16** locale di prova. Federico usa PostgreSQL 18.

| Prova | Esito |
|---|---|
| Suite completa rc7 (base di confronto) | **421 passed**, 0 skipped, 11 subtests, 9 min 38 s (PostgreSQL nativo compreso) |
| Suite completa rc8 | **433 passed**, 0 skipped, 11 subtests, 10 min 34 s (12 test nuovi) |
| `ruff --select F,E9` sui file cambiati | nessun errore (gli errori presenti in altri file sono quelli della rc7) |
| Browser (Chromium headless) su ambiente di prova | barra, tendine, menu stretto, pagina del verbale con striscia, viste dei verbali, campo numero bloccato con cambio d'anno, Firme, Destinazioni, Dati della società: controllati a vista |

**Non provato:** Windows, PostgreSQL 18, dati reali, LibreOffice con i modelli reali in emissione M01 completa dal browser, invii email.

## Da sapere

- Nessuna migrazione: un archivio rc7 (`0029`) si apre con la rc8 senza passi. L'unicità del codice del verbale è controllata dall'applicazione, non con un indice. Un indice avrebbe bloccato gli archivi di collaudo che contengono già il doppione VP/001/26 dell'anno «226»: quel doppione si corregge da solo salvando la bozza con la data giusta.
- I test usano date fisse nel 2026: con il limite «anno corrente ±1» quelli con date 2026 andranno rivisti dal 2028.
- Il limite dell'anno vale per il DPR. Il DM ha la sua registrazione (`dm/tecnico.py`) ed è da allineare se Federico lo chiede.

## Aperto (in ordine)

1. Collaudo di Federico su Windows/PostgreSQL 18: suite completa e prove manuali con gli stessi casi del 14/10.
2. D1-ter: revisione di un preventivo **accettato** quando la potenza rilevata cambia lo scaglione (domande nel documento integrale § 6).
3. Copie automatiche di verbali DPR, PDF e XML nelle destinazioni (nomi dei file da concordare).
4. Scheda tecnica completa modificabile in NEXUS oltre ai quattro campi, e migrazione delle schede al taglio finale (vedi documento integrale § 7.2).
5. Rilievi registrati e non ancora implementati: flusso preventivo → incarico frammentato (§ 3.6), «Programma verifica» con email al cliente (§ 3.7), testi email uniformi per tipo di documento (§ 3.5).
6. Importazione ingecert MariaDB, backup/ripristino, server di collaudo sul VPS, passaggio DPR (§ 4).
