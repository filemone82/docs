# Preventivi, clienti e sedi nel gestionale integrato

Versione 1.0 — 9 ottobre 2026. Riscontro sul codice/database Garda e proposta circoscritta; nessuna nuova migrazione o modifica della logica DM applicata in questo passaggio.

## 1. Esito del controllo

La descrizione dell’utente è corretta nella differenza operativa fra i due applicativi, con una precisazione: **adsrl contiene già sia cliente sia sede nella testata del preventivo**. La sede è obbligatoria e delimita normalmente la selezione delle attrezzature; non sostituisce il cliente come soggetto della testata.

| Relazione | AD_DM / adsrl | AD_DPR / ingecert |
|---|---|---|
| Anagrafica | Cliente → sedi operative → attrezzature SC/SP/GVR. | Cliente → sedi operative → impianti DPR. |
| Testata preventivo | Cliente e sede operativa obbligatori; la sede dipende dal cliente. | Cliente obbligatorio, nessun campo sede operativa nella tabella della testata. |
| Selezione nelle righe | Attrezzatura filtrata sulla sede del preventivo. | Impianto filtrato sul cliente: può appartenere a una sua diversa sede. |
| Fatturazione | Intestatario cliente o terzo pertinente alla fattura; sede non è un autonomo soggetto fiscale. | Stessa distinzione già acquisita; il terzo si sceglie nella fase di fatturazione. |

Fonti: dump del 7 ottobre 2026, DDL `preventivi`, `clienti_sedi_operative`, `attrezzature`/`impianti`; `cust/meta/preventivi.js` e `preventivi_righe.js` di adsrl/ingecert. In adsrl la riga trascina la sede dal preventivo, la presenta come dato letto e filtra `attrezzatura` con `depends_on: sede_operativa`. In ingecert trascina il cliente dal preventivo e filtra `impianto` sul cliente. La sede dell’impianto resta nel collegamento anagrafico e nei dati descrittivi del documento.

Questo dimostra la struttura presente nel backup, non le fasi storiche con cui è stata modificata. Il racconto dell’utente chiarisce la motivazione del cambiamento DPR, ma il backup non consente di ricostruire da solo le versioni precedenti.

## 2. Riscontro quantitativo sugli archivi

Query SQLite in sola lettura sulle copie di staging dei dump, senza eseguire PHP o modificarle:

| Controllo | adsrl | ingecert |
|---|---:|---:|
| Preventivi | 1.849 | 1.009 |
| Righe preventivo | 9.878 | 1.866 |
| Preventivi con attrezzature/impianti di più sedi effettive | 4 | 168 |
| Testate prive di sede operativa | 0 | Campo non presente |
| Testata con sede appartenente a un cliente diverso dal cliente indicato | 1 | Non applicabile alla testata |
| Righe il cui bene appartiene a una sede diversa dalla sede della testata | 32 | Non è un’anomalia: il multisede è previsto |
| Righe DPR con impianto che oggi appartiene a un cliente diverso da quello in testata | Non conteggiato nello stesso controllo | 5 |

I 4 casi DM multisede e le 32 righe non dimostrano che la maschera ordinaria permetta liberamente il multisede. Possono derivare da percorsi/import, cambi anagrafici o interventi storici: la causa non è stabilita. Analogamente le 5 righe DPR non vengono qualificate automaticamente come errori dell’operatore. Sono discrepanze fra collegamenti correnti da riportare nell’importazione, preservando l’originale.

Ne consegue che un importer non deve assumere rigidamente “ogni riga DM ha sempre la sede della testata” e correggere il bene di conseguenza. Né deve assumere che tutte le testate/riferimenti di cliente coincidano con l’anagrafica corrente.

## 3. Struttura comune consigliata

**Conservare l’anagrafica cliente → sedi → beni.** È già corretta e utile alle tre attività. Uniformare invece la rappresentazione commerciale, distinguendo intestatario, sede di contesto e oggetto delle righe:

| Elemento | Significato |
|---|---|
| Cliente del preventivo | Soggetto committente/intestatario della proposta. Obbligatorio in testata. |
| Sede di riferimento del preventivo | Sede operativa pertinente all’offerta, contatti e contesto. Conservata sugli storici DM/I&C; facoltativa nel nucleo comune, con vincoli del modulo. |
| Bene della riga | Impianto DPR, attrezzatura DM o accessorio pertinente; identifica la prestazione e la sua sede. |
| Sede della prestazione | Ricavata dal bene per i nuovi lavori pertinenti e conservata nella fotografia commerciale; presente anche per una riga che riguarda una sede senza un bene. |
| Fotografia del documento | Cliente, sedi, beni, descrizioni e prezzi pertinenti alla versione emessa, senza riscrittura per modifiche dell’anagrafica corrente. |

Una struttura comune consente il preventivo DPR del Comune con righe per scuola, municipio e palestra. Nell’uso DM ordinario si sceglie una sede e si propongono le sue attrezzature, come in Garda. Non si obbliga l’operatore DM a un nuovo lavoro di selezione multisede.

**Distinguere capacità del database e regola operativa:** il nucleo può conservare più sedi sulle righe senza imporre un FK di uguaglianza con l’unica sede della testata. Questo serve anche a importare gli storici effettivi. L’abilitazione ordinaria di nuove offerte DM multisede sarebbe invece un ampliamento funzionale del filtro Garda: non è approvata dalla sola richiesta di database comune. Per ora si conserva il comportamento DM per sede. Se l’utente vuole il multisede anche DM, si valuteranno esplicitamente presentazione delle sedi, contatti/invio, trasferte/contributi e altri effetti pertinenti.

Lo schema progettuale v0.3 **già prevede** cliente obbligatorio e sede opzionale in `preventivi`, sede/bene nelle righe e mappe delle origini. Non è necessario sostituire completamente quel disegno. Il backend applicativo 0.9.1 non implementa ancora le offerte DM comuni: queste relazioni saranno attuate nel raccordo, senza presentare il solo DDL come funzione disponibile.

Resta la separazione degli ambiti/sezionali: un database comune non implica un’unica offerta DM+DPR né una sola numerazione. I&C mantiene punti/sottopunti e prezzi singoli/a corpo, secondo le regole già analizzate.

## 4. Conseguenze dell’importazione

Non c’è un impedimento strutturale: i dati Garda contengono i collegamenti necessari. Si tratta di un mapping conservativo:

1. Mappare clienti, sedi e beni con identità/provenienza stabili, senza fusione per sola omonimia o uguaglianza di un codice commerciale.
2. Importare ogni preventivo come **una testata**, conservando cliente, serie/numero letterali, stato, importi e riferimento originario. Nel DM/I&C conservare la sede di testata; nel DPR non inventarne una unica.
3. Importare ogni riga con il suo bene e la relativa sede/provenienza, mantenendo descrizioni e valori storici. Nel caso di anagrafiche correnti discordanti mantenere l’evidenza originaria e segnalare l’anomalia: non sostituire silenziosamente il cliente o spostare l’attrezzatura.
4. Preservare incarichi/verifiche, fatture, allegati, accettazioni/riesami e i loro agganci. La ristrutturazione tecnica non genera nuovi lavori o documenti.
5. Verificare quadratura di testate/righe, importi, codici, FK, numero di lavori e campioni di documenti. Importi delle offerte accettate/emesse non vengono ricalcolati.

**Non dividere le vecchie offerte multisede e non unire automaticamente le vecchie offerte DM per sede.** Si conserva il documento realmente fatto. Il nuovo modello permette un comportamento futuro senza riscrivere la storia.

La sede DM ha effetti oltre al filtro: `gi_rpt_preventivi_close_html_after` ricava l’email di proposta dalla sede operativa. Questo contesto va mantenuto nell’import e nelle offerte DM ordinarie; rendere opzionale la sede nel nucleo non autorizza a sostituire sempre quel destinatario con una generica email cliente. Nessuna email è inviata in questo controllo.

Quando un bene è stato spostato o l’anagrafica è cambiata, la sede corrente non dimostra automaticamente la sede della prestazione storica: si preservano testata e dati copiati disponibili, segnalando ciò che non si può ricostruire. I contatti correnti non ricostruiscono da soli un indirizzo storico mancante. La ristrutturazione non recupera i PDF S3 assenti; importare riferimenti non dimostra di averne importato il contenuto. Ciò non blocca le prime prove del codice sui dati disponibili.

## 5. Richiesta sul prossimo codice

L’utente precisa che la fattura è al cliente e chiede che **il prossimo codice sia già integrato con DM**. Registrata R99: prossimo rilascio funzionale con DPR e DM effettivamente raccordati, non un ulteriore prototipo generico di beni presentato come DM. I&C rimane nell’architettura e nel perimetro successivo; INAIL resta essenziale per DM, non un dettaglio eliminabile.

La correzione dei duplicati DPR 0.8.1/0.9.1 era già stata realizzata e collaudata prima di questa indicazione. Viene conservata come manutenzione e base tecnica: **non costituisce il prossimo rilascio DM richiesto**. Non promettere un backend completo sulla base delle sole maschere.

Ordine di lavoro: completamento schede GVR/SC-SP e vincoli Garda (rapporto 19), offerte/righe/lavori DM sui beni comuni mantenendo contesto sede e tariffazione, documenti/INAIL e raccordo amministrativo secondo il perimetro. Presentare stato e prove per funzione, senza aggiungere un nuovo gestionale autonomo o duplicare i dati.

## 6. Stato delle scelte

- **Confermato e riscontrato:** struttura anagrafica, preventivo multisede DPR, normale filtro DM per sede, fattura cliente/terzo nella fase di fatturazione.
- **Proposta tecnica coerente con lo schema già disegnato:** testata commerciale comune con cliente e sede di contesto, righe legate ai beni/sedi, fotografie e origini; non ancora nuovo codice DM applicato.
- **Non acquisito:** consenso a offrire ordinariamente nuove offerte DM multisede. Finché non scelto si conserva il comportamento Garda; il database non deve però perdere gli storici discordanti già esistenti.
- **Eseguito qui:** lettura sorgenti/DDL e query in sola lettura sugli staging, aggiornamento della documentazione. Nessuna importazione completa, modifica dei dump o test operativo del nuovo flusso DM.


## 7. Rischi se si conservano i due comportamenti attuali

L’utente considera la ristrutturazione cliente/sede/righe, teme la coerenza con gli indirizzi e chiede cosa rischi mantenendo la differenza DM/DPR. Non sceglie definitivamente una nuova regola multisede DM.

**Raccomandazione:** conservare gli usi attuali nel nucleo comune. La catena cliente→sedi→beni è corretta e non richiede un altro livello anagrafico. Nel modello commerciale comune distinguere cliente intestatario e sede di contesto; nei servizi applicare il filtro DM per sede e quello DPR per cliente. Non servono due database o due copie della stessa anagrafica per sostenere questa differenza.

| Aspetto | Rischio effettivo / trattamento |
|---|---|
| DM rimane per sede | Resta il limite commerciale noto: per nuove attività su sedi diverse si fanno normalmente più offerte DM. Non è un difetto nuovo dell’integrazione. Non abilitare multisede senza valutazione. |
| Unico backend con due filtri | Piccola diversità di comportamento per ambito da rendere esplicita nel servizio; non impone due gestionali o due backend separati. |
| Indirizzi | Sono attributi della sede; il bene vi è collegato. Non farli ridigitare per ogni attrezzatura/impianto. L’offerta mostra quelli delle sedi pertinenti. |
| Documenti emessi | Fotografare i dati pertinenti all’emissione, secondo il requisito già acquisito; non rigenerare un’offerta storica usando automaticamente l’indirizzo corrente. |
| Importazione | Riferimenti disponibili e mapping conservativo. Sono necessarie quadrature e gestione delle discrepanze, non una riscrittura della storia. La conservazione della sede DM facilita importazione, contatti e documenti. |
| Aggiunta futura del multisede DM | Il nucleo cliente+sede di contesto+righe per bene/sede già predisposto evita una futura riscrittura dell’anagrafica. Resteranno da modificare filtri, layout e regole operative pertinenti dopo consenso. |

L’indirizzo corrente si ricava tramite sede; la fotografia commerciale è intenzionalmente storica e non è una seconda anagrafica da mantenere sincronizzata. Per gli importati la fotografia va ricostruita **solo con le informazioni disponibili**: senza documenti o dati copiati non si può inventare l’indirizzo effettivo di anni prima.

L’import non è dichiarato già completato o privo di ogni anomalia: i conteggi della sezione 2 mostrano perché va controllato. Le 32 righe DM discordanti e le altre discrepanze richiedono conservazione/segnalazione, non lo spostamento automatico dell’attrezzatura nella sede della testata.

Questo indirizzo è una raccomandazione motivata, non consenso acquisito a cambiare i flussi Garda. Il prossimo codice funzionale resta DPR+DM secondo R99; non si apre un nuovo progetto separato.
