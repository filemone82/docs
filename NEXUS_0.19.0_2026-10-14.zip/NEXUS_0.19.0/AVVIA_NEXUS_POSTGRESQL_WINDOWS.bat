@echo off
setlocal
cd /d "%~dp0"
title NEXUS - collaudo PostgreSQL locale
set "NEXUS_LAUNCHER_SELF=%~f0"
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; $nexusLines=[System.IO.File]::ReadAllLines($env:NEXUS_LAUNCHER_SELF); $nexusStart=[Array]::IndexOf($nexusLines,'# NEXUS_POWERSHELL'); if($nexusStart -lt 0){throw 'Avvio incompleto'}; & ([scriptblock]::Create(($nexusLines[($nexusStart+1)..($nexusLines.Length-1)] -join [Environment]::NewLine)))"
set "NEXUS_EXIT_CODE=%ERRORLEVEL%"
echo.
if not "%NEXUS_EXIT_CODE%"=="0" echo Avvio terminato con errore. Conserva il messaggio qui sopra.
pause
exit /b %NEXUS_EXIT_CODE%
# NEXUS_POWERSHELL
$ErrorActionPreference = 'Stop'
$nexusExitCode = 1
try {
    $nexusProgramDir = Split-Path -Parent $env:NEXUS_LAUNCHER_SELF
    Set-Location -LiteralPath $nexusProgramDir
    $nexusPython = Join-Path $nexusProgramDir '.venv\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $nexusPython)) {
        throw 'Python del progetto non trovato: metti questo file accanto a INSTALLA_WINDOWS.bat ed esegui prima l installazione.'
    }
    if (-not (Test-Path -LiteralPath (Join-Path $nexusProgramDir 'gestionale'))) {
        throw 'Cartella gestionale non trovata: sposta questo avvio nella cartella del programma.'
    }
    $nexusPgBin = 'C:\Program Files\PostgreSQL\18\bin'
    if (-not (Test-Path -LiteralPath (Join-Path $nexusPgBin 'pg_dump.exe')) -or
        -not (Test-Path -LiteralPath (Join-Path $nexusPgBin 'pg_restore.exe'))) {
        throw 'Utility PostgreSQL 18 non trovate nel percorso standard. Segnala il percorso effettivo prima di proseguire.'
    }
    $nexusConfigPath = Join-Path $nexusProgramDir 'config.postgresql.collaudo.json'
    if (-not (Test-Path -LiteralPath $nexusConfigPath)) {
        $nexusNewConfig = @{
            cartella_dati = (Join-Path $nexusProgramDir 'Dati_PostgreSQL_Collaudo')
            indirizzo = '127.0.0.1'
            porta = 8463
            apri_browser = $true
            https = $false
            backup_automatico = $false
            cartella_verbali_dm = ''
        } | ConvertTo-Json
        [System.IO.File]::WriteAllText($nexusConfigPath, $nexusNewConfig, [System.Text.UTF8Encoding]::new($false))
    }
    $nexusConfig = Get-Content -LiteralPath $nexusConfigPath -Raw | ConvertFrom-Json
    if ($nexusConfig.database_url) { throw 'La connessione deve essere fornita dall avvio, senza salvarla in config.json.' }
    $nexusDataDir = $nexusConfig.cartella_dati
    if (-not $nexusDataDir) { $nexusDataDir = Join-Path $nexusProgramDir 'Dati_PostgreSQL_Collaudo' }
    if (-not [System.IO.Path]::IsPathRooted($nexusDataDir)) { $nexusDataDir = Join-Path $nexusProgramDir $nexusDataDir }
    $env:GESTIONALE_CONFIG = $nexusConfigPath
    $env:GESTIONALE_CARTELLA_DATI = $nexusDataDir
    $env:GESTIONALE_PG_BIN = $nexusPgBin
    Write-Host ''
    Write-Host 'NEXUS - collaudo locale PostgreSQL 18'
    # 0.19: database a scelta (Invio = nexus_locale), per collaudare su una copia ripristinata con pg_restore
    $nexusDb = Read-Host 'Database (premi Invio per nexus_locale)'
    if (-not $nexusDb) { $nexusDb = 'nexus_locale' }
    if ($nexusDb -notmatch '^[a-z0-9_]+$') { throw 'Nome del database non valido: solo lettere minuscole, cifre e trattino basso.' }
    Write-Host ('Database: ' + $nexusDb + ' | Utente: nexus_locale | Server: 127.0.0.1:5432')
    Write-Host ('Documenti e archivio del modulo: ' + $nexusDataDir)
    Write-Host 'Inserisci la password PostgreSQL del ruolo nexus_locale.'
    $nexusSecurePassword = Read-Host 'Password' -AsSecureString
    $nexusCredential = [System.Net.NetworkCredential]::new('', $nexusSecurePassword)
    if (-not $nexusCredential.Password) { throw 'Password vuota: riapri il file e inserisci la password del ruolo nexus_locale.' }
    $nexusEncodedPassword = [uri]::EscapeDataString($nexusCredential.Password)
    $env:GESTIONALE_DATABASE_URL = "postgresql+psycopg://nexus_locale:${nexusEncodedPassword}@127.0.0.1:5432/${nexusDb}"
    Remove-Variable nexusSecurePassword, nexusCredential, nexusEncodedPassword
    Write-Host 'Avvio di NEXUS. Lascia aperta questa finestra; per arrestare premi Ctrl+C.'
    & $nexusPython -m gestionale
    $nexusExitCode = $LASTEXITCODE
} catch {
    Write-Host ''
    Write-Host ('ERRORE: ' + $_.Exception.Message) -ForegroundColor Red
} finally {
    Remove-Item Env:GESTIONALE_DATABASE_URL -ErrorAction SilentlyContinue
    Remove-Item Env:NEXUS_TEST_POSTGRESQL_ADMIN_URL -ErrorAction SilentlyContinue
    Remove-Variable nexusSecurePassword, nexusCredential, nexusEncodedPassword -ErrorAction SilentlyContinue
}
exit $nexusExitCode
