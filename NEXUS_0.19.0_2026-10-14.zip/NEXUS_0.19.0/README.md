# NEXUS 0.19.0 — VerbalizzAI dentro NEXUS

**Stato corrente (14/10/2026):** collaudo, schema **0030**. Verbali sempre nello stesso PostgreSQL (archivio SQLite da migrare con `MIGRA_VERBALI_POSTGRESQL_WINDOWS.bat`), strumenti DPR, modelli Word dei verbali, testi delle email e registro unico in NEXUS; tutto quanto della rc8. Collaudare su una **copia** del database (procedura in `PASSAGGIO_CONSEGNE_NEXUS_0.19.0.md`). Leggere **per primo** `PASSAGGIO_INTEGRALE_NEXUS_DPR_2026-10-14_rev5.md`. Le note seguenti sono storiche; per rc4–rc8 vedere i rispettivi `PASSAGGIO_CONSEGNE_NEXUS_0.18.0_rcN.md`.

## Stato precedente: rc3

**Stato corrente:** la migrazione 0028 amplia i tre campi testuali GVR prima di importare i cataloghi DM, preservando integralmente le descrizioni Garda. La rc2 si arrestava perché la baseline PostgreSQL limitava i campi a 20 caratteri. Leggere `COLLAUDO_POSTGRESQL_RC3.md` prima di ripetere l'avvio. La suite PostgreSQL nativa deve ancora essere rieseguita su Windows; VerbalizzAI incorporato continua per ora con il proprio SQLite.

Le note della rc2 e precedenti sono storiche.

## Stato precedente: rc2

**Stato corrente:** schema Alembic 0028. La migrazione aggiunge al PostgreSQL i cataloghi DM omessi dalla baseline 0027; non altera i dati di clienti e sedi già immessi. I test nativi devono ancora essere ripetuti sul PostgreSQL 18 locale di Federico prima di considerare completato il collaudo. Leggere `COLLAUDO_POSTGRESQL_RC2.md` per aggiornare l'installazione senza cambiare l'archivio. VerbalizzAI incorporato usa ancora un archivio SQLite separato: il suo porting PostgreSQL rimane aperto.

Le note della rc1 e delle versioni precedenti sono conservate qui sotto come documentazione storica.

## Stato precedente: rc1

**Stato corrente:** correzioni 0.16.1 integrate nella 0.17.0, con C17–C28 mantenuti. PostgreSQL predisposto, collaudo nativo da completare: non è una dichiarazione di prontezza per la produzione.

Leggere `RIPRESA_NEXUS_0.18.0_rc1.txt`, `MIGRAZIONE_0.18.0_rc1.md` e il documento 49. Modello e schema SQLite restano compatibili con 0027; PostgreSQL parte dalla baseline 0027 congelata. L'importazione definitiva resta dai tre MariaDB Garda al lancio.

Le sezioni seguenti conservano la descrizione della base ricevuta 0.17.0 come contesto storico; per lo stato del porting prevalgono i documenti della 0.18.0 rc1.

Correzioni del collaudo C17–C26 e divieto di riesaminare il proprio verbale (C28), sulla base consegnata 0.16.0. Database principale SQLite, schema Alembic **0027 invariato**. VerbalizzAI **1.0.1 rc2 invariato**. PostgreSQL e importazione completa MariaDB Garda sono il passo successivo approvato, non implementati in questa versione.

Leggere prima `MIGRAZIONE_0.17.0.md`, poi `documentazione/44_Differenze_0.17.0_2026-10-13.md` e `documentazione/45_Ripresa_NEXUS_0.17.0_2026-10-13.md`. Per proseguire con un'altra istanza LLM: documento 45, documento 46 (PostgreSQL/Garda), documento 47 (testi delle richieste), e risultati effettivi in `report_collaudo/0.17.0/`.

## Installazione e avvio

Python 3.12 o successivo; dipendenze applicative in `requirements.txt`, collaudo in `requirements-sviluppo.txt`. LibreOffice è richiesto per conversioni Word/PDF. Seguire `INIZIA_QUI_WINDOWS.md` e `README_INSTALLAZIONE.md` per i comandi e la scelta della cartella dati. I documenti storici riportano lo stato delle rispettive versioni: il riferimento corrente è questo README e il documento 45.

## Cambiamenti visibili

- Icone filtro, cancella e nascondi sulle colonne; operatori testo e periodi date inclusivi con scelte rapide.
- Gruppi Scadenze per cliente DPR / sede DM, ordinati per prima scadenza del risultato filtrato; date crescenti al loro interno. Attrezzature ordinate per prossima scadenza. Il raggruppamento visualizzato resta relativo alla pagina, il criterio di urgenza usa l'intero risultato filtrato.
- Filtri di lavoro, strumenti della vista e azioni sulle selezionate in zone distinte, con conteggio e motivi di indisponibilità.
- RC: selezione cumulativa dei requisiti, deflag singoli, stato parziale. Esito scelto manualmente, controlli conformità e storico conservati.
- Righe accessibili dagli elementi collegati di un solo preventivo DPR/DM; il riferimento resta attivo con Tutte, Azzera, viste ed Excel. Nessun elenco globale.
- RT DPR gestisce impianti DPR; RT DM attrezzature e accessori DM. I ruoli comuni restano regolati dai permessi assegnati.
- Scheda Utente: Salva e Salva e chiudi salvano insieme anagrafica e dati tecnici. La firma aggiorna la versione senza perdere la bozza. Restano i conflitti reali tra sessioni.
- PDF dei verbali: errori distinti, controlli sul Word prima della conversione e validazione strutturale del PDF. Limiti 25 MiB invariati.
- Nessun RT, verificatore o amministratore può riesaminare il proprio verbale, anche in blocco DM.

## Limiti

Versione di sviluppo/collaudo, non sostituto completo di Garda. Il Word reale segnalato da 1,2 MB non è stato fornito: la causa specifica non è dimostrata. Le prove usano archivi sintetici e Linux/Chromium; il collaudo Windows operativo resta necessario. I riesami pregressi non sono stati modificati. Viste salvate preservate; per vedere i nuovi valori iniziali usare Configurazioni → Vista iniziale della versione corrente.
