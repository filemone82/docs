"""rc9 · punto A (Federico, 14/10/2026): con il gestionale su PostgreSQL i verbali stanno sempre nello stesso database.

Un archivio verbali SQLite incorporato rimasto nella cartella dei dati blocca l'avvio finché non è migrato con
`importa_postgresql --dalla-cartella-dati` (backup completo + importazione verificata): nessun verbale si perde.
"""
import pytest

from gestionale.terzi.verbalizzai.storage import Archive


def _prepara(cfg):
    from gestionale.core import migrazioni
    from gestionale.core.db import Archivio
    nexus = Archivio(cfg)
    try:
        migrazioni.aggiorna(nexus.motore)
    finally:
        nexus.chiudi()


def test_verbali_in_postgresql_senza_impostazioni(cfg):
    from gestionale.app import crea_app
    from gestionale.moduli.verbali.archivio import ArchivioVerbaliPostgresql
    assert cfg.verbali_postgresql is None and cfg.verbali_in_postgresql
    app = crea_app(cfg)
    try:
        assert isinstance(app.state.verbali, ArchivioVerbaliPostgresql)
        assert not (cfg.cartella_dati / "verbali" / "archivio.sqlite").exists()
    finally:
        app.state.archivio.chiudi()


def test_archivio_sqlite_di_prova_si_migra_e_poi_si_avvia(cfg):
    from gestionale.app import crea_app
    from gestionale.moduli.verbali.importa_postgresql import backup_dalla_cartella_dati, importa
    _prepara(cfg)
    vecchio = Archive(cfg.cartella_dati / "verbali", cfg.cartella_dati / "verbali" / "backups")
    pid = vecchio.mutate(lambda c: vecchio._put(c, "plant", {"client_name": "Prova", "address": "Via 1", "sede_id": 1, "profiles": {}},
                                                action="plant_new"))
    with pytest.raises(RuntimeError, match="MIGRA_VERBALI_POSTGRESQL_WINDOWS"):
        crea_app(cfg)
    backup = backup_dalla_cartella_dati(cfg)
    assert backup.exists() and backup.parent == cfg.cartella_dati / "backup"
    assert importa(backup, cfg)["oggetti"] >= 1
    app = crea_app(cfg)
    try:
        assert app.state.verbali.get(pid)["data"]["client_name"] == "Prova"
    finally:
        app.state.archivio.chiudi()


def test_registro_dei_verbali_si_legge_anche_da_postgresql(cfg):
    """rc9 · punto F: il registro unico legge le operazioni del motore anche dallo schema «verbali» di PostgreSQL."""
    from gestionale.app import crea_app
    app = crea_app(cfg)
    try:
        vz = app.state.verbali
        vz.set_actor("admin")
        vz.set_mail_texts({"subject": "Verbale {numero}", "body": "Allegato.", "signature": "AD"})
        r = vz.oplog()
        assert any(x["action"] == "mail_texts" for x in r["rows"])
    finally:
        app.state.archivio.chiudi()
