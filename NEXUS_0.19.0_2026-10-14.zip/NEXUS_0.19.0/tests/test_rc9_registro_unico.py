"""rc9 · punto F (Federico, 14/10/2026): registro unico.

Nel Registro operazioni di NEXUS una seconda scheda mostra le operazioni sui verbali DPR registrate dal motore
(sola lettura): non serve più aprire il registro di VerbalizzAI.
"""

from __future__ import annotations

from conftest import nuovo_utente
from test_beni import ok


def test_operazioni_sui_verbali_nel_registro_di_nexus(admin, app):
    ok(admin.put("/api/impostazioni/testi-verbali-dpr", {"oggetto": "Verbale {numero}", "testo": "Allegato.", "firma": "AD"}))
    r = ok(admin.get("/api/registro-verbali"))
    riga = next(x for x in r["righe"] if x["azione"] == "mail_texts")
    assert riga["username"] == "federico" and riga["operazione"] and riga["quando"].endswith(("+01:00", "+02:00"))
    assert {"id": "verbali", "nome": "Verbali"} in r["categorie"]
    # filtri: categoria e periodo (giorni italiani)
    assert not ok(admin.get("/api/registro-verbali?categoria=strumenti"))["righe"] or all(
        x["categoria"] == "strumenti" for x in ok(admin.get("/api/registro-verbali?categoria=strumenti"))["righe"])
    assert ok(admin.get("/api/registro-verbali?al=2000-01-01"))["righe"] == []
    assert admin.get("/api/registro-verbali?dal=ieri").status_code == 400
    # la pagina del registro ha la seconda scheda
    pagina = admin.get("/registro").text
    assert 'data-scheda="verbali"' in pagina and "Operazioni sui verbali DPR" in pagina


def test_registro_verbali_richiede_il_permesso_del_registro(admin, app):
    tecnico = nuovo_utente(admin, app, "luca", "tecnico")
    assert tecnico.get("/api/registro-verbali").status_code == 403
