"""rc9 · punto E (Federico, 14/10/2026): testi delle email per tipo di documento in Configurazione.

Verbali DPR (prima nel menu di VerbalizzAI) e verbali DM (prima fissi nel programma) accanto a quelli dei preventivi.
"""

from __future__ import annotations

from test_beni import ok
from test_dm_documenti import effettua, generata, registrata, sede_dm  # noqa: F401
from test_dm_tecnico import salva


def test_testi_verbali_dpr_in_configurazione(admin, app):
    d = ok(admin.get("/api/impostazioni/testi-verbali-dpr"))
    assert "{numero}" in d["testi"]["subject"] and any(c["campo"] == "prossima_verifica" for c in d["campi"])
    r = ok(admin.put("/api/impostazioni/testi-verbali-dpr", {"oggetto": "Verbale {numero} – {cliente}", "testo": "Spett.le {cliente},\nallegato.",
                                                             "firma": "AD S.r.l."}))
    assert r["testi"]["subject"] == "Verbale {numero} – {cliente}"
    assert app.state.verbali.mail_texts()["body"] == "Spett.le {cliente},\nallegato."     # è il testo che usa il motore all'invio
    assert admin.put("/api/impostazioni/testi-verbali-dpr", {"oggetto": "", "testo": "x"}).status_code == 400


def test_testi_verbali_dm_configurabili(admin, sede, app):
    d = ok(admin.get("/api/dm/impostazioni/testi-verbali"))
    assert d["testi"]["oggetto"] == "Verbale {numero} — {cliente}"
    ok(admin.put("/api/dm/impostazioni/testi-verbali", {"oggetto": "Verbale DM {numero} del {data}", "testo": "Gentile {cliente},\nin allegato il verbale.",
                                                         "firma": "Ufficio DM"}))
    v, _a, _ = registrata(admin, sede)
    v = ok(salva(admin, v, data_rilascio="2026-08-01", date={"funz": "2028-07-31"}))
    ok(effettua(admin, generata(admin, v)))
    b = ok(admin.get(f"/api/dm/incarichi/{v['id']}/email"))
    assert b["oggetto"] == f"Verbale DM {v['codice_verbale']} del 01/08/2026" and b["testo"].startswith("Gentile ") and b["testo"].endswith("Ufficio DM")
    assert admin.put("/api/dm/impostazioni/testi-verbali", {"oggetto": "a\nb", "testo": "x"}).status_code == 400
