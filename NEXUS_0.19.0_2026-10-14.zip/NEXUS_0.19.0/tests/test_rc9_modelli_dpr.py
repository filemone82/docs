"""rc9 · punto D (Federico, 14/10/2026): modelli Word dei verbali DPR in Gestione › Configurazione › Modelli di NEXUS.

Si usano le funzioni del motore: il nucleo documentale non cambia. Un modello nuovo vale per le bozze nuove; i verbali
emessi conservano il modello con cui sono nati; si elimina solo un modello mai usato.
"""

from __future__ import annotations

from pathlib import Path

MODELLO_M02 = Path(__file__).parent / "dati" / "M02-PO01_dpr_rev02.docx"


def test_modelli_dpr_elenco_caricamento_e_eliminazione(admin, app):
    m = admin.get("/api/modelli-verbali-dpr").json()["modelli"]
    assert {x["modulo"] for x in m} >= {"M01", "M02", "M03"} and all(x["in_uso"] for x in m if x["modulo"] == "M01")
    prima = {x["id"] for x in m}
    r = admin.c.post("/api/modelli-verbali-dpr", files={"file": ("M02_nuovo.docx", MODELLO_M02.read_bytes(), "application/octet-stream")},
                     headers=admin.h)
    assert r.status_code == 200, r.text
    r = r.json()
    assert r["modulo"] == "M02"
    nuovi = [x for x in r["modelli"] if x["id"] not in prima]
    # lo stesso file già presente non crea un doppione; un file nuovo diventa quello in uso del suo modulo
    if nuovi:
        assert nuovi[0]["in_uso"] and sum(x["in_uso"] for x in r["modelli"] if x["modulo"] == "M02") == 1
    x = next(x for x in r["modelli"] if x["id"] == r["modello"])
    f = admin.get(f"/api/modelli-verbali-dpr/{x['id']}/file")
    assert f.status_code == 200 and f.content[:2] == b"PK"
    assert admin.post(f"/api/modelli-verbali-dpr/{x['id']}/associa", {"tutte": False}).status_code == 200
    if not (x["bozze"] + x["emessi"] + x["altri"] + x["word"]):
        assert admin.delete(f"/api/modelli-verbali-dpr/{x['id']}").status_code == 200
    r = admin.c.post("/api/modelli-verbali-dpr", files={"file": ("x.pdf", b"%PDF", "application/pdf")}, headers=admin.h)
    assert r.status_code == 400
    conf = admin.get("/configurazione").text
    assert 'href="/modelli"' in conf and "Modelli dei verbali DPR e del preventivo" in conf and "vista=templates" not in conf
