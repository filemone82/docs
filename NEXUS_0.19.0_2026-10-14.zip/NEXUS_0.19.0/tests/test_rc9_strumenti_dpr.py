"""rc9 · punto C (Federico, 14/10/2026): strumenti di misura AD_DPR nel modulo Strumenti di NEXUS.

Il motore dei verbali li legge da NEXUS nello stesso formato del suo registro: la bozza propone gli strumenti attivi
assegnati al verificatore; i verbali conservano la loro copia. Il registro proprio di VerbalizzAI si importa una volta.
"""

from __future__ import annotations

from datetime import date

from test_numerazione_verbali_rc8 import _assegnata, _bozza, _registra
from test_verbali import _vz
from test_verifiche import accettato  # noqa: F401  (fixture)

ANNO = date.today().year


def test_strumento_dpr_assegnato_entra_nella_bozza(admin, app, accettato):  # noqa: F811
    io = admin.get("/api/io").json()
    s = admin.post("/api/strumenti/DPR", {"codice": "mt-01", "denominazione": "Misuratore di terra", "costruttore": "HT", "modello": "M1",
                                          "matricola": "123", "data_taratura": f"{ANNO}-01-10", "scadenza_taratura": f"{ANNO + 1}-01-10",
                                          "assegnato_id": io["id"], "stato_operativo": "Attivo"})
    assert s.status_code == 200, s.text
    s = s.json()
    assert s["codice"] == "MT-01" and s["assegnato_id"] == io["id"] and s["attivo"] is True
    assert admin.post("/api/strumenti/DPR", {"codice": "MT-01", "denominazione": "Doppio", "matricola": "999"}).status_code == 400
    fuori = admin.post("/api/strumenti/DPR", {"codice": "MT-02", "denominazione": "Fuori uso", "matricola": "456", "assegnato_id": io["id"],
                                              "stato_operativo": "Fuori servizio"}).json()
    assert fuori["attivo"] is False
    # il motore li vede come prima vedeva il suo registro
    vz = app.state.verbali.all("instrument")
    assert {x["data"]["code"] for x in vz} == {"MT-01", "MT-02"}
    mt = next(x for x in vz if x["data"]["code"] == "MT-01")["data"]
    assert mt["calibration_due"] == f"10/01/{ANNO + 1}" and mt["assigned_to"] == io["nome"] and mt["type"] == "Misuratore di terra"
    # la bozza del verificatore propone solo quello attivo assegnato a lui
    v = _registra(admin, _assegnata(admin, accettato, "scariche"), f"15/10/{ANNO}").json()
    _vid, d, _rev = _bozza(admin, v)
    assert [r["serial"] for r in d["instruments"]] == ["123"] and d["instruments"][0]["auto"] is True
    # il registro proprio del motore non si modifica più da /verbali
    r = _vz(admin, "instrument/save", {"data": {"type": "x", "serial": "1"}})
    assert r.status_code == 403 and "NEXUS" in r.json()["error"]


def test_importazione_dal_registro_di_verbalizzai(admin, app):
    from gestionale.terzi.verbalizzai.storage import Archive
    io = admin.get("/api/io").json()
    vz = app.state.verbali
    for d in ({"code": "R-1", "type": "Multimetro", "serial": "S1", "calibration": "01/02/2026", "calibration_due": "01/02/2027",
               "assigned_to": "Ing. " + io["nome"], "status": "Attivo", "active": True},
              {"code": "R-2", "type": "Pinza", "serial": "S2", "status": "In taratura", "active": False, "assigned_to": "Sconosciuto"}):
        vz.mutate(lambda c, d=d: Archive._put(vz, c, "instrument", d, action="instrument"))
    assert admin.get("/api/strumenti/DPR/registro-verbali").json() == {"da_importare": 2}
    r = admin.post("/api/strumenti/DPR/registro-verbali", {}).json()
    assert r["importati"] == 2 and r["gia_presenti"] == 0 and any("Sconosciuto" in a for a in r["avvisi"])
    assert admin.get("/api/strumenti/DPR/registro-verbali").json() == {"da_importare": 0}
    assert admin.post("/api/strumenti/DPR/registro-verbali", {}).json()["gia_presenti"] == 2   # idempotente
    nexus = {x["data"]["code"]: x["data"] for x in vz.all("instrument")}
    assert nexus["R-1"]["assigned_to"] == io["nome"] and nexus["R-1"]["calibration_due"] == "01/02/2027"
    assert nexus["R-2"]["status"] == "In taratura" and nexus["R-2"]["active"] is False
