"""0.12.5 · R117: menu per attività con le sezioni di Garda; elenchi di attrezzature, valvole e cataloghi."""

from __future__ import annotations

import re

from test_anagrafica import crea_cliente, crea_sede
from test_beni import nuovo, ok


def voci(admin, percorso):
    """Titoli dei gruppi del menu (0.12.8: gruppi richiudibili; i gruppi di una sola voce sono collegamenti diretti)."""
    html = admin.get(percorso).text
    sezioni = re.findall(r'<summary class="nav-sezione">([^<]+)</summary>|<a class="nav-gruppo-unico[^"]*" href="[^"]+"><span class="icona">[^<]*</span>([^<]+)</a>', html)
    return [a or b for a, b in sezioni], html


def test_menu_dm_come_garda(admin):
    sezioni, html = voci(admin, "/attrezzature-gvr")  # una pagina DM porta l'attività AD_DM
    assert sezioni == ["Clienti", "Attrezzature", "Scadenze", "Preventivi", "Verifiche", "Fatture", "Gestione"]
    # 0.12.8 (Federico, 11/10/2026): cataloghi DM in una schermata; Gestione = utenti e permessi, configurazione, comuni
    for testo in ("Accessori · PSV", "Utenti e permessi", "Configurazione", "Comuni (ISTAT)"):
        assert testo in html, testo
    # 0.16 (Federico, 12/10/2026, 18:05): «Tipi e tariffe» sta in Gestione › Configurazione
    assert 'href="/cataloghi"' not in html and 'href="/cataloghi"' in admin.get("/configurazione").text
    assert "Parco comune" not in html and "/impianti" not in html and "Tipi di pagamento" not in html
    # rc8 (D3): barra in alto; il gruppo della pagina è evidenziato ma chiuso (una tendina aperta coprirebbe la pagina)
    assert '<details class="nav-gruppo" data-gruppo="Attrezzature" data-attivo>' in html
    sezioni, html = voci(admin, "/impianti")  # una pagina DPR porta l'attività AD_DPR
    assert sezioni == ["Clienti", "Impianti", "Scadenze", "Preventivi", "Verifiche", "Fatture", "Gestione"]
    assert "/attrezzature" not in html
    assert admin.get("/beni").url.path == "/attrezzature"
    pagina = admin.get("/cataloghi").text
    for testo in ("Tipi di attrezzature", "Tipi attrezzature GVR", "ID specifiche", "Tipi attr. / ID specifiche", "Tariffe SC/SP", "Tariffe GVR"):
        assert testo in pagina, testo
    r = admin.get("/cataloghi/tariffe-gvr")
    assert r.url.path == "/cataloghi" and "scheda=tariffe-gvr" in str(r.url)
    # C16 (0.16): la configurazione dipende dall'attività (qui AD_DM, l'ultima pagina aperta è /cataloghi)
    conf = admin.get("/configurazione").text
    for testo in ("Modelli dei verbali GVR e SC/SP e del preventivo DM", "Firme dei verificatori", "Strumenti di misura",
                  "Tipi di pagamento", "Aliquote IVA", "Registro operazioni", "Backup e integrità"):
        assert testo in conf, testo
    assert "Modelli dei verbali (VerbalizzAI)" not in conf and "Verbali di VerbalizzAI" not in conf
    admin.get("/impianti")
    conf = admin.get("/configurazione").text
    # 0.19 (punto D): modelli dei verbali DPR e del preventivo DPR in una sola voce, verso /modelli
    for testo in ("Modelli dei verbali DPR e del preventivo", "Verbali di VerbalizzAI"):
        assert testo in conf, testo
    assert admin.get("/tipi-pagamento").status_code == 200 and admin.get("/aliquote-iva").status_code == 200
    # utenti e permessi come in VerbalizzAI: una pagina sola
    u = admin.get("/utenti").text
    assert "Permessi per ruolo" in u and "Salva permessi" in u
    assert admin.get("/ruoli").url.path == "/utenti"


def test_elenchi_attrezzature_valvole_e_cataloghi(admin):
    sede = crea_sede(admin, crea_cliente(admin)["id"])
    gv = nuovo(admin, sede, "GVR", "GV-9", tipo_attr_id=24, tipo_attr_gvr_id=2, id_spec_id=52)
    nuovo(admin, sede, "SC", "SC-9")
    vs = nuovo(admin, sede, "PSV", "VS-9", dati_dm={"tip_accessorio": "valvola di sicurezza", "dn": "25", "ptar": "12"})
    ok(admin.post(f"/api/beni/{gv['id']}/accessori", {"versione": gv["versione"], "accessorio_id": vs["id"]}))
    righe = ok(admin.post("/api/griglie/attrezzature/dati", {}))["righe"]
    assert sorted(r["matr_informale"] for r in righe) == ["GV-9", "SC-9"]  # le valvole hanno il loro elenco
    r = next(x for x in righe if x["matr_informale"] == "GV-9")
    assert (r["gruppo"], r["famiglia_codice"], r["n_valvole"], r["sede_denominazione"]) == ("GVR", "a2", 1, sede["denominazione"])
    valvole = ok(admin.post("/api/griglie/valvole/dati", {}))["righe"]
    assert [(x["matr_informale"], x["tip_accessorio"], x["dn"], x["collegata_a"]) for x in valvole] == [("VS-9", "valvola di sicurezza", "25", "GV-9")]
    filtrate = ok(admin.post("/api/griglie/attrezzature/dati", {"filtri": [{"campo": "gruppo", "valore": "SC"}]}))["righe"]
    assert [x["matr_informale"] for x in filtrate] == ["SC-9"]
    for codice, quanti in (("cat_tipi_attrezzature", 31), ("cat_tipi_gvr", 6), ("cat_id_specifiche", 72), ("cat_compatibilita", 162)):
        assert ok(admin.post(f"/api/griglie/{codice}/dati", {}))["totale"] == quanti, codice
    tariffe = ok(admin.post("/api/griglie/cat_tariffe_gvr/dati", {}))["totale"] + ok(admin.post("/api/griglie/cat_tariffe_scsp/dati", {}))["totale"]
    assert tariffe == 314


def test_termini_di_esecuzione_configurabili(admin):
    """0.12.9: elenco «Termini di esecuzione» in Configurazione, proposto nel preventivo."""
    termini = admin.get("/api/elenchi/termine_esecuzione").json()
    assert "Da concordare con il cliente" in [x["descrizione"] for x in termini]
    assert admin.get("/termini-esecuzione").status_code == 200
    assert "Termini di esecuzione" in admin.get("/configurazione").text
