# NEXUS 0.19.0: passaggio di consegne tecnico

**Data:** 14 ottobre 2026. **Base:** rc8 (`NEXUS_0.18.0_rc8_2026-10-14.zip`, SHA-256 `103266d5…8a40`). Schema Alembic **0030**: una migrazione nuova, `0030_strumenti_dpr`, applicata da sola all'avvio dopo il backup «pre_aggiornamento».
**Stato:** collaudo. Non è una release per la produzione. La rc8 resta la versione a cui tornare in caso di errori gravi: la 0.19 è una revisione distinta, come chiesto da Federico.
**Autore:** Claude, su decisioni di Federico. Leggere per primo `PASSAGGIO_INTEGRALE_NEXUS_DPR_2026-10-14_rev5.md`; questo file elenca solo le modifiche tecniche e la procedura di collaudo.

## Richiesta e decisioni

- Federico, 14/10/2026, 14:43: «Finisci la migrazione di verbalizzAI in Nexus, tanto noi lavoriamo con verbalizzai in produzione, che e' separato. Poi analizzeremo come migrare i dati».
- «Questa sarà una revisione successiva a quella appena consegnata così da poter tornare indietro in caso di errori gravi di sviluppo».
- **R111 «Sì, nucleo intatto».** Il nucleo documentale del motore non si tocca: Word/PDF, impaginazione, firma, regole e revisioni. Le parti esterne (registri, configurazione, archivio) possono passare a NEXUS.
- **Perimetro «A→F, editor escluso».** L'editor dei modelli Word resta quello di VerbalizzAI.
- **Verbali di prova in SQLite: «Consigliami tu».** Consigliato e realizzato: si migrano con `MIGRA_VERBALI_POSTGRESQL_WINDOWS.bat`.

## Modifiche

| Punto | Cosa | File principali | Test |
|---|---|---|---|
| A | **Verbali sempre nello stesso PostgreSQL.** Con `GESTIONALE_DATABASE_URL` i verbali stanno nello schema `verbali` senza impostazioni: `verbali_postgresql` non serve più, e `true` senza PostgreSQL dà errore. Un archivio SQLite incorporato rimasto in `cartella_dati/verbali/archivio.sqlite` blocca l'avvio finché non viene migrato. La migrazione si fa con `python -m gestionale.moduli.verbali.importa_postgresql --dalla-cartella-dati`, oppure con il `.bat`: backup completo in `cartella_dati/backup/verbali_sqlite_prima_della_migrazione_….adbackup.zip`, poi importazione verificata. Il file SQLite non viene modificato. | `core/config.py` (`verbali_in_postgresql`), `app.py`, `backup/postgresql.py`, `verbali/attivazione.py`, `verbali/importa_postgresql.py`, `MIGRA_VERBALI_POSTGRESQL_WINDOWS.bat` | `tests/postgresql/test_rc9_verbali_pg.py` |
| B | **Scheda tecnica completa modificabile in NEXUS.** **Non realizzata**: attende le due risposte di Federico (vedi sotto). | — | — |
| C | **Strumenti di misura AD_DPR nel modulo Strumenti di NEXUS** (Gestione › Configurazione › Strumenti di misura, attività DPR). Migrazione 0030: attività `DPR` ammessa; nuove colonne codice interno, assegnatario (utente), controllo intermedio con scadenza, stato operativo. Il motore legge gli strumenti da NEXUS (`ArchivioVerbali.all('instrument')`) con gli stessi campi di prima, per cui il verbale non cambia; il salvataggio e l'importazione nel registro del motore sono esclusi dal ponte. Gli strumenti rimasti nel registro di VerbalizzAI si importano con «Importali» (idempotente: salta codice o matricola già presenti). | `migrazioni/versions/0030_strumenti_dpr.py`, `moduli/strumenti/*`, `verbali/archivio.py`, `verbali/ponte.py`, `static/js/strumenti.js` | `tests/test_rc9_strumenti_dpr.py` |
| D | **Modelli Word dei verbali DPR** (M01, M02, M03) in Gestione › Configurazione › Modelli, attività DPR: elenco, caricamento, scarico, associazione alle bozze ed eliminazione, con le funzioni del motore (`adapt_template`, `add_template`, `assign_template`, `delete_template`, `template_usage`). Un modello con campi non riconosciuti va caricato con l'importazione guidata della pagina dei verbali, che resta disponibile. | `verbali/api.py` (`/api/modelli-verbali-dpr…`), `static/js/modelli.js` | `tests/test_rc9_modelli_dpr.py` |
| E | **Testi delle email dei verbali** in Gestione › Configurazione › Impostazioni email, accanto a quelli del preventivo. **DPR:** oggetto, testo e firma restano dove li legge il motore all'invio (`mail_texts`/`set_mail_texts`), con i suoi campi `{…}`. **DM:** prima fissi nel programma, ora configurabili (impostazione `dm.email_verbale`), con gli stessi valori predefiniti. | `verbali/api.py`, `dm/servizio.py`, `dm/api.py`, `static/js/impostazioni_email.js` | `tests/test_rc9_testi_email.py` |
| F | **Registro unico.** In Gestione › Registro operazioni la scheda «Operazioni sui verbali DPR» mostra il registro del motore in sola lettura, con filtri per periodo, utente e categoria: emissioni, revisioni, annullamenti, invii, modelli, firme, strumenti, backup. Il registro del motore resta nell'archivio dei verbali (e nel suo backup), non viene copiato né modificato. | `verbali/api.py` (`GET /api/registro-verbali`), `templates/registro.html`, `static/js/registro.js` | `tests/test_rc9_registro_unico.py`, `tests/postgresql/test_rc9_verbali_pg.py` |
| — | **Avvii PostgreSQL con database a scelta**: `AVVIA_NEXUS_POSTGRESQL_WINDOWS.bat` e `MIGRA_VERBALI_POSTGRESQL_WINDOWS.bat` chiedono il database («Invio» = `nexus_locale`, come prima), per collaudare su una copia. | i due `.bat` | — |

Il motore VerbalizzAI (`gestionale/terzi/verbalizzai/`) è invariato: lo controlla `tests/test_verbalizzai_identico.py`.

## Punto B: domande aperte per Federico

1. **Dove si salva la scheda.** Proposta: la maschera NEXUS della scheda completa salva i dati in NEXUS e, nella stessa operazione, li riporta nel profilo del motore con la funzione di correzione già esistente (`save_plant_state`). La data di riferimento del profilo (`observed_date`) resta quella dell'ultima verifica. Esempio: un impianto ha la scheda rilevata il 12/03/2026; se oggi correggi una cabina, la data resta 12/03/2026, così un verbale con data 20/03/2026 aggiornerà ancora la scheda all'emissione (con una data nuova, quella di oggi, l'aggiornamento verrebbe bloccato). Confermi?
2. **Elementi aggiunti o dismessi fuori dalla verifica.** Oggi il motore aggiunge o dismette elementi (quadri, dispersori…) solo durante la verifica. Dalla scheda NEXUS: (a) solo correzioni dei dati degli elementi esistenti, mentre aggiunte e dismissioni restano in verifica; oppure (b) anche aggiunte e dismissioni, il che richiede una nuova versione del motore da approvare?

## Prove eseguite davvero

Ambiente cloud Linux, Python 3.13, librerie offline da `librerie_linux.zip`, PostgreSQL **16** locale di prova.

| Prova | Esito |
|---|---|
| Suite completa 0.19.0 | **443 passed**, 0 failed, 0 skipped, 11 subtests, 11 min 19 s (PostgreSQL 16 nativo compreso; 10 test nuovi rispetto alla rc8). Un primo giro aveva 1 fallimento: `test_menu_dm_come_garda` cercava la voce «Modelli dei verbali (VerbalizzAI)», sostituita di proposito nel punto D; aggiornato il test, poi suite intera ripetuta |
| Browser (Chromium headless) | Registro con le due schede e i filtri, Strumenti di misura DPR, Modelli, Impostazioni email: controllati a vista |
| Motore invariato | `tests/test_verbalizzai_identico.py` passato |
| Prova generale della procedura di collaudo su copia (PostgreSQL 16) | rc8 su `nexus_locale` con archivio verbali SQLite → `pg_dump` → `createdb -O nexus_locale nexus_collaudo_019` → `pg_restore --no-owner --role=nexus_locale` → avvio 0.19 bloccato con il messaggio atteso → `--dalla-cartella-dati`: «Importazione verificata» → avvio 0.19 con verbali in PostgreSQL, schema 0030, dati e modelli presenti; `nexus_locale` rimasto a 0029 |

**Non provato:** Windows, PostgreSQL 18, migrazione dell'archivio SQLite di collaudo di Federico, dati reali, invii email.

## Collaudo su Windows: su una copia, non su `nexus_locale`

La 0.19 applica la migrazione 0030 e sposta i verbali in PostgreSQL. Per tornare alla rc8 senza ripristini va provata su una **copia** del database e della cartella dati.

```powershell
$pg = "C:\Program Files\PostgreSQL\18\bin"
& "$pg\pg_dump.exe" -U postgres -h 127.0.0.1 -Fc -f "$HOME\Desktop\nexus_locale_prima_019.dump" nexus_locale
& "$pg\createdb.exe" -U postgres -h 127.0.0.1 -O nexus_locale nexus_collaudo_019
& "$pg\pg_restore.exe" -U postgres -h 127.0.0.1 -d nexus_collaudo_019 --no-owner --role=nexus_locale "$HOME\Desktop\nexus_locale_prima_019.dump"
```

1. Estrarre lo ZIP 0.19 in una cartella nuova ed eseguire `INSTALLA_WINDOWS.bat`. **Non** copiare `config.postgresql.collaudo.json` della rc8: il primo avvio crea quello nuovo, con `Dati_PostgreSQL_Collaudo` dentro la cartella 0.19.
2. Copiare il **contenuto** della cartella dati della rc8 (quella indicata nel suo `config.postgresql.collaudo.json`) in `Dati_PostgreSQL_Collaudo` della 0.19. Se il file di configurazione non c'è ancora, la cartella si crea a mano con quel nome.
3. Test automatici, nella stessa finestra PowerShell:
   ```powershell
   $env:NEXUS_TEST_POSTGRESQL_ADMIN_URL = "postgresql://postgres:PASSWORD@127.0.0.1:5432/postgres"
   .\.venv\Scripts\python.exe -m pip install -r requirements-sviluppo.txt
   .\.venv\Scripts\python.exe -m pytest -n 2 -q
   ```
4. `MIGRA_VERBALI_POSTGRESQL_WINDOWS.bat` → database `nexus_collaudo_019`, password di `nexus_locale`, `SI`. Atteso: «Importazione verificata: {…}». Se la cartella dati non contiene un archivio SQLite dei verbali, il messaggio «Nessun archivio verbali SQLite da migrare» è normale e si passa oltre. «L'archivio PostgreSQL contiene già dati» significa che lo schema `verbali` della copia era già popolato: fermarsi e segnalarlo.
5. `AVVIA_NEXUS_POSTGRESQL_WINDOWS.bat` → database `nexus_collaudo_019`. Al primo avvio la migrazione 0030 parte da sola.
6. Prove a mano:
   - **verbali emessi e bozze ci sono tutti**, con il PDF che si apre, uguali a prima;
   - Strumenti di misura (DPR): «Importali», poi assegnatario e scadenze; in una bozza M01 gli strumenti si scelgono come prima;
   - Modelli: i tre modelli DPR, scarico di uno, associazione alle bozze;
   - Impostazioni email: testi DPR e DM, con anteprima dell'email di un verbale DM. **Senza inviare**;
   - Registro operazioni › «Operazioni sui verbali DPR»: filtri per data e utente;
   - le prove della rc8: numerazione, firme, striscia della verifica, destinazioni, dati della società.
7. Per tornare alla rc8: chiudere la 0.19 e avviare la rc8 con «Invio» (`nexus_locale`). Né la cartella dati della rc8 né `nexus_locale` sono stati toccati.

## Aperto

1. Punto B (domande sopra).
2. Analisi della migrazione dei dati di VerbalizzAI di produzione (Federico: «Poi analizzeremo come migrare i dati»).
3. Dalla rc8: D1-ter, Q4, nomi delle copie DPR/fatture, limite dell'anno nel DM, §§ 3.6–3.7 registrati e non implementati.
