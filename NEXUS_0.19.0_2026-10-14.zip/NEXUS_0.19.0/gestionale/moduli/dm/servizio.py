"""Preventivi DM sullo stesso nucleo dei preventivi DPR.

Fonti adsrl: attrezzature/preventivi/preventivi_righe.js e
_custom.php calcola_tariffa_standard, gi_rpt_preventivi_*.
"""

import json
from datetime import date

from sqlalchemy import select

from ...core.errori import ErroreUtente
from ..anagrafica.modelli import Cliente, Sede
from ..beni.modelli import CompatibilitaClassificazione
from ..beni import servizio as beni
from ..beni.scheda_dm import controlla_matricola
from ..preventivi.modelli import Preventivo, RigaPreventivo
from .modelli import IncaricoDM, TariffaDM

TIPI = {"V1": "Prima verifica periodica", "V2": "Verifica periodica successiva"}
GVR = {"funz": "Funzionamento", "integrita": "Integrità", "interna": "Visita interna",
       "funz_integrita": "Funzionamento + integrità", "funz_integrita_interna": "Funzionamento + integrità + interna",
       "funz_interna": "Funzionamento + interna", "integrita_interna": "Integrità + interna"}


def componenti(gruppo, tipo_gvr):
    return set(tipo_gvr.split("_")) if gruppo == "GVR" else {"scsp"}


def tariffa(s, a, tipo, tipo_gvr):
    if tipo not in TIPI:
        raise ErroreUtente("DM: scegli prima verifica periodica o successiva.")
    if a.gruppo == "GVR":
        if tipo_gvr not in GVR:
            raise ErroreUtente("Scegli la combinazione di verifica GVR.")
        if not beni.visita_interna(s, a) and "interna" in componenti(a.gruppo, tipo_gvr):
            raise ErroreUtente("La visita interna è prevista solo per generatori di vapore e di acqua surriscaldata (GV/INS GV).")
        if tipo == "V1" and a.soggetto_messa_servizio is None:  # N9 (0.12.8): prima finiva in V2 senza avvisi
            raise ErroreUtente("Prima verifica periodica GVR: nella scheda dell'attrezzatura indica se è soggetta a messa in servizio "
                               "(art. 4 D.M. 329/04) o no (art. 5). Decide la colonna V1 o V2 del tariffario.")
        colonna = ("V1" if a.soggetto_messa_servizio else "V2") if tipo == "V1" else (
            "V3" if tipo_gvr in ("funz", "interna") else "V4")
        q = select(TariffaDM).where(TariffaDM.gruppo == "GVR", TariffaDM.id_spec_id == a.id_spec_id,
                                   TariffaDM.tipo == colonna)
    elif a.gruppo in ("SC", "SP"):
        if tipo_gvr:
            raise ErroreUtente("La combinazione GVR non si applica a SC/SP.")
        compat = s.scalar(select(CompatibilitaClassificazione.id).where(
            CompatibilitaClassificazione.gruppo == a.gruppo,
            CompatibilitaClassificazione.tipo_attr_id == a.tipo_attr_id,
            CompatibilitaClassificazione.id_spec_id == a.id_spec_id))
        colonna = tipo
        q = select(TariffaDM).where(TariffaDM.gruppo == "SCSP", TariffaDM.compatibilita_id == compat,
                                   TariffaDM.tipo == colonna)
    else:
        raise ErroreUtente("Preventivo DM: scegli un'attrezzatura SC, SP o GVR.")
    t = s.scalar(q)
    if t is None:
        raise ErroreUtente("Manca la tariffa Garda per questa classificazione e tipo di verifica.")
    return {"totale": t.importo, "voci": [{"tariffa_dm_id": t.id, "colonna": colonna,
            "importo": t.importo, "spiegazione": TIPI[tipo] + (" — " + GVR[tipo_gvr] if tipo_gvr else "")}],
            "problemi": [], "avvisi": []}


def controlla_copertura(s, a, tipo, gvr, escludi_riga=None, escludi_preventivo=None):
    q = (select(RigaPreventivo, Preventivo).join(Preventivo)
         .where(RigaPreventivo.asset_id == a.id, RigaPreventivo.tipo_verifica_dm == tipo,
                RigaPreventivo.stato != "annullata", Preventivo.stato.notin_(("annullato", "sostituito"))))
    if escludi_riga:
        q = q.where(RigaPreventivo.id != escludi_riga)
    if escludi_preventivo:
        q = q.where(Preventivo.id != escludi_preventivo)
    for r, p in s.execute(q):
        if s.scalar(select(IncaricoDM.id).where(IncaricoDM.riga_id == r.id, IncaricoDM.stato == 'effettuata')):
            continue
        if componenti(a.gruppo, gvr) & componenti(a.gruppo, r.tipo_verifica_gvr):
            raise ErroreUtente(f"Attività già preventivata per questa attrezzatura nel preventivo DM {p.codice}.", 409)


def copia_asset(s, r, a):
    sd = a.sede
    r.sede_nome, r.sede_indirizzo = sd.denominazione[:300], sd.indirizzo[:200]
    r.sede_comune = " ".join(x for x in (sd.cap, sd.comune, f"({sd.provincia})" if sd.provincia else "") if x)[:160]
    r.tipologia = a.gruppo
    raw = json.loads(a.attributi_json)
    r.descrizione = (raw.get("descr_attr") or a.denominazione or a.matr_informale)[:200]
    r.asset_fotografia = json.dumps(beni.scheda(s, a), ensure_ascii=False)


def nuova_riga(s, p, dati):
    from ..preventivi import servizio as pv
    if p.ambito != "DM":
        raise ErroreUtente("Le attrezzature DM si aggiungono a un preventivo DM.")
    a = beni.leggi(s, dati.get("asset_id"))
    controlla_matricola(a, nuovi=True)
    if not a.tipo_attr_id or not a.id_spec_id:
        raise ErroreUtente("Completa apparecchi all. 7 e ID specifica prima di preventivare.")
    if a.gruppo not in ("GVR", "SC", "SP") or a.sede_id != p.sede_id or a.sede.cliente_id != p.cliente_id:
        raise ErroreUtente("Scegli un'attrezzatura SC/SP/GVR della sede del preventivo DM.")
    if a.dismesso or not a.sede.attiva or not a.sede.cliente.attivo:
        raise ErroreUtente("L'attrezzatura o la sua sede/cliente non è attiva.")
    if json.loads(a.attributi_json).get("esente_verifiche", "F") != "F":
        raise ErroreUtente("L'attrezzatura è esente dal flusso DM; verificare il regime pertinente.")
    tipo = str(dati.get("tipo_verifica_dm") or "")
    gvr = str(dati.get("tipo_verifica_gvr") or "")
    calcolo = tariffa(s, a, tipo, gvr)
    controlla_copertura(s, a, tipo, gvr, escludi_preventivo=p.id)
    for r in p.righe:
        if r.asset_id == a.id and r.tipo_verifica_dm == tipo and r.stato != "annullata" and (
            componenti(a.gruppo, gvr) & componenti(a.gruppo, r.tipo_verifica_gvr)):
            raise ErroreUtente("La stessa attività è già presente in questo preventivo.", 409)
    r = RigaPreventivo(asset_id=a.id, tipo_verifica="periodica", tipo_verifica_dm=tipo,
                      tipo_verifica_gvr=gvr, ordine=max([x.ordine for x in p.righe] + [0]) + 1,
                      tariffa_standard=calcolo["totale"], dettaglio_tariffa=json.dumps(calcolo, ensure_ascii=False),
                      stato="in_attesa", sconto=min(10000, max(0, a.sede.cliente.sconto_dm or 0)))  # AD-13 (0.12.8)
    copia_asset(s, r, a)
    pv._applica_sconto(r)
    p.righe.append(r)
    return r


def crea(s, attore, dati):
    from ..preventivi import servizio as pv
    from ..anagrafica.servizio import _crea, _data
    from ..registro import servizio as registro
    sd = s.get(Sede, beni.intero(dati.get("sede_id"), "Sede"))
    if sd is None or not sd.attiva or not sd.cliente.attivo:
        raise ErroreUtente("Scegli una sede attiva di un cliente attivo.")
    if not sd.cliente.ambito_dm:  # R114/R137: il preventivo DM si fa solo per clienti AD_DM; l'ambito è del cliente
        raise ErroreUtente(f"La sede «{sd.denominazione}» non è AD_DM: il suo cliente «{sd.cliente.ragione_sociale}» non è AD_DM. "
                           "Se deve diventarlo, aggiungi l'ambito AD_DM nella scheda del cliente (Clienti › Ambiti di lavoro).")
    if dati.get("cliente_id") and int(dati["cliente_id"]) != sd.cliente_id:
        raise ErroreUtente("Cliente e sede del preventivo non coincidono.")
    giorno = _data(dati, "data", "Data") or date.today()
    serie = str(dati.get("serie") or giorno.year).strip()
    if not serie or len(serie) > 40:
        raise ErroreUtente("Serie preventivo: da 1 a 40 caratteri.")
    numero = pv.numero_successivo(s, giorno.year, "DM", serie)
    c = s.get(Cliente, sd.cliente_id)
    p = Preventivo(ambito="DM", serie=serie, anno=giorno.year, numero=numero, revisione=0,
                   codice=f"{numero}/{serie}", data=giorno, cliente_id=c.id, sede_id=sd.id,
                   commerciale_id=c.commerciale_id, stato="creato", modalita_pagamento=c.modalita_pagamento.descrizione
                   if c.modalita_pagamento else "", termine_esecuzione=c.termine_esecuzione,
                   note=str(dati.get("note") or "")[:4000])
    s.add(p)
    for rd in dati.get("attrezzature") or []:
        nuova_riga(s, p, rd)
    pv._totali(p)
    _crea(s, p, attore)
    registro.scrivi(s, utente=attore, azione="preventivo.crea", oggetto_tipo="preventivo", oggetto_id=p.id,
                    descrizione=f"Creato preventivo DM {p.codice} per sede {sd.denominazione}")
    return p


def controlla_preventivo(s, p):
    presenti = {}
    for r in p.righe:
        if r.asset_id is not None and r.stato != "annullata":
            a = beni.leggi(s, r.asset_id)
            key = (r.asset_id, r.tipo_verifica_dm)
            parti = componenti(a.gruppo, r.tipo_verifica_gvr)
            if presenti.get(key, (set(), []))[0] & parti:
                # N8 (0.12.8): la combinazione scelta copre un'altra riga della stessa attrezzatura: si dice quale togliere
                altre = ", ".join(str(n) for n in presenti[key][1])
                raise ErroreUtente(f"Riga {r.ordine}: l'attività {GVR.get(r.tipo_verifica_gvr, 'SC/SP')} dell'attrezzatura "
                                   f"{a.matr_informale or a.id} è già nella riga {altre} di questo preventivo. Se vuoi la combinazione, "
                                   "togli prima quella riga (seleziona › «Togli selezionate»).", 409)
            presenti.setdefault(key, (set(), []))[0].update(parti)
            presenti[key][1].append(r.ordine)
            controlla_copertura(s, a, r.tipo_verifica_dm, r.tipo_verifica_gvr,
                               escludi_riga=r.id, escludi_preventivo=p.id)


def genera_incarichi(s, attore, p):
    from ..anagrafica.servizio import _crea
    from ..registro import servizio as registro
    controlla_preventivo(s, p)
    gia = set(s.scalars(select(IncaricoDM.riga_id).where(IncaricoDM.stato != "annullata")))
    nuovi = []
    for r in p.righe:
        if r.stato == "accettata" and r.asset_id and r.id not in gia:
            x = IncaricoDM(riga_id=r.id, asset_id=r.asset_id, stato="da_assegnare", fotografia_json=r.asset_fotografia)
            _crea(s, x, attore)
            nuovi.append(x)
    s.flush()
    if nuovi:
        registro.scrivi(s, utente=attore, azione="dm.incarichi_crea", oggetto_tipo="preventivo", oggetto_id=p.id,
                        descrizione=f"Creati {len(nuovi)} incarichi DM dopo riesame conforme",
                        dettagli={"incarichi": [x.id for x in nuovi]})
    return nuovi


def elenchi_documento(p):
    from ..preventivi.servizio import euro
    out = {"gvr": [], "scsp": []}
    for r in p.righe:
        if not r.asset_id or r.stato in ("annullata", "rifiutata"):
            continue
        a = json.loads(r.asset_fotografia)
        raw = a["attributi"]
        d = {"rif_interno": raw.get("rif_interno", ""), "descr_attr": raw.get("descr_attr") or a["denominazione"],
             "rag_soc_costr": a["costruttore"], "matr_informale": a["matr_informale"], "num_fabbrica": a["num_fabbrica"],
             "portata_attr_sc_sp": raw.get("portata_attr_sc_sp", ""), "tipo_verifica": TIPI[r.tipo_verifica_dm],
             "tipo_verifica_gvr": GVR.get(r.tipo_verifica_gvr, ""), "tariffa_standard": euro(r.tariffa_standard)}
        out["gvr" if a["gruppo"] == "GVR" else "scsp"].append(d)
    return out



# ---------------------------------------------------------------- N8 (0.12.8): preventivo dalle scadenze, come in Garda

COMPONENTE_GVR = {"funzionamento": "funz", "integrita": "integrita", "interna": "interna"}


def tipo_della_scadenza(s, a, sc):
    """Garda `ricalcola_scadenze_attrezzatura` (AD-40): la scadenza più vicina dell'attrezzatura prende il «tipo prossima
    verifica» (prima periodica V1 o successiva V2); le altre sono successive."""
    from ..beni.modelli import ScadenzaTecnica
    tipo = json.loads(a.attributi_json).get("tipo_prox_verifica") or "V2"
    vicine = [x for x in s.scalars(select(ScadenzaTecnica).where(ScadenzaTecnica.asset_id == a.id,
              ScadenzaTecnica.componente.in_(("funzionamento", "integrita", "interna", "scsp")))) if x.data_prossima]
    if not vicine:
        return tipo
    piu_vicina = min(vicine, key=lambda x: (x.data_prossima, x.id))
    return tipo if piu_vicina.id == sc.id or not sc.data_prossima else "V2"


def da_scadenze(s, attore, dati):
    """Garda `gi_scadenze_preventivi_crea` (AD-42, AD-43): righe di preventivo DM dalle scadenze selezionate.
    - solo funzionamento, integrità, visita interna e SC/SP (CND, indagini supplementari, efficienza valvole e regime ISO 17020 sono EX);
    - attrezzatura non dismessa e non esente; scadenza non già preventivata (copertura, AD-41);
    - una riga per scadenza, mai combinate (Garda `$merge = false`; Federico, 11/10/2026: la combinazione si sceglie
      a mano sulla riga); tipo V1/V2 dalla scadenza; sconto predefinito del cliente;
    - un preventivo per cliente e sede; con `preventivo` le righe vanno in quel preventivo, che deve essere «creato» e
      della stessa sede (come il «preventivo fisso» di Garda)."""
    from ..anagrafica.servizio import _data, _modificato
    from ..beni.modelli import ScadenzaTecnica
    from ..preventivi import servizio as pv
    from ..registro import servizio as registro
    ids = [beni.intero(x, "Scadenza") for x in (dati.get("scadenze") or [])]
    if not ids:
        raise ErroreUtente("Seleziona le scadenze da preventivare.")
    scadenze = list(s.scalars(select(ScadenzaTecnica).where(ScadenzaTecnica.id.in_(ids)).order_by(ScadenzaTecnica.data_prossima, ScadenzaTecnica.id)))
    if len(scadenze) != len(set(ids)):
        raise ErroreUtente("Scadenze non trovate: ricarica l'elenco.")
    # R129 (0.12.9): solo le verifiche dell'allegato VII D.Lgs. 81/08 (GVR funzionamento/integrità/interna, SC/SP) di
    # attrezzature non esenti; il resto è attività EX (CND, indagini supplementari, efficienza valvole, regime ISO 17020)
    def _all_vii(sc):  # noqa: ANN001, ANN202
        a = sc.asset
        ok = (a.gruppo == "GVR" and sc.componente in ("funzionamento", "integrita", "interna")) or (
            a.gruppo in ("SC", "SP") and sc.componente == "scsp")
        return ok and json.loads(a.attributi_json or "{}").get("esente_verifiche", "F") == "F"
    escluse = [sc for sc in scadenze if not _all_vii(sc)]
    if escluse:
        raise ErroreUtente("Il preventivo DM contiene solo le verifiche dell'allegato VII D.Lgs. 81/08 (GVR: funzionamento, integrità, "
                           "visita interna; SC/SP) di attrezzature non esenti. CND, indagini supplementari, efficienza delle valvole e "
                           "verifiche in regime volontario ISO 17020 sono attività EX: togli la spunta a "
                           + ", ".join(f"{sc.asset.matr_informale} ({sc.componente})" for sc in escluse[:8]) + ".")
    gruppi = {}
    for sc in scadenze:
        gruppi.setdefault(sc.asset.sede_id, []).append(sc)
    fisso = None
    if str(dati.get("preventivo") or "").strip():
        rif = str(dati["preventivo"]).strip()
        numero = rif.split("/")[0].strip()
        q = select(Preventivo).where(Preventivo.ambito == "DM", Preventivo.sede_id.in_(list(gruppi)))
        q = q.where((Preventivo.codice == rif) | (Preventivo.numero == int(numero))) if numero.isdigit() else q.where(Preventivo.codice == rif)
        candidati = list(s.scalars(q.order_by(Preventivo.anno.desc(), Preventivo.revisione.desc(), Preventivo.id.desc())))
        if not candidati:
            raise ErroreUtente(f"Preventivo DM «{rif}» non trovato per la sede delle scadenze.")
        fisso = candidati[0]
        if len(gruppi) > 1:
            raise ErroreUtente("Le scadenze selezionate sono di sedi diverse: con un preventivo indicato si sceglie una sola sede.")
        if fisso.stato != "creato":
            raise ErroreUtente(f"Il preventivo {pv.etichetta(fisso)} è «{pv.STATI[fisso.stato]}»: le righe si aggiungono solo a un preventivo «creato» (come in Garda).")
    giorno = _data(dati, "data", "Data preventivo")
    creati = []
    for sede_id, elenco in gruppi.items():
        p = fisso or crea(s, attore, {"sede_id": sede_id, **({"data": giorno.isoformat()} if giorno else {})})
        # C13 (0.16, Federico 12/10/2026, 17:49-17:52): la prima verifica periodica (PVP) va alla PRIMA scadenza
        # dell'attrezzatura che entra nel preventivo (ordine dell'elenco: data, poi scadenza); le altre sono successive.
        con_pvp = set(s.scalars(select(RigaPreventivo.asset_id).where(RigaPreventivo.preventivo_id == p.id,
                                                                     RigaPreventivo.tipo_verifica_dm == "V1")))
        for sc in elenco:
            a = sc.asset
            tipo = "V1" if json.loads(a.attributi_json or "{}").get("tipo_prox_verifica") == "V1" and a.id not in con_pvp else "V2"
            if tipo == "V1":
                con_pvp.add(a.id)
            gvr = COMPONENTE_GVR.get(sc.componente, "") if a.gruppo == "GVR" else ""
            try:
                nuova_riga(s, p, {"asset_id": a.id, "tipo_verifica_dm": tipo, "tipo_verifica_gvr": gvr})
            except ErroreUtente as e:
                raise ErroreUtente(f"{a.matr_informale or a.id} · {sc.componente}: {e.messaggio}", e.stato if hasattr(e, "stato") else 400) from None
        pv._totali(p)
        _modificato(p, attore)
        s.flush()
        registro.scrivi(s, utente=attore, azione="preventivo.da_scadenze", oggetto_tipo="preventivo", oggetto_id=p.id,
                        descrizione=f"Preventivo DM {p.codice}: {len(elenco)} righe dalle scadenze",
                        dettagli={"scadenze": [sc.id for sc in elenco]})
        creati.append(p)
    return creati



# ---------------------------------------------------------------- rc9 (punto E): testi delle email dei verbali DM
# Prima erano fissi nel codice (dm/api.py::bozza_email): restano gli stessi come testi predefiniti.
TESTI_EMAIL_VERBALE = {
    "oggetto": "Verbale {numero} — {cliente}",
    "testo": "Spett.le {cliente},\n\nin allegato trasmettiamo il verbale di verifica.\n\nCordiali saluti",
    "firma": "AD S.r.l.",
}
CAMPI_EMAIL_VERBALE = [("numero", "Numero del verbale"), ("cliente", "Ragione sociale"), ("sede", "Sede operativa"),
                       ("data", "Data di rilascio del verbale")]


def testi_email_verbale(s) -> dict:
    import json as _json
    from ..impostazioni.modelli import Impostazione
    x = s.get(Impostazione, "dm.email_verbale")
    return {**TESTI_EMAIL_VERBALE, **(_json.loads(x.valore) if x else {})}


def componi_testo(testo: str, valori: dict) -> str:
    """Sostituisce i campi {…} noti; quelli sconosciuti restano come scritti."""
    import re as _re
    return _re.sub(r"\{(\w+)\}", lambda m: str(valori[m.group(1)]) if m.group(1) in valori else m.group(0), testo or "")


def salva_testi_email_verbale(s, attore, dati: dict) -> dict:
    import json as _json
    from ...core.errori import ErroreUtente
    from ..impostazioni.modelli import Impostazione
    from ..registro import servizio as registro
    nuovi = {k: str(dati.get(k) or "").replace("\r\n", "\n")[:5000] for k in TESTI_EMAIL_VERBALE}
    if not nuovi["oggetto"].strip() or not nuovi["testo"].strip():
        raise ErroreUtente("Scrivi oggetto e testo dell'email.")
    if "\n" in nuovi["oggetto"]:
        raise ErroreUtente("L'oggetto deve stare su una riga.")
    x = s.get(Impostazione, "dm.email_verbale")
    prima = testi_email_verbale(s)
    if x is None:
        x = Impostazione(chiave="dm.email_verbale", valore="{}")
        s.add(x)
    x.valore, x.aggiornata_da = _json.dumps(nuovi, ensure_ascii=False), getattr(attore, "id", None)
    registro.scrivi(s, utente=attore, azione="impostazioni.email_verbali_dm", oggetto_tipo="impostazione", oggetto_id="dm.email_verbale",
                    descrizione="Modificati i testi standard delle email dei verbali DM", dettagli={"modifiche": registro.differenze(prima, nuovi)})
    return nuovi
