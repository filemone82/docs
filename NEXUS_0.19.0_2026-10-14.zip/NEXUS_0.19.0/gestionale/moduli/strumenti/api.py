"""API degli strumenti di misura AD_DPR, AD_DM e I&C (C16, 0.16; rc9 punto C)."""

from __future__ import annotations

from fastapi import APIRouter, Body, Depends, Request

from ...core.db import Archivio
from ...core.errori import ErroreUtente, PermessoNegato
from ...web.dipendenze import archivio, utente
from ..utenti.accesso import UtenteCorrente
from . import servizio

router = APIRouter(prefix="/api/strumenti")


def _att(attivita: str, u: UtenteCorrente, codice: str) -> str:
    if attivita not in servizio.NOMI:
        raise ErroreUtente("Attività non valida.")
    if not u.puo(codice, attivita):
        raise PermessoNegato("Non hai il permesso per gli strumenti di misura di questa attività.")
    return attivita


@router.get("/DPR/registro-verbali")
def registro_verbali(request: Request, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    """rc9 (punto C): quanti strumenti del registro di VerbalizzAI non sono ancora fra gli strumenti AD_DPR di NEXUS."""
    _att("DPR", u, "strumenti.vedere")
    with arc.lettura() as s:
        return {"da_importare": len(servizio.da_importare(s, request.app.state.verbali.strumenti_del_registro()))}


@router.post("/DPR/registro-verbali")
def importa_registro_verbali(request: Request, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    _att("DPR", u, "strumenti.gestire")
    registro = request.app.state.verbali.strumenti_del_registro()
    with arc.scrittura() as s:
        return servizio.importa_registro_verbali(s, u.come_attore(), registro)


@router.get("/{attivita}/{id}")
def leggi(attivita: str, id: int, u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    a = _att(attivita, u, "strumenti.vedere")
    with arc.lettura() as s:
        return servizio.json_strumento(servizio.leggi(s, id, a))


@router.post("/{attivita}")
def crea(attivita: str, dati: dict = Body(...), u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    a = _att(attivita, u, "strumenti.gestire")
    with arc.scrittura() as s:
        return servizio.json_strumento(servizio.salva(s, u.come_attore(), a, dati))


@router.put("/{attivita}/{id}")
def modifica(attivita: str, id: int, dati: dict = Body(...), u: UtenteCorrente = Depends(utente), arc: Archivio = Depends(archivio)) -> dict:
    a = _att(attivita, u, "strumenti.gestire")
    with arc.scrittura() as s:
        return servizio.json_strumento(servizio.salva(s, u.come_attore(), a, dati, id))
