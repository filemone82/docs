"""Strumenti di misura di AD_DPR, AD_DM e I&C (C16, 0.16; rc9 punto C: anche AD_DPR, prima nel registro di VerbalizzAI).

Per AD_DPR servono anche codice interno, assegnatario (il verbale propone gli strumenti assegnati al verificatore),
controllo intermedio e stato operativo, come nel registro M07 di VerbalizzAI. Migrazione 0030."""

from __future__ import annotations

from datetime import date

from sqlalchemy import Boolean, CheckConstraint, Date, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from ...core.db import Base
from ...core.modelli_comuni import Tracciato


class StrumentoMisura(Base, Tracciato):
    __tablename__ = "strumenti_misura"
    __table_args__ = (CheckConstraint("attivita IN ('DPR','DM','IEC')", name="attivita"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    attivita: Mapped[str] = mapped_column(String(4), index=True)
    denominazione: Mapped[str] = mapped_column(String(200))
    costruttore: Mapped[str] = mapped_column(String(120), default="")
    modello: Mapped[str] = mapped_column(String(120), default="")
    matricola: Mapped[str] = mapped_column(String(120), default="")
    campo_misura: Mapped[str] = mapped_column(String(200), default="")
    ente_taratura: Mapped[str] = mapped_column(String(200), default="")
    certificato: Mapped[str] = mapped_column(String(120), default="")
    data_taratura: Mapped[date | None] = mapped_column(Date)
    scadenza_taratura: Mapped[date | None] = mapped_column(Date, index=True)
    attivo: Mapped[bool] = mapped_column(Boolean, default=True)
    note: Mapped[str] = mapped_column(Text, default="")
    # rc9 (punto C): campi del registro strumenti di VerbalizzAI (M07)
    codice: Mapped[str] = mapped_column(String(60), default="", server_default="")
    assegnato_id: Mapped[int | None] = mapped_column(ForeignKey("utenti.id", ondelete="RESTRICT"), nullable=True, index=True)
    controllo_intermedio: Mapped[date | None] = mapped_column(Date, nullable=True)
    scadenza_controllo_intermedio: Mapped[date | None] = mapped_column(Date, nullable=True)
    stato_operativo: Mapped[str] = mapped_column(String(40), default="Attivo", server_default="Attivo")
