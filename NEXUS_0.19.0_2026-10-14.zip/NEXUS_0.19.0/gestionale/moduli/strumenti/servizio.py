"""Strumenti di misura AD_DPR, AD_DM e I&C: scheda, controlli, registro (C16, 0.16; rc9 punto C: anche AD_DPR)."""

from __future__ import annotations

from datetime import date
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ...core.db import adesso
from ...core.errori import Conflitto, ErroreUtente, NonTrovato
from ..registro import servizio as registro
from .modelli import StrumentoMisura

TESTI = {"denominazione": 200, "costruttore": 120, "modello": 120, "matricola": 120, "campo_misura": 200,
         "ente_taratura": 200, "certificato": 120, "note": 4000, "codice": 60}
NOMI = {"DPR": "AD_DPR", "DM": "AD_DM", "IEC": "I&C"}
# rc9: stati operativi del registro strumenti di VerbalizzAI (M07); «In uso» = stato Attivo
STATI_OPERATIVI = ("Attivo", "In taratura", "Fuori servizio", "Dismesso", "Non attivo")


def json_strumento(x: StrumentoMisura) -> dict:
    iso = lambda d: d.isoformat() if d else None  # noqa: E731
    return {"id": x.id, "attivita": x.attivita, **{k: getattr(x, k) for k in TESTI},
            "data_taratura": iso(x.data_taratura), "scadenza_taratura": iso(x.scadenza_taratura),
            "controllo_intermedio": iso(x.controllo_intermedio), "scadenza_controllo_intermedio": iso(x.scadenza_controllo_intermedio),
            "assegnato_id": x.assegnato_id, "stato_operativo": x.stato_operativo or "Attivo",
            "attivo": x.attivo, "versione": x.versione}


def _data(v: Any, nome: str) -> date | None:
    if v in (None, ""):
        return None
    try:
        return date.fromisoformat(str(v))
    except ValueError:
        raise ErroreUtente(f"{nome}: data non valida.") from None


def _assegnatario(s: Session, v: Any) -> int | None:
    if v in (None, "", 0, "0"):
        return None
    from ..utenti.modelli import Utente
    try:
        u = s.get(Utente, int(v))
    except (TypeError, ValueError):
        u = None
    if u is None:
        raise ErroreUtente("Assegnatario non trovato.")
    return u.id


def leggi(s: Session, id: int, attivita: str) -> StrumentoMisura:
    x = s.get(StrumentoMisura, id)
    if x is None or x.attivita != attivita:
        raise NonTrovato("Strumento non trovato.")
    return x


def salva(s: Session, attore: Any, attivita: str, dati: dict, id: int | None = None) -> StrumentoMisura:
    if attivita not in NOMI:
        raise ErroreUtente("Attività non valida.")
    if id is None:
        x, prima = StrumentoMisura(attivita=attivita, creato_da=attore.nome), None
    else:
        x = leggi(s, id, attivita)
        if dati.get("versione") is not None and int(dati["versione"]) != x.versione:
            raise Conflitto()
        prima = json_strumento(x)
    for k, n in TESTI.items():
        if k in dati or id is None:
            v = str(dati.get(k) or "").strip()
            if len(v) > n:
                raise ErroreUtente(f"{k}: massimo {n} caratteri.")
            setattr(x, k, v)
    if not x.denominazione:
        raise ErroreUtente("Scrivi la denominazione dello strumento (es. «Spessimetro a ultrasuoni»).")
    x.codice = (x.codice or "").upper()
    for k, nome in (("data_taratura", "Data di taratura"), ("scadenza_taratura", "Scadenza della taratura"),
                    ("controllo_intermedio", "Controllo intermedio"), ("scadenza_controllo_intermedio", "Scadenza del controllo intermedio")):
        if k in dati or id is None:
            setattr(x, k, _data(dati.get(k), nome))
    if x.data_taratura and x.scadenza_taratura and x.scadenza_taratura < x.data_taratura:
        raise ErroreUtente("La scadenza della taratura non può precedere la data di taratura.")
    if x.controllo_intermedio and x.scadenza_controllo_intermedio and x.scadenza_controllo_intermedio < x.controllo_intermedio:
        raise ErroreUtente("La scadenza del controllo intermedio non può precedere il controllo.")
    if "assegnato_id" in dati or id is None:
        x.assegnato_id = _assegnatario(s, dati.get("assegnato_id"))
    # stato operativo e «in uso» coerenti, come nel registro di VerbalizzAI: in uso solo se Attivo
    if "stato_operativo" in dati and str(dati["stato_operativo"] or "").strip():
        stato = str(dati["stato_operativo"]).strip()
        if stato not in STATI_OPERATIVI:
            raise ErroreUtente("Stato operativo non valido: " + ", ".join(STATI_OPERATIVI) + ".")
        x.stato_operativo, x.attivo = stato, stato == "Attivo"
    elif "attivo" in dati:
        x.attivo = bool(dati["attivo"])
        x.stato_operativo = "Attivo" if x.attivo else (x.stato_operativo if x.stato_operativo not in (None, "", "Attivo") else "Non attivo")
    elif id is None:
        x.attivo, x.stato_operativo = True, "Attivo"
    if x.codice and s.scalar(select(func.count(StrumentoMisura.id)).where(
            StrumentoMisura.attivita == attivita, StrumentoMisura.codice == x.codice, StrumentoMisura.id != (x.id or 0))):
        raise ErroreUtente(f"Codice interno {x.codice} già usato da un altro strumento {NOMI[attivita]}.")
    if x.matricola and s.scalar(select(func.count(StrumentoMisura.id)).where(
            StrumentoMisura.attivita == attivita, func.lower(StrumentoMisura.matricola) == x.matricola.lower(),
            StrumentoMisura.id != (x.id or 0))):
        raise ErroreUtente(f"Esiste già uno strumento {NOMI[attivita]} con matricola «{x.matricola}».")
    x.modificato_da, x.modificato_il = attore.nome, adesso()
    if id is None:
        s.add(x)
    else:
        x.versione += 1
    s.flush()
    registro.scrivi(s, utente=attore, azione="strumento.crea" if prima is None else "strumento.modifica", oggetto_tipo="strumento",
                    oggetto_id=x.id, descrizione=f"{'Creato' if prima is None else 'Modificato'} lo strumento {NOMI[attivita]} «{x.denominazione}»",
                    dettagli={"dopo": json_strumento(x)} if prima is None else {"modifiche": registro.differenze(prima, json_strumento(x))})
    return x


# ---------------------------------------------------------------- rc9 (punto C): dal registro di VerbalizzAI
def _da_gg(v: Any) -> str | None:
    t = str(v or "").strip()
    try:
        g, m, a = (int(x) for x in t.split("/"))
        return date(a, m, g).isoformat()
    except ValueError:
        return None


def _gia_presente(s: Session, d: dict) -> bool:
    codice, matricola = str(d.get("code") or "").strip().upper(), str(d.get("serial") or "").strip().lower()
    q = select(func.count(StrumentoMisura.id)).where(StrumentoMisura.attivita == "DPR")
    if codice and s.scalar(q.where(StrumentoMisura.codice == codice)):
        return True
    return bool(matricola) and bool(s.scalar(q.where(func.lower(StrumentoMisura.matricola) == matricola)))


def da_importare(s: Session, registro: list[dict]) -> list[dict]:
    return [x for x in registro if not _gia_presente(s, x.get("data") or {})]


def importa_registro_verbali(s: Session, attore: Any, registro: list[dict]) -> dict:
    """Strumenti del registro proprio di VerbalizzAI (oggetti «instrument») → strumenti AD_DPR di NEXUS. Idempotente:
    salta quelli con lo stesso codice interno o la stessa matricola. L'assegnatario si riconosce dal nome dell'utente."""
    import re
    from ..utenti.modelli import Utente

    def chiave(n: Any) -> str:
        n = re.sub(r"^(?:(?:dott|dr|ing|per|ind|p|i|geom|arch|avv|sig\.ra|sig|prof|rag)(?:\.\s*|\s+))+", "", str(n or "").strip(), flags=re.I)
        return re.sub(r"\s+", " ", n).casefold()

    utenti = {chiave(u.nome): u.id for u in s.scalars(select(Utente))}
    importati, gia, avvisi = 0, 0, []
    for x in registro:
        d = x.get("data") or {}
        if _gia_presente(s, d):
            gia += 1
            continue
        assegnato = utenti.get(chiave(d.get("assigned_to"))) if d.get("assigned_to") else None
        if d.get("assigned_to") and assegnato is None:
            avvisi.append(f"{d.get('code') or d.get('serial')}: assegnatario «{d['assigned_to']}» non trovato fra gli utenti.")
        stato = d.get("status") if d.get("status") in STATI_OPERATIVI else ("Attivo" if d.get("active", True) else "Non attivo")
        salva(s, attore, "DPR", {"codice": d.get("code") or "", "denominazione": d.get("type") or "Strumento", "costruttore": d.get("brand") or "",
                                  "modello": d.get("model") or "", "matricola": d.get("serial") or "",
                                  "data_taratura": _da_gg(d.get("calibration")), "scadenza_taratura": _da_gg(d.get("calibration_due")),
                                  "controllo_intermedio": _da_gg(d.get("internal_check")),
                                  "scadenza_controllo_intermedio": _da_gg(d.get("internal_check_due")),
                                  "assegnato_id": assegnato, "stato_operativo": stato,
                                  "note": "Importato dal registro strumenti di VerbalizzAI"})
        importati += 1
    return {"importati": importati, "gia_presenti": gia, "avvisi": avvisi}
