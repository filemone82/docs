"""Importazione una tantum da un backup completo VerbalizzAI nel PostgreSQL DPR.

Avviare a NEXUS fermo. Non legge né modifica la produzione standalone: riceve
esclusivamente una copia .adbackup.zip già verificata, con tutti i documenti.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

from ...core.config import carica_config
from ...terzi.verbalizzai.storage import Archive
from .attivazione import CHIAVE, impronta
from .postgresql import ArchivioPostgresql


def importa(percorso: Path, cfg) -> dict:
    if not cfg.postgresql:
        raise ValueError("Configurare GESTIONALE_DATABASE_URL verso il database PostgreSQL di NEXUS.")
    originali, _, manifest = Archive.verify_backup(percorso)
    if manifest["documents"] != "included":
        raise ValueError("Per la migrazione occorre un backup completo, con tutti i documenti inclusi.")
    if originali["format_version"] != 2:
        raise ValueError("Aggiornare prima la copia standalone al formato 2 e riesportare il backup completo.")
    target = ArchivioPostgresql(cfg.cartella_dati / "verbali", cfg.database_url)
    c = target.connect()
    try:
        if any(c.execute(f"SELECT 1 FROM {table} LIMIT 1").fetchone()
               for table in ("objects", "documents", "events", "users")):
            raise ValueError("L'archivio PostgreSQL contiene già dati: importazione bloccata per evitare sovrascritture.")
    finally:
        c.close()
    target.set_actor("migrazione")
    target.restore(percorso)
    # La procedura di ripristino registra intenzionalmente UN evento in più.
    verifica = target._snapshot()
    for key in ("objects", "documents", "users"):
        if verifica[key] != originali[key]:
            raise RuntimeError(f"Collaudo post-importazione fallito: {key} non corrisponde alla sorgente.")
    eventi = {e["id"]: e for e in verifica["events"]}
    if len(eventi) != len(originali["events"]) + 1 or any(
            eventi.get(e["id"]) != e for e in originali["events"]):
        raise RuntimeError("Collaudo post-importazione fallito: storico eventi differente dalla sorgente.")
    if set(verifica["meta"].items()) != set(originali["meta"].items()):
        raise RuntimeError("Collaudo post-importazione fallito: identificativo o metadati differenti.")
    for documento in originali["documents"]:
        target._document_bytes(documento["sha"])
    controllo = target.export_backup(include_documents=True)
    try:
        Archive.verify_backup(controllo)
    finally:
        controllo.unlink(missing_ok=True)
    impronta_file = hashlib.sha256()
    with percorso.open("rb") as f:
        for blocco in iter(lambda: f.read(1024 * 1024), b""):
            impronta_file.update(blocco)
    conferma = {"archive_id": originali["meta"]["archive_id"],
                "impronta": impronta(originali),
                "backup_sha256": impronta_file.hexdigest(),
                "oggetti": len(originali["objects"]), "documenti": len(originali["documents"]),
                "eventi": len(originali["events"])}
    # La conferma non è scritta se un solo controllo precedente fallisce.
    target.mutate(lambda c: c.execute("INSERT INTO meta(key,value) VALUES(?,?)",
                                      (CHIAVE, json.dumps(conferma, sort_keys=True))))
    return {"oggetti": len(originali["objects"]), "documenti": len(originali["documents"]),
            "eventi_originali": len(originali["events"]), "archivio_id": originali["meta"]["archive_id"]}


def backup_dalla_cartella_dati(cfg) -> Path:
    """rc9 (punto A): backup completo dell'archivio verbali SQLite incorporato (verbali/archivio.sqlite), da importare
    poi in PostgreSQL. Il file resta nella cartella dei backup come copia di sicurezza della sorgente."""
    from datetime import datetime

    cartella = cfg.cartella_dati / "verbali"
    sorgente = cartella / "archivio.sqlite"
    if not sorgente.exists() or not sorgente.stat().st_size:
        raise ValueError(f"Nessun archivio verbali SQLite da migrare in {cartella}.")
    destinazione = cfg.cartella_dati / "backup" / f"verbali_sqlite_prima_della_migrazione_{datetime.now():%Y%m%d_%H%M%S}.adbackup.zip"
    destinazione.parent.mkdir(parents=True, exist_ok=True)
    return Path(Archive(cartella, cartella / "backups").export_backup(destinazione, include_documents=True))


def main() -> int:
    parser = argparse.ArgumentParser(description="Importa un backup completo VerbalizzAI nel database PostgreSQL di NEXUS.")
    parser.add_argument("backup", type=Path, nargs="?", help="backup completo .adbackup.zip da importare")
    parser.add_argument("--dalla-cartella-dati", action="store_true",
                        help="rc9: crea il backup completo dell'archivio verbali SQLite incorporato e lo importa")
    argomenti = parser.parse_args()
    if bool(argomenti.backup) == argomenti.dalla_cartella_dati:
        parser.error("indicare un backup oppure --dalla-cartella-dati")
    try:
        cfg = carica_config()
        percorso = argomenti.backup
        if argomenti.dalla_cartella_dati:
            percorso = backup_dalla_cartella_dati(cfg)
            print(f"Backup completo dell'archivio SQLite: {percorso}")
        risultato = importa(percorso, cfg)
    except (ValueError, RuntimeError, OSError) as errore:
        print(f"Importazione non confermata: {errore}", file=sys.stderr)
        return 1
    print("Importazione verificata:", risultato)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
