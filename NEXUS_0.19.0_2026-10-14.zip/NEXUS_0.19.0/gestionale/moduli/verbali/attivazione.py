"""Conferma della migrazione prima di aprire un vecchio archivio DPR su PostgreSQL.

Il marcatore viene scritto soltanto dopo il confronto integrale del backup
importato. Se il vecchio SQLite è ancora presente, deve essere proprio la
sorgente importata e non deve avere ricevuto ulteriori scritture.
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
from contextlib import closing
from pathlib import Path


CHIAVE = "nexus_importazione_verificata"
TABELLE = {
    "objects": "SELECT * FROM objects ORDER BY id",
    "events": "SELECT * FROM events ORDER BY created_at,id",
    "users": "SELECT * FROM users ORDER BY username",
    "documents": "SELECT sha,filename,created_at FROM documents ORDER BY sha",
}


def impronta(contenuto: dict) -> str:
    """Impronta delle righe originali, senza l'evento di ripristino aggiunto da NEXUS."""
    dati = {"meta": contenuto["meta"], **{tabella: contenuto[tabella] for tabella in TABELLE}}
    serializzato = json.dumps(dati, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(serializzato.encode("utf-8")).hexdigest()


def _istantanea_sqlite(percorso: Path) -> dict:
    # La connessione URI in sola lettura non crea un nuovo database né esegue
    # le migrazioni del motore VerbalizzAI sulla sorgente storica.
    with closing(sqlite3.connect(percorso.resolve().as_uri() + "?mode=ro", uri=True)) as c:
        c.row_factory = sqlite3.Row
        c.execute("BEGIN")
        risultato = {"meta": {r["key"]: r["value"] for r in c.execute("SELECT * FROM meta")}}
        risultato.update({nome: [dict(r) for r in c.execute(query)] for nome, query in TABELLE.items()})
        c.execute("COMMIT")
    return risultato


def verifica_archivio_precedente(target, percorso: Path) -> None:
    """Blocca l'avvio se SQLite non coincide con la sorgente importata."""
    if not percorso.exists() or not percorso.stat().st_size:
        return
    with target.connect() as c:
        riga = c.execute("SELECT value FROM meta WHERE key=?", (CHIAVE,)).fetchone()
    if not riga:
        raise RuntimeError("Archivio verbali SQLite presente: manca la conferma di importazione verificata in PostgreSQL. "
                           "Con NEXUS fermo esegui MIGRA_VERBALI_POSTGRESQL_WINDOWS.bat (oppure "
                           "python -m gestionale.moduli.verbali.importa_postgresql --dalla-cartella-dati), poi riavvia.")
    try:
        conferma = json.loads(riga[0])
        originale = _istantanea_sqlite(percorso)
        if (conferma["archive_id"] != originale["meta"]["archive_id"]
                or conferma["impronta"] != impronta(originale)):
            raise RuntimeError("Archivio verbali SQLite diverso dal backup importato o modificato dopo l'importazione.")
    except (sqlite3.Error, KeyError, TypeError, ValueError) as exc:
        raise RuntimeError("Impossibile verificare la corrispondenza dell'archivio verbali SQLite.") from exc
