"""Archivio dei verbali: lo stesso di VerbalizzAI (storage.Archive), con utenti, permessi e posta del gestionale (D67).

- Il file `verbali/archivio.sqlite` e i documenti dei verbali stanno nella cartella dei dati del gestionale e finiscono
  nei suoi backup.
- Utenti: quelli del gestionale (nessun utente o password propria di VerbalizzAI).
- Permessi: quelli del gestionale, tradotti nei permessi di VerbalizzAI (PERMESSI); l'utente della richiesta
  in corso, con i permessi, è fornito dal ponte (`imposta_utente_corrente`).
- Impianti di VerbalizzAI («plant»): sono sedi del gestionale; `data.sede_id` e `data.impianti` {modulo: impianto_id}
  li collegano. Ragione sociale, sede e indirizzo vengono sempre dal gestionale.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from sqlalchemy import select

from ...terzi.verbalizzai import mailer
from ...terzi.verbalizzai.storage import Archive
from .postgresql import ArchivioPostgresql

# Permesso di VerbalizzAI → permesso del gestionale (None = mai: lo gestisce il gestionale)
PERMESSI = {
    "import": "anagrafica.importa", "draft": "verifiche.esegui", "issue": "verifiche.esegui", "send": "verifiche.esegui",
    "revision": "verifiche.revisione", "draft_delete": "verifiche.esegui", "plant": None,
    "plant_technical": "impianti.stato_tecnico", "templates": "sistema.modelli",
    "instruments_view": "strumenti.vedere", "instruments": "strumenti.gestire", "signatures_view": "firme.vedere",
    "signatures": "firme.gestire", "annul": "verifiche.annulla", "oplog": "sistema.registro", "backup": "sistema.backup",
    "users": "sistema.impostazioni",
}
RUOLI = {"amministratore": "admin", "responsabile_tecnico": "rt", "tecnico": "tecnico", "segreteria": "segreteria",
         "responsabile_tecnico_dm": "rt", "tecnico_dm": "tecnico", "tecnico_dm_dpr": "tecnico"}


def permessi_vz(u: Any) -> list[str]:
    """VerbalizzAI è il modulo dei verbali AD_DPR: i permessi tecnici valgono solo per chi lavora nel DPR (R132)."""
    return [k for k, g in PERMESSI.items() if g and u.puo(g, "DPR")]


class PostaVerbali(mailer.MailConfig):
    """Server di posta: quello del gestionale (Sistema › Impostazioni email), nel formato di VerbalizzAI."""

    def __init__(self, cartella_dati: Path) -> None:
        from ...core.posta import ImpostazioniPosta

        self.gestionale = ImpostazioniPosta(cartella_dati, "DPR")  # C15: i verbali di VerbalizzAI sono AD_DPR
        self.path = self.gestionale.percorso

    def load(self) -> dict:
        c = self.gestionale.leggi()
        return {"host": c["server"], "port": c["porta"], "security": {"nessuna": "none"}.get(c["sicurezza"], c["sicurezza"]),
                "username": c["utente"], "password": c.get("password", ""), "from_address": c["mittente"], "from_name": c["nome_mittente"],
                "office_copy": c.get("copia_ufficio", "")}

    def save(self, data: dict) -> dict:  # noqa: ARG002
        raise ValueError("Il server di posta si imposta nel gestionale: Sistema › Impostazioni email.")


class ArchivioVerbali(Archive):
    def __init__(self, cartella: Path, gestionale: Any) -> None:
        self.gestionale = gestionale  # Archivio del gestionale (database principale)
        super().__init__(cartella, cartella / "backups")

    # ---- utenti: quelli del gestionale -------------------------------------------------------
    def users(self) -> list[dict]:
        from ..utenti.modelli import Utente, ruoli_di
        from ..utenti.servizio import ruolo_vz

        with self.gestionale.lettura() as s:
            return [{"username": u.username, "name": u.nome, "role": RUOLI.get(ruolo_vz(ruoli_di(u)), "tecnico"), "active": bool(u.attivo),
                     "created_at": u.creato_il.isoformat() if u.creato_il else ""}
                    for u in s.execute(select(Utente).order_by(Utente.nome)).scalars()]

    def has_users(self) -> bool:
        return True

    def imposta_utente_corrente(self, utente_vz: dict | None) -> None:
        """Il ponte registra l'utente della richiesta in corso (con i permessi tradotti dal gestionale)."""
        self._local.utente_corrente = utente_vz

    def user(self, username):  # noqa: ANN001, ANN201
        """Utente con i suoi permessi: VerbalizzAI lo rilegge per esempio all'emissione (permesso sullo stato tecnico)."""
        corrente = getattr(self._local, "utente_corrente", None)
        nome = str(username or "").strip().lower()
        if corrente and corrente.get("username", "").lower() == nome:
            return corrente
        return next((dict(u, perms=[]) for u in self.users() if u["username"].lower() == nome), None)

    def authenticate(self, username, password):  # noqa: ANN001, ANN201, ARG002
        return None  # l'accesso è quello del gestionale

    def add_user(self, *a, **k):  # noqa: ANN002, ANN003, ANN201
        raise ValueError("Gli utenti si gestiscono nel gestionale: Sistema › Utenti.")

    def update_user(self, *a, **k):  # noqa: ANN002, ANN003, ANN201
        raise ValueError("Gli utenti si gestiscono nel gestionale: Sistema › Utenti.")

    # ---- strumenti di misura: quelli di NEXUS (rc9, punto C) ---------------------------------
    # Il registro strumenti AD_DPR è il modulo Strumenti di NEXUS (attività DPR). Il motore li legge da qui con lo stesso
    # formato dei suoi oggetti «instrument»: la bozza propone quelli attivi assegnati al verificatore e il verbale li
    # copia come prima (le righe nel verbale sono copie: i verbali già emessi non cambiano).
    def all(self, kind=None):  # noqa: ANN001, ANN201
        if kind == "instrument":
            return self.strumenti_nexus()
        return super().all(kind)

    def strumenti_del_registro(self) -> list[dict]:
        """Strumenti rimasti nel registro proprio di VerbalizzAI (archivi precedenti alla rc9), da importare in NEXUS."""
        return super().all("instrument")

    def strumenti_nexus(self) -> list[dict]:
        from ..strumenti.modelli import StrumentoMisura
        from ..utenti.modelli import Utente

        def gg(d):  # noqa: ANN001, ANN202
            return d.strftime("%d/%m/%Y") if d else ""

        with self.gestionale.lettura() as s:
            nomi = dict(s.execute(select(Utente.id, Utente.nome)).all())
            righe = s.execute(select(StrumentoMisura).where(StrumentoMisura.attivita == "DPR")
                              .order_by(StrumentoMisura.codice, StrumentoMisura.id)).scalars().all()
            return [{"id": f"nexus-{x.id}", "kind": "instrument", "revision": x.versione,
                     "updated_at": x.modificato_il.isoformat() if x.modificato_il else "", "updated_by": x.modificato_da or "",
                     "data": {"code": x.codice or "", "type": x.denominazione, "brand": x.costruttore or "", "model": x.modello or "",
                              "serial": x.matricola or "", "calibration": gg(x.data_taratura), "calibration_due": gg(x.scadenza_taratura),
                              "internal_check": gg(x.controllo_intermedio), "internal_check_due": gg(x.scadenza_controllo_intermedio),
                              "assigned_to": nomi.get(x.assegnato_id, "") if x.assegnato_id else "",
                              "status": x.stato_operativo or ("Attivo" if x.attivo else "Non attivo"), "active": bool(x.attivo)}}
                    for x in righe]

    # ---- permessi: quelli del gestionale -----------------------------------------------------
    def perms_of(self, user):  # noqa: ANN001, ANN201
        return list((user or {}).get("perms") or [])

    def can(self, user, perm):  # noqa: ANN001, ANN201
        return perm in self.perms_of(user)


class ArchivioVerbaliPostgresql(ArchivioVerbali, ArchivioPostgresql):
    """Stesse regole di accesso NEXUS, con i documenti DPR nel database comune."""

    def __init__(self, cartella: Path, gestionale: Any) -> None:
        self.gestionale = gestionale
        ArchivioPostgresql.__init__(self, cartella, gestionale.cfg.database_url)
