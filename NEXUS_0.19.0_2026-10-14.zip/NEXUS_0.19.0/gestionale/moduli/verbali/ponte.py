"""Ponte tra le richieste del gestionale e le funzioni del server di VerbalizzAI (app.Handler), usate senza modifiche.

Ogni richiesta a /verbali/api/… diventa una chiamata a `Handler.do_GET` / `do_POST` di VerbalizzAI con:
- l'utente e i permessi del gestionale (niente accesso, sessioni o password di VerbalizzAI);
- il token anti-contraffazione della sessione del gestionale (VerbalizzAI lo manda come «X-AD-Token»);
- l'archivio dei verbali del gestionale e la posta del gestionale.
Le funzioni che nel gestionale esistono già (utenti, permessi, backup, accesso) non passano dal ponte.
"""

from __future__ import annotations

import io
import json
import threading
from typing import Any

from ...terzi.verbalizzai import app as vz
from .archivio import RUOLI, permessi_vz

# Funzioni di VerbalizzAI che nel gestionale non si usano (le fa il gestionale)
ESCLUSE = {"/api/login", "/api/logout", "/api/setup", "/api/password", "/api/users", "/api/users/add", "/api/users/update",
           "/api/permissions", "/api/backup", "/api/backup/local", "/api/backup/verify", "/api/backup/restore",
           "/api/backup/restore-local", "/api/plant/update", "/api/plant/new", "/api/plant/delete", "/api/draft/new",
           # rc9 (punto C): il registro strumenti AD_DPR è in NEXUS
           "/api/instrument/save", "/api/instrument/import/preview", "/api/instrument/import/commit"}
# Anagrafica unica (0.6.0): clienti, sedi e impianti si creano, correggono ed eliminano solo nel gestionale.
MESSAGGI = {"/api/plant/update": "L'anagrafica (cliente, sede, indirizzo) si corregge nel gestionale: Lavoro › Clienti / Sedi operative / Impianti.",
            "/api/plant/new": "I nuovi clienti, sedi e impianti si registrano nel gestionale (Lavoro › Impianti); il verbale nasce dalla verifica: Lavoro › Verifiche › «Compila il verbale».",
            "/api/draft/new": "Nel gestionale il verbale nasce dalla verifica, che gli dà il numero: Lavoro › Verifiche › «Compila il verbale».",
            "/api/plant/delete": "Gli impianti si eliminano o si dismettono nel gestionale: Lavoro › Impianti.",
            "/api/backup": "I backup comprendono i verbali: Sistema › Backup e integrità del gestionale.",
            **{k: "Gli strumenti di misura AD_DPR si gestiscono in NEXUS: Gestione › Configurazione › Strumenti di misura."
               for k in ("/api/instrument/save", "/api/instrument/import/preview", "/api/instrument/import/commit")}}


class _Intestazioni(dict):
    def get(self, chiave, predefinito=None):  # noqa: ANN001, ANN201
        for k, v in self.items():
            if k.lower() == chiave.lower():
                return v
        return predefinito


class _Server:
    def __init__(self, archivio: Any, posta: Any) -> None:
        self.archive, self.mail = archivio, posta
        self.sessions = vz.Sessions()
        self.server_mode, self.tls, self.allowed_hosts = True, False, set()


class Ponte(vz.Handler):
    """Un «Handler» di VerbalizzAI senza rete: legge la richiesta da memoria e restituisce stato, intestazioni e corpo."""

    def __init__(self, server: _Server, utente: Any, csrf: str, metodo: str, percorso: str, corpo: bytes, intestazioni: dict) -> None:
        self.server, self.utente_gestionale, self.csrf_gestionale = server, utente, csrf
        self.command, self.path = metodo, percorso
        self.headers = _Intestazioni({**intestazioni, "Content-Length": str(len(corpo or b""))})
        self.rfile, self.client_address = io.BytesIO(corpo or b""), ("127.0.0.1", 0)
        self.stato, self.uscita, self.corpo = 200, [], b""

    # ---- risposta in memoria ---------------------------------------------------------------
    def send_response(self, code, message=None):  # noqa: ANN001, ANN201, ARG002
        self.stato = code

    def send_header(self, chiave, valore):  # noqa: ANN001, ANN201
        if chiave.lower() not in ("set-cookie", "content-security-policy", "content-length"):
            self.uscita.append((chiave, valore))

    def end_headers(self):  # noqa: ANN201
        pass

    def send(self, status, data, ctype="application/json; charset=utf-8", filename=None, cookie=None, inline_pdf=False):  # noqa: ANN001, ANN201, ARG002
        if isinstance(data, (dict, list)):
            data = json.dumps(data, ensure_ascii=False).encode("utf-8")
        elif isinstance(data, str):
            data = data.encode("utf-8")
        self.stato, self.corpo = status, data
        self.uscita.append(("Content-Type", ctype))
        self.headers_common(filename, inline_pdf=inline_pdf)  # PDF «inline»: anteprima nella finestra (VerbalizzAI 0.3.31)

    def send_path(self, path, filename, remove=False):  # noqa: ANN001, ANN201
        try:
            self.send(200, path.read_bytes(), "application/zip", filename)
        finally:
            if remove and path.exists():
                path.unlink()

    # ---- accesso: utente e permessi del gestionale --------------------------------------------
    def guard(self, path, mutation=False):  # noqa: ANN001, ANN201
        a = self.server.archive
        a.set_actor("")
        a.imposta_utente_corrente(None)
        self.session = {"user": self.utente_gestionale.username, "csrf": self.csrf_gestionale}
        if path in ESCLUSE:
            raise PermissionError(MESSAGGI.get(path, "Questa funzione nel gestionale si trova nel menu Sistema."))
        if mutation and self.headers.get("X-AD-Token") != self.csrf_gestionale:
            raise PermissionError("Sessione non valida: ricaricare la pagina.")
        u = self.utente_gestionale
        self.user = {"username": u.username, "name": u.nome, "role": RUOLI.get(getattr(u, "ruolo_codice", ""), "tecnico"),
                     "active": True, "perms": permessi_vz(u)}
        need = vz.NEEDS.get(path)
        if need and not a.can(self.user, need):
            raise PermissionError("Il tuo ruolo non ha il permesso: " + vz.PERM_LABEL[need] + ". Chiedere all'amministratore (Ruoli e permessi).")
        a.imposta_utente_corrente(self.user)
        a.set_actor(u.username)

    def me(self) -> dict:
        self.guard("/api/me")
        return {"user": self.user, "csrf": self.csrf_gestionale, "version": vz.APP_VERSION, "server": True, "perms": self.user["perms"],
                "roles": vz.ROLE_LABELS, "permission_list": vz.PERMISSIONS, "gestionale": True}


_blocco = threading.Lock()
_server: _Server | None = None


def server(archivio: Any, posta: Any) -> _Server:
    global _server
    with _blocco:
        if _server is None or _server.archive is not archivio:
            _server = _Server(archivio, posta)
        return _server


def esegui(srv: _Server, utente: Any, csrf: str, metodo: str, percorso: str, corpo: bytes, intestazioni: dict) -> tuple[int, list, bytes]:
    p = Ponte(srv, utente, csrf, metodo, percorso, corpo, intestazioni)
    if percorso.split("?")[0] == "/api/me":
        try:
            dati = p.me()
            return 200, [("Content-Type", "application/json; charset=utf-8")], json.dumps(dati, ensure_ascii=False).encode()
        except PermissionError as e:
            return 403, [("Content-Type", "application/json; charset=utf-8")], json.dumps({"error": str(e)}).encode()
    if metodo == "GET":
        p.do_GET()
    else:
        p.do_POST()
    return p.stato, p.uscita, p.corpo
