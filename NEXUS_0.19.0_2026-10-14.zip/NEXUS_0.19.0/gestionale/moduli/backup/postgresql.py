"""Backup PostgreSQL con pg_dump/pg_restore e documenti coordinati.

Il server e le utility native devono essere collaudati nell'ambiente di destinazione.
Il ripristino richiede un fermo operativo; un marcatore impedisce la riapertura
silenziosa se il processo si interrompe fra database e documenti.
"""
from __future__ import annotations

from contextlib import nullcontext
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import tempfile
import zipfile
from uuid import uuid4

from sqlalchemy import and_, delete, func, select, text
from sqlalchemy.engine import make_url

from ... import VERSIONE
from ...core import migrazioni
from ...core.errori import ErroreUtente
from ..registro import servizio as registro
from ..utenti import servizio as utenti
from ..utenti.modelli import Sessione, Utente


def _utility(nome):
    directory = os.environ.get("GESTIONALE_PG_BIN", "")
    p = Path(directory) / (nome + (".exe" if os.name == "nt" else "")) if directory else None
    trovato = str(p) if p is not None and p.is_file() else shutil.which(nome)
    if not trovato:
        raise ErroreUtente(f"Utility {nome} non disponibile: configurare le utility PostgreSQL dell'ambiente.")
    return trovato


def _ambiente(cfg):
    url = make_url(cfg.database_url)
    if not url.database:
        raise ErroreUtente("La connessione PostgreSQL deve indicare un database dedicato.")
    env = {k: v for k, v in os.environ.items() if not k.startswith("PG")}
    env.update(PGDATABASE=url.database, PGHOST=url.host or "", PGPORT=str(url.port or 5432),
               PGUSER=url.username or "", PGCONNECT_TIMEOUT="15")
    if url.password is not None:
        env["PGPASSWORD"] = url.password
    for chiave in ("sslmode", "sslrootcert", "sslcert", "sslkey"):
        if chiave in url.query:
            env["PG" + chiave.upper()] = str(url.query[chiave])
    return env


def _esegui(cfg, nome, argomenti):
    try:
        p = subprocess.run([_utility(nome), *map(str, argomenti)], env=_ambiente(cfg),
                           capture_output=True, timeout=600, check=False)
    except (OSError, subprocess.TimeoutExpired):
        raise ErroreUtente(f"Operazione {nome} non completata; controllare disponibilità e tempi del server.") from None
    if p.returncode:
        # Non esporre URL, credenziali o contenuti del dump restituiti da un processo esterno.
        raise ErroreUtente(f"Operazione {nome} non riuscita; controllare server, credenziali e versione delle utility.")
    return p.stdout


def _revisione(arc):
    with arc.lettura() as s:
        return s.execute(text("SELECT version_num FROM alembic_version")).scalar()


def crea(arc, tipo, attore=None, registra=True):
    from . import servizio as backup
    cfg = arc.cfg
    destinazione = backup._nome_nuovo(cfg.cartella_backup, tipo)
    provvisorio = destinazione.with_suffix(".tmp")
    vz = getattr(arc, "verbali", None)
    try:
        with arc.esclusivo(), vz.lock if vz is not None else nullcontext():
            with tempfile.TemporaryDirectory(dir=cfg.cartella_temporanea) as temp:
                temp = Path(temp)
                dump = temp / "database.pgdump"
                _esegui(cfg, "pg_dump", ["--format=custom", "--no-owner", "--no-privileges", "--file", dump])
                revisione = _revisione(arc)
                manifest = {"programma": "NEXUS", "backend": "postgresql", "versione_programma": VERSIONE,
                    "revisione_schema": revisione, "creato_il": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                    "tipo": tipo, "file": []}
                with zipfile.ZipFile(provvisorio, "w", zipfile.ZIP_DEFLATED) as z:
                    def aggiungi(p, relativo):
                        z.write(p, relativo)
                        manifest["file"].append({"percorso": relativo, "sha256": backup._sha256_file(p),
                                                 "dimensione": p.stat().st_size})
                    aggiungi(dump, "database.pgdump")
                    if vz is not None and not arc.cfg.verbali_in_postgresql:
                        copia = temp / "verbali.adbackup.zip"
                        vz.export_backup(copia, include_documents=True)
                        aggiungi(copia, "verbali/verbali.adbackup.zip")
                    for p in sorted(cfg.cartella_documenti.rglob("*")):
                        if p.is_file() and not p.name.endswith(".tmp"):
                            aggiungi(p, "documenti/" + p.relative_to(cfg.cartella_documenti).as_posix())
                    z.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=1))
                os.replace(provvisorio, destinazione)
            if registra:
                with arc.scrittura() as s:
                    registro.scrivi(s, utente=attore, azione="backup.crea", oggetto_tipo="backup",
                        oggetto_id=destinazione.name, descrizione="Creato backup PostgreSQL completo.")
    except BaseException:
        provvisorio.unlink(missing_ok=True)
        raise
    if tipo == "automatico":
        backup.pulisci_automatici(arc, tieni=destinazione)
    return backup.info(destinazione)


def verifica_file(arc, p):
    if not arc.cfg.postgresql:
        return {"valido": False, "problemi": ["Backup PostgreSQL: ripristinarlo nell'ambiente PostgreSQL."]}
    problemi = []
    revisione = None
    try:
        with zipfile.ZipFile(p) as z:
            m = json.loads(z.read("manifest.json"))
            revisione = m.get("revisione_schema")
            nomi = z.namelist()
            if len(nomi) != len(set(nomi)):
                raise ValueError("Nomi duplicati nell'archivio.")
            for nome in nomi:
                r = PurePosixPath(nome)
                if r.is_absolute() or ".." in r.parts or "\\" in nome or ":" in nome:
                    raise ValueError("Percorso non valido nell'archivio.")
            indicati = {x["percorso"] for x in m["file"]}
            if indicati != set(nomi) - {"manifest.json"} or "database.pgdump" not in indicati:
                raise ValueError("Manifest e contenuto del backup discordanti.")
            for x in m["file"]:
                h = hashlib.sha256()
                with z.open(x["percorso"]) as f:
                    for b in iter(lambda: f.read(1 << 20), b""):
                        h.update(b)
                if h.hexdigest() != x["sha256"] or z.getinfo(x["percorso"]).file_size != x["dimensione"]:
                    problemi.append("File alterato o danneggiato: " + x["percorso"])
            with tempfile.TemporaryDirectory(dir=arc.cfg.cartella_temporanea) as temp:
                dump = Path(temp) / "database.pgdump"
                dump.write_bytes(z.read("database.pgdump"))
                if dump.open("rb").read(5) != b"PGDMP":
                    raise ValueError("Il database non è un dump PostgreSQL custom.")
                _esegui(arc.cfg, "pg_restore", ["--list", dump])
                sql = _esegui(arc.cfg, "pg_restore", ["--data-only", "--table=alembic_version", "--file=-", dump]).decode("utf-8")
                trovato = re.search(r"COPY [^\n]*alembic_version[^\n]*\n([^\n]+)\n", sql)
                if not trovato or trovato[1].strip() != revisione:
                    problemi.append("Versione schema nel dump discordante dal manifest.")
            if revisione not in migrazioni.revisioni_note():
                problemi.append("Versione schema non riconosciuta.")
    except (zipfile.BadZipFile, KeyError, ValueError, OSError, ErroreUtente) as e:
        problemi.append(e.messaggio if isinstance(e, ErroreUtente) else "Backup non leggibile o struttura non valida.")
    return {"valido": not problemi, "problemi": problemi, "revisione_schema": revisione,
            "versione_programma": m.get("versione_programma") if 'm' in locals() else None,
            "file_controllati": len(m.get("file", [])) if 'm' in locals() else 0}


def ripristina(arc, nome, attore):
    # Fermo esplicito: la normale interfaccia non dichiara concluso un ripristino non collaudato.
    raise ErroreUtente("Il ripristino PostgreSQL richiede il fermo applicativo e la procedura di collaudo dedicata; "
                       "non è abilitato dall'interfaccia in questa versione preliminare.")


def ripristina_a_fermo(arc, nome, attore):
    """Procedura amministrativa di collaudo. Richiede app ferma e lo stesso schema.

    pg_restore usa una transazione; il backup di sicurezza recupera un errore
    successivo sui file. Il marcatore resta se anche il recupero fallisce.
    Non è una transazione distribuita e non viene descritta come tale.
    """
    from . import servizio as backup
    p = backup.percorso_sicuro(arc, nome)
    esito = verifica_file(arc, p)
    if not esito["valido"]:
        raise ErroreUtente("Backup non valido: " + "; ".join(esito["problemi"]))
    if esito["revisione_schema"] != migrazioni.revisione_programma():
        raise ErroreUtente("Il ripristino PostgreSQL preliminare richiede la stessa versione dello schema.")
    marker = arc.cfg.cartella_dati / "ripristino_postgresql_in_corso.json"
    if marker.exists():
        raise ErroreUtente("Un precedente ripristino richiede recupero: il marcatore è ancora presente.")
    vecchi = arc.cfg.cartella_dati / ("documenti_prima_ripristino_" + uuid4().hex)
    vz = getattr(arc, "verbali", None)
    with arc.esclusivo(), vz.lock if vz is not None else nullcontext():
        sicurezza = crea(arc, "pre_ripristino", attore)
        precedente = backup.percorso_sicuro(arc, sicurezza["nome"])
        marker.write_text(json.dumps({"backup": nome, "sicurezza": sicurezza["nome"],
                                    "vecchi_documenti": vecchi.name}, indent=2))
        database_cambiato = False
        documenti_spostati = False
        with tempfile.TemporaryDirectory(dir=arc.cfg.cartella_temporanea) as temp:
            temp = Path(temp)
            with zipfile.ZipFile(p) as z:
                z.extractall(temp)
            nuovi = temp / "documenti"
            nuovi.mkdir(exist_ok=True)
            try:
                # Anche un timeout può avvenire dopo il commit del server: il recupero
                # usa comunque il backup precedente, senza presumere l'esito.
                database_cambiato = True
                _esegui(arc.cfg, "pg_restore", ["--clean", "--if-exists", "--single-transaction", "--no-owner",
                                             "--no-privileges", "--dbname", _ambiente(arc.cfg)["PGDATABASE"],
                                             temp / "database.pgdump"])
                if _revisione(arc) != esito["revisione_schema"]:
                    raise ErroreUtente("Versione ripristinata discordante dal backup.")
                backup._sposta(arc.cfg.cartella_documenti, vecchi)
                documenti_spostati = True
                backup._sposta(nuovi, arc.cfg.cartella_documenti)
                copia_vz = temp / "verbali/verbali.adbackup.zip"
                if vz is not None and not arc.cfg.verbali_in_postgresql:
                    if not copia_vz.is_file():
                        raise ErroreUtente("Manca l'archivio VerbalizzAI nel backup completo.")
                    vz.set_actor(attore.nome)
                    vz.restore(copia_vz.read_bytes())
                with arc.scrittura() as s:
                    s.execute(delete(Sessione))
                    presente = s.get(Utente, attore.id) if attore.id else None
                    chi = attore if presente is not None and presente.nome == attore.nome else utenti.Attore(id=None, nome=attore.nome)
                    registro.scrivi(s, utente=chi, azione="backup.ripristino", oggetto_tipo="backup", oggetto_id=nome,
                        descrizione="Ripristinato backup PostgreSQL a fermo applicativo.",
                        dettagli={"backup_di_sicurezza": sicurezza["nome"]})
            except BaseException as errore:
                try:
                    if database_cambiato:
                        ripresa = temp / "ripresa"
                        with zipfile.ZipFile(precedente) as z:
                            z.extractall(ripresa)
                        _esegui(arc.cfg, "pg_restore", ["--clean", "--if-exists", "--single-transaction", "--no-owner",
                            "--no-privileges", "--dbname", _ambiente(arc.cfg)["PGDATABASE"], ripresa / "database.pgdump"])
                        if vz is not None and not arc.cfg.verbali_in_postgresql:
                            vz.restore((ripresa / "verbali/verbali.adbackup.zip").read_bytes())
                    if documenti_spostati:
                        backup._rimuovi_cartella(arc.cfg.cartella_documenti)
                        backup._sposta(vecchi, arc.cfg.cartella_documenti)
                    marker.unlink()
                except BaseException:
                    raise ErroreUtente("Ripristino interrotto: mantenere l'applicazione ferma e recuperare dal backup di sicurezza indicato nel marcatore.") from None
                raise ErroreUtente("Ripristino non completato; lo stato precedente è stato recuperato.") from errore
            marker.unlink()
        backup._rimuovi_cartella(vecchi)
    return {"ripristinato": nome, "backup_di_sicurezza": sicurezza["nome"]}


def controllo_logico(s):
    from ...modelli import Base
    problemi = []
    if s.execute(text("SELECT count(*) FROM pg_constraint WHERE connamespace="
        "(SELECT oid FROM pg_namespace WHERE nspname=current_schema()) AND NOT convalidated")).scalar():
        problemi.append("Vincoli non validati")
    for tabella in Base.metadata.sorted_tables:
        for fk in tabella.foreign_key_constraints:
            padre = fk.referred_table.alias()
            unione = and_(*(x.parent == padre.c[x.column.name] for x in fk.elements))
            presente = and_(*(x.parent.is_not(None) for x in fk.elements))
            assente = padre.c[fk.elements[0].column.name].is_(None)
            numero = s.execute(select(func.count()).select_from(tabella.outerjoin(padre, unione))
                               .where(presente, assente)).scalar()
            if numero:
                problemi.append(f"{tabella.name}: {numero} riferimenti orfani")
    return ("ok" if not problemi else "Controlli logici PostgreSQL non superati"), problemi
