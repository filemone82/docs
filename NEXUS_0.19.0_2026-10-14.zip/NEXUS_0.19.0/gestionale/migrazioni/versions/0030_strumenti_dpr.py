"""rc9 punto C (Federico, 14/10/2026): strumenti di misura AD_DPR nel modulo Strumenti di NEXUS.

Prima stavano nel registro di VerbalizzAI (oggetti «instrument»). Si aggiungono i campi di quel registro (codice interno,
assegnatario, controllo intermedio, stato operativo) e l'attività DPR. Nessun dato viene spostato qui: l'importazione
degli strumenti del registro si fa da «Strumenti di misura» (AD_DPR) o nella migrazione dei dati.
"""
import sqlalchemy as sa
from alembic import op

revision = "0030"
down_revision = "0029"
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table("strumenti_misura", recreate="always") as b:
        b.drop_constraint(op.f("ck_strumenti_misura_attivita"), type_="check")
        b.create_check_constraint(op.f("ck_strumenti_misura_attivita"), "attivita IN ('DPR','DM','IEC')")
        b.add_column(sa.Column("codice", sa.String(length=60), nullable=False, server_default=""))
        b.add_column(sa.Column("assegnato_id", sa.Integer(), nullable=True))
        b.add_column(sa.Column("controllo_intermedio", sa.Date(), nullable=True))
        b.add_column(sa.Column("scadenza_controllo_intermedio", sa.Date(), nullable=True))
        b.add_column(sa.Column("stato_operativo", sa.String(length=40), nullable=False, server_default="Attivo"))
        b.create_foreign_key(op.f("fk_strumenti_misura_assegnato_id_utenti"), "utenti", ["assegnato_id"], ["id"], ondelete="RESTRICT")
        b.create_index(op.f("ix_strumenti_misura_assegnato_id"), ["assegnato_id"])


def downgrade():
    op.execute(sa.text("DELETE FROM strumenti_misura WHERE attivita = 'DPR'"))
    with op.batch_alter_table("strumenti_misura", recreate="always") as b:
        b.drop_index(op.f("ix_strumenti_misura_assegnato_id"))
        b.drop_constraint(op.f("fk_strumenti_misura_assegnato_id_utenti"), type_="foreignkey")
        for c in ("stato_operativo", "scadenza_controllo_intermedio", "controllo_intermedio", "assegnato_id", "codice"):
            b.drop_column(c)
        b.drop_constraint(op.f("ck_strumenti_misura_attivita"), type_="check")
        b.create_check_constraint(op.f("ck_strumenti_misura_attivita"), "attivita IN ('DM','IEC')")
