"""NEXUS (Gestionale AD integrato) — gestionale dell'organismo di ispezione AD S.r.l. (D.P.R. 462/01).

Documentazione di progetto: documenti 01–07 del progetto claude.ai «Gestionale completo AD_dpr».
Le decisioni citate nei commenti (es. D24) sono nel documento 02 «Registro delle decisioni».
"""

VERSIONE = "0.19.0"
