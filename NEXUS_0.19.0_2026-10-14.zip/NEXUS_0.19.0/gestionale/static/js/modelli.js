/* Modelli Word come documenti controllati: in uso / superati, caricamento di una nuova revisione. */
"use strict";

(async () => {
  const { el, api, toast, errore, formatta, scarica } = GAD;
  const S = GAD.schede;
  const { f, campo } = S;
  const box = document.getElementById("modelli");
  async function disegna() {
    // C16 (0.16): ogni attività vede e carica solo i suoi modelli
    const att = document.documentElement.dataset.ambito || "DPR";
    const PER_ATT = { DPR: ["preventivo"], DM: ["preventivo_dm", "verbale_dm_gvr", "verbale_dm_scsp"], IEC: ["preventivo_iec"] };
    const ammessi = PER_ATT[att] || PER_ATT.DPR;
    const elenco = (await api("GET", "/api/modelli")).filter((x) => ammessi.includes(x.tipo));
    const file = el("input", { type: "file", accept: ".docx" });
    const m = { codice: f.testo("M01-RG01_dpr"), revisione: f.testo("", { placeholder: "es. 04" }), descrizione: f.area("", { rows: "2" }) };
    const inUso = f.casella("Metti subito in uso (il precedente diventa superato)", true);
    const tipo=f.scelta([{valore:"preventivo",testo:"Preventivo DPR"},{valore:"preventivo_dm",testo:"Preventivo DM"},
      {valore:"verbale_dm_gvr",testo:"Verbale DM GVR"},{valore:"verbale_dm_scsp",testo:"Verbale DM SC/SP"},{valore:"preventivo_iec",testo:"Preventivo I&C"}]
      .filter((x)=>ammessi.includes(x.valore)),ammessi[0]);
    box.replaceChildren(
      ...(att === "DPR" ? [await pannelloVerbaliDpr()] : []),
      el("div", { class: "panel" }, el("h3", {}, `Modelli · ${{ DPR: "AD_DPR", DM: "AD_DM", IEC: "I&C" }[att] || "AD_DPR"}`),
        el("p", { class: "subtle" }, "Ogni documento generato registra il modello usato. Segnaposto dell'offerta: {{cli.rag_soc}}, {{cli.indirizzo}}, {{cli.cap}}, {{cli.comune}}, {{p.anno_numero_preventivo}}, {{p.data_preventivo}}, {{p.totale_dec}}, {{p.termini_di_pagamento}}, {{p.termine_esecuzione}}; righe tra {{#r}} e {{/r}} con {{r.rpt_nome_sede}}, {{r.rpt_indirizzo}}, {{r.rpt_comune}}, {{r.rpt_tipo_impianto}}, {{r.rpt_pot_impianto}}, {{r.tariffa_applicata}} (anche {{r.tariffa_standard}}, {{r.sconto}}, {{r.tipo_verifica}}). Altri: {{cli.piva}}, {{cli.cf}}, {{p.rif_ordine}}, {{p.commerciale}}."),
        S.tabella([
          { titolo: "Tipo", valore: (x) => x.tipo_testo }, { titolo: "Codice", valore: (x) => x.codice }, { titolo: "Rev.", valore: (x) => x.revisione },
          { titolo: "Stato", valore: (x) => el("span", { class: "badge " + (x.in_uso ? "ok" : x.stato === "da approvare" ? "avviso" : "grigio") }, x.stato || (x.in_uso ? "in uso" : "superato")) },
          { titolo: "Caricato", valore: (x) => `${formatta.dataora(x.caricato_il)} · ${x.caricato_da}` }, { titolo: "Descrizione", valore: (x) => x.descrizione },
          { titolo: "", valore: (x) => el("span", { class: "actions" },
            el("button", { class: "btn small", type: "button", onclick: () => scarica("GET", `/api/modelli/${x.id}/file`, undefined, x.nome_file || "modello.docx").catch(errore) }, "Scarica"),
            x.in_uso ? null : el("button", { class: "btn small", type: "button", onclick: async () => { try { await api("POST", `/api/modelli/${x.id}/in-uso`); toast("Modello in uso."); disegna(); } catch (e) { errore(e); } } }, "Metti in uso")) },
        ], elenco)),
      el("div", { class: "panel" }, el("h3", {}, "Carica una nuova revisione"),
        el("div", { class: "field-grid" }, campo("Tipo",tipo),campo("File Word (.docx)", file, { pieno: true }), campo("Codice", m.codice), campo("Revisione", m.revisione),
          campo("Descrizione / modifiche", m.descrizione, { pieno: true }), el("div", { class: "field full" }, inUso.el)),
        el("div", { class: "actions" }, S.azione("Carica", "primary", async () => {
          if (!file.files[0]) throw new Error("Scegli il file Word.");
          const dati = new FormData();
          dati.append("file", file.files[0]); dati.append("tipo", tipo.value); dati.append("codice", m.codice.value);
          dati.append("revisione", m.revisione.value); dati.append("descrizione", m.descrizione.value); dati.append("in_uso", inUso.valore ? "true" : "false");
          await api("POST", "/api/modelli", dati); toast("Modello caricato."); disegna();
        }))));
  }
  // rc9 (punto D): modelli Word dei verbali DPR (M01, M02, M03), prima nel menu «Template Word» di VerbalizzAI.
  // Il più recente di ogni modulo è in uso; i precedenti restano consultabili; si elimina solo un modello mai usato.
  async function pannelloVerbaliDpr() {
    const { modelli } = await api("GET", "/api/modelli-verbali-dpr");
    const file = el("input", { type: "file", accept: ".docx" });
    const gestisce = S.puo("sistema.modelli");
    const azioni = (x) => el("span", { class: "actions" },
      el("button", { class: "btn small", type: "button", onclick: () => scarica("GET", `/api/modelli-verbali-dpr/${x.id}/file`, undefined, x.nome || "modello.docx").catch(errore) }, "Scarica"),
      gestisce && x.in_uso ? el("button", { class: "btn small", type: "button", title: "Le bozze aperte senza modello valido usano questo", onclick: async () => {
        try { const r = await api("POST", `/api/modelli-verbali-dpr/${x.id}/associa`, { tutte: false }); toast(`Modello associato a ${r.bozze} bozze.`); disegna(); } catch (e) { errore(e); } } }, "Associa alle bozze") : null,
      gestisce && !(x.bozze + x.emessi + x.altri + x.word) ? el("button", { class: "btn small danger", type: "button", onclick: async () => {
        if (!await GAD.conferma("Eliminare il modello?", "Si elimina solo un modello mai usato (caricato per errore).")) return;
        try { await api("DELETE", `/api/modelli-verbali-dpr/${x.id}`); toast("Modello eliminato."); disegna(); } catch (e) { errore(e); } } }, "Elimina") : null);
    return el("div", { class: "panel" }, el("h3", {}, "Modelli dei verbali DPR (M01, M02, M03)"),
      el("p", { class: "subtle" }, "I Word da cui nascono i verbali DPR. Per ogni modulo è in uso il più recente; i precedenti restano per i verbali già fatti. Un nuovo modello vale per le bozze nuove: i verbali emessi non cambiano."),
      S.tabella([
        { titolo: "Modulo", valore: (x) => x.modulo }, { titolo: "File", valore: (x) => x.nome },
        { titolo: "Stato", valore: (x) => el("span", { class: "badge " + (x.in_uso ? "ok" : "grigio") }, x.in_uso ? "in uso" : "superato") },
        { titolo: "Caricato", valore: (x) => `${formatta.dataora(x.caricato_il)}${x.caricato_da ? " · " + x.caricato_da : ""}` },
        { titolo: "Uso", valore: (x) => `${x.bozze} bozze · ${x.emessi} emessi` }, { titolo: "", valore: azioni },
      ], modelli),
      gestisce ? el("div", { class: "field-grid" }, campo("Nuovo modello (.docx)", file, { pieno: true, aiuto: "Il modulo (M01, M02, M03) si riconosce dal contenuto. Se il programma non riconosce i campi, usa l'importazione guidata." })) : null,
      gestisce ? el("div", { class: "actions" }, S.azione("Carica il modello", "primary", async () => {
        if (!file.files[0]) throw new Error("Scegli il file Word.");
        const d = new FormData(); d.append("file", file.files[0]);
        const r = await api("POST", "/api/modelli-verbali-dpr", d);
        toast(`Modello ${r.modulo} caricato.` + (r.avvisi.length ? " Avvisi: " + r.avvisi.join("; ") : "")); disegna();
      }), el("a", { class: "btn", href: "/verbali?vista=templates" }, "Importazione guidata")) : null);
  }
  disegna().catch(errore);
})();
