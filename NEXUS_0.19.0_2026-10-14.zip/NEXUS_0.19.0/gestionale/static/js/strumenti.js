/* Strumenti di misura AD_DPR, AD_DM e I&C (C16, 0.16; rc9 punto C: anche AD_DPR, prima nel registro di VerbalizzAI):
   elenco, scheda, tarature, controllo intermedio, assegnatario e stato operativo. Il verbale DPR propone gli strumenti
   attivi assegnati al verificatore. */
"use strict";

(async () => {
  const { el, api, toast, errore, pannello } = GAD;
  const S = GAD.schede;
  const { f, campo } = S;
  await S.me();
  const att = document.documentElement.dataset.ambito;
  const box = document.getElementById("griglia");
  const nome = { DPR: "AD_DPR", DM: "AD_DM", IEC: "I&C" }[att];
  if (!nome) { box.replaceChildren(el("div", { class: "notice" }, "Scegli l'attività in alto.")); document.getElementById("nuovo")?.remove(); return; }
  // assegnatari: i verificatori dell'attività (il verbale DPR propone gli strumenti assegnati al verificatore)
  let verificatori = [];
  try {
    if (att === "DPR") verificatori = (await api("GET", "/api/verifiche/valori")).verificatori || [];
    else if (att === "DM") verificatori = (await api("GET", "/api/dm/incarichi/valori")).verificatori || [];
  } catch (_) { verificatori = []; }
  const STATI = ["Attivo", "In taratura", "Fuori servizio", "Dismesso", "Non attivo"];
  if (att === "DPR" && S.puo("strumenti.gestire")) {
    // rc9: strumenti ancora nel registro di VerbalizzAI (archivi precedenti): si portano qui una volta
    try {
      const r = await api("GET", "/api/strumenti/DPR/registro-verbali");
      if (r.da_importare) box.before(el("div", { class: "notice" }, `${r.da_importare} strumenti del registro dei verbali non sono ancora qui. `,
        S.azione("Importali", "primary", async () => { const x = await api("POST", "/api/strumenti/DPR/registro-verbali", {}); toast(`Importati ${x.importati}, già presenti ${x.gia_presenti}.`); location.reload(); })));
    } catch (_) { /* niente */ }
  }
  const g = await GAD.griglia(box, "strumenti_misura", { suRiga: (r) => apri(r.id), azioni: { modifica: (r) => apri(r.id) } });

  function modulo(x) {
    x = x || { attivo: true, stato_operativo: "Attivo" };
    const assegnato = el("select", {}, el("option", { value: "" }, "—"), ...verificatori.map((v) => el("option", { value: String(v.id) }, v.nome)));
    assegnato.value = x.assegnato_id ? String(x.assegnato_id) : "";
    const stato = el("select", {}, ...STATI.map((s) => el("option", { value: s }, s)));
    stato.value = x.stato_operativo || (x.attivo === false ? "Non attivo" : "Attivo");
    const m = { codice: f.testo(x.codice, { maxlength: "60" }), denominazione: f.testo(x.denominazione, { maxlength: "200" }), costruttore: f.testo(x.costruttore, { maxlength: "120" }),
      modello: f.testo(x.modello, { maxlength: "120" }), matricola: f.testo(x.matricola, { maxlength: "120" }),
      campo_misura: f.testo(x.campo_misura, { maxlength: "200" }), ente_taratura: f.testo(x.ente_taratura, { maxlength: "200" }),
      certificato: f.testo(x.certificato, { maxlength: "120" }), data_taratura: el("input", { type: "date", value: x.data_taratura || "" }),
      scadenza_taratura: el("input", { type: "date", value: x.scadenza_taratura || "" }),
      controllo_intermedio: el("input", { type: "date", value: x.controllo_intermedio || "" }),
      scadenza_controllo_intermedio: el("input", { type: "date", value: x.scadenza_controllo_intermedio || "" }), note: f.area(x.note, { maxlength: "4000" }) };
    const griglia = el("div", { class: "field-grid" }, campo("Strumento", m.denominazione, { aiuto: "Es. «Multimetro», «Misuratore di terra»." }),
      campo("Codice interno", m.codice), campo("Costruttore", m.costruttore), campo("Modello", m.modello), campo("Matricola", m.matricola),
      campo("Assegnato a", assegnato, { aiuto: att === "DPR" ? "Il verbale DPR propone gli strumenti attivi assegnati al verificatore." : "" }),
      campo("Stato operativo", stato), campo("Campo di misura", m.campo_misura),
      campo("Ente di taratura", m.ente_taratura), campo("Certificato", m.certificato), campo("Data di taratura", m.data_taratura),
      campo("Scadenza della taratura", m.scadenza_taratura), campo("Controllo intermedio", m.controllo_intermedio),
      campo("Scadenza del controllo intermedio", m.scadenza_controllo_intermedio), campo("Note", m.note, { pieno: true }));
    return { griglia, valori: () => ({ ...Object.fromEntries(Object.entries(m).map(([k, v]) => [k, v.value])), assegnato_id: assegnato.value || null, stato_operativo: stato.value }) };
  }

  document.getElementById("nuovo")?.addEventListener("click", () => {
    const m = modulo(null);
    pannello.apri(`Nuovo strumento ${nome}`, m.griglia, [S.azione("Crea", "primary", async () => {
      const x = await api("POST", `/api/strumenti/${att}`, m.valori()); toast("Strumento creato."); g.ricarica(); apri(x.id);
    })]);
  });

  async function apri(id) {
    let x;
    try { x = await api("GET", `/api/strumenti/${att}/${id}`); } catch (e) { return errore(e); }
    const m = modulo(x);
    const storico = el("div");
    const corpo = el("div", {}, S.linguette([{ titolo: "Strumento", contenuto: m.griglia },
      { titolo: "Storico", contenuto: storico, apri: async () => storico.replaceChildren(await S.storico("strumento", x.id)) }]));
    const pulsanti = [];
    if (S.puo("strumenti.gestire")) {
      pulsanti.push(S.azione("Salva", "primary", async () => {
        await api("PUT", `/api/strumenti/${att}/${x.id}`, { ...m.valori(), versione: x.versione }); toast("Salvato."); g.ricarica(); apri(x.id);
      }));
    } else S.solaLettura(corpo);
    pannello.apri(x.denominazione, corpo, pulsanti);
  }
})().catch((e) => GAD.errore(e));
