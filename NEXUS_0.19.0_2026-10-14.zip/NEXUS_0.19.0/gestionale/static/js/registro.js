/* Registro delle operazioni: elenco e dettaglio di ogni riga. */
"use strict";

(async () => {
  const { el, api, errore, pannello, formatta } = GAD;

  function valore(v) {
    if (v === null || v === undefined || v === "") return "—";
    if (typeof v === "boolean") return v ? "Sì" : "No";
    if (typeof v === "object") return JSON.stringify(v, null, 1);
    return String(v);
  }

  function dettagli(d) {
    const chiavi = Object.keys(d || {});
    if (!chiavi.length) return el("p", { class: "subtle" }, "Nessun dettaglio aggiuntivo.");
    if (d.modifiche) {
      const righe = Object.entries(d.modifiche).map(([campo, [prima, dopo]]) => el("tr", {}, el("td", {}, campo), el("td", {}, valore(prima)), el("td", {}, valore(dopo))));
      return el("table", { class: "matrice" }, el("thead", {}, el("tr", {}, el("th", {}, "Campo"), el("th", {}, "Prima"), el("th", {}, "Dopo"))), el("tbody", {}, ...righe));
    }
    if (d.dopo && typeof d.dopo === "object") {
      const kv = el("dl", { class: "kv" });
      for (const [k, v] of Object.entries(d.dopo)) kv.append(el("dt", {}, k), el("dd", {}, valore(v)));
      const resto = Object.fromEntries(Object.entries(d).filter(([k]) => k !== "dopo"));
      return [kv, Object.keys(resto).length ? el("div", { class: "json" }, JSON.stringify(resto, null, 2)) : null].filter(Boolean);
    }
    return el("div", { class: "json" }, JSON.stringify(d, null, 2));
  }

  async function apri(id) {
    let r;
    try { r = await api("GET", `/api/registro/${id}`); } catch (e) { return errore(e); }
    pannello.apri(`Operazione n. ${r.id}`, [
      el("dl", { class: "kv" },
        el("dt", {}, "Data e ora"), el("dd", {}, formatta.dataora(r.quando)),
        el("dt", {}, "Utente"), el("dd", {}, r.utente || "—"),
        el("dt", {}, "Azione"), el("dd", {}, r.azione),
        el("dt", {}, "Oggetto"), el("dd", {}, [r.oggetto_tipo, r.oggetto_id].filter(Boolean).join(" ") || "—"),
        el("dt", {}, "Descrizione"), el("dd", {}, r.descrizione)),
      el("h3", {}, "Dettagli"),
      ...[dettagli(r.dettagli)].flat(),
      el("p", { class: "subtle" }, "Impronta: ", el("code", {}, r.impronta)),
    ]);
  }

  await GAD.griglia(document.getElementById("griglia-registro"), "registro", { suRiga: (r) => apri(r.id) });

  // rc9 (punto F): registro unico — operazioni sui verbali DPR registrate dall'archivio dei verbali (sola lettura)
  for (const b of document.querySelectorAll("[data-scheda]")) {
    b.addEventListener("click", () => {
      for (const x of document.querySelectorAll("[data-scheda]")) x.classList.toggle("active", x === b);
      for (const s of document.querySelectorAll("[data-sezione]")) s.hidden = s.dataset.sezione !== b.dataset.scheda;
      if (b.dataset.scheda === "verbali" && !caricato) carica();
    });
  }
  let caricato = false;
  const f = {
    dal: el("input", { type: "date", "aria-label": "Dal giorno" }),
    al: el("input", { type: "date", "aria-label": "Al giorno" }),
    chi: el("select", { "aria-label": "Utente" }, el("option", { value: "" }, "Tutti gli utenti")),
    categoria: el("select", { "aria-label": "Categoria" }, el("option", { value: "" }, "Tutte le categorie")),
  };
  const conta = el("span", { class: "subtle" });
  document.getElementById("filtri-verbali").append(
    el("label", {}, "Dal ", f.dal), el("label", {}, "al ", f.al), f.chi, f.categoria,
    el("button", { class: "btn", type: "button", onclick: () => carica() }, "Filtra"), conta);

  async function carica() {
    const q = new URLSearchParams();
    for (const [k, c] of Object.entries(f)) if (c.value) q.set(k, c.value);
    let r;
    try { r = await api("GET", `/api/registro-verbali?${q}`); } catch (e) { return errore(e); }
    if (!caricato) {
      for (const x of r.utenti) f.chi.append(el("option", { value: x.username }, x.nome));
      for (const x of r.categorie) f.categoria.append(el("option", { value: x.id }, x.nome));
      caricato = true;
    }
    conta.textContent = r.troncato ? `${r.righe.length} di ${r.totale} operazioni (restringi le date per vederle tutte)` : `${r.totale} operazioni`;
    const corpo = r.righe.map((x) => el("tr", {},
      el("td", {}, formatta.dataora(x.quando)), el("td", {}, x.utente || "sistema"), el("td", {}, x.operazione),
      el("td", {}, x.dettaglio || "—")));
    const box = document.getElementById("tabella-verbali");
    box.replaceChildren(r.righe.length
      ? el("table", { class: "matrice" }, el("thead", {}, el("tr", {}, el("th", {}, "Data e ora"), el("th", {}, "Utente"), el("th", {}, "Operazione"), el("th", {}, "Dettaglio"))), el("tbody", {}, ...corpo))
      : el("p", { class: "subtle" }, "Nessuna operazione sui verbali nel periodo scelto."));
  }
})().catch((e) => GAD.errore(e));
